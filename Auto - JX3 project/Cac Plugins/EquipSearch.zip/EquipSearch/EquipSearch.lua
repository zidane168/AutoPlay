﻿EquipSearch = EquipSearch or {}
EquipSearch.tNpcList = {}
local INI_FILE_PATH = "Interface/EquipSearch/EquipSearch.ini"
local EXPAND_ITEM_TYPE = {}
local PAGE_RESULT_COUNT = 50
local RESULT_PAGE_START = 1
local tDataBase = {}
tEnchant = {}
local tResult = {}
local tFilter = {
	nSort = 0,
	nSubSort = 0,
	nQuality = -1,
	szBelongSchool = "",
	szGetType = "",
	szName = "",
	nLevelMin = 0,
	nLevelMax = 99,
	nQualityLevelMin = 0,
	nQualityLevelMax = 999,
	nRepresentID = -1,
	nColorID = -1,
	}
EquipSearch = EquipSearch or {}
EquipSearch.tSearchSort =
	{
		["Vũ Khí"] =
		{
		 	nSortID = 1,
		 	tSubSort =
		 	{
		 		["Côn"]   = 1,
				["Trường Binh"]   = 2,
				["Đoãn Binh"] = 3,
				--["quyen"] = 4,
				["Song Binh"] = 5,
				["Bú"]   = 6,
				["Trọng Binh"] = 7,
				["Sáo"] = 8,
				["Thiên Cơ Hạp"] = 9,
				["Loạn Đao"] = 10,
		 	},
		},
		["Ám Khí"] =
		{
			nSortID = 2,
			tSubSort =
			{
				["Ám Tiễn"] = 1,
				["Cung"] = 2,
				--["am tien"] = 3,
				["Phi Tiêu"] = 4,
			},
		},
		["Phục Trang"] =
		{
			nSortID = 3,
			tSubSort =
			{
				["Áo"] = 1,
				["Nón"] = 2,
				["Thắt Lưng"] = 3,
				["Quần"] = 4,
				["Giầy"] = 5,
				["Bao Tay"] = 6,
			},
		},
		["Trang Sức"] =
		{
			nSortID = 4,
			tSubSort =
			{
				["Dây Chuyền"] = 1,
				["Nhẫn"] = 2,
				["Yên Trụy"] = 3,
				["Phụ Kiện Eo"] = 4,
				["Phụ Kiện Lưng"] = 5,
			},
		},
		["Thú Cưỡi"] =
		{
			nSortID = 5,
			tSubSort =
			{
				["Ngựa Trưỡng Thành"]     = 1,
				["Đầu Sức"] = 2,
				["Hung Sức"] = 3,
				["Túc Sức"] = 4,
				["Yên Sức"] = 5,
				["Ngựa Non"] = 6,
			},
		},
		["Túi"] = {nSortID = 6, tSubSort = {}, },
		["Bí Kíp"] =
		{
			nSortID = 7,
			tSubSort =
			{
				["Thuần Dương"] = 1,
				["Thiên Sách"] = 2,
				["Thiếu Lâm"] = 3,
				["Thất Tú"] = 4,
				["Vạn Hoa"] = 5,
				["Giang Hồ"] = 6,				
				["Tàng Kiếm"] = 7,
				["Ngũ Độc"] = 8,
				["Đường Môn"] = 9,
				["Minh Giáo"] = 10,
			},
		},
		["Công Thức"] =
		{
			nSortID = 8,
			tSubSort =
			{
				["May Vá"] = 1,
				["Nấu Ăn"] = 2,
				["Y Thuật"] = 3,
				["Đúc"] = 4,
			},
		},
		["Vật Phẩm"] =
		{
			nSortID = 9,
			tSubSort =
			{
				["Thức Ăn"]     = 1,
				["Thuốc"]     = 2,
				--["vat pham gia tang"] = 3,
				["Tặng Phẩm"]     = 4,
				["Cỏ Ngựa"]     = 5,
			},
		},
		["Thuộc Tính Nghề"] =
		{
			nSortID = 13,
			tSubSort =
			{
				["Nón"] = 1,
				["Áo"] = 2,
				["Quần"] = 3,
				["Thắt Lưng"] = 4,
				["Giày"] = 5,
				["Bao Tay"] = 6,
				["Vũ Khí"] = 7,
				["Trang Sức"] = 8,
			},
		},
		["Nguyên Liệu"] =
		{
			nSortID = 10,
			tSubSort =
			{
				["Khoáng"] = 1,
				["Thảo Dược"] = 2,
				["Rượu"]   = 3,
				["Vãi"] = 4,
				["Da"] = 5,
				["Thịt"] = 6,
				["Giấy Mực"] = 7,
				["Đặc Biệt"] = 8,
			},
		},
		["Sách"] =
		{
			nSortID = 12,
			tSubSort =
			{
				["Linh Tinh"] = 1,
				["Đạo Học"] = 2,
				["Phật Học"] = 3,
			},
		},
		["Đá Ngũ Hành"] =
		{
			nSortID = 15,
			tSubSort =
			{
				["Kim"] = 1,
				["Môc"] = 2,
				["Thủy"] = 3,
				["Hỏa"] = 4,
				["Thổ"] = 5,
				["Đá Ngũ Sắc"] = 6,
			},
		},
		["Bảo Rương"] =
		{
			nSortID = 16,
			tSubSort =
			{
				["Rương"] = 1,
				["Chìa Khóa"] = 2,
			},
		},
		["Sản Vật Bang Hội"] =
		{
			nSortID = 14,
			tSubSort =
			{
				["Hồn Thạch"] = 1,
				["Khác"] = 2,
			},
		},
		["Khác"] =
		{
			nSortID = 20,
			tSubSort =
			{
				["Rác"] = 1,
				["Khác"] = 2,
			},
		},
	}

function EquipSearch.GetItemAuctionType(nAucType, nAucSubType)
    for k, v in pairs(EquipSearch.tSearchSort) do
        if v.nSortID == nAucType then
            for szKey, nID in pairs(v.tSubSort) do
                if nID == nAucSubType then
                    return szKey
                end
            end
        end
    end
end

function EquipSearch.FormatItemInfo(tLine, dwType)
	local szItemName = Table_GetItemName(tLine.UiID)
	return{
		dwTabType = dwType,
		nItemID = tLine.ID,	--��ƷID
		szName = szItemName,	--��Ʒ����
		nRepresentID = tLine.RepresentID or 0,	--ģ��ID
		nColorID = tLine.ColorID or 0,	--��ɫID
		szEquipType = EquipSearch.GetItemAuctionType(tLine.AucGenre, tLine.AucSubType) or "",	--װ������
		nRequireLevel = tLine.Require1Value or 0,	--����ȼ�
		nQualityLevel = tLine.Level or 0,	--װ��Ʒ��
		nQuality = tLine.Quality or 0,	--װ��Ʒ��	
		szBelongSchool = tLine.BelongSchool or "",	--����ְҵ
		szMagicKind = tLine.MagicKind or "",	--����
		szMagicType = tLine.MagicType or "",	--����
		szGetType = tLine.GetType or "",	--��ȡ����
		szBelongMap = tLine.BelongMap or "",  --����
		nAucGenre = tLine.AucGenre,
		nAucSubType = tLine.AucSubType,
		nCampRequest = tLine.RequireCamp,	--��Ӫ����
		}
end

function EquipSearch.FilterItem(tData)
	if (tFilter.nSort==0 or tFilter.nSort==tData.nAucGenre) and 
		(tFilter.nSubSort==0 or tFilter.nSubSort==tData.nAucSubType) and
		(tFilter.nQuality==-1 or tFilter.nQuality==tData.nQuality) and
		(tFilter.szName=="" or StringFindW(tData.szName, tFilter.szName) ) and
		(tFilter.szBelongSchool =="" or StringFindW(tData.szBelongSchool, tFilter.szBelongSchool) ) and
		(tFilter.szGetType =="" or StringFindW(tData.szGetType, tFilter.szGetType) ) and
		(tFilter.nLevelMin <= tData.nRequireLevel)	and 
		(tFilter.nLevelMax >= tData.nRequireLevel)	and 
		(tFilter.nQualityLevelMin <= tData.nQualityLevel)	and 
		(tFilter.nQualityLevelMax >= tData.nQualityLevel)	and
		(tFilter.nRepresentID==-1 or tFilter.nRepresentID==tData.nRepresentID) and
		(tFilter.nColorID==-1 or tFilter.nColorID==tData.nColorID) 
		then
		return	true
	else
		return false
	end
end

function EquipSearch.ResetFilter()
	local frame = Station.Lookup("Normal/EquipSearch")
	local hWnd = frame:Lookup("Wnd_Search")
	hWnd:Lookup("Edit_ItemName"):SetText("")
	hWnd:Lookup("Edit_Level1"):SetText("")
	hWnd:Lookup("Edit_Level2"):SetText("")
	hWnd:Lookup("Edit_QualityLevel1"):SetText("")
	hWnd:Lookup("Edit_QualityLevel2"):SetText("")
	hWnd:Lookup("Edit_RepresentID"):SetText("")
	hWnd:Lookup("Edit_ColorID"):SetText("")
	
	tFilter.nQuality = -1
	tFilter.szBelongSchool = ""
	tFilter.szGetType = ""
	tFilter.szName = ""
	tFilter.nLevelMin = 0
	tFilter.nLevelMax = 99
	tFilter.nQualityLevelMin = 0
	tFilter.nQualityLevelMax = 999
	tFilter.nRepresentID = -1
	tFilter.nColorID = -1
	EquipSearch.UpdateResult()
end

--ˢ���������
function EquipSearch.UpdateResult()
	local frame = Station.Lookup("Normal/EquipSearch")
	
	tResult = {}
	RESULT_PAGE_START = 1
	local nCount = 0 
	
	for i=2,#tDataBase,1 do
		tData = tDataBase[i]
		if EquipSearch.FilterItem(tData) then
			table.insert(tResult, tData)
		end
	end
	
	
	EquipSearch.UpdateResultList(frame, RESULT_PAGE_START, tResult)
end

--��������
function EquipSearch.LoadData()
	tDataBase = {}
	EquipSearch.Custom_Armor_List = KG_Table.Load(EquipSearch.Custom_Armor_Tab.Path, EquipSearch.Custom_Armor_Tab.Title)
	EquipSearch.Custom_Weapon_List = KG_Table.Load(EquipSearch.Custom_Weapon_Tab.Path, EquipSearch.Custom_Weapon_Tab.Title)
	EquipSearch.Custom_Trinket_List = KG_Table.Load(EquipSearch.Custom_Trinket_Tab.Path, EquipSearch.Custom_Trinket_Tab.Title)
	EquipSearch.Custom_Other_List = KG_Table.Load(EquipSearch.Custom_Other_Tab.Path, EquipSearch.Custom_Other_Tab.Title)

	nCount = EquipSearch.Custom_Armor_List:GetRowCount()
	for i=2,nCount,1 do
		tLine = EquipSearch.Custom_Armor_List:GetRow(i)
		tData = EquipSearch.FormatItemInfo(tLine, ITEM_TABLE_TYPE.CUST_ARMOR)
		table.insert(tDataBase, tData)
	end
	
	nCount = EquipSearch.Custom_Weapon_List:GetRowCount()
	for i=2,nCount,1 do
		tLine = EquipSearch.Custom_Weapon_List:GetRow(i)
		tData = EquipSearch.FormatItemInfo(tLine, ITEM_TABLE_TYPE.CUST_WEAPON)
		table.insert(tDataBase, tData)
	end
	
	nCount = EquipSearch.Custom_Trinket_List:GetRowCount()
	for i=2,nCount,1 do
		tLine = EquipSearch.Custom_Trinket_List:GetRow(i)
		tData = EquipSearch.FormatItemInfo(tLine, ITEM_TABLE_TYPE.CUST_TRINKET)
		table.insert(tDataBase, tData)
	end
	
	nCount = EquipSearch.Custom_Other_List:GetRowCount()
	for i=2,nCount,1 do
		tLine = EquipSearch.Custom_Other_List:GetRow(i)
		tData = EquipSearch.FormatItemInfo(tLine, ITEM_TABLE_TYPE.OTHER)
		table.insert(tDataBase, tData)
	end
	
	EquipSearch.Custom_Armor_List = nil
	EquipSearch.Custom_Weapon_List = nil
	EquipSearch.Custom_Trinket_List = nil
	EquipSearch.Custom_Other_List = nil
	
	--�Ӹ�ħ���ݶ�ȡ���߱���ID--
	EquipSearch.Enchant_List = KG_Table.Load(EquipSearch.Enchant_Tab.Path, EquipSearch.Enchant_Tab.Title)
	nCount = EquipSearch.Enchant_List:GetRowCount()
	for i=2,nCount,1 do
		tLine = EquipSearch.Enchant_List:GetRow(i)
		tData = {
		nRepresentIndex = tLine.RepresentIndex or 0,
		nRepresentID = tLine.RepresentID or 0,
		nUIID = tLine.UIID or 0,
		}
		if tData["nRepresentIndex"] >= 27 and tData["nRepresentIndex"] <= 30 then
			table.insert(tEnchant, tData)
		end
	end
	EquipSearch.Enchant_List = nil
end

function EquipSearch.OnFrameCreate()
	EquipSearch.UpdateItemTypeList(this)
	EquipSearch.ResetFilter()
end

RegisterEvent("NPC_ENTER_SCENE", function()
	EquipSearch.tNpcList[arg0] = 0
end)

RegisterEvent("NPC_LEAVE_SCENE", function()
	EquipSearch.tNpcList[arg0] = nil
end)

function EquipSearch.OnFrameBreathe()
	local frame = Station.Lookup("Normal/EquipSearch")
	local hWnd = frame:Lookup("Wnd_Search")
	tFilter.szName =  hWnd:Lookup("Edit_ItemName"):GetText() or ""
	tFilter.nLevelMin = tonumber(hWnd:Lookup("Edit_Level1"):GetText()) or 0
	tFilter.nLevelMax = tonumber(hWnd:Lookup("Edit_Level2"):GetText()) or 99
	tFilter.nQualityLevelMin = tonumber(hWnd:Lookup("Edit_QualityLevel1"):GetText()) or 0
	tFilter.nQualityLevelMax = tonumber(hWnd:Lookup("Edit_QualityLevel2"):GetText()) or 999
	tFilter.nRepresentID = tonumber(hWnd:Lookup("Edit_RepresentID"):GetText()) or -1
	tFilter.nColorID = tonumber(hWnd:Lookup("Edit_ColorID"):GetText()) or -1

end

--ˢ��Ŀ¼�˵�
function EquipSearch.UpdateItemTypeList(frame)
	local tItemType = {}
	for k, tSubType in pairs(EquipSearch.tSearchSort) do
		if tSubType.nSortID ~= 12 then --���˵��鼮ѡ��
			tItemType[tSubType.nSortID] = {szType = k, tSubType = {}}
			for i, v in pairs(tSubType.tSubSort) do
				tItemType[tSubType.nSortID].tSubType[v] = i
			end
		end
	end

	local hWnd = frame:Lookup("Wnd_Search")
	local hListLv1 = hWnd:Lookup("", "Handle_SearchList")
	hListLv1:Clear()

	for k, v in pairs(tItemType) do
		local hListLv2 = hListLv1:AppendItemFromIni(INI_FILE_PATH, "Handle_ListContent")
		local imgBg1 = hListLv2:Lookup("Image_SearchListBg1")
		local imgBg2 = hListLv2:Lookup("Image_SearchListBg2")
		local imgCover = hListLv2:Lookup("Image_SearchListCover")
		local imgMin = hListLv2:Lookup("Image_Minimize")

		if EXPAND_ITEM_TYPE.szType == v.szType then
			hListLv2.bSel = true
			local hListLv3 = hListLv2:Lookup("Handle_Items")
	    	local w, h = EquipSearch.AddItemSubTypeList(hListLv3, v.tSubType or {})
	    	imgBg1:Hide()
	    	imgBg2:Show()
	    	imgCover:Show()
	    	imgMin:SetFrame(8)

	    	local wB, _ = imgBg2:GetSize()
	    	imgBg2:SetSize(wB, h + 50)

	    	local wL, _ = hListLv2:GetSize()
	    	hListLv2:SetSize(wL, h + 50)
	    else
	    	imgBg1:Show()
	    	imgBg2:Hide()
	    	imgCover:Hide()
	    	imgMin:SetFrame(12)
	    	imgBg2:SetSize(0, 0)

	    	local w, h = imgBg1:GetSize()
	    	hListLv2:SetSize(w, h)
	    end

		hListLv2:Lookup("Text_ListTitle"):SetText(v.szType)
	end
	EquipSearch.OnUpdateItemTypeList(hListLv1)	--ˢ�¹�����
end

--������Ŀ¼�˵�
function EquipSearch.AddItemSubTypeList(hList, tSubType)
	for k, v in pairs(tSubType) do
		local hItem = hList:AppendItemFromIni(INI_FILE_PATH, "Handle_List01")
		local imgCover =  hItem:Lookup("Image_SearchListCover01")
		if EXPAND_ITEM_TYPE.szSubType == v then
			hItem.bSel = true
			imgCover:Show()
		else
			imgCover:Hide()
		end

		hItem:Lookup("Text_List01"):SetText(v)

	end
	hList:Show()
	hList:FormatAllItemPos()
	hList:SetSizeByAllItemSize()
	return hList:GetSize()
end

--ˢ��Ŀ¼������
function EquipSearch.OnUpdateItemTypeList(hList)
	hList:FormatAllItemPos()
	local hWnd = hList:GetParent():GetParent()
	local scroll = hWnd:Lookup("Scroll_Search")
	local w, h = hList:GetSize()
	local wAll, hAll = hList:GetAllItemSize()
	local nStepCount = math.ceil((hAll - h) / 10)

	scroll:SetStepCount(nStepCount)
	if nStepCount > 0 then
		scroll:Show()
		hWnd:Lookup("Btn_SUp"):Show()
		hWnd:Lookup("Btn_SDown"):Show()
	else
		scroll:Hide()
		hWnd:Lookup("Btn_SUp"):Hide()
		hWnd:Lookup("Btn_SDown"):Hide()
	end
end

--������������б�
function EquipSearch.UpdateResultList(frame, nStart, tResult)
	if not tItemInfo then
		tItemInfo = {}
	end
	local player = GetClientPlayer()
	local hList, szItem = nil, nil
	local hList = frame:Lookup("Wnd_Result", "Handle_List")

	hList:Clear()
	hList.hSelItem = nil
    local nEnd = nStart + PAGE_RESULT_COUNT - 1
    nEnd = math.min(nEnd, #tResult)
    for i=nStart, nEnd, 1 do
        local tItem = tResult[i]
        local hItem = hList:AppendItemFromIni(INI_FILE_PATH, "Handle_ItemList")
        local hBox = hItem:Lookup("Box_Bg")
        local hItemInfo = GetItemInfo(tItem.dwTabType, tItem.nItemID)
        local nIconID = Table_GetItemIconID(hItemInfo.nUiId)
        local tRecommend = g_tTable.EquipRecommend:Search(hItemInfo.nRecommendID)
        local szSchool = ""
        if tRecommend and tRecommend.szDesc then
            szSchool = tRecommend.szDesc
        end
        hItem.dwTabType = tItem.dwTabType
        hItem.nItemID = tItem.nItemID
		hItem.nRepresentID = tItem.nRepresentID
		hItem.nColorID = tItem.nColorID
		hItem.szEquipType = tItem.szEquipType
		
        hBox.dwTabType = tItem.dwTabType
        hBox.nItemID = tItem.nItemID
		hBox.nRepresentID = tItem.nRepresentID
		hBox.nColorID = tItem.nColorID
		hBox.szEquipType = tItem.szEquipType
        local szKey = tItem.dwTabType..tItem.nItemID

        hBox:SetObject(UI_OBJECT_ITEM_INFO, GLOBAL.CURRENT_ITEM_VERSION, tItem.dwTabType, tItem.nItemID)
        hBox:SetObjectIcon(nIconID)
        hItem:Lookup("Text_BoxName"):SetText(tItem.szName)
        local r, g, b = GetItemFontColorByQuality(hItemInfo.nQuality)
        hItem:Lookup("Text_BoxName"):SetFontColor(r, g, b)
        hItem:Lookup("Text_BoxCategory"):SetText(tItem.szEquipType)
        hItem:Lookup("Text_BoxLevel"):SetText(tItem.nRequireLevel)
        hItem:Lookup("Text_BoxQuality"):SetText(tItem.nQualityLevel)
        hItem:Lookup("Text_BoxRepresent"):SetText(hItem.nRepresentID)
        hItem:Lookup("Text_BoxColor"):SetText(tItem.nColorID)
        hItem:Lookup("Text_BoxSchool"):SetText(tItem.szBelongSchool.." "..tItem.szMagicKind.." "..tItem.szMagicType)
        hItem:Lookup("Text_BoxDrop"):SetText(tItem.szGetType.." "..tItem.szBelongMap)
        if i == nStart then
            EquipSearch.Selected(hItem)
        end
        EquipSearch.UpdateBgStatus(hItem, "Image_Light")
    end
    EquipSearch.OnUpdateItemList(hList, true)	--ˢ���������������
    
    local hWndRes = frame:Lookup("Wnd_Search")
    EquipSearch.UpdatePageInfo(hWndRes, nStart, #tResult)	--ˢ�½���б���ҳ
end

--ˢ�½���б���ҳ��ť
function EquipSearch.UpdatePageInfo(hWnd, nStart, nTotal)
	local player = GetClientPlayer()
	local btnBack = hWnd:Lookup("Btn_Back1")
	local btnNext = hWnd:Lookup("Btn_Next1")
	local text    = hWnd:Lookup("", "Text_Page1")

	local nEnd = nStart + PAGE_RESULT_COUNT - 1
	nEnd = math.min(nEnd, nTotal)
	btnBack:Enable(nStart ~= 1)
	btnNext:Enable(nEnd < nTotal)
	if nTotal == 0 then
		text:SetText("(0-0(0))")
	else
		if nEnd > nTotal then
			local szText = ""
			local nLargest = GetIntergerBit(nTotal)
			for i = 1, nLargest do
				szText = szText .. "?"
			end
			text:SetText(szText.."-"..szText.." ("..nTotal..")")
		else
			text:SetText(nStart.."-"..nEnd.." ("..nTotal..")")
		end
	end
end

--ˢ�½����ѡ�������
function EquipSearch.UpdateBgStatus(hItem, szImage)

	if not hItem then
		return
	end
	local img = hItem:Lookup(szImage)
	if not img then
		return
	end

	if hItem.bSel then
		img:Show()
		img:SetAlpha(255)
	elseif hItem.bOver then
		img:Show()
		img:SetAlpha(128)
	else
		img:Hide()
	end
end

--ѡ����Ŀ
function EquipSearch.Selected(hItem)
	if hItem then
		local hList = hItem:GetParent()
		local nCount = hList:GetItemCount() - 1
		for i=0, nCount, 1 do
			local hI = hList:Lookup(i)
			if hI.bSel then
				hI.bSel = false
				AuctionPanel.UpdateBgStatus(hI)
			end
		end
		hItem.bSel = true
		EquipSearch.UpdateBgStatus(hItem, "Image_Light")
	end
end

--ˢ���������������
function EquipSearch.OnUpdateItemList(hList, bDefault)
	hList:FormatAllItemPos()
	local hWnd = hList:GetParent():GetParent()
	local scroll = hWnd:Lookup("Scroll_Result")
	local w, h = hList:GetSize()
	local wAll, hAll = hList:GetAllItemSize()
	local nStepCount = math.ceil((hAll - h) / 10)

	scroll:SetStepCount(nStepCount)
	if nStepCount > 0 then
		scroll:Show()
		hWnd:Lookup("Btn_RUp"):Show()
		hWnd:Lookup("Btn_RDown"):Show()
	else
		scroll:Hide()
		hWnd:Lookup("Btn_RUp"):Hide()
		hWnd:Lookup("Btn_RDown"):Hide()
	end
	if bStart then
		scroll:SetScrollPos(0)
	end
end

function EquipSearch.OnItemLButtonClick()
	local szName = this:GetName()
	if szName == "Handle_ListContent" then
		local szType = this:Lookup("Text_ListTitle"):GetText()
		if EXPAND_ITEM_TYPE.szType == szType then
			EXPAND_ITEM_TYPE = {}
			tFilter.nSort = 0
			tFilter.nSubSort = 0
		else
			EXPAND_ITEM_TYPE.szType = szType
			tFilter.nSort = EquipSearch.tSearchSort[szType].nSortID or 0
			tFilter.nSubSort = 0
		end
		EquipSearch.UpdateItemTypeList(this:GetRoot())	--ˢ��Ŀ¼
		EquipSearch.UpdateResult()	--ˢ�½��
		PlaySound(SOUND.UI_SOUND,g_sound.Button)
	elseif szName == "Handle_List01" then
		local szSubType = this:Lookup("Text_List01"):GetText()
		EXPAND_ITEM_TYPE.szSubType = szSubType
		tFilter.nSubSort = EquipSearch.tSearchSort[EXPAND_ITEM_TYPE.szType].tSubSort[EXPAND_ITEM_TYPE.szSubType] or 0
		EquipSearch.UpdateItemTypeList(this:GetRoot())
		EquipSearch.UpdateResult()	--ˢ�½��
	elseif szName == "Handle_ItemList" or szName == "Box_Bg" then
		if szName == "Handle_ItemList" then
			EquipSearch.Selected(this)
		else
			EquipSearch.Selected(this:GetParent())
		end
		local iteminfo = GetItemInfo(this.dwTabType, this.nItemID)
		if IsCtrlKeyDown() then
			local frame = Station.Lookup("Lowest2/EditBox")
			if not frame:IsVisible() then
				frame:Show()
				local hEditInput = frame:Lookup("Edit_Input")
				Station.SetFocusWindow(hEditInput)
			end	
			if iteminfo then
				local szName = "["..Table_GetItemName(iteminfo.nUiId).."]"		
				local edit = Station.Lookup("Lowest2/EditBox/Edit_Input")
				edit:InsertObj(szName, {type = "iteminfo", text = szName, version = GLOBAL.CURRENT_ITEM_VERSION, tabtype = this.dwTabType, index = this.nItemID})
				Station.SetFocusWindow(edit)
			end
		elseif IsShiftKeyDown() then
			local player = GetClientPlayer()
			if not player then
				return 
			end 
			--����Ԥ��--
			if iteminfo.nSub == EQUIPMENT_SUB.HORSE then
				local frame = Station.Lookup("Normal/HorseStable")
				if frame and frame:Lookup("", "Handle_ItemList"):IsVisible() then
					frame:Lookup("", "Text_Title"):SetText("����Ԥ��")
					frame:Lookup("", "Handle_ItemList"):Hide()
				end
				if not frame then
					local dwNpcID = 0
					for dwID, _ in pairs(EquipSearch.tNpcList) do
						local npc = GetNpc(dwID)
						if npc and npc.CanDialog(player) then
							dwNpcID = dwID
							break
						end
					end
					if dwNpcID == 0 then
						OutputMessage("MSG_SYS",  "��EquipSearch��վ������NPC����6�����ڷ���Ԥ����������ߣ�\n")
						return
					end
					frame = Wnd.OpenWindow("HorseStable")		
					frame.dwNpcID = dwNpcID
					frame:Lookup("", "Text_Title"):SetText("����Ԥ��")
					frame:Lookup("", "Handle_ItemList"):Hide()
				end

				local tRepresentID = frame.tRepresentID or player.GetRepresentID()
				if this.szEquipType == "����" then					
					tRepresentID[EQUIPMENT_REPRESENT.HORSE_STYLE] = this.nRepresentID
					if iteminfo.nDetail ~= 0 then --��������Ƴ�����
						if not frame.bHorseAdornmentSaved then
							frame.nHorseAdornment1 = tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT1]
							frame.nHorseAdornment2 = tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT2]
							frame.nHorseAdornment3 = tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT3]
							frame.nHorseAdornment4 = tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT4]
							frame.bHorseAdornmentSaved = true
						end
						tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT1] = 0
						tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT2] = 0
						tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT3] = 0
						tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT4] = 0
					else
						if frame.bHorseAdornmentSaved then
							tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT1] = frame.nHorseAdornment1
							tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT2] = frame.nHorseAdornment2
							tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT3] = frame.nHorseAdornment3
							tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT4] = frame.nHorseAdornment4
							frame.bHorseAdornmentSaved = false
						end
					end
					FireUIEvent("RIDES_MODEL_PREVIEW_UPDATE", "HorseStable", "HorseStable", tRepresentID)
					frame:Lookup("", "Handle_Preview"):Lookup("Text_RideName"):SetText(Table_GetItemName(iteminfo.nUiId))
					frame:Lookup("", "Handle_Preview"):Lookup("Text_RideName"):Show()
				elseif this.szEquipType == "����ͷ��" or this.szEquipType == "���ﰰ��" or this.szEquipType == "��������" or this.szEquipType == "��������" then
					if frame.bHorseAdornmentSaved then
						OutputMessage("MSG_SYS",  "��EquipSearch���������޷�װ�����ߣ�\n")
						return
					end
					if this.szEquipType == "��������" then
						tRepresentID[EQUIPMENT_REPRESENT.HORSE_ADORNMENT4] = 0
					end
					for i = 1, #tEnchant do
						if tEnchant[i].nUIID == iteminfo.nUiId then
							tRepresentID[tEnchant[i].nRepresentIndex] = tEnchant[i].nRepresentID
							break
						end
					end
					FireUIEvent("RIDES_MODEL_PREVIEW_UPDATE", "HorseStable", "HorseStable", tRepresentID)
				end
				frame.tRepresentID = tRepresentID
				return
			end
			--����Ԥ��--
			if iteminfo.nSub == EQUIPMENT_SUB.PET then
				local tPet = nil
				local szName = Table_GetItemName(iteminfo.nUiId)
				for i = 1, 50 do 
					tPet = g_tTable.FellowPet:Search(i)
					if not tPet then
						return 
					end 
					if tPet.szName == szName then
						break
					end 
				end 
				if not tPet then
					return 
				end 
				local frame = Station.Lookup("Normal/CharacterPanel")
				frame:Show()
				frame:Lookup("Page_Main"):ActivePage("Page_Ride")
				frame:Lookup("Page_Main/Page_Ride/PageSet_Ride"):ActivePage("Page_Pet")
				FireUIEvent("NPC_MODEL_PREVIEW_UPDATE", "CharacterPanel", "CharacterPanel", tPet.dwModelID, tPet.nColorChannelTable, tPet.nColorChannel, tPet.fModelScale, {0, 150, -200, 0, 50, 70})
				local handle = frame:Lookup("Page_Main/Page_Ride/PageSet_Ride/Page_Pet"):Lookup("","Handle_Basck")
				handle:Lookup("Text_PetName"):SetText(FormatString(g_tStrings.CHARACTER_PET_NAME, tPet.szName, tPet.szClass))
				handle:Lookup("Text_PetName"):Show()
				handle:Lookup("Text_Level"):Show()
				handle:Lookup("Text_PetLevel"):SetText(tPet.nLevel)
				handle:Lookup("Text_PetLevel"):Show()
				return
			end
			--����װ��Ԥ��--
			local Sub2RepresentID =
				{
					[EQUIPMENT_SUB.MELEE_WEAPON]  = EQUIPMENT_REPRESENT.WEAPON_STYLE,
					[EQUIPMENT_SUB.CHEST]                  = EQUIPMENT_REPRESENT.CHEST_STYLE,
					[EQUIPMENT_SUB.HELM]                   = EQUIPMENT_REPRESENT.HELM_STYLE,
					[EQUIPMENT_SUB.WAIST]                  = EQUIPMENT_REPRESENT.WAIST_STYLE,
					[EQUIPMENT_SUB.BOOTS]                 = EQUIPMENT_REPRESENT.BOOTS_STYLE,
					[EQUIPMENT_SUB.BANGLE]               = EQUIPMENT_REPRESENT.BANGLE_STYLE,
					[EQUIPMENT_SUB.WAIST_EXTEND]    = EQUIPMENT_REPRESENT.WAIST_EXTEND,
					[EQUIPMENT_SUB.BACK_EXTEND]      = EQUIPMENT_REPRESENT.BACK_EXTEND,
					[EQUIPMENT_SUB.FACE_EXTEND]       = EQUIPMENT_REPRESENT.FACE_EXTEND,
				}
			if iteminfo.nGenre ~= ITEM_GENRE.EQUIPMENT or not Sub2RepresentID[iteminfo.nSub] then
				return
			end
			
			local frame = Station.Lookup("Normal/ExteriorView")
			if not frame then
				frame = Wnd.OpenWindow("ExteriorView")
			end
			local tRepresentID = frame.tRepresentID or player.GetRepresentID()

			if iteminfo.nSub == EQUIPMENT_SUB.MELEE_WEAPON and iteminfo.nDetail == WEAPON_DETAIL.BIG_SWORD then
				tRepresentID[EQUIPMENT_REPRESENT.BIG_SWORD_STYLE] = this.nRepresentID
			elseif Sub2RepresentID[iteminfo.nSub] then
				tRepresentID[Sub2RepresentID[iteminfo.nSub]] = this.nRepresentID
			end
			
			local Sub2ColorID =
				{
					[EQUIPMENT_SUB.MELEE_WEAPON]  = EQUIPMENT_REPRESENT.WEAPON_COLOR,
					[EQUIPMENT_SUB.CHEST]                  = EQUIPMENT_REPRESENT.CHEST_COLOR,
					[EQUIPMENT_SUB.HELM]                   = EQUIPMENT_REPRESENT.HELM_COLOR,
					[EQUIPMENT_SUB.WAIST]                  = EQUIPMENT_REPRESENT.WAIST_COLOR,
					[EQUIPMENT_SUB.BOOTS]                 = EQUIPMENT_REPRESENT.BOOTS_COLOR,
					[EQUIPMENT_SUB.BANGLE]               = EQUIPMENT_REPRESENT.BANGLE_COLOR,
				}			
			if iteminfo.nSub == EQUIPMENT_SUB.MELEE_WEAPON and iteminfo.nDetail == WEAPON_DETAIL.BIG_SWORD then
				tRepresentID[EQUIPMENT_REPRESENT.BIG_SWORD_COLOR] = this.nColorID
			elseif Sub2ColorID[iteminfo.nSub] then
				tRepresentID[Sub2ColorID[iteminfo.nSub]] = this.nColorID
			end
			
			FireUIEvent("EXTERIOR_CHARACTER_UPDATE", "ExteriorView", "ExteriorView", tRepresentID)
			frame.tRepresentID = tRepresentID
		end
	end
end

function EquipSearch.OnScrollBarPosChanged()
	local hWnd = this:GetParent()
	local nCurrentValue = this:GetScrollPos()
	local szName = this:GetName()
	local hBtnUp, hBtnDown, hList = nil, nil, nil
	if szName == "Scroll_Result" then
		hBtnUp = hWnd:Lookup("Btn_RUp")
		hBtnDown = hWnd:Lookup("Btn_RDown")
		hList = hWnd:Lookup("", "Handle_List")
	elseif szName == "Scroll_Search" then
		hBtnUp = hWnd:Lookup("Btn_SUp")
		hBtnDown = hWnd:Lookup("Btn_SDown")
		hList = hWnd:Lookup("", "Handle_SearchList")
	end

	if nCurrentValue == 0 then
		hBtnUp:Enable(false)
	else
		hBtnUp:Enable(true)
	end

	if nCurrentValue == this:GetStepCount() then
		hBtnDown:Enable(false)
	else
		hBtnDown:Enable(true)
	end
	hList:SetItemStartRelPos(0, -nCurrentValue * 10)
end

function EquipSearch.OnItemMouseWheel()
	local nDistance = Station.GetMessageWheelDelta()
	local szName = this:GetName()
	if szName == "Handle_List" then
		this:GetParent():GetParent():Lookup("Scroll_Result"):ScrollNext(nDistance)
	elseif szName == "Handle_SearchList" then
		this:GetParent():GetParent():Lookup("Scroll_Search"):ScrollNext(nDistance)
	end
	return true
end

function EquipSearch.OnLButtonHold()
	local szName = this:GetName()
	if szName == "Btn_RUp" then
		this:GetParent():Lookup("Scroll_Result"):ScrollPrev()
	elseif szName == "Btn_RDown" then
		this:GetParent():Lookup("Scroll_Result"):ScrollNext()
	elseif szName == "Btn_SUp" then
		this:GetParent():Lookup("Scroll_Search"):ScrollPrev()
	elseif szName == "Btn_SDown" then
		this:GetParent():Lookup("Scroll_Search"):ScrollNext()
	end
end

function EquipSearch.OnItemMouseEnter()
	local szName = this:GetName()
    if szName == "Box_Bg" then
		if not this:IsEmpty() then
			local x, y = this:GetAbsPos()
			local w, h = this:GetSize()
            OutputItemTip(UI_OBJECT_ITEM_INFO, GLOBAL.CURRENT_ITEM_VERSION, this.dwTabType, this.nItemID, {x, y, w, h})
		end
	elseif szName == "Handle_ItemList" or szName == "Handle_ListContent" or szName == "Handle_List01" then
		local tImage = 
        {
            ["Handle_ItemList"] = "Image_Light",
            ["Handle_ListContent"] = "Image_SearchListCover",
            ["Handle_List01"] = "Image_SearchListCover01",
        }
        this.bOver = true
		EquipSearch.UpdateBgStatus(this, tImage[szName])
        
    elseif this:IsLink() and this:GetType() == "Text" then
        this.nFont=this:GetFontScheme()
        this:SetFontScheme(188)
	end
end

function EquipSearch.OnItemMouseLeave()
	local szName = this:GetName()
	if szName == "Box_Bg" then
		HideTip()
	elseif szName == "Handle_ItemList" or szName == "Handle_ListContent" or szName == "Handle_List01" then
        local tImage = 
        {
            ["Handle_ItemList"] = "Image_Light",
            ["Handle_ListContent"] = "Image_SearchListCover",
            ["Handle_List01"] = "Image_SearchListCover01",
        }
		this.bOver = false
		EquipSearch.UpdateBgStatus(this, tImage[szName])
    elseif this:IsLink() and this:GetType() == "Text" then
        this:SetFontScheme(this.nFont)
	end
end

function EquipSearch.OnLButtonClick() 
		local frame = Station.Lookup("Normal/EquipSearch")
    local szName = this:GetName()
    if szName == "Btn_Search" then
        EquipSearch.UpdateResult()
    elseif szName == "Btn_SearchDefault" then
    		EquipSearch.ResetFilter()				
    elseif szName == "Btn_Back1" then
        RESULT_PAGE_START = math.max(1, RESULT_PAGE_START - PAGE_RESULT_COUNT)
        EquipSearch.UpdateResultList(frame, RESULT_PAGE_START, tResult)
    elseif szName == "Btn_Next1" then
        RESULT_PAGE_START = RESULT_PAGE_START + PAGE_RESULT_COUNT
        EquipSearch.UpdateResultList(frame, RESULT_PAGE_START, tResult)
    elseif szName == "Btn_Filter" then
    
				if not this:IsEnabled() then
					return
				end
				local text = this:GetParent():Lookup("", "Text_Filter")
				local xA, yA = text:GetAbsPos()
				local w, h = text:GetSize()
				local menu =
					{
						nMiniWidth = w,
						x = xA, y = yA + h,
						fnCancelAction = function()
							local btn = Station.Lookup("Normal/EquipSearch/Wnd_Search/Btn_Filter")
							if btn then
								local x, y = Cursor.GetPos()
								local xA, yA = btn:GetAbsPos()
								local w, h = btn:GetSize()
								if x >= xA and x < xA + w and y >= yA and y <= yA + h then
									btn.bIgnor = true
								end
							end
						end,
						fnAction = function(UserData, bCheck)
							local frame = Station.Lookup("Normal/EquipSearch")
						end,
						fnAutoClose = function() if EquipSearch.IsOpened() then return false else return true end end,
					}
		
			   table.insert(menu, {szOption = "Ʒ�ʹ���",
			   {szOption = "�κ�Ʒ��", bMCheck = true, bChecked = (tFilter.nQuality == -1), fnAction = function() tFilter.nQuality = -1 EquipSearch.UpdateResult() end,},
			   {szOption = "�ư�", bMCheck = true, bChecked = (tFilter.nQuality == 0), fnAction = function() tFilter.nQuality = 0 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(0, false)},},
			   {szOption = "��ͨ", bMCheck = true, bChecked = (tFilter.nQuality == 1), fnAction = function() tFilter.nQuality = 1 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(1, false)},},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.nQuality == 2), fnAction = function() tFilter.nQuality = 2 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(2, false)},},
			   {szOption = "׿Խ", bMCheck = true, bChecked = (tFilter.nQuality == 3), fnAction = function() tFilter.nQuality = 3 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(3, false)},},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.nQuality == 4), fnAction = function() tFilter.nQuality = 4 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(4, false)},},
			   {szOption = "ϡ��", bMCheck = true, bChecked = (tFilter.nQuality == 5), fnAction = function() tFilter.nQuality = 5 EquipSearch.UpdateResult() end,rgb = {GetItemFontColorByQuality(5, false)},},
			  }
			   )
			   table.insert(menu, {szOption = "���ɹ���",
			   {szOption = "�κ�����", bMCheck = true, bChecked = (tFilter.szBelongSchool == ""), fnAction = function() tFilter.szBelongSchool = "" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szBelongSchool == "����"), fnAction = function() tFilter.szBelongSchool = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szBelongSchool == "����"), fnAction = function() tFilter.szBelongSchool = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szBelongSchool == "����"), fnAction = function() tFilter.szBelongSchool = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "���", bMCheck = true, bChecked = (tFilter.szBelongSchool == "���"), fnAction = function() tFilter.szBelongSchool = "���" EquipSearch.UpdateResult() end,},
			   {szOption = "��", bMCheck = true, bChecked = (tFilter.szBelongSchool == "��"), fnAction = function() tFilter.szBelongSchool = "��" EquipSearch.UpdateResult() end,},
			   {szOption = "�ؽ�", bMCheck = true, bChecked = (tFilter.szBelongSchool == "�ؽ�"), fnAction = function() tFilter.szBelongSchool = "�ؽ�" EquipSearch.UpdateResult() end,},
			   {szOption = "�嶾", bMCheck = true, bChecked = (tFilter.szBelongSchool == "�嶾"), fnAction = function() tFilter.szBelongSchool = "�嶾" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szBelongSchool == "����"), fnAction = function() tFilter.szBelongSchool = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szBelongSchool == "����"), fnAction = function() tFilter.szBelongSchool = "����" EquipSearch.UpdateResult() end,},
			  }
			   )
			   table.insert(menu, {szOption = "��Դ����",
			   {szOption = "�κ���Դ", bMCheck = true, bChecked = (tFilter.szGetType == ""), fnAction = function() tFilter.szGetType = "" EquipSearch.UpdateResult() end,},
			   {szOption = "�̵�", bMCheck = true, bChecked = (tFilter.szGetType == "�̵�"), fnAction = function() tFilter.szGetType = "�̵�" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szGetType == "����"), fnAction = function() tFilter.szGetType = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szGetType == "����"), fnAction = function() tFilter.szGetType = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szGetType == "����"), fnAction = function() tFilter.szGetType = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "����", bMCheck = true, bChecked = (tFilter.szGetType == "����"), fnAction = function() tFilter.szGetType = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "���߻�ȡ", bMCheck = true, bChecked = (tFilter.szGetType == "���߻�ȡ"), fnAction = function() tFilter.szGetType = "���߻�ȡ" EquipSearch.UpdateResult() end,},
			   {szOption = "�����", bMCheck = true, bChecked = (tFilter.szGetType == "�����"), fnAction = function() tFilter.szGetType = "�����" EquipSearch.UpdateResult() end,},
			   {szOption = "�ﹱ", bMCheck = true, bChecked = (tFilter.szGetType == "���׶�"), fnAction = function() tFilter.szGetType = "���׶�" EquipSearch.UpdateResult() end,},
			   {szOption = "����ֵ", bMCheck = true, bChecked = (tFilter.szGetType == "����ֵ"), fnAction = function() tFilter.szGetType = "����ֵ" EquipSearch.UpdateResult() end,},
			   {szOption = "Danh Vong", bMCheck = true, bChecked = (tFilter.szGetType == "����"), fnAction = function() tFilter.szGetType = "����" EquipSearch.UpdateResult() end,},
			   {szOption = "BOSS", bMCheck = true, bChecked = (tFilter.szGetType == "Ұ��BOSS"), fnAction = function() tFilter.szGetType = "Ұ��BOSS" EquipSearch.UpdateResult() end,},
			   {szOption = "Hoat Dong", bMCheck = true, bChecked = (tFilter.szGetType == "�"), fnAction = function() tFilter.szGetType = "�" EquipSearch.UpdateResult() end,},
			   {szOption = "Dau Truong", bMCheck = true, bChecked = (tFilter.szGetType == "������"), fnAction = function() tFilter.szGetType = "������" EquipSearch.UpdateResult() end,},
			   {szOption = "Pet", bMCheck = true, bChecked = (tFilter.szGetType == "����ϵͳ"), fnAction = function() tFilter.szGetType = "����ϵͳ" EquipSearch.UpdateResult() end,},
			  }
			   )
				PopupMenu(menu)

				
    elseif szName == "Btn_Close" then
        EquipSearch.Close()
    end
end

function EquipSearch.IsOpened()
	local frame = Station.Lookup("Normal/EquipSearch")
	if frame and frame:IsVisible() then
		return true
	end
end

function EquipSearch.Open()

	EquipSearch.LoadData()
	
	local frame = Station.Lookup("Normal/EquipSearch")
	if not frame then
		frame = Wnd.OpenWindow("Interface/EquipSearch/EquipSearch.ini", "EquipSearch")
	else 
		frame:Show()
	end
end

function EquipSearch.Close()
	RESULT_PAGE_START = 1
	EXPAND_ITEM_TYPE = {}
	tResult = {}
	tDataBase = {}
	if EquipSearch.IsOpened() then
		Wnd.CloseWindow("EquipSearch")
	end
	
end

local menu = {szOption = "EquipSearch", fnAction = function() if EquipSearch.IsOpened() then EquipSearch.Close() else EquipSearch.Open() end end}
RegisterEvent("LOGIN_GAME", function()
	TraceButton_AppendAddonMenu({menu})
end)