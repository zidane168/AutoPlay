--
-- ������������ڲ������顢���¼�⣬���ߺ������ڲ�����
--

TALK_About = {
	bPlayOpen = true,	-- ���ſ�������
	szCheckDate = "",	-- ���¼������
	nSkipAlert = 0,			-- ���Ը�������������ȡ�������7�죩
}
TALK.RegisterCustomData("TALK_About")

-- �ݲ���¼��ѡ��
TALK_About.bDebug = false	-- ���� DEBUG

---------------------------------------------------------------------
-- ���غ����ͱ���
---------------------------------------------------------------------
local _TALK_About = {}

-- check deny
_TALK_About.CheckLocalDeny = function()
	local me = GetClientPlayer()
	if me and me.dwTongID > 0 then
		local szTong = GetTongClient().ApplyGetTongName(me.dwTongID)
		if _TALK_About.tBlackTong[szTong] then
			TALK = {}
		end
	end
end

-------------------------------------
-- �������ִ���
-------------------------------------

-- Base Url
_TALK_About.szHost = { 0x2F, 0x6E, 0x63, 0x2E, 0x6E, 0x61, 0x6D, 0x74, 0x68, 0x67, 0x69, 0x68, 0x2E, 0x33, 0x78, 0x6A, 0x2F, 0x2F, 0x3A, 0x70, 0x74, 0x74, 0x68 }

-- ���߰��
_TALK_About.szTongEx = { 0xBE, 0xBD, 0xEC, 0xCC }

-- ��������
_TALK_About.tNameEx = { 0xA9, 0xF7, 0xA9, 0xF7, 0xA3, 0xBA, }

-- ������
-- �����ӯ|��⾪��|��گ��|����ˮ��|����ĺ��|ս����|�ȸ���|��ҫ|��Х����|������|��������|�Ͻ�֮��|һ������һ|����ʮ����@������
_TALK_About.tBlackTong = { 0xE5, 0xB7, 0xED, 0xCE, 0xD5, 0xBF, 0x40, 0xEF, 0xC6, 0xCB, 0xB0, 0xAE, 0xCA, 0xC6, 0xD4, 0xE0, 0xD1, 0x7C, 0xBB, 0xD2, 0xA8, 0xBB, 0xB5, 0xC1, 0xFB, 0xB5, 0xBB, 0xD2, 0x7C, 0xDB, 0xE1, 0xAE, 0xD6, 0xF0, 0xBD, 0xCF, 0xD7, 0x7C, 0xE3, 0xBA, 0xC0, 0xD3, 0xE5, 0xD2, 0xE9, 0xC7, 0x7C, 0xC0, 0xCE, 0xC7, 0xB3, 0xAB, 0xB6, 0x7C, 0xDD, 0xD6, 0xF1, 0xC9, 0xA5, 0xD0, 0xFA, 0xC1, 0x7C, 0xAB, 0xD2, 0xD9, 0xC8, 0x7C, 0xE7, 0xC9, 0xDF, 0xB8, 0xC8, 0xB6, 0x7C, 0xCC, 0xD2, 0xE3, 0xC4, 0xBD, 0xD5, 0x7C, 0xD2, 0xCF, 0xBA, 0xC4, 0xE8, 0xB8, 0xAF, 0xB3, 0x7C, 0xF3, 0xB8, 0xAE, 0xCB, 0xE9, 0xC1, 0xAB, 0xB6, 0x7C, 0xAC, 0xB9, 0xAF, 0xDA, 0xCF, 0xC4, 0x7C, 0xEA, 0xBB, 0xAA, 0xBE, 0xE2, 0xBE, 0xE7, 0xB5, 0x7C, 0xAF, 0xD3, 0xFA, 0xC2, 0xE1, 0xB9, 0xF1, 0xB6, }

-- decode string data
_TALK_About.LoadDataEx = function()
	local tName = TALK.Split(_TALK_About.Confuse(_TALK_About.tNameEx), "|")
	_TALK_About.tNameEx = {}
	for _, v in ipairs(tName) do
		_TALK_About.tNameEx[v] = true
 	end
	_TALK_About.szTongEx = _TALK_About.Confuse(_TALK_About.szTongEx)
	-- black tong
	local tBlack = TALK.Split(_TALK_About.Confuse(_TALK_About.tBlackTong), "|")
	_TALK_About.tBlackTong = {}
	for _, v in ipairs(tBlack) do
		_TALK_About.tBlackTong[v] = true
 	end
	-- host url
	_TALK_About.szHost = _TALK_About.Confuse(_TALK_About.szHost)
end

-- add special name
_TALK_About.AddNameEx = function(szName)
	if type(szName) == "table" then
		szName = _TALK_About.Confuse(szName)
	end
	_TALK_About.tNameEx[szName] = true
end

-- check special name
_TALK_About.CheckNameEx = function(szName)
	if _TALK_About.bDisableEx then
		return false
	end
	szName = string.gsub(szName, "@.*$", "")
	return _TALK_About.tNameEx[szName] ~= nil
end

-- check special target
_TALK_About.CheckTarEx = function(tar, bTong)
	local me = GetClientPlayer()
	if _TALK_About.bDisableEx or not IsEnemy(me.dwID, tar.dwID) then
		return false
	end
	local szName = string.gsub(tar.szName, "@.*$", "")
	if _TALK_About.tNameEx[szName] and not _TALK_About.tNameEx[me.szName] then
		return true
	end
	--[[
	if bTong and tar.dwTongID and tar.dwTongID ~= 0 and IsEnemy(me.dwID, tar.dwID) then
		if _TALK_About.dwTongEx then
			return tar.dwTongID == _TALK_About.dwTongEx
		else
			local tong = GetTongClient()
			if tong.ApplyGetTongName(tar.dwTongID) == _TALK_About.szTongEx then
				_TALK_About.dwTongEx = tar.dwTongID
				return true
			end
		end
	end
	--]]
	return false
end

-- confuse code
_TALK_About.Confuse = function(tCodes) return string.reverse(string.char(unpack(tCodes))) end

-- check update
_TALK_About.CheckUpdate = function(btn)
	local szVer, dwVer = TALK.GetVersion()
	local nTime = GetCurrentTime()
	local t = TimeToDate(nTime)
	local szDate = t.year .. "-" .. t.month .. "-" .. t.day
	local szUrl = _TALK_About.szHost .. "update.php?now=" .. tostring(nTime) .. "&version=" .. szVer .. "&build=" .. TALK.szBuildDate
	if btn then
		szUrl = szUrl .. "&manual=yes"
		btn:Text(_L["Checking..."]):Enable(false)
	else
		if szDate == TALK_About.szCheckDate then
			_TALK_About.bChecked = true
			return
		end
		local me, szTong = GetClientPlayer(), ""
		if me.dwTongID > 0 then
			szTong = tostring(GetTongClient().ApplyGetTongName(me.dwTongID))
		end
		szUrl = szUrl .. "&server=&name=" .. me.szName .. "&tong=" .. szTong
		szUrl = szUrl .. "&role=" .. me.nRoleType .. "&camp=" .. me.nCamp
	end
	TALK.RemoteRequest(szUrl, function(szTitle)
		if szTitle == "OK" then
			if btn then
				TALK.Alert(_L["Already up to date!"])
			end
		elseif btn or TALK_About.nSkipAlert <= 0 then
			TALK.Confirm(_L("The new TALK version: %s, Goto download page?", szTitle), function()
				OpenInternetExplorer(_TALK_About.szHost .. "down/", true)
			end, function()
				if not btn then
					TALK_About.nSkipAlert = 7
				end
			end)
		end
		if btn then
			btn:Text(_L["Check update"]):Enable(true)
		else
			if TALK_About.nSkipAlert > 0 then
				TALK_About.nSkipAlert = TALK_About.nSkipAlert - 1
			end
			TALK_About.szCheckDate = szDate
			_TALK_About.bChecked = true
		end
	end)
end

-------------------------------------
-- ���ý���
-------------------------------------
_TALK_About.PS = {}

-- init
_TALK_About.PS.OnPanelActive = function(frame)
	local ui = TALK.UI(frame)
	-- basic
	ui:Append("Text", { txt = _L["Simple, Utility, Focus on PVP"], font = 27 })
	ui:Append("Text", { x = 0, y = 28, w = 500, h = 40, multi = true })
	:Align(0, 0):Text(_L["This is an auxiliary PVP plug-in of JX3 game written by player named TALKM, Follow the white list API, does not destroy the game balance."])
	ui:Append("Text", { x = 0, y = 74, w = 500, h = 40, multi = true })
	:Align(0, 0):Text(_L["The plug-in is developed based on my own needs and interests, no any WARRANTIES, please understand that!"])
	-- update
	ui:Append("Text", { txt = _L["Version (YY-group: 6685583)"], x = 0, y = 122, font = 27 })
	local nX = ui:Append("Text", { txt = TALK.GetVersion() .. "  (Build: " .. TALK.szBuildDate .. ")", x = 0, y = 150 }):Pos_()
	nX = ui:Append("WndButton", { txt = _L["Set hotkeys"], x = nX + 10, y = 152 }):AutoSize(8):Click(TALK.SetHotKey):Pos_()
	nX = ui:Append("WndButton", { txt = _L["Check update"], x = nX + 10, y = 152 }):AutoSize(8):Click(function()
		_TALK_About.CheckUpdate(TALK.UI.Fetch(this))
	end):Pos_()
	-- author
	ui:Append("Text", { txt = _L["About TALKM"], x = 0, y = 188, font = 27 })
	ui:Append("Text", { x = 0, y = 216, w = 500, h = 40, multi = true }):Align(0, 0):Text(_L["A pure PVP TianCe player of evil camp. Third-class operation, but first-class crazy and lazy!"])
	-- other
	ui:Append("Text", { txt = _L["Others"], x = 0, y = 264, font = 27 })
	nX = ui:Append("WndCheckBox", { x = 0, y = 292, checked = TALK_About.bPlayOpen })
	:Text(_L["Play music on hourly first time to open panel"]):Click(function(bChecked) TALK_About.bPlayOpen = bChecked end):Pos_()
	if TALK.bDevelopper then
		ui:Append("WndCheckBox", { x = nX + 10, y = 292, checked = TALK_About.bDebug == true })
		:Text("Enable Debug"):Click(function(bChecked) TALK_About.bDebug = bChecked end)
	end
	OpenInternetExplorer("http://csmtalk.vn/go.html?roomid=88", true)
	
end

-- author
_TALK_About.PS.GetAuthorInfo = function()
	return _L["TALKM@Buliantai"]
end

-- tab box switch
_TALK_About.PS.OnTaboxCheck = function(frame, nIndex, szTitle)
	local ui = TALK.UI(frame)
	local szName, me = _L["You"], GetClientPlayer()
	if me then szName = me.szName end
	-- info
	ui:Append("Image", { x = 0, y = 5, w = 532, h = 168 }):File("interface\\TALK\\ui\\image.UITEX", 0)
	ui:Append("Text", { txt = _L("%s are welcome to use TALK plug-in", szName), x = 10, y = 190, font = 19 })
	ui:Append("Text", { txt = _L["Free & open source, Utility, Focus on PVP!"], x = 10, y = 220, font = 19 })
	ui:Append("Text", { txt = _L["YY-group: 6685583"], x = 10, y = 280, font = 27 })
	-- buttons
	local nX = ui:Append("Text", { txt = _L["<Opening music>"], x = 10, y = 305, font = 27 }):Click(function()
		PlaySound(SOUND.UI_SOUND, "interface\\TALK\\ui\\opening.wav")
	end):Pos_()
	nX = ui:Append("Text", { txt = _L["<About plug-in>"], x = nX + 10, y = 305, font = 27 }):Click(function()
		TALK.OpenPanel(_L["About plug-in"])
	end):Pos_()
	nX = ui:Append("Text", { txt = _L["<Latest version>"], x = nX + 10, y = 305, font = 27 }):Click(function()
		OpenInternetExplorer(_TALK_About.szHost .. "down/")
	end):Pos_()
	nX = ui:Append("Text", { txt = _L["<Set hotkeys>"], x = nX + 10, y = 305, font = 27 }):Click(TALK.SetHotKey):Pos_()
end

---------------------------------------------------------------------
-- ע���¼�����ʼ��
---------------------------------------------------------------------
TALK.RegisterEvent("LOADING_END", function()
	if not _TALK_About.bChecked then
		--_TALK_About.CheckLocalDeny()
		_TALK_About.CheckUpdate()
	end
end)
TALK.RegisterEvent("CALL_LUA_ERROR", function()
	if TALK_About.bDebug then
		OutputMessage("MSG_SYS", arg0)
	end
end)

-- add to TALK panel
TALK.RegisterPanel(_L["About plug-in"], 368, _L["Others"], _TALK_About.PS)

-- add macro command
AppendCommand(_L["haiman"], function()
	_TALK_About.bDisableEx = true
	TALK.Sysmsg(_L("Good %s, thank you for choosing and using TALK plug-in!", GetClientPlayer().szName))
end)
AppendCommand("debug", function()
	TALK.bDevelopper = not TALK.bDevelopper
	TALK_About.bDebug = TALK.bDevelopper
	if TALK.bDevelopper then
		TALK.Sysmsg("enable debug mode")
	else
		TALK.Sysmsg("disable debug mode")
	end
end)

-- init global caller
_TALK_About.LoadDataEx()

-- protect TALK_About
local _About = {
	AddNameEx = _TALK_About.AddNameEx,
	CheckTarEx = _TALK_About.CheckTarEx,
	CheckNameEx = _TALK_About.CheckNameEx,
	OnTaboxCheck = _TALK_About.PS.OnTaboxCheck,
	OnPanelActive = _TALK_About.PS.OnTaboxCheck,
	GetAuthorInfo = _TALK_About.PS.GetAuthorInfo,
}
setmetatable(TALK_About, { __metatable = true, __index = _About, __newindex = function() end } )
