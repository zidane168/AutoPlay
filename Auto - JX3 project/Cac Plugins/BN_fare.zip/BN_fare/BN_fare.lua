BN_fare = {}
BN_fare.menu_funcs= {}
BNBasePanel = class()
BN_fare.BR = 0
BN_fare.up = {}

function BN_fare.Menu()
				local menu = {szOption = "�����]����"}		
					for i=1, #BN_fare.menu_funcs, 1 do
						table.insert(menu, BN_fare.menu_funcs[i]())
					end	
					table.insert(menu, {bDevide = true})
						local menu_b = {
								szOption = "�d�ݳ̷s��s",
								fnAction = function()
								local szName = "BN.txt"
								Interaction_Request(szName, "http://jx3.hehagame.com/index.php", "", "", 80)
								end }
					table.insert(menu, menu_b)
         return menu
end

function BN_fare.RegMenu(func)
	table.insert(BN_fare.menu_funcs, func)
end

BN_fare._InsertPlayerMenu = InsertPlayerMenu;
function BN_fare.InsertPlayerMenu(_menu)
        BN_fare._InsertPlayerMenu(_menu)
        local _MyMenu = BN_fare.Menu()
        table.insert(_menu, {bDevide = true})
        table.insert(_menu,_MyMenu)
end
InsertPlayerMenu = BN_fare.InsertPlayerMenu

OutputMessage("MSG_SYS","�����]����..����U��[�����\..\n")

local BASE_PANEL_INDEX = 0
local BASE_PANEL_DEFAULT_OFFSET_X = 200
local BASE_PANEL_DEFAULT_OFFSET_Y = 10
local BASE_PANEL_HOLD_TIME = 1000 * 20

function BN_fare.Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
		local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
		if not nFindLastIndex then
			nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
			break
		end
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
		nFindStartIndex = nFindLastIndex + string.len(szSeparator)
		nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end

RegisterEvent("INTERACTION_REQUEST_RESULT", function()
  if arg0 == "BN.txt" and arg1 then
    local szText = BN_fare.Split(arg2, ",")
    for i = 1, #szText do
      if szText[i] ~= "" then
        local szValue, szVersion = szText[i]:match("(.+)|(.+)")
        BN_fare.GetVersion(szValue, szVersion)
      end
    end
  end
end)
function BN_fare.GetVersion(szValue, szVersion)
	local nCount = GetAddOnCount() - 1
	for i = 0, nCount do
		local aInfo = GetAddOnInfo(i)
		if aInfo.szName == szValue then
		  local Value, Version = aInfo.szDesc:match("(.+)v(.+)")
		  if Version ~= szVersion then
		    BN_fare.OpenBasePanel(Value.." �̷s����"..szVersion)
        return
		  end
		  if Version == szVersion then
		  	BN_fare.BR = BN_fare.BR + 1
		  end
		end
	end
		  if BN_fare.BR == #BN_fare.up then
		  BN_fare.OpenBasePanel("�����]���´��󶰤w���O�̷s����")
		  end
end

function BN_fare.Update(hFrame, szText)
  local hText = hFrame:Lookup("", "BN_ActiveMes")
	hText:SetText(szText)
end

function BN_fare.UpdateAnchor(hFrame)
	local nWidth, nHeight = hFrame:GetSize()
	local nOffsetY = BASE_PANEL_DEFAULT_OFFSET_Y  + hFrame.nIndex * nHeight
	hFrame:SetPoint("TOPLEFT", 0, 0, "TOPLEFT", BASE_PANEL_DEFAULT_OFFSET_X , nOffsetY)
	hFrame:CorrectPos()
end

function BN_fare.OpenBasePanel(szText)
  BASE_PANEL_INDEX = BASE_PANEL_INDEX + 1
  local hFrame = Wnd.OpenWindow("\\Interface\\BN_fare\\BN_fare.ini", "BN_fare"..BASE_PANEL_INDEX)
	hFrame.nIndex = BASE_PANEL_INDEX
	hFrame.dwStartTime = GetTickCount()
	BN_fare.Update(hFrame, szText)
	BN_fare.UpdateAnchor(hFrame)
end

function BNBasePanel.OnLButtonClick()
  local szName = this:GetName()
	if szName == "BN_Link" then
	  OpenInternetExplorer("http://bbs.duowan.com/thread-23067212-1-1.html", true)
	  BN_fare.CloseBasePanel(this:GetRoot())
	elseif szName == "BN_Close" then
	  BN_fare.CloseBasePanel(this:GetRoot())
	end
end

function BN_fare.CloseBasePanel(hFrame)
	BN_fare.BR = 0
	BASE_PANEL_INDEX = 0
	Wnd.CloseWindow(hFrame)
end

function BNBasePanel.OnFrameBreathe()
  if this.dwStartTime and GetTickCount() - this.dwStartTime > BASE_PANEL_HOLD_TIME then
		BN_fare.CloseBasePanel(this)
    return
	end
end
function BN_fare.ceshi()
local BNnCount = GetAddOnCount() - 1
	for i = 0, BNnCount do
		local BNaInfo = GetAddOnInfo(i)
		local Value, Version = BNaInfo.szName:match("(.+)_(.+)")
		if Value == "BN" then
			table.insert(BN_fare.up, BNaInfo.szName)
		end
	end
end
BN_fare.ceshi()
