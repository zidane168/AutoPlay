heilong = {}
heilong.userdata = {}
heilong.userdata.btalkOn = false
heilong.userdata.HkOn = false
heilong.userdata.EkOn = false
heilong.userdata.ZkOn = false
heilong.userdata.WkOn = false
heilong.userdata.dir = ""
heilong.playerlist = {}

RegisterCustomData("heilong.userdata")
RegisterCustomData("heilong.playerlist")

local fnAddToList=function(szName)
if szName=="" or szName==nil then return end
table.insert(heilong.playerlist,szName)
end

function heilong.accept(szEvent)
		if not heilong.userdata.btalkOn then
					return
		end
		if szEvent=="PARTY_APPLY_REQUEST" and heilong.userdata.HkOn then
					if g_tStrings.STR_GUILD_CAMP_NAME[arg1] == "�E��" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
			elseif szEvent=="PARTY_APPLY_REQUEST" and heilong.userdata.EkOn then
					if g_tStrings.STR_GUILD_CAMP_NAME[arg1] == "�c�H" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
			elseif szEvent=="PARTY_APPLY_REQUEST" and heilong.userdata.ZkOn then
					if g_tStrings.STR_GUILD_CAMP_NAME[arg1] == "����" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
			elseif szEvent=="PARTY_APPLY_REQUEST" and heilong.userdata.WkOn then
    				for i,v in pairs(heilong.playerlist) do
    						if heilong.playerlist[i] == arg0 then
    							CloseMessageBox("ATMP_"..tostring(arg0))
    							break
    						end
						end
		end
end

function heilong.Menu()
        local menu = {szOption = "�}��ն��U��", fnAction =function() heilong.button() end,bCheck=true,bChecked = heilong.userdata.btalkOn == true,}
        local menu_a1 = {szOption = "�ڵ��E��J��", fnAction =function() heilong.Hbutton() end,bCheck=true,bChecked = heilong.userdata.HkOn == true,}
        local menu_a2 = {szOption = "�ڵ��c�H�J��", fnAction =function() heilong.Ebutton() end,bCheck=true,bChecked = heilong.userdata.EkOn == true,}
        local menu_a3 = {szOption = "�ڵ����ߤJ��", fnAction =function() heilong.Zbutton() end,bCheck=true,bChecked = heilong.userdata.ZkOn == true,}
        local menu_a4 = {szOption = "�ڵ����w���a", fnAction =function() heilong.Wbutton() end,bCheck=true,bChecked = heilong.userdata.WkOn == true,}
        local menu_a41 = {szOption = "�K�[���w���a", fnAction =function() heilong.enterdir() end,}
        local menu_a42 = {szOption = "�ڵ����a�C��"}
table.insert(menu,menu_a1)
table.insert(menu,menu_a2)
table.insert(menu,menu_a3)
table.insert(menu,menu_a4)
table.insert(menu_a4,menu_a41)
table.insert(menu_a4, {bDevide = true})
table.insert(menu_a4,menu_a42)
for i,v in pairs(heilong.playerlist) do
       local list=
{
                           szOption=v,	
                           {szOption="�R��",fnAction=function() table.remove(heilong.playerlist, i) end,fnAutoClose=function() return true end}
}
table.insert(menu_a42,list)
end
			return menu
end 

RegisterEvent("CUSTOM_DATA_LOADED", function() if arg0 == "Role" then BN_fare.RegMenu(heilong.Menu) end end)

function heilong.button()
	if heilong.userdata.btalkOn then
		heilong.userdata.btalkOn = false
		OutputMessage("MSG_SYS","�}��ն��U��w����\n")
	 else
		heilong.userdata.btalkOn = true
		OutputMessage("MSG_SYS","�}��ն��U��w�}��\n")
	end
end

function heilong.Wbutton()
	if heilong.userdata.WkOn then
		heilong.userdata.WkOn = false
	 else
		heilong.userdata.WkOn = true
	end
end

function heilong.Hbutton()
	if heilong.userdata.HkOn then
		heilong.userdata.HkOn = false
	 else
		heilong.userdata.HkOn = true
	end
end

function heilong.Ebutton()
	if heilong.userdata.EkOn then
		heilong.userdata.EkOn = false
	 else
		heilong.userdata.EkOn = true
	end
end

function heilong.Zbutton()
	if heilong.userdata.ZkOn then
		heilong.userdata.ZkOn = false
	 else
		heilong.userdata.ZkOn = true
	end
end

function heilong.enterdir()
	GetUserInput(
	"�п�J���a�m�W",
	fnAddToList,
	nil,
	nil,
	nil,
	"",
	nil,
	nil,
	nil
	)
end
RegisterEvent("PARTY_APPLY_REQUEST",heilong.accept)

specific = {}
specific.button = {}
specific.button.Switch = false
specific.button.sthTC = false
specific.button.sthWH = false
specific.button.sthCY = false
specific.button.sthXX = false
specific.button.sthHS = false
specific.button.sthCJ = false
specific.button.sthWD = false
specific.button.sthTM = false

RegisterCustomData("specific.button")

function specific.reject(szEvent)
		if not specific.button.Switch then
					return
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthTC then
					if g_tStrings.tForceTitle[arg2] == "�ѵ�" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthWH then
					if g_tStrings.tForceTitle[arg2] == "�U��" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthCY then
					if g_tStrings.tForceTitle[arg2] == "�¶�" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthXX then
					if g_tStrings.tForceTitle[arg2] == "�C�q" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthHS then
					if g_tStrings.tForceTitle[arg2] == "�֪L" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthCJ then
					if g_tStrings.tForceTitle[arg2] == "�üC" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthWD then
					if g_tStrings.tForceTitle[arg2] == "" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
		if szEvent=="PARTY_APPLY_REQUEST" and specific.button.sthTM then
					if g_tStrings.tForceTitle[arg2] == "" then
						CloseMessageBox("ATMP_"..tostring(arg0))
					end
		end
end

function specific.fnSwitch()
	if specific.button.Switch then
			specific.button.Switch = false
		else
			specific.button.Switch = true
	end
end

function specific.Menu()
        local menu = {szOption = "�ڵ��S�w¾�~", fnAction =function() specific.fnSwitch() end,bCheck=true,bChecked = specific.button.Switch}
        local menu_a1 = {szOption = "�ڵ��ѵ��J��", fnAction =function() specific.button.sthTC = not specific.button.sthTC end,bCheck=true,bChecked = specific.button.sthTC}
        local menu_a2 = {szOption = "�ڵ��U��J��", fnAction =function() specific.button.sthWH = not specific.button.sthWH end,bCheck=true,bChecked = specific.button.sthWH}
        local menu_a3 = {szOption = "�ڵ��¶��J��", fnAction =function() specific.button.sthCY = not specific.button.sthCY end,bCheck=true,bChecked = specific.button.sthCY}
        local menu_a4 = {szOption = "�ڵ��C�q�J��", fnAction =function() specific.button.sthXX = not specific.button.sthXX end,bCheck=true,bChecked = specific.button.sthXX}
        local menu_a5 = {szOption = "�ڵ��֪L�J��", fnAction =function() specific.button.sthHS = not specific.button.sthHS end,bCheck=true,bChecked = specific.button.sthHS}
        local menu_a6 = {szOption = "�ڵ��üC�J��", fnAction =function() specific.button.sthCJ = not specific.button.sthCJ end,bCheck=true,bChecked = specific.button.sthCJ}
	table.insert(menu,menu_a1)
	table.insert(menu,menu_a2)
	table.insert(menu,menu_a3)
	table.insert(menu,menu_a4)
	table.insert(menu,menu_a5)
	table.insert(menu,menu_a6)
	table.insert(menu,menu_a7)
	table.insert(menu,menu_a8)
	return menu
end
RegisterEvent("CUSTOM_DATA_LOADED", function() if arg0 == "Role" then BN_fare.RegMenu(specific.Menu) end end)
RegisterEvent("PARTY_APPLY_REQUEST",specific.reject)
