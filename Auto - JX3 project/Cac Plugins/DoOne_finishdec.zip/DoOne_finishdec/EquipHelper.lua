-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: EquipHelper.lua 

local l_0_0 = class()
l_0_0.ctor = function(l_1_0, l_1_1, l_1_2)
  local l_1_3 = "interface/Moon_EquipHelper/FrameBtn.ini"
  local l_1_4 = Wnd.OpenWindow(l_1_3)
  l_1_4:Show()
  l_1_4:SetName(l_1_2)
  handle = l_1_4:Lookup("Btn_Equip")
  handle:SetName(l_1_2)
  handle:RegisterRButtonDrag()
  handle:ChangeRelation(l_1_1, true, true)
  l_1_0.style = style
  l_1_0.handle = handle
  Wnd.CloseWindow(l_1_2)
end

l_0_0.pos = function(l_2_0, ...)
  l_2_0.handle:SetRelPos(...)
end

l_0_0.txt = function(l_3_0, l_3_1)
  l_3_0.handle:Lookup("", "Text_Btn_Equip"):SetText(tostring(l_3_1))
end

l_0_0.font = function(l_4_0, ...)
  l_4_0.handle:Lookup("", "Text_Btn_Equip"):SetFontScheme(...)
end

l_0_0.dragbegin = function(l_5_0, l_5_1)
  l_5_0.handle.OnDragButtonBegin = function()
    -- upvalues: l_5_1
    l_5_1()
  end
end

l_0_0.drag = function(l_6_0, l_6_1)
  l_6_0.handle.OnDragButton = function()
    -- upvalues: l_6_1
    l_6_1()
  end
end

l_0_0.dragend = function(l_7_0, l_7_1)
  l_7_0.handle.OnDragButtonEnd = function()
    -- upvalues: l_7_1
    l_7_1()
  end
end

l_0_0.mousein = function(l_8_0, l_8_1)
  l_8_0.handle.OnMouseEnter = function()
    -- upvalues: l_8_1
    l_8_1()
  end
end

l_0_0.mouseleave = function(l_9_0)
  l_9_0.handle.OnMouseLeave = function()
    HideTip()
  end
end

l_0_0.Click = function(l_10_0, l_10_1)
  l_10_0.handle.OnLButtonClick = function()
    -- upvalues: l_10_1
    l_10_1()
  end
end

local l_0_1 = function()
  local l_11_0 = this
  local l_11_1 = this
  local l_11_2 = Station.GetMessagePos()
  l_11_1.fDragY = R3_PC5
  l_11_0.fDragX = l_11_2
  l_11_0 = this
  l_11_0, l_11_1 = l_11_0:GetRoot, l_11_0
  l_11_0 = l_11_0(l_11_1)
  l_11_1 = this
  l_11_2 = this
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_11_3 = R3_PC5
  l_11_2.fDragFrameY = l_11_0
  l_11_1.fDragFrameX = l_11_3
end

local l_0_2 = function()
  local l_12_0, l_12_1 = Station.GetMessagePos()
  if l_12_0 < 0 or l_12_1 < 0 then
    return 
  end
  local l_12_2 = this.fDragX - l_12_0
  local l_12_3 = this.fDragY - l_12_1
  local l_12_4 = this:GetRoot()
  l_12_4:SetAbsPos(this.fDragFrameX - l_12_2, this.fDragFrameY - l_12_3)
end

local l_0_3 = {}
l_0_3.nEquipCount = 3
l_0_3.btnin = 1
l_0_3.tSaveEquipmentList = {}
l_0_3.tDurableEquipmentList = {}
l_0_3.tBtnTip = {}
l_0_3.nX = 0
l_0_3.nY = 0
l_0_3.szTip = "�����ռ䲻����ֻ�Ѳ���װ����\n"
do
  local l_0_4 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, function()
  if arg0 == "Role" then
    local l_33_0 = Station.Lookup("Normal/EquipHelper")
    if l_33_0 then
      Wnd.CloseWindow("EquipHelper")
    end
    l_33_0 = Wnd.OpenWindow("interface/Moon_EquipHelper/EquipHelper.ini", "EquipHelper")
    if EquipHelper.nX ~= 0 and EquipHelper.nY ~= 0 then
      l_33_0:SetRelPos(EquipHelper.nX, EquipHelper.nY)
      l_33_0:CorrectPos()
      EquipHelper.Anchor = GetFrameAnchor(l_33_0)
      EquipHelper.nX = 0
      EquipHelper.nY = 0
    end
    EquipHelper.UpdateAnchor()
    if EquipHelper.bshow then
      l_33_0:Show()
    else
      l_33_0:Hide()
    end
    EquipHelper.UpdateImage(tostring(EquipHelper.btnin))
    local l_33_1 = Station.Lookup("Normal/Player/", "")
    for l_33_5 = 1, 3 do
      l_33_1:AppendItemFromString("<handle>name=\"" .. "Handle_Suit" .. l_33_5 .. "\" eventid=272</handle>")
      local l_33_6 = l_33_1:Lookup("Handle_Suit" .. l_33_5)
      do
        l_33_6:SetRelPos((l_33_5 - 1) * 25 + 280, 15)
        l_33_6:AppendItemFromString(GetFormatImage("ui/Image/button/ShopButton.UITex", 47, 25, 25, 0, "Image"))
        l_33_6:AppendItemFromString("<text>text=" .. EncodeComponentsString(l_33_5) .. " name=\"Text_Suit\" x=8 y=3 font=18</text>")
        l_33_6.nIndex = l_33_5
        l_33_6.OnItemLButtonClick = function()
          PlayerChangeSuit(this.nIndex)
        end
        l_33_6.OnItemMouseEnter = function()
          -- upvalues: l_33_6
          local l_35_0, l_35_1 = this:GetAbsPos()
          local l_35_2, l_35_3 = this:GetSize()
          local l_35_4 = ""
          local l_35_5 = FormatString("��<D0>���¹�", NumberToChinese(l_33_6.nIndex))
          l_35_4 = "<text>text=" .. EncodeComponentsString(l_35_5) .. " font=60 r=255 g=255 b=255 </text>"
          if EquipHelper.nIndex == l_33_6.nIndex then
            l_35_4 = l_35_4 .. "<text>text=" .. EncodeComponentsString(g_tStrings.STR_SUIT_EQUIPED) .. " font=192 </text>"
          else
            l_35_4 = l_35_4 .. "<text>text=" .. EncodeComponentsString(g_tStrings.STR_SUIT_EQUIP) .. " font=60 r=0 g=200 b=70 </text>"
          end
          local l_35_6 = OutputTip
          local l_35_7 = l_35_4
          local l_35_8 = 400
          do
            local l_35_9 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_35_6(l_35_7, l_35_8, l_35_9)
          end
           -- WARNING: undefined locals caused missing assignments!
        end
        l_33_6.OnItemMouseLeave = function()
          HideTip()
        end
        l_33_6.OnItemRefreshTip = function()
          -- upvalues: l_33_6
          local l_37_1 = nil
          local l_37_0 = l_33_6.OnItemMouseEnter
          return l_37_0()
        end
        l_33_6:FormatAllItemPos()
        if EquipHelper.bshowsuit then
          l_33_6:Show()
        else
          l_33_6:Hide()
        end
      end
    end
    l_33_1:FormatAllItemPos()
    DelayCall(1.5, function()
      EquipHelper.updateSuit(true)
    end)
  end
end
)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, function()
  EquipHelper.updateSuit()
end
)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, function()
  EquipHelper.updateSuit()
end
)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, 2567, "��װ����", "General", EquipHelper.Create)
end
 -- WARNING: undefined locals caused missing assignments!

