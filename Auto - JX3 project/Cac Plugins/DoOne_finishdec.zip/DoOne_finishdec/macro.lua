-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: macro.lua 

local l_0_0 = {}
l_0_0.bShieldTip = false
l_0_0.Plus = {}
BoxMacro = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BoxMacro.bShieldTip")
MacroData, l_0_0 = l_0_0, {}
l_0_0 = RegisterCustomData
l_0_0("MacroData")
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_2 = "����ǧ�������"
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_4 = function(l_22_0)
  -- upvalues: l_0_0
  local l_22_1 = nil
  if l_0_0.tAuraTime[l_22_0] then
    local l_22_2 = nil
    for l_22_6,l_22_7 in ipairs(l_22_2) do
      local l_22_3 = GetClientPlayer()
       -- DECOMPILER ERROR: Confused about usage of registers!

      if GetNpc(R8_PC12.dwNpcID) and BoxMacro.GetDistanceByTarget(l_22_3, GetNpc(R8_PC12.dwNpcID)) <= l_22_8.nDis and (not l_22_1 or l_22_1.dwStartTime < l_22_8.dwStartTime) then
        l_22_1 = l_22_8
      end
    end
  end
  return l_22_1
end

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_5 = function()
  local l_36_0 = GetClientPlayer()
  local l_36_1 = 0
  local l_36_2 = GetAllNpc()
  for l_36_6,l_36_7 in pairs(l_36_2) do
    if l_36_7.dwTemplateID == 16000 and l_36_7.dwEmployer == l_36_0.dwID then
      l_36_1 = l_36_1 + 1
    end
  end
  return l_36_1
end

BoxMacro.ParamSegmentation = function(l_73_0, l_73_1)
  if not l_73_1 then
    l_73_1 = "|"
  end
  l_73_0 = l_73_0 .. l_73_1
  local l_73_2 = {}
  local l_73_3 = StringFindW(l_73_0, l_73_1)
  if l_73_3 then
    local l_73_4 = string.sub(l_73_0, 1, l_73_3 - 1)
    if l_73_4 ~= "" then
      l_73_4 = StringReplaceW(l_73_4, " ", "")
      local l_73_5, l_73_6, l_73_7 = l_73_4:match("(.-)([<>=]+)(.+)")
      if l_73_5 then
        local l_73_8 = {}
        l_73_8.bCompare = true
        l_73_8.szWord = l_73_6
        l_73_8.n = tonumber(l_73_7)
        l_73_2[l_73_5] = l_73_8
      end
    else
      local l_73_9 = {}
      l_73_9.bCompare = false
      l_73_2[l_73_4] = l_73_9
    end
    l_73_0 = string.sub(l_73_0, l_73_3 + 1, -1)
    l_73_3 = StringFindW(l_73_0, l_73_1)
  end
end
return l_73_2
end

BoxMacro.Compare = function(l_74_0, l_74_1, l_74_2)
  local l_74_3 = {}
  l_74_3["="] = l_74_1 == l_74_2
  l_74_3[">"] = l_74_2 < l_74_1
  l_74_3["<"] = l_74_1 < l_74_2
  l_74_3[">="] = l_74_2 <= l_74_1
  l_74_3["<="] = l_74_1 <= l_74_2
  if l_74_3[l_74_0] then
    return l_74_3[l_74_0]
  end
  return false
end

BoxMacro.GetTarget = function()
  local l_75_0 = GetClientPlayer()
  local l_75_1 = GetTargetHandle(l_75_0.GetTarget())
  return l_75_1, l_75_0
end

BoxMacro.GetTTarget = function()
  local l_76_0 = GetClientPlayer()
  local l_76_1 = (GetTargetHandle(l_76_0.GetTarget()))
  local l_76_2 = nil
  if l_76_1 then
    l_76_2 = GetTargetHandle(l_76_1.GetTarget())
  end
  return l_76_2, l_76_1, l_76_0
end

BoxMacro.CheckSkillCD = function(l_77_0, l_77_1)
  local l_77_2 = "|"
  local l_77_3 = false
  l_77_0 = StringReplaceW(l_77_0, "-", "&")
  if StringFindW(l_77_0, "&") then
    l_77_2 = "&"
  end
  local l_77_4 = GetClientPlayer()
  local l_77_5 = BoxMacro.ParamSegmentation(l_77_0, l_77_2)
  for l_77_9 in pairs(l_77_5) do
    local l_77_10 = BoxGetSkillID(l_77_9)
    local l_77_11 = l_77_4.GetSkillLevel(l_77_10)
    local l_77_12, l_77_13 = l_77_4.GetSkillCDProgress(l_77_10, l_77_11)
    if l_77_1 then
      if l_77_13 <= 0 and l_77_2 == "&" then
        return false
      elseif l_77_13 > 0 and l_77_2 == "|" then
        return true
      end
    elseif l_77_13 > 0 and l_77_2 == "&" then
      return false
    elseif l_77_13 <= 0 and l_77_2 == "|" then
      return true
    end
  end
  return l_77_3
end

BoxMacro.CheckForce = function(l_78_0, l_78_1)
  if not IsPlayer(l_78_0.dwID) then
    return false
  end
  local l_78_2 = false
  local l_78_3 = GetForceTitle(l_78_0.dwForceID)
  l_78_1 = StringReplaceW(l_78_1, "&", "|")
  l_78_1 = StringReplaceW(l_78_1, "-", "|")
  local l_78_4 = string.split(l_78_1, "|")
  for l_78_8,l_78_9 in ipairs(l_78_4) do
    if l_78_3 == l_78_9 then
      l_78_2 = true
      do break end
    end
  end
  return l_78_2
end

BoxMacro.CheckMount = function(l_79_0, l_79_1)
  local l_79_2 = l_79_0.GetKungfuMount()
  if not l_79_2 then
    return false
  end
  l_79_1 = StringReplaceW(l_79_1, "&", "|")
  l_79_1 = StringReplaceW(l_79_1, "-", "|")
  local l_79_3 = string.split(l_79_1, "|")
  for l_79_7,l_79_8 in ipairs(l_79_3) do
    if l_79_2.szSkillName == l_79_8 or l_79_8 == "����" and (l_79_2.szSkillName == "�����ľ�" or l_79_2.szSkillName == "�����" or l_79_2.szSkillName == "�뾭�׵�") then
      return true
    end
  end
  return false
end

BoxMacro.CheckNoBuff = function(l_80_0, l_80_1, l_80_2)
  if not l_80_0.GetBuffList() then
    local l_80_3 = {}
  end
  local l_80_4 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_80_5 = "-"
  local l_80_6 = GetClientPlayer()
  for l_80_10,l_80_11 in ipairs(l_80_4) do
    local l_80_7 = BoxMacro.ParamSegmentation(l_80_1, l_80_5)
     -- DECOMPILER ERROR: Confused about usage of registers!

    if (l_80_7[Table_GetBuffName(R11_PC30.dwID, R11_PC30.nLevel) or ""] or l_80_7[tostring(R11_PC30.dwID)]) and (not l_80_2 or not l_80_2 or R11_PC30.dwSkillSrcID == l_80_6.dwID) then
      return false
    end
  end
  return true
end

local l_0_6 = {stand = MOVE_STATE.ON_STAND, walk = MOVE_STATE.ON_WALK, run = MOVE_STATE.ON_RUN, jump = MOVE_STATE.ON_JUMP, swim = MOVE_STATE.ON_SWIM, swimjump = MOVE_STATE.ON_SWIM_JUMP, float = MOVE_STATE.ON_FLOAT, sit = MOVE_STATE.ON_SIT, down = MOVE_STATE.ON_KNOCKED_DOWN, back = MOVE_STATE.ON_KNOCKED_BACK, off = MOVE_STATE.ON_KNOCKED_OFF, halt = MOVE_STATE.ON_HALT, freeze = MOVE_STATE.ON_FREEZE, entrap = MOVE_STATE.ON_ENTRAP, autofly = MOVE_STATE.ON_AUTO_FLY, death = MOVE_STATE.ON_DEATH, dash = MOVE_STATE.ON_DASH, pull = MOVE_STATE.ON_PULL, repulsed = MOVE_STATE.ON_REPULSED, rise = MOVE_STATE.ON_RISE, skid = MOVE_STATE.ON_SKID}
local l_0_7 = function(l_81_0, l_81_1, l_81_2)
  if l_81_0.bCompare then
    local l_81_3 = nil
    if l_81_1 == "time" then
      l_81_3 = math.ceil((l_81_2.nEndFrame - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
    elseif l_81_1 == "normal" then
      l_81_3 = l_81_2.nStackNum
    end
    if BoxMacro.Compare(l_81_0.szWord, l_81_3, l_81_0.n) then
      return true
    end
  else
    return true
  end
end

RegisterEvent("DO_SKILL_CAST", function()
  -- upvalues: l_0_0 , l_0_4
  local l_94_0 = GetClientPlayer()
  if arg0 ~= l_94_0.dwID then
    return 
  end
  local l_94_1 = GetClientPlayer()
  local l_94_2 = arg1
  local l_94_3 = arg2
  local l_94_4 = table.hasVal
  local l_94_5 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_94_4 then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_94_2 == 3360 and l_94_4 then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_94_2 == 3111 then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_94_2 == 3357 and l_94_4 > 1000 and l_94_4 ~= 0 then
    do return end
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_94_4 then
    if l_94_5 == 3 then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    if l_94_4 then
      if l_94_5 == 3 then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

    end
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
local l_0_9 = function(l_86_0)
  local l_86_1 = Station.Lookup("Normal/PetActionBar")
  local l_86_2 = l_86_1:Lookup("", "")
  local l_86_3 = (l_86_2:Lookup("Handle_Box/Handle_SkillMod"))
  local l_86_4 = nil
  for l_86_8 = 1, 6 do
    do
      local l_86_9 = l_86_3:Lookup("Box_Skills" .. l_86_8)
      if l_86_9:GetObjectData() == l_86_0 then
        l_86_4 = l_86_9
      end
      do break end
    end
  end
  if not l_86_4 then
    for l_86_13 = 7, 8 do
      local l_86_14 = l_86_3:Lookup("Handle_OtherSkill/Handle_SkillBox" .. l_86_13)
      local l_86_15 = l_86_14:Lookup("Box_Skill")
      if l_86_15:GetObjectData() == l_86_0 then
        l_86_4 = l_86_15
      end
      do break end
    end
  end
  return l_86_4
end

local l_0_10 = function(l_87_0, l_87_1, l_87_2)
  -- upvalues: l_0_7
  if l_87_1.UITestCast then
    if IsSkillCastMyself then
      local l_87_3 = l_87_1.UITestCast
      local l_87_4 = l_87_0
      local l_87_5, l_87_6, l_87_9, l_87_10, l_87_14 = IsSkillCastMyself(l_87_1), .end
      return l_87_3(l_87_4, l_87_5, l_87_6, l_87_9, l_87_10, l_87_14)
    end
  else
    local l_87_7 = l_87_1.UITestCast
    local l_87_8 = l_87_0
    return l_87_7(l_87_8)
  end
  local l_87_11 = nil
  if l_87_2 then
    l_87_11 = l_0_7(l_87_1.dwSkillID)
  else
    l_87_11 = GetSkillActionBarBox(l_87_1.dwSkillID)
  end
  if l_87_11 then
    local l_87_12, l_87_13 = l_87_11:IsObjectEnable, l_87_11
    return l_87_12(l_87_13)
  else
    return true
  end
end

RegisterEvent("NPC_ENTER_SCENE", function()
  -- upvalues: l_0_1 , l_0_2 , l_0_9 , l_0_0 , l_0_10
  local l_96_0 = arg0
  local l_96_1 = GetNpc(l_96_0)
  local l_96_2 = GetClientPlayer()
  if l_96_1 and table.hasVal(l_0_1, l_96_1.szName) and l_96_1.dwEmployer == l_96_2.dwID then
    l_0_2 = l_96_0
  end
  local l_96_3 = l_0_9[l_96_1.dwTemplateID]
  if l_96_1 and l_96_3 and l_96_1.dwModelID == l_96_3.dwStartModelID and l_96_1.dwEmployer and l_96_1.dwEmployer ~= 0 and (l_96_1.dwEmployer == l_96_2.dwID or l_96_2.IsPlayerInMyParty(l_96_1.dwEmployer)) then
    if not l_0_0.tAuraTime[l_96_3.szName] then
      local l_96_4 = l_0_0.tAuraTime
      local l_96_5 = l_96_3.szName
      l_96_4[l_96_5] = {}
    end
    local l_96_6 = table.insert
    local l_96_7 = l_0_0.tAuraTime[l_96_3.szName]
    local l_96_8 = {}
    l_96_8.dwTime = l_96_3.dwTime
    l_96_8.dwCaster = l_96_1.dwEmployer
    l_96_8.dwStartTime = GetCurrentTime()
    l_96_8.nDis = l_0_10(l_96_1.dwTemplateID)
    l_96_8.dwNpcID = l_96_0
    l_96_6(l_96_7, l_96_8)
  end
end
)
RegisterEvent("NPC_LEAVE_SCENE", function()
  -- upvalues: l_0_2 , l_0_0
  if l_0_2 ~= 0 and arg0 == l_0_2 then
    l_0_2 = 0
    l_0_0.dwAttackID = 0
  end
end
)
RegisterEvent("SYS_MSG", function()
  -- upvalues: l_0_0
  if arg0 == "UI_OME_DEATH_NOTIFY" and arg1 == l_0_0.dwAttackID then
    l_0_0.dwAttackID = 0
  end
end
)
AppendCommand("config", function(l_100_0)
  -- upvalues: l_0_0
  l_100_0 = StringReplaceW(l_100_0, " ", "")
  if l_100_0 == "��������" then
    l_0_0.bProtectChannelSkill = true
  elseif l_100_0 == "����������" then
    l_0_0.bProtectChannelSkill = false
  end
  local l_100_1 = string.find(l_100_0, ":")
  if l_100_1 then
    local l_100_2 = string.sub(l_100_0, 1, l_100_1 - 1)
    local l_100_3 = string.sub(l_100_0, l_100_1 + 1, -1)
  end
  if l_100_2 == "before" then
    if l_100_3 == "null" then
      l_0_0.szBeforeCmd = ""
    end
  else
    l_0_0.szBeforeCmd = l_100_3:sub(2, -2)
  end
end
)
AppendCommand("if", function(l_101_0)
  -- upvalues: l_0_0
  l_101_0 = StringReplaceW(l_101_0, " ", "")
  if l_101_0 == "" then
    return 
  end
  l_0_0.szBeforeCmd = l_101_0:sub(2, -2)
end
)
 -- DECOMPILER ERROR: Confused about usage of registers!

AppendCommand("elseif", function(l_101_0)
  -- upvalues: l_0_0
  l_101_0 = StringReplaceW(l_101_0, " ", "")
  if l_101_0 == "" then
    return 
  end
  l_0_0.szBeforeCmd = l_101_0:sub(2, -2)
end
)
AppendCommand("else", function()
  -- upvalues: l_0_0
  l_0_0.szBeforeCmd = ""
end
)
AppendCommand("skill", function(l_104_0)
  -- upvalues: l_0_0 , l_0_11 , l_0_13
  local l_104_1 = GetClientPlayer()
  local l_104_2 = l_104_0:match("%s*[%[](.+)[%]]%s*(.+)")
  do
    local l_104_3 = l_104_0 or l_104_0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_104_4 = StringReplaceW(l_104_3, " ", "")
  local l_104_5 = string.split(l_104_4, ",")
  if (l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd)) and (not l_104_2 or l_0_11(l_104_2)) then
    for l_104_9 = 1, #l_104_5 do
      local l_104_10 = l_104_1.GetOTActionState()
      if (l_0_0.bProtectChannelSkill and l_104_10 ~= 2) or not l_0_0.bProtectChannelSkill then
        l_0_13(l_104_5[l_104_9])
      end
    end
  end
end
)
AppendCommand("cbuff", function(l_106_0)
  -- upvalues: l_0_0 , l_0_11
  local l_106_1 = l_106_0:match("%s*[%[](.+)[%]]%s*(.+)")
  do
    local l_106_2 = l_106_0 or l_106_0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_106_3 = StringReplaceW(l_106_2, " ", "")
  local l_106_4 = string.split(l_106_3, ",")
  if (l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd)) and (not l_106_1 or l_0_11(l_106_1)) then
    for l_106_8 = 1, #l_106_4 do
      BoxMacro.CancelBuff(l_106_4[l_106_8])
    end
  end
end
)
AppendCommand("s", function(l_107_0)
  -- upvalues: l_0_0 , l_0_11
  if l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd) then
    local l_107_1 = GetClientPlayer()
    local l_107_2 = PLAYER_TALK_CHANNEL.NEARBY
    local l_107_3 = l_107_0:match("%s*[%[](.+)[%]]%s*(.+)")
    do
      local l_107_4 = l_107_0 or l_107_0
  end
  if l_107_3 then
    end
  if l_107_3 then
    end
  end
  local l_107_5 = nil
  local l_107_6 = l_107_1.Talk
  local l_107_7 = l_107_2
  local l_107_8 = ""
  local l_107_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_107_6(l_107_7, l_107_8, l_107_9)
end
)
local l_0_17 = {
[4982] = {szName = "��ɽ��", dwSkillID = 371, dwStartModelID = 3574, dwEndModelID = 3852, dwTemplateID = 4982, dwTime = 8}, 
[4976] = {szName = "��̫��", dwSkillID = 358, dwStartModelID = 3574, dwEndModelID = 3846, dwTemplateID = 4976, dwTime = 24}, 
[4981] = {szName = "������", dwSkillID = 363, dwStartModelID = 3574, dwEndModelID = 3851, dwTemplateID = 4981, dwTime = 24}, 
[3080] = {szName = "������", dwSkillID = 357, dwStartModelID = 3574, dwEndModelID = 2122, dwTemplateID = 3080, dwTime = 24}, 
[4978] = {szName = "������", dwSkillID = 360, dwStartModelID = 3574, dwEndModelID = 3848, dwTemplateID = 4978, dwTime = 8}, 
[4977] = {szName = "�Ʋ��", dwSkillID = 359, dwStartModelID = 3574, dwEndModelID = 3847, dwTemplateID = 4977, dwTime = 24}, 
[4979] = {szName = "��̫��", dwSkillID = 361, dwStartModelID = 3574, dwEndModelID = 3849, dwTemplateID = 4979, dwTime = 24}, 
[4980] = {szName = "���ǳ�", dwSkillID = 362, dwStartModelID = 3574, dwEndModelID = 3850, dwTemplateID = 4980, dwTime = 24}}
AppendCommand("omwp", function(l_111_0)
  -- upvalues: l_0_0 , l_0_11
  if l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd) then
    local l_111_1 = l_111_0:match("[[](.+)[]]%s*(.+)")
    do
      local l_111_2, l_111_3 = l_111_0 or l_111_0
  end
  if l_111_1 then
    end
  if l_111_1 then
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  BoxMacro.OnMountWeapon(l_111_2)
end
)
AppendCommand("umwp", function(l_112_0)
  -- upvalues: l_0_0 , l_0_11
  if l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd) then
    local l_112_1 = l_112_0:match("[%[](.+)[%]]")
  if l_112_1 then
    end
  if l_112_1 then
    end
  end
  BoxMacro.UnMountWeapon()
end
)
AppendCommand("end", function(l_113_0)
  -- upvalues: l_0_0 , l_0_11
  local l_113_1 = l_113_0:match("%s*[%[](.+)[%]]")
  if not l_113_1 then
    l_0_0.szBeforeCmd = ""
  else
    if (l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd)) and l_0_11(l_113_1) then
      return false
    end
  end
end
)
AppendCommand("return", function()
  -- upvalues: l_0_0 , l_0_11
  if l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd) then
    local l_114_0 = szCmd:match("%s*[%[](.+)[%]]")
  end
  if l_114_0 and l_0_11(l_114_0) then
    return false
  end
end
)
local l_0_22 = function(l_95_0)
  if l_95_0 == 4982 then
    return 4
  end
  return 10
end

AppendCommand("item", function(l_117_0)
  -- upvalues: l_0_0 , l_0_11
  if l_0_0.szBeforeCmd == "" or l_0_11(l_0_0.szBeforeCmd) then
    local l_117_1 = l_117_0:match("[%[](.+)[%]]%s*(.+)")
    do
      local l_117_2, l_117_3 = l_117_0 or l_117_0
  end
  if l_117_1 then
    end
  if l_117_1 then
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  BoxMacro.UseItem(l_117_2)
end
)
RegisterEvent("Breathe", function()
  -- upvalues: l_0_0
  local l_118_0 = GetLogicFrameCount()
  local l_118_1 = pairs
  local l_118_2 = {}
  local l_118_3 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_118_4 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  for l_118_4,i_2 in l_118_1 do
    do
       -- DECOMPILER ERROR: Overwrote pending register.

  end
  if "nNextSunLevel"[l_118_5[1]] > 0 and l_118_0 - l_0_0[l_118_5[1]] > 32 then
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_118_1 == 0 then
      local l_118_6 = nil
      do break end
      local l_118_7, l_118_8, l_118_9, l_118_10, l_118_11 = nil
      local l_118_12 = nil
      for l_118_12 = l_118_9, l_118_10, l_118_11 do
        do
          local l_118_13, l_118_14, l_118_15, l_118_16 = nil
          local l_118_17 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_118_15 < l_118_14 then
            l_118_14(l_118_15, l_118_16)
          end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_118_18, l_118_23, l_118_24 = l_118_11, l_118_13
  if not Station.Lookup(pairs(l_0_0.tAuraTime)) then
    return 
  end
  if not Station.Lookup(pairs(l_0_0.tAuraTime)):Lookup("Btn_Save") then
    local l_118_19, l_118_25 = l_118_14, l_118_15
    local l_118_20, l_118_26 = l_118_16
    local l_118_21, l_118_27 = nil
    local l_118_22 = nil
    BoxButton(Station.Lookup(pairs(l_0_0.tAuraTime)), "Btn_Save", l_118_6):OnClick(function()
      -- upvalues: l_118_1
      local l_119_0 = "Interface/Moon_macro/macro.jx3"
      local l_119_1 = l_118_1:Lookup("Edit_Name")
      local l_119_2 = l_118_1:Lookup("Edit_Content")
      local l_119_3 = {}
      if IsFileExist(l_119_0) and not LoadLUAData(l_119_0) then
        l_119_3 = {}
      end
      local l_119_4 = {}
      local l_119_5 = {}
      l_119_5.szOption = "˵��"
      l_119_5.fnAction = function()
        local l_120_0, l_120_1 = Cursor.GetPos()
        local l_120_2 = OutputTip
        local l_120_3 = GetFormatText("1�����棺����굽��������У�����ʹ�ú����ϴ�����������\n 2�����룺ͨ����������굽���Ŀ¼��macro.jx3�ļ���Ȼ��ͨ����������ڶ���˺ż������")
        local l_120_4 = 400
        do
          local l_120_5 = {}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_120_2(l_120_3, l_120_4, l_120_5, l_120_0, true, 0)
        end
         -- WARNING: undefined locals caused missing assignments!
      end
      local l_119_6 = {}
      l_119_6.szOption = "����"
      l_119_6.fnAction = function()
        -- upvalues: l_1_1 , l_1_2
        local l_121_0 = l_1_1:GetText()
        local l_121_1 = l_1_2:GetText()
        if l_121_1 == "" then
          return 
        end
        GetUserInput("ȷ�Ϻ�ı������ƣ�", function(l_122_0)
          -- upvalues: l_2_1
          if not l_122_0 or l_122_0 == "" then
            OutputMessage("MSG_ANNOUNCE_YELLOW", "�����Ӻ�ı�������")
            return 
          end
          if MacroData[l_122_0] then
            MsgBox("����ͬ���ĺ꣬�Ƿ񸲸ǣ�", function()
            -- upvalues: l_1_0 , l_2_1
            local l_123_0 = MacroData
            local l_123_1 = l_1_0
            l_123_0[l_123_1] = l_2_1
          end)
          else
            MacroData[l_122_0] = l_2_1
          end
        end, nil, nil, nil, l_121_0, 31)
      end
      local l_119_7 = {}
      l_119_7.szOption = "����"
      l_119_7.bDisable = IsEmpty(l_119_3)
      local l_119_8 = {}
      do
        l_119_8.bDevide = true
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_119_5 = IsEmpty
        l_119_6 = l_119_3
        l_119_5 = l_119_5(l_119_6)
        if not l_119_5 then
          l_119_5 = table
          l_119_5 = l_119_5.pairsByKeys
          l_119_6 = l_119_3
          l_119_5 = l_119_5(l_119_6)
          for l_119_8,i_2 in l_119_5 do
            local l_119_10 = table.insert
            local l_119_11 = l_119_4[3]
            local l_119_12 = {}
            l_119_12.szOption = l_119_8
            local l_119_13 = {}
            l_119_13.szOption = "����"
            l_119_13.fnAction = function()
              -- upvalues: l_1_1 , l_1_8 , l_1_2 , l_1_9
              l_1_1:SetText(l_1_8)
              l_1_2:SetText(l_1_9)
            end
            local l_119_14 = {}
            l_119_14.szOption = "ɾ��"
            l_119_14.fnAction = function()
              -- upvalues: l_1_3 , l_1_8 , l_1_0
              l_1_3[l_1_8] = nil
              SaveLUAData(l_1_0, l_1_3)
            end
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_119_10(l_119_11, l_119_12)
          end
        end
        for l_119_18,l_119_19 in table.pairsByKeys(MacroData) do
          local l_119_16, l_119_17, l_119_18, l_119_19 = nil
          l_119_16 = table
          l_119_16 = l_119_16.insert
          local l_119_20 = nil
          l_119_17 = l_119_4
          local l_119_21 = nil
          local l_119_22 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          local l_119_23 = nil
          l_119_20 = function()
            -- upvalues: l_1_1 , l_1_8 , l_1_2 , l_1_9
            l_1_1:SetText(l_1_8)
            l_1_2:SetText(l_1_9)
          end
          local l_119_24 = nil
          l_119_21 = function()
            -- upvalues: l_1_3 , l_1_9 , l_1_0 , l_1_8
            local l_125_0 = GetUserInput
            l_125_0("ȷ�Ϻ�ĵ������ƣ�", function(l_126_0)
              -- upvalues: l_1_3 , l_1_9 , l_1_0
              if not l_126_0 or l_126_0 == "" then
                OutputMessage("MSG_ANNOUNCE_YELLOW", "�����Ӻ�ĵ�������")
                return 
              end
              if l_1_3[l_126_0] then
                MsgBox("����ͬ���ĺ꣬�Ƿ񸲸ǣ�", function()
                -- upvalues: l_1_3 , l_1_0 , l_1_9 , l_1_0
                local l_127_0 = l_1_3
                local l_127_1 = l_1_0
                l_127_0[l_127_1] = l_1_9
                l_127_0 = SaveLUAData
                l_127_1 = l_1_0
                l_127_0(l_127_1, l_1_3)
                l_127_0 = Msg
                l_127_1 = "�굼���ɹ���"
                l_127_0(l_127_1)
              end)
              else
                l_1_3[l_126_0] = l_1_9
                SaveLUAData(l_1_0, l_1_3)
                Msg("�굼���ɹ���")
              end
            end, nil, nil, nil, l_1_8, 31)
          end
          local l_119_25 = nil
          l_119_22 = function()
            -- upvalues: l_1_8
            MacroData[l_1_8] = nil
          end
          l_119_21, l_119_20, l_119_19 = {szOption = "ɾ��", fnAction = l_119_22}, {szOption = "����", fnAction = l_119_21}, {szOption = "����", fnAction = l_119_20}
          l_119_16(l_119_17, l_119_18)
          l_119_18 = {l_119_19, l_119_20, l_119_21; szOption = l_119_8}
        end
        PopupMenu(l_119_4)
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
    end)
  end
   -- WARNING: undefined locals caused missing assignments!
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 33 
end
)
local l_0_24 = function(l_99_0)
  -- upvalues: l_0_11 , l_0_0
  if not l_99_0 or l_99_0 == "" then
    return true
  end
  local l_99_1 = {}
  local l_99_2, l_99_3 = string.find(l_99_0, "%b()")
  if l_99_2 then
    local l_99_4 = "brackets_" .. #l_99_1 + 1
    l_99_1[l_99_4] = string.sub(l_99_0, l_99_2 + 1, l_99_3 - 1)
    l_99_4 = string
    l_99_4 = l_99_4.find
    l_99_4 = l_99_4(l_99_0, "%b()", l_99_3)
    l_99_3 = 
    l_99_2 = l_99_4
  else
    local l_99_5 = 1
    l_99_2 = string.find(l_99_0, "%b()")
    if l_99_2 then
      l_99_0 = string.gsub(l_99_0, "%b()", "brackets_" .. l_99_5, 1)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_99_2 = string.find(l_99_0, "%b()")
      l_99_5 = l_99_5 + 1
    else
      local l_99_6 = false
      do
        local l_99_7 = string.split(l_99_0, ";")
        for l_99_11,l_99_12 in ipairs(l_99_7) do
          local l_99_13 = true
          local l_99_14 = 0
          l_99_12 = l_99_12 .. ","
          do
            local l_99_15 = string.find(l_99_12, ",")
            if l_99_15 then
              local l_99_16 = string.sub(l_99_12, 1, l_99_15 - 1)
              if l_99_16 ~= "" then
                l_99_16 = string.gsub(l_99_16, " ", "")
              end
              local l_99_17 = ""
              local l_99_18, l_99_19, l_99_20 = string.find(l_99_16, "([:<>=]+)")
              if l_99_18 then
                l_99_17 = string.sub(l_99_16, l_99_19 + 1, -1)
                l_99_16 = string.sub(l_99_16, 1, l_99_18 - 1)
              end
              if l_99_1[l_99_16] then
                l_99_14 = l_99_14 + 1
                if not l_0_11(l_99_1[l_99_16]) then
                  l_99_13 = false
                end
                do break end
              end
            else
              if l_0_0[l_99_16] or BoxMacro.Plus[l_99_16] then
                l_99_14 = l_99_14 + 1
              if not l_0_0[l_99_16] or l_0_0[l_99_16](l_99_17, l_99_20) then
                end
              end
            if l_0_0[l_99_16] and not BoxMacro.Plus[l_99_16](l_99_17, l_99_20) then
              end
            end
            l_99_13 = false
            do break end
            l_99_12 = string.sub(l_99_12, l_99_15 + 1, -1)
            l_99_15 = string.find(l_99_12, ",")
          end
          if l_99_14 == 0 then
            l_99_13 = false
          end
          if l_99_13 then
            l_99_6 = true
          end
          do break end
        end
      end
      return l_99_6
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 13 43 
end

RegisterMoonButton("Moon_macro", 582, "����չ", "General", function(l_119_0)
  local l_119_1 = l_119_0:Lookup("", "")
  BoxBoolCheckBox(l_119_0, "CheckBox_bShieldTip", "���κ�ʹ����ʾ", BoxMacro, "bShieldTip")
  local l_119_2 = BoxLabel
  local l_119_3 = l_119_1
  local l_119_4 = "label1"
  local l_119_5 = "�����˵����"
  do
    local l_119_6 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    l_119_2(l_119_3, l_119_4, l_119_5, l_119_6, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_119_2(l_119_3)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_119_2(l_119_3, l_119_4)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_119_2(l_119_3)
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
RegisterEvent("Breathe", function()
  local l_120_0 = Station.Lookup("Topmost/MacroSettingPanel")
  if not l_120_0 or l_120_0.bInit then
    return 
  end
  l_120_0:Lookup("", "Text_MaxByte"):SetText(FormatString(g_tStrings.MACRO_INPUT_LIMIT, 0, 9999))
  l_120_0:Lookup("Edit_Content"):SetLimit(2048)
  l_120_0.bInit = true
end
)
local l_0_25 = nil
local l_0_26 = function(l_103_0)
  -- upvalues: l_0_0
  l_103_0 = StringReplaceW(l_103_0, " ", "")
  local l_103_1 = GetClientPlayer()
  if l_103_0 == "��" then
    if l_103_1.nMoveState == MOVE_STATE.ON_SIT then
      if not l_103_1.GetBuffList() then
        local l_103_2, l_103_3 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      for l_103_7,l_103_8 in pairs(l_103_2) do
        local l_103_4 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        if R7_PC24.dwID == 103 then
          l_103_1.CancelBuff(R7_PC24.nIndex)
        end
      end
      return 
    end
    local l_103_9 = true
    local l_103_10 = table.hasVal
    do
      local l_103_11 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_103_10 then
        l_103_10(l_103_11, l_103_1.nFaceDirection)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: unhandled construct in 'if'

    elseif (l_103_0 == "�ж϶���" or l_103_0 == "���") and l_103_9() ~= 0 then
      l_103_1.StopCurrentAction()
    end
    do return end
     -- DECOMPILER ERROR: Overwrote pending register.

    if BoxMacro.GetPetSkillID(l_103_10) then
      local l_103_12, l_103_13, l_103_14 = BoxMacro.CanUsePetSkill(l_103_0), l_103_11
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_103_12 then
        OnAddOnUseSkill(MOVE_STATE.ON_SWIM, MOVE_STATE.ON_RUN)
      end
    else
      if BoxMacro.IsQianJiBianSkill(l_103_0) and BoxMacro.CanCastQianJiBianSkill(l_103_0) then
        BoxMacro.CastQianJiBianSkill(l_103_0)
      end
    end
    do return end
    if BoxMacro.CanUseSkill(l_103_0) then
      local l_103_15 = BoxGetSkillID(l_103_0)
      local l_103_16 = l_103_1.GetSkillLevel(l_103_15)
      if not l_103_16 or l_103_16 == 0 then
        l_103_16 = 1
      end
      local l_103_17 = GetSkill(l_103_15, l_103_16)
      if l_103_17 and l_103_17.bIsChannelSkill then
        l_0_0.nLastChannelSkillTime = GetCurrentTime()
      end
      OnAddOnUseSkill(l_103_15, l_103_16)
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 50 
end

do
  local l_0_27 = nil
  RegisterFrameHook("macro_content_limit", {"Topmost/MacroSettingPanel/Edit_Content"}, "OnEditChanged", function()
  local l_121_0 = this:GetTextLength()
  local l_121_1 = this:GetParent()
  if l_121_1.dwID then
    l_121_1:Lookup("Btn_Apply"):Enable(true)
  end
  l_121_1:Lookup("", "Text_MaxByte"):SetText(FormatString(g_tStrings.MACRO_INPUT_LIMIT, l_121_0, 2048))
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

