-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SkillRecipeTip.lua 

local l_0_0 = function()
  local l_1_0 = Station.Lookup("Normal/MystiquePanel")
  if not l_1_0 then
    return 
  end
  local l_1_1 = l_1_0:Lookup("", "Handle_List")
  local l_1_2 = l_1_1:GetItemCount() - 1
  for l_1_6 = 0, l_1_2 - 1 do
    local l_1_7 = l_1_1:Lookup(l_1_6)
    if l_1_7 then
      local l_1_8 = l_1_7:Lookup("Handle_Items")
    end
    if l_1_8 then
      for l_1_12 = 1, 4 do
        local l_1_13 = l_1_8:Lookup("Handle_Item" .. l_1_12)
        if l_1_13 then
          local l_1_14 = l_1_13:Lookup("Box_Mys")
        end
        if l_1_14:IsObjectMouseOver() then
          return l_1_14
        end
      end
    end
  end
end

RegisterTipFunc(function()
  local l_2_0 = Station.GetMouseOverWindow()
  if not l_2_0 or l_2_0:GetName() ~= "MystiquePanel" then
    return false
  end
  return true
end
, function(l_3_0)
  -- upvalues: l_0_0
  local l_3_1 = l_0_0()
  if not l_3_1 then
    return 
  end
  local l_3_2, l_3_3 = l_3_1:GetAbsPos()
  local l_3_4, l_3_5 = l_3_1:GetSize()
  local l_3_6, l_3_7 = l_3_1:GetObjectData()
  local l_3_8 = ""
  if SkillRecipeFrom.Book[l_3_6] then
    for l_3_12,l_3_13 in pairs(SkillRecipeFrom.Book[l_3_6]) do
      local l_3_14, l_3_15 = GlobelRecipeID2BookID(l_3_13)
      local l_3_16 = Table_GetBookItemIndex(l_3_14, l_3_15)
      l_3_8 = l_3_8 .. GetFormatText("�鼮��", 163) .. "<Text>text=" .. EncodeComponentsString("[" .. Table_GetSegmentName(l_3_14, l_3_15) .. "]\n") .. GetItemFontColorByQuality(GetItemInfo(5, l_3_16).nQuality, true) .. "</text>"
    end
    do break end
  end
  if SkillRecipeFrom.Quest[l_3_6] then
    for l_3_20,l_3_21 in pairs(SkillRecipeFrom.Quest[l_3_6]) do
      local l_3_22 = Table_GetQuestStringInfo(l_3_21)
      if l_3_22 then
        l_3_8 = l_3_8 .. GetFormatText("����", 163) .. "<Text>text=" .. EncodeComponentsString("[" .. l_3_22.szName .. "]\n") .. " font=162 </text>"
      end
      if IsCtrlKeyDown() then
        local l_3_23 = OutputQuestTip
        local l_3_24 = l_3_21
        local l_3_25 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_3_23(l_3_24, l_3_25, true)
      end
    end
  end
  if l_3_8 ~= "" and (StringFindW(l_3_0, "��װ��") or StringFindW(l_3_0, "δװ��")) then
    return l_3_8
  end
   -- WARNING: undefined locals caused missing assignments!
end
)

