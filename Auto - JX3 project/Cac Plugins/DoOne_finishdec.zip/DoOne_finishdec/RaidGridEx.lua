-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RaidGridEx.lua 

local l_0_0 = "interface\\RaidGridEx\\RaidGridEx.ini"
local l_0_1 = {}
l_0_1.bOn = false
local l_0_2 = {}
l_0_2.s = "LEFTCENTER"
l_0_2.r = "LEFTCENTER"
l_0_2.x = 418
l_0_2.y = -180
l_0_1.Anchor = l_0_2
l_0_1.bKeepFormation = true
l_0_1.bKeepAllyMark = true
l_0_1.bPlayerMenu = true
l_0_1.fScale = 1.2
l_0_1.bAutoScalePanel = true
l_0_1.bLockGroup = false
l_0_1.bAutoBUFFColor = true
l_0_1.nBuffFlashAlpha = 225
l_0_1.nBuffCoverAlpha = 96
l_0_1.nBuffFlashTime = 15
l_0_1.bAutoDistColor = true
l_0_1.szDistColor_0 = "White"
l_0_1.szDistColor_8 = "Green"
l_0_1.szDistColor_20 = "Green"
l_0_1.szDistColor_24 = "Orange"
l_0_1.szDistColor_999 = "Red"
l_0_1.nKungfuType = 1
l_0_1.nNameColor = 1
l_0_1.nFontScheme = 15
l_0_1.nLifeType = 1
l_0_1.bFullFile = false
l_0_1.nLifeFontScale = 1
l_0_1.bSystemRaidPanel = false
l_0_1.bSystemPartyPanel = true
l_0_1.bShowInRaid = false
l_0_1.bShowNumber = true
l_0_1.bQuickSelect = false
l_0_1.bDrag = false
l_0_1.tFormationLeader, l_0_2 = l_0_2, {}
l_0_1.handleLastSelect = nil
l_0_1.dwLastTargetID = nil
RaidGridEx = l_0_1
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.Anchor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bOn"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bKeepFormation"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bKeepAllyMark"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bPlayerMenu"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.fScale"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bAutoScalePanel"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bLockGroup"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bAutoBUFFColor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nBuffFlashAlpha"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nBuffCoverAlpha"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nBuffFlashTime"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bAutoDistColor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.szDistColor_0"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.szDistColor_8"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.szDistColor_20"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.szDistColor_24"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.szDistColor_999"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nKungfuType"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nNameColor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nFontScheme"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nLifeType"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bFullFile"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.nLifeFontScale"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bSystemRaidPanel"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bSystemPartyPanel"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bShowInRaid"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bShowNumber"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "RaidGridEx.bQuickSelect"
l_0_1(l_0_2)
l_0_1 = RaidGridEx
l_0_2 = function()
  RaidGridEx.frame = this
  local l_1_0 = this
  RaidGridEx.hMain = l_1_0:Lookup("", "")
  RaidGridEx.hRoles = l_1_0:Lookup("", "Handle_Roles")
  RaidGridEx.hBg = l_1_0:Lookup("", "Handle_BG")
  RaidGridEx.hRoles:Clear()
  local l_1_1 = RaidGridEx.hBg:Lookup("Handle_LootMode")
  RaidGridEx.tLootModeImage = {}
  local l_1_2 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_1_6,l_1_7 in "Image_LootMode_Free"("Image_LootMode_Looter") do
    table.insert(RaidGridEx.tLootModeImage, l_1_1:Lookup(l_1_7))
  end
  RaidGridEx.hLootMode = l_1_1
  RaidGridEx.tRollQualityImage = {}
  local l_1_8, l_1_15 = RaidGridEx.hBg:Lookup("Handle_LootColor")
  local l_1_9, l_1_16 = nil
  l_1_9 = ""
  l_1_16 = "Image_LootColor_Green"
  l_1_9 = ipairs
  l_1_16, l_1_15 = l_1_15, {l_1_9, l_1_16, "Image_LootColor_Blue", "Image_LootColor_Purple", "Image_LootColor_Orange"}
  l_1_9 = l_1_9(l_1_16)
  for l_1_13,l_1_14 in l_1_9 do
    local l_1_13, l_1_14 = nil
    if l_1_12 == "" then
      l_1_13 = table
      l_1_13 = l_1_13.insert
      l_1_14 = RaidGridEx
      l_1_14 = l_1_14.tRollQualityImage
      l_1_13(l_1_14, {})
    else
      l_1_13 = table
      l_1_13 = l_1_13.insert
      l_1_14 = RaidGridEx
      l_1_14 = l_1_14.tRollQualityImage
      l_1_13(l_1_14, l_1_8:Lookup(l_1_12))
    end
  end
  RaidGridEx.hLootColor = l_1_8
  l_1_0:RegisterEvent("UI_SCALED")
  l_1_0:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
  l_1_0:RegisterEvent("PARTY_ADD_MEMBER")
  l_1_0:RegisterEvent("PARTY_DELETE_MEMBER")
  l_1_0:RegisterEvent("PARTY_DISBAND")
  l_1_0:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
  l_1_0:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
  l_1_0:RegisterEvent("PARTY_UPDATE_MEMBER_LMR")
  l_1_0:RegisterEvent("PLAYER_STATE_UPDATE")
  l_1_0:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
  l_1_0:RegisterEvent("PARTY_SET_MARK")
  l_1_0:RegisterEvent("BUFF_UPDATE")
  l_1_0:RegisterEvent("TEAM_AUTHORITY_CHANGED")
  l_1_0:RegisterEvent("PARTY_SET_FORMATION_LEADER")
  l_1_0:RegisterEvent("PARTY_LOOT_MODE_CHANGED")
  l_1_0:RegisterEvent("PARTY_ROLL_QUALITY_CHANGED")
  l_1_0:RegisterEvent("TEAM_CHANGE_MEMBER_GROUP")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  l_1_0:RegisterEvent("RIAD_READY_CONFIRM_RECEIVE_ANSWER")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1.OnFrameCreate = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_2_0 = GetClientPlayer()
  if not l_2_0 then
    return 
  end
  if RaidGridEx.handleLastSelect then
    local l_2_1 = RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole")
  end
  if l_2_1 then
    l_2_1:Hide()
    RaidGridEx.handleLastSelect = nil
  end
  local l_2_2, l_2_3 = l_2_0.GetTarget()
  if l_2_3 and l_2_3 > 0 then
    local l_2_4 = nil
    if IsPlayer(l_2_3) and l_2_0.IsPlayerInMyParty(l_2_3) then
      l_2_4 = GetPlayer(l_2_3)
    else
      if IsPlayer(l_2_3) then
        l_2_4 = GetPlayer(l_2_3)
      else
        l_2_4 = GetNpc(l_2_3)
      end
    end
    if l_2_4 then
      local l_2_5, l_2_6 = l_2_4.GetTarget()
      if IsPlayer(l_2_6) and l_2_0.IsPlayerInMyParty(l_2_6) then
        l_2_4 = GetPlayer(l_2_6)
      end
    else
      l_2_4 = nil
    end
  end
  if l_2_4 then
    RaidGridEx.handleLastSelect = RaidGridEx.GetHandleByID(l_2_4.dwID)
  end
  if RaidGridEx.handleLastSelect then
    RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole"):Show()
  end
  if RaidGridEx.bDrag and not IsKeyDown("LButton") then
    RaidGridEx.bDrag = false
    RaidGridEx.AutoScalePanel()
    RaidGridEx.hBg:Lookup("Image_DragBox"):Hide()
    RaidGridEx.hBg:Lookup("Image_DragBox_Disable"):Hide()
    RaidGridEx.CloseRaidDragPanel()
  end
  local l_2_7 = GetLogicFrameCount()
  if l_2_7 % 12 == 0 then
    RaidGridEx.UpdateAllSpecialState()
  end
  if RaidGridEx.bAutoBUFFColor then
    local l_2_8 = RaidGridEx.hRoles:GetItemCount()
    for l_2_12 = 0, l_2_8 - 1 do
      local l_2_13 = RaidGridEx.hRoles:Lookup(l_2_12)
      if l_2_13 and l_2_13.dwMemberID then
        RaidGridEx.UpdateMemberBuff(l_2_13.dwMemberID)
      end
    end
  end
end

l_0_1.OnFrameBreathe = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  this:CorrectPos()
  RaidGridEx.Anchor = GetFrameAnchor(this)
end

l_0_1.OnFrameDrag = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function(l_4_0)
  local l_4_1 = RaidGridEx.Anchor
  l_4_0:SetPoint(l_4_1.s, 0, 0, l_4_1.r, l_4_1.x, l_4_1.y)
  l_4_0:CorrectPos()
end

l_0_1.UpdateAnchor = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function(l_5_0)
  local l_5_1 = GetClientPlayer()
  if l_5_0 == "UI_SCALED" then
    RaidGridEx.UpdateAnchor(Station.Lookup("Normal/RaidGridEx"))
    do break end
  end
  if l_5_0 == "PARTY_ADD_MEMBER" or l_5_0 == "PARTY_SYNC_MEMBER_DATA" then
    RaidGridEx.UpdateByGroup(arg2)
    RaidGridEx.AutoScalePanel()
    do break end
  end
  if l_5_0 == "PARTY_DELETE_MEMBER" then
    if l_5_1.dwID == arg1 then
      RaidGridEx.ClosePanel()
      do break end
    end
    RaidGridEx.UpdateByGroup(arg3)
    RaidGridEx.AutoScalePanel()
    do break end
  end
  if l_5_0 == "PARTY_DISBAND" then
    RaidGridEx.ClosePanel()
    do break end
  end
  if l_5_0 == "PARTY_UPDATE_MEMBER_INFO" or l_5_0 == "UPDATE_PLAYER_SCHOOL_ID" then
    local l_5_2 = RaidGridEx.GetHandleByID(arg1)
    if l_5_2 then
      RaidGridEx.UpdateMemberSpecialState(l_5_2)
      RaidGridEx.UpdateMemberLFData(l_5_2)
    end
    do break end
  end
  if l_5_0 == "PARTY_UPDATE_MEMBER_LMR" then
    local l_5_3 = RaidGridEx.GetHandleByID(arg1)
    if l_5_3 then
      RaidGridEx.UpdateMemberHFData(l_5_3)
    end
    do break end
  end
  if l_5_0 == "PLAYER_STATE_UPDATE" then
    local l_5_4 = RaidGridEx.GetHandleByID(arg0)
    if l_5_4 then
      RaidGridEx.UpdateMemberLFData(l_5_4)
      RaidGridEx.UpdateMemberHFData(l_5_4)
    end
    do break end
  end
  if l_5_0 == "PARTY_SET_MEMBER_ONLINE_FLAG" then
    local l_5_5 = RaidGridEx.GetHandleByID(arg1)
    if l_5_5 then
      RaidGridEx.UpdateMemberLFData(l_5_5)
      RaidGridEx.UpdateMemberHFData(l_5_5)
    end
    do break end
  end
  if l_5_0 == "PARTY_SET_MARK" then
    RaidGridEx.UpdateMemberMark()
    do break end
  end
  if l_5_0 == "BUFF_UPDATE" and l_5_1.IsPlayerInMyParty(arg0) then
    RaidGridEx.OnUpdateBuffData(arg0, arg1, arg2, arg4, arg5, arg6, arg8)
  end
  do break end
  if l_5_0 == "TEAM_AUTHORITY_CHANGED" then
    local l_5_6 = RaidGridEx.GetHandleByID(arg2)
    if l_5_6 then
      RaidGridEx.UpdateMemberLFData(l_5_6)
    end
    do
      local l_5_7 = RaidGridEx.GetHandleByID(arg3)
      if l_5_7 then
        RaidGridEx.UpdateMemberLFData(l_5_7)
      end
      if RaidGridEx.IsInRaid() then
        RaidGridEx.hLootMode:Show()
        RaidGridEx.hLootColor:Show()
        RaidGridEx.AutoScalePanel()
        do break end
      end
      RaidGridEx.hLootMode:Hide()
      RaidGridEx.hLootColor:Hide()
      RaidGridEx.AutoScalePanel()
    end
    do break end
  end
  if l_5_0 == "PARTY_SET_FORMATION_LEADER" then
    local l_5_8 = RaidGridEx.GetGroupIndex(arg0)
    local l_5_9 = RaidGridEx.GetHandleByID(arg0)
    if l_5_9 then
      RaidGridEx.UpdateMemberLFData(l_5_9)
      local l_5_10 = RaidGridEx.tFormationLeader[l_5_8]
    end
    if l_5_10 then
      local l_5_11 = RaidGridEx.GetHandleByID(l_5_10)
    end
    if l_5_11 then
      RaidGridEx.UpdateMemberLFData(l_5_11)
    end
    do break end
  end
  if l_5_0 == "PARTY_LOOT_MODE_CHANGED" then
    for l_5_15 = 1, 3 do
      if arg1 == l_5_15 then
        RaidGridEx.tLootModeImage[l_5_15]:SetAlpha(255)
      else
        RaidGridEx.tLootModeImage[l_5_15]:SetAlpha(64)
      end
    end
    do break end
  end
  if l_5_0 == "PARTY_ROLL_QUALITY_CHANGED" then
    for l_5_19 = 2, 5 do
      if arg1 == l_5_19 then
        RaidGridEx.tRollQualityImage[l_5_19]:SetAlpha(255)
      else
        RaidGridEx.tRollQualityImage[l_5_19]:SetAlpha(64)
      end
    end
  elseif l_5_0 == "TEAM_CHANGE_MEMBER_GROUP" then
    RaidGridEx.UpdateByGroup(arg1)
    RaidGridEx.UpdateByGroup(arg2)
    RaidGridEx.EnableRaidPanel(RaidGridEx.bSystemRaidPanel)
    RaidGridEx.AutoScalePanel()
  elseif l_5_0 == "RIAD_READY_CONFIRM_RECEIVE_ANSWER" then
    RaidGridEx.ChangeReadyConfirm(arg0, arg1)
  end
end

l_0_1.OnEvent = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_6_0 = this:GetName()
  if l_6_0 ~= "Image_Looter" and l_6_0:match("Image_Loot") and RaidGridEx.IsAuthority(GetClientPlayer().dwID, "distribute") then
    this:SetAlpha(210)
  end
  do return end
  if l_6_0:match("Handle_Role_") then
    RaidGridEx.EnterRoleHandle(nil, nil, this)
    RaidGridEx.SetTempTarget(this.dwMemberID, true)
  end
  if RaidGridEx.bDrag then
    local l_6_1 = l_6_0:match("Handle_Role_(%d)_%d")
    local l_6_2 = Station.Lookup("Normal/RaidExDragPanel")
  end
  if l_6_2 and l_6_2.dwID then
    local l_6_3 = (RaidGridEx.GetGroupIndex(l_6_2.dwID))
    local l_6_4 = nil
    if l_6_3 == l_6_1 then
      l_6_4 = RaidGridEx.hBg:Lookup("Image_DragBox_Disable")
      RaidGridEx.hBg:Lookup("Image_DragBox"):Hide()
    else
      l_6_4 = RaidGridEx.hBg:Lookup("Image_DragBox")
      RaidGridEx.hBg:Lookup("Image_DragBox_Disable"):Hide()
    end
  end
  if l_6_4 then
    l_6_4:Show()
    local l_6_5 = 64
    local l_6_6 = 28
    l_6_4:SetRelPos((l_6_1 * l_6_5 + 5) * RaidGridEx.fScale, l_6_6)
    RaidGridEx.hBg:FormatAllItemPos()
  end
end

l_0_1.OnItemMouseEnter = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_7_0 = this:GetName()
  local l_7_1, l_7_2 = RaidGridEx.GetLootModenQuality()
  if l_7_0:match("Image_LootColor") then
    if RaidGridEx.tRollQualityImage[l_7_2] and RaidGridEx.tRollQualityImage[l_7_2]:GetName() == l_7_0 then
      this:SetAlpha(255)
    else
      this:SetAlpha(64)
    end
  else
    if l_7_0:match("Image_LootMode") then
      if RaidGridEx.tLootModeImage[l_7_1] and RaidGridEx.tLootModeImage[l_7_1]:GetName() == l_7_0 then
        this:SetAlpha(255)
      end
    else
      this:SetAlpha(64)
    end
  else
    if l_7_0:match("Handle_Role_") then
      RaidGridEx.LeaveRoleHandle(nil, nil, this)
      RaidGridEx.SetTempTarget(this.dwMemberID, false)
    end
  end
end

l_0_1.OnItemMouseLeave = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_8_0 = this:GetName()
  if l_8_0:match("Handle_Role_") and this.dwMemberID then
    local l_8_1 = this.dwMemberID
  end
  if IsPlayer(l_8_1) then
    if IsCtrlKeyDown() then
      local l_8_2 = RaidGridEx.GetTeamMemberInfo(l_8_1)
    end
    if l_8_2 then
      EditBox_AppendLinkPlayer(l_8_2.szName)
    end
  else
    local l_8_3 = GetPlayer(l_8_1)
  end
  if l_8_3 then
    if RaidGridEx.handleLastSelect then
      RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole"):Hide()
      RaidGridEx.handleLastSelect = nil
    end
    RaidGridEx.dwLastTargetID = l_8_1
    local l_8_4 = RaidGridEx.GetTeamMemberInfo(l_8_1)
    RaidGridEx.SetTarget(l_8_1)
  end
end

l_0_1.OnItemLButtonClick = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function(l_9_0, l_9_1)
  if not RaidGridEx.bQuickSelect then
    return 
  end
  local l_9_2 = GetClientPlayer()
  if not l_9_0 or l_9_0 <= 0 or l_9_0 == l_9_2.dwID then
    return 
  end
  local l_9_3, l_9_4 = Target_GetTargetData()
  if l_9_1 then
    RaidGridEx.dwLastTargetID = l_9_3
    if l_9_0 ~= l_9_3 then
      RaidGridEx.SetTarget(l_9_0)
    end
  elseif ((l_9_3 and l_9_0 == l_9_3) or not l_9_3) and RaidGridEx.dwLastTargetID ~= l_9_3 then
    RaidGridEx.SetTarget(RaidGridEx.dwLastTargetID)
  end
end

l_0_1.SetTempTarget = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function(l_10_0, l_10_1)
  local l_10_2 = GetClientTeam()
  local l_10_3 = {}
  l_10_3.szOption = g_tStrings.STR_RAID_MENU_CHANG_GROUP
  local l_10_4 = l_10_2.GetMemberGroupIndex(l_10_1)
  for l_10_8 = 0, l_10_2.nGroupNum - 1 do
    do
      if l_10_8 ~= l_10_4 then
        local l_10_9 = l_10_2.GetGroupInfo(l_10_8)
      end
      if l_10_9 and l_10_9.MemberList then
        local l_10_10 = {}
        l_10_10.szOption = g_tStrings.STR_NUMBER[l_10_8 + 1]
        l_10_10.bDisable = #l_10_9.MemberList >= 5
        l_10_10.fnAction = function()
          -- upvalues: l_10_1 , l_10_8
          GetClientTeam().ChangeMemberGroup(l_10_1, l_10_8, 0)
        end
        l_10_10.fnAutoClose = function()
          return true
        end
        table.insert(l_10_3, l_10_10)
      end
    end
  end
  table.insert(l_10_0, l_10_3)
end

l_0_1.InsertChangeGroupMenu = l_0_2
RaidExDragPanel, l_0_1 = l_0_1, {}
l_0_1 = RaidGridEx
l_0_2 = function(l_11_0)
  local l_11_1 = GetClientTeam()
  local l_11_2 = l_11_1.GetMemberInfo(l_11_0)
  if not l_11_2 then
    return 
  end
  local l_11_3 = Wnd.OpenWindow("Interface\\RaidGridEx\\RaidExDragPanel.ini", "RaidExDragPanel")
  local l_11_4, l_11_5 = Cursor.GetPos()
  l_11_3:SetAbsPos(l_11_4, l_11_5)
  l_11_3:StartMoving()
  l_11_3.dwID = l_11_0
  local l_11_6 = l_11_3:Lookup("", "")
  local l_11_7, l_11_8 = GetForceImage(l_11_2.dwForceID)
  l_11_6:Lookup("Image_Force"):FromUITex(l_11_7, l_11_8)
  local l_11_9 = l_11_6:Lookup("Text_Name")
  l_11_9:SetText(l_11_2.szName)
  local l_11_10 = l_11_6:Lookup("Image_Health")
  local l_11_11 = l_11_6:Lookup("Image_Mana")
  if l_11_2.bIsOnLine then
    if l_11_2.nMaxLife > 0 then
      l_11_10:SetPercentage(l_11_2.nCurrentLife / l_11_2.nMaxLife)
    end
    if l_11_2.nMaxMana > 0 and l_11_2.nMaxMana ~= 1 then
      l_11_11:SetPercentage(l_11_2.nCurrentMana / l_11_2.nMaxMana)
    end
  else
    l_11_10:SetPercentage(0)
    l_11_11:SetPercentage(0)
  end
  l_11_6:Show()
end

l_0_1.OpenRaidDragPanel = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_12_0 = Station.Lookup("Normal/RaidExDragPanel")
  if l_12_0 then
    l_12_0:EndMoving()
    Wnd.CloseWindow(l_12_0)
  end
end

l_0_1.CloseRaidDragPanel = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_13_0 = this:GetName()
  local l_13_1 = GetClientPlayer()
  local l_13_2 = GetClientTeam()
  local l_13_3 = {}
  l_13_3.Image_LootMode_Free = PARTY_LOOT_MODE.FREE_FOR_ALL
  l_13_3.Image_LootMode_Looter = PARTY_LOOT_MODE.DISTRIBUTE
  l_13_3.Image_LootMode_Roll = PARTY_LOOT_MODE.GROUP_LOOT
  local l_13_4 = {}
  l_13_4.Image_LootColor_Green = 2
  l_13_4.Image_LootColor_Blue = 3
  l_13_4.Image_LootColor_Purple = 4
  l_13_4.Image_LootColor_Orange = 5
  if l_13_0:match("Handle_Role_") and this.dwMemberID then
    local l_13_5 = {}
    local l_13_6 = this.dwMemberID
     -- DECOMPILER ERROR: unhandled construct in 'if'

    if l_13_2.nGroupNum == 1 and l_13_1.dwID ~= l_13_6 then
      InsertTeammateMenu(l_13_5, l_13_6)
    end
    do return end
    if RaidGridEx.IsAuthority(l_13_1.dwID, "leader") then
      RaidGridEx.InsertChangeGroupMenu(l_13_5, l_13_6)
    end
    if l_13_6 == l_13_1.dwID then
      do return end
    end
    InsertTeammateMenu(l_13_5, l_13_6)
    if l_13_5 and #l_13_5 > 0 then
      PopupMenu(l_13_5)
    end
  else
    if l_13_0:match("Image_LootMode") and RaidGridEx.IsAuthority(l_13_1.dwID, "distribute") then
      l_13_2.SetTeamLootMode(l_13_3[l_13_0])
    end
  else
    if l_13_0:match("Image_LootColor") and RaidGridEx.IsAuthority(l_13_1.dwID, "distribute") then
      l_13_2.SetTeamRollQuality(l_13_4[l_13_0])
    end
  end
end

l_0_1.OnItemRButtonClick = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_14_0 = this:GetName()
  local l_14_1 = GetClientPlayer()
  if not RaidGridEx.IsInRaid() then
    return 
  end
  if not RaidGridEx.IsAuthority(l_14_1.dwID, "leader") or not l_14_0:match("Handle_Role_") then
    return 
  end
  local l_14_2 = this.dwMemberID
  if not l_14_2 then
    return 
  end
  if not RaidGridEx.bLockGroup or IsShiftKeyDown() then
    RaidGridEx.bDrag = true
    RaidGridEx.AutoScalePanel()
    RaidGridEx.OpenRaidDragPanel(l_14_2)
  else
    Msg("����С�ӷ���������������Ҫ ���� �� ��סShift ���ܽ��з��飡")
  end
end

l_0_1.OnItemLButtonDrag = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_15_0 = this:GetName()
  local l_15_1 = GetClientPlayer()
  local l_15_2 = GetClientTeam()
  if not RaidGridEx.IsAuthority(l_15_1.dwID, "leader") or not l_15_0:match("Handle_Role_") or not l_15_2 then
    return 
  end
  RaidGridEx.bDrag = false
  RaidGridEx.AutoScalePanel()
  do
    local l_15_3 = this.dwMemberID or 0
  end
  local l_15_4 = nil
  if l_15_0:match("Handle_Role_(%d)_%d") then
    local l_15_5 = nil
  end
  if Station.Lookup("Normal/RaidExDragPanel") and Station.Lookup("Normal/RaidExDragPanel").dwID then
    l_15_2.ChangeMemberGroup(Station.Lookup("Normal/RaidExDragPanel").dwID, l_15_5, l_15_4)
  end
  RaidGridEx.hBg:Lookup("Image_DragBox"):Hide()
  RaidGridEx.hBg:Lookup("Image_DragBox_Disable"):Hide()
  RaidGridEx.CloseRaidDragPanel()
end

l_0_1.OnItemLButtonDragEnd = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_16_0 = this:GetName()
  if l_16_0 == "Btn_Option" then
    RaidGridEx.PopOptions()
  end
end

l_0_1.OnLButtonClick = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  -- upvalues: l_0_0
  if not RaidGridEx.bOn then
    return 
  end
  local l_17_0 = GetClientPlayer()
  if not l_17_0 or not l_17_0.IsInParty() then
    return 
  end
  if RaidGridEx.bShowInRaid and not RaidGridEx.IsInRaid() then
    return 
  end
  if not Station.Lookup("Normal/RaidGridEx") then
    local l_17_1, l_17_2, l_17_3, l_17_4, l_17_5 = Wnd.OpenWindow(l_0_0, "RaidGridEx")
  end
  RaidGridEx.CreateAllRoleHandle()
  RaidGridEx.UpdateRaid()
  RaidGridEx.AutoScalePanel()
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_17_6 = nil
  l_17_1:Lookup("", "Handle_BG"):Lookup("Image_DragBox"):Scale(RaidGridEx.fScale, RaidGridEx.fScale)
  l_17_1:Lookup("", "Handle_BG"):Lookup("Image_DragBox_Disable"):Scale(RaidGridEx.fScale, RaidGridEx.fScale)
  l_17_6:Show()
  RaidGridEx.UpdateAnchor(l_17_6)
  RaidGridEx.EnableRaidPanel(RaidGridEx.bSystemRaidPanel)
  RaidGridEx.HidePartyPanel()
end

l_0_1.OpenPanel = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  local l_18_0 = Station.Lookup("Normal/RaidGridEx")
  if l_18_0 then
    Wnd.CloseWindow("RaidGridEx")
  end
  RaidGridEx.HidePartyPanel()
end

l_0_1.ClosePanel = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  if Station.Lookup("Normal/RaidGridEx") then
    return true
  end
  return false
end

l_0_1.IsOpened = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function(l_20_0)
  local l_20_1 = Station.Lookup("Normal/RaidPanel_Main")
  if l_20_1 then
    l_20_1:Show(l_20_0)
  end
end

l_0_1.EnableRaidPanel = l_0_2
l_0_1 = RaidGridEx
l_0_2 = function()
  if not RaidGridEx.IsInRaid() and not RaidGridEx.bShowInRaid and not RaidGridEx.bSystemPartyPanel then
    CloseTeammate()
  end
end

l_0_1.HidePartyPanel = l_0_2
l_0_1 = function()
  if RaidGridEx.IsOpened() then
    RaidGridEx.ClosePanel()
  end
end

l_0_2 = function()
  if RaidGridEx.IsOpened() then
    RaidGridEx.ClosePanel()
  end
  RaidGridEx.OpenPanel()
end

RegisterEvent("PARTY_LEVEL_UP_RAID", l_0_2)
RegisterEvent("SYNC_ROLE_DATA_END", RaidGridEx.OpenPanel)
RegisterEvent("PARTY_RESET", l_0_1)
RegisterEvent("PARTY_UPDATE_BASE_INFO", l_0_2)
RaidGridEx.Create = function(l_24_0)
  local l_24_1 = BoxCheckBox
  local l_24_2 = l_24_0
  local l_24_3 = "CheckBox_Run"
  local l_24_4 = {}
  l_24_4.txt = "�����Ŷӿ��"
  l_24_1 = l_24_1(l_24_2, l_24_3, l_24_4)
  l_24_2 = RaidGridEx
  l_24_2 = l_24_2.bOn
  if l_24_2 then
    l_24_2, l_24_3 = l_24_1:Check, l_24_1
    l_24_4 = true
    l_24_2(l_24_3, l_24_4)
  end
  l_24_2, l_24_3 = l_24_1:OnCheck, l_24_1
  l_24_4 = function()
    RaidGridEx.bOn = true
    RaidGridEx.OpenPanel()
  end
  l_24_2(l_24_3, l_24_4)
  l_24_2, l_24_3 = l_24_1:UnCheck, l_24_1
  l_24_4 = function()
    RaidGridEx.bOn = false
    RaidGridEx.ClosePanel()
    if RaidGridEx.IsInRaid() then
      RaidGridEx.EnableRaidPanel(true)
    else
      OpenTeammate()
    end
  end
  l_24_2(l_24_3, l_24_4)
  l_24_2 = BoxCheckBox
  l_24_3 = l_24_0
  l_24_4 = "CheckBox_InRaid"
  local l_24_5 = {}
  l_24_5.txt = "�����Ŷ�ʱ��ʾ"
  l_24_5.x = 150
  l_24_5.y = 0
  l_24_2 = l_24_2(l_24_3, l_24_4, l_24_5)
  l_24_3 = RaidGridEx
  l_24_3 = l_24_3.bShowInRaid
  if l_24_3 then
    l_24_3, l_24_4 = l_24_2:Check, l_24_2
    l_24_5 = true
    l_24_3(l_24_4, l_24_5)
  end
  l_24_3, l_24_4 = l_24_2:OnCheck, l_24_2
  l_24_5 = function()
    RaidGridEx.bShowInRaid = true
    if not RaidGridEx.IsInRaid() then
      RaidGridEx.ClosePanel()
      OpenTeammate()
    end
  end
  l_24_3(l_24_4, l_24_5)
  l_24_3, l_24_4 = l_24_2:UnCheck, l_24_2
  l_24_5 = function()
    RaidGridEx.bShowInRaid = false
    if not RaidGridEx.IsInRaid() then
      RaidGridEx.OpenPanel()
    end
  end
  l_24_3(l_24_4, l_24_5)
  l_24_3, l_24_4 = l_24_0:Lookup, l_24_0
  l_24_5 = ""
  l_24_3 = l_24_3(l_24_4, l_24_5, "")
  l_24_4 = BoxLabel
  l_24_5 = l_24_3
  local l_24_6 = "label1"
  local l_24_7 = "�Ŷ��б�����"
  local l_24_8 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7, l_24_8, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7, l_24_8)
  l_24_8 = {0, 30}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5, l_24_6, l_24_7, l_24_8)
  l_24_8 = {0, 145}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_4(l_24_5)
end

RegisterMoonButton("RaidGridEx", 1680, "�Ŷӿ��", "Team", RaidGridEx.Create)
Hotkey.AddBinding("Raid_Open", "�Ŷӿ��", "�Ŷӿ��", function()
  local l_25_0 = GetClientPlayer()
  local l_25_1 = l_25_0.IsInParty()
  local l_25_2 = l_25_0.IsInRaid()
  if RaidGridEx.bOn then
    RaidGridEx.bOn = false
    RaidGridEx.ClosePanel()
    if RaidGridEx.IsInRaid() then
      RaidGridEx.EnableRaidPanel(true)
    else
      OpenTeammate()
    end
  elseif l_25_1 and not l_25_2 then
    RaidGridEx.bShowInRaid = false
  end
  RaidGridEx.bOn = true
  RaidGridEx.OpenPanel()
end
, nil)
Hotkey.AddBinding("Raid_Save", "�Ŷӱ���", nil, function()
  RaidGridEx.SaveRaid()
end
, nil)
Hotkey.AddBinding("Raid_Restore", "�Ŷӻ�ԭ", nil, function()
  RaidGridEx.RestoreRaid()
end
, nil)
RegisterPlayerMenu("raidgridex", function()
  if not RaidGridEx.bPlayerMenu then
    return {}
  end
  local l_28_0 = {}
  l_28_0.szOption = "�Ŷӱ���"
  local l_28_1 = {}
  l_28_1.szOption = "�����Ŷ�"
  l_28_1.fnAction = function()
    RaidGridEx.SaveRaid()
  end
  local l_28_2 = {}
  l_28_2.szOption = "��ԭ�Ŷ�"
  l_28_2.fnAction = function()
    RaidGridEx.RestoreRaid()
  end
  local l_28_3 = {}
  l_28_3.bDevide = true
  local l_28_4 = {}
  l_28_4.szOption = "����С������"
  l_28_4.bCheck = true
  l_28_4.bChecked = RaidGridEx.bKeepFormation
  l_28_4.fnAction = function()
    RaidGridEx.bKeepFormation = not RaidGridEx.bKeepFormation
  end
  local l_28_5 = {}
  l_28_5.szOption = "������Ա���"
  l_28_5.bCheck = true
  l_28_5.bChecked = RaidGridEx.bKeepAllyMark
  l_28_5.fnAction = function()
    RaidGridEx.bKeepAllyMark = not RaidGridEx.bKeepAllyMark
  end
  local l_28_6 = {}
  l_28_6.bDevide = true
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_28_2 = l_28_0
  return l_28_1
  l_28_1 = {l_28_2}
end
)

