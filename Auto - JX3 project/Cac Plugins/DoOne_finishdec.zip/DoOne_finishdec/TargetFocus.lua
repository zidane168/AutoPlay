-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetFocus.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = 378
l_0_1.y = 75
l_0_0.Anchor = l_0_1
l_0_0.life = 1
l_0_0.hBuff = nil
l_0_0.hDebuff = nil
TargetFocus = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "TargetFocus.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "TargetFocus.life"
l_0_0(l_0_1)
l_0_0 = 0
l_0_1 = TargetFocus
l_0_1.OnFrameCreate = function()
  -- upvalues: l_0_0
  this:RegisterEvent("NPC_STATE_UPDATE")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("PLAYER_STATE_UPDATE")
  this:RegisterEvent("PLAYER_ENTER_SCENE")
  this:RegisterEvent("UPDATE_RELATION")
  this:RegisterEvent("UPDATE_ALL_RELATION")
  this:RegisterEvent("PLAYER_LEVEL_UP")
  this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
  this:RegisterEvent("PARTY_UPDATE_BASE_INFO")
  this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
  this:RegisterEvent("SET_SHOW_VALUE_BY_PERCENTAGE")
  this:RegisterEvent("SET_TARGET_SHOW_STATE_VALUE")
  this:RegisterEvent("PARTY_SET_MARK")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("CHANGE_CAMP")
  this:RegisterEvent("CHANGE_CAMP_FLAG")
  this:RegisterEvent("UI_ON_DAMAGE_EVENT")
  local l_1_0 = this:Lookup("", "")
  TargetFocus.hBuff = l_1_0:Lookup("Handle_Buff")
  TargetFocus.hBuff:Clear()
  TargetFocus.hDebuff = l_1_0:Lookup("Handle_Debuff")
  TargetFocus.hDebuff:SetRelPos(5, 88)
  TargetFocus.hDebuff:Clear()
  TargetFocus.hBuff.tItem = {}
  TargetFocus.hBuff.tVersion = {}
  TargetFocus.hDebuff.tItem = {}
  TargetFocus.hDebuff.tVersion = {}
  l_0_0 = 0
  TargetFocus.UpdateAnchor(this)
  UpdateCustomModeWindow(this, "����Ŀ��")
end

l_0_1 = TargetFocus
l_0_1.OnFrameDragEnd = function()
  this:CorrectPos()
  TargetFocus.Anchor = GetFrameAnchor(this)
end

l_0_1 = TargetFocus
l_0_1.FormatNumber = function(l_3_0, l_3_1)
  if not l_3_1 then
    return l_3_0
  end
  if l_3_0 > 10000 then
    return "%.2f":format(l_3_0 / 10000) .. "��"
  else
    return l_3_0
  end
end

l_0_1 = TargetFocus
l_0_1.GetStateString = function(l_4_0, l_4_1, l_4_2, l_4_3)
  local l_4_4 = ""
  if TargetFocus.life == 2 then
    l_4_4 = string.format("%.1f", 100 * l_4_0 / l_4_1) .. "%"
  elseif l_4_2 and (l_4_0 == l_4_1 or l_4_0 > 9999) then
    l_4_4 = "????/????"
  else
    l_4_4 = TargetFocus.FormatNumber(l_4_0, l_4_3) .. "/" .. TargetFocus.FormatNumber(l_4_1, l_4_3)
  end
  return l_4_4
end

l_0_1 = TargetFocus
l_0_1.UpdateState = function(l_5_0)
  local l_5_1 = GetClientPlayer()
  local l_5_2 = 0
  local l_5_3 = 0
  local l_5_4 = nil
  local l_5_5 = true
  local l_5_6 = GetTargetHandle(l_5_0.dwType, l_5_0.dwID)
  if not l_5_6 then
    return 
  end
  if l_5_0.dwType == TARGET.NPC then
    l_5_4 = GetNpcIntensity(l_5_6)
    l_5_5 = l_5_6.CanSeeLifeBar()
  end
  if l_5_6.nLevel - l_5_1.nLevel > 10 then
    local l_5_7 = not l_5_1.IsPlayerInMyParty(l_5_0.dwID)
  else
    local l_5_8 = false
  end
  local l_5_9 = nil
  if not IsPlayer(l_5_6.dwID) and l_5_6.nMaxLife > 100000 then
    local l_5_10 = true
    if l_5_6.nMaxLife ~= 0 then
      local l_5_11 = nil
      if l_5_5 then
        local l_5_12 = l_5_0:Lookup("", ""):Lookup("Text_Health")
        l_5_12:SetText(TargetFocus.GetStateString(l_5_6.nCurrentLife, l_5_6.nMaxLife, l_5_9, l_5_10))
        l_5_12:Show()
      end
     -- DECOMPILER ERROR: Confused about usage of registers!

    else
      l_5_12:Hide()
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_5_13 = nil
    l_5_11:Lookup("Text_Mana"):Hide()
    local l_5_14 = nil
    if l_5_6.nMaxMana > 1 then
      if l_5_5 then
        local l_5_15 = l_5_13:Lookup("Image_Mana")
        if l_5_0.dwType == TARGET.PLAYER then
          local l_5_16 = TargetFocus.GetStateString(l_5_6.nCurrentMana, l_5_6.nMaxMana, l_5_9, l_5_10)
          if GetForceTitle(l_5_6.dwForceID) == "�ؽ�" then
            l_5_15:SetFrame(86)
            l_5_16 = l_5_6.nCurrentRage .. "/" .. l_5_6.nMaxRage
             -- DECOMPILER ERROR: Overwrote pending register.

          end
        elseif GetForceTitle(l_5_6.dwForceID) == "����" then
          l_5_15:SetFrame(87)
          l_5_16 = l_5_6.nCurrentEnergy .. "/" .. l_5_6.nMaxEnergy
           -- DECOMPILER ERROR: Overwrote pending register.

        elseif GetForceTitle(l_5_6.dwForceID) == "����" then
          if l_5_6.nMoonPowerValue > 0 then
            l_5_16 = "����"
            l_5_15:SetFrame(37)
             -- DECOMPILER ERROR: Overwrote pending register.

          elseif l_5_6.nSunPowerValue > 0 then
            l_5_16 = "����"
             -- DECOMPILER ERROR: Overwrote pending register.

          else
            l_5_16 = "��:%d ��:%d":format(l_5_6.nCurrentSunEnergy / 100, l_5_6.nCurrentMoonEnergy / 100)
            if l_5_6.nCurrentSunEnergy < l_5_6.nCurrentMoonEnergy then
              l_5_15:SetFrame(37)
               -- DECOMPILER ERROR: Overwrote pending register.

            end
          else
            l_5_15:SetFrame(105)
             -- DECOMPILER ERROR: Overwrote pending register.

          end
        else
          l_5_15:SetFrame(37)
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_5_14:SetText(l_5_16)
        l_5_14:Show()
      end
    else
      l_5_14:Hide()
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_5_15:SetPercentage(l_5_3)
    local l_5_17 = nil
    local l_5_18 = l_5_13:Lookup("Image_Health")
    local l_5_19 = l_5_13:Lookup("Image_SubHealth")
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_5_6.nMoveState == MOVE_STATE.ON_DEATH or l_5_0.dwLastTarget ~= l_5_0.dwID then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    l_5_19:SetPercentage(0)
    l_5_0.dwLastTarget = l_5_0.dwID
    l_5_18:SetPercentage(l_5_2)
    if l_5_0.dwType == TARGET.PLAYER and l_5_0.dwMountType then
      l_5_0:Lookup("", "Image_TarBg"):Show()
      l_5_0:Lookup("", "Image_TarBgF"):Hide()
      l_5_17:Show()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 48 
end

l_0_1 = TargetFocus
l_0_1.OnActionBreak = function(l_6_0)
  l_6_0:Lookup("", "Handle_Bar").nActionState = ACTION_STATE.BREAK
end

l_0_1 = TargetFocus
l_0_1.UpdateAction = function(l_7_0)
  local l_7_1 = GetTargetHandle(l_7_0.dwType, l_7_0.dwID)
  local l_7_2 = l_7_0:Lookup("", "Handle_Bar")
  if not l_7_1 then
    l_7_2:Hide()
    return 
  end
  local l_7_3, l_7_4, l_7_5, l_7_6 = l_7_1.GetSkillPrepareState()
  if l_7_3 and l_7_2.nActionState ~= ACTION_STATE.PREPARE then
    l_7_2:SetAlpha(255)
    l_7_2:Show()
    l_7_2:Lookup("Image_Progress"):Show()
    l_7_2:Lookup("Image_FlashS"):Hide()
    l_7_2:Lookup("Image_FlashF"):Hide()
    l_7_2:Lookup("Text_Name"):SetText(Table_GetSkillName(l_7_4, l_7_5))
    l_7_2.nActionState = ACTION_STATE.PREPARE
  elseif not l_7_3 and l_7_2.nActionState == ACTION_STATE.PREPARE then
    l_7_2.nActionState = ACTION_STATE.DONE
  end
  if l_7_2.nActionState == ACTION_STATE.PREPARE then
    l_7_2:Lookup("Image_Progress"):SetPercentage(l_7_6)
  else
    if l_7_2.nActionState == ACTION_STATE.DONE then
      l_7_2:Lookup("Image_FlashS"):Show()
      l_7_2.nActionState = ACTION_STATE.FADE
    end
  else
    if l_7_2.nActionState == ACTION_STATE.BREAK then
      l_7_2:Lookup("Image_FlashF"):Show()
      l_7_2.nActionState = ACTION_STATE.FADE
    end
  else
    if l_7_2.nActionState == ACTION_STATE.FADE then
      local l_7_7 = l_7_2:GetAlpha() - 10
      if l_7_7 > 0 then
        l_7_2:SetAlpha(l_7_7)
      end
    else
      l_7_2.nActionState = ACTION_STATE.NONE
    end
  else
    l_7_2:Hide()
  end
end

l_0_1 = TargetFocus
l_0_1.RemoveLeftItem = function(l_8_0, l_8_1)
  local l_8_2 = l_8_0:GetItemCount()
  local l_8_3 = l_8_2 - l_8_1
  for l_8_7 = 1, l_8_3 do
    l_8_0:RemoveItem(l_8_2 - l_8_7)
  end
end

l_0_1 = TargetFocus
l_0_1.UpdateMountType = function(l_9_0)
  if l_9_0.dwType ~= TARGET.PLAYER then
    return 
  end
  l_9_0.dwMountType = nil
  local l_9_1 = GetPlayer(l_9_0.dwID)
  if l_9_1 then
    local l_9_2 = l_9_1.GetKungfuMount()
  end
  if l_9_2 then
    l_9_0.dwMountType = l_9_2.dwMountType
  end
end

l_0_1 = TargetFocus
l_0_1.UpdateInfo = function(l_10_0)
  local l_10_1 = GetTargetHandle(l_10_0.dwType, l_10_0.dwID)
  if not l_10_1 then
    return 
  end
  local l_10_2 = ""
  local l_10_3 = 0
  local l_10_4 = GetClientPlayer()
  if l_10_0.dwType == TARGET.PLAYER then
    local l_10_5, l_10_6 = GetForceImage(l_10_1.dwForceID)
    local l_10_7 = l_10_0:Lookup("", "Image_NewTarget")
    l_10_7:FromUITex(l_10_5, l_10_6)
  else
    if l_10_0.dwType == TARGET.NPC then
      local l_10_8 = GetNpc(l_10_0.dwID).dwModelID
      local l_10_9 = l_10_0:Lookup("", "Image_Target")
      local l_10_10 = l_10_0:Lookup("", "Image_NewTarget")
      local l_10_11 = NPC_GetProtrait(l_10_8)
      local l_10_12 = NPC_GetHeadImageFile(l_10_8)
      if l_10_11 and IsFileExist(l_10_11) then
        l_10_2 = l_10_11
      else
        l_10_2 = l_10_12
      end
      if IsFileExist(l_10_2) then
        l_10_10:FromTextureFile(l_10_2)
      end
    end
  else
    l_10_2 = GetNpcHeadImage(l_10_0.dwID)
    l_10_10:FromUITex(l_10_2, l_10_3)
  end
  local l_10_13 = l_10_0:Lookup("", "Text_Target")
  l_10_13:SetFontColor(GetForceFontColor(l_10_0.dwID, l_10_4.dwID))
  local l_10_14 = GetTargetName(l_10_0.dwType, l_10_0.dwID)
  l_10_13:SetText(l_10_14)
  local l_10_15 = l_10_0:Lookup("", "Text_Level")
  local l_10_16 = l_10_0:Lookup("", "Image_Danger")
  local l_10_17 = l_10_1.nLevel - l_10_4.nLevel
  if l_10_4.IsPlayerInMyParty(l_10_0.dwID) or l_10_17 <= 10 then
    local l_10_18 = GetTargetLevelFont(l_10_17)
    l_10_15:SetFontScheme(l_10_18)
    l_10_15:SetText(l_10_1.nLevel)
    l_10_15:Show()
    l_10_16:Hide()
  else
    l_10_15:Hide()
    l_10_16:Show()
  end
  local l_10_19 = nil
  if l_10_0.dwType == TARGET.PLAYER then
    local l_10_20 = GetTargetHandle(l_10_0.dwType, l_10_0.dwID)
    l_10_19 = GetCampImageFrame(l_10_20.nCamp, l_10_20.bCampFlag)
  end
  local l_10_21 = l_10_0:Lookup("", "Image_Camp")
  SetImage(l_10_21, l_10_19)
  local l_10_22 = (l_10_0:Lookup("", "Image_NPCMark"))
  local l_10_23 = nil
  if l_10_4.IsInParty() then
    local l_10_24 = GetClientTeam().GetTeamMark()
    assert(l_10_24)
  end
  if l_10_24 and l_10_24[l_10_0.dwID] then
    local l_10_25 = l_10_24[l_10_0.dwID]
    local l_10_26 = assert
    l_10_26(l_10_25 > 0 and l_10_25 <= #PARTY_MARK_ICON_FRAME_LIST)
    l_10_26 = PARTY_MARK_ICON_FRAME_LIST
    l_10_23 = l_10_26[l_10_25]
  end
  if l_10_23 then
    l_10_22:FromUITex(PARTY_MARK_ICON_PATH, l_10_23)
    l_10_22:Show()
  else
    l_10_22:Hide()
  end
end

l_0_1 = TargetFocus
l_0_1.OnDamageEvent = function(l_11_0, l_11_1, l_11_2)
  local l_11_3 = l_11_0:Lookup("", "Image_Health")
  local l_11_4 = l_11_0:Lookup("", "Image_SubHealth")
  local l_11_5 = (l_11_3:GetPercentage())
  local l_11_6 = nil
  if l_11_0.dwType == TARGET.PLAYER then
    l_11_6 = GetPlayer(l_11_0.dwID)
  else
    if l_11_0.dwType == TARGET.NPC then
      l_11_6 = GetNpc(l_11_0.dwID)
    end
  end
  local l_11_7 = l_11_3:GetPercentage()
  if not l_11_6 or l_11_6.nMaxLife == 0 then
    l_11_4:SetPercentage(l_11_7)
    return 
  end
  local l_11_9 = l_11_4:GetPercentage()
  if l_11_9 - l_11_1 / l_11_6.nMaxLife < l_11_7 then
    l_11_9 = l_11_7
    do
      local l_11_8 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_11_9 = l_11_9 - l_11_8
  end
  l_11_4:SetPercentage(l_11_9)
end

l_0_1 = TargetFocus
l_0_1.UpdateAnchor = function(l_12_0)
  l_12_0:SetPoint(TargetFocus.Anchor.s, 0, 0, TargetFocus.Anchor.r, TargetFocus.Anchor.x, TargetFocus.Anchor.y)
  l_12_0:CorrectPos()
end

l_0_1 = function(l_13_0, l_13_1)
  local l_13_2, l_13_5 = GetTimeToHourMinuteSecond(l_13_0, true)
  if l_13_2 > 0 then
    return ""
  end
  if l_13_5 > 0 then
    if true >= 1 then
      local l_13_3, l_13_4 = , ""
    end
    return l_13_5 .. "'"
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_13_3 > 0 then
    return l_13_3 .. "''"
  end
  return ""
end

do
  local l_0_3 = function(l_14_0)
  -- upvalues: l_0_1
  local l_14_1 = GetLogicFrameCount()
  local l_14_2 = l_14_0:GetItemCount()
  if l_14_2 > 0 then
    for l_14_6 = 0, l_14_2 - 1 do
      local l_14_7 = l_14_0:Lookup(l_14_6)
      if l_14_7 then
        if l_14_7.nEndFrame < l_14_1 then
          l_14_0:RemoveItem(l_14_7:GetName())
          l_14_0:FormatAllItemPos()
        end
      else
        local l_14_8 = l_0_1(l_14_7.nEndFrame - GetLogicFrameCount(), true)
        l_14_7:SetOverTextPosition(1, 3)
        l_14_7:SetOverTextFontScheme(1, 16)
        l_14_7:SetOverText(1, l_14_8)
      end
    end
  end
end

  RegisterEvent("Breathe", function()
  local l_21_0 = Station.Lookup("Normal/TargetFocus")
  local l_21_1 = GetTargetHandle(l_21_0.dwType, l_21_0.dwID)
  if not l_21_1 and l_21_0:IsVisible() then
    l_21_0:Hide()
  end
  do return end
  if not l_21_0:IsVisible() then
    l_21_0:Show()
  end
end
)
  RegisterTargetMenu("focus", RegisterTargetFocusMenu)
  Wnd.OpenWindow("interface\\Moon_TargetFocus\\TargetFocus.ini", "TargetFocus"):Hide()
  RegisterBoxAddonVersion("Moon_TargetFocus", 0.2)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

