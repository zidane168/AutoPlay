-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TeamShow.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
local l_0_27 = string.format
TeammateBak = nil
local l_0_28 = {}
local l_0_29 = {}
l_0_29.s = "TOPLEFT"
l_0_29.r = "TOPLEFT"
l_0_29.x = 25
l_0_29.y = 255
l_0_28.DefaultAnchor = l_0_29
l_0_28.Anchor, l_0_29 = l_0_29, {s = "TOPLEFT", r = "TOPLEFT", x = 25, y = 255}
TeammateHook = l_0_28
l_0_28 = RegisterCustomData
l_0_29 = "TeammateHook.Anchor"
l_0_28(l_0_29)
l_0_28 = 1
if l_0_28 == 1 and l_0_28 == 1 then
  l_0_28 = 0
  l_0_29 = function()
    -- upvalues: l_0_28
    return l_0_28 == 2 or l_0_28 == 3
  end
end
end
end
l_0_29 = function()
local l_2_0 = 1
if l_2_0 == 1 and l_2_0 == 1 then
l_2_0 = 0
else
do return end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_2_2 = nil
if function()
  -- upvalues: l_2_0
  return l_2_0 == 2 or l_2_0 == 3
end
.modelView == nil then
  TeammateHook.modelView = {}
  for i = 1, 5 do
    TeammateHook.modelView[i] = PlayerModelView.new()
    TeammateHook.modelView[i]:init()
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
local l_0_30 = function()
local l_3_0 = 1
if l_3_0 == 1 and l_3_0 == 1 then
l_3_0 = 0
else
do return end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_3_2 = nil
if function()
  -- upvalues: l_3_0
  return l_3_0 == 2 or l_3_0 == 3
end
.modelView then
  for i = 1, 5 do
    TeammateHook.modelView[i]:UnloadModel()
    TeammateHook.modelView[i]:release()
  end
end
TeammateHook.modelView = nil
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
TeammateHook.OnFrameCreate = function()
-- upvalues: l_0_29
l_0_29()
this:RegisterEvent("BUFF_UPDATE")
this:RegisterEvent("PARTY_UPDATE_BASE_INFO")
this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
this:RegisterEvent("PLAYER_STATE_UPDATE")
this:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
this:RegisterEvent("PARTY_DELETE_MEMBER")
this:RegisterEvent("PARTY_DISBAND")
this:RegisterEvent("PLAYER_LEAVE_SCENE")
this:RegisterEvent("PARTY_UPDATE_MEMBER_LMR")
this:RegisterEvent("PARTY_INVITE_REQUEST")
this:RegisterEvent("PARTY_APPLY_REQUEST")
this:RegisterEvent("PARTY_SET_FORMATION_LEADER")
this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
this:RegisterEvent("SET_SHOW_VALUE_BY_PERCENTAGE")
this:RegisterEvent("SET_SHOW_TEAMMATE_STATE_VALUE")
this:RegisterEvent("SYNC_ROLE_DATA_END")
this:RegisterEvent("PARTY_SET_MARK")
this:RegisterEvent("UI_SCALED")
this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
this:RegisterEvent("TEAMMATE_ANCHOR_CHANGED")
this:RegisterEvent("CUSTOM_DATA_LOADED")
TeammateHook.UpdateAnchor(this)
UpdateCustomModeWindow(this, g_tStrings.TEAMMATE)
this.bCreate = true
end
TeammateHook.OnFrameDrag = function()
end
TeammateHook.OnFrameDragSetPosEnd = function()
end
TeammateHook.OnFrameDragEnd = function()
this:CorrectPos()
TeammateHook.Anchor = GetFrameAnchor(this)
end
TeammateHook.UpdateAnchor = function(l_8_0)
l_8_0:SetPoint(TeammateHook.Anchor.s, 0, 0, TeammateHook.Anchor.r, TeammateHook.Anchor.x, TeammateHook.Anchor.y)
l_8_0:CorrectPos()
end
TeammateHook.OnFrameDestroy = function()
-- upvalues: l_0_30
this.bCreate = false
l_0_30()
end
TeammateHook.Update = function(l_10_0)
TeammateHook.UptadePartyList(l_10_0)
TeammateHook.UpdateAnchor(l_10_0)
end
TeammateHook.UptadePartyList = function(l_11_0)
-- upvalues: l_0_1 , l_0_10
local l_11_1 = l_11_0:Lookup("", "")
l_11_1:Clear()
local l_11_2 = l_0_1()
if not l_11_2 or not l_11_2.IsInParty() then
return 
end
local l_11_3 = l_0_10()
local l_11_4 = l_11_3.GetMemberGroupIndex(l_11_2.dwID)
local l_11_5 = l_11_3.GetGroupInfo(l_11_4)
for l_11_9,l_11_10 in pairs(l_11_5.MemberList) do
TeammateHook.AddPartyMember(l_11_1, l_11_10)
end
TeammateHook.UpdatePosInfo(l_11_0)
TeammateHook.UpdatePartyMark(l_11_0)
end
TeammateHook.BuffPosUpdate = function(l_12_0)
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_12_1 = Station.Lookup("Normal/Teammate")
if l_12_1 then
local l_12_2 = l_12_1:Lookup("", "")
local l_12_3 = l_12_2:GetItemCount()
for l_12_7 = 0, l_12_3 - 1 do
  local l_12_8 = l_12_2:Lookup(l_12_7)
  local l_12_9 = l_12_8:Lookup("Handle_Buff")
  local l_12_10 = l_12_8:Lookup("Handle_Debuff")
  local l_12_11 = PrettyShow.Options.nScale_Team
  local l_12_12, l_12_13 = l_12_8:GetAbsPos()
  if PrettyShow.Options.TeamBuffLeft == 1 then
    local l_12_14 = l_12_12 + l_12_11 * 2
    local l_12_15 = l_12_13 + l_12_11 * 70
    l_12_9:SetAbsPos(l_12_14, l_12_15)
    local l_12_16 = l_12_12 + l_12_11 * 248
    local l_12_17 = l_12_13 + l_12_11 * 36
    l_12_10:SetAbsPos(l_12_16, l_12_17)
  else
    if PrettyShow.Options.TeamBuffLeft == 2 then
      local l_12_18 = l_12_12 + l_12_11 * 248
      local l_12_19 = l_12_13 + l_12_11 * 36
      l_12_9:SetAbsPos(l_12_18, l_12_19)
      local l_12_20 = l_12_12 + l_12_11 * 2
      local l_12_21 = l_12_13 + l_12_11 * 70
      l_12_10:SetAbsPos(l_12_20, l_12_21)
    end
  else
    if PrettyShow.Options.TeamBuffLeft == 3 then
      local l_12_22 = l_12_12 + l_12_11 * 248
      local l_12_23 = l_12_13 + l_12_11 * 2
      l_12_9:SetAbsPos(l_12_22, l_12_23)
      local l_12_24 = l_12_12 + l_12_11 * 248
      local l_12_25 = l_12_13 + l_12_11 * 36
      l_12_10:SetAbsPos(l_12_24, l_12_25)
    end
  end
end
end
end
TeammateHook.OnEvent = function(l_13_0)
-- upvalues: l_0_1 , l_0_10 , l_0_8
if l_13_0 == "BUFF_UPDATE" then
if not TeammateHook.IsInMyGroup(arg0) then
  return 
end
local l_13_1 = TeammateHook.GetMemberHandle(this, arg0)
do
  if l_13_1 then
    if arg7 then
      TeammateHook.RefreshBuff(l_13_1)
    end
    do break end
  end
  if arg3 then
    TeammateHook.UpdateBuff(l_13_1:Lookup("Handle_Buff"), arg1, arg2, true, arg4, arg5, arg6, arg8, arg9)
    do break end
  end
  TeammateHook.UpdateBuff(l_13_1:Lookup("Handle_Debuff"), arg1, arg2, false, arg4, arg5, arg6, arg8, arg9)
end
do break end
end
if l_13_0 == "PARTY_UPDATE_BASE_INFO" then
TeammateHook.Update(this)
do break end
end
if l_13_0 == "PARTY_UPDATE_MEMBER_LMR" then
if not TeammateHook.IsInMyGroup(arg1) then
  return 
end
local l_13_2 = TeammateHook.GetMemberHandle(this, arg1)
if l_13_2 then
  TeammateHook.UpdateMemberHFData(l_13_2)
end
do break end
end
if l_13_0 == "PARTY_UPDATE_MEMBER_INFO" then
if not TeammateHook.IsInMyGroup(arg1) then
  return 
end
local l_13_3 = TeammateHook.GetMemberHandle(this, arg1)
if l_13_3 then
  TeammateHook.UpdateMemberLFData(l_13_3)
end
do break end
end
if l_13_0 == "PLAYER_STATE_UPDATE" then
if not TeammateHook.IsInMyGroup(arg0) then
  return 
end
local l_13_4 = TeammateHook.GetMemberHandle(this, arg0)
if l_13_4 then
  TeammateHook.UpdateMemberLFData(l_13_4)
end
do break end
end
if l_13_0 == "PARTY_SET_MEMBER_ONLINE_FLAG" then
if not TeammateHook.IsInMyGroup(arg1) then
  return 
end
local l_13_5 = TeammateHook.GetMemberHandle(this, arg1)
if l_13_5 then
  TeammateHook.UpdateMemberLFData(l_13_5)
end
do break end
end
if l_13_0 == "TEAM_AUTHORITY_CHANGED" then
local l_13_6 = false
if TeammateHook.IsInMyGroup(arg2) then
  local l_13_7 = TeammateHook.GetMemberHandle(this, arg2)
end
if l_13_7 then
  TeammateHook.UpdateMemberLFData(l_13_7)
  l_13_6 = true
end
if TeammateHook.IsInMyGroup(arg3) then
  local l_13_8 = TeammateHook.GetMemberHandle(this, arg3)
end
if l_13_8 then
  TeammateHook.UpdateMemberLFData(l_13_8)
  l_13_6 = true
end
if l_13_6 then
  TeammateHook.UpdatePosInfo(this)
end
do break end
end
if l_13_0 == "PARTY_SET_FORMATION_LEADER" then
if not TeammateHook.IsInMyGroup(arg0) then
  return 
end
local l_13_9 = this:Lookup("", "")
if not l_13_9 then
  return 
end
do
  local l_13_10 = l_13_9:GetItemCount()
  for l_13_14 = 0, l_13_10 - 1 do
    local l_13_15 = l_13_9:Lookup(l_13_14)
    if l_13_15.bFormationLeader or l_13_15.dwID == arg0 then
      TeammateHook.UpdateMemberLFData(l_13_15)
    end
  end
end
do break end
end
if l_13_0 == "TEAM_CHANGE_MEMBER_GROUP" then
local l_13_16 = l_0_1()
local l_13_17 = l_0_10()
local l_13_18 = l_13_17.GetMemberGroupIndex(l_13_16.dwID)
if l_13_18 == arg1 or l_13_18 == arg2 then
  TeammateHook.UptadePartyList(this)
end
do break end
end
if l_13_0 == "PARTY_DELETE_MEMBER" then
local l_13_19 = this:Lookup("", "")
local l_13_20 = l_0_1()
if l_13_20.dwID == arg1 then
  l_13_19:Clear()
  do break end
end
local l_13_21 = l_0_10()
do
  local l_13_22 = l_13_21.GetMemberGroupIndex(l_13_20.dwID)
  if l_13_22 ~= arg3 then
    return 
  end
  TeammateHook.DeletePartyMember(l_13_19, arg1)
end
do break end
end
if l_13_0 == "PARTY_DISBAND" then
this:Lookup("", ""):Clear()
do break end
end
if l_13_0 == "PLAYER_LEAVE_SCENE" then
if not TeammateHook.IsInMyGroup(arg0) then
  return 
end
local l_13_23 = this:Lookup("", "")
do
  local l_13_24 = l_13_23:GetItemCount()
  for l_13_28 = 0, l_13_24 - 1 do
    do
      local l_13_29 = l_13_23:Lookup(l_13_28)
      if l_13_29.dwID == arg0 then
        l_13_29:Lookup("Handle_Buff"):Clear()
        l_13_29:Lookup("Handle_Debuff"):Clear()
      end
      do break end
    end
  end
end
do break end
end
if l_13_0 == "PARTY_ADD_MEMBER" and TeammateHook.AddPartyMember(this:Lookup("", ""), arg1) then
PlaySound(SOUND.UI_SOUND, g_sound.Complete)
end
do break end
if l_13_0 == "PARTY_SYNC_MEMBER_DATA" then
TeammateHook.AddPartyMember(this:Lookup("", ""), arg1)
do break end
end
if l_13_0 == "PARTY_INVITE_REQUEST" then
local l_13_30 = arg0
local l_13_31 = l_0_8()
local l_13_32 = {}
l_13_32.szName = "IMTP_" .. l_13_30
l_13_32.szMessage = FormatString(g_tStrings.STR_PLAYER_INVITE_PARTY, arg0, arg3, g_tStrings.tForceTitle[arg2], g_tStrings.STR_GUILD_CAMP_NAME[arg1])
l_13_32.fnAutoClose = function()
  -- upvalues: l_0_8 , l_13_2
  return l_0_8() - l_13_2 > 120000
end

l_13_32.fnCancelAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamInvite(l_13_1, 0)
end

local l_13_33 = {}
l_13_33.szOption = g_tStrings.STR_ACCEPT
l_13_33.fnAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamInvite(l_13_1, 1)
  return 
end

l_13_33.szSound = g_sound.Complete
do
  local l_13_34 = {}
  l_13_34.szOption = g_tStrings.STR_REFUSE
  l_13_34.fnAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamInvite(l_13_1, 0)
  return 
end

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_13_33 = MessageBox
  l_13_34 = l_13_32
  l_13_33(l_13_34, true)
  l_13_33 = AddContactPeople
  l_13_34 = arg0
  l_13_33(l_13_34)
  l_13_33 = PlaySound
  l_13_34 = SOUND
  l_13_34 = l_13_34.UI_SOUND
  l_13_33(l_13_34, g_sound.Invite)
end
do break end
end
if l_13_0 == "PARTY_APPLY_REQUEST" then
local l_13_35 = arg0
local l_13_36 = l_0_8()
local l_13_37 = {}
l_13_37.szName = "ATMP_" .. l_13_35
l_13_37.szMessage = FormatString(g_tStrings.STR_PLAYER_APPLY_PARTY, arg0, arg3, g_tStrings.tForceTitle[arg2], g_tStrings.STR_GUILD_CAMP_NAME[arg1])
l_13_37.fnAutoClose = function()
  -- upvalues: l_0_8 , l_13_2
  return l_0_8() - l_13_2 > 120000
end

l_13_37.fnCancelAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamApply(l_13_1, 0)
end

local l_13_38 = {}
l_13_38.szOption = g_tStrings.STR_ACCEPT
l_13_38.fnAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamApply(l_13_1, 1)
  return 
end

l_13_38.szSound = g_sound.Complete
do
  local l_13_39 = {}
  l_13_39.szOption = g_tStrings.STR_REFUSE
  l_13_39.fnAction = function()
  -- upvalues: l_0_10 , l_13_1
  l_0_10().RespondTeamApply(l_13_1, 0)
  return 
end

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_13_38 = MessageBox
  l_13_39 = l_13_37
  l_13_38(l_13_39, true)
  l_13_38 = AddContactPeople
  l_13_39 = arg0
  l_13_38(l_13_39)
  l_13_38 = PlaySound
  l_13_39 = SOUND
  l_13_39 = l_13_39.UI_SOUND
  l_13_38(l_13_39, g_sound.OpenFrame)
end
do break end
end
if l_13_0 == "UPDATE_PLAYER_SCHOOL_ID" then
local l_13_40 = TeammateHook.GetMemberHandle(this, arg0)
if l_13_40 then
  TeammateHook.UpdateMemberLFData(l_13_40)
end
do break end
end
if l_13_0 == "SYNC_ROLE_DATA_END" then
local l_13_41 = this:Lookup("", "")
do
  local l_13_42 = l_13_41:GetItemCount()
  for l_13_46 = 0, l_13_42 - 1 do
    TeammateHook.UpdateMemberLFData(l_13_41:Lookup(l_13_46))
  end
end
do break end
end
if l_13_0 == "PARTY_SET_MARK" then
TeammateHook.UpdatePartyMark(this)
do break end
end
if l_13_0 == "SET_SHOW_VALUE_BY_PERCENTAGE" or l_13_0 == "SET_SHOW_TEAMMATE_STATE_VALUE" then
local l_13_47 = this:Lookup("", "")
TeammateHook.UpdateTeamateStateValueShow(l_13_47)
local l_13_48 = l_13_47:GetItemCount()
for l_13_52 = 0, l_13_48 - 1 do
  TeammateHook.UpdateMemberHFData(l_13_47:Lookup(l_13_52))
end
elseif l_13_0 == "UI_SCALED" then
TeammateHook.BuffPosUpdate(this)
TeammateHook.UpdateAnchor(this)
elseif l_13_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_13_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
UpdateCustomModeWindow(this)
elseif l_13_0 == "TEAMMATE_ANCHOR_CHANGED" then
TeammateHook.UpdateAnchor(this)
elseif l_13_0 == "CUSTOM_DATA_LOADED" then
Output("22")
TeammateHook.UpdateAnchor(this)
end
end
TeammateHook.UpdateBufferSparking = function(l_14_0)
-- upvalues: l_0_6 , l_0_9
local l_14_1 = l_14_0
local l_14_2 = l_14_1:GetItemCount() - 1
local l_14_3 = l_0_6()
local l_14_4 = PrettyShow.Options.bCoolTeam
local l_14_5 = PrettyShow.Options.bCoolTeam_Dir
local l_14_6 = PrettyShow.Options.bTextTeam
for l_14_10 = 0, l_14_2 do
local l_14_11 = l_14_1:Lookup(l_14_10)
if not l_14_11:IsVisible() then
  return 
end
local l_14_12 = ""
if l_14_11.bShowTime then
  local l_14_13 = l_14_11.nEndFrame - l_14_3
  if l_14_4 and l_14_11.bCool then
    l_14_11:SetObjectCoolDown(1)
    if l_14_5 then
      l_14_11:SetCoolDownPercentage(1 - l_14_13 / l_14_11.nStartFrame)
    end
  else
    l_14_11:SetCoolDownPercentage(l_14_13 / l_14_11.nStartFrame)
  end
  if l_14_13 < 0 then
    l_14_13 = 0
  end
  local l_14_15, l_14_16 = l_0_9(l_14_13, true)
  if l_14_15 >= 1 then
    if l_14_16 >= 1 or true >= 1 then
      l_14_15 = l_14_15 + 1
      local l_14_14 = nil
    end
    l_14_12 = ""
  end
 -- DECOMPILER ERROR: Confused about usage of registers!

elseif l_14_16 >= 1 then
  if l_14_14 >= 1 then
    l_14_16 = l_14_16 + 1
  end
  l_14_12 = l_14_16 .. "'"
 -- DECOMPILER ERROR: Confused about usage of registers!

else
  l_14_12 = l_14_14 .. ""
end
if PrettyShow.Options.bTextTeam then
  l_14_11:SetOverText(1, l_14_12)
end
end
end
TeammateHook.IsInMyGroup = function(l_15_0)
-- upvalues: l_0_1 , l_0_10
local l_15_1 = l_0_1()
if not l_15_1 or not l_15_1.IsInParty() then
return 
end
if not l_15_1.IsPlayerInMyParty(l_15_0) then
return 
end
local l_15_2 = l_0_10()
if l_15_2.IsPlayerInTeam(l_15_0) and l_15_2.GetMemberGroupIndex(l_15_1.dwID) == l_15_2.GetMemberGroupIndex(l_15_0) then
return true
end
end
TeammateHook.DeletePartyMember = function(l_16_0, l_16_1)
local l_16_2 = TeammateHook.GetMemberHandle(l_16_0:GetRoot(), l_16_1)
if l_16_2 then
local l_16_3 = l_16_2:GetIndex()
l_16_0:RemoveItem(l_16_3)
TeammateHook.UpdatePosInfo(l_16_0:GetRoot())
end
end
TeammateHook.UpdatePartyMark = function(l_17_0)
-- upvalues: l_0_1 , l_0_10
local l_17_1 = l_0_1()
if not l_17_1.IsInParty() then
return 
end
local l_17_2 = l_0_10().GetTeamMark()
if not l_17_2 then
return 
end
local l_17_3 = l_17_0:Lookup("", "")
local l_17_4 = l_17_3:GetItemCount()
for l_17_8 = 0, l_17_4 - 1 do
local l_17_9 = nil
local l_17_10 = l_17_3:Lookup(l_17_8)
local l_17_11 = l_17_10:Lookup("Image_NPCMark")
local l_17_12 = l_17_2[l_17_10.dwID]
if l_17_12 then
  local l_17_13 = assert
  l_17_13(l_17_12 > 0 and l_17_12 <= #PARTY_MARK_ICON_FRAME_LIST)
  l_17_13 = PARTY_MARK_ICON_FRAME_LIST
  l_17_9 = l_17_13[l_17_12]
end
if l_17_9 then
  l_17_11:FromUITex(PARTY_MARK_ICON_PATH, l_17_9)
  l_17_11:Show()
else
  l_17_11:Hide()
end
end
end
local l_0_31 = function(l_18_0, l_18_1)
local l_18_2 = Station.Lookup("Normal/Teammate")
if not l_18_2 then
return 
end
local l_18_3 = l_18_2:Lookup("Show_Role" .. l_18_0)
if l_18_3 then
if l_18_1 == true then
  l_18_3:Show()
end
else
l_18_3:Hide()
end
end
local l_0_34 = function(l_19_0)
-- upvalues: l_0_11
local l_19_1 = 1
if l_19_1 == 1 and l_19_1 == 1 then
l_19_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_19_3 = nil
if not function()
  -- upvalues: l_19_1
  return l_19_1 == 2 or l_19_1 == 3
end
.Lookup("Normal/Teammate") then
return 
end
local l_19_4 = nil
local l_19_5 = (TeammateHook.GetMemberHandle(function()
  -- upvalues: l_19_1
  return l_19_1 == 2 or l_19_1 == 3
end
.Lookup("Normal/Teammate"), l_19_0))
 -- DECOMPILER ERROR: Overwrote pending register.

if l_19_5 then

end
local l_19_6 = nil
local l_19_7 = l_0_11(l_19_0)
if not l_19_7 and l_19_6 then
l_19_6:SetAlpha(255)
TeammateHook.modelView[l_19_5:GetIndex() + 1]:UnloadModel()
end
return 
if l_19_6 then
l_19_6:SetAlpha(0)
end
local l_19_8 = nil
local l_19_9 = l_19_4:Lookup("Show_Role" .. l_19_5:GetIndex())
TeammateHook.modelView[l_19_8]:SetCamera(SelfPortraitCameraInfo[l_19_7.nRoleType])
l_19_9:SetScene(TeammateHook.modelView[l_19_8].m_scene)
TeammateHook.modelView[l_19_8]:UnloadModel()
local l_19_10 = nil
do
local l_19_11 = TeammateHook.modelView[l_19_8]
l_19_11.m_aRoleAnimation = {Idle = 41}
l_19_11 = TeammateHook
l_19_11 = l_19_11.modelView
l_19_11 = l_19_11[l_19_8]
l_19_11(l_19_11, l_19_0, false)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_19_11(l_19_11)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_19_11(l_19_11, "Idle", "loop")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
RegisterEvent("PARTY_DISBAND", function(l_37_0)
-- upvalues: l_0_1 , l_0_31
local l_37_1 = Station.Lookup("Normal/Teammate")
if not l_37_1 then
return 
end
do
if l_37_0 == "PARTY_DELETE_MEMBER" then
  local l_37_2 = l_37_1:Lookup("", "")
end
if l_0_1().dwID ~= arg1 then
  return 
end
end
local l_37_3 = l_37_1:Lookup("", "")
for l_37_7 = 0, 4 do
l_0_31(l_37_7, false)
end
end)
 -- DECOMPILER ERROR: Confused about usage of registers!

RegisterEvent("PARTY_DELETE_MEMBER", function(l_37_0)
-- upvalues: l_0_1 , l_0_31
local l_37_1 = Station.Lookup("Normal/Teammate")
if not l_37_1 then
return 
end
do
if l_37_0 == "PARTY_DELETE_MEMBER" then
  local l_37_2 = l_37_1:Lookup("", "")
end
if l_0_1().dwID ~= arg1 then
  return 
end
end
local l_37_3 = l_37_1:Lookup("", "")
for l_37_7 = 0, 4 do
l_0_31(l_37_7, false)
end
end)
RegisterEvent("PLAYER_DISPLAY_DATA_UPDATE", function()
-- upvalues: l_0_32
if PrettyShow.Options.TeamEnable == true then
local l_38_0 = Station.Lookup("Normal/Teammate")
end
if l_38_0 and l_38_0.bCreate then
l_0_32(arg0)
end
end)
local l_0_37 = function(l_22_0, l_22_1)
-- upvalues: l_0_27
local l_22_2 = l_0_27("%d", l_22_1)
local l_22_3 = l_0_27("%d", l_22_0)
local l_22_4 = l_0_27("%.1f%%", l_22_0 * 100 / l_22_1)
if PrettyShow.Options.nActHealth == 2 then
if l_22_1 > 100000 then
  l_22_2 = l_0_27("%.1f��", l_22_1 / 10000)
end
if l_22_0 > 100000 then
  l_22_3 = l_0_27("%.1f��", l_22_0 / 10000)
end
else
if PrettyShow.Options.nActHealth == 3 then
  if l_22_1 > 100000 then
    l_22_2 = l_0_27("%.1fW", l_22_1 / 10000)
  end
end
end
if l_22_0 > 100000 then
l_22_3 = l_0_27("%.1fW", l_22_0 / 10000)
end
if PrettyShow.Options.nHealthMode == 1 then
return l_22_3
end
if PrettyShow.Options.nHealthMode == 2 then
return l_22_3 .. "(" .. l_22_4 .. ")"
end
if PrettyShow.Options.nHealthMode == 3 then
return l_22_3, l_22_4
end
if PrettyShow.Options.nHealthMode == 4 then
return l_22_3 .. "/" .. l_22_2
end
if PrettyShow.Options.nHealthMode == 5 then
local l_22_8 = l_22_3
local l_22_9 = "/"
local l_22_10 = l_22_2
l_22_8 = l_22_8 .. l_22_9 .. l_22_10 .. "(" .. l_22_4 .. ")"
return l_22_8
end
if PrettyShow.Options.nHealthMode == 6 then
return l_22_3 .. "/" .. l_22_2, l_22_4
end
if PrettyShow.Options.nHealthMode == 7 then
if l_22_0 - l_22_1 < 0 then
  local l_22_5 = l_0_27
  local l_22_6 = "%d"
  local l_22_7 = l_22_0 - l_22_1
  return l_22_5(l_22_6, l_22_7)
end
else
return ""
end
end
RegisterEvent("HEALTH_MODE_RESET", function()
-- upvalues: l_0_10
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_43_0 = Station.Lookup("Normal/Teammate")
if l_43_0 then
local l_43_1 = l_43_0:Lookup("", "")
local l_43_2 = l_43_1:GetItemCount()
for l_43_6 = 0, l_43_2 - 1 do
  local l_43_7 = l_43_1:Lookup(l_43_6)
  if PrettyShow.Options.nMode == 1 then
    l_43_7:Lookup("Shadow_Health"):Hide()
    l_43_7:Lookup("Shadow_Mana"):Hide()
    l_43_7:Lookup("Image_Health"):Show()
    l_43_7:Lookup("Image_Mana"):Show()
    local l_43_8 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nHealthBar]
    if l_43_8 then
      l_43_7:Lookup("Image_Health"):FromUITex(l_43_8[1], l_43_8[2])
    end
    local l_43_9 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nManaBar]
    if l_43_9 then
      l_43_7:Lookup("Image_Mana"):FromUITex(l_43_9[1], l_43_9[2])
    end
  else
    if PrettyShow.Options.nMode == 2 then
      l_43_7:Lookup("Image_Health"):Hide()
      l_43_7:Lookup("Image_Mana"):Hide()
      local l_43_10 = PrettyShow.Options.tHealthColor[1]
      l_43_7:Lookup("Shadow_Health"):SetColorRGB(l_43_10[1], l_43_10[2], l_43_10[3])
      local l_43_11 = PrettyShow.Options.tHealthColor[2]
      l_43_7:Lookup("Shadow_Mana"):SetColorRGB(l_43_11[1], l_43_11[2], l_43_11[3])
      l_43_7:Lookup("Shadow_Health"):Show()
      l_43_7:Lookup("Shadow_Mana"):Show()
    end
  else
    if PrettyShow.Options.nMode == 3 then
      l_43_7:Lookup("Image_Health"):Hide()
      l_43_7:Lookup("Image_Mana"):Hide()
      l_43_7:Lookup("Shadow_Health"):Show()
      l_43_7:Lookup("Shadow_Mana"):Show()
      local l_43_12 = l_0_10()
      local l_43_13 = l_43_12.GetMemberInfo(l_43_7.dwID)
      if not PrettyShow.Options.tForceColor[l_43_13.dwForceID] then
        local l_43_14, l_43_15, l_43_16, l_43_17, l_43_18 = {}
        l_43_15 = 0
        l_43_16 = 255
        l_43_17 = 0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_43_7:Lookup("Shadow_Health"):SetColorRGB(l_43_14[1], l_43_14[2], l_43_14[3])
      local l_43_19 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_43_7:Lookup("Shadow_Mana"):SetColorRGB(PrettyShow.Options.tHealthColor[2][1], PrettyShow.Options.tHealthColor[2][2], PrettyShow.Options.tHealthColor[2][3])
    end
  else
    l_43_7:Lookup("Shadow_Health"):Show()
    l_43_7:Lookup("Shadow_Mana"):Show()
    l_43_7:Lookup("Image_Health"):Hide()
    l_43_7:Lookup("Image_Mana"):Hide()
    local l_43_20 = PrettyShow.Options.tHealthColor[2]
    l_43_7:Lookup("Shadow_Mana"):SetColorRGB(l_43_20[1], l_43_20[2], l_43_20[3])
  end
  local l_43_21 = l_43_7:Lookup("Text_Health")
  local l_43_22 = l_43_7:Lookup("Text_Mana")
  local l_43_23 = l_43_7:Lookup("Text_HealthPer")
  local l_43_24 = l_43_7:Lookup("Text_ManaPer")
  if PrettyShow.Options.nHealthMode == 1 then
    l_43_21:SetHAlign(1)
    l_43_22:SetHAlign(1)
  else
    if PrettyShow.Options.nHealthMode == 2 then
      l_43_21:SetHAlign(1)
      l_43_22:SetHAlign(1)
    end
  else
    if PrettyShow.Options.nHealthMode == 3 then
      l_43_21:SetHAlign(0)
      l_43_22:SetHAlign(0)
    end
  else
    if PrettyShow.Options.nHealthMode == 4 then
      l_43_21:SetHAlign(1)
      l_43_22:SetHAlign(1)
    end
  else
    if PrettyShow.Options.nHealthMode == 5 then
      l_43_21:SetHAlign(1)
      l_43_22:SetHAlign(1)
    end
  else
    if PrettyShow.Options.nHealthMode == 6 then
      l_43_21:SetHAlign(0)
      l_43_22:SetHAlign(0)
    end
  else
    if PrettyShow.Options.nHealthMode == 7 then
      l_43_21:SetHAlign(2)
      l_43_22:SetHAlign(2)
    end
  end
  local l_43_25 = PrettyShow.Options.tHealth[1]
  local l_43_26 = PrettyShow.Options.tHealth[2]
  l_43_21:SetFontScheme(l_43_25)
  l_43_21:SetFontColor(l_43_26[1], l_43_26[2], l_43_26[2])
  l_43_23:SetFontScheme(l_43_25)
  l_43_23:SetFontColor(l_43_26[1], l_43_26[2], l_43_26[2])
  l_43_22:SetFontScheme(l_43_25)
  l_43_22:SetFontColor(l_43_26[1], l_43_26[2], l_43_26[2])
  l_43_24:SetFontScheme(l_43_25)
  l_43_24:SetFontColor(l_43_26[1], l_43_26[2], l_43_26[2])
  TeammateHook.UpdateMemberHFData(l_43_7)
end
end
end)
local l_0_41 = function(l_24_0)
if l_24_0 <= 0 or l_24_0 >= 1 then
return 0.09, 0.7, 0.03
end
if l_24_0 >= 0.5 then
return (1 - l_24_0) * 2, 0.7, 0
else
return 1, l_24_0 * 2, 0
end
end
RegisterEvent("BUFF_RESET", function()
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_44_0 = Station.Lookup("Normal/Teammate")
if l_44_0 then
TeammateHook.BuffPosUpdate(l_44_0)
local l_44_1 = l_44_0:Lookup("", "")
local l_44_2 = l_44_1:GetItemCount()
for l_44_6 = 0, l_44_2 - 1 do
  local l_44_7 = l_44_1:Lookup(l_44_6)
  TeammateHook.RefreshBuff(l_44_7)
  if PrettyShow.Options.ShowTeamBuff == true then
    l_44_7:Lookup("Handle_Buff"):Show()
    l_44_7:Lookup("Handle_Debuff"):Show()
  else
    l_44_7:Lookup("Handle_Buff"):Hide()
    l_44_7:Lookup("Handle_Debuff"):Hide()
  end
end
end
end)
local l_0_42 = nil
RegisterEvent("HEAD_ALPHA_RESET", function()
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_45_0 = Station.Lookup("Normal/Teammate")
if l_45_0 then
local l_45_1 = l_45_0:Lookup("", "")
local l_45_2 = l_45_1:GetItemCount()
for l_45_6 = 0, l_45_2 - 1 do
  local l_45_7 = l_45_1:Lookup(l_45_6)
  local l_45_8 = l_45_7:Lookup("Image_BgMidC")
  if l_45_8 then
    l_45_8:SetAlpha(PrettyShow.Options.Bg)
  end
end
end
end)
local l_0_43 = nil
RegisterEvent("CASTER_STYLE_RESET", function()
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_46_0 = Station.Lookup("Normal/Teammate")
if l_46_0 then
local l_46_1 = l_46_0:Lookup("", "")
local l_46_2 = l_46_1:GetItemCount()
for l_46_6 = 0, l_46_2 - 1 do
  local l_46_7 = l_46_1:Lookup(l_46_6)
  local l_46_8 = l_46_7:Lookup("Image_Progress")
  local l_46_9 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nCaster]
  if l_46_8 and l_46_9 then
    l_46_8:FromUITex(l_46_9[1], l_46_9[2])
  end
  local l_46_10 = PrettyShow.Options.tCasterText[1]
  local l_46_11 = PrettyShow.Options.tCasterText[2]
  if l_46_10 and l_46_11 then
    local l_46_12 = l_46_7:Lookup("Text_SkillName")
    l_46_12:SetFontScheme(l_46_10)
    l_46_12:SetFontColor(l_46_11[1], l_46_11[2], l_46_11[3])
  end
end
end
end)
local l_0_44 = function(l_40_0, l_40_1)
for l_40_5,l_40_6 in pairs(l_40_1) do
if type(l_40_6) == "function" then
  l_40_0[l_40_5] = l_40_6
end
end
end
RegisterEvent("BGFRAME_RESET", function()
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_47_0 = Station.Lookup("Normal/Teammate")
if l_47_0 then
local l_47_1 = l_47_0:Lookup("", "")
local l_47_2 = l_47_1:GetItemCount()
for l_47_6 = 0, l_47_2 - 1 do
  local l_47_7 = l_47_1:Lookup(l_47_6)
  local l_47_8 = l_47_7:Lookup("Image_Frame")
  if PrettyShow.Options.bShowFrame then
    l_47_8:Show()
  else
    l_47_8:Hide()
  end
end
 -- WARNING: missing end command somewhere! Added here
end
end)
local l_0_46 = function()
-- upvalues: l_0_37
if not TeammateBak then
TeammateBak = {}
l_0_37(TeammateBak, Teammate)
end
l_0_37(Teammate, TeammateHook)
end
RegisterEvent("CUSTOM_UI_MODE_SET_DEFAULT", TeammateHook_SetAnchorDefault)
RegisterEvent("TEAM_ENABLE", function()
-- upvalues: l_0_38 , l_0_40 , l_0_41 , l_0_43 , l_0_44 , l_0_42 , l_0_39
local l_48_0 = IsTeammateOpened()
Wnd.CloseWindow("Teammate")
local l_48_1 = nil
if PrettyShow.Options.TeamEnable == true then
l_0_38()
l_48_1 = Wnd.OpenWindow("Interface\\PrettyShow\\TeamShow.ini", "Teammate")
if l_48_1 then
  TeammateHook.Update(l_48_1)
  l_0_40()
  l_48_1:Scale(PrettyShow.Options.nScale_Team, PrettyShow.Options.nScale_Team)
  TeammateHook.UpdateAnchor(l_48_1)
  l_0_41()
  l_0_43()
  l_0_44()
  l_0_42()
end
if l_48_0 ~= true then
  l_48_1:Hide()
end
else
l_0_39()
l_48_1 = Wnd.OpenWindow("Teammate")
end
if l_48_0 ~= true then
l_48_1:Hide()
end
end)
RegisterEvent("SYNC_ROLE_DATA_END", function()
-- upvalues: l_0_46 , l_0_45
if l_0_46 == false then
l_0_45()
l_0_46 = true
end
end)
RegisterEvent("FRAME_SIZE_RESET", function()
-- upvalues: l_0_45
if arg0 ~= "Team" then
return 
end
if PrettyShow.Options.TeamEnable == false then
return 
end
l_0_45()
end)
local l_0_49 = function()
-- upvalues: l_0_37
if TeammateBak then
l_0_37(Teammate, TeammateBak)
end
end
RegisterEvent("FORCE_RESET", function()
if PrettyShow.Options.TeamEnable ~= true then
return 
end
local l_52_0 = Station.Lookup("Normal/Teammate")
if l_52_0 then
local l_52_1 = l_52_0:Lookup("", "")
local l_52_2 = l_52_1:GetItemCount()
for l_52_6 = 0, l_52_2 - 1 do
  local l_52_7 = l_52_1:Lookup(l_52_6)
  TeammateHook.UpdateMemberLFData(l_52_7)
end
end
end)
do
RegisterEvent("PARTY_ADD_MEMBER", function()
-- upvalues: l_0_1 , l_0_45
if PrettyShow.Options.TeamEnable == false then
return 
end
local l_53_0 = l_0_1()
if not l_53_0 then
return false
end
if not TeammateHook.IsInMyGroup(arg1) then
return false
end
local l_53_1 = Station.Lookup("Normal/Teammate")
if l_53_1 then
l_0_45()
end
end)
 -- DECOMPILER ERROR: Confused about usage of registers!

RegisterEvent("PARTY_SYNC_MEMBER_DATA", function()
-- upvalues: l_0_1 , l_0_45
if PrettyShow.Options.TeamEnable == false then
return 
end
local l_53_0 = l_0_1()
if not l_53_0 then
return false
end
if not TeammateHook.IsInMyGroup(arg1) then
return false
end
local l_53_1 = Station.Lookup("Normal/Teammate")
if l_53_1 then
l_0_45()
end
end)
RegisterEvent("TEAM_CHANGE_MEMBER_GROUP", function()
-- upvalues: l_0_1 , l_0_10 , l_0_45
if PrettyShow.Options.TeamEnable == false then
return 
end
local l_54_0 = l_0_1()
local l_54_1 = l_0_10()
local l_54_2 = l_54_1.GetMemberGroupIndex(l_54_0.dwID)
if l_54_2 == arg1 or l_54_2 == arg2 then
local l_54_3 = Station.Lookup("Normal/Teammate")
end
if l_54_3 then
l_0_45()
end
end)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

