-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: PrettyShowOption.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
if not ChenYuOption then
  ChenYuOption = {}
end
PrettyShow = {}
PrettyShow.Options = {}
PrettyShow.Options.PlayerEnable = true
PrettyShow.Options.TeamEnable = true
PrettyShow.Options.TargetEnable = true
PrettyShow.Options.FocusEnable = true
PrettyShow.Options.AddSelf = true
PrettyShow.Options.Bg = 140
PrettyShow.Options.bShowFrame = true
PrettyShow.Options.bFocusIcon = true
PrettyShow.Options.ShowDamage_Target = true
PrettyShow.Options.ShowDamage_FromPlayer = true
PrettyShow.Options.ShowDamage_FromTeam = false
PrettyShow.Options.ShowDamage_FromOthers = false
PrettyShow.Options.ShowTeamBuff = true
PrettyShow.Options.ShowTargetBuff = true
PrettyShow.Options.ShowTTBuff = true
PrettyShow.Options.ShowFocusBuff = true
PrettyShow.Options.nSize = 40
PrettyShow.Options.nCol = 8
PrettyShow.Options.bCool = true
PrettyShow.Options.bText = true
PrettyShow.Options.bCool_Own = true
PrettyShow.Options.bCool_Dir = true
PrettyShow.Options.bOwnOnly = false
PrettyShow.Options.bCoolTeam = false
PrettyShow.Options.bTextTeam = true
PrettyShow.Options.bCoolTeam_Own = false
PrettyShow.Options.bCoolTeam_Dir = true
PrettyShow.Options.bOwnOnly_TeamBuff = false
PrettyShow.Options.TeamBuffLeft = 1
PrettyShow.Options.nFilters = {}
PrettyShow.Options.TargetFilter = true
PrettyShow.Options.TargetTargetFilter = true
PrettyShow.Options.TeamFilter = true
PrettyShow.Options.FocusFilter = true
local l_0_27 = PrettyShow.Options
local l_0_28 = {}
local l_0_29 = 162
local l_0_30 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_30 = {255, 255, 255}
l_0_27.tHealth, l_0_28 = l_0_28, {l_0_29, l_0_30}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nHealthBar = 14
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nManaBar = 18
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nActHealth = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nScale = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nScale_TargetTarget = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nScale_Player = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nScale_Team = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nScale_Focus = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.BuffPos = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.DebuffPos = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.ForceHigh = false
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.FocusFlash = false
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27.nMode = 1
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_30 = 0
l_0_30, l_0_29 = {0, 128, 255}, {l_0_30, 255, 0}
l_0_27.tHealthColor, l_0_28 = l_0_28, {l_0_29, l_0_30}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_30 = 171
l_0_29 = {l_0_30, 212, 115}
l_0_30 = 245
l_0_29 = {l_0_30, 140, 186}
l_0_30 = 36
l_0_29 = {l_0_30, 89, 255}
l_0_30 = 199
l_0_29 = {l_0_30, 156, 110}
l_0_30 = 105
l_0_29 = {l_0_30, 204, 240}
l_0_30 = 255
l_0_29 = {l_0_30, 125, 10}
l_0_30 = 148
l_0_29 = {l_0_30, 130, 202}
l_0_30 = 255
l_0_29 = {l_0_30, 245, 105}
l_0_30 = 34
l_0_29 = {l_0_30, 177, 76}
l_0_27.tForceColor, l_0_28 = l_0_28, {[0] = l_0_29, [1] = l_0_29, [2] = l_0_29, [3] = l_0_29, [4] = l_0_29, [5] = l_0_29, [6] = l_0_29, [8] = l_0_29, [999] = l_0_29}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_28 = g_tStrings
l_0_28 = l_0_28.tForceTitle
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_27[999] = "NPC"
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bShowFrame"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bFocusIcon"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ForceHigh"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nMode"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.tHealthColor"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.tForceColor"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.Bg"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.PlayerEnable"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TeamEnable"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TargetEnable"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.FocusEnable"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.AddSelf"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowDamage_Target"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowDamage_FromPlayer"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowDamage_FromTeam"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowDamage_FromOthers"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowFocusBuff"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowTeamBuff"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowTargetBuff"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nSize"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nCol"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.ShowTTBuff"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCool"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bText"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCool_Own"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCool_Dir"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bOwnOnly"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCoolTeam"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bTextTeam"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCoolTeam_Own"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bCoolTeam_Dir"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.bOwnOnly_TeamBuff"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TeamBuffLeft"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nFilters"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TargetFilter"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TargetTargetFilter"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TeamFilter"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.FocusFilter"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.tCasterText"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.CasterBg"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TargetCaster"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TargetTargetCaster"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.TeamCaster"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.FocusCaster"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nCaster"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nActHealth"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nHealthMode"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.tHealth"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nHealthBar"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nManaBar"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nScale"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nScale_TargetTarget"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nScale_Player"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nScale_Team"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.nScale_Focus"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.BuffPos"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.DebuffPos"
l_0_28(l_0_29)
l_0_28 = RegisterCustomData
l_0_29 = "PrettyShow.Options.FocusFlash"
l_0_28(l_0_29)
l_0_28 = PrettyShow
l_0_28 = l_0_28.Options
local l_0_31 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_32 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_33 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_34 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_35 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_36 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_37 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_38 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_39 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_40 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_41 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_42 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_43 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_44 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_45 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_46 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_47 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_48 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_49 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_50 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_51 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_52 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_53 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_54 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_55 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_56 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_57 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_58 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_59 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_60 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_61 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_62 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_63 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_31(l_0_32, l_0_33)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

Pretty_CriticalScale, l_0_31 = l_0_31, {l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_57, l_0_58, l_0_59, l_0_60, l_0_61, l_0_62, l_0_63, 86, 87, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45}
l_0_31 = 4
P_COMBAT_TEXT_FADE_IN_FRAME = l_0_31
l_0_31 = 20
P_COMBAT_TEXT_HOLD_FRAME = l_0_31
l_0_31 = 8
P_COMBAT_TEXT_FADE_OUT_FRAME = l_0_31
l_0_31 = OutputMessage
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_31(l_0_32, l_0_33)

