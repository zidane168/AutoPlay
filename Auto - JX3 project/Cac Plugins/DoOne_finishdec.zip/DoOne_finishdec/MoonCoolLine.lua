-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: MoonCoolLine.lua 

local l_0_0 = {}
RegisterEvent("SYNC_ROLE_DATA_END", function(l_1_0, l_1_1)
  -- upvalues: l_0_0
  local l_1_2 = GetClientPlayer()
  if not l_1_2 then
    return 
  end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_1_0 and l_1_1 and l_1_1 > 0 and Table_IsSkillShow(l_1_0, l_1_1) then
    local l_1_3 = Table_GetSkillName(l_1_0, l_1_1)
  end
  if l_1_3 then
    l_0_0[l_1_3] = l_1_0
  end
  return 
  if not l_1_2.GetAllSkillList() then
    local l_1_4, l_1_5 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_1_9,l_1_10 in pairs(l_1_4) do
    local l_1_6 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if Table_IsSkillShow(l_1_10, R8_PC37) and Table_GetSkillName(l_1_10, R8_PC37) then
      l_0_0[Table_GetSkillName(l_1_10, R8_PC37)] = l_1_10
    end
  end
end
)
RegisterEvent("SKILL_UPDATE", function()
  -- upvalues: l_0_1
  l_0_1(arg0, arg1)
end
)
local l_0_2 = nil
local l_0_3 = {}
l_0_3.DefaultAnchor = {s = "BOTTOMCENTER", r = "BOTTOMCENTER", x = 35, y = -220}
l_0_3.Anchor = {s = "BOTTOMCENTER", r = "BOTTOMCENTER", x = 35, y = -220}
local l_0_4 = {}
local l_0_5 = {nTime = 1000, sText = "1", szOption = "1 s"}
local l_0_6 = {nTime = 10000, sText = "10", szOption = "10 s"}
local l_0_7 = {nTime = 30000, sText = "30", szOption = "30 s"}
local l_0_8 = {nTime = 60000, sText = "60", szOption = "60 s"}
do
  local l_0_9 = {nTime = 120000, sText = "2m", szOption = "2 m"}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_0_3.Marks = l_0_4
  l_0_3.bOn = false
  l_0_3.bBoxTimer = true
  l_0_3.nRemainTime = 700
  l_0_3.n_BoxSize = 35
  l_0_3.time_compression = 0.4
  l_0_3.nTimeMax = 60000
  l_0_3.nLastScale = 2.8
  l_0_3.nLastTime = 1000
  l_0_3.Width = 800
  Moon_CoolLine = l_0_3
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.bOn"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.nRemainTime"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.time_compression"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.nTimeMax"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.nLastTime"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.bBoxTimer"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.Anchor"
  l_0_3(l_0_4)
  l_0_3 = RegisterCustomData
  l_0_4 = "Moon_CoolLine.n_BoxSize"
  l_0_3(l_0_4)
  l_0_4, l_0_3 = nil
  l_0_5 = Moon_CoolLine
  l_0_6 = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("MOON_COOLLINE_ANCHOR_CHANGED")
end

  l_0_5.OnFrameCreate = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function()
  -- upvalues: l_0_0
  local l_4_0 = GetClientPlayer()
  if not l_4_0 then
    return 
  end
  for l_4_4,l_4_5 in pairs(l_0_0) do
    local l_4_6 = l_4_0.GetSkillLevel(l_4_5)
    local l_4_7, l_4_8, l_4_9 = l_4_0.GetSkillCDProgress(l_4_5, l_4_6)
    if l_4_8 > 24 and l_4_9 ~= 40 and l_4_8 < Moon_CoolLine.nTimeMax * 16 / 1000 then
      Moon_CoolLine.UpdataSkillCDProgress(l_4_5, dwSkillLevel, l_4_8)
    end
  end
end

  l_0_5.OnFrameBreathe = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function()
  local l_5_0 = GetClientPlayer()
  if not l_5_0 then
    return 
  end
  local l_5_1 = GetTime()
  local l_5_2 = Station.Lookup("Normal/Moon_CoolLine")
  local l_5_3 = l_5_2:Lookup("", "Handle_SkillIcons")
  local l_5_4 = l_5_3:GetItemCount() - 1
  if l_5_4 > -1 then
    box_handle = l_5_3:Lookup(l_5_4)
    if box_handle.g_nEndTime + Moon_CoolLine.nRemainTime < l_5_1 and not l_5_0.GetSkillCDProgress(box_handle.dwSkillID, box_handle.dwSkillLevel) then
      Moon_CoolLine.RemoveIconAndBar(l_5_4)
    else
      Moon_CoolLine.UpdateBoxInfo(box_handle, l_5_1, box_handle.g_nEndTime)
    end
    l_5_4 = l_5_4 - 1
  end
end
l_5_3:FormatAllItemPos()
end

  l_0_5.OnFrameRender = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_6_0)
  local l_6_1 = Station.Lookup("Normal/Moon_CoolLine")
  local l_6_2 = l_6_1:Lookup("", "Handle_SkillIcons")
  l_6_2:RemoveItem(l_6_0)
end

  l_0_5.RemoveIconAndBar = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_7_0, l_7_1, l_7_2)
  local l_7_3 = l_7_2 - l_7_1
  local l_7_4 = 0
  local l_7_5 = 0
  local l_7_6 = 1
  l_7_4 = Moon_CoolLine.GetPos(l_7_3)
  l_7_6 = Moon_CoolLine.GetRelSize(l_7_3)
  l_7_4 = l_7_4 - (l_7_6 - 1) * Moon_CoolLine.n_BoxSize / 2
  l_7_5 = l_7_5 - (l_7_6 - 1) * Moon_CoolLine.n_BoxSize / 2
  l_7_0:Lookup(0):SetSize(Moon_CoolLine.n_BoxSize * l_7_6, Moon_CoolLine.n_BoxSize * l_7_6)
  l_7_0:Lookup(1):SetSize(Moon_CoolLine.n_BoxSize * l_7_6, Moon_CoolLine.n_BoxSize * l_7_6)
  l_7_0:SetAlpha(Moon_CoolLine.GetAlpha(l_7_3))
  l_7_0:SetRelPos(l_7_4, l_7_5)
  local l_7_7 = l_7_0:Lookup(1)
  if Moon_CoolLine.bBoxTimer then
    if l_7_3 > 10000 then
      l_7_7:SetText(string.format("%0.0f", l_7_3 / 1000))
    elseif l_7_3 > 0 then
      l_7_7:SetText(string.format("%0.1f", l_7_3 / 1000))
    else
      l_7_7:SetText("")
    end
  else
    l_7_7:SetText("")
  end
end

  l_0_5.UpdateBoxInfo = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_8_0, l_8_1, l_8_2)
  -- upvalues: l_0_3
  l_0_3 = GetTime()
  local l_8_3 = Station.Lookup("Normal/Moon_CoolLine")
  local l_8_4 = l_8_3:Lookup("", "Handle_SkillIcons")
  local l_8_5 = 0
  if l_8_5 < l_8_4:GetItemCount() then
    if l_8_0 == l_8_4:Lookup(l_8_5).dwSkillID then
      return 
    end
    l_8_5 = l_8_5 + 1
  end
end
Moon_CoolLine.AppendNewSkill(l_8_0, l_8_1, l_0_3, l_0_3 + l_8_2 * 1000 / GLOBAL.GAME_FPS)
l_8_4:FormatAllItemPos()
end

  l_0_5.UpdataSkillCDProgress = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_9_0, l_9_1, l_9_2, l_9_3)
  local l_9_4 = Station.Lookup("Normal/Moon_CoolLine")
  local l_9_5 = l_9_4:Lookup("", "Handle_SkillIcons")
  l_9_5:AppendItemFromString("<handle>firstpostype=0 handletype=0 w=" .. Moon_CoolLine.n_BoxSize .. " h=" .. Moon_CoolLine.n_BoxSize .. " </handle>")
  local l_9_6 = l_9_5:GetItemCount() - 1
  local l_9_7 = l_9_5:Lookup(l_9_6)
  l_9_7:AppendItemFromString("<box>w=" .. Moon_CoolLine.n_BoxSize .. " h=" .. Moon_CoolLine.n_BoxSize .. " eventid=525311 lockshowhide=1</box>")
  l_9_7:AppendItemFromString("<text>w=" .. Moon_CoolLine.n_BoxSize .. " h=" .. Moon_CoolLine.n_BoxSize .. " halign=2 valign=2  lockshowhide=1</text>")
  local l_9_8 = l_9_7:Lookup(0)
  l_9_8:SetName("SkillBox")
  l_9_8:Show()
  local l_9_9 = l_9_7:Lookup(1)
  l_9_9:Show()
  l_9_9:SetName("Text")
  l_9_9:SetFontScheme(15)
  l_9_7.dwSkillID = l_9_0
  l_9_7.dwSkillLevel = l_9_1
  l_9_7.g_nStartTime = l_9_2
  l_9_7.g_nEndTime = l_9_3
  if l_9_6 > 0 then
    local l_9_10 = l_9_5:Lookup(l_9_6 - 1)
    local l_9_11 = l_9_5:Lookup(l_9_6)
  if l_9_11.g_nEndTime < l_9_10.g_nEndTime then
    end
  else
    local l_9_12 = l_9_10.g_nEndTime
    local l_9_13 = l_9_10.g_nStartTime
    local l_9_14 = l_9_10.dwSkillID
    local l_9_15 = l_9_10.dwSkillLevel
    l_9_10.g_nEndTime = l_9_11.g_nEndTime
    l_9_10.g_nStartTime = l_9_11.g_nStartTime
    l_9_10.dwSkillID = l_9_11.dwSkillID
    l_9_10.dwSkillLevel = l_9_11.dwSkillLevel
    l_9_11.g_nEndTime = l_9_12
    l_9_11.g_nStartTime = l_9_13
    l_9_11.dwSkillID = l_9_14
    l_9_11.dwSkillLevel = l_9_15
    l_9_6 = l_9_6 - 1
  end
else
  l_9_6 = l_9_5:GetItemCount() - 1
  if l_9_6 > -1 then
    l_9_7 = l_9_5:Lookup(l_9_6)
    l_9_8 = l_9_7:Lookup(0)
    l_9_8:SetObject(UI_OBJECT_SKILL, l_9_7.dwSkillID, l_9_7.dwSkillLevel)
    l_9_8:SetObjectIcon(Table_GetSkillIconID(l_9_7.dwSkillID, l_9_7.dwSkillLevel))
    l_9_6 = l_9_6 - 1
  end
end
-- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 68 
end

  l_0_5.AppendNewSkill = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_10_0)
  if l_10_0 == "UI_SCALED" or l_10_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    Moon_CoolLine.OnUpdateHeight()
    Moon_CoolLine.UpdateMarks(this)
    Moon_CoolLine.UpdateAnchor(this)
    if Moon_CoolLine.bOn then
      this:Show()
    else
      this:Hide()
    end
  elseif l_10_0 == "MOON_COOLLINE_ANCHOR_CHANGED" then
    Moon_CoolLine.UpdateAnchor(this)
  elseif l_10_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_10_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "������ȴ��", true)
  end
end

  l_0_5.OnEvent = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function()
  this:CorrectPos()
  Moon_CoolLine.Anchor = GetFrameAnchor(this)
end

  l_0_5.OnFrameDragEnd = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_12_0)
  local l_12_1 = Moon_CoolLine.Anchor
  l_12_0:SetPoint(l_12_1.s, 0, 0, l_12_1.r, l_12_1.x, l_12_1.y)
  l_12_0:CorrectPos()
end

  l_0_5.UpdateAnchor = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_13_0)
  if l_13_0 < 0 then
    return 0
  end
  return l_13_0 / Moon_CoolLine.nTimeMax ^ Moon_CoolLine.time_compression * (Moon_CoolLine.Width - 40)
end

  l_0_5.GetPos = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_14_0)
  if l_14_0 > 0 then
    return 255
  else
    return 255 * (Moon_CoolLine.nRemainTime + l_14_0) / Moon_CoolLine.nRemainTime
  end
end

  l_0_5.GetAlpha = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_15_0)
  if Moon_CoolLine.nLastTime < l_15_0 then
    return 1
  elseif l_15_0 > 0 then
    return Moon_CoolLine.nLastScale - (Moon_CoolLine.nLastScale - 1) * Moon_CoolLine.GetPos(l_15_0) / Moon_CoolLine.GetPos(Moon_CoolLine.nLastTime)
  else
    return Moon_CoolLine.nLastScale
  end
end

  l_0_5.GetRelSize = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_16_0)
  do
    local l_16_1 = l_16_0:Lookup("", ""):Lookup("Handle_BGText")
    if l_16_1:GetItemCount() ~= 0 then
      l_16_1:Clear()
    else
      for l_16_5 = 1, #Moon_CoolLine.Marks do
        if Moon_CoolLine.nTimeMax < Moon_CoolLine.Marks[l_16_5].nTime then
          do break end
        end
        l_16_1:AppendItemFromString("<text>w=" .. Moon_CoolLine.n_BoxSize .. " h=" .. Moon_CoolLine.n_BoxSize .. " halign=0 valign=1 lockshowhide=1</text>")
        local l_16_6 = l_16_1:Lookup(l_16_5 - 1)
        l_16_6:Show()
        l_16_6:SetName("Text_" .. l_16_5 - 1)
        l_16_6:SetText(Moon_CoolLine.Marks[l_16_5].sText)
        l_16_6:SetRelPos(Moon_CoolLine.GetPos(Moon_CoolLine.Marks[l_16_5].nTime), 1)
        l_16_6:SetFontScheme(19)
      end
      l_16_1:FormatAllItemPos()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 8 
end

  l_0_5.UpdateMarks = l_0_6
  l_0_5 = function()
  Moon_CoolLine.Anchor.s = Moon_CoolLine.DefaultAnchor.s
  Moon_CoolLine.Anchor.r = Moon_CoolLine.DefaultAnchor.r
  Moon_CoolLine.Anchor.x = Moon_CoolLine.DefaultAnchor.x
  Moon_CoolLine.Anchor.y = Moon_CoolLine.DefaultAnchor.y
  FireEvent("MOON_COOLLINE_ANCHOR_CHANGED")
end

  Moon_CoolLine_SetAnchorDefault = l_0_5
  l_0_5 = RegisterEvent
  l_0_6 = "CUSTOM_UI_MODE_SET_DEFAULT"
  l_0_7 = Moon_CoolLine_SetAnchorDefault
  l_0_5(l_0_6, l_0_7)
  l_0_5 = Wnd
  l_0_5 = l_0_5.OpenWindow
  l_0_6 = "interface\\Moon_CoolLine\\CoolLine.ini"
  l_0_7 = "Moon_CoolLine"
  l_0_5(l_0_6, l_0_7)
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_18_0)
  local l_18_1 = BoxCheckBox
  local l_18_2 = l_18_0
  local l_18_3 = "CheckBox_ShowCoolLine"
  local l_18_4 = {}
  l_18_4.txt = "����������ȴ����Shift+U��������λ�ã�"
  l_18_1 = l_18_1(l_18_2, l_18_3, l_18_4)
  l_18_2, l_18_3 = l_18_1:SetBoolValue, l_18_1
  l_18_4 = Moon_CoolLine
  l_18_2(l_18_3, l_18_4, "bOn")
  l_18_2, l_18_3 = l_18_1:OnCheck, l_18_1
  l_18_4 = function()
    Station.Lookup("Normal/Moon_CoolLine"):Show()
  end
  l_18_2(l_18_3, l_18_4)
  l_18_2, l_18_3 = l_18_1:UnCheck, l_18_1
  l_18_4 = function()
    Station.Lookup("Normal/Moon_CoolLine"):Hide()
  end
  l_18_2(l_18_3, l_18_4)
  l_18_2 = BoxBoolCheckBox
  l_18_3 = l_18_0
  l_18_4 = "CheckBox_ShowCoolLine"
  l_18_2 = l_18_2(l_18_3, l_18_4, "����ͼ���ʱ", Moon_CoolLine, "bBoxTimer")
  l_18_2, l_18_3 = l_18_2:SetRelPos, l_18_2
  l_18_4 = 0
  l_18_2(l_18_3, l_18_4, 30)
  l_18_2 = BoxComboBox
  l_18_3 = l_18_0
  l_18_4 = "ComboBox_CoolLineSet"
  local l_18_5 = {}
  l_18_5.txt = "��ȴ������"
  l_18_5.x = 0
  l_18_5.y = 60
  l_18_2 = l_18_2(l_18_3, l_18_4, l_18_5)
  l_18_2, l_18_3 = l_18_2:SetMenu, l_18_2
  l_18_4 = Moon_CoolLine
  l_18_4 = l_18_4.AddLayoutMenu
  l_18_2(l_18_3, l_18_4)
  l_18_2 = BoxComboBox
  l_18_3 = l_18_0
  l_18_4 = "ComboBox_CoolBoxSet"
  l_18_2, l_18_5 = l_18_2(l_18_3, l_18_4, l_18_5), {txt = "ͼ��Ч������", x = 0, y = 90}
  l_18_2, l_18_3 = l_18_2:SetMenu, l_18_2
  l_18_4 = Moon_CoolLine
  l_18_4 = l_18_4.AddBoxMenu
  l_18_2(l_18_3, l_18_4)
end

  l_0_5.Create = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_19_0)
  local l_19_1 = {}
  l_19_1.szOption = "���ʱ��"
  for l_19_5 = 2, #Moon_CoolLine.Marks do
    do
      local l_19_6 = {}
      l_19_6.szOption = Moon_CoolLine.Marks[l_19_5].szOption
      l_19_6.bMCheck = true
      l_19_6.bChecked = Moon_CoolLine.Marks[l_19_5].nTime == Moon_CoolLine.nTimeMax
      l_19_6.fnAction = function()
        -- upvalues: l_19_5
        Moon_CoolLine.nTimeMax = Moon_CoolLine.Marks[l_19_5].nTime
        Moon_CoolLine.UpdateMarks(Station.Lookup("Normal/Moon_CoolLine"))
      end
      table.insert(l_19_1, l_19_6)
    end
  end
  table.insert(l_19_0, l_19_1)
  local l_19_9 = {}
  do
    local l_19_10 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_19_11 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_19_12 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_19_13 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_19_14 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_19_15 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_19_14,l_19_15 in l_19_11 do
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_19_16 = 0.3
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_19_17 = 0.2
      local l_19_18 = {}
      l_19_18.szOption = l_19_16
      l_19_18.bMCheck = true
      l_19_18.bChecked = Moon_CoolLine.time_compression == l_19_17
      l_19_18.fnAction = function()
        -- upvalues: l_19_10
        Moon_CoolLine.time_compression = l_19_10
        Moon_CoolLine.UpdateMarks(Station.Lookup("Normal/Moon_CoolLine"))
      end
      table.insert(l_19_10, l_19_18)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_19_11.insert(l_19_12, l_19_10)
    do
      local l_19_21, l_19_31 = nil
      for l_19_25 = 30, 45, 5 do
        local l_19_22, l_19_23, l_19_24, l_19_25 = nil
        l_19_21 = table
        l_19_21 = l_19_21.insert
        local l_19_26 = nil
        l_19_31 = {szOption = "��ȴ���߶�"}
        local l_19_27 = nil
        local l_19_28 = nil
        l_19_23 = tostring
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_24 = l_19_15
        l_19_23 = l_19_23(l_19_24)
        l_19_23 = Moon_CoolLine
        l_19_23 = l_19_23.n_BoxSize
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_23 = l_19_23 == l_19_15
        l_19_23 = function()
        -- upvalues: l_19_8
        Moon_CoolLine.n_BoxSize = l_19_8
        Moon_CoolLine.OnUpdateHeight()
        Moon_CoolLine.UpdateMarks(Station.Lookup("Normal/Moon_CoolLine"))
      end
        l_19_21(l_19_31, l_19_22)
        l_19_22 = {szOption = l_19_23, bMCheck = true, bChecked = l_19_23, fnAction = l_19_23}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

    end
    table.insert(l_19_0, {szOption = "��ȴ���߶�"})
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

  l_0_5.AddLayoutMenu = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function()
  local l_20_0 = Moon_CoolLine.n_BoxSize
  local l_20_1 = Station.Lookup("Normal/Moon_CoolLine")
  local l_20_2 = l_20_1:Lookup("", "")
  local l_20_3 = 0
  local l_20_4 = 0
  l_20_3 = l_20_2:Lookup("Image_BG_L"):GetSize()
  l_20_2:Lookup("Image_BG_L"):SetSize(l_20_3, l_20_0 + 2)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_20_3 = l_20_2:Lookup("Image_BG_C"):GetSize()
  l_20_2:Lookup("Image_BG_C"):SetSize(l_20_3, l_20_0 + 2)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_20_3 = l_20_2:Lookup("Image_BG_R"):GetSize()
  l_20_2:Lookup("Image_BG_R"):SetSize(l_20_3, l_20_0 + 2)
end

  l_0_5.OnUpdateHeight = l_0_6
  l_0_5 = Moon_CoolLine
  l_0_6 = function(l_21_0)
  local l_21_1 = {}
  l_21_1.szOption = "���Ž���"
  local l_21_2 = {}
  local l_21_3 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_21_4 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_21_5 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_21_6 = {}
  do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_21_6,i_2 in l_21_3 do
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_21_8 = 1500.insert
      do
        local l_21_9 = l_21_1
        local l_21_10 = {}
        l_21_8(l_21_9, l_21_10)
      end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_21_3.insert(l_21_4, l_21_1)
    local l_21_13, l_21_25 = nil
    do
      local l_21_14, l_21_26 = nil
      local l_21_15 = nil
      local l_21_16 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_21_17 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      for l_21_25,l_21_14 in ipairs(R6_PC69) do
        local l_21_18, l_21_19 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_21_20 = nil
        local l_21_21 = nil
        local l_21_22 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_21_26(l_21_15, l_21_16)
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    table.insert(l_21_0, l_21_13)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

  l_0_5.AddBoxMenu = l_0_6
  l_0_5 = RegisterMoonButton
  l_0_6 = "CoolLine"
  l_0_7 = 1447
  l_0_8 = "������ȴ��"
  l_0_9 = "General"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_5(l_0_6, l_0_7, l_0_8, l_0_9, ({nTime = 300000, sText = "5m", szOption = "5 m"}).Create)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.


