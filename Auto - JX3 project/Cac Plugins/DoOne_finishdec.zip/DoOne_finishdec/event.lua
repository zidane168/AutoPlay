-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: event.lua 

Gkp.GetSelNumForAccounts = function()
  local l_1_0 = nil
  local l_1_1 = nil
  local l_1_2 = nil
  if Gkp.PageAcccount:Lookup("", "Handle_List1"):GetItemCount() > 0 then
    for l_1_6 = 0, Gkp.PageAcccount:Lookup("", "Handle_List1"):GetItemCount() - 1 do
      local l_1_3 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_1_2:Lookup(R7_PC15) and l_1_2:Lookup(R7_PC15).bSel then
        l_1_0 = tonumber(l_1_2:Lookup(R7_PC15):GetName())
      end
    end
  end
  return l_1_0
end

Gkp.OnLButtonClick = function()
  local l_2_0 = GetClientPlayer()
  local l_2_1 = this:GetName()
  local l_2_2 = Station.Lookup("Normal/Gkp")
  local l_2_3 = Station.Lookup("Normal/GkpAccountPanel")
  if l_2_1 == "Btn_AddAccount" and not l_2_3 then
    if not l_2_0.IsInParty() then
      MsgBox("�㲻�ڶ�����Ŷ��У�")
      return 
    end
    if not Gkp.bActive then
      MsgBox("���ȿ�ʼ���")
      return 
    end
    Gkp.Account("add")
  end
  do return end
  if l_2_1 == "Btn_ChangeAccount" and not l_2_3 then
    local l_2_4 = Gkp.GetSelNumForAccounts()
    do
    end
    if l_2_4 then
      Gkp.Account("change", l_2_4)
    end
  end
  do return end
  if l_2_1 == "Btn_DelAccount" then
    local l_2_5 = Gkp.GetSelNumForAccounts()
    if l_2_5 then
      table.remove(Gkp.Accounts, l_2_5)
      Gkp.UpdateAccount()
      Gkp.UpdateScroll("account")
    end
  elseif l_2_1 == "Btn_Close" then
    l_2_2:Hide()
  elseif l_2_1 == "Btn_Balance" then
    if not Gkp.bActive then
      MsgBox("���ȿ�ʼ���")
      return 
    end
    Gkp.RefreshWage()
  elseif l_2_1 == "Btn_Clear" then
    Gkp.ClearData()
  elseif l_2_1 == "Btn_Active" then
    local l_2_6 = this:Lookup("", "Text_Btn")
    if not Gkp.bActive then
      if not l_2_0.IsInParty() then
        MsgBox("�㲻�ڶ�����Ŷ��У��޷���ʼ���")
        return 
      end
      if #Gkp.Accounts > 0 or #Gkp.WageData > 0 then
        Gkp.ClearData()
      end
      Gkp.bActive = true
      l_2_6:SetText("�����")
    else
      MsgBox("�Ƿ�������������󣬲��ᴥ����Ʒ��¼��", function()
      -- upvalues: l_2_4
      Gkp.bActive = false
      l_2_4:SetText("��ʼ�")
    end)
    end
  elseif l_2_1 == "Btn_SayAccount" then
    Gkp.SayAccount()
  elseif l_2_1 == "Btn_SayWage" then
    Gkp.SayWage()
  end
end

Gkp.OnMouseEnter = function()
  local l_3_0 = this:GetName()
  local l_3_1, l_3_2 = this:GetAbsPos()
  local l_3_3, l_3_4 = this:GetSize()
  local l_3_5 = ""
  if l_3_0 == "Btn_Clear" then
    l_3_5 = "��յ�ǰ�����"
  elseif l_3_0 == "Btn_Active" then
    local l_3_6 = this:Lookup("", "Text_Btn")
    local l_3_7 = l_3_6:GetText()
    if l_3_7 == "��ʼ�" then
      l_3_5 = "��ʼ�»�����Զ����֮ǰ������\n���ҿ��Դ�����Ʒ��¼"
    elseif l_3_7 == "�����" then
      l_3_5 = "������ǰ�"
    end
  elseif l_3_0 == "Btn_AddAccount" then
    l_3_5 = "������Ʒ��������Ǯ����ϯ������"
  elseif l_3_0 == "Btn_ChangeAccount" then
    l_3_5 = "�޸ĵ�ǰ��ѡ"
  elseif l_3_0 == "Btn_DelAccount" then
    l_3_5 = "ɾ����ǰ��ѡ"
  elseif l_3_0 == "Btn_SayAccount" then
    l_3_5 = "����������Ϣ"
  elseif l_3_0 == "Btn_SayWage" then
    l_3_5 = "������������"
  elseif l_3_0 == "Btn_Balance" then
    l_3_5 = "��������ʷ���\n��Ŀ�б仯ʱ����Ҫ���½���"
  end
  if l_3_5 ~= "" then
    local l_3_8 = OutputTip
    local l_3_9 = GetFormatText(l_3_5)
    local l_3_10 = 400
    local l_3_11 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_3_8(l_3_9, l_3_10, l_3_11)
  end
   -- WARNING: undefined locals caused missing assignments!
end

Gkp.OnMouseLeave = function()
  HideTip()
end

Gkp.ClearData = function()
  Gkp.WageData = {}
  Gkp.CountMoney = 0
  Gkp.CountDuoyu = 0
  Gkp.MemberCount = 0
  Gkp.tBili = {}
  Gkp.Accounts = {}
  Gkp.UpdateAccount()
  Gkp.UpdateScroll("account")
  Gkp.UpdateWage()
  Gkp.UpdateScroll("wage")
end

Gkp.Account = function(l_6_0, l_6_1)
  local l_6_2 = "GkpAccountPanel" .. Gkp.frameName
  local l_6_3 = BoxSetFrame
  local l_6_4 = l_6_2
  local l_6_5 = {}
  l_6_5.bdrag = true
  l_6_5.w = 380
  l_6_5.h = 370
  l_6_3 = l_6_3(l_6_4, l_6_5)
  l_6_4, l_6_5 = l_6_3:Center, l_6_3
  l_6_4(l_6_5)
  l_6_4 = l_6_3.frame
  l_6_5 = l_6_3.handle
  local l_6_6 = BoxLabel
  local l_6_7 = l_6_5
  local l_6_8 = "Text_Title"
  local l_6_9 = "���Ӽ�¼"
  local l_6_10 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_6_11 = 0
  local l_6_12 = {}
  l_6_12.nW = 380
  l_6_12.nH = 30
  l_6_12.nHAlign = 1
  l_6_6 = l_6_6(l_6_7, l_6_8, l_6_9, l_6_10, l_6_11, l_6_12)
  if l_6_0 == "change" then
    l_6_7, l_6_8 = l_6_6:SetText, l_6_6
    l_6_9 = "�޸ļ�¼"
    l_6_7(l_6_8, l_6_9)
  end
  l_6_7 = BoxLabel
  l_6_8 = l_6_5
  l_6_9 = "Text_Name"
  l_6_10 = "������"
  l_6_12 = 0
  l_6_12 = nil
  local l_6_13 = {}
  l_6_13.nW = 120
  l_6_13.nH = 30
  l_6_13.nHAlign = 1
  l_6_7(l_6_8, l_6_9, l_6_10, l_6_11, l_6_12, l_6_13)
  l_6_11 = {l_6_12, 50}
  l_6_7 = BoxEdit
  l_6_8 = l_6_4
  l_6_9 = "Edit_Name"
  l_6_7, l_6_10 = l_6_7(l_6_8, l_6_9, l_6_10), {x = 95, y = 50, w = 150, h = 25}
  l_6_8 = BoxImage
  l_6_9 = l_6_5
  l_6_10 = "Image_Name"
  l_6_11 = "ui/image/button/commonbutton_1.uitex"
  l_6_12 = 8
  local l_6_14 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_6_15 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_9(l_6_10, l_6_11, l_6_12, l_6_13, l_6_14, l_6_15)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_9(l_6_10, l_6_11, l_6_12, l_6_13, l_6_14, l_6_15)
  l_6_15, l_6_14 = {30, 30}, {l_6_15, 30}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = {x = 95, y = 90}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = 0
  l_6_10(l_6_11, l_6_12)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = "Text_Type"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_15 = 15
  l_6_15 = nil
  local l_6_16 = {}
  l_6_16.nW = 120
  l_6_16.nH = 30
  l_6_16.nHAlign = 1
  l_6_10(l_6_11, l_6_12, l_6_13, l_6_14, l_6_15, l_6_16)
  l_6_14 = {l_6_15, 130}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = "Image_TypeBg"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = 48
  l_6_16 = 50
  local l_6_17 = {}
  l_6_17.nType = 10
  l_6_10(l_6_11, l_6_12, l_6_13, l_6_14, l_6_15, l_6_16, l_6_17)
  l_6_16, l_6_15 = {270, 45}, {l_6_16, 160}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = BoxRadioBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = "RadioBox_Type1"
  l_6_16 = l_6_11
  l_6_17 = "xiaofei"
  l_6_16 = l_6_16(l_6_17)
  l_6_12, l_6_15 = l_6_12(l_6_13, l_6_14, l_6_15), {group = "type", x = 60, y = 170, txt = "��Ʒ", bchecked = l_6_16}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = l_6_12:OnCheck
  l_6_14 = function()
    -- upvalues: l_6_10
    l_6_10 = "xiaofei"
  end
  l_6_12(l_6_13, l_6_14)
  l_6_12 = BoxRadioBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = "RadioBox_Type2"
  l_6_16 = l_6_11
  l_6_17 = "buzhu"
  l_6_16 = l_6_16(l_6_17)
  l_6_12, l_6_15 = l_6_12(l_6_13, l_6_14, l_6_15), {group = "type", x = 140, y = 170, txt = "����", bchecked = l_6_16}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = l_6_12:OnCheck
  l_6_14 = function()
    -- upvalues: l_6_10
    l_6_10 = "buzhu"
  end
  l_6_12(l_6_13, l_6_14)
  l_6_12 = BoxRadioBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = "RadioBox_Type3"
  l_6_16 = l_6_11
  l_6_17 = "kouqian"
  l_6_16 = l_6_16(l_6_17)
  l_6_12, l_6_15 = l_6_12(l_6_13, l_6_14, l_6_15), {group = "type", x = 220, y = 170, txt = "��Ǯ", bchecked = l_6_16}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_12 = l_6_12:OnCheck
  l_6_14 = function()
    -- upvalues: l_6_10
    l_6_10 = "kouqian"
  end
  l_6_12(l_6_13, l_6_14)
  l_6_12 = BoxLabel
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = "Text_Why"
  l_6_15 = "ԭ��"
  l_6_17 = 0
  l_6_17 = nil
  local l_6_18 = {}
  l_6_18.nW = 120
  l_6_18.nH = 30
  l_6_18.nHAlign = 1
  l_6_12(l_6_13, l_6_14, l_6_15, l_6_16, l_6_17, l_6_18)
  l_6_16 = {l_6_17, 210}
  l_6_12 = BoxEdit
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = "Edit_Why"
  l_6_12, l_6_15 = l_6_12(l_6_13, l_6_14, l_6_15), {x = 50, y = 240, w = 270, h = 70, nlimit = 100, nmulti = 10}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_14 = l_6_4
  l_6_15 = "Btn_Sure"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_6_16 = {txt = "ȷ��", x = 50, y = 320}
  l_6_14, l_6_15 = l_6_13:OnClick, l_6_13
  l_6_16 = function()
    -- upvalues: l_6_7 , l_6_9 , l_6_12 , l_6_0 , l_6_10 , l_6_1 , l_6_2
    local l_15_0 = Gkp.GetTime()
    local l_15_1 = l_6_7:GetText()
    local l_15_2 = tonumber(l_6_9:GetText())
    local l_15_3 = (l_6_12:GetText())
    local l_15_4 = nil
    local l_15_5 = Gkp.GetRoleInfo(l_15_1)
    if l_15_5 then
      l_15_4 = l_15_5.dwForceID
    end
    if l_15_1 == "" then
      MsgBox("������������")
      return 
    else
      if not Gkp.GetRoleInfo(l_15_1) then
        MsgBox("�������Ŷӳ�Ա��������")
        return 
      end
    end
    if not l_15_2 then
      MsgBox("�������")
      return 
    end
    if l_15_3 == "" then
      MsgBox("��ѡ���¼���ͣ�")
      return 
    end
    if l_6_0 == "add" or l_6_0 == "new" then
      local l_15_6 = table.insert
      local l_15_7 = Gkp.Accounts
      local l_15_8 = {}
      l_15_8.type = l_6_10
      l_15_8.forceid = l_15_4
      l_15_8.name = l_15_1
      l_15_8.time = l_15_0
      l_15_8.money = l_15_2
      l_15_8.why = l_15_3
      l_15_6(l_15_7, l_15_8)
    elseif l_6_0 == "change" then
      Gkp.Accounts[l_6_1].name = l_15_1
      Gkp.Accounts[l_6_1].money = l_15_2
      Gkp.Accounts[l_6_1].why = l_15_3
      Gkp.Accounts[l_6_1].type = l_6_10
      Gkp.Accounts[l_6_1].forceid = l_15_4
    end
    Wnd.CloseWindow(l_6_2)
    Gkp.UpdateAccount()
    Gkp.UpdateScroll("account")
  end
  l_6_14(l_6_15, l_6_16)
  l_6_14 = BoxButton
  l_6_15 = l_6_4
  l_6_16 = "Btn_Cancel"
  l_6_14, l_6_17 = l_6_14(l_6_15, l_6_16, l_6_17), {txt = "ȡ��", x = 220, y = 320}
  l_6_15, l_6_16 = l_6_14:OnClick, l_6_14
  l_6_17 = function()
    -- upvalues: l_6_2
    Wnd.CloseWindow(l_6_2)
  end
  l_6_15(l_6_16, l_6_17)
  l_6_15, l_6_16 = l_6_5:FormatAllItemPos, l_6_5
  l_6_15(l_6_16)
  if l_6_0 == "change" then
    l_6_15 = Gkp
    l_6_15 = l_6_15.Accounts
    l_6_15 = l_6_15[l_6_1]
    l_6_16, l_6_17 = l_6_7:SetText, l_6_7
    l_6_18 = l_6_15.name
    l_6_16(l_6_17, l_6_18)
    l_6_16, l_6_17 = l_6_9:SetText, l_6_9
    l_6_18 = l_6_15.money
    l_6_16(l_6_17, l_6_18)
    l_6_16, l_6_17 = l_6_12:SetText, l_6_12
    l_6_18 = l_6_15.why
    l_6_16(l_6_17, l_6_18)
  elseif l_6_0 == "new" then
    l_6_15, l_6_16 = l_6_7:SetText, l_6_7
    l_6_17 = l_6_1.name
    l_6_15(l_6_16, l_6_17)
    l_6_15, l_6_16 = l_6_12:SetText, l_6_12
    l_6_17 = l_6_1.why
    l_6_15(l_6_16, l_6_17)
  end
  l_6_15 = Gkp
  l_6_16 = Gkp
  l_6_16 = l_6_16.frameName
  l_6_16 = l_6_16 + 1
  l_6_15.frameName = l_6_16
end

Gkp.GetRoleInfo = function(l_7_0)
  local l_7_1 = GetClientTeam()
  local l_7_2 = l_7_1.nGroupNum - 1
  for l_7_6 = 0, l_7_2 do
    local l_7_7 = GetClientTeam().GetGroupInfo(l_7_6)
    if table.getn(l_7_7.MemberList) ~= 0 then
      for l_7_11,l_7_12 in pairs(l_7_7.MemberList) do
        local l_7_13 = l_7_1.GetMemberInfo(l_7_12)
        if l_7_13.szName == l_7_0 then
          return l_7_13
        end
      end
    end
  end
  return nil
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

GkpItemPanel = {}
GkpItemPanel.OnFrameCreate = function()
  this:Hide()
  local l_8_0 = this:Lookup("", "")
  l_8_0:Clear()
  GkpItemPanel.UpdatePos(this)
end

GkpItemPanel.OnItemLButtonClick = function()
  local l_9_0 = this:GetParent()
  local l_9_1 = this:GetRoot()
  local l_9_2 = Gkp.Account
  local l_9_3 = "new"
  local l_9_4 = {}
  l_9_4.name = this.playerName
  l_9_4.why = this.why
  l_9_2(l_9_3, l_9_4)
  l_9_2, l_9_3 = l_9_0:RemoveItem, l_9_0
  l_9_4 = this
   -- DECOMPILER ERROR: Overwrote pending register.

  l_9_2(l_9_3, l_9_4)
  l_9_2 = GkpItemPanel
  l_9_2 = l_9_2.UpdatePos
  l_9_3 = l_9_1
  l_9_2(l_9_3)
  l_9_2, l_9_3 = l_9_0:GetItemCount, l_9_0
  l_9_2 = l_9_2(l_9_3)
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_9_2 == 0 then
    l_9_3 = l_9_1:Hide
    l_9_3(l_9_4)
  end
end

GkpItemPanel.OnItemMouseEnter = function()
  this:SetObjectMouseOver(1)
  local l_10_0, l_10_1 = this:GetAbsPos()
  local l_10_2, l_10_3 = this:GetSize()
  local l_10_4, l_10_5 = this:GetObjectData()
  local l_10_6 = OutputItemTip
  local l_10_7 = UI_OBJECT_ITEM_ONLY_ID
  local l_10_8 = l_10_5
  local l_10_9, l_10_10 = nil, nil
  do
    local l_10_11 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    l_10_6(l_10_7, l_10_8, l_10_9, l_10_10, l_10_11, l_10_0, true)
  end
   -- WARNING: undefined locals caused missing assignments!
end

GkpItemPanel.OnItemMouseLeave = function()
  HideTip()
  this:SetObjectMouseOver(0)
end

GkpItemPanel.UpdatePos = function(l_12_0)
  local l_12_1 = l_12_0:Lookup("", "")
  local l_12_2 = l_12_1:GetItemCount()
  if l_12_2 > 0 then
    for l_12_6 = 0, l_12_2 - 1 do
      local l_12_7 = l_12_1:Lookup(l_12_6)
      if l_12_7 then
        l_12_7:SetRelPos(l_12_6 * 48, 0)
      end
    end
  end
  l_12_1:FormatAllItemPos()
  local l_12_8, l_12_9 = l_12_1:GetAllItemSize()
  l_12_1:SetSize(l_12_8, l_12_9)
  l_12_0:SetSize(l_12_8, l_12_9)
  l_12_0:SetPoint("BOTTOMCENTER", 0, 0, "BOTTOMCENTER", 0, -300)
end

Wnd.OpenWindow("interface/Moon_Gkp/ItemBox.ini", "GkpItemPanel")

