-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Head.lua 

local l_0_0 = {}
l_0_0.enable = false
Head = l_0_0
l_0_0 = Head
l_0_0.nHead = 30
l_0_0 = RegisterCustomData
l_0_0("Head.nHead")
l_0_0 = Head
l_0_0.nHeight = 40
l_0_0 = RegisterCustomData
l_0_0("Head.nHeight")
l_0_0 = RegisterCustomData
l_0_0("Head.enable")
l_0_0 = Head
l_0_0.bdistarget = true
l_0_0 = RegisterCustomData
l_0_0("Head.bdistarget")
l_0_0 = Head
l_0_0.bdis = true
l_0_0 = RegisterCustomData
l_0_0("Head.bdis")
l_0_0 = Head
l_0_0.bspecialNpc = false
l_0_0 = RegisterCustomData
l_0_0("Head.bspecialNpc")
l_0_0 = Head
l_0_0.bLifeNpc = true
l_0_0 = RegisterCustomData
l_0_0("Head.bLifeNpc")
l_0_0 = Head
l_0_0.bLifePlayer = true
l_0_0 = RegisterCustomData
l_0_0("Head.bLifePlayer")
l_0_0 = Head
l_0_0.bLifeFight = true
l_0_0 = RegisterCustomData
l_0_0("Head.bLifeFight")
l_0_0 = Head
l_0_0.bLifeImg = false
l_0_0 = RegisterCustomData
l_0_0("Head.bLifeImg")
l_0_0 = Head
l_0_0.bplayer = true
l_0_0 = RegisterCustomData
l_0_0("Head.bplayer")
l_0_0 = Head
l_0_0.p_self = false
l_0_0 = RegisterCustomData
l_0_0("Head.p_self")
l_0_0 = Head
l_0_0.p_school = false
l_0_0 = RegisterCustomData
l_0_0("Head.p_school")
l_0_0 = Head
l_0_0.p_level = true
l_0_0 = RegisterCustomData
l_0_0("Head.p_level")
l_0_0 = Head
l_0_0.p_title = false
l_0_0 = RegisterCustomData
l_0_0("Head.p_title")
l_0_0 = Head
l_0_0.p_bang = true
l_0_0 = RegisterCustomData
l_0_0("Head.p_bang")
l_0_0 = Head
l_0_0.p_flag = false
l_0_0 = RegisterCustomData
l_0_0("Head.p_flag")
l_0_0 = Head
l_0_0.bnpc = true
l_0_0 = RegisterCustomData
l_0_0("Head.bnpc")
l_0_0 = Head
l_0_0.n_level = false
l_0_0 = RegisterCustomData
l_0_0("Head.n_level")
l_0_0 = Head
l_0_0.n_title = true
l_0_0 = RegisterCustomData
l_0_0("Head.n_title")
l_0_0 = Head
l_0_0.bquest = true
l_0_0 = RegisterCustomData
l_0_0("Head.bquest")
l_0_0 = Head
l_0_0.questSign = "��"
l_0_0 = RegisterCustomData
l_0_0("Head.questSign")
l_0_0 = Head
l_0_0.bManaImg = false
l_0_0 = RegisterCustomData
l_0_0("Head.bManaImg")
l_0_0 = Head
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.DColor, l_0_1 = l_0_1, {255, 128, 64}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.DColor"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.fDColor, l_0_1 = l_0_1, {255, 128, 192}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.fDColor"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.btargetcolor = false
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.btargetcolor"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.bdcolor = true
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.bdcolor"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.bfdcolor = true
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.bfdcolor"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.bOnlySelf = false
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.bOnlySelf"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.bEnemy = false
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.bEnemy"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.bMark = false
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.bMark"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.tAngleConfig, l_0_1 = l_0_1, {bOn = false, nType = 2, bAll = true, bSelf = false, bOnlyTarget = true}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Head.tAngleConfig"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.RoleList, l_0_1 = l_0_1, {}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.SeeList, l_0_1 = l_0_1, {}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.nRenderCount = 0
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.hasEmployer, l_0_1 = l_0_1, {}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.questNpc, l_0_1 = l_0_1, {}
l_0_1 = Head
l_0_1.OnFrameCreate = function()
  local l_1_0 = Station.Lookup("Lowest/Head")
  l_1_0:ChangeRelation("Lowest/Scene", true)
  local l_1_1 = l_1_0:Lookup("", "")
  local l_1_2 = l_1_1:Lookup("Handle_Label")
  l_1_1:Clear()
  l_1_0:RegisterEvent("NPC_ENTER_SCENE")
  l_1_0:RegisterEvent("NPC_LEAVE_SCENE")
  l_1_0:RegisterEvent("RENDER_FRAME_UPDATE")
  l_1_0:RegisterEvent("PLAYER_LEAVE_SCENE")
  l_1_0:RegisterEvent("PLAYER_ENTER_SCENE")
  l_1_0:RegisterEvent("QUEST_ACCEPTED")
  l_1_0:RegisterEvent("QUEST_CANCELED")
  l_1_0:RegisterEvent("QUEST_FINISHED")
  l_1_0:RegisterEvent("QUEST_DATA_UPDATE")
  l_1_0:RegisterEvent("SYNC_ROLE_DATA_END")
  l_1_0:RegisterEvent("AddonLoad")
end

l_0_1 = Head
l_0_1.CheckShowBar = function(l_2_0)
  local l_2_1 = false
  if IsPlayer(l_2_0.dwID) and Head.bLifePlayer then
    l_2_1 = true
  else
    if not IsPlayer(l_2_0.dwID) and Head.bLifeNpc then
      l_2_1 = true
    end
  end
  local l_2_2 = true
  if Head.bLifeFight and l_2_0.bFightState then
    l_2_2 = true
  else
    l_2_2 = false
  end
  if l_2_1 and l_2_2 then
    return true
  end
  return false
end

l_0_1 = Head
l_0_1.GetPetName = function(l_3_0)
  local l_3_1 = {}
  l_3_1["����ǧ��������"] = "����"
  l_3_1["����ǧ��������"] = "����"
  l_3_1["����ǧ�������"] = "��ɲ"
  if l_3_1[l_3_0] then
    return l_3_1[l_3_0]
  end
  if StringFindW(l_3_0, "����") then
    local l_3_2 = StringReplaceW
    local l_3_3 = l_3_0
    local l_3_4 = "����"
    local l_3_5 = ""
    return l_3_2(l_3_3, l_3_4, l_3_5)
  end
  if StringFindW(l_3_0, "����") then
    local l_3_6 = StringReplaceW
    local l_3_7 = l_3_0
    local l_3_8 = "����"
    local l_3_9 = ""
    return l_3_6(l_3_7, l_3_8, l_3_9)
  end
  return l_3_0
end

Head.OnFrameBreathe = function()
  -- upvalues: l_0_0
  if not Head.bdis and not Head.bLifeNpc and not Head.bLifePlayer and GetLogicFrameCount() % 8 ~= 0 then
    return 
  end
  local l_4_0 = GetClientPlayer()
  if not l_4_0 then
    return 
  end
  local l_4_1 = Station.Lookup("Lowest/Head")
  local l_4_2 = l_4_1:Lookup("", "")
  local l_4_3 = l_4_2:GetItemCount()
  if l_4_3 > 0 then
    for l_4_7 = 0, l_4_3 - 1 do
      local l_4_8 = l_4_2:Lookup(l_4_7)
      if l_4_8 and l_4_8:GetType() == "Handle" then
        local l_4_9 = l_4_8:Lookup("Text_Content")
        local l_4_10 = Head.GetRole(l_4_8.id)
        if not l_4_10 then
          Head.RemoveRole(l_4_8.id)
          return 
        end
        local l_4_11 = ""
        local l_4_12 = GetTargetHandle(l_4_0.GetTarget())
        if not l_4_12 or l_4_12.dwID ~= l_4_8.id then
          local l_4_13 = false
          l_4_13 = l_4_13
          local l_4_14 = nil
        end
        local l_4_15 = true
        if Head.bdistarget then
          l_4_15 = false
        end
        if l_4_13 then
          l_4_15 = true
        end
        local l_4_16 = ""
        if Head.bdis and l_4_15 and l_4_10.dwID ~= l_4_0.dwID then
          l_4_16 = string.format("%.1f", Head.GetDistance(l_4_8.id)) .. "��"
        end
        l_4_11 = l_4_16 .. Head.RequestAngle(l_4_0, l_4_10, l_4_12, l_4_13) .. "\n"
        local l_4_17 = ""
        if math.floor(100 * l_4_10.nCurrentLife / l_4_10.nMaxLife) > 100 then
          local l_4_18 = Head.bLifeImg or not Head.CheckShowBar(l_4_10) or 100
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_4_17 = " " .. l_4_18 .. "%"
        local l_4_19 = l_4_10.szName
        if not IsPlayer(l_4_10.dwID) then
          if l_4_10.dwEmployer and l_4_10.dwEmployer ~= 0 then
            local l_4_20 = GetPlayer(l_4_10.dwEmployer)
            local l_4_21 = Head.GetPetName(l_4_10.szName)
            if not l_4_20 then
              l_4_19 = "ĳ�ˡ�" .. l_4_21
            end
          else
            l_4_19 = l_4_20.szName .. "��" .. l_4_21
          end
        else
          if Head.questNpc[l_4_19] and Head.bquest then
            l_4_19 = Head.questSign .. l_4_10.szName
          end
        end
        if l_4_8.data.isNpc then
          if Head.n_level then
            l_4_11 = l_4_11 .. "(" .. l_4_10.nLevel .. ")"
          end
          l_4_11 = l_4_11 .. l_4_19 .. l_4_17
          if Head.n_title and l_4_10.szTitle and l_4_10.szTitle ~= "" then
            l_4_11 = l_4_11 .. "\n<" .. l_4_10.szTitle .. ">"
          end
        else
          if Head.p_flag then
            if l_4_10.nGender == 2 then
              l_4_11 = l_4_11 .. "��"
            end
          else
            l_4_11 = l_4_11 .. "��"
          end
          if Head.p_level then
            l_4_11 = l_4_11 .. "(" .. l_4_10.nLevel .. ")"
          end
          if Head.p_school and IsPlayer(l_4_10.dwID) then
            local l_4_22 = GetForceTitle(l_4_10.dwForceID)
            if l_4_22 == "����" then
              l_4_11 = l_4_11 .. string.format("��%s��", "����")
            end
          else
            l_4_11 = l_4_11 .. string.format("��%s��", l_4_22)
          end
          l_4_11 = l_4_11 .. l_4_19 .. l_4_17
          if Head.p_title and l_4_10.szTitle and l_4_10.szTitle ~= "" then
            l_4_11 = l_4_11 .. "\n<" .. l_4_10.szTitle .. ">"
          end
        end
        if Head.p_bang and not IsInBattleField() and not IsInArena() then
          local l_4_23 = GetTongClient()
        end
        if l_4_23 and l_4_10.dwTongID ~= 0 then
          local l_4_24 = nil
          if l_0_0[l_4_10.dwTongID] then
            l_4_24 = l_0_0[l_4_10.dwTongID]
          else
            l_4_24 = l_4_23.ApplyGetTongName(l_4_10.dwTongID)
          end
          if l_4_24 and l_4_24 ~= "" then
            l_0_0[l_4_10.dwTongID] = l_4_24
          end
        end
        if l_4_24 and l_4_24 ~= "" then
          l_4_11 = l_4_11 .. "\n��" .. l_4_24 .. "��"
        end
        l_4_9:SetText(l_4_11)
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

Head.GetDistance = function(l_5_0, l_5_1)
  local l_5_2 = GetClientPlayer()
  local l_5_3 = Head.GetRole(l_5_0)
  local l_5_4 = math.floor(l_5_2.nX - l_5_3.nX ^ 2 + l_5_2.nY - l_5_3.nY ^ 2 + l_5_2.nZ / 8 - l_5_3.nZ / 8 ^ 2 ^ 0.5)
  if l_5_1 then
    return l_5_4
  end
  do return end
  return l_5_4 / 64
end

Head.AppendRole = function(l_6_0)
  local l_6_1 = Head.GetRole(l_6_0)
  local l_6_2 = true
  if IsPlayer(l_6_0) then
    l_6_2 = false
  end
  local l_6_3 = Head.RoleList
  local l_6_4 = {}
  l_6_4.name = l_6_1.szName
  l_6_4.isNpc = l_6_2
  l_6_3[l_6_0] = l_6_4
end

Head.RemoveRole = function(l_7_0)
  if not l_7_0 or not Head.RoleList[l_7_0] then
    return 
  end
  Head.RoleList[l_7_0] = nil
  local l_7_1 = Station.Lookup("Lowest/Head")
  local l_7_2 = l_7_1:Lookup("", "")
  local l_7_3 = l_7_2:Lookup(tostring(l_7_0))
  if l_7_3 then
    local l_7_4 = l_7_3:GetIndex()
    if l_7_3.hwndhp then
      l_7_2:RemoveItem(l_7_3.hwndhp:GetIndex())
      l_7_2:RemoveItem(l_7_3.hwndbg:GetIndex())
      l_7_3.hwndhp = nil
      l_7_3.hwndbg = nil
    end
    if l_7_3.hwndmp then
      l_7_2:RemoveItem(l_7_3.hwndmp:GetIndex())
      l_7_3.hwndmp = nil
    end
    l_7_2:RemoveItem(l_7_4)
  end
end

Head.OnEvent = function(l_8_0)
  if l_8_0 == "NPC_ENTER_SCENE" or l_8_0 == "PLAYER_ENTER_SCENE" then
    local l_8_1 = arg0
    local l_8_2 = Head.GetRole(l_8_1)
    if Head.RoleList[l_8_1] and not l_8_2 then
      Head.RemoveRole(l_8_1)
    end
    Head.AppendRole(l_8_1)
  elseif l_8_0 == "PLAYER_LEAVE_SCENE" or l_8_0 == "NPC_LEAVE_SCENE" then
    Head.RemoveRole(arg0)
  elseif l_8_0 == "RENDER_FRAME_UPDATE" then
    Head.nRenderCount = Head.nRenderCount + 1
    if Head.nRenderCount >= 100000000 then
      Head.nRenderCount = -1
    end
    if not Head.enable then
      return 
    end
    Head.RefreshSeeList()
    Head.RefreshDisplay()
  elseif l_8_0 == "SYNC_ROLE_DATA_END" or l_8_0 == "QUEST_ACCEPTED" or l_8_0 == "QUEST_CANCELED" or l_8_0 == "QUEST_FINISHED" or l_8_0 == "AddonLoad" then
    Head.UpdateQuestNpc()
  elseif l_8_0 == "QUEST_DATA_UPDATE" and arg0 >= 0 then
    Head.UpdateQuestNpc()
  end
end

Head.ClearTable = function(l_9_0)
  for l_9_4 in pairs(l_9_0) do
    if not Head.RoleList[l_9_4] then
      l_9_0[l_9_4] = nil
    end
  end
end

Head.IsPet = function(l_10_0, l_10_1)
  if l_10_1.isNpc then
    local l_10_2 = Head.GetRole(l_10_0)
  end
  if l_10_2.dwEmployer and l_10_2.dwEmployer ~= 0 then
    return l_10_2.dwEmployer
  end
end

Head.CanSeeName = function(l_11_0)
  local l_11_1 = false
  local l_11_2 = GetNpc(l_11_0)
  if Head.bspecialNpc and not Head.IsFilterName(l_11_2) then
    l_11_1 = true
  else
    if l_11_2.CanSeeName() then
      l_11_1 = true
    end
  end
  return l_11_1
end

Head.IsFilterName = function(l_12_0)
  local l_12_1 = false
  do
    local l_12_2 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_12_6,l_12_7 in "����ǧ�������"("����ǧ��������") do
       -- DECOMPILER ERROR: Overwrote pending register.

      if "���ذ���ɱ��" == l_12_7 then
        do break end
      end
    end
    return l_12_1
  end
   -- WARNING: undefined locals caused missing assignments!
end

Head.CanSee = function(l_13_0, l_13_1)
  local l_13_2 = false
  local l_13_3 = GetClientPlayer()
  local l_13_4 = Head.GetDistance(l_13_0)
  if l_13_4 <= Head.nHead and Head.bEnemy and IsEnemy(l_13_3.dwID, l_13_0) then
    l_13_2 = true
  end
  do return end
  if Head.bOnlySelf then
    local l_13_5, l_13_6 = l_13_3.GetTarget()
    if l_13_0 == l_13_3.dwID or l_13_6 ~= 0 and l_13_0 == l_13_6 then
      l_13_2 = true
    end
  elseif l_13_1.isNpc and Head.bnpc and Head.CanSeeName(l_13_0) then
    l_13_2 = true
  end
  do return end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if Head.bplayer and l_13_0 == l_13_3.dwID and not Head.p_self then
    l_13_2 = true
  end
  do return end
  l_13_2 = true
  return l_13_2
end

Head.RefreshSeeList = function()
  Head.ClearTable(Head.SeeList)
  Head.ClearTable(Head.hasEmployer)
  local l_14_0 = GetClientPlayer()
  if not l_14_0 then
    return 
  end
  if IsEmpty(Head.RoleList) then
    return 
  end
  local l_14_1 = GetClientPlayer()
  if not Head.RoleList[l_14_1.dwID] then
    local l_14_2 = Head.RoleList
    local l_14_3 = l_14_1.dwID
    local l_14_4 = {}
    l_14_4.name = l_14_1.szName
    l_14_4.isNpc = false
    l_14_2[l_14_3] = l_14_4
  end
  for l_14_8,l_14_9 in pairs(Head.RoleList) do
    local l_14_10 = Head.IsPet(l_14_8, l_14_9)
    if l_14_10 then
      Head.hasEmployer[l_14_8] = l_14_10
    else
      if Head.hasEmployer[l_14_8] then
        Head.hasEmployer[l_14_8] = nil
      end
    end
    if Head.CanSee(l_14_8, l_14_9) then
      Head.SeeList[l_14_8] = l_14_9
    else
      if Head.SeeList[l_14_8] then
        Head.SeeList[l_14_8] = nil
      end
    end
  end
end

Head.AdjustPos = function(l_15_0, l_15_1, l_15_2)
  if not l_15_2 or not l_15_2:IsValid() then
    return 
  end
  local l_15_3 = l_15_2:Lookup("Text_Content")
  if l_15_0 then
    local l_15_4, l_15_5 = l_15_3:GetSize()
    local l_15_6 = math.ceil(l_15_0 - l_15_4 / 2)
    local l_15_7 = math.floor(l_15_1 - l_15_5 / 2) - Head.nHeight
    l_15_3:SetAbsPos(l_15_6, l_15_7)
    l_15_2:Show()
    l_15_7 = l_15_7 + l_15_5
    local l_15_8 = math.floor(l_15_0 - l_15_2.nFixWidth / 2)
    l_15_2.hwndhp:SetAbsPos(l_15_8, l_15_7 + 3)
    if l_15_2.hwndmp then
      l_15_2.hwndmp:SetAbsPos(l_15_8, l_15_7 + 9)
    end
    if l_15_2.hwndhp:IsVisible() then
      l_15_2.hwndbg:SetAbsPos(l_15_8, l_15_7 + 3)
    elseif l_15_2.hwndmp and l_15_2.hwndmp:IsVisible() then
      l_15_2.hwndbg:SetAbsPos(l_15_8, l_15_7 + 9)
    else
      l_15_2.hwndbg:SetAbsPos(l_15_8, l_15_7 + 3)
    end
  else
    l_15_2:Hide()
    l_15_2.hwndhp:Hide()
    l_15_2.hwndbg:Hide()
  end
  if l_15_2.hwndmp then
    l_15_2.hwndmp:Hide()
  end
end

Head.AppendHandle = function(l_16_0, l_16_1, l_16_2)
  local l_16_3 = GetClientPlayer()
  local l_16_4 = l_16_0:AppendItemFromIni("interface/Moon_Head/Head.ini", "Handle_Label", tostring(l_16_1))
  l_16_4.id = l_16_1
  l_16_4.data = l_16_2
  local l_16_5 = l_16_4:Lookup("Text_Content")
  l_16_5:SetFontScheme(40)
  local l_16_6 = "Hp_" .. tostring(l_16_1)
  if not l_16_0:Lookup(l_16_6) then
    local l_16_8, l_16_9, l_16_10 = , GetHeadTextForceFontColor(l_16_1, l_16_3.dwID)
    do
      if l_16_9 == 255 and l_16_10 == 0 and l_16_3.dwID == 0 then
        local l_16_7, l_16_11 = , l_16_0:AppendItemFromIni("Interface/Moon_Head/Head.ini", "Image_HP_Bg", l_16_6 .. "_Bg")
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

    elseif l_16_9 == 255 and l_16_10 == 255 and l_16_7 == 0 then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_8.dwID = l_16_1
    l_16_4.hwndhp = l_16_8
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_4.hwndbg = l_16_11
  end
  if not l_16_2.isNpc then
    local l_16_12 = l_16_8
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_16_0:Lookup("Mp_" .. tostring(l_16_1)) then
    local l_16_13 = nil
    l_16_0:AppendItemFromIni("Interface/Moon_Head/Head.ini", "Image_MP", "Mp_" .. tostring(l_16_1)).dwID = l_16_1
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_4.hwndmp = l_16_0:AppendItemFromIni("Interface/Moon_Head/Head.ini", "Image_MP", "Mp_" .. tostring(l_16_1))
  end
  return l_16_4
end

Head.GetColor = function(l_17_0)
  local l_17_1 = GetClientPlayer()
  local l_17_2, l_17_3, l_17_4 = GetHeadTextForceFontColor(l_17_0, l_17_1.dwID)
  if Head.hasEmployer[l_17_0] then
    local l_17_5 = Head.hasEmployer[l_17_0]
    if l_17_5 == l_17_1.dwID or l_17_1.IsPlayerInMyParty(l_17_5) or IsParty(l_17_1.dwID, l_17_5) then
      l_17_2 = 0
    end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    if IsEnemy(l_17_1.dwID, l_17_5) then
      l_17_2 = 255
    end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_17_2 = 255
  end
  return l_17_2, l_17_3, l_17_4
end

Head.RefreshDisplay = function()
  local l_18_0 = GetClientPlayer()
  if not l_18_0 then
    return 
  end
  local l_18_1, l_18_2 = l_18_0.GetTarget()
  local l_18_3 = Station.Lookup("Lowest/Head")
  local l_18_4 = l_18_3:Lookup("", "")
  local l_18_5 = l_18_4:GetItemCount()
  if l_18_5 > 0 then
    for l_18_9 = 0, l_18_5 - 1 do
      local l_18_10 = l_18_4:Lookup(l_18_9)
      if l_18_10 and l_18_10:GetType() == "Handle" and not Head.SeeList[l_18_10.id] then
        if l_18_10.hwndhp then
          l_18_4:RemoveItem(l_18_10.hwndhp:GetIndex())
          l_18_4:RemoveItem(l_18_10.hwndbg:GetIndex())
          l_18_10.hwndhp = nil
          l_18_10.hwndbg = nil
        end
        if l_18_10.hwndmp then
          l_18_4:RemoveItem(l_18_10.hwndmp:GetIndex())
          l_18_10.hwndmp = nil
        end
        l_18_4:RemoveItem(l_18_10:GetIndex())
      end
    end
  end
  for l_18_14,l_18_15 in pairs(Head.SeeList) do
    if not l_18_4:Lookup(tostring(l_18_14)) then
      local l_18_16, l_18_17 = Head.AppendHandle(l_18_4, l_18_14, l_18_15)
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_18_18 = nil
    local l_18_19 = l_18_16:Lookup("Text_Content")
    local l_18_20 = 210
    local l_18_21 = Head.GetDistance(l_18_14, true)
    if l_18_19 and Head.nRenderCount % 4 == 0 then
      if l_18_21 < 1000 then
        l_18_19:SetFontScheme(({16, 187, 40})[3])
        l_18_19:SetFontScale(1)
      end
     -- DECOMPILER ERROR: Confused about usage of registers!

    elseif l_18_21 < 2000 then
      l_18_19:SetFontScheme(({16, 187, 40})[2])
      l_18_19:SetFontScale(1)
     -- DECOMPILER ERROR: Confused about usage of registers!

    elseif l_18_21 < 3000 then
      l_18_19:SetFontScheme(({16, 187, 40})[1])
      l_18_19:SetFontScale(1)
    else
      local l_18_22 = nil
      if 1 - (l_18_21 - 3000) / 5000 <= 0.7 then
        local l_18_23, l_18_24, l_18_25 = , 0.7
      end
      l_18_19:SetFontScheme(l_18_22[1])
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_18_19:SetFontScale(l_18_24)
    end
    if l_18_21 - 900 <= 0 then
      local l_18_26 = nil
    end
    l_18_20 = l_18_20 - math.floor(0 / 50)
    if l_18_20 <= 0 then
      l_18_20 = 0
    end
    local l_18_27, l_18_28, l_18_29 = , Head.GetColor(l_18_14)
    if l_18_2 ~= 0 and l_18_14 == l_18_2 and Head.btargetcolor then
      local l_18_30 = Head.TColor[2]
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if Head.GetRole(l_18_14).nMoveState == MOVE_STATE.ON_DEATH and IsEnemy(l_18_0.dwID, l_18_14) and Head.bdcolor then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if not Head.bfdcolor or 80 - l_18_21 / 80 * 0.0075 <= 25 then
        local l_18_31 = Head.TColor[3]
      end
      l_18_18.nFixWidth = 25
      local l_18_32 = nil
      local l_18_33 = nil
      if l_18_18.hwndmp then
        if not Head.bManaImg then
          l_18_18.hwndmp:Hide()
        end
      do
        elseif Head.CheckShowBar(Head.GetRole(l_18_14)) then
          local l_18_34, l_18_35 = nil
          l_18_18.hwndmp:SetSize(l_18_34, R29_PC260)
          l_18_18.hwndmp:SetPercentage(l_18_33.nCurrentMana / R29_PC260)
          l_18_18.hwndmp:Show()
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_18_18.hwndmp:GetSize():Hide()
      end
      local l_18_36 = nil
      if not Head.bLifeImg then
        l_18_18.hwndhp:Hide()
       -- DECOMPILER ERROR: Confused about usage of registers!

      do
        elseif l_18_35 then
          local l_18_37, l_18_38 = , true
           -- DECOMPILER ERROR: Overwrote pending register.

          l_18_18.hwndhp:SetSize(R29_PC260, R30_PC293)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_18_18.hwndhp:SetPercentage(R29_PC260)
          l_18_18.hwndhp:Show()
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_18_18.hwndhp:GetSize():Hide()
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if not l_18_38 and not true then
        l_18_18.hwndbg:Hide()
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif l_18_38 and true then
        l_18_18.hwndbg:Show()
        l_18_18.hwndbg:SetSize(l_18_36, 12)
       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif l_18_38 then
        l_18_18.hwndbg:Show()
        l_18_18.hwndbg:SetSize(l_18_36, 6)
       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif true then
        l_18_18.hwndbg:Show()
        l_18_18.hwndbg:SetSize(l_18_36, 6)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      l_18_19:SetFontColor(l_18_29, l_18_30, R29_PC260)
      l_18_19:SetAlpha(l_18_20)
      Moon_Lib.ApplyTargetTopScreenPos(Head.AdjustPos, l_18_18, l_18_18.id)
    end
    if Head.nRenderCount % 16 == 0 then
      l_18_4:Sort()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 182 
end

Head.GetRole = function(l_19_0)
  if IsPlayer(l_19_0) then
    local l_19_1 = GetPlayer
    local l_19_2 = l_19_0
    return l_19_1(l_19_2)
  else
    local l_19_3 = GetNpc
    local l_19_4 = l_19_0
    return l_19_3(l_19_4)
  end
end

Head.RequestAngle = function(l_20_0, l_20_1, l_20_2, l_20_3)
  if not Head.tAngleConfig.bOn then
    return ""
  end
  local l_20_4 = ""
  if l_20_0.dwID == l_20_1.dwID and l_20_2 and Head.tAngleConfig.bSelf then
    l_20_4 = Head.GetAngleTxt(l_20_0, l_20_2)
  end
  do return end
  if Head.tAngleConfig.bAll then
    l_20_4 = Head.GetAngleTxt(l_20_1, l_20_0)
  end
  if Head.tAngleConfig.bOnlyTarget and not l_20_3 then
    l_20_4 = ""
  end
  return l_20_4
end

Head.GetAngleTxt = function(l_21_0, l_21_1)
  local l_21_2 = Head.GetTargetAngle(l_21_0, l_21_1)
  local l_21_3 = ""
  if Head.tAngleConfig.nType == 1 then
    l_21_3 = "(" .. tostring(l_21_2) .. ")"
  else
    if Head.tAngleConfig.nType == 2 then
      l_21_3 = "(��)"
    end
  end
  if l_21_2 < 90 then
    l_21_3 = "(��)"
  end
  return l_21_3
end

Head.GetTargetAngle = function(l_22_0, l_22_1)
  local l_22_2 = math.floor
  local l_22_3, l_22_4, l_22_5 = Moon_Lib.GetFaceDirection(l_22_0, l_22_1), .end
  return l_22_2(l_22_3, l_22_4, l_22_5)
end

Head.UpdateQuestNpc = function()
  Head.questNpc = {}
  local l_23_0 = GetClientPlayer()
  if not l_23_0 then
    return 
  end
  local l_23_1 = l_23_0.GetQuestTree()
  for l_23_5,l_23_6 in pairs(l_23_1) do
    do break end
    do
      local l_23_7, l_23_8, l_23_9, l_23_10, l_23_11 = pairs(l_23_6)
      local l_23_12 = l_23_0.GetQuestID(l_23_11)
      if l_23_0.GetQuestPhase(l_23_12) ~= 2 then
        local l_23_13 = GetQuestInfo(l_23_12)
        local l_23_14 = l_23_0.GetQuestTraceInfo(l_23_12)
        for l_23_18,l_23_19 in pairs(l_23_14.kill_npc) do
          l_23_19.have = math.min(l_23_19.have, l_23_19.need)
          if l_23_19.have < l_23_19.need then
            local l_23_20 = Table_GetNpcTemplateName(l_23_19.template_id)
            Head.questNpc[l_23_20] = true
          end
        end
        local l_23_21 = Table_GetQuestStringInfo(l_23_12)
        local l_23_22 = l_23_21.szDescription
        for l_23_26,l_23_27 in string.gfind(l_23_22, "<F17(%d)%s*(.-)>") do
          if tonumber(l_23_26) == 2 and not Head.questNpc[l_23_27] then
            Head.questNpc[l_23_27] = true
          end
        end
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

Wnd.OpenWindow("interface\\Moon_Head\\Head.ini", "Head")
RegisterBoxAddonVersion("Moon_Head", 3.5)

