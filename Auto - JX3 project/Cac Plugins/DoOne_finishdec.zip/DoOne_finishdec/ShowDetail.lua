-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ShowDetail.lua 

local l_0_0 = {}
l_0_0.DAMAGE = "�˺�ͳ��"
l_0_0.BEDAMAGE = "����ͳ��"
l_0_0.HEAL = "����ͳ��"
l_0_0.BEHEAL = "����ͳ��"
SHOW_DETAIL_MODE = l_0_0
ShowDetail, l_0_0 = l_0_0, {nCurrentMode = SHOW_DETAIL_MODE.DAMAGE, szPlayeName = nil, nMaxDetailEntryCount = 8, nWidth = 400, nSelectIndex = 0, 
DisplayDataList = {}}
l_0_0 = ShowDetail
l_0_0.OnFrameCreate = function()
  this:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  ShowDetail.Hide()
end

l_0_0 = ShowDetail
l_0_0.Show = function(l_2_0)
  if not l_2_0 then
    return 
  end
  local l_2_1 = Station.Lookup("Normal/ShowDetail")
  l_2_1:Show()
  ShowDetail.szPlayerName = l_2_0
  if Recount.nCurrentMode == RECOUNT_MODE.DAMAGE then
    ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.DAMAGE
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEDAMAGE then
      ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.BEDAMAGE
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.HEAL then
      ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.HEAL
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEHEAL then
      ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.BEHEAL
    end
  end
  ShowDetail.Select(1)
  ShowDetail.Display()
end

l_0_0 = ShowDetail
l_0_0.Hide = function()
  local l_3_0 = Station.Lookup("Normal/ShowDetail")
  l_3_0:Hide()
end

l_0_0 = ShowDetail
l_0_0.Select = function(l_4_0)
  local l_4_1 = Station.Lookup("Normal/ShowDetail")
  local l_4_2 = (l_4_1:Lookup("Wnd_OutputA"))
  local l_4_3, l_4_4, l_4_5 = nil, nil, nil
  if l_4_0 ~= ShowDetail.nSelectIndex then
    l_4_3 = l_4_2:Lookup("", "Shadow_Entry_A" .. ShowDetail.nSelectIndex)
    if l_4_3 then
      l_4_4 = l_4_3:GetSize()
      l_4_3:SetSize(0, l_4_5)
    end
    l_4_3 = l_4_2:Lookup("", "Shadow_Entry_A" .. l_4_0)
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_4_3 then
      l_4_4 = l_4_3:GetSize()
      l_4_3:SetSize(ShowDetail.nWidth, l_4_5)
    end
    ShowDetail.nSelectIndex = l_4_0
  end
end

l_0_0 = ShowDetail
l_0_0.OnLButtonClick = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "Btn_Close" then
    ShowDetail.Hide()
  end
end

l_0_0 = ShowDetail
l_0_0.OnItemLButtonClick = function()
  local l_6_0 = this:GetName()
  if string.find(l_6_0, "Text_Entry_A") == nil then
    return 
  end
  local l_6_1 = tonumber(string.match(l_6_0, "%d+"))
  if not l_6_1 then
    return 
  end
  if #ShowDetail.DisplayDataList < l_6_1 then
    return 
  end
  ShowDetail.Select(l_6_1)
  ShowDetail.Display()
end

l_0_0 = ShowDetail
l_0_0.Display = function()
  if not ShowDetail.szPlayerName then
    return 
  end
  local l_7_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_7_1, l_7_2 = "#", "��������"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if "����".nCurrentMode == "����".DAMAGE then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.BEDAMAGE then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.HEAL then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if ShowDetail.nCurrentMode ~= SHOW_DETAIL_MODE.BEHEAL or not l_7_2 then
    return 
  end
  local l_7_3 = Station.Lookup("Normal/ShowDetail")
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_7_4 = l_7_3:Lookup("Wnd_Main"):Lookup("", "Text_Name")
  if l_7_4 then
    l_7_4:SetText(ShowDetail.szPlayerName .. "-" .. ShowDetail.nCurrentMode)
  end
  local l_7_5 = l_7_3:Lookup("Wnd_OutputA")
  for l_7_9 = 1, 5 do
    local l_7_10 = l_7_5:Lookup("", "Text_Title_A_" .. l_7_9)
    l_7_10:SetText(l_7_0[l_7_9])
  end
  ShowDetail.DisplayDataList = {}
  for l_7_14,l_7_15 in pairs(l_7_2) do
    ShowDetail.DisplayDataList[#ShowDetail.DisplayDataList + 1] = l_7_15
  end
  table.sort(ShowDetail.DisplayDataList, function(l_8_0, l_8_1)
    return l_8_1.Total < l_8_0.Total
  end)
  local l_7_16 = nil
  for l_7_20,l_7_21 in ipairs(ShowDetail.DisplayDataList) do
    if l_7_20 <= ShowDetail.nMaxDetailEntryCount then
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_20 .. "_1")
      l_7_16:SetText(l_7_20)
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_20 .. "_2")
      l_7_16:SetText(l_7_21.Name)
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_20 .. "_3")
      l_7_16:SetText(l_7_21.nTotal)
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_20 .. "_4")
      l_7_16:SetText(l_7_21.Total)
      local l_7_22 = l_7_21.Total / l_7_1 * 100
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_20 .. "_5")
      l_7_16:SetText(string.format("%.1f", l_7_22) .. "%")
    end
  end
  for l_7_26 = #ShowDetail.DisplayDataList + 1, ShowDetail.nMaxDetailEntryCount do
    for l_7_30 = 1, 5 do
      l_7_16 = l_7_5:Lookup("", "Text_Entry_A" .. l_7_26 .. "_" .. l_7_30)
      l_7_16:SetText("")
    end
  end
  local l_7_31 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for i = l_7_31, 7 do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_7_35 = "ƽ��"("���", "����", "%" .. l_7_34)
    l_7_35:SetText(l_7_0[l_7_34])
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_7_36 = nil
  if not l_7_31.DisplayDataList[ShowDetail.nSelectIndex] then
    return 
  end
  local l_7_37 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMinHit)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.0f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotalHit / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nHit))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMaxHit)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nHit)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nHit / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMinCritical)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.0f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotalCritical / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nCritical))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMaxCritical)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nCritical)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nCritical / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "��")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nBlock)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nBlock / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nShield)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nShield / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "δ����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMiss)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nMiss / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nDodge)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nDodge / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_7_37 > 0 then
    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, l_7_36)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "ʶ��")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_37(l_7_16, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nShipo)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_16 = l_7_37
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_7_37(l_7_16, string.format("%.1f", l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nShipo / l_7_31.DisplayDataList[ShowDetail.nSelectIndex].nTotal * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_7_41 = l_7_37, 7 do
    do
      local l_7_41 = nil
      l_7_41 = 1
      for l_7_45 = l_7_41, 7 do
        local l_7_45 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_16 = l_7_45
         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_45(l_7_16, "")
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_0("Interface\\Moon_zRecount\\ShowDetail.ini", "ShowDetail")
l_0_0 = ShowDetail
l_0_0 = l_0_0.Hide
l_0_0()

