-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: time.lua 

AuctionTip.time = "11��02�� 20:26"

