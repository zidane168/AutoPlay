-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: gkp.lua 

Gkp = {}
Gkp.Accounts = {}
RegisterCustomData("Account/Gkp.Accounts")
Gkp.tBili = {}
RegisterCustomData("Gkp.tBili")
Gkp.ItemColor = 1
RegisterCustomData("Gkp.ItemColor")
Gkp.TipSet = 2
RegisterCustomData("Gkp.TipSet")
Gkp.szRule = ""
RegisterCustomData("Gkp.szRule")
Gkp.WageData = {}
RegisterCustomData("Gkp.WageData")
Gkp.CountMoney = 0
RegisterCustomData("Gkp.CountMoney")
Gkp.CountDuoyu = 0
RegisterCustomData("Gkp.CountDuoyu")
Gkp.MemberCount = 0
RegisterCustomData("Gkp.MemberCount")
Gkp.bActive = false
RegisterCustomData("Gkp.bActive")
Gkp.frameName = 0
Gkp.nButie = 0
Gkp.nRealCount = 0
Gkp.nPinJun = 0
Gkp.bUse = false
RegisterCustomData("Gkp.bUse")
Gkp.assignMode = 1
RegisterCustomData("Gkp.assignMode")
Gkp.Create = function(l_1_0)
  BoxBoolCheckBox(l_1_0, "CheckBox_bUse", "�������ż�¼(ͷ���Ҽ��˵�����)", Gkp, "bUse")
end

RegisterMoonButton("Gkp", 704, "���ż�¼", "Team", Gkp.Create)
Gkp.OnFrameCreate = function()
  Gkp.PageAcccount = this:Lookup("Page_Total/Page_Account")
  Gkp.PageWage = this:Lookup("Page_Total/Page_Wage")
  Gkp.PageSet = this:Lookup("Page_Total/Page_Set")
  local l_2_0 = BoxButton
  local l_2_1 = this
  local l_2_2 = "Btn_Active"
  local l_2_3 = {}
  l_2_3.txt = "��ʼ�"
  l_2_3.w = 100
  l_2_3.h = 30
  l_2_3.x = 30
  l_2_3.y = 15
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_0 = BoxButton
  l_2_1 = this
  l_2_2 = "Btn_Clear"
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_3 = {txt = "�������", w = 100, h = 30, x = 140, y = 15}
  l_2_0 = BoxButton
  l_2_1 = Gkp
  l_2_1 = l_2_1.PageAcccount
  l_2_2 = "Btn_AddAccount"
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_3 = {txt = "����", w = 100, h = 27, x = 40, y = 470}
  l_2_0 = BoxButton
  l_2_1 = Gkp
  l_2_1 = l_2_1.PageAcccount
  l_2_2 = "Btn_ChangeAccount"
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_3 = {txt = "�޸�", w = 100, h = 27, x = 150, y = 470}
  l_2_0 = BoxButton
  l_2_1 = Gkp
  l_2_1 = l_2_1.PageAcccount
  l_2_2 = "Btn_DelAccount"
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_3 = {txt = "ɾ��", w = 100, h = 27, x = 260, y = 470}
  l_2_0 = BoxButton
  l_2_1 = Gkp
  l_2_1 = l_2_1.PageAcccount
  l_2_2 = "Btn_SayAccount"
  l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_3 = {txt = "����", w = 100, h = 27, x = 370, y = 470}
  l_2_0 = Gkp
  l_2_0 = l_2_0.PageWage
  l_2_0, l_2_1 = l_2_0:Lookup, l_2_0
  l_2_2 = ""
  l_2_3 = ""
  l_2_0 = l_2_0(l_2_1, l_2_2, l_2_3)
  l_2_1 = BoxLabel
  l_2_2 = l_2_0
  l_2_3 = "Text_MoneyTip"
  local l_2_4 = ""
  local l_2_5 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_2_6 = 30
  local l_2_7 = {}
  l_2_7.nHAlign = 0
  l_2_1(l_2_2, l_2_3, l_2_4, l_2_5, l_2_6, l_2_7)
  l_2_1 = BoxCheckBox
  l_2_2 = Gkp
  l_2_2 = l_2_2.PageWage
  l_2_3 = "CheckBox_Allot"
  l_2_1(l_2_2, l_2_3, l_2_4)
  l_2_4 = {txt = "�������", x = 450, y = 470}
  l_2_1 = BoxButton
  l_2_2 = Gkp
  l_2_2 = l_2_2.PageWage
  l_2_3 = "Btn_SayWage"
  l_2_1(l_2_2, l_2_3, l_2_4)
  l_2_4 = {txt = "����", w = 100, h = 35, x = 550, y = 470}
  l_2_1 = BoxButton
  l_2_2 = Gkp
  l_2_2 = l_2_2.PageWage
  l_2_3 = "Btn_Balance"
  l_2_1(l_2_2, l_2_3, l_2_4)
  l_2_4 = {txt = "����", w = 100, h = 35, x = 650, y = 470}
  l_2_1 = Gkp
  l_2_1 = l_2_1.LoadSet
  l_2_1()
  l_2_1 = this
  l_2_1, l_2_2 = l_2_1:RegisterEvent, l_2_1
  l_2_3 = "UI_SCALED"
  l_2_1(l_2_2, l_2_3)
  l_2_1 = this
  l_2_1, l_2_2 = l_2_1:RegisterEvent, l_2_1
  l_2_3 = "DISTRIBUTE_ITEM"
  l_2_1(l_2_2, l_2_3)
  l_2_1 = this
  l_2_1, l_2_2 = l_2_1:RegisterEvent, l_2_1
  l_2_3 = "CUSTOM_DATA_LOADED"
  l_2_1(l_2_2, l_2_3)
end

Gkp.LoadSet = function()
  local l_3_0 = Gkp.PageSet:Lookup("", "")
  local l_3_1 = BoxLabel
  local l_3_2 = l_3_0
  local l_3_3 = "Label_ItemColor"
  local l_3_4 = "������¼����Ʒ�ȼ���"
  local l_3_5 = {}
  do
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_3_6 = 30
    do
      local l_3_7 = {}
      l_3_7.nHAlign = 0
      l_3_1(l_3_2, l_3_3, l_3_4, l_3_5, l_3_6, l_3_7)
      l_3_3 = "��ɫ"
      l_3_5 = 30
      l_3_6 = 50
      l_3_6 = 0
      l_3_7 = 200
      l_3_5, l_3_4 = {l_3_6, l_3_7, 72}, {l_3_5, l_3_6}
      l_3_4 = "��ɫ"
      l_3_6 = 100
      l_3_7 = 50
      l_3_7 = 0
      l_3_6, l_3_5 = {l_3_7, 126, 255}, {l_3_6, l_3_7}
      l_3_5 = "��ɫ"
      l_3_7 = 170
      l_3_7, l_3_6 = {255, 40, 255}, {l_3_7, 50}
      l_3_6 = "��ɫ"
      do
        local l_3_8 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for l_3_5,l_3_6 in l_3_2 do
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          local l_3_9 = 255
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          local l_3_10, l_3_11, l_3_12 = 165(0)
          local l_3_13 = BoxRadioBox
          local l_3_14 = Gkp.PageSet
          local l_3_15 = "RadioBox_ItemColor" .. l_3_5
          local l_3_16 = {}
          l_3_16.group = "itemcolor"
          l_3_16.x = l_3_7
          l_3_16.y = l_3_8
          l_3_16.txt = l_3_9
          l_3_13 = l_3_13(l_3_14, l_3_15, l_3_16)
          l_3_14, l_3_15 = l_3_13:SetFontColor, l_3_13
          l_3_16 = l_3_10
          l_3_14(l_3_15, l_3_16, l_3_11, l_3_12)
          l_3_14, l_3_15 = l_3_13:OnCheck, l_3_13
          l_3_16 = function()
          -- upvalues: l_3_5
          Gkp.ItemColor = l_3_5
        end
          l_3_14(l_3_15, l_3_16)
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_3_2(l_3_3, l_3_4, l_3_5, {l_3_7, l_3_8}, l_3_7, l_3_8)
        l_3_8 = {nHAlign = 0}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for i_1,l_3_7 in ipairs({
{"�ֶ�����", 30, 120}, 
{"��������", 130, l_3_7}, 
{"��Ʒ��ʾ��", l_3_7, l_3_8}}) do
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_3_17 = l_3_7[3]
          local l_3_18 = l_3_7[1]
          local l_3_19 = BoxRadioBox
          local l_3_20 = Gkp.PageSet
          local l_3_21 = "RadioBox_ItemTip" .. i_1
          local l_3_22 = {}
          l_3_22.group = "itemtip"
          l_3_22.x = l_3_8
          l_3_22.y = l_3_17
          l_3_22.txt = l_3_18
          l_3_19 = l_3_19(l_3_20, l_3_21, l_3_22)
          l_3_20, l_3_21 = l_3_19:OnCheck, l_3_19
          l_3_22 = function()
          -- upvalues: l_3_6
          Gkp.TipSet = l_3_6
        end
          l_3_20(l_3_21, l_3_22)
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        do
          local l_3_23 = {}
          BoxLabel(l_3_0, "Label_GkpRule", "GKP����", {l_3_8, 150}, l_3_8, l_3_23)
          BoxEdit(Gkp.PageSet, "Edit_GkpRule", {nmulti = 20, limit = 1000, w = 350, h = 150, x = 30, y = 180}):SetValue(Gkp, "szRule")
        end
        l_3_0:FormatAllItemPos()
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
end

Gkp.OnEvent = function(l_4_0)
  local l_4_1 = Station.Lookup("Normal/Gkp")
  if l_4_0 == "UI_SCALED" then
    this:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  elseif l_4_0 == "DISTRIBUTE_ITEM" then
    if not Gkp.bActive then
      return 
    end
    local l_4_2 = GetPlayer(arg0)
    local l_4_3 = GetItem(arg1)
    local l_4_4 = GetItemNameByItem(l_4_3)
    if l_4_3.nQuality < Gkp.ItemColor + 1 then
      return 
    end
    if Gkp.TipSet == 2 then
      local l_4_5 = Gkp.Account
      local l_4_6 = "new"
      local l_4_7 = {}
      l_4_7.name = l_4_2.szName
      l_4_7.why = l_4_4
      l_4_5(l_4_6, l_4_7)
    else
      if Gkp.TipSet == 3 then
        local l_4_8 = Station.Lookup("Normal/GkpItemPanel")
        local l_4_9 = l_4_8:Lookup("", "")
        local l_4_10 = l_4_9:AppendItemFromIni("interface/Moon_Gkp/ItemBox.ini", "Box_Item", tostring(l_4_3.nUiId))
        l_4_10:SetRelPos(l_4_10:GetIndex() * 48, 0)
        l_4_10:Show()
        l_4_10.playerName = l_4_2.szName
        l_4_10.why = l_4_4
        l_4_10:SetObject(UI_OBJECT_ITEM_ONLY_ID, l_4_3.nUiId, l_4_3.dwID, l_4_3.nVersion, l_4_3.dwTabType, l_4_3.dwIndex)
        l_4_10:SetObjectIcon(Table_GetItemIconID(l_4_3.nUiId))
        UpdateItemBoxExtend(l_4_10, l_4_3)
        if l_4_3 and l_4_3.bCanStack and l_4_3.nStackNum > 1 then
          l_4_10:SetOverText(0, l_4_3.nStackNum)
        else
          l_4_10:SetOverText(0, "")
        end
        l_4_8:Show()
        GkpItemPanel.UpdatePos(l_4_8)
      end
    end
  elseif l_4_0 == "CUSTOM_DATA_LOADED" then
    if arg0 ~= "Role" then
      return 
    end
    local l_4_11 = l_4_1:Lookup("Btn_Active")
    local l_4_12 = l_4_11:Lookup("", "Text_Btn")
    if Gkp.bActive then
      l_4_12:SetText("�����")
    end
  else
    l_4_12:SetText("��ʼ�")
  end
end

Gkp.UpdatePos = function(l_5_0)
  local l_5_1 = l_5_0:GetItemCount()
  for l_5_5 = 0, l_5_1 - 1 do
    local l_5_6 = l_5_0:Lookup(l_5_5)
    if l_5_6 then
      l_5_6:SetRelPos(10, 25 * l_5_5)
    end
  end
end

Gkp.GetTime = function()
  local l_6_0 = GetCurrentTime()
  local l_6_1 = TimeToDate(l_6_0)
  local l_6_2 = string.format
  local l_6_3 = "%d��%d�� %02d:%02d"
  local l_6_4 = l_6_1.month
  local l_6_5 = l_6_1.day
  local l_6_6 = l_6_1.hour
  local l_6_7 = l_6_1.minute
  return l_6_2(l_6_3, l_6_4, l_6_5, l_6_6, l_6_7)
end

Gkp.AppendMoney = function(l_7_0, l_7_1, l_7_2, l_7_3)
  l_7_0:AppendItemFromString("<handle>name=\"" .. l_7_1 .. "\"</handle>")
  local l_7_4 = l_7_0:Lookup(l_7_0:GetItemCount() - 1)
  if l_7_4 then
    l_7_4:AppendItemFromString("<text>text=\"" .. l_7_2 .. "\"" .. " name=\"Text_Money\"</text>")
    local l_7_5 = l_7_4:Lookup(l_7_4:GetItemCount() - 1)
    l_7_5:SetHAlign(2)
    l_7_5:SetVAlign(1)
    l_7_5:SetSize(l_7_3 - 20, 25)
    l_7_4:AppendItemFromString("<image>path=\"UI/Image/Common/Money.UITex\" name=\"Image_Gold\" frame=0</image>")
    local l_7_6 = l_7_4:Lookup(l_7_4:GetItemCount() - 1)
    l_7_6:SetRelPos(l_7_3 - 20, 0)
    l_7_6:SetSize(20, 20)
    l_7_4:FormatAllItemPos()
  end
  return l_7_4
end

Gkp.AppendAccount = function(l_8_0, l_8_1, l_8_2)
  local l_8_3 = GetClientPlayer()
  l_8_0:AppendItemFromString("<handle>name=\"" .. l_8_1 .. "\" eventid=277</handle>")
  local l_8_4 = l_8_0:Lookup(l_8_0:GetItemCount() - 1)
  if l_8_4 then
    local l_8_5 = BoxLabel
    local l_8_6 = l_8_4
    local l_8_7 = "Text_Time"
    local l_8_8 = l_8_2.time
    local l_8_9, l_8_10 = nil, nil
    local l_8_11 = {}
    l_8_11.nW = 150
    l_8_11.nH = 25
    l_8_11.nHAlign = 1
    l_8_5(l_8_6, l_8_7, l_8_8, l_8_9, l_8_10, l_8_11)
    l_8_5 = ""
    l_8_6 = l_8_2.forceid
    if l_8_6 then
      l_8_6 = "["
      l_8_7 = GetForceTitle
      l_8_8 = l_8_2.forceid
      l_8_7 = l_8_7(l_8_8)
      l_8_8 = "]"
      l_8_9 = l_8_2.name
      l_8_5 = l_8_6 .. l_8_7 .. l_8_8 .. l_8_9
    else
      l_8_5 = l_8_2.name
    end
    l_8_6 = BoxLabel
    l_8_7 = l_8_4
    l_8_8 = "Text_Name"
    l_8_9 = l_8_5
    l_8_11 = 170
    l_8_11 = nil
    local l_8_12 = {}
    l_8_12.nW = 150
    l_8_12.nH = 25
    l_8_6(l_8_7, l_8_8, l_8_9, l_8_10, l_8_11, l_8_12)
    l_8_10 = {l_8_11, 0}
    l_8_6 = Gkp
    l_8_6 = l_8_6.AppendMoney
    l_8_7 = l_8_4
    l_8_8 = "Handle_Money"
    l_8_9 = l_8_2.money
    l_8_10 = 110
    l_8_6 = l_8_6(l_8_7, l_8_8, l_8_9, l_8_10)
    l_8_7, l_8_8 = l_8_6:SetRelPos, l_8_6
    l_8_9 = 333
    l_8_10 = 0
    l_8_7(l_8_8, l_8_9, l_8_10)
    l_8_7 = ""
    l_8_8 = l_8_2.type
    if l_8_8 == "xiaofei" then
      l_8_7 = "[��Ʒ]"
    else
      l_8_8 = l_8_2.type
      if l_8_8 == "buzhu" then
        l_8_7 = "[����]"
      end
    else
      l_8_8 = l_8_2.type
    end
    if l_8_8 == "kouqian" then
      l_8_7 = "[��Ǯ]"
    end
    l_8_8 = BoxLabel
    l_8_9 = l_8_4
    l_8_10 = "Text_Why"
    l_8_11 = l_8_7
    l_8_12 = l_8_2.why
    l_8_11 = l_8_11 .. l_8_12
    local l_8_13 = nil
    local l_8_14 = {}
    l_8_14.nW = 300
    l_8_14.nH = 25
    l_8_8(l_8_9, l_8_10, l_8_11, l_8_12, l_8_13, l_8_14)
    l_8_12 = {470, 0}
    l_8_8 = BoxImage
    l_8_9 = l_8_4
    l_8_10 = "Image_Sel"
    l_8_11 = "ui/Image/Common/TextShadow.UITex"
    l_8_12 = 0
    l_8_13 = nil
    l_8_8, l_8_14 = l_8_8(l_8_9, l_8_10, l_8_11, l_8_12, l_8_13, l_8_14), {750, 25}
    l_8_8, l_8_9 = l_8_8:Hide, l_8_8
    l_8_8(l_8_9)
    l_8_4.bimg = true
    l_8_8, l_8_9 = l_8_4:FormatAllItemPos, l_8_4
    l_8_8(l_8_9)
  end
end

Gkp.UpdateAccount = function()
  local l_9_0 = Gkp.PageAcccount
  local l_9_1 = l_9_0:Lookup("", "Handle_List1")
  l_9_1:Clear()
  if #Gkp.Accounts <= 0 then
    return 
  end
  for l_9_5,l_9_6 in ipairs(Gkp.Accounts) do
    Gkp.AppendAccount(l_9_1, tostring(l_9_5), l_9_6)
  end
  Gkp.UpdatePos(l_9_1)
  l_9_1:FormatAllItemPos()
end

Gkp.AppendWage = function(l_10_0, l_10_1, l_10_2)
  local l_10_3 = GetClientPlayer()
  l_10_0:AppendItemFromString("<handle>name=\"" .. l_10_1 .. "\" eventid=319</handle>")
  local l_10_4 = l_10_0:Lookup(l_10_0:GetItemCount() - 1)
  if l_10_4 then
    local l_10_5 = "[" .. GetForceTitle(l_10_2.forceid) .. "]" .. l_10_2.name
    BoxLabel(l_10_4, "Text_Name", l_10_5)
    do
      local l_10_6 = Gkp.tBili[l_10_2.name] or 1
    end
    local l_10_7 = nil
    local l_10_8 = ""
    local l_10_9 = 255
    local l_10_10 = 255
    if l_10_7 == 1 then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_10_7 == 0.5 then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_10_7 == 0 then
      local l_10_11 = 255
    end
    local l_10_12 = BoxLabel
    local l_10_13 = l_10_4
    local l_10_14 = "Text_Bili"
    local l_10_15 = l_10_8
    local l_10_16 = {160, 0}
    local l_10_17 = nil
    l_10_12 = l_10_12(l_10_13, l_10_14, l_10_15, l_10_16, l_10_17, {nW = 100, nH = 30, nHAlign = 1})
    l_10_12, l_10_13 = l_10_12:SetFontColor, l_10_12
    l_10_14 = l_10_9
    l_10_15 = l_10_10
    l_10_16 = l_10_11
    l_10_12(l_10_13, l_10_14, l_10_15, l_10_16)
    l_10_12 = Gkp
    l_10_12 = l_10_12.AppendMoney
    l_10_13 = l_10_4
    l_10_14 = "money1"
    l_10_15 = l_10_2.ncost
    l_10_16 = 110
    l_10_12 = l_10_12(l_10_13, l_10_14, l_10_15, l_10_16)
    l_10_13, l_10_14 = l_10_12:SetRelPos, l_10_12
    l_10_15 = 270
    l_10_16 = 0
    l_10_13(l_10_14, l_10_15, l_10_16)
    l_10_13 = Gkp
    l_10_13 = l_10_13.AppendMoney
    l_10_14 = l_10_4
    l_10_15 = "money2"
    l_10_16 = l_10_2.nPinJun
    l_10_17 = 110
    l_10_13 = l_10_13(l_10_14, l_10_15, l_10_16, l_10_17)
    l_10_14, l_10_15 = l_10_13:SetRelPos, l_10_13
    l_10_16 = 390
    l_10_17 = 0
    l_10_14(l_10_15, l_10_16, l_10_17)
    l_10_14 = Gkp
    l_10_14 = l_10_14.AppendMoney
    l_10_15 = l_10_4
    l_10_16 = "money3"
    l_10_17 = l_10_2.nbk
    l_10_14 = l_10_14(l_10_15, l_10_16, l_10_17, 110)
    l_10_15, l_10_16 = l_10_14:SetRelPos, l_10_14
    l_10_17 = 515
    l_10_15(l_10_16, l_10_17, 0)
    l_10_15 = Gkp
    l_10_15 = l_10_15.AppendMoney
    l_10_16 = l_10_4
    l_10_17 = "money4"
    l_10_15 = l_10_15(l_10_16, l_10_17, l_10_2.nreal, 110)
    l_10_16, l_10_17 = l_10_15:SetRelPos, l_10_15
    l_10_16(l_10_17, 640, 0)
    l_10_16 = BoxImage
    l_10_17 = l_10_4
    local l_10_18 = "Image_Sel"
    local l_10_19 = "ui/Image/Common/TextShadow.UITex"
    local l_10_20 = 0
    local l_10_21 = nil
    l_10_16 = l_10_16(l_10_17, l_10_18, l_10_19, l_10_20, l_10_21, {750, 25})
    l_10_16, l_10_17 = l_10_16:Hide, l_10_16
    l_10_16(l_10_17)
    l_10_4.bimg = true
    l_10_4.btip = true
    l_10_16 = l_10_2.name
    l_10_4.name = l_10_16
    l_10_16, l_10_17 = l_10_4:FormatAllItemPos, l_10_4
    l_10_16(l_10_17)
  end
end

Gkp.UpdateWageData = function()
  local l_11_0 = {}
  l_11_0.xiaofei = {}
  l_11_0.buzhu = {}
  l_11_0.kouqian = {}
  local l_11_1 = 0
  local l_11_2 = 0
  Gkp.CountMoney = 0
  Gkp.CountDuoyu = 0
  Gkp.MemberCount = 0
  Gkp.nButie = 0
  for l_11_6,l_11_7 in ipairs(Gkp.Accounts) do
    if l_11_7.type == "xiaofei" then
      l_11_1 = l_11_1 + l_11_7.money
      Gkp.CountMoney = Gkp.CountMoney + l_11_7.money
      if not l_11_0.xiaofei[l_11_7.name] then
        l_11_0.xiaofei[l_11_7.name] = 0
      end
      local l_11_8 = l_11_0.xiaofei
      local l_11_9 = l_11_7.name
      l_11_8[l_11_9] = l_11_0.xiaofei[l_11_7.name] + l_11_7.money
    elseif l_11_7.type == "buzhu" then
      if not l_11_0.buzhu[l_11_7.name] then
        l_11_0.buzhu[l_11_7.name] = 0
      end
      local l_11_10 = l_11_0.buzhu
      local l_11_11 = l_11_7.name
      l_11_10[l_11_11] = l_11_0.buzhu[l_11_7.name] + l_11_7.money
      l_11_10 = l_11_7.money
      l_11_1 = l_11_1 - l_11_10
      l_11_10 = Gkp
      l_11_11 = Gkp
      l_11_11 = l_11_11.nButie
      l_11_11 = l_11_11 + l_11_7.money
      l_11_10.nButie = l_11_11
    elseif l_11_7.type == "kouqian" then
      if not l_11_0.kouqian[l_11_7.name] then
        l_11_0.kouqian[l_11_7.name] = 0
      end
      local l_11_12 = l_11_0.kouqian
      local l_11_13 = l_11_7.name
      l_11_12[l_11_13] = l_11_0.kouqian[l_11_7.name] + l_11_7.money
      l_11_12 = l_11_7.money
      l_11_2 = l_11_2 + l_11_12
    end
  end
  Gkp.WageData = {}
  local l_11_14 = 0
  local l_11_15 = GetClientTeam()
  local l_11_16 = l_11_15.nGroupNum - 1
  for l_11_20 = 0, l_11_16 do
    local l_11_21 = GetClientTeam().GetGroupInfo(l_11_20)
    if table.getn(l_11_21.MemberList) ~= 0 then
      for l_11_25,l_11_26 in pairs(l_11_21.MemberList) do
        local l_11_27 = l_11_15.GetMemberInfo(l_11_26)
        local l_11_28 = l_11_27.szName
        local l_11_29 = l_11_27.dwForceID
        do
          local l_11_30 = l_11_0.xiaofei[l_11_28] or 0
        do
          end
          local l_11_31 = nil
        do
          end
          local l_11_32 = nil
        end
        local l_11_33 = nil
        local l_11_34 = nil
        local l_11_35 = nil
        local l_11_36 = (l_11_0.buzhu[l_11_28] or 0) - (l_11_0.kouqian[l_11_28] or 0)
        table.insert(Gkp.WageData, {name = l_11_27.szName, forceid = l_11_29, nbk = l_11_36, ncost = l_11_33, nreal = 0, nPinJun = 0})
        l_11_14 = l_11_14 + 1
        if Gkp.tBili[l_11_27.szName] == 0 then
          l_11_14 = l_11_14 - 1
        end
      end
    end
  end
  local l_11_37 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_11_41,l_11_42 in l_11_37 do
    local l_11_42 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_11_41 ~= 0 then
      l_11_2 = l_11_42
    end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  l_11_37.nRealCount = l_11_1
  Gkp.nPinJun = math.floor((l_11_1) / (l_11_14))
  Gkp.MemberCount = l_11_14
  Gkp.CountDuoyu = l_11_2
  if #Gkp.WageData > 0 then
    for l_11_46,l_11_47 in ipairs(Gkp.WageData) do
      do
        local l_11_47 = l_11_42
        l_11_47 = Gkp
        l_11_47 = l_11_47.tBili
        l_11_47 = l_11_47[l_11_46.name]
        if not l_11_47 then
          l_11_47 = 1
          local l_11_48, l_11_49, l_11_50, l_11_51, l_11_52 = nil
        end
        if l_11_47 ~= 0 then
          if Gkp.assignMode == 1 then
            Gkp.WageData[l_11_45].nreal = math.floor(math.floor(l_11_2 / (l_11_14)) + math.floor((l_11_1) / (l_11_14)) * l_11_47 + l_11_46.nbk)
          else
            if Gkp.assignMode == 2 then
              Gkp.WageData[l_11_45].nreal = math.floor(math.floor((l_11_1) / (l_11_14)) * l_11_47 + l_11_46.nbk)
            end
          end
          Gkp.WageData[l_11_45].nPinJun = math.floor((l_11_1) / (l_11_14))
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

Gkp.RefreshWage = function()
  local l_12_0 = GetClientPlayer()
  if not l_12_0.IsInParty() then
    MsgBox("�㲻���Ŷ��У��޷����㣡")
    return 
  end
  Gkp.UpdateWageData()
  Gkp.UpdateWage()
  Gkp.UpdateScroll("wage")
end

Gkp.UpdateWage = function()
  local l_13_0 = Gkp.PageWage
  local l_13_1 = l_13_0:Lookup("", "")
  local l_13_2 = l_13_1:Lookup("Text_MoneyTip")
  local l_13_3 = l_13_0:Lookup("", "Handle_List2")
  l_13_3:Clear()
  if #Gkp.WageData > 0 then
    for l_13_7,l_13_8 in ipairs(Gkp.WageData) do
      Gkp.AppendWage(l_13_3, tostring(l_13_7), l_13_8)
    end
  end
  l_13_2:SetText(FormatString("�ܽ�<D0>����<D1>������������<D2>", Gkp.CountMoney, Gkp.CountDuoyu, Gkp.MemberCount))
  if Gkp.assignMode == 1 then
    local l_13_9 = l_13_0:Lookup("CheckBox_Allot")
  end
  if not l_13_9:IsCheckBoxChecked() then
    l_13_9:Check(true)
  end
  Gkp.UpdatePos(l_13_3)
  l_13_3:FormatAllItemPos()
end

Gkp.OnCheckBoxCheck = function()
  local l_14_0 = this:GetName()
  if l_14_0 == "CheckBox_Allot" then
    Gkp.assignMode = 1
  end
end

Gkp.OnCheckBoxUncheck = function()
  local l_15_0 = this:GetName()
  if l_15_0 == "CheckBox_Allot" then
    Gkp.assignMode = 2
  end
end

Gkp.OnItemRButtonClick = function()
  local l_16_0 = this
  local l_16_1 = {}
  l_16_1.fnAction = function(l_17_0)
    -- upvalues: l_16_0
    Gkp.tBili[l_16_0.name] = l_17_0
    Gkp.RefreshWage()
  end
  local l_16_2 = table.insert
  local l_16_3 = l_16_1
  local l_16_4 = {}
  l_16_4.szOption = "ȫ��"
  l_16_4.UserData = 1
  l_16_2(l_16_3, l_16_4)
  l_16_2 = table
  l_16_2 = l_16_2.insert
  l_16_3 = l_16_1
  l_16_2(l_16_3, l_16_4)
  l_16_4 = {szOption = "���", UserData = 0.5}
  l_16_2 = table
  l_16_2 = l_16_2.insert
  l_16_3 = l_16_1
  l_16_2(l_16_3, l_16_4)
  l_16_4 = {szOption = "����", UserData = 0}
  l_16_2 = PopupMenu
  l_16_3 = l_16_1
  l_16_2(l_16_3)
end

Gkp.UpdateItemImage = function(l_17_0)
  local l_17_1 = l_17_0:Lookup("Image_Sel")
  if l_17_0.bSel then
    l_17_1:Show()
    l_17_1:SetAlpha(255)
  elseif l_17_0.bOver then
    l_17_1:Show()
    l_17_1:SetAlpha(128)
  else
    l_17_1:Hide()
  end
end

Gkp.OnItemMouseEnter = function()
  if this.bimg then
    this.bOver = true
    Gkp.UpdateItemImage(this)
  end
  if this.btip then
    local l_18_0, l_18_1 = this:GetAbsPos()
    local l_18_2, l_18_3 = this:GetSize()
    local l_18_4 = OutputTip
    local l_18_5 = GetFormatText("�Ҽ���������״̬")
    local l_18_6 = 400
    local l_18_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_18_4(l_18_5, l_18_6, l_18_7)
  end
   -- WARNING: undefined locals caused missing assignments!
end

Gkp.OnItemMouseLeave = function()
  if this.bimg then
    this.bOver = false
    Gkp.UpdateItemImage(this)
  end
  if this.btip then
    HideTip()
  end
end

Gkp.OnItemLButtonClick = function()
  if this.bimg then
    local l_20_0 = this:GetParent()
    local l_20_1 = l_20_0:GetItemCount() - 1
    for l_20_5 = 0, l_20_1 do
      local l_20_6 = l_20_0:Lookup(l_20_5)
      if l_20_6 then
        l_20_6.bSel = false
        Gkp.UpdateItemImage(l_20_6)
      end
    end
    this.bSel = true
    Gkp.UpdateItemImage(this)
  end
end

Gkp.OnFrameKeyDown = function()
  if GetKeyName(Station.GetMessageKey()) == "Esc" then
    this:Hide()
    return 1
  end
end

Gkp.OnLButtonDown = function()
  local l_22_0 = this:GetName()
  if l_22_0:find("Btn_BUp") or l_22_0:find("Btn_BDown") then
    local l_22_1 = this:GetParent()
    local l_22_2 = (l_22_1:GetName())
    local l_22_3 = nil
    if l_22_2 == "Page_Account" then
      l_22_3 = l_22_1:Lookup("Scroll_List1")
    elseif l_22_2 == "Page_Wage" then
      l_22_3 = l_22_1:Lookup("Scroll_List2")
    end
  end
  if l_22_3 then
    if l_22_0:find("Btn_BUp") then
      l_22_3:ScrollPrev(1)
    end
  else
    if l_22_0:find("Btn_BDown") then
      l_22_3:ScrollNext(1)
    end
  end
end

Gkp.OnScrollBarPosChanged = function()
  local l_23_0 = this:GetScrollPos()
  local l_23_1 = this:GetName()
  local l_23_2 = (this:GetParent())
  local l_23_3, l_23_4, l_23_5 = nil, nil, nil
  if l_23_1 == "Scroll_List1" then
    l_23_4 = l_23_2:Lookup("Btn_BDown1")
    l_23_5 = l_23_2:Lookup("Btn_BUp1")
    l_23_3 = l_23_2:Lookup("", "Handle_List1")
  elseif l_23_1 == "Scroll_List2" then
    l_23_4 = l_23_2:Lookup("Btn_BDown2")
    l_23_5 = l_23_2:Lookup("Btn_BUp2")
    l_23_3 = l_23_2:Lookup("", "Handle_List2")
  end
  if l_23_0 == 0 then
    l_23_5:Enable(0)
  else
    l_23_5:Enable(1)
  end
  if l_23_0 == this:GetStepCount() then
    l_23_4:Enable(0)
  else
    l_23_4:Enable(1)
  end
  l_23_3:SetItemStartRelPos(0, -l_23_0 * 20)
end

Gkp.UpdateScroll = function(l_24_0)
  local l_24_1, l_24_2, l_24_3, l_24_4, l_24_6, l_24_7, l_24_8, l_24_9, l_24_11, l_24_12, l_24_13, l_24_14, l_24_15, l_24_17, l_24_18, l_24_19, l_24_20, l_24_21, l_24_22, l_24_23, l_24_24, l_24_25 = nil
  if l_24_0 == "account" then
    local l_24_5 = nil
    l_24_5 = Station.Lookup("Normal/Gkp/Page_Total/Page_Account"):Lookup("Scroll_List1")
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_24_0 == "wage" then
    local l_24_10, l_24_16, l_24_26 = , Station.Lookup("Normal/Gkp/Page_Total/Page_Account"):Lookup("", "Handle_List1"), Station.Lookup("Normal/Gkp/Page_Total/Page_Account"):Lookup("Btn_BUp1")
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

  end
  l_24_10:ScrollHome()
  local l_24_27, l_24_28 = nil
  local l_24_29, l_24_30 = l_24_26, Station.Lookup("Normal/Gkp/Page_Total/Page_Account"):Lookup("Btn_BDown1")
  local l_24_31 = nil
  l_24_27:SetStepCount(math.ceil((l_24_28 - l_24_16) / 20))
  if math.ceil((l_24_28 - l_24_16) / 20) > 0 then
    l_24_27:Show()
    l_24_29:Show()
    l_24_30:Show()
  else
    l_24_27:Hide()
    l_24_29:Hide()
    l_24_30:Hide()
  end
   -- WARNING: undefined locals caused missing assignments!
end

Gkp.OnItemMouseWheel = function()
  local l_25_0 = Station.GetMessageWheelDelta()
  local l_25_1 = this:GetName()
  local l_25_2 = this:GetParent():GetParent()
  if l_25_1 == "Handle_List1" then
    l_25_2:Lookup("Scroll_List1"):ScrollNext(l_25_0)
  elseif l_25_1 == "Handle_List2" then
    l_25_2:Lookup("Scroll_List2"):ScrollNext(l_25_0)
  end
  return 1
end

Gkp.OnLButtonHold = function()
  local l_26_1 = nil
  local l_26_0 = Gkp.OnLButtonDown
  return l_26_0()
end

Gkp.Show = function()
  local l_27_0 = Station.Lookup("Normal/Gkp")
  if l_27_0 then
    l_27_0:Show()
    l_27_0:Lookup("Page_Total"):ActivePage("Page_Account")
  end
end

Gkp.TalkRule = function()
  local l_28_0 = GetClientPlayer()
  if not l_28_0.IsInParty() then
    Msg("���㲻���Ŷӻ��߶����У�")
    return 
  end
  local l_28_1 = l_28_0.Talk
  local l_28_2 = PLAYER_TALK_CHANNEL.RAID
  local l_28_3 = ""
  local l_28_4 = {}
  local l_28_5 = {}
  l_28_5.type = "text"
  l_28_5.text = Gkp.szRule
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_28_1(l_28_2, l_28_3, l_28_4)
end

AppendCommand("gkp", Gkp.Show)
AppendCommand("saygkp", Gkp.TalkRule)
Gkp.SayAccount = function()
  local l_29_0 = GetClientPlayer()
  if not l_29_0.IsInParty() then
    Msg("���㲻�ڶ�������Ŷ��У�")
    return 
  end
  if #Gkp.Accounts <= 0 then
    return 
  end
  local l_29_1 = {}
  local l_29_2 = 0
  for l_29_6,l_29_7 in ipairs(Gkp.Accounts) do
    if l_29_7.type == "xiaofei" then
      l_29_2 = l_29_2 + l_29_7.money
      if not l_29_1[l_29_7.name] then
        l_29_1[l_29_7.name] = 0
      end
      local l_29_8 = l_29_7.name
      l_29_1[l_29_8] = l_29_1[l_29_7.name] + l_29_7.money
    end
  end
  function(l_30_0)
    -- upvalues: l_29_0
    local l_30_1 = l_29_0.Talk
    local l_30_2 = PLAYER_TALK_CHANNEL.RAID
    local l_30_3 = ""
    local l_30_4 = {}
    local l_30_5 = {}
    l_30_5.type = "text"
    l_30_5.text = l_30_0
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_30_1(l_30_2, l_30_3, l_30_4)
  end("���λ�����룺" .. l_29_2 .. "������������£�")
  for l_29_13,l_29_14 in pairs(l_29_1) do
    local l_29_10 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_29_10("[" .. l_29_14 .. "]��" .. l_29_8 .. "��")
  end
end

Gkp.SayWage = function()
  local l_30_0 = GetClientPlayer()
  if not l_30_0.IsInParty() then
    Msg("���㲻�ڶ�������Ŷ��У�")
    return 
  end
  if #Gkp.Accounts <= 0 then
    return 
  end
  do
    Gkp.UpdateWageData()
    function(l_31_0)
    -- upvalues: l_30_0
    local l_31_1 = l_30_0.Talk
    local l_31_2 = PLAYER_TALK_CHANNEL.RAID
    local l_31_3 = ""
    local l_31_4 = {}
    local l_31_5 = {}
    l_31_5.type = "text"
    l_31_5.text = l_31_0
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_31_1(l_31_2, l_31_3, l_31_4)
  end("���λ�����룺" .. Gkp.CountMoney .. "�𣬲������ã�" .. Gkp.nButie .. "��ʵ�ʿ��ã�" .. Gkp.nRealCount .. "�𣬷���������" .. Gkp.MemberCount .. "�ˣ�ƽ�����ʣ�" .. Gkp.nPinJun .. "��������Ա���£�\n")
    if #Gkp.WageData > 0 then
      for l_30_5,l_30_6 in ipairs(Gkp.WageData) do
        local l_30_2 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

        if Gkp.nButie.nreal ~= Gkp.nPinJun then
          if l_30_7.nbk > 0 then
            do return end
          end
           -- DECOMPILER ERROR: Overwrote pending register.

          do
            local l_30_8 = ""
          end
          local l_30_9 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

          if l_30_7.nbk < 0 and Gkp.tBili[l_30_7.name] or 1 == 1 then
            do return end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_30_7.nbk < 0 and Gkp.tBili[l_30_7.name] or 1 == 0.5 then
            do return end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_30_7.nbk < 0 and Gkp.tBili[l_30_7.name] or 1 == 0 then
            l_30_2(l_30_7.name .. "" .. l_30_9 .. "ʵ�ʷ��䣺" .. l_30_7.nreal .. "\n")
          end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 91 
end

RegisterPlayerMenu("gkp", function(l_31_0)
  if not Gkp.bUse then
    return {}
  end
  local l_31_1 = {}
  local l_31_2 = {}
  l_31_2.szOption = "���ż�¼"
  local l_31_3 = {}
  l_31_3.szOption = "�鿴����"
  l_31_3.fnAction = function()
    Gkp.UpdateAccount()
    Gkp.UpdateScroll("account")
    Gkp.UpdateWage()
    Gkp.UpdateScroll("wage")
    Gkp.PageSet:Lookup("Edit_GkpRule/Edit_Default"):SetText(Gkp.szRule)
    Gkp.PageSet:Lookup("RadioBox_ItemTip" .. tostring(Gkp.TipSet)):Check(true)
    Gkp.PageSet:Lookup("RadioBox_ItemColor" .. tostring(Gkp.ItemColor)):Check(true)
    Gkp.Show()
  end
  local l_31_4 = {}
  l_31_4.bDevide = true
  local l_31_5 = {}
  l_31_5.szOption = "��������������"
  l_31_5.fnAction = function()
    Gkp.SayAccount()
  end
  local l_31_6 = {}
  l_31_6.szOption = "��������"
  l_31_6.fnAction = function()
    Gkp.SayWage()
  end
  local l_31_7 = {}
  l_31_7.szOption = "����GKP����"
  l_31_7.fnAction = function()
    Gkp.TalkRule()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  return l_31_1
end
)
Wnd.OpenWindow("interface/Moon_Gkp/gkp.ini", "Gkp"):Hide()

