-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Ballon.lua 

Chat.say = function(l_1_0)
  local l_1_1 = arg0
  local l_1_2 = arg1
  local l_1_3 = arg2
  local l_1_4 = GetClientPlayer()
  if l_1_2 == l_1_4.dwID then
    return 
  end
  if not IsTeammateOpened() then
    return 
  end
  if (l_1_3 == PLAYER_TALK_CHANNEL.RAID or l_1_3 == PLAYER_TALK_CHANNEL.TEAM) and l_1_4.IsInParty() and not l_1_4.IsInRaid() then
    local l_1_5 = GetClientTeam()
    local l_1_6 = l_1_5.GetGroupInfo(0)
  end
  if l_1_6 and l_1_6.MemberList then
    for l_1_10,l_1_11 in pairs(l_1_6.MemberList) do
      if l_1_11 == l_1_2 then
        Chat.addBalloon(l_1_2, l_1_1)
      end
      do break end
    end
  end
end

Chat.addBalloon = function(l_2_0, l_2_1)
  local l_2_2 = this:Lookup("", "Handle_TotalBalloon")
  local l_2_3 = "Balloon" .. l_2_0
  local l_2_4 = l_2_2:Lookup(l_2_3)
  if not l_2_4 then
    l_2_2:AppendItemFromIni("Interface\\Moon_Chat\\Moon_Chat.ini", "Handle_Balloon", l_2_3)
    l_2_4 = l_2_2:Lookup(l_2_2:GetItemCount() - 1)
    l_2_4:Show()
    l_2_4.dwCharacterID = l_2_0
    l_2_4.saytime = GetTime()
    l_2_4.Alpha = 255
    hwnd = l_2_4:Lookup("Handle_Content")
    hwnd:Show()
  else
    l_2_4.saytime = GetTime()
    l_2_4.Alpha = 255
    hwnd = l_2_4:Lookup("Handle_Content")
  end
  local l_2_5, l_2_6, l_2_7 = GetMsgFontColor("MSG_PARTY")
  l_2_1 = EmotionPanel_ParseBallonText(l_2_1, l_2_5, l_2_6, l_2_7)
  hwnd:Clear()
  hwnd:SetSize(300, 131)
  hwnd:AppendItemFromString(l_2_1)
  hwnd:FormatAllItemPos()
  hwnd:SetSizeByAllItemSize()
  Chat.AdjustSize(l_2_4, hwnd)
  Chat.ShowteamBalloon(hwnd, l_2_0, l_2_4)
end

Chat.ShowteamBalloon = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = Station.Lookup("Normal/Teammate", "")
  local l_3_4 = l_3_3:GetItemCount()
  for l_3_8 = 0, l_3_4 - 1 do
    local l_3_9 = l_3_3:Lookup(l_3_8)
    if l_3_9.dwID == l_3_1 then
      local l_3_10, l_3_11 = l_3_9:GetAbsPos()
      local l_3_12, l_3_13 = l_3_0:GetSize()
      l_3_2:SetAbsPos(l_3_10 + 205, l_3_11 - l_3_13 - 2)
    end
  end
end

Chat.AdjustSize = function(l_4_0, l_4_1)
  local l_4_3 = nil
  local l_4_2 = l_4_1 + 20
  image = l_4_0:Lookup("Image_Bg1")
  image:SetSize(l_4_3, l_4_2)
  image = l_4_0:Lookup("Image_Bg2")
  image:SetRelPos((l_4_3) * 0.8 - 16, l_4_2 - 4)
  l_4_0:SetSize(10000, 10000)
  l_4_0:FormatAllItemPos()
  l_4_0:SetSizeByAllItemSize()
end


