-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SkillBuff.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1["��ҡֱ��"] = "buff"
l_0_1["����"] = "buff"
l_0_1["����"] = "buff"
l_0_1["����"] = "buff"
l_0_1["����"] = "buff"
l_0_1["����"] = "buff"
l_0_1["��"] = "buff"
l_0_1["��Ѩ"] = "buff"
l_0_1["�ͻ���ɽ"] = "buff"
l_0_1["���"] = "debuff"
l_0_1["����"] = "debuff"
l_0_1["��ע"] = "debuff"
l_0_1["ѣ��"] = "debuff"
l_0_1["ͬ��"] = "debuff"
l_0_1["��Ĭ"] = "debuff"
l_0_1["ä��"] = "debuff"
l_0_1["����"] = "debuff"
l_0_1["����"] = "debuff"
l_0_1["���ǹ���"] = "debuff"
l_0_0["ͨ��"] = l_0_1
l_0_0["����"], l_0_1 = l_0_1, {["��̫��"] = "qcskill", ["������"] = "qcskill", ["������"] = "qcskill", ["�Ʋ��"] = "qcskill", ["��ɽ��"] = "qcskill", ["��̫��"] = "qcskill", ["������"] = "qcskill", ["���ǳ�"] = "qcskill", ["������"] = "buff", ["躹�����"] = "buff", ["�꼯"] = "buff", ["ƾ������"] = "buff", ["�������"] = "buff", ["����޺�"] = "buff", ["�ٷ�"] = "buff", ["����"] = "buff", ["��ظ�"] = "buff", ["����"] = "buff", ["ϻ��"] = "buff", ["�����ֻ�"] = "debuff", ["����"] = "debuff", ["������"] = "debuff", ["׽Ӱ"] = "debuff", ["����"] = "debuff", ["��������"] = "debuff", ["����"] = "debuff", ["���Ż���"] = "debuff", ["���Զ���"] = "debuff", ["����"] = "debuff", ["���ɾ���"] = "debuff", ["��һ����"] = "debuff", ["����"] = "debuff", ["���⽭ɽ"] = "buff", ["�巽�о�"] = "debuff", ["�������"] = "debuff"}
l_0_0["����"], l_0_1 = l_0_1, {["�޺�����"] = "buff", ["�������"] = "buff", ["���ŭĿ"] = "buff", ["����Ǭ��"] = "buff", ["����"] = "buff", ["��ִ"] = "buff", ["�۹�"] = "buff", ["����ʽ"] = "buff", ["��ɽʩ��"] = "buff", ["���"] = "buff", ["����"] = "buff", ["����"] = "buff", ["ȡ��"] = "buff", ["������"] = "buff", ["�﷨"] = "buff", ["����"] = "buff", ["����"] = "buff", ["������"] = "buff", ["����"] = "buff", ["����"] = "buff", ["ǧ��"] = "buff", ["����"] = "buff", ["ҵ��"] = "debuff", ["�ƻ�"] = "debuff", ["����ʽ"] = "debuff", ["Ħڭ����"] = "debuff", ["ִ��"] = "debuff", ["��ħ"] = "debuff", ["���̽Կ�"] = "debuff", ["����ʽ"] = "debuff", ["���سɷ�"] = "debuff", ["�����"] = "debuff", ["��ɨ����"] = "debuff", ["��ӽ�ɳ"] = "debuff"}
l_0_0["���"], l_0_1 = l_0_1, {["��"] = "buff", ["������"] = "buff", ["��ˮ"] = "buff", ["ͻ"] = "buff", ["Х�绢"] = "buff", ["�����"] = "buff", ["�˵�"] = "buff", ["�γ۳�"] = "buff", ["����"] = "buff", ["����"] = "buff", ["������"] = "buff", ["����ͻ"] = "buff", ["����ɽ"] = "buff", ["�ع³�"] = "buff", ["�ɽ�"] = "buff", ["�绢"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["��Ѫ"] = "buff", ["���"] = "buff", ["����"] = "debuff", ["����"] = "debuff", ["���"] = "debuff", ["��Ӱ"] = "debuff", ["�²�"] = "debuff", ["����"] = "debuff", ["�Ѳ��"] = "debuff", ["�Ʒ�"] = "debuff", ["����"] = "debuff", ["��"] = "debuff", ["��Ѫ"] = "debuff"}
l_0_0["��"], l_0_1 = l_0_1, {["���໤��"] = "buff", ["��¥��Ӱ"] = "buff", ["����"] = "buff", ["��ˮ����"] = "buff", ["��������"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����Ѫ"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["�θ�"] = "buff", ["��Ӱ"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "debuff", ["̫��ָ"] = "debuff", ["ѩ����"] = "debuff", ["����ָ"] = "debuff", ["��������"] = "debuff", ["ˮ���޼�"] = "debuff", ["����ָ"] = "debuff", ["��������"] = "debuff", ["ܽ�ز���"] = "debuff", ["����ָ"] = "debuff", ["����ع��"] = "debuff", ["�ɹ�"] = "debuff"}
l_0_0["����"], l_0_1 = l_0_1, {["��صͰ�"] = "buff", ["�������"] = "buff", ["��Ԫ����"] = "buff", ["ȵ̤֦"] = "buff", ["ѸӰ"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["��������"] = "buff", ["��������"] = "buff", ["����"] = "buff", ["���"] = "buff", ["����"] = "buff", ["��������"] = "buff", ["����Ͱ�"] = "buff", ["����"] = "buff", ["˪��"] = "buff", ["ڤ��"] = "buff", ["��Ū��"] = "buff", ["���"] = "debuff", ["����"] = "debuff", ["����"] = "debuff", ["����"] = "debuff", ["��������"] = "debuff", ["������ŭ"] = "debuff", ["�벽��"] = "debuff", ["����ͨ��"] = "debuff", ["Ӱ��"] = "debuff"}
l_0_0["�ؽ�"], l_0_1 = l_0_1, {["�෵"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "buff", ["Х��"] = "buff", ["ݺ��"] = "buff", ["����"] = "buff", ["����"] = "buff", ["��÷"] = "buff", ["����"] = "buff", ["��Ȫ��Ծ"] = "buff", ["����"] = "buff", ["������"] = "buff", ["����"] = "buff", ["���"] = "buff", ["����"] = "buff", ["���"] = "buff", ["����"] = "buff", ["����"] = "buff", ["����"] = "debuff", ["����"] = "debuff", ["��ѩ"] = "debuff", ["����"] = "debuff", ["�׹��ɽ"] = "debuff", ["����"] = "debuff", ["�紵��"] = "debuff", ["����ƾ�"] = "debuff", ["�ƾ�"] = "debuff", ["����"] = "debuff", ["�̹�"] = "debuff"}
l_0_0["�嶾"], l_0_1 = l_0_1, {["�Ƴ��׼�"] = "buff", ["�Ƴ��"] = "buff", ["���ԡ��"] = "buff", ["�����׼�"] = "buff", ["ʥЫ�׼�"] = "buff", ["�����׼�"] = "buff", ["�����׼�"] = "buff", ["����׼�"] = "buff", ["�̵��׼�"] = "buff", ["Ы�Ķ���"] = "buff", ["�����ƶ�"] = "buff", ["ʥ��֯��"] = "buff", ["���"] = "buff", ["ʥӿ"] = "buff", ["����"] = "buff", ["β����"] = "buff", ["�ҽ�"] = "buff", ["������"] = "debuff", ["�ݲй�"] = "debuff", ["���Ĺ�"] = "debuff", ["����ݲ�"] = "debuff", ["Ы�Ŀݲ�"] = "debuff", ["��Ӱ�ݲ�"] = "debuff", ["��Ӱ����"] = "debuff", ["�Х����"] = "debuff", ["��������"] = "debuff", ["Ы������"] = "debuff", ["ǧ˿����"] = "debuff", ["��Ӱ����"] = "debuff", ["�Х����"] = "debuff", ["�߹�"] = "debuff", ["�ù�"] = "debuff", ["ǧ˿"] = "debuff", ["��Ӱ"] = "debuff", ["�Х"] = "debuff", ["����"] = "debuff", ["�Ի�"] = "debuff", ["Ӱ��"] = "debuff", ["���"] = "debuff"}
l_0_1 = "����"
local l_0_2 = {}
l_0_2["����"] = "buff"
l_0_2["�ϻ�ɰ"] = "buff"
l_0_2["��Ӱ"] = "buff"
l_0_2["������"] = "buff"
l_0_2["����"] = "buff"
l_0_2["����"] = "buff"
l_0_2["����"] = "buff"
l_0_2["��������"] = "buff"
l_0_2["������Ⱥ"] = "buff"
l_0_2["�������"] = "buff"
l_0_2["ǧ������"] = "buff"
l_0_2["ǧ��֮��"] = "buff"
l_0_2["���ǧ��"] = "buff"
l_0_2["����"] = "buff"
l_0_2["����֮��"] = "buff"
l_0_2["����"] = "buff"
l_0_2["��������"] = "buff"
l_0_2["������ɢ"] = "buff"
l_0_2["����"] = "buff"
l_0_2["Ӱ��"] = "buff"
l_0_2["ӰϢ"] = "buff"
l_0_2["׷������"] = "buff"
l_0_2["����"] = "buff"
l_0_2["������Ӱ"] = "buff"
l_0_2["�����滨��"] = "debuff"
l_0_2["������"] = "debuff"
l_0_2["������"] = "debuff"
l_0_2["����޼"] = "debuff"
l_0_2["�ϻ�ɰ"] = "debuff"
l_0_2["��Ѫ��"] = "debuff"
l_0_2["���켬��"] = "debuff"
l_0_2["������"] = "debuff"
l_0_2["÷����"] = "debuff"
l_0_2["����"] = "debuff"
l_0_2["��Ӱ"] = "debuff"
l_0_2["���"] = "debuff"
l_0_2["����"] = "debuff"
l_0_2["�������"] = "debuff"
l_0_2["��צ"] = "debuff"
l_0_2["��צ"] = "debuff"
l_0_2["����"] = "debuff"
l_0_2["���Ĵ̹�"] = "debuff"
l_0_0[l_0_1] = l_0_2
l_0_1 = "����"
l_0_0[l_0_1], l_0_2 = l_0_2, {["̰ħ��"] = "buff", ["����"] = "buff", ["ʥ����"] = "buff", ["����"] = "buff", ["ʥ��"] = "buff", ["������ɢ"] = "buff", ["ʥ��"] = "buff", ["����"] = "buff", ["��ʥ"] = "buff", ["����"] = "buff", ["��ҹ�ϳ�"] = "buff", ["��Ȼ"] = "buff", ["Ѹ��"] = "buff", ["����֮��"] = "buff", ["��ħ"] = "buff", ["�������"] = "buff", ["�﷣"] = "buff", ["�����¾"] = "buff", ["�ɶ�"] = "buff", ["���"] = "buff", ["���"] = "buff", ["��ࡤ����"] = "buff", ["��ࡤ����"] = "buff", ["��ࡤ����"] = "buff", ["��ࡤѣ��"] = "buff", ["��¾"] = "buff", ["ѪӰ"] = "buff", ["�������"] = "buff", ["����ͬ��"] = "buff", ["������"] = "buff", ["�޼�Ӱ��"] = "buff", ["�һ�"] = "buff", ["ר��"] = "buff", ["������ʥ"] = "buff", ["������Դ"] = "buff", ["�۳�"] = "buff", ["��Ӱ"] = "buff", ["�ùⲽ"] = "debuff", ["������"] = "debuff", ["����"] = "debuff", ["ҵ���︿"] = "debuff", ["��η����"] = "debuff", ["�ս�"] = "debuff", ["�½�"] = "debuff", ["��ҹ����"] = "debuff", ["��ҹ����"] = "debuff", ["��ҹ����"] = "debuff", ["��ҹ����"] = "debuff", ["����"] = "debuff", ["����"] = "debuff", ["��ħ"] = "debuff", ["��������"] = "debuff", ["����"] = "debuff", ["����"] = "debuff", ["������Ӱ"] = "debuff", ["���賤��"] = "debuff"}
l_0_1 = "ؤ��"
l_0_0[l_0_1], l_0_2 = l_0_2, {["������"] = "buff", ["Ц����"] = "buff", ["��Ծ��Ԩ"] = "buff", ["��ˮ��"] = "buff", ["��Х����"] = "buff", ["����"] = "buff", ["��Ԩ"] = "buff", ["����"] = "buff", ["�޽�"] = "buff", ["ѱ��"] = "buff", ["Ԫ��"] = "buff", ["����"] = "buff", ["����·"] = "debuff", ["��������"] = "debuff", ["����ң"] = "debuff", ["��"] = "debuff", ["����"] = "debuff"}
l_0_2 = "bSelf"
l_0_2 = "bTarget"
l_0_2 = "bOpen"
l_0_2 = "Anchor"
local l_0_3 = {}
local l_0_4 = "x"
l_0_3[l_0_4] = -303
l_0_4 = "y"
l_0_3[l_0_4] = -216
l_0_4 = "s"
l_0_3[l_0_4] = "CENTER"
l_0_4 = "r"
l_0_3[l_0_4] = "CENTER"
l_0_2 = "tShield"
l_0_3 = {}
l_0_2 = "MonitorBuff"
l_0_3 = {}
l_0_2 = "nVersion"
l_0_3 = 0
l_0_2 = "nCurrVersion"
l_0_3 = 6
Moon_SkillBuff, l_0_1 = l_0_1, {[l_0_2] = true, [l_0_2] = true, [l_0_2] = false, [l_0_2] = l_0_3, [l_0_2] = l_0_3, [l_0_2] = l_0_3, [l_0_2] = l_0_3, [l_0_2] = l_0_3}
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.MonitorBuff"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.tShield"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.nVersion"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.bSelf"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.bTarget"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.bOpen"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "Moon_SkillBuff.Anchor"
l_0_1(l_0_2)
l_0_1 = Moon_SkillBuff
l_0_2 = "MonitorBuff"
l_0_3 = clone
l_0_4 = l_0_0
l_0_3 = l_0_3(l_0_4)
l_0_1[l_0_2] = l_0_3
l_0_1 = 0
l_0_3 = 4976
local l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {name = "��̫��", [l_0_5] = 358, [l_0_5] = 24}
l_0_3 = 3080
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "������", [l_0_5] = 357, [l_0_5] = 24}
l_0_3 = 4978
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "������", [l_0_5] = 360, [l_0_5] = 8}
l_0_3 = 4977
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "�Ʋ��", [l_0_5] = 359, [l_0_5] = 24}
l_0_3 = 4982
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "��ɽ��", [l_0_5] = 371, [l_0_5] = 8}
l_0_3 = 4979
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "��̫��", [l_0_5] = 361, [l_0_5] = 24}
l_0_3 = 4981
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "������", [l_0_5] = 363, [l_0_5] = 24}
l_0_3 = 4980
l_0_5 = "name"
l_0_5 = "dwSkillID"
l_0_5 = "dwTime"
l_0_4 = {[l_0_5] = "���ǳ�", [l_0_5] = 362, [l_0_5] = 24}
l_0_4 = "interface/Moon_SkillBuff/SkillBuff.ini"
l_0_5 = Moon_SkillBuff
local l_0_6 = "OnFrameCreate"
l_0_5[l_0_6] = function()
  local l_1_0 = this:Lookup("", "")
  l_1_0:RemoveItem("Handle_Role")
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("UI_SCALED")
end

l_0_5 = Moon_SkillBuff
l_0_6 = "OnEvent"
l_0_5[l_0_6] = function(l_2_0)
  -- upvalues: l_0_2 , l_0_3
  local l_2_1 = GetClientPlayer()
  if not l_2_1 then
    return 
  end
  if not Moon_SkillBuff.bOpen then
    return 
  end
  local l_2_2 = GetTargetHandle(l_2_1.GetTarget())
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if (l_2_2 and arg0 == l_2_2.dwID and Moon_SkillBuff.bTarget) or arg0 == l_2_1.dwID and Moon_SkillBuff.bSelf then
    if arg7 then
      Moon_SkillBuff.UpdateBuff(arg0)
    end
  else
    local l_2_3 = "debuff"
    if arg3 then
      l_2_3 = "buff"
    end
    Moon_SkillBuff.UpdateSingle(arg0, arg1, l_2_3, arg4, arg5, arg6, arg8, arg9)
  end
  do return end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_2_0 == "DO_SKILL_CAST" and arg0 == l_2_1.dwID and Moon_SkillBuff.bTarget and name == "���ǹ���" then
    Moon_SkillBuff.DeleteQixing(l_2_1.dwID)
  end
  do return end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_2_0 == "SYS_MSG" and arg0 == "UI_OME_DEATH_NOTIFY" then
    Moon_SkillBuff.RemoveRole(arg1)
  end
  do return end
  if l_2_0 == "NPC_ENTER_SCENE" then
    if not Moon_SkillBuff.bSelf then
      return 
    end
    local l_2_4 = arg0
    local l_2_5 = GetNpc(l_2_4)
    local l_2_6 = l_0_2[l_2_5.dwTemplateID]
    if not l_2_6 then
      return 
    end
    if not l_2_5.dwEmployer or l_2_5.dwEmployer == 0 or l_2_5.dwEmployer ~= l_2_1.dwID then
      return 
    end
    local l_2_7 = l_2_6.dwSkillID
    local l_2_8 = l_2_1.GetSkillLevel(l_2_7)
    if l_0_3[l_2_7] and l_2_4 == l_0_3[l_2_7].dwNpcID then
      Moon_SkillBuff.UpdateSingle(l_2_1.dwID, false, "qcskill", l_2_7, 0, l_0_3[l_2_7].dwEndTime, l_2_8)
    else
      local l_2_9 = l_2_6.dwTime * 16
      local l_2_10 = l_0_3
      local l_2_11 = {}
      l_2_11.dwTime = l_2_9
      l_2_11.dwNpcID = l_2_4
      l_2_11.dwEndTime = GetLogicFrameCount() + l_2_9
      l_2_10[l_2_7] = l_2_11
      l_2_10 = Moon_SkillBuff
      l_2_10 = l_2_10.UpdateQC
      l_2_10()
      l_2_10 = Moon_SkillBuff
      l_2_10 = l_2_10.UpdateSingle
      l_2_11 = l_2_1.dwID
      l_2_10(l_2_11, false, "qcskill", l_2_7, 0, l_0_3[l_2_7].dwEndTime, l_2_8)
    end
  elseif l_2_0 == "UI_SCALED" then
    Moon_SkillBuff.UpdateAnchor(this)
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "UpdateQC"
l_0_5[l_0_6] = function()
  -- upvalues: l_0_3
  local l_3_0, l_3_1 = nil, nil
  local l_3_2 = GetClientPlayer()
  local l_3_3 = nil
  if Station.Lookup("Normal/Moon_SkillBuff"):Lookup("", ""):Lookup(tostring(l_3_2.dwID)) then
    local l_3_4 = nil
    local l_3_5 = nil
    local l_3_6 = nil
  end
  if Station.Lookup("Normal/Moon_SkillBuff"):Lookup("", ""):Lookup(tostring(l_3_2.dwID)):Lookup("Handle_TotalList"):GetItemCount() >= 3 then
    for l_3_10 = 0, Station.Lookup("Normal/Moon_SkillBuff"):Lookup("", ""):Lookup(tostring(l_3_2.dwID)):Lookup("Handle_TotalList"):GetItemCount() - 1 do
      local l_3_7, l_3_8 = , 0
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_3_6:Lookup(R12_PC30) and l_3_6:Lookup(R12_PC30).Type == "qcskill" then
        if not l_3_1 or l_3_6:Lookup(R12_PC30).endTime < l_3_1 then
          l_3_1 = l_3_6:Lookup(R12_PC30).endTime
          l_3_0 = l_3_6:Lookup(R12_PC30).id
        end
        l_3_8 = l_3_8 + 1
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

  end
  if l_3_8 >= 3 and l_3_0 then
    Moon_SkillBuff.UpdateSingle(l_3_2.dwID, true, "qcskill", l_3_0)
    l_0_3[l_3_0] = nil
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "RemoveRole"
l_0_5[l_0_6] = function(l_4_0)
  local l_4_1 = false
  local l_4_2 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_4_3 = l_4_2:Lookup("", "")
  local l_4_4 = l_4_3:GetItemCount()
  for l_4_8 = l_4_4 - 1, 0, -1 do
    local l_4_9 = l_4_3:Lookup(l_4_8)
    if l_4_9 and l_4_9.id == l_4_0 then
      l_4_1 = true
      l_4_3:RemoveItem(l_4_8)
    end
  end
  if l_4_1 then
    Moon_SkillBuff.UpdateAllPos()
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "Clear"
l_0_5[l_0_6] = function(l_5_0, l_5_1)
  local l_5_2 = false
  local l_5_3 = function(l_6_0, l_6_1)
    if not IsEmpty(l_6_1) then
      for l_6_5,l_6_6 in pairs(l_6_1) do
        if tonumber(l_6_0:GetName()) == l_6_6.dwID then
          return true
        end
      end
    end
    return false
  end
  local l_5_4 = l_5_0:GetItemCount()
  for l_5_8 = l_5_4 - 1, 0, -1 do
    local l_5_9 = l_5_0:Lookup(l_5_8)
    if l_5_9 and not l_5_3(l_5_9, l_5_1) and (l_5_9.Type == "buff" or l_5_9.Type == "debuff") then
      l_5_0:RemoveItem(l_5_8)
      l_5_2 = true
    end
  end
  return l_5_2
end

l_0_5 = Moon_SkillBuff
l_0_6 = "UpdateBuff"
l_0_5[l_0_6] = function(l_6_0)
  -- upvalues: l_0_4
  local l_6_1 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_6_2 = l_6_1:Lookup("", "")
  local l_6_4 = l_6_2:Lookup(tostring(l_6_0))
  if not Moon_SkillBuff.GetRole(l_6_0) then
    return 
  end
  if not l_6_4 then
    l_6_4 = l_6_2:AppendItemFromIni(l_0_4, "Handle_Role", tostring(l_6_0))
    local l_6_3 = nil
    l_6_4.id = l_6_0
    l_6_4:Lookup("Handle_TotalList"):Clear()
  end
  local l_6_5 = nil
  if not l_6_5.GetBuffList() then
    local l_6_6, l_6_7, l_6_9, l_6_10, l_6_11, l_6_17, l_6_18 = l_6_4:Lookup("Handle_TotalList"), {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_6_6:GetItemCount() > 0 then
    local l_6_8 = nil
  end
  if Moon_SkillBuff.Clear(l_6_6, l_6_7) then
    Moon_SkillBuff.UpdateRoleSize(l_6_8)
    Moon_SkillBuff.UpdateAllPos()
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_6_7 then
    for l_6_15,l_6_16 in pairs(l_6_7) do
      local l_6_12, l_6_13 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_6_18.bCanCancel then
        Moon_SkillBuff.UpdateSingle(l_6_5.dwID, false, "buff", l_6_18.dwID, l_6_18.nStackNum, l_6_18.nEndFrame, l_6_18.nLevel, l_6_18.dwSkillSrcID)
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      else
        Moon_SkillBuff.UpdateSingle(l_6_5.dwID, false, "debuff", l_6_18.dwID, l_6_18.nStackNum, l_6_18.nEndFrame, l_6_18.nLevel, l_6_18.dwSkillSrcID)
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_6_12:GetItemCount() <= 0 then
    l_6_2:RemoveItem(tostring(l_6_0))
    Moon_SkillBuff.UpdateAllPos()
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "DeleteQixing"
l_0_5[l_0_6] = function(l_7_0)
  local l_7_1 = false
  local l_7_2 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_7_3 = l_7_2:Lookup("", "")
  local l_7_4 = l_7_3:GetItemCount()
  for l_7_8 = l_7_4 - 1, 0, -1 do
    local l_7_9 = l_7_3:Lookup(l_7_8)
    if l_7_9 then
      local l_7_10 = false
      local l_7_11 = l_7_9:Lookup("Handle_TotalList")
      for l_7_15 = l_7_11:GetItemCount() - 1, 0, -1 do
        local l_7_16 = l_7_11:Lookup(l_7_15)
        if l_7_16 and l_7_16.szName == "���ǹ���" and l_7_16.dwSkillSrcID == l_7_0 then
          l_7_11:RemoveItem(l_7_15)
          l_7_10 = true
          l_7_1 = true
        end
      end
      if l_7_11:GetItemCount() <= 0 then
        l_7_3:RemoveItem(l_7_8)
        l_7_1 = true
      end
    elseif l_7_10 then
      Moon_SkillBuff.UpdateRoleSize(l_7_11)
    end
  end
  if l_7_1 then
    Moon_SkillBuff.UpdateAllPos()
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "DeleteBuff"
l_0_5[l_0_6] = function(l_8_0, l_8_1)
  local l_8_2 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_8_3 = l_8_2:Lookup("", "")
  local l_8_4 = l_8_3:Lookup(tostring(l_8_0))
  if not l_8_4 then
    return 
  end
  do return end
  local l_8_5 = type(l_8_1)
  local l_8_6 = l_8_4:Lookup("Handle_TotalList")
  local l_8_7 = l_8_6:GetItemCount()
  for l_8_11 = l_8_7 - 1, 0, -1 do
    local l_8_12 = l_8_6:Lookup(l_8_11)
    if (l_8_5 == "number" and l_8_12.id == l_8_1) or l_8_12.szName == l_8_1 then
      l_8_6:RemoveItem(l_8_11)
    end
  end
  if l_8_6:GetItemCount() <= 0 then
    l_8_3:RemoveItem(l_8_4:GetName())
  else
    Moon_SkillBuff.UpdateRoleSize(l_8_6)
  end
  Moon_SkillBuff.UpdateAllPos()
end

l_0_5 = Moon_SkillBuff
l_0_6 = "IsMonnitorBuff"
l_0_5[l_0_6] = function(l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5)
  local l_9_6 = GetClientPlayer()
  local l_9_10 = l_9_6.dwID == l_9_0
  local l_9_11 = Moon_SkillBuff.IsCurrentPlayerTarget(l_9_0)
  local l_9_12 = (Moon_SkillBuff.GetSchoolTitle(l_9_6))
   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_9_10 and l_9_11 then
    local l_9_13 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if Moon_SkillBuff.tShield["ͨ��"][l_9_4] or Moon_SkillBuff.tShield[l_9_12][l_9_4] or l_9_13 and Moon_SkillBuff.tShield[l_9_13][l_9_4] then
      return false
    end
    if not l_9_5 == l_9_6.dwID and l_9_5 ~= 0 and l_9_4 == "���ǹ���" and l_9_6.IsInParty() and l_9_6.IsPlayerInMyParty(l_9_5) then
      Moon_SkillBuff.DeleteQixing(l_9_5)
      local l_9_17, l_9_18 = , true
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: unhandled construct in 'if'

    if l_9_13 and l_9_3 == "debuff" and not l_9_18 and not l_9_2 then
      return false
    end
    do return end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_9_1 and not l_9_2 and l_9_0 ~= l_9_6.dwID and not l_9_18 then
      return false
    end
    do
      local l_9_19 = nil
      if not Moon_SkillBuff.GetBuffType(l_9_12, l_9_13, l_9_4) or Moon_SkillBuff.GetBuffType(l_9_12, l_9_13, l_9_4) ~= l_9_3 then
        return false
      end
      return true
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 29 
end

l_0_5 = Moon_SkillBuff
l_0_6 = "GetBuffType"
l_0_5[l_0_6] = function(l_10_0, l_10_1, l_10_2)
  local l_10_3 = Moon_SkillBuff.MonitorBuff
  local l_10_4 = nil
  if l_10_0 ~= "ͨ��" and (not l_10_1 or not l_10_1 or l_10_1 ~= "ͨ��") then
    l_10_4 = l_10_3["ͨ��"][l_10_2]
  end
  if l_10_4 then
    return l_10_4
  end
  if l_10_1 and l_10_1 == l_10_0 then
    l_10_4 = l_10_3[l_10_1][l_10_2]
  else
    l_10_4 = l_10_3[l_10_0][l_10_2]
  end
  if l_10_1 and not l_10_4 then
    l_10_4 = l_10_3[l_10_1][l_10_2]
  end
  return l_10_4
end

l_0_5 = Moon_SkillBuff
l_0_6 = "UpdateSingle"
l_0_5[l_0_6] = function(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4, l_11_5, l_11_6, l_11_7)
  -- upvalues: l_0_4
  local l_11_8 = nil
  if not l_11_7 then
    l_11_8 = 0
  end
  local l_11_9 = nil
  if not l_11_6 then
    l_11_9 = 0
  end
  if l_11_9 == 0 then
    l_11_9 = 1
  end
  local l_11_10 = GetClientPlayer()
  local l_11_11 = ""
  local l_11_12 = false
  if l_11_2 == "buff" or l_11_2 == "debuff" then
    l_11_11 = Table_GetBuffName(l_11_3, l_11_9)
    l_11_12 = true
    if not Table_BuffNeedShowTime(l_11_3, l_11_9) then
      return 
    end
  elseif l_11_2 == "qcskill" then
    l_11_11 = Table_GetSkillName(l_11_3, l_11_9)
  end
  if not Moon_SkillBuff.IsMonnitorBuff(l_11_0, l_11_12, l_11_1, l_11_2, l_11_11, l_11_8) then
    return 
  end
  local l_11_13 = true
  if l_11_2 == "debuff" then
    l_11_13 = false
  end
  if l_11_1 then
    Moon_SkillBuff.DeleteBuff(l_11_0, l_11_3)
  else
    local l_11_14 = Station.Lookup("Normal/Moon_SkillBuff")
    do
      local l_11_15 = l_11_14:Lookup("", "")
      local l_11_17 = l_11_15:Lookup(tostring(l_11_0))
      if not Moon_SkillBuff.GetRole(l_11_0) then
        return 
      end
      if not l_11_17 then
        l_11_17 = l_11_15:AppendItemFromIni(l_0_4, "Handle_Role", tostring(l_11_0))
        local l_11_16 = nil
        l_11_17.id = l_11_0
        l_11_17:Lookup("Handle_TotalList"):Clear()
        l_11_17:FormatAllItemPos()
      end
      local l_11_18 = nil
      local l_11_20 = nil
      if not l_11_17:Lookup("Handle_TotalList"):Lookup(tostring(l_11_3)) then
        local l_11_19 = l_11_20:AppendItemFromIni(l_0_4, "HandleBuff", tostring(l_11_3))
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_11_21 = nil
      if l_11_2 == "qcskill" then
        l_11_19:Lookup("Boxico"):SetObject(UI_OBJECT_SKILL, l_11_3, l_11_9)
        l_11_19:Lookup("Boxico"):SetObjectIcon(Table_GetSkillIconID(l_11_3, l_11_9))
        if true then
          l_11_19:Lookup("Boxico").OnItemMouseEnter = function()
          -- upvalues: l_11_21
          l_11_21:SetObjectMouseOver(1)
          local l_12_0, l_12_1 = l_11_21:GetAbsPos()
          local l_12_2, l_12_3 = l_11_21:GetSize()
          local l_12_4, l_12_5 = l_11_21:GetObjectData()
          local l_12_6 = OutputSkillTip
          local l_12_7 = l_12_4
          local l_12_8 = l_12_5
          do
            local l_12_9 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_12_6(l_12_7, l_12_8, l_12_9, false)
          end
           -- WARNING: undefined locals caused missing assignments!
        end
        end
      else
        l_11_19:Lookup("Boxico").nCount = l_11_4
        l_11_19:Lookup("Boxico").bCanCancel = l_11_13
        l_11_19:Lookup("Boxico").dwBuffID = l_11_3
        l_11_19:Lookup("Boxico").nLevel = l_11_9
        l_11_19:Lookup("Boxico").bShowTime = Table_BuffNeedShowTime(l_11_3, l_11_9)
        l_11_19:Lookup("Boxico"):SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_11_3)
        l_11_19:Lookup("Boxico"):SetObjectIcon(Table_GetBuffIconID(l_11_3, l_11_9))
        if l_11_4 > 1 then
          l_11_19:Lookup("Boxico"):SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
          l_11_19:Lookup("Boxico"):SetOverTextFontScheme(0, 16)
          l_11_19:Lookup("Boxico"):SetOverText(0, l_11_4)
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

      end
      if true then
        l_11_19:Lookup("Boxico").OnItemMouseEnter = function()
        -- upvalues: l_11_3
        this:SetObjectMouseOver(1)
        local l_13_0 = math.floor(this.nEndFrame - GetLogicFrameCount()) / 16 + 1
        local l_13_1, l_13_2 = this:GetAbsPos()
        local l_13_3, l_13_4 = this:GetSize()
        local l_13_5 = OutputBuffTip
        local l_13_6 = l_11_3
        local l_13_7 = this.dwBuffID
        local l_13_8 = this.nLevel
        local l_13_9 = this.nCount
        if this.bShowTime then
          local l_13_10 = not this.bCanCancel
        end
        local l_13_11 = nil
        local l_13_12 = l_13_0
        l_13_5(l_13_6, l_13_7, l_13_8, l_13_9, l_13_11, l_13_12, {l_13_1, l_13_2, l_13_3, l_13_4})
      end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if true then
        l_11_19:Lookup("Boxico").OnItemMouseHover = l_11_19:Lookup("Boxico").OnItemMouseEnter
        l_11_19:Lookup("Boxico").OnItemMouseLeave = function()
          HideTip()
          this:SetObjectMouseOver(0)
        end
        Moon_SkillBuff.UpdateRoleSize(l_11_20)
        Moon_SkillBuff.UpdateAllPos()
      end
    end
  end
end

l_0_5 = Moon_SkillBuff
l_0_6 = "IsNeedDelQiChang"
l_0_5[l_0_6] = function(l_12_0)
  -- upvalues: l_0_3
  if l_12_0.Type == "qcskill" then
    local l_12_1 = l_12_0.id
    if not l_0_3[l_12_1] or not GetNpc(l_0_3[l_12_1].dwNpcID) then
      return true
    end
  else
    return false
  end
  return false
end

l_0_5 = 0
l_0_6 = Moon_SkillBuff
local l_0_7 = "OnFrameBreathe"
l_0_6[l_0_7] = function()
  -- upvalues: l_0_5 , l_0_3
  l_0_5 = l_0_5 + 1
  if l_0_5 == 3 then
    l_0_5 = 0
  else
    return 
  end
  local l_13_0 = GetClientPlayer()
  if not l_13_0 then
    return 
  end
  local l_13_1 = GetLogicFrameCount()
  for l_13_5,l_13_6 in pairs(l_0_3) do
    if l_13_6.dwEndTime < l_13_1 then
      l_0_3[l_13_5] = nil
    end
  end
  local l_13_7, l_13_26 = Station.Lookup("Normal/Moon_SkillBuff")
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_13_8, l_13_27 = nil
  l_13_8, l_13_27 = l_13_26:GetItemCount, l_13_26
  l_13_8 = l_13_8(l_13_27)
  local l_13_9, l_13_28 = nil
  l_13_27 = false
  local l_13_10, l_13_29 = nil
  if l_13_8 == 0 then
    return 
  end
  l_13_9 = l_13_8 - 1
  l_13_28 = 0
  l_13_10 = -1
  for l_13_29 = l_13_9, l_13_28, l_13_10 do
    local l_13_11, l_13_12, l_13_13, l_13_14 = nil
    l_13_11, l_13_12 = l_13_26:Lookup, l_13_26
    l_13_13 = l_13_29
    l_13_11 = l_13_11(l_13_12, l_13_13)
    local l_13_15 = nil
    if l_13_11 then
      l_13_12 = Moon_SkillBuff
      l_13_12 = l_13_12.GetRole
      l_13_13 = l_13_11.id
      l_13_12 = l_13_12(l_13_13)
      local l_13_16 = nil
      if not l_13_12 then
        l_13_13, l_13_14 = l_13_26:RemoveItem, l_13_26
        l_13_15, l_13_16 = l_13_11:GetName, l_13_11
        l_13_16, l_13_15 = .end, l_13_15(l_13_16)
        l_13_13(l_13_14, l_13_15, l_13_16)
        l_13_27 = true
      end
    else
      l_13_13, l_13_14 = l_13_11:Lookup, l_13_11
      l_13_15 = "TargetName"
      l_13_13 = l_13_13(l_13_14, l_13_15)
      local l_13_17 = nil
      l_13_14, l_13_15 = l_13_13:SetText, l_13_13
      l_13_16 = l_13_12.szName
      l_13_14(l_13_15, l_13_16)
      l_13_14, l_13_15 = l_13_13:SetFontColor, l_13_13
      l_13_16 = GetForceFontColor
      l_13_17 = l_13_11.id
      l_13_17, l_13_16 = .end, l_13_16(l_13_17, l_13_0.dwID)
      l_13_14(l_13_15, l_13_16, l_13_17)
      l_13_14, l_13_15 = l_13_11:Lookup, l_13_11
      l_13_16 = "Handle_TotalList"
      l_13_14 = l_13_14(l_13_15, l_13_16)
      local l_13_18 = nil
      l_13_15, l_13_16 = l_13_14:GetItemCount, l_13_14
      l_13_15 = l_13_15(l_13_16)
      local l_13_19 = nil
      l_13_16 = false
      local l_13_20 = nil
      l_13_17 = l_13_15 - 1
      l_13_18 = 0
      l_13_19 = -1
      for l_13_20 = l_13_17, l_13_18, l_13_19 do
        local l_13_21, l_13_22, l_13_23, l_13_24 = nil
        l_13_21, l_13_22 = l_13_14:Lookup, l_13_14
        l_13_23 = l_13_20
        l_13_21 = l_13_21(l_13_22, l_13_23)
        local l_13_25 = nil
        if l_13_21 then
          l_13_22 = l_13_21.endTime
          if l_13_22 >= l_13_1 then
            l_13_22 = Moon_SkillBuff
            l_13_22 = l_13_22.IsNeedDelQiChang
            l_13_23 = l_13_21
            l_13_22 = l_13_22(l_13_23)
          if l_13_22 then
            end
          end
          l_13_22, l_13_23 = l_13_14:RemoveItem, l_13_14
          l_13_24 = l_13_20
          l_13_22(l_13_23, l_13_24)
          l_13_16 = true
          l_13_27 = true
        end
        do return end
        l_13_22 = Moon_SkillBuff
        l_13_22 = l_13_22.UpdateInfo
        l_13_23 = l_13_21
        l_13_22(l_13_23)
      end
    end
    if l_13_16 then
      if l_13_14:GetItemCount() <= 0 then
        l_13_26:RemoveItem(l_13_29)
      end
    else
      Moon_SkillBuff.UpdateRoleSize(l_13_14)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  if l_13_27 then
    Moon_SkillBuff.UpdateAllPos()
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_6 = Moon_SkillBuff
l_0_7 = "UpdateInfo"
l_0_6[l_0_7] = function(l_14_0)
  -- upvalues: l_0_3
  local l_14_1 = ""
  if l_14_0.Type == "qcskill" then
    l_14_1 = Table_GetSkillName(l_14_0.id, l_14_0.level)
  else
    l_14_1 = Table_GetBuffName(l_14_0.id, l_14_0.level)
  end
  local l_14_2 = Moon_SkillBuff.GetBuffTime(l_14_0.endTime)
  local l_14_3 = l_14_0:Lookup("Text_Time")
  l_14_3:SetText(l_14_2 .. " - " .. l_14_1)
  local l_14_4 = GetClientPlayer()
  local l_14_5 = l_14_0:GetParent()
  local l_14_6 = l_14_5.id
  local l_14_7 = l_14_0:Lookup("Image_2")
  local l_14_8 = l_14_0:Lookup("Image_3")
  if l_14_6 == l_14_4.dwID and l_14_0.Type == "debuff" then
    l_14_7 = l_14_0:Lookup("Image_3")
    l_14_8 = l_14_0:Lookup("Image_2")
  end
  l_14_8:Hide()
  l_14_7:Show()
  local l_14_9 = nil
  if l_14_0.Type == "qcskill" then
    l_14_9 = l_0_3[l_14_0.id].dwTime
  else
    l_14_9 = GetBuffTime(l_14_0.id, l_14_0.level)
  end
  local l_14_10 = GetLogicFrameCount()
  local l_14_11 = l_14_0.endTime - l_14_10
  l_14_7:SetPercentage(l_14_11 / l_14_9)
end

l_0_6 = Moon_SkillBuff
l_0_7 = "UpdateAllPos"
l_0_6[l_0_7] = function()
  local l_15_0 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_15_1 = l_15_0:Lookup("", "")
  local l_15_2 = l_15_1:GetItemCount()
  if l_15_2 > 0 then
    for l_15_6 = 0, l_15_2 - 1 do
      local l_15_7 = l_15_1:Lookup(l_15_6)
      if l_15_7 then
        if l_15_6 == 0 then
          l_15_7:SetRelPos(0, 0)
        end
      else
        local l_15_8 = l_15_1:Lookup(l_15_6 - 1)
        local l_15_9, l_15_10 = l_15_8:GetRelPos()
        local l_15_11, l_15_12 = l_15_8:GetSize()
        l_15_7:SetRelPos(l_15_9, l_15_10 + l_15_12)
      end
    end
    l_15_1:FormatAllItemPos()
  else
    l_15_0:SetSize(0, 0)
  end
  local l_15_13 = l_15_1:Lookup(l_15_2 - 1)
  if l_15_13 then
    local l_15_14, l_15_15 = l_15_13:GetRelPos()
    local l_15_16, l_15_17 = l_15_13:GetSize()
    l_15_0:SetSize(l_15_16, l_15_15 + l_15_17)
    l_15_1:SetSize(l_15_16, l_15_15 + l_15_17)
    l_15_0:SetDragArea(0, 0, l_15_16, l_15_15 + l_15_17)
  end
end

l_0_6 = Moon_SkillBuff
l_0_7 = "UpdateRoleSize"
l_0_6[l_0_7] = function(l_16_0)
  local l_16_1 = l_16_0:GetItemCount()
  for l_16_5 = 0, l_16_1 - 1 do
    local l_16_6 = l_16_0:Lookup(l_16_5)
    if l_16_6 then
      l_16_6:SetRelPos(0, l_16_5 * 33)
    end
  end
  l_16_0:FormatAllItemPos()
  l_16_0:SetSize(220, l_16_1 * 35)
  local l_16_7 = l_16_0:GetParent()
  l_16_7:SetSize(240, l_16_1 * 35 + 40)
  l_16_7:Lookup("Image_BG"):SetSize(240, l_16_1 * 35 + 40)
end

l_0_6 = Moon_SkillBuff
l_0_7 = "OnFrameDragEnd"
l_0_6[l_0_7] = function()
  this:CorrectPos()
  Moon_SkillBuff.Anchor = GetFrameAnchor(this)
end

l_0_6 = Moon_SkillBuff
l_0_7 = "UpdateAnchor"
l_0_6[l_0_7] = function(l_18_0)
  l_18_0:SetPoint(Moon_SkillBuff.Anchor.s, 0, 0, Moon_SkillBuff.Anchor.r, Moon_SkillBuff.Anchor.x, Moon_SkillBuff.Anchor.y)
  l_18_0:CorrectPos()
end

l_0_6 = Moon_SkillBuff
l_0_7 = "GetSchoolTitle"
l_0_6[l_0_7] = function(l_19_0)
  local l_19_1 = GetForceTitle(l_19_0.dwForceID)
  if l_19_1 == "����" then
    return "ͨ��"
  else
    return l_19_1
  end
end

l_0_6 = Moon_SkillBuff
l_0_7 = "GetQCSkillTime"
l_0_6[l_0_7] = function(l_20_0, l_20_1)
  if l_20_0 == 363 then
    return 24
  end
  local l_20_2 = GetClientPlayer()
  if not l_20_1 then
    l_20_1 = l_20_2.GetSkillLevel(l_20_0)
  end
  local l_20_3 = Table_GetSkillDesc(l_20_0, l_20_1)
  local l_20_4 = 0
  string.gsub(l_20_3, "<BUFF (%d+) (%d+) time>", function(l_21_0, l_21_1)
    -- upvalues: l_20_4
    if l_21_1 or l_21_1 == "0" then
      l_21_1 = 1
    end
    l_20_4 = math.floor(GetBuffTime(l_21_0, l_21_1) / 16)
  end)
  return l_20_4
end

l_0_6 = Moon_SkillBuff
l_0_7 = "GetRole"
l_0_6[l_0_7] = function(l_21_0)
  local l_21_1 = nil
  if IsPlayer(l_21_0) then
    l_21_1 = GetPlayer(l_21_0)
  else
    l_21_1 = GetNpc(l_21_0)
  end
  return l_21_1
end

l_0_6 = Moon_SkillBuff
l_0_7 = "IsCurrentPlayerTarget"
l_0_6[l_0_7] = function(l_22_0)
  if GetClientPlayer().GetTarget() == TARGET.PLAYER and R3_PC8 == l_22_0 then
    return true
  end
  return false
end

l_0_6 = Moon_SkillBuff
l_0_7 = "FormatTime"
l_0_6[l_0_7] = function(l_23_0, l_23_1)
  if l_23_1 then
    l_23_0 = l_23_0 / GLOBAL.GAME_FPS
  end
  local l_23_2 = math.floor(l_23_0 / 3600)
  l_23_0 = l_23_0 - l_23_2 * 3600
  local l_23_3 = math.floor((l_23_0) / 60)
  l_23_0 = l_23_0 - l_23_3 * 60
  local l_23_4 = math.floor(l_23_0)
  return l_23_2, l_23_3, l_23_4
end

l_0_6 = Moon_SkillBuff
l_0_7 = "GetBuffTime"
l_0_6[l_0_7] = function(l_24_0)
  local l_24_1 = GetLogicFrameCount()
  local l_24_2 = l_24_0 - l_24_1
  local l_24_3, l_24_4, l_24_5 = Moon_SkillBuff.FormatTime(l_24_2, true)
  local l_24_6 = string.format
  local l_24_7 = "%02d:%02d"
  local l_24_8 = l_24_4
  local l_24_9 = l_24_5
  return l_24_6(l_24_7, l_24_8, l_24_9)
end

l_0_6 = Moon_SkillBuff
l_0_7 = "Create"
l_0_6[l_0_7] = function(l_25_0)
  local l_25_1 = GetClientPlayer()
  local l_25_2 = GetTargetHandle(l_25_1.GetTarget())
  local l_25_3 = Station.Lookup("Normal/Moon_SkillBuff")
  local l_25_4 = l_25_3:Lookup("", "")
  local l_25_6 = function()
    -- upvalues: l_25_3 , l_25_1 , l_25_2
    if l_25_3 then
      if l_25_3:IsVisible() then
        return true
      end
    else
      Moon_SkillBuff.UpdateBuff(l_25_1.dwID)
      if l_25_2 then
        Moon_SkillBuff.UpdateBuff(l_25_2.dwID)
      end
      l_25_3:Show()
    end
  end
  local l_25_7 = BoxCheckBox
  local l_25_8 = l_25_0
  local l_25_9 = "Check_Toggle"
  l_25_7 = l_25_7(l_25_8, l_25_9, {txt = "��������Buff��ʱ"})
  l_25_8, l_25_9 = l_25_7:OnCheck, l_25_7
  l_25_8(l_25_9, function()
    -- upvalues: l_25_5 , l_25_0
    Moon_SkillBuff.bOpen = true
    l_25_5()
    local l_27_0 = l_25_0:Lookup("Check_MonitorSelf")
    l_27_0:Enable(true)
    l_27_0:Lookup("", "Text_CheckBox"):SetFontColor(255, 255, 255)
    local l_27_1 = l_25_0:Lookup("Check_MonitorTarget")
    l_27_1:Enable(true)
    l_27_1:Lookup("", "Text_CheckBox"):SetFontColor(255, 255, 255)
  end)
  l_25_8 = function()
    -- upvalues: l_25_3 , l_25_4 , l_25_0
    Moon_SkillBuff.bOpen = false
    if l_25_3 then
      l_25_4:Clear()
      l_25_3:Hide()
    end
    local l_28_0 = l_25_0:Lookup("Check_MonitorSelf")
    l_28_0:Enable(false)
    l_28_0:Lookup("", "Text_CheckBox"):SetFontColor(188, 188, 188)
    local l_28_1 = l_25_0:Lookup("Check_MonitorTarget")
    l_28_1:Enable(false)
    l_28_1:Lookup("", "Text_CheckBox"):SetFontColor(188, 188, 188)
  end
  l_25_9(l_25_7, l_25_8)
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_25_10 = l_25_0
  local l_25_11 = "Btn_Manager"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_25_10 = l_25_9
  l_25_11 = OpenSkillBuffManager
  l_25_9(l_25_10, l_25_11)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_25_10 = l_25_0
  l_25_11 = "Check_MonitorSelf"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_25_10, l_25_11 = l_25_9:SetBoolValue, l_25_9
  l_25_10(l_25_11, Moon_SkillBuff, "bSelf")
  l_25_10, l_25_11 = l_25_9:OnCheck, l_25_9
  l_25_10(l_25_11, function()
    -- upvalues: l_25_1
    Moon_SkillBuff.UpdateBuff(l_25_1.dwID)
  end)
  l_25_10, l_25_11 = l_25_9:UnCheck, l_25_9
  l_25_10(l_25_11, function()
    -- upvalues: l_25_1
    Moon_SkillBuff.RemoveRole(l_25_1.dwID)
  end)
  l_25_10 = BoxCheckBox
  l_25_11 = l_25_0
  do
    local l_25_12 = "Check_MonitorTarget"
    l_25_10 = l_25_10(l_25_11, l_25_12, {txt = "���ü���Ŀ��", x = 150, y = 30})
    l_25_11, l_25_12 = l_25_10:SetBoolValue, l_25_10
    l_25_11(l_25_12, Moon_SkillBuff, "bTarget")
    l_25_11, l_25_12 = l_25_10:OnCheck, l_25_10
    l_25_11(l_25_12, function()
    -- upvalues: l_25_2
    if l_25_2 then
      Moon_SkillBuff.UpdateBuff(l_25_2.dwID)
    end
  end)
    l_25_11, l_25_12 = l_25_10:UnCheck, l_25_10
    l_25_11(l_25_12, function()
    -- upvalues: l_25_4 , l_25_1
    local l_32_0 = l_25_4:GetItemCount()
    if l_32_0 > 0 then
      l_25_4:Clear()
      Moon_SkillBuff.UpdateBuff(l_25_1.dwID)
    end
  end)
    l_25_11 = Moon_SkillBuff
    l_25_11 = l_25_11.bOpen
    if l_25_11 then
      l_25_11, l_25_12 = l_25_7:Check, l_25_7
      l_25_11(l_25_12, true)
    else
      l_25_11 = l_25_8
      l_25_11()
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_6 = RegisterMoonButton
l_0_7 = "Moon_SkillBuff"
l_0_6(l_0_7, 404, "����Buff", "General", Moon_SkillBuff.Create)
l_0_6 = Moon_SkillBuff
l_0_7 = "AddBuff"
l_0_6[l_0_7] = function(l_26_0)
  -- upvalues: l_0_1
  local l_26_1 = "AddSkillBuff" .. l_0_1
  l_0_1 = l_0_1 + 1
  local l_26_2 = BoxSetFrame
  local l_26_3 = l_26_1
  local l_26_4 = {}
  l_26_4.w = 350
  l_26_4.h = 270
  l_26_4.bdrag = true
  l_26_2 = l_26_2(l_26_3, l_26_4)
  l_26_3, l_26_4 = l_26_2:Center, l_26_2
  l_26_3(l_26_4)
  l_26_3, l_26_4 = l_26_2:ui, l_26_2
  l_26_3 = l_26_3(l_26_4)
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_26_5 = BoxLabel
  local l_26_6 = l_26_4
  local l_26_7 = "Text_Title"
  local l_26_8 = "���Ӽ���"
  local l_26_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_26_10 = 0
  local l_26_11 = {}
  l_26_11.nW = 350
  l_26_11.nH = 30
  l_26_11.nHAlign = 1
  l_26_5(l_26_6, l_26_7, l_26_8, l_26_9, l_26_10, l_26_11)
  l_26_5 = BoxLabel
  l_26_6 = l_26_4
  l_26_7 = "Text_BuffName"
  l_26_8 = "Buff���ƣ�"
  l_26_10 = 40
  l_26_11 = 50
  l_26_5(l_26_6, l_26_7, l_26_8, l_26_9)
  l_26_9 = {l_26_10, l_26_11}
  l_26_5 = BoxEdit
  l_26_6 = l_26_3
  l_26_7 = "Edit_BuffName"
  l_26_5, l_26_8 = l_26_5(l_26_6, l_26_7, l_26_8), {x = 40, y = 80, w = 250, h = 30}
  l_26_6 = BoxLabel
  l_26_7 = l_26_4
  l_26_8 = "Text_BuffType"
  l_26_9 = "Buff���ͣ�"
  l_26_11 = 40
  l_26_6(l_26_7, l_26_8, l_26_9, l_26_10)
  l_26_10 = {l_26_11, 125}
  l_26_6 = "debuff"
  l_26_7 = BoxRadioBox
  l_26_8 = l_26_3
  l_26_9 = "RadioBox_Buff"
  l_26_11 = l_26_6 == "buff"
  l_26_7, l_26_10 = l_26_7(l_26_8, l_26_9, l_26_10), {x = 40, y = 160, txt = "����Buff", bchecked = l_26_11, group = "bufftype"}
  l_26_7, l_26_8 = l_26_7:OnCheck, l_26_7
  l_26_9 = function()
    -- upvalues: l_26_6
    l_26_6 = "buff"
  end
  l_26_7 = l_26_7(l_26_8, l_26_9)
  l_26_8 = BoxRadioBox
  l_26_9 = l_26_3
  l_26_10 = "RadioBox_Debuff"
  l_26_8, l_26_11 = l_26_8(l_26_9, l_26_10, l_26_11), {x = 180, y = 160, txt = "����Buff", bchecked = l_26_6 == "debuff", group = "bufftype"}
  l_26_8, l_26_9 = l_26_8:OnCheck, l_26_8
  l_26_10 = function()
    -- upvalues: l_26_6
    l_26_6 = "debuff"
  end
  l_26_8(l_26_9, l_26_10)
  l_26_8 = BoxButton
  l_26_9 = l_26_3
  l_26_10 = "Btn_Sure"
  l_26_8, l_26_11 = l_26_8(l_26_9, l_26_10, l_26_11), {x = 60, w = 90, h = 25, y = 210, txt = "ȷ��"}
  l_26_8, l_26_9 = l_26_8:OnClick, l_26_8
  l_26_10 = function()
    -- upvalues: l_26_5 , l_26_0 , l_26_6 , l_26_1
    local l_29_0 = l_26_5:GetText()
    if l_29_0 == "" then
      MsgBox("������Buff���ƣ�")
      return 
    end
    if Moon_SkillBuff.MonitorBuff[l_26_0][l_29_0] then
      MsgBox("�޷����ӣ���Buff�Ѿ�������ˣ�")
      return 
    end
    Moon_SkillBuff.MonitorBuff[l_26_0][l_29_0] = l_26_6
    SkillBuffManager.UpdateList()
    Wnd.CloseWindow(l_26_1)
  end
  l_26_8(l_26_9, l_26_10)
  l_26_8 = BoxButton
  l_26_9 = l_26_3
  l_26_10 = "Btn_Cancel"
  l_26_8, l_26_11 = l_26_8(l_26_9, l_26_10, l_26_11), {x = 180, w = 90, h = 25, y = 210, txt = "ȡ��"}
  l_26_8, l_26_9 = l_26_8:OnClick, l_26_8
  l_26_10 = function()
    -- upvalues: l_26_1
    Wnd.CloseWindow(l_26_1)
  end
  l_26_8(l_26_9, l_26_10)
  l_26_8, l_26_9 = l_26_4:FormatAllItemPos, l_26_4
  l_26_8(l_26_9)
end

l_0_6 = RegisterEvent
l_0_7 = "CUSTOM_DATA_LOADED"
l_0_6(l_0_7, function()
  -- upvalues: l_0_0
  if arg0 == "Role" then
    if Moon_SkillBuff.nVersion < Moon_SkillBuff.nCurrVersion then
      Moon_SkillBuff.MonitorBuff = clone(l_0_0)
      Moon_SkillBuff.nVersion = Moon_SkillBuff.nCurrVersion
    end
    for l_27_3 in pairs(Moon_SkillBuff.MonitorBuff) do
      if not Moon_SkillBuff.tShield[l_27_3] then
        Moon_SkillBuff.tShield[l_27_3] = {}
      end
    end
    do
      local l_27_4, l_27_5 = Station.Lookup("Normal/Moon_SkillBuff")
      if not l_27_4 then
        return 
      end
      l_27_5 = Moon_SkillBuff
      l_27_5 = l_27_5.bOpen
      if l_27_5 then
        l_27_5(l_27_4)
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_27_5(l_27_4)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

    end
    l_27_5(l_27_4)
  end
end
)
l_0_6 = Wnd
l_0_7 = "OpenWindow"
l_0_6 = l_0_6[l_0_7]
l_0_7 = l_0_4
l_0_6 = l_0_6(l_0_7, "Moon_SkillBuff")
l_0_6, l_0_7 = l_0_6:Hide, l_0_6
l_0_6(l_0_7)
l_0_7 = "szForce"
SkillBuffManager, l_0_6 = l_0_6, {[l_0_7] = "ͨ��"}
l_0_6 = SkillBuffManager
l_0_7 = "OnFrameCreate"
l_0_6[l_0_7] = function()
  this:EnableDrag(false)
  InitFrameAutoPosInfo(this, 1, nil, nil, function()
    Wnd.CloseWindow("SkillBuffManager")
  end)
end

l_0_6 = SkillBuffManager
l_0_7 = "OnItemMouseEnter"
l_0_6[l_0_7] = function()
  if not this.bItem then
    return 
  end
  this.bIn = true
  if not this.bSel then
    this:Lookup("Image_Over"):Show()
  end
end

l_0_6 = SkillBuffManager
l_0_7 = "OnItemMouseLeave"
l_0_6[l_0_7] = function()
  if not this.bItem then
    return 
  end
  this.bIn = false
  if not this.bSel then
    this:Lookup("Image_Over"):Hide()
  end
end

l_0_6 = SkillBuffManager
l_0_7 = "OnItemLButtonUp"
l_0_6[l_0_7] = function()
  if not this.bItem then
    return 
  end
  this.bSel = true
  local l_31_0 = this:GetParent()
  local l_31_1 = l_31_0:GetItemCount() - 1
  for l_31_5 = 0, l_31_1 do
    local l_31_6 = l_31_0:Lookup(l_31_5)
    if l_31_6 then
      if l_31_6:GetName() == this:GetName() then
        this:Lookup("Image_Sel"):Show()
        this:Lookup("Image_Over"):Hide()
      end
    else
      l_31_6.bSel = false
      l_31_6:Lookup("Image_Sel"):Hide()
    end
  end
end

l_0_6 = SkillBuffManager
l_0_7 = "OnItemRButtonClick"
l_0_6[l_0_7] = function()
  if not this.bItem then
    return 
  end
  local l_32_0 = SkillBuffManager.szForce
  local l_32_1 = this.szName
  local l_32_2 = {}
  local l_32_3 = {}
  l_32_3.szOption = "ɾ��"
  l_32_3.fnAction = function()
    -- upvalues: l_32_0 , l_32_1
    Moon_SkillBuff.MonitorBuff[l_32_0][l_32_1] = nil
    SkillBuffManager.UpdateList()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_32_3 = PopupMenu
  l_32_3(l_32_2)
end

l_0_6 = SkillBuffManager
l_0_7 = "OnItemLButtonClick"
l_0_6[l_0_7] = function()
  local l_33_0 = this:GetName()
  if l_33_0 == "Image_CheckBox" then
    local l_33_1 = this:GetParent()
    local l_33_2 = l_33_1.szName
    local l_33_3 = SkillBuffManager.szForce
    if this:GetFrame() == 6 then
      this:SetFrame(5)
      Moon_SkillBuff.tShield[l_33_3][l_33_2] = true
    end
  else
    this:SetFrame(6)
    Moon_SkillBuff.tShield[l_33_3][l_33_2] = nil
  end
end

l_0_7 = 1
l_0_7 = 2
l_0_7 = 3
l_0_7 = function(l_34_0, l_34_1)
  -- upvalues: l_0_6
  local l_34_2 = l_0_6[l_34_0[2]]
  local l_34_3 = l_0_6[l_34_1[2]]
  if not l_34_2 or not l_34_3 then
    Output(l_34_0, l_34_1)
  end
  return l_34_2 < l_34_3
end

local l_0_8 = SkillBuffManager
local l_0_9 = "pairsByVal"
l_0_8[l_0_9] = function(l_35_0, l_35_1)
  do
    local l_35_2 = {}
    for l_35_6,l_35_7 in pairs(l_35_0) do
      local l_35_8 = table.insert
      local l_35_9 = l_35_2
      local l_35_10 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_35_8(l_35_9, l_35_10)
    end
    table.sort(l_35_2, l_35_1)
    return function()
    -- upvalues: l_35_3 , l_35_2
    l_35_3 = l_35_3 + 1
    if l_35_2[l_35_3] == nil then
      return nil
    else
      return l_35_2[l_35_3][1], l_35_2[l_35_3][2]
    end
  end
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_8 = SkillBuffManager
l_0_9 = "UpdateList"
l_0_8[l_0_9] = function()
  -- upvalues: l_0_7
  if not Station.Lookup("Normal/SkillBuffManager") then
    return 
  end
  local l_36_0 = SkillBuffManager.sBuffs.handle
  l_36_0:Clear()
  local l_36_1 = SkillBuffManager.szForce
  do
    local l_36_2 = 0
    for l_36_6,l_36_7 in SkillBuffManager.pairsByVal(Moon_SkillBuff.MonitorBuff[l_36_1], l_0_7) do
      local l_36_8 = BoxHandle
      local l_36_9 = l_36_0
      local l_36_10 = (tostring(l_36_2))
      local l_36_11 = nil
      local l_36_12 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_36_13 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_36_14 = 30
      local l_36_15 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_36_16 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if not l_36_10 then
        l_36_10(l_36_11, l_36_12)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_36_7 == "debuff" then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_36_7 == "qcskill" then
        local l_36_17 = l_36_11
        local l_36_18 = {}
        l_36_18.nW = 330
        l_36_18.nH = 30
        l_36_12(l_36_13, l_36_14, l_36_15, l_36_16, l_36_17, l_36_18)
        l_36_16 = {30, 2}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_16 = 0
        l_36_17 = nil
        local l_36_19 = {}
        l_36_19.nAlpha = 230
         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_18 = {330, 30}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_12(l_36_13)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_16 = 5
        l_36_17 = nil
        l_36_19 = 330
         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_19, l_36_18 = {nAlpha = 230}, {l_36_19, 30}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_12(l_36_13)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_36_12(l_36_13)
        l_36_2 = l_36_2 + 1
      end
      l_36_0:FormatAllItemPos()
      SkillBuffManager.sBuffs:Update()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 74 
end

l_0_8 = function()
  -- upvalues: l_0_0
  if Station.Lookup("Normal/SkillBuffManager") then
    return 
  end
  local l_37_0 = BoxFrame
  local l_37_1 = "SkillBuffManager"
  local l_37_2 = {}
  l_37_2.title = "����Buff����"
  l_37_2.bglobal = true
  l_37_0 = l_37_0(l_37_1, l_37_2)
  l_37_1, l_37_2 = l_37_0:ui, l_37_0
  l_37_1 = l_37_1(l_37_2)
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_37_3 = BoxComboBox
  local l_37_4 = l_37_1
  local l_37_5 = "ComboBox_ForceList"
  local l_37_6 = {}
  l_37_6.x = 20
  l_37_6.y = 40
  l_37_6.w = 180
  l_37_6.h = 25
  l_37_6.txt = SkillBuffManager.szForce
  l_37_3 = l_37_3(l_37_4, l_37_5, l_37_6)
  l_37_4 = BoxButton
  l_37_5 = l_37_1
  l_37_6 = "Btn_Add"
  local l_37_7 = {}
  l_37_7.x = 205
  l_37_7.y = 42
  l_37_7.txt = "����"
  l_37_7.w = 80
  l_37_7.h = 25
  l_37_4 = l_37_4(l_37_5, l_37_6, l_37_7)
  l_37_5 = BoxButton
  l_37_6 = l_37_1
  l_37_7 = "Btn_Reset"
  local l_37_8 = {}
  l_37_8.x = 285
  l_37_8.y = 42
  l_37_8.txt = "����"
  l_37_8.w = 80
  l_37_8.h = 25
  l_37_5 = l_37_5(l_37_6, l_37_7, l_37_8)
  l_37_6 = BoxImage
  l_37_7 = l_37_2
  l_37_8 = "Image_Break1"
  local l_37_9 = "ui/Image/UICommon/CommonPanel.UITex"
  local l_37_10 = 42
  local l_37_11 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_37_12 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_37_13 = {}
  l_37_6(l_37_7, l_37_8, l_37_9, l_37_10, l_37_11, l_37_12, l_37_13)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7(l_37_8, l_37_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_37_14 = {}
  l_37_14.nAlpha = 255
  l_37_7(l_37_8, l_37_9, l_37_10, l_37_11, l_37_12, l_37_13, l_37_14)
  l_37_13, l_37_12 = {380, 7}, {l_37_13, 7}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_12 = 20
  l_37_13 = 467
  l_37_7(l_37_8, l_37_9, l_37_10, l_37_11)
  l_37_11 = {l_37_12, l_37_13}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7(l_37_8, l_37_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7(l_37_8, l_37_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7(l_37_8, l_37_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_7(l_37_8)
end

OpenSkillBuffManager = l_0_8

