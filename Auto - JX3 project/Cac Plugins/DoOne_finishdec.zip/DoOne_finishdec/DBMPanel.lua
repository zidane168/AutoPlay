-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMPanel.lua 

local l_0_0 = {}
l_0_0.s = nil
l_0_0.showMod = ""
l_0_0.ModList = {}
l_0_0.ModData = {}
DBMPanel = l_0_0
l_0_0 = RegisterCustomData
l_0_0("DBMPanel.ModList")
DBMPanel_Set, l_0_0 = l_0_0, {bOn = false, bSayAlarm = false, nSaySkill = PLAYER_TALK_CHANNEL.NEARBY, nSayBuff = PLAYER_TALK_CHANNEL.NEARBY, bFlashAlarm = true, bBossRollCall = true, bMsgAlarm = true, szRollCallColor = "red"}
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.bOn")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.bSayAlarm")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.nSaySkill")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.nSayBuff")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.bFlashAlarm")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.bBossRollCall")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.szRollCallColor")
l_0_0 = RegisterCustomData
l_0_0("DBMPanel_Set.bMsgAlarm")
l_0_0 = DBMPanel
l_0_0.OnFrameCreate = function()
  DBMPanel.frame = this
  InitFrameAutoPosInfo(this, 2, nil, nil, function()
    CloseDBMPanel()
  end)
end

l_0_0 = DBMPanel
l_0_0.OnCreate = function(l_2_0)
  local l_2_1 = l_2_0:Lookup("", "")
  BoxBoolCheckBox(l_2_0, "CheckBox_Run", "������������", DBMPanel_Set, "bOn")
  local l_2_2 = BoxButton
  local l_2_3 = l_2_0
  local l_2_4 = "Btn_Option"
  local l_2_5 = {}
  l_2_5.txt = "������"
  l_2_5.x = 120
  l_2_5.y = 0
  l_2_2 = l_2_2(l_2_3, l_2_4, l_2_5)
  l_2_2, l_2_3 = l_2_2:OnClick, l_2_2
  l_2_4 = OpenDBMPanel
  l_2_2(l_2_3, l_2_4)
  l_2_2 = BoxBoolCheckBox
  l_2_3 = l_2_0
  l_2_4 = "CheckBox_BossRollCall"
  l_2_5 = "������������"
  l_2_2 = l_2_2(l_2_3, l_2_4, l_2_5, DBMPanel_Set, "bBossRollCall")
  l_2_2, l_2_3 = l_2_2:SetRelPos, l_2_2
  l_2_4 = 0
  l_2_5 = 30
  l_2_2(l_2_3, l_2_4, l_2_5)
  l_2_2 = BoxLabel
  l_2_3 = l_2_1
  l_2_4 = "label1"
  l_2_5 = "��ʾ����"
  local l_2_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_2(l_2_3, l_2_4, l_2_5, l_2_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_2(l_2_3, l_2_4, l_2_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_2(l_2_3, l_2_4, l_2_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_2(l_2_3, l_2_4, l_2_5, l_2_6, 27)
  l_2_6 = {0, 60}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_6 = DBMPanel_Set
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_2(l_2_3, l_2_4, l_2_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_6 = true
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_6 = "MSG_PARTY"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_6 = PLAYER_TALK_CHANNEL
  l_2_6 = l_2_6.RAID
  l_2_6 = GetMsgFontColor
  l_2_6 = l_2_6("MSG_TEAM", true)
  l_2_5, l_2_4, l_2_3 = {szName = "�Ŷ�Ƶ��", nChannel = l_2_6, color = l_2_6}, {szName = "����Ƶ��", nChannel = l_2_5, color = l_2_5}, {szName = "����Ƶ��", nChannel = l_2_4, color = l_2_4}
  l_2_3 = BoxComboBox
  l_2_4 = l_2_0
  l_2_5 = "ComboBox_SayBuffChannel"
  l_2_3, l_2_6 = l_2_3(l_2_4, l_2_5, l_2_6), {txt = "״̬ͨ��Ƶ��", x = 0, y = 180, w = 150, h = 25}
  l_2_3, l_2_4 = l_2_3:SetMenu, l_2_3
  l_2_5 = function(l_3_0)
    -- upvalues: l_2_2
    for l_3_4,l_3_5 in ipairs(l_2_2) do
      do
        local l_3_6 = table.insert
        local l_3_7 = l_3_0
        local l_3_8 = {}
        l_3_8.szOption = l_3_5.szName
        l_3_8.rgb = l_3_5.color
        l_3_8.bMCheck = true
        l_3_8.bChecked = DBMPanel_Set.nSayBuff == l_3_5.nChannel
        l_3_8.fnAction = function()
          -- upvalues: l_1_5
          DBMPanel_Set.nSayBuff = l_1_5.nChannel
        end
        l_3_6(l_3_7, l_3_8)
      end
    end
    local l_3_11, l_3_16 = table.insert
    l_3_16 = l_3_0
    local l_3_12, l_3_17 = nil
    do
      local l_3_13, l_3_18 = nil
      l_3_17 = GetMsgFontColor
      l_3_13 = "MSG_WHISPER"
      l_3_18 = true
      l_3_17 = l_3_17(l_3_13, l_3_18)
      l_3_17 = DBMPanel_Set
      l_3_17 = l_3_17.nSayBuff
      l_3_13 = PLAYER_TALK_CHANNEL
      l_3_13 = l_3_13.WHISPER
      l_3_17 = l_3_17 == l_3_13
      l_3_17 = function()
      DBMPanel_Set.nSayBuff = PLAYER_TALK_CHANNEL.WHISPER
    end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_3_11(l_3_16, {szOption = "����Ƶ��", rgb = l_3_17, bMCheck = true, bChecked = l_3_17, fnAction = l_3_17})
  end
  l_2_3(l_2_4, l_2_5)
  l_2_3 = BoxComboBox
  l_2_4 = l_2_0
  l_2_5 = "ComboBox_SaySkillChannel"
  l_2_3, l_2_6 = l_2_3(l_2_4, l_2_5, l_2_6), {txt = "����ͨ��Ƶ��", x = 180, y = 180, w = 150, h = 25}
  l_2_3, l_2_4 = l_2_3:SetMenu, l_2_3
  l_2_5 = function(l_4_0)
    -- upvalues: l_2_2
    for l_4_4,l_4_5 in ipairs(l_2_2) do
      do
        local l_4_6 = table.insert
        local l_4_7 = l_4_0
        local l_4_8 = {}
        l_4_8.szOption = l_4_5.szName
        l_4_8.rgb = l_4_5.color
        l_4_8.bMCheck = true
        l_4_8.bChecked = DBMPanel_Set.nSaySkill == l_4_5.nChannel
        l_4_8.fnAction = function()
          -- upvalues: l_2_5
          DBMPanel_Set.nSaySkill = l_2_5.nChannel
        end
        l_4_6(l_4_7, l_4_8)
      end
    end
  end
  l_2_3(l_2_4, l_2_5)
  l_2_3, l_2_4 = l_2_1:FormatAllItemPos, l_2_1
  l_2_3(l_2_4)
end

l_0_0 = RegisterMoonButton
l_0_0("DBM", 2462, "��������", "General", DBMPanel.OnCreate)
l_0_0 = DBMPanel
l_0_0.GetBossSel = function()
  local l_3_0 = DBMPanel.hBossList
  local l_3_1 = l_3_0:GetItemCount()
  for l_3_5 = 0, l_3_1 do
    local l_3_6 = l_3_0:Lookup(l_3_5)
    if l_3_6 and l_3_6.bSel then
      return l_3_6
    end
  end
  return nil
end

l_0_0 = DBMPanel
l_0_0.GetDungeonSel = function()
  local l_4_0 = DBMPanel.hDungeonList
  local l_4_1 = l_4_0:GetItemCount()
  for l_4_5 = 0, l_4_1 do
    local l_4_6 = l_4_0:Lookup(l_4_5)
    if l_4_6 and l_4_6.bSel then
      return l_4_6
    end
  end
  return nil
end

l_0_0 = DBMPanel
l_0_0.CheckSpecialChar = function(l_5_0)
  if StringFindW(l_5_0, "|") then
    return false
  end
  return true
end

l_0_0 = DBMPanel
l_0_0.OnMouseEnter = function()
  local l_6_0 = this:GetName()
  if l_6_0 == "Btn_AddDungeon" then
    OutputTip(GetFormatText("�����븱����ͼ������"), 400)
  end
end

l_0_0 = DBMPanel
l_0_0.OnLButtonClick = function()
  local l_7_0 = this:GetName()
  if l_7_0 == "Btn_AddBoss" then
    if DBMPanel.showMod == "" then
      MsgBox("����ѡ�񸱱���")
      return 
    end
    local l_7_1 = DBMPanel.frame:Lookup("Edit_BossName/Edit_Default"):GetText()
    if l_7_1 == "" then
      return 
    end
    if not DBMPanel.CheckSpecialChar(szTxt) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    l_7_1 = StringReplaceW(l_7_1, " ", "")
    if DBMPanel.InitBossModData(l_7_1) then
      DBMPanel.UpdateBossList()
      DBMLogic.UpdateCurrentMap()
    else
      MsgBox("��Bossģ���Ѿ����ڣ�")
    end
  elseif l_7_0 == "Btn_DelBoss" then
    local l_7_2 = DBMPanel.GetBossSel()
    if not l_7_2 then
      MsgBox("��ѡ��Ҫɾ�����")
      return 
    end
    DBMPanel.hBossList:RemoveItem(l_7_2:GetIndex())
    DBMPanel.sBoss:Update()
    local l_7_3 = DBMPanel.showMod
    local l_7_4 = DBMPanel.ModData[l_7_3].bossData
    if l_7_4[l_7_2.szName] then
      l_7_4[l_7_2.szName] = nil
    end
    for l_7_8,l_7_9 in ipairs(DBMPanel.ModData[l_7_3].bossMod) do
      if l_7_2.szName == l_7_9 then
        table.remove(DBMPanel.ModData[l_7_3].bossMod, l_7_8)
      end
    end
    CloseDBMSetPanel()
  elseif l_7_0 == "Btn_Close" then
    CloseDBMPanel()
  elseif l_7_0 == "Btn_AddDungeon" then
    local l_7_10 = DBMPanel.frame:Lookup("ComboBox_DungeonName/Edit_Default"):GetText()
    l_7_10 = StringReplaceW(l_7_10, " ", "")
    if l_7_10 == "" then
      return 
    end
    if not DBMPanel.CheckSpecialChar(l_7_10) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    for l_7_14,l_7_15 in pairs(DBMPanel.ModList) do
      if l_7_15 == l_7_10 then
        if DBMPanel.ModData[l_7_15] then
          MsgBox("�����Ѿ����ڣ�")
          return 
        end
      else
        table.remove(DBMPanel.ModList, l_7_14)
      end
    end
    table.insert(DBMPanel.ModList, 1, l_7_10)
    DBMPanel.InitModData(l_7_10)
    DBMPanel.UpdateDungeonList()
  end
end

l_0_0 = DBMPanel
l_0_0.OnItemLButtonClick = function()
  local l_8_0 = this:GetName()
  if l_8_0 == "Image_CheckBox" then
    local l_8_1 = this
    local l_8_2 = l_8_1:GetParent()
  if not l_8_2.bBoss then
    end
  if not l_8_2.bBoss then
    end
  end
  local l_8_3 = nil
  if l_8_2.bBoss then
    l_8_3 = DBMPanel.ModData[DBMPanel.showMod].bossData[l_8_2.szName]
  elseif l_8_2.bDungeon then
    l_8_3 = DBMPanel.ModData[l_8_2.szName]
  end
  if l_8_1:GetFrame() == 6 then
    l_8_1:SetFrame(5)
    l_8_3.bOn = false
  else
    l_8_1:SetFrame(6)
    l_8_3.bOn = true
  end
  if l_8_1.bBoss then
    DBMLogic.RefreshWatchNpc()
  end
end

l_0_0 = DBMPanel
l_0_0.OnItemMouseEnter = function()
  local l_9_0 = this:GetName()
  local l_9_1 = this
  if l_9_1.bBoss or l_9_1.bDungeon or l_9_1.bDungeonDefault then
    l_9_1.bIn = true
  end
  if not l_9_1.bSel then
    l_9_1:Lookup("Image_Over"):Show()
  end
end

l_0_0 = DBMPanel
l_0_0.OnItemMouseLeave = function()
  local l_10_0 = this:GetName()
  local l_10_1 = this
  if l_10_1.bBoss or l_10_1.bDungeon or l_10_1.bDungeonDefault then
    l_10_1.bIn = false
  end
  if not l_10_1.bSel then
    l_10_1:Lookup("Image_Over"):Hide()
  end
end

l_0_0 = DBMPanel
l_0_0.OnItemLButtonUp = function()
  local l_11_0 = this:GetName()
  local l_11_1 = this
  if l_11_1.bBoss or l_11_1.bDungeon or l_11_1.bDungeonDefault then
    l_11_1.bSel = true
    local l_11_2 = l_11_1:GetParent()
    local l_11_3 = l_11_2:GetItemCount() - 1
    for l_11_7 = 0, l_11_3 do
      local l_11_8 = l_11_2:Lookup(l_11_7)
      if l_11_8 then
        if l_11_8:GetName() == l_11_1:GetName() then
          l_11_1:Lookup("Image_Sel"):Show()
          l_11_1:Lookup("Image_Over"):Hide()
        end
      else
        l_11_8.bSel = false
        l_11_8:Lookup("Image_Sel"):Hide()
      end
    end
    if l_11_1.bBoss then
      OpenDBMSetPanel(DBMPanel.showMod, l_11_1.szName)
    end
  elseif l_11_1.bDungeon or l_11_1.bDungeonDefault then
    DBMPanel.showMod = l_11_1.szName
    DBMPanel.UpdateBossList()
  end
end

l_0_0 = DBMPanel
l_0_0.OnItemRButtonClick = function()
  local l_12_0 = this
  if l_12_0.bDungeon then
    local l_12_1 = l_12_0.szName
    do
      local l_12_2 = {}
      local l_12_3 = {}
      l_12_3.szOption = "�޸�"
      l_12_3.fnAction = function()
        -- upvalues: l_12_1
        local l_13_0 = GetUserInput
        l_13_0("�����µ�����", function(l_14_0)
          -- upvalues: l_12_1
          if l_14_0 == "" then
            return 
          end
          szText = StringReplaceW(szText, " ", "")
          if not DBMPanel.CheckSpecialChar(l_14_0) then
            MsgBox("���󣬰��������ַ���|����")
            return 
          end
          if table.hasVal(DBMPanel.ModList, l_14_0) then
            MsgBox("�����Ѿ����ڣ�")
            return 
          end
          table.removeVal(DBMPanel.ModList, l_12_1)
          table.insert(DBMPanel.ModList, 1, l_14_0)
          DBMPanel.ModData[l_14_0] = DBMPanel.ModData[l_12_1]
          DBMPanel.ModData[l_12_1] = nil
          if DBMPanel.showMod == l_12_1 then
            DBMPanel.showMod = l_14_0
            DBMPanel.UpdateDungeonList()
            DBMPanel.UpdateBossList()
            CloseDBMSetPanel()
          end
        end, nil, nil, nil, l_12_1)
      end
      local l_12_4 = {}
      l_12_4.szOption = "ɾ��"
      l_12_4.UserData = l_12_1
      l_12_4.fnAction = function(l_14_0)
        MsgBox("ɾ��������������ظ������ݱ����!", function()
          -- upvalues: l_2_0
          DBMPanel.ModData[l_2_0] = nil
          for l_15_3,l_15_4 in ipairs(DBMPanel.ModList) do
            if l_15_4 == l_2_0 then
              table.remove(DBMPanel.ModList, l_15_3)
              do break end
            end
          end
          if DBMPanel.showMod == l_2_0 then
            DBMPanel.showMod = ""
            DBMPanel.UpdateDungeonList()
            DBMPanel.UpdateBossList()
            CloseDBMSetPanel()
          end
        end)
      end
      local l_12_5 = {}
      l_12_5.bDevide = true
      local l_12_6 = {}
      l_12_6.szOption = "�ָ�Ĭ��"
      l_12_6.fnDisable = function()
        -- upvalues: l_12_1
        if MoonDBMPredefinedData[l_12_1] then
          return false
        end
        return true
      end
      l_12_6.fnAction = function()
        -- upvalues: l_12_1
        DBMPanel.LoadPredefinedData(l_12_1)
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_12_3 = PopupMenu
      l_12_4 = l_12_2
      l_12_3(l_12_4)
    end
  elseif l_12_0.bDungeonDefault then
    local l_12_7 = l_12_0.szName
    local l_12_8 = {}
    local l_12_9 = {}
    l_12_9.szOption = "�ָ�Ĭ��"
    l_12_9.fnDisable = function()
      -- upvalues: l_12_1
      if MoonDBMPredefinedData[l_12_1] then
        return false
      end
      return true
    end
    l_12_9.fnAction = function()
      -- upvalues: l_12_1
      table.insert(DBMPanel.ModList, 1, l_12_1)
      DBMPanel.LoadPredefinedData(l_12_1)
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_12_9 = PopupMenu
    l_12_9(l_12_8)
  end
end

l_0_0 = DBMPanel
l_0_0.AppendCheckBoxToList = function(l_13_0, l_13_1, l_13_2, l_13_3)
  local l_13_4 = l_13_0:AppendItemFromIni("interface\\Moon_DBM\\DBMSetPanel.ini", "Handle_Item", tostring(l_13_1))
  l_13_4:SetSize(330, 30)
  l_13_4:Lookup("Text_ScreenTip"):SetSize(0, 0)
  l_13_4:Lookup("Image_Over"):SetSize(300, 30)
  l_13_4:Lookup("Image_Sel"):SetSize(300, 30)
  local l_13_5 = l_13_4:Lookup("Text_CheckTxt")
  if l_13_3 then
    l_13_5:SetFontScheme(l_13_3)
  end
  l_13_5:SetSize(300, 30)
  l_13_5:SetText(l_13_2)
  return l_13_4
end

l_0_0 = DBMPanel
l_0_0.UpdateBossList = function()
  local l_14_0 = DBMPanel.hBossList
  l_14_0:Clear()
  local l_14_1 = DBMPanel.showMod
  if l_14_1 ~= "" then
    local l_14_2 = DBMPanel.ModData[l_14_1]
  end
  if l_14_2 and l_14_2.bossMod then
    for l_14_6,l_14_7 in ipairs(l_14_2.bossMod) do
      local l_14_8 = DBMPanel.AppendCheckBoxToList(l_14_0, l_14_6, l_14_7)
      local l_14_9 = l_14_2.bossData[l_14_7]
      if l_14_9.bOn then
        l_14_8:Lookup("Image_CheckBox"):SetFrame(6)
      end
      l_14_8.bBoss = true
      l_14_8.szName = l_14_7
    end
  end
  l_14_2 = DBMPanel
  l_14_2 = l_14_2.sBoss
  l_14_2(l_14_2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_14_2()
end

l_0_0 = DBMPanel
l_0_0.UpdateDungeonList = function()
  local l_15_0 = DBMPanel.hDungeonList
  l_15_0:Clear()
  for l_15_4,l_15_5 in ipairs(DBMPanel.ModList) do
    if DBMPanel.ModData[l_15_5] then
      local l_15_6 = DBMPanel.AppendCheckBoxToList(l_15_0, l_15_4, l_15_5)
      local l_15_7 = DBMPanel.ModData[l_15_5]
      if l_15_7.bOn then
        l_15_6:Lookup("Image_CheckBox"):SetFrame(6)
      end
      l_15_6.bDungeon = true
      l_15_6.szName = l_15_5
    end
  end
  if #MoonDBMPredefinedList > 0 then
    for l_15_11,l_15_12 in ipairs(MoonDBMPredefinedList) do
      if not DBMPanel.ModData[l_15_12] then
        local l_15_13 = DBMPanel.AppendCheckBoxToList(l_15_0, l_15_11, l_15_12, 107)
        l_15_13.bDungeonDefault = true
        l_15_13.szName = l_15_12
      end
    end
  end
  DBMPanel.sDungeon:Update()
end

l_0_0 = DBMPanel
l_0_0.InitModData = function(l_16_0)
  if DBMPanel.ModData[l_16_0] then
    return 
  end
  local l_16_1 = DBMPanel.ModData
  local l_16_2 = {}
  l_16_2.bOn = true
  l_16_2.bossMod = {}
  l_16_2.bossData = {}
  l_16_1[l_16_0] = l_16_2
end

l_0_0 = DBMPanel
l_0_0.InitBossModData = function(l_17_0)
  local l_17_1 = DBMPanel.showMod
  for l_17_5,l_17_6 in ipairs(DBMPanel.ModData[l_17_1].bossMod) do
    if l_17_6 == l_17_0 then
      return false
    end
  end
  table.insert(DBMPanel.ModData[l_17_1].bossMod, l_17_0)
  if not DBMPanel.ModData[l_17_1].bossData[l_17_0] then
    DBMPanel.ModData[l_17_1].bossData[l_17_0] = {}
  end
  do
    local l_17_7, l_17_9 = DBMPanel.ModData[l_17_1].bossData
    local l_17_8 = nil
    l_17_8 = {}
    l_17_8 = {}
    l_17_8 = {}
    l_17_7[l_17_0], l_17_9 = l_17_9, {bOn = true, bLife = false, tLife = l_17_8, bArea = false, nAngle = 0, nRange = 0, bEnter = false, Skill = l_17_8, Buff = l_17_8}
    l_17_7 = true
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_17_7
end

l_0_0 = DBMPanel
l_0_0.Create = function()
  local l_18_0 = BoxSetFrame
  local l_18_1 = "DBMPanel"
  local l_18_2 = {}
  l_18_2.w = 380
  l_18_2.h = 480
  l_18_2.bglobal = true
  l_18_0 = l_18_0(l_18_1, l_18_2)
  l_18_1, l_18_2 = l_18_0:ui, l_18_0
  l_18_1 = l_18_1(l_18_2)
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_18_3 = BoxLabel
  local l_18_4 = l_18_2
  local l_18_5 = "Text_Title"
  local l_18_6 = "��������"
  local l_18_7 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_18_8 = 0
  local l_18_9 = {}
  l_18_9.nW = 380
  l_18_9.nH = 30
  l_18_9.nHAlign = 1
  l_18_3(l_18_4, l_18_5, l_18_6, l_18_7, l_18_8, l_18_9)
  l_18_6 = "ݶ��ʥ��"
  l_18_7 = "10��Ӣ��ݶ��ʥ��"
  l_18_8 = "10����ͨ��Ԩ��"
  l_18_9 = "10��Ӣ����Ԩ��"
  l_18_5 = {l_18_6, l_18_7, l_18_8, l_18_9, "ݶ������", "�ֹ�����¼", "������", "��ս����"}
  l_18_7 = "25����ͨݶ��ʥ��"
  l_18_8 = "25��Ӣ��ݶ��ʥ��"
  l_18_9 = "Ӣ��ݶ������"
  l_18_6 = {l_18_7, l_18_8, l_18_9, "25��Ӣ����Ԩ��", "25����ͨ��Ԩ��", "Ӣ�۳ֹ�����¼", "Ӣ��������", "25��Ӣ�ۻ�ս����"}
  l_18_5, l_18_4 = {szClass = "25�˸���", tDungeon = l_18_6}, {szClass = "10�˸���", tDungeon = l_18_5}
  l_18_4 = BoxEditComboBox
  l_18_5 = l_18_1
  l_18_6 = "ComboBox_DungeonName"
  l_18_4, l_18_7 = l_18_4(l_18_5, l_18_6, l_18_7), {x = 20, y = 40, w = 240, h = 25}
  l_18_4, l_18_5 = l_18_4:SetMenu, l_18_4
  l_18_6 = function(l_19_0, l_19_1)
    -- upvalues: l_18_3
    for l_19_5,l_19_6 in ipairs(l_18_3) do
      local l_19_7 = {}
      l_19_7.szOption = l_19_6.szClass
      for l_19_11,l_19_12 in ipairs(l_19_6.tDungeon) do
        do
          local l_19_13 = table.insert
          local l_19_14 = l_19_7
          local l_19_15 = {}
          l_19_15.szOption = l_19_12
          l_19_15.fnAction = function()
            -- upvalues: l_1_1 , l_1_12
            l_1_1:SetText(l_1_12)
          end
          l_19_13(l_19_14, l_19_15)
        end
      end
      table.insert(l_19_0, l_19_7)
    end
  end
  l_18_4(l_18_5, l_18_6)
  l_18_4 = BoxButton
  l_18_5 = l_18_1
  l_18_6 = "Btn_AddDungeon"
  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_7 = {x = 280, y = 40, txt = "���Ӹ���", w = 80, h = 28}
  l_18_4 = BoxImage
  l_18_5 = l_18_2
  l_18_6 = "Image_Break1"
  l_18_7 = "ui/Image/UICommon/CommonPanel.UITex"
  l_18_8 = 42
  local l_18_10 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_18_11 = {}
  l_18_4(l_18_5, l_18_6, l_18_7, l_18_8, l_18_9, l_18_10, l_18_11)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6, l_18_7, l_18_8, l_18_9, l_18_10, l_18_11)
  l_18_11, l_18_10, l_18_9 = {nAlpha = 255}, {l_18_11, 7}, {l_18_10, l_18_11}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_8 = {x = 30, y = 225, w = 345, h = 200, nstep = 10, bhome = true}
  l_18_4.sBoss = l_18_5
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4.hBossList = l_18_5
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_8 = 42
  l_18_10 = 10
  l_18_11 = 425
  l_18_11 = 360
  l_18_4(l_18_5, l_18_6, l_18_7, l_18_8, l_18_9, l_18_10, l_18_11)
  l_18_11, l_18_10, l_18_9 = {nAlpha = 255}, {l_18_11, 7}, {l_18_10, l_18_11}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_7 = {x = 20, y = 440, w = 180, h = 25}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_7 = {x = 205, y = 440, w = 80, h = 28, txt = "����"}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_7 = {x = 285, y = 440, w = 80, h = 28, txt = "ɾ��"}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4(l_18_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_18_4()
end

l_0_0 = function()
  local l_19_0 = Station.Lookup("Normal/DBMPanel")
  if l_19_0 and l_19_0:IsVisible() then
    return true
  end
  return false
end

IsDBMPanelOpened = l_0_0
l_0_0 = function()
  if not IsDBMPanelOpened() then
    return 
  end
  local l_20_0 = Station.Lookup("Normal/DBMPanel")
  l_20_0:Hide()
  CloseDBMSetPanel()
end

CloseDBMPanel = l_0_0
l_0_0 = function()
  if IsDBMPanelOpened() then
    return 
  end
  local l_21_0 = Station.Lookup("Normal/DBMPanel")
  if not l_21_0 then
    DBMPanel.Create()
  else
    l_21_0:Show()
  end
end

OpenDBMPanel = l_0_0
l_0_0 = AppendCommand
l_0_0("dbm", OpenDBMPanel)
l_0_0 = RegisterBoxAddonVersion
l_0_0("Moon_DBM", 1.8)

