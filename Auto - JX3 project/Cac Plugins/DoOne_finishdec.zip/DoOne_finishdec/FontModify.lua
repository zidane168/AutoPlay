-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: FontModify.lua 

local l_0_0 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_4 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_5 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_6 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_6, l_0_5, l_0_4, l_0_3 = {"������Ϣ", "UI\\Font\\��������_GBK.ttf", 16}, {l_0_6, "UI\\Font\\������ֽ����.ttf", 20}, {l_0_5, l_0_6, 15}, {l_0_4, l_0_5, l_0_6}
l_0_1.tModify, l_0_2 = l_0_2, {l_0_3, l_0_4, l_0_5, l_0_6}
FontModify = l_0_1
l_0_1 = RegisterCustomData
l_0_2 = "FontModify.bOn"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "FontModify.tModify"
l_0_1(l_0_2)
l_0_1 = FontModify
l_0_2 = function(l_1_0)
  local l_1_1 = l_1_0:Lookup("", "")
  BoxBoolCheckBox(l_1_0, "CheckBox_bOn", "���������޸�", FontModify, "bOn", function()
    FontModify.LoadFont(FontModify.tModify)
  end, function()
    FontModify.LoadFont(FontModify.tDefault)
  end)
  local l_1_2 = BoxLabel
  local l_1_3 = l_1_1
  local l_1_4 = "Label1"
  local l_1_5 = "�����б���"
  local l_1_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_1_2(l_1_3, l_1_4, l_1_5, l_1_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3(l_1_4, l_1_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_1_7 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_1_3(l_1_4, l_1_5, l_1_6, l_1_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  do
    local l_1_8 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_1_4(l_1_5, l_1_6, l_1_7, l_1_8)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_5(l_1_6, l_1_7)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_5(l_1_6, l_1_7)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_5(l_1_6, l_1_7)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_5(l_1_6)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1.Create = l_0_2
l_0_1 = RegisterMoonButton
l_0_2 = "FontModify"
l_0_3 = 390
l_0_4 = "�����޸�"
l_0_5 = "General"
l_0_6 = FontModify
l_0_6 = l_0_6.Create
l_0_1(l_0_2, l_0_3, l_0_4, l_0_5, l_0_6)
l_0_1 = FontModify
l_0_2 = function(l_2_0, l_2_1, l_2_2, l_2_3)
  l_2_0:Lookup("ComboBox_Font/", "Text_ComboBox"):SetText(l_2_1)
  l_2_0:Lookup("Edit_FontPath/Edit_Default"):SetText(l_2_2)
  l_2_0:Lookup("Edit_FontSize/Edit_Default"):SetText(l_2_3)
end

l_0_1.SetShowFontInfo = l_0_2
l_0_1 = FontModify
l_0_2 = function(l_3_0)
  if #l_3_0 <= 4 then
    return false
  end
  local l_3_1 = string.lower(string.sub(l_3_0, #l_3_0 - 2, #l_3_0))
  local l_3_2 = table.hasVal
  local l_3_3 = {}
  local l_3_5 = "ttf"
  local l_3_6 = "ttc"
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_3_4 = "otf"
  return l_3_2(l_3_3, l_3_5)
end

l_0_1.IsFontFile = l_0_2
l_0_1 = FontModify
l_0_2 = function(l_4_0)
  -- upvalues: l_0_0
  for l_4_4,l_4_5 in pairs(l_4_0) do
    local l_4_6 = l_0_0[l_4_4]
    local l_4_7 = l_4_5[2]
    local l_4_8 = l_4_5[3]
    local l_4_9 = {}
    local l_4_10, l_4_11, l_4_12 = Font.GetFont(l_4_6)
    l_4_9.aStyle = R13_PC13
    l_4_9.nSize = l_4_12
    l_4_9.szFile = l_4_11
    l_4_9.szName = l_4_10
    l_4_9.szFile = l_4_7
    l_4_9.nSize = l_4_8
    l_4_10 = IsFileExist
    l_4_11 = l_4_9.szFile
    l_4_10 = l_4_10(l_4_11)
    if l_4_10 then
      l_4_10 = FontModify
      l_4_10 = l_4_10.IsFontFile
      l_4_11 = l_4_9.szFile
      l_4_10 = l_4_10(l_4_11)
    end
    if l_4_10 then
      l_4_10 = Font
      l_4_10 = l_4_10.SetFont
      l_4_11 = l_4_6
      l_4_12 = l_4_9.szName
      R13_PC13 = l_4_9.szFile
      l_4_10(l_4_11, l_4_12, R13_PC13, l_4_9.nSize, l_4_9.aStyle)
    end
  end
end

l_0_1.LoadFont = l_0_2
l_0_1 = RegisterEvent
l_0_2 = "AddonLoad"
l_0_3 = function()
  if FontModify.bOn then
    FontModify.LoadFont(FontModify.tModify)
  end
end

l_0_1(l_0_2, l_0_3)
l_0_1 = RegisterBoxAddonVersion
l_0_2 = "Moon_FontModify"
l_0_3 = 0.1
l_0_1(l_0_2, l_0_3)

