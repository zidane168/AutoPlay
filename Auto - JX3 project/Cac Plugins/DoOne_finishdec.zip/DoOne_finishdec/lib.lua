-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: lib.lua 

Moon_Lib = {}
Moon_Lib.AdjustToOriginalPos = function(l_1_0, l_1_1)
  local l_1_2 = 640
  local l_1_3 = 480
  local l_1_4 = Station.GetUIScale()
  l_1_2 = l_1_0 / l_1_4
  l_1_3 = l_1_1 / l_1_4
  return l_1_2, l_1_3
end

Moon_Lib.GetTarget = function(l_2_0, l_2_1)
  if not l_2_0 then
    local l_2_2 = GetClientPlayer()
    if l_2_2 then
      l_2_0 = l_2_2.GetTarget()
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_2_0 = TARGET.NO_TARGET
    end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  elseif (not l_2_1 and IsPlayer(l_2_1) and l_2_1 <= 0) or l_2_0 == TARGET.NO_TARGET then
    return nil, TARGET.NO_TARGET
  else
    if l_2_0 == TARGET.PLAYER then
      return GetPlayer(l_2_1), TARGET.PLAYER
    end
  else
    if l_2_0 == TARGET.DOODAD then
      return GetDoodad(l_2_1), TARGET.DOODAD
    end
  else
    return GetNpc(l_2_1), TARGET.NPC
  end
end

Moon_Lib.ApplyScreenPoint = function(l_3_0, l_3_1, l_3_2, l_3_3, l_3_4)
  if not l_3_3 then
    local l_3_5 = l_3_2
    l_3_2 = l_3_5.nX
  end
  if not l_3_1 then
    l_3_1 = 0
  end
  PostThreadCall(function(l_4_0, l_4_1, l_4_2)
    -- upvalues: l_3_0
    if l_4_1 and l_4_2 then
      l_4_1 = Station.AdjustToOriginalPos(l_4_1, l_4_2)
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_4_1 = nil
    end
    l_3_0(l_4_1, l_4_2, l_4_0)
  end, l_3_1, "Scene_GameWorldPositionToScreenPoint", l_3_2, l_3_3, l_3_4, false)
end

Moon_Lib.ApplyTargetTopScreenPos = function(l_4_0, l_4_1, l_4_2, l_4_3)
  local l_4_8, l_4_9 = nil
  if not l_4_1 then
    l_4_1 = 0
  end
  if type(l_4_2) == "number" then
    l_4_2 = Moon_Lib.GetTarget(l_4_2)
  end
  if not l_4_2 then
    local l_4_4 = l_4_0
    local l_4_5, l_4_6 = nil, nil
    local l_4_7 = l_4_1
    return l_4_4(l_4_5, l_4_6, l_4_7)
  end
  if not l_4_3 then
    PostThreadCall(function(l_5_0, l_5_1, l_5_2, l_5_3, l_5_4, l_5_5)
    -- upvalues: l_4_0
    if l_5_1 and l_5_2 then
      l_5_1 = Station.AdjustToOriginalPos(l_5_1, l_5_2)
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_5_1 = nil
    end
    l_4_0(l_5_1, l_5_2, l_5_0)
  end, l_4_1, "Scene_GetCharacterTopScreenPos", l_4_2.dwID)
  elseif l_4_3 < 64 then
    l_4_3 = l_4_3 * 64
  end
  Moon_Lib.ApplyScreenPoint(l_4_0, l_4_1, l_4_2.nX, l_4_2.nY, l_4_2.nZ + l_4_3)
end

Moon_Lib.GetDistance = function(l_5_0, l_5_1)
  local l_5_2 = math.floor(l_5_0.nX - l_5_1.nX ^ 2 + l_5_0.nY - l_5_1.nY ^ 2 + l_5_0.nZ / 8 - l_5_1.nZ / 8 ^ 2 ^ 0.5)
  local l_5_3 = tonumber
  local l_5_4, l_5_5, l_5_6 = "%.2f":format(l_5_2 / 64), .end
  return l_5_3(l_5_4, l_5_5, l_5_6)
end

Moon_Lib.GetTargetDistance = function(l_6_0)
  local l_6_1 = Moon_Lib.GetDistance
  local l_6_2 = GetClientPlayer()
  local l_6_3 = l_6_0
  return l_6_1(l_6_2, l_6_3)
end

Moon_Lib.GetFaceDirection = function(l_7_0, l_7_1)
  local l_7_2 = l_7_1.nX - l_7_0.nX
  local l_7_3 = l_7_1.nY - l_7_0.nY
  local l_7_4 = math.sqrt(l_7_2 ^ 2 + l_7_3 ^ 2)
  if l_7_4 == 0 then
    return 0
  end
  if l_7_2 < 0 and l_7_3 >= 0 then
    do return end
  end
  if l_7_2 < 0 and l_7_3 < 0 then
    do return end
  end
  if l_7_2 >= 0 and l_7_3 < 0 then
    local l_7_5, l_7_7 = math.pi * 2 - (math.pi + (math.pi - math.asin(math.abs(l_7_3) / l_7_4)))
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if math.abs(l_7_5 * 180 / math.pi - l_7_0.nFaceDirection / 256 * 360) >= 180 then
    local l_7_6, l_7_8 = , 360 - math.abs(l_7_5 * 180 / math.pi - l_7_0.nFaceDirection / 256 * 360)
  end
  local l_7_9 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_7_10, l_7_11, l_7_12 = , tonumber, "%.1f":format(l_7_8)
  return l_7_11(l_7_12)
end

Moon_Lib.SetTarget = function(l_8_0)
  local l_8_1 = TARGET.NPC
  if IsPlayer(l_8_0) then
    l_8_1 = TARGET.PLAYER
  end
  SetTarget(l_8_1, l_8_0)
end

Moon_Lib.GetAddonInfo = function(l_9_0)
  local l_9_1 = GetAddOnCount() - 1
  for l_9_5 = 0, l_9_1 do
    local l_9_6 = GetAddOnInfo(l_9_5)
    if l_9_6.szID == l_9_0 then
      return l_9_6
    end
  end
end

MsgBox = function(l_10_0, l_10_1, l_10_2)
  local l_10_3, l_10_4 = Station.GetClientSize()
  local l_10_5 = {}
  l_10_5.x = l_10_3 / 2
  l_10_5.y = l_10_4 / 2
  l_10_5.bVisibleWhenHideUI = true
  l_10_5.szMessage = l_10_0
  l_10_5.szName = "Moontip"
  if l_10_1 then
    local l_10_6 = table.insert
    local l_10_7 = l_10_5
    local l_10_8 = {}
    l_10_8.szOption = g_tStrings.STR_HOTKEY_SURE
    l_10_8.fnAction = function()
      -- upvalues: l_10_1
      l_10_1()
    end
    l_10_6(l_10_7, l_10_8)
    l_10_6 = table
    l_10_6 = l_10_6.insert
    l_10_7 = l_10_5
    l_10_6(l_10_7, l_10_8)
    l_10_8 = {szOption = "ȡ��", fnAction = function()
      -- upvalues: l_10_2
      if l_10_2 then
        l_10_2()
      end
    end}
  else
    local l_10_9 = table.insert
    local l_10_10 = l_10_5
    local l_10_11 = {}
    l_10_11.szOption = g_tStrings.STR_HOTKEY_SURE
    l_10_11.fnAction = function()
    end
    l_10_9(l_10_10, l_10_11)
  end
  MessageBox(l_10_5)
end

Msg = function(l_11_0)
  OutputMessage("MSG_SYS", tostring(l_11_0) .. "\n")
end

IE_Resize = function(l_12_0, l_12_1, l_12_2)
  if l_12_1 < 400 then
    l_12_1 = 400
  end
  if l_12_2 < 200 then
    l_12_2 = 200
  end
  local l_12_3 = l_12_0:Lookup("", "")
  l_12_3:SetSize(l_12_1, l_12_2)
  l_12_3:Lookup("Image_Bg"):SetSize(l_12_1, l_12_2)
  l_12_3:Lookup("Image_BgT"):SetSize(l_12_1 - 6, 64)
  l_12_3:Lookup("Image_Edit"):SetSize(l_12_1 - 300, 25)
  l_12_3:Lookup("Text_Title"):SetSize(l_12_1 - 168, 30)
  l_12_3:FormatAllItemPos()
  local l_12_4 = l_12_0:Lookup("WebPage_Page")
  l_12_4:SetSize(l_12_1 - 12, l_12_2 - 76)
  l_12_0:Lookup("Edit_Input"):SetSize(l_12_1 - 306, 20)
  l_12_0:Lookup("Btn_GoTo"):SetRelPos(l_12_1 - 110, 38)
  l_12_0:Lookup("Btn_Close"):SetRelPos(l_12_1 - 40, 10)
  l_12_0:Lookup("CheckBox_MaxSize"):SetRelPos(l_12_1 - 70, 10)
  l_12_0:Lookup("Btn_DL"):SetSize(10, l_12_2 - 20)
  l_12_0:Lookup("Btn_DT"):SetSize(l_12_1 - 20, 10)
  l_12_0:Lookup("Btn_DTR"):SetRelPos(l_12_1 - 10, 0)
  l_12_0:Lookup("Btn_DR"):SetRelPos(l_12_1 - 10, 10)
  l_12_0:Lookup("Btn_DR"):SetSize(10, l_12_2 - 20)
  l_12_0:Lookup("Btn_DRB"):SetRelPos(l_12_1 - 10, l_12_2 - 10)
  l_12_0:Lookup("Btn_DB"):SetRelPos(10, l_12_2 - 10)
  l_12_0:Lookup("Btn_DB"):SetSize(l_12_1 - 20, 10)
  l_12_0:Lookup("Btn_DLB"):SetRelPos(0, l_12_2 - 10)
  l_12_0:SetSize(l_12_1, l_12_2)
  l_12_0:SetDragArea(0, 0, l_12_1, 30)
end

table.isEmpty = function(l_13_0)
  local l_13_1 = true
  for l_13_5 in pairs(l_13_0) do
    l_13_1 = false
    do break end
  end
  return l_13_1
end

table.hasVal = function(l_14_0, l_14_1)
  for l_14_5,l_14_6 in pairs(l_14_0) do
    if l_14_6 == l_14_1 then
      return true
    end
  end
  return false
end

table.removeVal = function(l_15_0, l_15_1)
  for l_15_5,l_15_6 in pairs(l_15_0) do
    if l_15_6 == l_15_1 then
      table.remove(l_15_0, l_15_5)
      do break end
    end
  end
end

table.pairsByKeys = function(l_16_0, l_16_1)
  do
    local l_16_2 = {}
    for l_16_6 in pairs(l_16_0) do
      table.insert(l_16_2, l_16_6)
    end
    table.sort(l_16_2, l_16_1)
    return function()
    -- upvalues: l_16_3 , l_16_2 , l_16_0
    l_16_3 = l_16_3 + 1
    if l_16_2[l_16_3] == nil then
      return nil
    else
      return l_16_2[l_16_3], l_16_0[l_16_2[l_16_3]]
    end
  end
  end
   -- WARNING: undefined locals caused missing assignments!
end

string.split = function(l_17_0, l_17_1, l_17_2)
  if not l_17_2 then
    l_17_2 = 1
  end
  local l_17_3 = 1
  local l_17_4 = 1
  local l_17_5 = {}
  while 1 do
    local l_17_6 = string.find(l_17_0, l_17_1, l_17_3)
    if not l_17_6 then
      l_17_5[l_17_4] = string.sub(l_17_0, l_17_3, string.len(l_17_0))
      do break end
    end
    l_17_5[l_17_4] = string.sub(l_17_0, l_17_3, l_17_6 - 1)
    l_17_3 = l_17_6 + l_17_2
    l_17_4 = l_17_4 + 1
  end
  return l_17_5
end

local l_0_0 = {}
RegisterBoxAddonVersion = function(l_18_0, l_18_1)
  -- upvalues: l_0_0
  l_0_0[l_18_0] = l_18_1
end

GetBoxAddonVersion = function(l_19_0)
  -- upvalues: l_0_0
  return l_0_0[l_19_0] or 0
end


