-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetSelect.lua 

local l_0_0 = {}
l_0_0.bOn = false
l_0_0.bAlly = false
local l_0_1 = {}
l_0_1.OnlyPlayer = false
l_0_1.OnlyNearDis = false
l_0_1.Weakness = false
l_0_1.MidAxisFirst = false
l_0_1.bInner = true
l_0_1.bSystem = false
l_0_0.tOption = l_0_1
l_0_0.tAllyOption, l_0_1 = l_0_1, {OnlyPlayer = true, Teammate = true, OnlyNearDis = false, Weakness = false, MidAxisFirst = false, bInner = true, bSystem = false}
TargetSelect = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "TargetSelect.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "TargetSelect.bAlly"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "TargetSelect.bMenu"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "TargetSelect.tOption"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "TargetSelect.tAllyOption"
l_0_0(l_0_1)
l_0_0 = function()
  local l_1_0 = {}
  local l_1_1 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_1_2 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  for i_1,i_2 in l_1_1 do
    if TargetSelect[l_1_5[1]] then
      for l_1_9,l_1_10 in ipairs({"OnlyPlayer", "Weakness", "OnlyNearDis", "bInner", "MidAxisFirst"}) do
        local l_1_11 = TargetSelect[l_1_5[2]][l_1_10]
        if l_1_10 == "bInner" then
          if l_1_11 then
            SearchTarget_SetAreaSettting("Inner", 512, 85, 3, l_1_5[3])
            SearchTarget_SetAreaSettting("MidAxis", 2560, 15, 2, l_1_5[3])
          else
            SearchTarget_SetAreaSettting("Inner", 512, 85, 2, l_1_5[3])
            SearchTarget_SetAreaSettting("MidAxis", 2560, 15, 3, l_1_5[3])
          end
        else
          SearchTarget_SetOtherSettting(l_1_10, l_1_11, l_1_5[3])
        end
      end
      if l_1_5[3] == "Ally" then
        SearchTarget_SetOtherSettting("Teammate", TargetSelect[l_1_5[2]].Teammate, l_1_5[3])
      end
    else
      SearchTarget_SetAreaSettting("Inner", 512, 85, 2, l_1_5[3])
      SearchTarget_SetAreaSettting("MidAxis", 2560, 15, 3, l_1_5[3])
      for l_1_15,l_1_16 in ipairs({"OnlyPlayer", "Weakness", "OnlyNearDis", "MidAxisFirst"}) do
        SearchTarget_SetOtherSettting(l_1_16, false, l_1_5[3])
      end
    end
    if l_1_5[3] == "Ally" then
      SearchTarget_SetOtherSettting("Teammate", false, l_1_5[3])
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- WARNING: undefined locals caused missing assignments!
end

l_0_1 = RegisterEvent
l_0_1("SYNC_ROLE_DATA_END", l_0_0)
l_0_1 = function(l_2_0, l_2_1)
  -- upvalues: l_0_0
  for l_2_5,l_2_6 in pairs({"Weakness", "OnlyNearDis", "bSystem", "bInner", "MidAxisFirst"}) do
    if l_2_6 == l_2_0 then
      TargetSelect[l_2_1][l_2_6] = true
    else
      TargetSelect[l_2_1][l_2_6] = false
    end
  end
  l_0_0()
end

TargetSelect.OnCreate = function(l_3_0)
  -- upvalues: l_0_0 , l_0_1
  local l_3_1 = l_3_0:Lookup("", "")
  BoxBoolCheckBox(l_3_0, "Check_bMenu", "����ͷ��˵���������", TargetSelect, "bMenu")
  BoxBoolCheckBox(l_3_0, "Check_bOn", "�ж�Ŀ��ѡ��", TargetSelect, "bOn", function()
    -- upvalues: l_0_0
    if SearchTarget_IsOldVerion() then
      this:Check(false)
      MsgBox("��Ҫ����Ŀ��ѡ����ԣ��°棩��")
      return 
    else
      l_0_0()
    end
  end, l_0_0):SetRelPos(0, 30)
  BoxBoolCheckBox(l_3_0, "Check_bOn", "����Ŀ��ѡ��", TargetSelect, "bAlly", function()
    -- upvalues: l_0_0
    if SearchTarget_IsOldVerion() then
      this:Check(false)
      MsgBox("��Ҫ����Ŀ��ѡ����ԣ��°棩��")
      return 
    else
      l_0_0()
    end
  end, l_0_0):SetRelPos(200, 30)
  local l_3_2 = BoxLabel
  local l_3_3 = l_3_1
  local l_3_4 = "label1"
  local l_3_5 = "�ж�Ŀ��ѡ��(Tab)"
  local l_3_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4, l_3_5, l_3_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4, l_3_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "��ϷĬ��", group = "select", bchecked = l_3_6, x = 0, y = 120}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "ֻѡ���2��", group = "select", bchecked = l_3_6, x = 150, y = 120}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "������ǰ������", group = "select", bchecked = l_3_6, x = 300, y = 120}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "����Ѫ��", group = "select", bchecked = l_3_6, x = 0, y = 150}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "��������Ƕ�С", group = "select", bchecked = l_3_6, x = 150, y = 150}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = "����Ŀ��ѡ��"
  l_3_2(l_3_3, l_3_4, l_3_5, l_3_6, 27)
  l_3_6 = {0, 180}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = "ֻѡ���"
  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = 210
  l_3_2(l_3_3, l_3_4, l_3_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = "ֻѡ����"
  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = 210
  l_3_2(l_3_3, l_3_4, l_3_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
  l_3_6 = l_3_6.bSystem
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "��ϷĬ��", group = "select", bchecked = l_3_6, x = 0, y = 240}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
  l_3_6 = l_3_6.OnlyNearDis
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "ֻѡ���2��", group = "select", bchecked = l_3_6, x = 150, y = 240}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
  l_3_6 = l_3_6.bInner
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "������ǰ������", group = "select", bchecked = l_3_6, x = 300, y = 240}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
  l_3_6 = l_3_6.Weakness
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "����Ѫ��", group = "select", bchecked = l_3_6, x = 0, y = 270}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6 = TargetSelect
  l_3_6 = l_3_6.tAllyOption
  l_3_6 = l_3_6.MidAxisFirst
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_5 = {txt = "��������Ƕ�С", group = "select", bchecked = l_3_6, x = 150, y = 270}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3, l_3_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_2(l_3_3)
end

RegisterMoonButton("TargetSelect", 3353, "Ŀ��ѡ��", "General", TargetSelect.OnCreate)
RegisterPlayerMenu("target_select", function(l_4_0)
  -- upvalues: l_0_0
  if not TargetSelect.bMenu then
    return {}
  end
  local l_4_1 = {}
  l_4_1.szOption = "Ŀ��ѡ��"
  local l_4_2 = {}
  l_4_2.szOption = "�����ж�Ŀ��ѡ��"
  l_4_2.bCheck = true
  l_4_2.bChecked = TargetSelect.bOn
  l_4_2.fnAction = function(l_5_0, l_5_1)
    if not TargetSelect.bOn and SearchTarget_IsOldVerion() then
      local l_5_2 = MsgBox
      local l_5_3 = "��Ҫ����Ŀ��ѡ����ԣ��°棩��"
      return l_5_2(l_5_3)
    end
    TargetSelect.bOn = l_5_1
  end
  local l_4_3 = {}
  l_4_3.szOption = "��������Ŀ��ѡ��"
  l_4_3.bCheck = true
  l_4_3.bChecked = TargetSelect.bAlly
  l_4_3.fnAction = function(l_6_0, l_6_1)
    if not TargetSelect.bAlly and SearchTarget_IsOldVerion() then
      local l_6_2 = MsgBox
      local l_6_3 = "��Ҫ����Ŀ��ѡ����ԣ��°棩��"
      return l_6_2(l_6_3)
    end
    TargetSelect.bAlly = l_6_1
  end
  local l_4_4 = {}
  l_4_4.bDevide = true
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_4_2 = ipairs
  local l_4_5 = {}
  do
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    for l_4_5,i_2 in l_4_2 do
      local l_4_7 = {}
      local l_4_8 = {}
      local l_4_9 = {}
      local l_4_10 = {}
      local l_4_11 = {}
      local l_4_12 = {}
      local l_4_13 = {}
      local l_4_14 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_4_8 == "����Ŀ��" then
        l_4_8(l_4_9, l_4_10, l_4_11)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_4_8(l_4_9, l_4_10)
    end
    do
      local l_4_15 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

    end
    return {l_4_3}
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
   -- WARNING: undefined locals caused missing assignments!
end
)

