-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMSetBuff.lua 

local l_0_0 = {}
l_0_0.type = ""
l_0_0.szName = ""
l_0_0.szColor = "red"
DBMSetBuff = l_0_0
l_0_0 = DBMSetBuff
l_0_0.OnFrameCreate = function()
end

l_0_0 = DBMSetBuff
l_0_0.OnLButtonClick = function()
  local l_2_0 = this:GetName()
  if l_2_0 == "Btn_Close" or l_2_0 == "Btn_Cancle" then
    Wnd.CloseWindow("DBMSetBuff")
  elseif l_2_0 == "Btn_Submit" then
    local l_2_1 = Station.Lookup("Normal/DBMSetBuff")
    local l_2_2 = l_2_1:Lookup("Edit_Name/Edit_Default"):GetText()
    local l_2_3 = l_2_1:Lookup("Edit_Count/Edit_Default"):GetText()
    local l_2_4 = l_2_1:Lookup("Edit_Desc/Edit_Default"):GetText()
    local l_2_5 = l_2_1:Lookup("CheckBox_Buff")
    local l_2_6 = l_2_1:Lookup("CheckBox_DeBuff")
    local l_2_7 = l_2_1:Lookup("CheckBox_Self")
    local l_2_8 = l_2_1:Lookup("CheckBox_All")
    local l_2_9 = {}
    if l_2_2 == "" then
      MsgBox("BUFF���Ʋ���Ϊ�ա�")
      return 
    end
    if l_2_4 == "" then
      MsgBox("BUFF��������Ϊ�ա�")
      return 
    end
    if not DBMPanel.CheckSpecialChar(l_2_2) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    if not DBMPanel.CheckSpecialChar(l_2_4) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    if l_2_3 == "" then
      MsgBox("BUFF��������Ϊ�ա�")
      return 
    end
    l_2_9.nType = 1
    if l_2_6:IsCheckBoxChecked() then
      l_2_9.nType = 2
    end
    l_2_9.nTarget = 1
    if l_2_8:IsCheckBoxChecked() then
      l_2_9.nTarget = 2
    end
    l_2_9.szDesc = l_2_4
    l_2_9.szName = l_2_2
    l_2_9.nCount = tonumber(l_2_3)
    l_2_9.bFlash = l_2_1:Lookup("CheckBox_FlashAlarm"):IsCheckBoxChecked()
    l_2_9.bMsg = l_2_1:Lookup("CheckBox_MsgAlarm"):IsCheckBoxChecked()
    l_2_9.bSay = l_2_1:Lookup("CheckBox_SayAlarm"):IsCheckBoxChecked()
    l_2_9.szrgb = DBMSetBuff.szColor
    local l_2_10 = DBMSetPanel.GetCurrMod()
    if DBMSetBuff.type == "modify" then
      for l_2_14,l_2_15 in pairs(l_2_10.Buff) do
        if l_2_15.szName == DBMSetBuff.szName then
          l_2_9.bOn = l_2_15.bOn
          table.remove(l_2_10.Buff, l_2_14)
          do break end
        end
      end
      do break end
    end
    l_2_9.bOn = true
    for l_2_19,l_2_20 in pairs(l_2_10.Buff) do
      if l_2_20.szName == l_2_2 then
        MsgBox("�Ѵ��ڸ�Buff�����ݣ�")
        return 
      end
    end
    table.insert(l_2_10.Buff, l_2_9)
    Wnd.CloseWindow("DBMSetBuff")
    DBMSetPanel.UpdateBuff()
  end
end

l_0_0 = function(l_3_0)
  if Station.Lookup("Normal/DBMSetBuff") then
    return 
  end
  DBMSetBuff.szColor = "red"
  DBMSetBuff.type = "new"
  DBMSetBuff.szName = ""
  local l_3_1 = {}
  local l_3_2 = DBMSetPanel.GetCurrMod()
  if l_3_0 then
    DBMSetBuff.type = "modify"
    DBMSetBuff.szName = l_3_0
    for l_3_6,l_3_7 in pairs(l_3_2.Buff) do
      if l_3_7.szName == l_3_0 then
        l_3_1 = l_3_7
      end
    end
  end
  local l_3_8, l_3_24 = BoxSetFrame
  l_3_24 = "DBMSetBuff"
  local l_3_9, l_3_25 = nil
  local l_3_10, l_3_26 = nil
  l_3_8, l_3_9 = l_3_8(l_3_24, l_3_9), {w = 400, h = 420, bdrag = true, bglobal = true}
  l_3_24, l_3_9 = l_3_8:Center, l_3_8
  l_3_24(l_3_9)
  l_3_24 = l_3_8.handle
  l_3_9 = BoxLabel
  l_3_25 = l_3_24
  local l_3_11, l_3_27 = nil
  l_3_10 = "Label_Title"
  local l_3_12, l_3_28 = nil
  l_3_26 = "Buff����"
  local l_3_13, l_3_29 = nil
  local l_3_14, l_3_30 = nil
  l_3_27 = 0
  l_3_12 = 10
  l_3_27 = nil
  local l_3_15, l_3_31 = nil
  local l_3_16, l_3_32 = nil
  l_3_9(l_3_25, l_3_10, l_3_26, l_3_11, l_3_27, l_3_12)
  l_3_12, l_3_11 = {nW = 400, nH = 30, nHAlign = 1}, {l_3_27, l_3_12}
  l_3_9 = BoxLabel
  l_3_25 = l_3_24
  l_3_10 = "Label1"
  l_3_26 = "Buff���ƣ�"
  l_3_27 = 30
  l_3_12 = 50
  l_3_9(l_3_25, l_3_10, l_3_26, l_3_11)
  l_3_11 = {l_3_27, l_3_12}
  l_3_9 = BoxEdit
  l_3_25 = l_3_8.frame
  l_3_10 = "Edit_Name"
  l_3_9, l_3_26 = l_3_9(l_3_25, l_3_10, l_3_26), {x = 120, y = 50, w = 230, h = 30}
  l_3_25 = BoxLabel
  l_3_10 = l_3_24
  l_3_26 = "Label2"
  l_3_11 = "Buff���ͣ�"
  l_3_12 = 30
  l_3_28 = 88
  l_3_25(l_3_10, l_3_26, l_3_11, l_3_27)
  l_3_27 = {l_3_12, l_3_28}
  l_3_25 = BoxRadioBox
  l_3_10 = l_3_8.frame
  l_3_26 = "CheckBox_Buff"
  l_3_25, l_3_11 = l_3_25(l_3_10, l_3_26, l_3_11), {x = 120, y = 90, txt = "����"}
  l_3_10, l_3_26 = l_3_25:OnCheck, l_3_25
  l_3_11 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_DeBuff"):Check(false)
  end
  l_3_10(l_3_26, l_3_11)
  l_3_10 = BoxRadioBox
  l_3_26 = l_3_8.frame
  l_3_11 = "CheckBox_DeBuff"
  l_3_10, l_3_27 = l_3_10(l_3_26, l_3_11, l_3_27), {x = 200, y = 90, txt = "����"}
  l_3_26, l_3_11 = l_3_10:OnCheck, l_3_10
  l_3_27 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_Buff"):Check(false)
  end
  l_3_26(l_3_11, l_3_27)
  l_3_26 = BoxLabel
  l_3_11 = l_3_24
  l_3_27 = "Label3"
  l_3_12 = "Buff������"
  local l_3_17, l_3_33 = nil
  l_3_13 = 30
  l_3_29 = 125
  l_3_26(l_3_11, l_3_27, l_3_12, l_3_28)
  l_3_28 = {l_3_13, l_3_29}
  l_3_26 = BoxEdit
  l_3_11 = l_3_8.frame
  l_3_27 = "Edit_Count"
  l_3_26, l_3_12 = l_3_26(l_3_11, l_3_27, l_3_12), {x = 120, y = 125, w = 230, h = 30}
  l_3_11, l_3_27 = l_3_26:SetType, l_3_26
  l_3_12 = 0
  l_3_11(l_3_27, l_3_12)
  l_3_11 = BoxLabel
  l_3_27 = l_3_24
  l_3_12 = "Label4"
  l_3_28 = "BuffĿ�꣺"
  local l_3_18, l_3_34 = nil
  l_3_29 = 30
  l_3_14 = 163
  l_3_11(l_3_27, l_3_12, l_3_28, l_3_13)
  l_3_13 = {l_3_29, l_3_14}
  l_3_11 = BoxRadioBox
  l_3_27 = l_3_8.frame
  l_3_12 = "CheckBox_Self"
  l_3_11, l_3_28 = l_3_11(l_3_27, l_3_12, l_3_28), {x = 120, y = 165, txt = "����"}
  l_3_27, l_3_12 = l_3_11:OnCheck, l_3_11
  l_3_28 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_All"):Check(false)
  end
  l_3_27(l_3_12, l_3_28)
  l_3_27 = BoxRadioBox
  l_3_12 = l_3_8.frame
  l_3_28 = "CheckBox_All"
  l_3_27, l_3_13 = l_3_27(l_3_12, l_3_28, l_3_13), {x = 200, y = 165, txt = "Ⱥ��"}
  l_3_12, l_3_28 = l_3_27:OnCheck, l_3_27
  l_3_13 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_Self"):Check(false)
  end
  l_3_12(l_3_28, l_3_13)
  l_3_12 = BoxLabel
  l_3_28 = l_3_24
  l_3_13 = "Label5"
  l_3_29 = "��ʾ���ã�"
  local l_3_19, l_3_35 = nil
  local l_3_20, l_3_36 = nil
  l_3_30 = 30
  l_3_15 = 195
  l_3_12(l_3_28, l_3_13, l_3_29, l_3_14)
  l_3_14 = {l_3_30, l_3_15}
  l_3_12 = BoxCheckBox
  l_3_28 = l_3_8.frame
  l_3_13 = "CheckBox_FlashAlarm"
  l_3_12, l_3_29 = l_3_12(l_3_28, l_3_13, l_3_29), {x = 65, y = 225, txt = "ȫ������"}
  l_3_28 = BoxComboBox
  l_3_13 = l_3_8.frame
  l_3_29 = "ComboBox_FlashColor"
  l_3_28, l_3_14 = l_3_28(l_3_13, l_3_29, l_3_14), {txt = "������ɫ", x = 200, y = 225, w = 150, h = 25}
  l_3_28, l_3_13 = l_3_28:SetMenu, l_3_28
  l_3_29 = function(l_8_0)
    local l_8_1 = {}
    local l_8_2 = {}
    l_8_2.Name = "��"
    l_8_2.Val = "red"
    local l_8_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_8_4 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_8_5 = {}
    do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_8_6 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_8_7 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      do
        local l_8_8 = {}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for l_8_5,l_8_6 in l_8_2 do
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_9 = 0
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_10 = 255.insert
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_11 = 255
          local l_8_12 = {}
          l_8_12.szOption = l_8_6.Name .. " ��"
          l_8_12.bMCheck = true
          l_8_12.bChecked = DBMSetBuff.szColor == l_8_6.Val
          l_8_12.r = l_8_7
          l_8_12.g = l_8_8
          l_8_12.b = l_8_9
          l_8_12.fnAction = function()
          -- upvalues: l_5_6
          DBMSetBuff.szColor = l_5_6.Val
        end
          l_8_10(l_8_11, l_8_12)
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
  l_3_28(l_3_13, l_3_29)
  l_3_28 = BoxCheckBox
  l_3_13 = l_3_8.frame
  l_3_29 = "CheckBox_MsgAlarm"
  l_3_28, l_3_14 = l_3_28(l_3_13, l_3_29, l_3_14), {x = 65, y = 255, txt = "��������"}
  l_3_13 = BoxCheckBox
  l_3_29 = l_3_8.frame
  l_3_14 = "CheckBox_SayAlarm"
  do
    local l_3_21, l_3_37 = nil
    l_3_13, l_3_30 = l_3_13(l_3_29, l_3_14, l_3_30), {x = 200, y = 255, txt = "���챨��"}
    l_3_29 = BoxLabel
    l_3_14 = l_3_24
    l_3_30 = "Label6"
    l_3_15 = "��ʾ���ݣ�"
    local l_3_22 = nil
    local l_3_23 = nil
    l_3_16 = 30
    l_3_32 = 285
    l_3_29(l_3_14, l_3_30, l_3_15, l_3_31)
    l_3_31 = {l_3_16, l_3_32}
    l_3_29 = BoxEdit
    l_3_14 = l_3_8.frame
    l_3_30 = "Edit_Desc"
    l_3_29, l_3_15 = l_3_29(l_3_14, l_3_30, l_3_15), {bmulti = true, nlimit = 100, w = 300, h = 60, y = 315, x = 45}
    l_3_14 = BoxButton
    l_3_30 = l_3_8.frame
    l_3_15 = "Btn_Submit"
    l_3_14(l_3_30, l_3_15, l_3_31)
    l_3_31 = {txt = "ȷ��", y = 380, x = 70}
    l_3_14 = BoxButton
    l_3_30 = l_3_8.frame
    l_3_15 = "Btn_Cancle"
    l_3_14(l_3_30, l_3_15, l_3_31)
    l_3_31 = {txt = "ȡ��", y = 380, x = 230}
    l_3_14 = DBMSetBuff
    l_3_14 = l_3_14.type
    if l_3_14 == "modify" then
      l_3_14, l_3_30 = l_3_9:SetText, l_3_9
      l_3_15 = l_3_1.szName
      l_3_14(l_3_30, l_3_15)
      l_3_14 = l_3_25
      l_3_30 = l_3_1.nType
      if l_3_30 == 2 then
        l_3_14 = l_3_10
      end
      l_3_30, l_3_15 = l_3_14:Check, l_3_14
      l_3_31 = true
      l_3_30(l_3_15, l_3_31)
      l_3_14 = l_3_11
      l_3_30 = l_3_1.nTarget
      if l_3_30 == 2 then
        l_3_14 = l_3_27
      end
      l_3_30, l_3_15 = l_3_14:Check, l_3_14
      l_3_31 = true
      l_3_30(l_3_15, l_3_31)
      l_3_30, l_3_15 = l_3_26:SetText, l_3_26
      l_3_31 = l_3_1.nCount
      l_3_30(l_3_15, l_3_31)
      l_3_30, l_3_15 = l_3_29:SetText, l_3_29
      l_3_31 = l_3_1.szDesc
      l_3_30(l_3_15, l_3_31)
      l_3_30 = l_3_1.szrgb
      if l_3_30 then
        l_3_30 = DBMSetBuff
        l_3_15 = l_3_1.szrgb
        l_3_30.szColor = l_3_15
      else
        l_3_30 = DBMSetBuff
        l_3_30.szColor = "red"
      end
      l_3_30, l_3_15 = l_3_12:Check, l_3_12
      l_3_31 = l_3_1.bFlash
      l_3_30(l_3_15, l_3_31)
      l_3_30, l_3_15 = l_3_28:Check, l_3_28
      l_3_31 = l_3_1.bMsg
      l_3_30(l_3_15, l_3_31)
      l_3_30, l_3_15 = l_3_13:Check, l_3_13
      l_3_31 = l_3_1.bSay
      l_3_30(l_3_15, l_3_31)
    else
      l_3_14, l_3_30 = l_3_28:Check, l_3_28
      l_3_15 = true
      l_3_14(l_3_30, l_3_15)
      l_3_14, l_3_30 = l_3_25:Check, l_3_25
      l_3_15 = true
      l_3_14(l_3_30, l_3_15)
      l_3_14, l_3_30 = l_3_11:Check, l_3_11
      l_3_15 = true
      l_3_14(l_3_30, l_3_15)
      l_3_14, l_3_30 = l_3_26:SetText, l_3_26
      l_3_15 = 1
      l_3_14(l_3_30, l_3_15)
    end
    l_3_14, l_3_30 = l_3_24:FormatAllItemPos, l_3_24
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_3_14(l_3_30)
end

OpenDBMSetBuff = l_0_0

