-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SkillRange.lua 

local l_0_0 = "interface\\Moon_SkillRange\\SkillRange.ini"
local l_0_1 = {}
l_0_1.tPetTimeInfo = {}
l_0_1.tSeeList = {}
l_0_1.tCast = {}
l_0_1.nMinDelay = 500
l_0_1.nMaxDelay = 1400
l_0_1.nMax = 10
l_0_1.nAlpha = 40
l_0_1.bShowQiChang = false
l_0_1.bShowJiGuan = false
l_0_1.bShowName = true
l_0_1.bShowDistance = false
l_0_1.tColor = {}
local l_0_2 = {}
local l_0_3 = {}
l_0_3[15959] = true
l_0_2[2] = l_0_3
l_0_2[3], l_0_3 = l_0_3, {[15959] = true}
l_0_2[4], l_0_3 = l_0_3, {[0] = true}
l_0_1.tHide = l_0_2
l_0_1.nRenderCount = -1
SkillRange = l_0_1
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.nMax"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.nAlpha"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.bShowDistance"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.bShowQiChang"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.bShowJiGuan"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.bShowName"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.tColor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "SkillRange.tHide"
l_0_1(l_0_2)
l_0_2 = {name = "��ɽ��", dwSkillID = 371, dwStartModelID = 3574, dwEndModelID = 3852, dwTemplateID = 4982, dwTime = 8}
l_0_2 = {name = "��̫��", dwSkillID = 358, dwStartModelID = 3574, dwEndModelID = 3846, dwTemplateID = 4976, dwTime = 24}
l_0_2 = {name = "������", dwSkillID = 363, dwStartModelID = 3574, dwEndModelID = 3851, dwTemplateID = 4981, dwTime = 24}
l_0_2 = {name = "������", dwSkillID = 357, dwStartModelID = 3574, dwEndModelID = 2122, dwTemplateID = 3080, dwTime = 24}
l_0_2 = {name = "������", dwSkillID = 360, dwStartModelID = 3574, dwEndModelID = 3848, dwTemplateID = 4978, dwTime = 8}
l_0_2 = {name = "�Ʋ��", dwSkillID = 359, dwStartModelID = 3574, dwEndModelID = 3847, dwTemplateID = 4977, dwTime = 24}
l_0_2 = {name = "��̫��", dwSkillID = 361, dwStartModelID = 3574, dwEndModelID = 3849, dwTemplateID = 4979, dwTime = 24}
l_0_2 = {name = "���ǳ�", dwSkillID = 362, dwStartModelID = 3574, dwEndModelID = 3850, dwTemplateID = 4980, dwTime = 24}
l_0_2 = {name = "����", dwSkillID = 3368, dwStartModelID = 26327, dwEndModelID = 26290, dwTemplateID = 16175, dwTime = 120}
l_0_2 = {name = "����", dwSkillID = 3369, dwStartModelID = 26329, dwEndModelID = 26291, dwTemplateID = 16176, dwTime = 120}
l_0_2 = {name = "��ɷ", dwSkillID = 3370, dwStartModelID = 26326, dwEndModelID = 26292, dwTemplateID = 16177, dwTime = 8}
l_0_2 = {name = "���Ƕ�Ӱ", dwSkillID = 3103, dwStartModelID = 26106, dwEndModelID = 26069, dwTemplateID = 15959, dwTime = 30}
l_0_2 = {name = "�������", dwSkillID = 3108, dwStartModelID = 26113, dwEndModelID = 26112, dwTemplateID = 15994, dwTime = 15}
l_0_2 = {name = "����ɱ��", dwSkillID = 3111, dwStartModelID = 26123, dwEndModelID = 26122, dwTemplateID = 16000, dwTime = 60}
l_0_2 = {name = "������צ", dwSkillID = 3107, dwStartModelID = 26121, dwEndModelID = 26120, dwTemplateID = 15999, dwTime = 30}
l_0_3 = "�Լ���"
local l_0_4 = {}
local l_0_5 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_6 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_7 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_8 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

do
  local l_0_9 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_5(l_0_6, l_0_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_6(l_0_7, l_0_8, l_0_9, 0, 255.Create)
end
 -- WARNING: undefined locals caused missing assignments!

