-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMData.lua 

DBMPanel.convertStr = function(l_1_0)
  local l_1_1 = function(l_2_0, l_2_1)
    local l_2_2 = {}
    for l_2_6,l_2_7 in ipairs(l_2_0) do
      if type(l_2_1[l_2_7]) == "boolean" then
        local l_2_8 = 0
        if l_2_1[l_2_7] then
          l_2_8 = 1
        end
        table.insert(l_2_2, l_2_8)
      else
        if type(l_2_1[l_2_7]) == "table" then
          local l_2_17, l_2_18 = table.insert, l_2_2
          l_2_17(l_2_18, table.concat(l_2_1[l_2_7], ","))
        end
      else
        local l_2_12, l_2_13 = nil
      end
      l_2_12 = table
      l_2_12 = l_2_12.insert
      local l_2_14 = nil
      l_2_13 = l_2_2
      local l_2_15 = nil
      l_2_14 = l_2_1[l_2_7]
      local l_2_16 = nil
      l_2_12(l_2_13, l_2_14)
    end
    local l_2_9 = table.concat
    local l_2_10 = l_2_2
    local l_2_11 = "|"
    return l_2_9(l_2_10, l_2_11)
  end
  local l_1_2 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_1_3 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  do
    local l_1_4 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_1_8,l_1_9 in "bOn"("bFlash") do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_1_10 = "nTarget"("szName", "szDesc")
       -- DECOMPILER ERROR: Overwrote pending register.

      table.insert(l_1_3.buffandskill, "szrgb" .. l_1_10)
    end
    do
      local l_1_11 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_1_15,l_1_16 in "bOn"("bFlash") do
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_1_17 = "nTarget"("nCount", "szName")
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        table.insert(l_1_3.buffandskill, "szDesc" .. "szrgb")
      end
    end
    return l_1_3
  end
   -- WARNING: undefined locals caused missing assignments!
end

local l_0_0 = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = 1
  local l_2_4 = 1
  local l_2_5 = {}
  if not l_2_2 then
    l_2_2 = 1
  end
  while 1 do
    local l_2_6 = string.find(l_2_0, l_2_1, l_2_3)
    if not l_2_6 then
      l_2_5[l_2_4] = string.sub(l_2_0, l_2_3, string.len(l_2_0))
      do break end
    end
    l_2_5[l_2_4] = string.sub(l_2_0, l_2_3, l_2_6 - 1)
    l_2_3 = l_2_6 + l_2_2
    l_2_4 = l_2_4 + 1
  end
  return l_2_5
end

DBMPanel.convertTable = function(l_3_0)
  -- upvalues: l_0_0
  local l_3_2 = function(l_4_0, l_4_1, l_4_2, l_4_3)
    -- upvalues: l_0_0
    do break end
    do
      local l_4_4, l_4_5, l_4_6, l_4_7, l_4_8 = ipairs(l_4_0)
      local l_4_9 = l_4_8[2]
      local l_4_10 = l_4_8[1]
      local l_4_11 = l_4_7
      if l_4_2 == "skill" or l_4_2 == "buff" then
        l_4_11 = l_4_7 + 1
      end
      if l_4_9 == "boolean" then
        l_4_3[l_4_10] = false
        if l_4_1[l_4_11] == "1" then
          l_4_3[l_4_10] = true
        end
        do break end
      end
      if l_4_9 == "table" then
        local l_4_12 = l_0_0(l_4_1[l_4_11], ",")
        l_4_3[l_4_10] = {}
        for l_4_16,l_4_17 in ipairs(l_4_12) do
          l_4_3[l_4_10][l_4_16] = tonumber(l_4_17)
        end
      elseif l_4_9 == "number" then
        l_4_3[l_4_10] = tonumber(l_4_1[l_4_11]) or 2
      elseif l_4_10 == "szrgb" and StringFindW(l_4_1[l_4_11], ",") then
        l_4_3[l_4_10] = "red"
      else
        l_4_3[l_4_10] = l_4_1[l_4_11]
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
  local l_3_3 = {}
  local l_3_4 = {"bOn", "boolean"}
  local l_3_5 = {"bEnter", "boolean"}
  local l_3_6 = {"bArea", "boolean"}
  local l_3_7 = {"nAngle", "number"}
  local l_3_8 = {"nRange", "number"}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_3_5 = {}
  l_3_5 = {}
  l_3_5 = l_0_0
  l_3_6 = l_3_0.base
  l_3_7 = "|"
  l_3_5 = l_3_5(l_3_6, l_3_7)
  l_3_6 = l_3_2
  l_3_7 = l_3_3
  l_3_8 = l_3_5
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_6(l_3_7, l_3_8, {"bLife", "boolean"}, l_3_4)
  l_3_6 = l_3_0.tLife
  l_3_4.tLife = l_3_6
  l_3_8 = "bOn"
  local l_3_9 = {"bMsg", "boolean"}
  local l_3_10 = {"bSay", "boolean"}
  local l_3_11 = {"type", "number"}
  local l_3_12 = {"nTarget", "number"}
  local l_3_13 = {"szName", "string"}
  local l_3_14 = {"szDesc", "string"}
  l_3_8, l_3_7 = {"bFlash", "boolean"}, {l_3_8, "boolean"}
  l_3_9 = "bOn"
  l_3_10 = "boolean"
  l_3_10 = "bFlash"
  l_3_11 = "boolean"
  l_3_11 = "bMsg"
  l_3_12 = "boolean"
  l_3_12 = "bSay"
  l_3_13 = "boolean"
  l_3_13 = "nType"
  l_3_14 = "number"
  l_3_14 = "nTarget"
  local l_3_15 = {"szName", "string"}
  do
    local l_3_16 = {"szDesc", "string"}
    l_3_14, l_3_13, l_3_12, l_3_11, l_3_10, l_3_9, l_3_8 = {"nCount", "number"}, {l_3_14, "number"}, {l_3_13, l_3_14}, {l_3_12, l_3_13}, {l_3_11, l_3_12}, {l_3_10, l_3_11}, {l_3_9, l_3_10}
    l_3_8 = ipairs
    l_3_9 = l_3_0.buffandskill
    l_3_8 = l_3_8(l_3_9)
    for l_3_11,l_3_12 in l_3_8 do
      l_3_13 = string
      l_3_13 = l_3_13.gsub
      l_3_14 = l_3_12
      l_3_15 = "\n"
      l_3_16 = ""
      l_3_13 = l_3_13(l_3_14, l_3_15, l_3_16)
      l_3_12 = l_3_13
      l_3_13 = l_0_0
      l_3_14 = l_3_12
      l_3_15 = "|"
      l_3_13 = l_3_13(l_3_14, l_3_15)
      l_3_5 = l_3_13
      l_3_13 = l_3_5[1]
      if l_3_13 == "0" then
        l_3_13 = l_3_4.Skill
        l_3_13 = #l_3_13
        l_3_13 = l_3_13 + 1
        l_3_14 = l_3_4.Skill
        l_3_14[l_3_13], l_3_15 = l_3_15, {}
        l_3_14 = l_3_2
        l_3_15, l_3_6 = l_3_6, {l_3_7, l_3_8, l_3_9, l_3_10, l_3_11, l_3_12, l_3_13, l_3_14, 
{"szrgb", "string"}}
        l_3_16 = l_3_5
        l_3_14(l_3_15, l_3_16, "skill", l_3_4.Skill[l_3_13])
      else
        l_3_13 = l_3_4.Buff
        l_3_13 = #l_3_13
        l_3_13 = l_3_13 + 1
        l_3_14 = l_3_4.Buff
        l_3_14[l_3_13], l_3_15 = l_3_15, {}
        l_3_14 = l_3_2
        l_3_15, l_3_7 = l_3_7, {l_3_8, l_3_9, l_3_10, l_3_11, l_3_12, l_3_13, l_3_14, l_3_15, l_3_16, 
{"szrgb", "string"}}
        l_3_16 = l_3_5
        l_3_14(l_3_15, l_3_16, "buff", l_3_4.Buff[l_3_13])
      end
    end
    return l_3_4
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

DBMPanel.LoadPredefinedData = function(l_4_0)
  if not MoonDBMPredefinedData[l_4_0] then
    return 
  end
  DBMPanel.ModData[l_4_0] = {}
  local l_4_1 = MoonDBMPredefinedData[l_4_0]
  DBMPanel.ModData[l_4_0].bOn = l_4_1.bOn
  DBMPanel.ModData[l_4_0].bossMod = l_4_1.bossMod
  DBMPanel.ModData[l_4_0].bossData = {}
  for l_4_5,l_4_6 in ipairs(l_4_1.bossMod) do
    local l_4_7 = l_4_1.bossData[l_4_6]
    DBMPanel.ModData[l_4_0].bossData[l_4_6] = DBMPanel.convertTable(l_4_7)
  end
  DBMPanel.UpdateDungeonList()
  DBMPanel.UpdateBossList()
  CloseDBMSetPanel()
end

MoonDBMData = {}
RegisterCustomData("MoonDBMData")
RegisterEvent("PLAYER_EXIT_GAME", function()
  MoonDBMData = {}
  do break end
  local l_5_0, l_5_1, l_5_2, l_5_3, l_5_4 = ipairs(DBMPanel.ModList)
  local l_5_5 = DBMPanel.ModData[l_5_4]
  if l_5_5 then
    MoonDBMData[l_5_4] = {}
    MoonDBMData[l_5_4].bOn = l_5_5.bOn
    MoonDBMData[l_5_4].bossMod = l_5_5.bossMod
    MoonDBMData[l_5_4].bossData = {}
    for l_5_9,l_5_10 in ipairs(l_5_5.bossMod) do
      local l_5_11 = l_5_5.bossData[l_5_10]
      MoonDBMData[l_5_4].bossData[l_5_10] = DBMPanel.convertStr(l_5_11)
    end
  end
end
end
)
RegisterEvent("CUSTOM_DATA_LOADED", function()
  if arg0 == "Role" then
    local l_6_0 = {}
    local l_6_1 = {}
    for l_6_5,l_6_6 in ipairs(DBMPanel.ModList) do
      table.insert(l_6_0, l_6_6)
      l_6_1[l_6_6] = true
    end
    for l_6_10,l_6_11 in ipairs(MoonDBMPredefinedList) do
      if not l_6_1[l_6_11] then
        table.insert(l_6_0, l_6_11)
        table.insert(DBMPanel.ModList, l_6_11)
      end
    end
    do break end
    local l_6_12, l_6_13, l_6_14, l_6_15, l_6_16 = ipairs(l_6_0)
    if not MoonDBMData[l_6_16] then
      local l_6_17, l_6_18, l_6_19, l_6_20, l_6_21, l_6_22, l_6_23, l_6_24 = MoonDBMPredefinedData[l_6_16]
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_6_17 then
      DBMPanel.ModData[l_6_16] = {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      DBMPanel.ModData[l_6_16].bOn = l_6_17.bOn
       -- DECOMPILER ERROR: Confused about usage of registers!

      DBMPanel.ModData[l_6_16].bossMod = l_6_17.bossMod
      DBMPanel.ModData[l_6_16].bossData = {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      for l_6_28,l_6_29 in ipairs(l_6_17.bossMod) do
        local l_6_25 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        DBMPanel.ModData[l_6_16].bossData[l_6_30] = DBMPanel.convertTable(l_6_25.bossData[l_6_22])
      end
    end
  end
end
end
)

