-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon.lua 

local l_0_0 = {}
l_0_0.nCurrentPage = 1
Moon = l_0_0
l_0_0 = 14
local l_0_1 = {}
l_0_1.General = {}
l_0_1.Team = {}
local l_0_2 = {}
l_0_2.General = {}
l_0_2.Team = {}
Moon.OnFrameCreate = function()
  -- upvalues: l_0_1 , l_0_2
  local l_1_0 = Station.Lookup("Normal/Moon")
  local l_1_1 = l_1_0:Lookup("Wnd_Content")
  local l_1_2 = l_1_1:Lookup("", "")
  Moon.frame = l_1_0
  Moon.handle = l_1_2
  Moon.list = l_1_2:Lookup("Handle_List")
  Moon.Details = l_1_0:Lookup("Wnd_Details")
  local l_1_3 = BoxLabel
  local l_1_4 = l_1_2
  local l_1_5 = "Text_Title"
  local l_1_6 = "����(������Ե�������)"
  local l_1_7 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_1_8 = 10
  local l_1_9 = {}
  l_1_9.nW = 771
  l_1_9.nH = 30
  l_1_9.nHAlign = 1
  l_1_3(l_1_4, l_1_5, l_1_6, l_1_7, l_1_8, l_1_9)
  l_1_3 = Moon
  l_1_4 = BoxButton
  l_1_5 = l_1_0
  l_1_6 = "Btn_Prev"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "��һҳ", w = 80, h = 27, x = 20, y = 455}
  l_1_3.btnPrev = l_1_4
  l_1_3 = Moon
  l_1_4 = BoxButton
  l_1_5 = l_1_0
  l_1_6 = "Btn_Next"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "��һҳ", w = 80, h = 27, x = 160, y = 455}
  l_1_3.btnNext = l_1_4
  l_1_3 = Moon
  l_1_4 = BoxLabel
  l_1_5 = l_1_2
  l_1_6 = "Text_Page"
  l_1_7 = ""
  l_1_9 = 105
  l_1_9 = nil
  local l_1_10 = {}
  l_1_10.nW = 50
  l_1_10.nH = 25
  l_1_10.nHAlign = 1
  l_1_4, l_1_8 = l_1_4(l_1_5, l_1_6, l_1_7, l_1_8, l_1_9, l_1_10), {l_1_9, 455}
  l_1_3.pageTxt = l_1_4
  l_1_3, l_1_4 = l_1_2:FormatAllItemPos, l_1_2
  l_1_3(l_1_4)
  l_1_4 = pairs
  l_1_5 = l_0_1
  l_1_4 = l_1_4(l_1_5)
  for l_1_7,l_1_8 in l_1_4 do
    l_1_9 = l_0_2
    l_1_9 = l_1_9[l_1_7]
    l_1_9 = #l_1_9
    if l_1_9 > 0 then
      l_1_9 = "CheckBox_"
      l_1_10 = l_1_7
      l_1_9 = l_1_9 .. l_1_10
      l_1_10 = BoxUICheckBox
      l_1_10 = l_1_10(l_1_0, l_1_9, "plugingroup")
      l_1_10:OnCheck(function()
        Moon.nCurrentPage = 1
        Moon.UpdateList()
      end)
      if l_1_7 == "General" then
        l_1_10:SetText("����")
      end
    do
      elseif l_1_7 == "Team" then
        local l_1_16, l_1_17, l_1_18, l_1_19, l_1_20, l_1_21, l_1_22, l_1_23, l_1_24, l_1_25, l_1_26, l_1_27, l_1_28, l_1_29, l_1_30 = nil
      end
      l_1_16, l_1_17 = l_1_10:SetText, l_1_10
      l_1_18 = "�Ŷ�"
      l_1_16(l_1_17, l_1_18)
    end
  end
  for l_1_10,i_2 in ipairs({l_1_9, l_1_10}) do
    local l_1_12 = l_1_0:Lookup(l_1_11)
    if l_1_12 then
      l_1_12:SetRelPos(25 + (1 - 1) * 15, 52)
      local l_1_13 = l_1_12:Lookup("", "Text_CheckBox")
      local l_1_14 = l_1_13:GetTextPosExtent()
      local l_1_15 = l_1_13:GetTextExtent()
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if 1 == 1 then
        l_1_12:Check(true)
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

    end
  end
  if not true then
    Moon.UpdateList()
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_0:SetPoint(l_1_9, l_1_10, 0, "CENTER", 0, 0)
  l_1_0:RegisterEvent("UI_SCALED")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- WARNING: undefined locals caused missing assignments!
end

Moon.GetActivePageName = function()
  local l_2_0 = "General"
  local l_2_1 = Moon.frame:Lookup("CheckBox_Team")
  if l_2_1 and l_2_1:IsCheckBoxChecked() then
    l_2_0 = "Team"
  end
  return l_2_0
end

Moon.UpdateList = function()
  -- upvalues: l_0_2 , l_0_0 , l_0_1
  local l_3_0 = Moon.GetActivePageName()
  local l_3_1 = math.ceil(#l_0_2[l_3_0] / l_0_0)
  if #l_0_2[l_3_0] > 0 then
    table.sort(l_0_2[l_3_0])
  end
  Moon.list:Clear()
  local l_3_2 = (Moon.nCurrentPage - 1) * l_0_0 + 1
  local l_3_3 = (Moon.nCurrentPage - 1) * l_0_0 + l_0_0
  for l_3_7 = l_3_2, l_3_3 do
    if l_0_2[l_3_0][l_3_7] then
      local l_3_8 = l_0_2[l_3_0][l_3_7]
      local l_3_9 = l_0_1[l_3_0][l_3_8]
      local l_3_10 = BoxUIButton(Moon.list, l_3_8, l_3_9.ico)
      l_3_10:SetText(l_3_9.title)
      local l_3_11 = math.ceil((l_3_7 - l_0_0 * (Moon.nCurrentPage - 1)) / 2) - 1
      local l_3_12 = 0
      if l_3_7 % 2 == 0 then
        l_3_12 = 125
      end
      l_3_10:SetRelPos(l_3_12, l_3_11 * 50)
    end
  end
  Moon.list:FormatAllItemPos()
  Moon.pageTxt:SetText(Moon.nCurrentPage .. "/" .. l_3_1)
  Moon.UpdatePage(l_3_1)
end

Moon.UpdatePage = function(l_4_0)
  if Moon.nCurrentPage == 1 or Moon.nCurrentPage == 0 then
    Moon.btnPrev:Enable(false)
  else
    Moon.btnPrev:Enable(true)
  end
  if Moon.nCurrentPage == l_4_0 then
    Moon.btnNext:Enable(false)
  else
    Moon.btnNext:Enable(true)
  end
end

Moon.OnLButtonClick = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "Btn_Prev" then
    Moon.nCurrentPage = Moon.nCurrentPage - 1
    Moon.UpdateList()
  elseif l_5_0 == "Btn_Next" then
    Moon.nCurrentPage = Moon.nCurrentPage + 1
    Moon.UpdateList()
  elseif l_5_0 == "Btn_Close" then
    ActiveMoon()
  end
end

Moon.OnItemLButtonClick = function()
  -- upvalues: l_0_1
  local l_6_0 = this:GetName()
  if this.bBtn then
    local l_6_1 = Moon.frame:Lookup("Window_Details")
    if l_6_1 then
      l_6_1:Destroy()
    end
    local l_6_2 = BoxWindow
    local l_6_3 = Moon.frame
    local l_6_4 = "Window_Details"
    local l_6_5 = {}
    l_6_5.x = 290
    l_6_5.y = 90
    l_6_5.w = 490
    l_6_5.h = 400
    l_6_2 = l_6_2(l_6_3, l_6_4, l_6_5)
    l_6_1 = l_6_2
    l_6_2 = Moon
    l_6_2 = l_6_2.GetActivePageName
    l_6_2 = l_6_2()
    l_6_3 = l_0_1
    l_6_3 = l_6_3[l_6_2]
    l_6_3 = l_6_3[l_6_0]
  end
  if l_6_3 then
    l_6_3 = l_0_1
    l_6_3 = l_6_3[l_6_2]
    l_6_3 = l_6_3[l_6_0]
    l_6_3 = l_6_3.fnAction
    l_6_4 = l_6_1.hwindow
    l_6_3(l_6_4)
  end
end

RegisterMoonButton = function(l_7_0, l_7_1, l_7_2, l_7_3, l_7_4)
  -- upvalues: l_0_1 , l_0_2
  if l_0_1[l_7_3] then
    local l_7_5 = l_0_1[l_7_3]
    local l_7_6 = {}
    l_7_6.title = l_7_2
    l_7_6.ico = l_7_1
    l_7_6.fnAction = l_7_4
    l_7_5[l_7_0] = l_7_6
    l_7_5 = table
    l_7_5 = l_7_5.insert
    l_7_6 = l_0_2
    l_7_6 = l_7_6[l_7_3]
    l_7_5(l_7_6, l_7_0)
  end
end

Moon.CheckAddon = function(l_8_0, l_8_1, l_8_2)
  local l_8_3 = GetAddOnCount() - 1
  for l_8_7 = 0, l_8_3 do
    local l_8_8 = GetAddOnInfo(l_8_7)
    if l_8_8.bEnable or l_8_8.bDefault and not l_8_8.bDisable then
      if l_8_8.szID == l_8_0 and l_8_8.szDependence == "Moon_Base" then
        return true
      end
    elseif l_8_1 and l_8_8.szID == l_8_0 then
      if l_8_2 then
        return true, l_8_8
      end
    else
      return true
    end
  end
  return false
end

ActiveMoon = function()
  if not Station.Lookup("Normal/Moon") then
    local l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5 = Wnd.OpenWindow("interface/Moon_Base/Moon.ini", "Moon")
    l_9_1, l_9_2 = l_9_0:Show, l_9_0
    l_9_1(l_9_2)
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_9_0:IsVisible() then
    l_9_0:Hide()
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_9_0:Show()
  end
end

Moon.OnFrameKeyDown = function()
  if GetKeyName(Station.GetMessageKey()) == "Esc" then
    local l_10_0 = Station.Lookup("Normal/Moon")
    l_10_0:Hide()
    return 1
  end
end

Moon.OnFrameBreathe = function()
  FireEvent("Breathe")
end

Moon.OnEvent = function(l_12_0)
  if l_12_0 == "UI_SCALED" then
    this:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  end
end

local l_0_3 = {}
RegisterMoonMenu = function(l_13_0, l_13_1)
  -- upvalues: l_0_3
  l_0_3[l_13_0] = l_13_1
end

Moon.GetSystemMenuCount = function()
  local l_14_0 = 0
  local l_14_1 = Station.Lookup("Topmost/SystemMenu")
  local l_14_2 = l_14_1:Lookup("Wnd_Menu")
  local l_14_3 = l_14_2:GetFirstChild()
  if l_14_3 then
    if l_14_3:GetType() == "WndButton" then
      l_14_0 = l_14_0 + 1
    end
    l_14_3 = l_14_3:GetNext()
  end
end
return l_14_0
end

Moon.AppendOnSystemMenuRight = function(l_15_0)
  -- upvalues: l_0_3
  local l_15_1 = l_15_0:Lookup("Wnd_Menu")
  local l_15_2 = l_15_1:Lookup("Btn_Moon")
  if l_15_2 then
    return 
  end
  local l_15_3, l_15_4 = l_15_0:GetSize()
  l_15_0:SetSize(l_15_3 + 36, l_15_4)
  l_15_3 = l_15_1:GetSize()
  l_15_1:SetSize(l_15_3 + 36, l_15_4)
  local l_15_5, l_15_6 = l_15_0:GetAbsPos()
  l_15_0:SetAbsPos(l_15_5 - 36, l_15_6)
  local l_15_7 = l_15_1:GetFirstChild()
  if l_15_7 then
    if l_15_7:GetType() == "WndButton" then
      local l_15_8, l_15_9 = l_15_7:GetRelPos()
      l_15_7:SetRelPos(l_15_8 + 36, l_15_9)
    end
    l_15_7 = l_15_7:GetNext()
  end
end
local l_15_10 = Wnd.OpenWindow("interface/Moon_Base/MoonBtn.ini", "MoonBtn")
local l_15_11 = l_15_10:Lookup("Btn_Moon")
l_15_11:ChangeRelation(l_15_1, true, true)
Wnd.CloseWindow("MoonBtn")
local l_15_12 = l_15_1:Lookup("Btn_Char")
local l_15_13, l_15_14 = l_15_12:GetAbsPos()
l_15_11:SetAbsPos(l_15_13 - 36, l_15_14)
l_15_11.OnLButtonClick = function()
  ActiveMoon()
end

l_15_11.OnMouseEnter = function()
  -- upvalues: l_15_9 , l_0_3
  local l_17_0, l_17_1 = l_15_9:GetAbsPos()
  if IsEmpty(l_0_3) then
    return 
  end
  do
    local l_17_2 = {}
    for l_17_6,l_17_7 in table.pairsByKeys(l_0_3) do
      table.insert(l_17_2, l_17_7)
    end
    local l_17_8 = PopBoxMenu
    local l_17_9 = l_17_2
    do
      local l_17_10 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_17_8(l_17_9, l_17_10)
  end
   -- WARNING: undefined locals caused missing assignments!
end

end

AppendMoonBtn = function()
  local l_16_0 = Station.Lookup("Topmost/SystemMenu_Right")
  if l_16_0 then
    Moon.AppendOnSystemMenuRight(l_16_0)
  end
end

RegisterEvent("CUSTOM_DATA_LOADED", function()
  if arg0 == "Role" then
    AppendMoonBtn()
    Wnd.OpenWindow("interface/Moon_Base/Moon.ini", "Moon"):Hide()
    FireEvent("AddonLoad")
  end
end
)
RegisterBoxAddonVersion("Moon_Base", 5.4)

