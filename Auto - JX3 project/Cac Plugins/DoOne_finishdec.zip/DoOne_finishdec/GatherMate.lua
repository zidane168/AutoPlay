-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: GatherMate.lua 

local l_0_0 = {}
l_0_0.bStela = true
l_0_0.bMiddleMap = true
l_0_0.bMiniMap = false
l_0_0.bCollection = true
GatherMate = l_0_0
l_0_0 = RegisterCustomData
l_0_0("GatherMate.bStela")
l_0_0 = RegisterCustomData
l_0_0("GatherMate.bMiddleMap")
l_0_0 = RegisterCustomData
l_0_0("GatherMate.bMiniMap")
l_0_0 = RegisterCustomData
l_0_0("GatherMate.bCollection")
l_0_0 = GatherMate
l_0_0.WatchList = {}
l_0_0 = RegisterCustomData
l_0_0("GatherMate.WatchList")
l_0_0 = GatherMate
l_0_0.tSceneDoodad = {}
local l_0_1 = 0
local l_0_2 = 0
local l_0_3 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_4 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_5 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

if not "��ҩ" then
  local l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14 = MiddleMap.OnItemMouseEnter, "����", "��˼��", "����", "��ǰ��", "������", "��ζ��", "������", "��С��"
end
local l_0_15 = nil
RegisterEvent("AddonLoad", GatherMate.ApplySettings)
RegisterEvent("OnMiddleMapUpdateCurrentMap", GatherMate.c)
RegisterEvent("OnMiddleMapShowMap", GatherMate.ShowAll)
Wnd.OpenWindow("Interface\\Moon_GatherMate\\Settings.ini", "GatherMate")
RegisterEvent("Breathe", function()
  if not GatherMate.bCollection then
    return 
  end
  local l_13_0 = GetClientPlayer()
  if not l_13_0 or l_13_0.GetOTActionState() ~= 0 or l_13_0.nMoveState ~= MOVE_STATE.ON_STAND or l_13_0.bFightState then
    return 
  end
  if GetLogicFrameCount() % 4 == 0 then
    GatherMate.OnCollectDoodad()
  end
end
)
do
  local l_0_16 = {nX = 7, nY = 63, nW = 1033, nH = 775}
  RegisterMoonButton("GatherMate", 937, "�ɼ�����", "General", GatherMate.Create)
end
 -- WARNING: undefined locals caused missing assignments!

