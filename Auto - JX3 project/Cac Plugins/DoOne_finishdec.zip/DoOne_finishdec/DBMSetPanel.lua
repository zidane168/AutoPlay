-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMSetPanel.lua 

local l_0_0 = "interface\\Moon_DBM\\DBMSetPanel.ini"
local l_0_1 = {}
l_0_1.showDungeon = ""
l_0_1.showMod = ""
DBMSetPanel = l_0_1
l_0_1 = DBMSetPanel
l_0_1.OnFrameCreate = function()
  this:Hide()
  DBMSetPanel.frame = this
  DBMSetPanel.pageTotal = DBMSetPanel.frame:Lookup("Page_Total")
  DBMSetPanel.pageSkill = DBMSetPanel.pageTotal:Lookup("Page_Skill")
  DBMSetPanel.skillList = DBMSetPanel.pageSkill:Lookup("", "Handle_SkillList")
  DBMSetPanel.pageBuff = DBMSetPanel.pageTotal:Lookup("Page_Buff")
  DBMSetPanel.buffList = DBMSetPanel.pageBuff:Lookup("", "Handle_BuffList")
  DBMSetPanel.pageBase = DBMSetPanel.pageTotal:Lookup("Page_Base")
  BoxUpdateScroll("Handle_SkillList", "DBMSetPanel", true)
  BoxUpdateScroll("Handle_BuffList", "DBMSetPanel", true)
  this:RegisterEvent("CORRECT_AUTO_POS")
end

l_0_1 = DBMSetPanel
l_0_1.OnEvent = function(l_2_0)
  if l_2_0 == "CORRECT_AUTO_POS" and arg0 == "DBMPanel" then
    DBMSetPanel.OnCorrectPos(this)
  end
end

l_0_1 = DBMSetPanel
l_0_1.ToggleSkillOrBuff = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = DBMSetPanel.GetCurrMod()
  local l_3_4 = l_3_3.Skill
  if l_3_0 == "buff" then
    l_3_4 = l_3_3.Buff
  end
  for l_3_8,l_3_9 in ipairs(l_3_4) do
    if l_3_1 == l_3_9.szName then
      l_3_4[l_3_8].bOn = l_3_2
    end
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnCorrectPos = function(l_4_0)
  l_4_0:SetPoint("TOPLEFT", 0, 0, "Normal/DBMPanel", "TOPLEFT", 380, 0)
end

l_0_1 = DBMSetPanel
l_0_1.GetCurrMod = function()
  return DBMPanel.ModData[DBMSetPanel.showDungeon].bossData[DBMSetPanel.showMod]
end

l_0_1 = DBMSetPanel
l_0_1.UpdateAll = function()
  local l_6_0 = DBMSetPanel.frame:Lookup("", "")
  l_6_0:Lookup("Text_Title"):SetText("��������(" .. DBMSetPanel.showMod .. ")")
  local l_6_1 = DBMSetPanel.pageTotal:GetActivePage()
  DBMSetPanel.UpdateBase()
  DBMSetPanel.UpdateSkill()
  DBMSetPanel.UpdateBuff()
end

l_0_1 = DBMSetPanel
l_0_1.UpdateBase = function()
  local l_7_0 = DBMSetPanel.pageBase
  local l_7_1 = DBMSetPanel.GetCurrMod()
  l_7_0:Lookup("CheckBox_AttackArea"):Check(l_7_1.bArea)
  l_7_0:Lookup("CheckBox_LifeTip"):Check(l_7_1.bLife)
  l_7_0:Lookup("CheckBox_NpcEnter"):Check(l_7_1.bEnter)
  l_7_0:Lookup("Window_AttackAngle/Edit_AttackAngle"):SetText(tostring(l_7_1.nAngle))
  l_7_0:Lookup("Window_AttackRange/Edit_AttackRange"):SetText(tostring(l_7_1.nRange))
end

l_0_1 = DBMSetPanel
l_0_1.GetSel = function(l_8_0)
  local l_8_1 = DBMSetPanel.buffList
  if l_8_0 == "skill" then
    l_8_1 = DBMSetPanel.skillList
  end
  local l_8_2 = l_8_1:GetItemCount()
  for l_8_6 = 0, l_8_2 do
    local l_8_7 = l_8_1:Lookup(l_8_6)
    if l_8_7 and l_8_7.bSel then
      return l_8_7
    end
  end
  return nil
end

l_0_1 = DBMSetPanel
l_0_1.UpdateSkill = function()
  local l_9_0 = DBMSetPanel.skillList
  l_9_0:Clear()
  local l_9_1 = DBMSetPanel.GetCurrMod()
  for l_9_5,l_9_6 in ipairs(l_9_1.Skill) do
    local l_9_7 = l_9_0:AppendItemFromIni("interface\\Moon_DBM\\DBMSetPanel.ini", "Handle_Item", tostring(l_9_5))
    l_9_7:Lookup("Text_CheckTxt"):SetText(l_9_6.szName)
    l_9_7:Lookup("Text_ScreenTip"):SetText(l_9_6.szDesc)
    if l_9_6.bOn then
      l_9_7:Lookup("Image_CheckBox"):SetFrame(6)
    end
    l_9_7.bSkill = true
    l_9_7.nPos = l_9_5
    l_9_7.szName = l_9_6.szName
  end
  BoxUpdateScroll("Handle_SkillList", "DBMSetPanel", true)
end

l_0_1 = DBMSetPanel
l_0_1.UpdateBuff = function()
  local l_10_0 = DBMSetPanel.buffList
  l_10_0:Clear()
  local l_10_1 = DBMSetPanel.GetCurrMod()
  for l_10_5,l_10_6 in ipairs(l_10_1.Buff) do
    local l_10_7 = l_10_0:AppendItemFromIni("interface\\Moon_DBM\\DBMSetPanel.ini", "Handle_Item", tostring(l_10_5))
    l_10_7:Lookup("Text_CheckTxt"):SetText(l_10_6.szName)
    l_10_7:Lookup("Text_ScreenTip"):SetText(l_10_6.szDesc)
    if l_10_6.bOn then
      l_10_7:Lookup("Image_CheckBox"):SetFrame(6)
    end
    l_10_7.bBuff = true
    l_10_7.nPos = l_10_5
    l_10_7.szName = l_10_6.szName
  end
  BoxUpdateScroll("Handle_BuffList", "DBMSetPanel", true)
end

l_0_1 = DBMSetPanel
l_0_1.OnLButtonClick = function()
  local l_11_0 = this:GetName()
  if l_11_0 == "Btn_SkillAdd" then
    OpenDBMSetSkill()
  elseif l_11_0 == "Btn_SkillChange" then
    local l_11_1 = DBMSetPanel.GetSel("skill")
    do
      if not l_11_1 then
        MsgBox("��ѡ��Ҫ�޸ĵ��")
        return 
      end
      OpenDBMSetSkill(l_11_1.szName)
    end
  elseif l_11_0 == "Btn_SkillDel" then
    local l_11_2 = DBMSetPanel.GetSel("skill")
    if not l_11_2 then
      MsgBox("��ѡ��Ҫɾ�����")
      return 
    end
    local l_11_3 = DBMSetPanel.GetCurrMod()
    table.remove(l_11_3.Skill, l_11_2.nPos)
    DBMSetPanel.UpdateSkill()
  elseif l_11_0 == "Btn_BuffAdd" then
    OpenDBMSetBuff()
  elseif l_11_0 == "Btn_BuffChange" then
    local l_11_4 = DBMSetPanel.GetSel()
    if not l_11_4 then
      MsgBox("��ѡ��Ҫ�޸ĵ��")
      return 
    end
    OpenDBMSetBuff(l_11_4.szName)
  elseif l_11_0 == "Btn_BuffDel" then
    local l_11_5 = DBMSetPanel.GetSel()
    if not l_11_5 then
      MsgBox("��ѡ��Ҫɾ�����")
      return 
    end
    local l_11_6 = DBMSetPanel.GetCurrMod()
    table.remove(l_11_6.Buff, l_11_5.nPos)
    DBMSetPanel.UpdateBuff()
  elseif l_11_0 == "Close" then
    CloseDBMSetPanel()
  elseif l_11_0 == "Btn_ComboBoxLife" then
    local l_11_7 = this:Lookup("", "")
    local l_11_8, l_11_9 = l_11_7:GetAbsPos()
    local l_11_10, l_11_11 = l_11_7:GetSize()
    do
      local l_11_12 = {}
      l_11_12.nMiniWidth = l_11_10
      l_11_12.x = l_11_8
      l_11_12.y = l_11_9 + l_11_11
      local l_11_13 = DBMSetPanel.GetCurrMod()
      local l_11_14 = table.insert
      local l_11_15 = l_11_12
      local l_11_16 = {}
      l_11_16.szOption = "����"
      l_11_16.fnAction = function()
        -- upvalues: l_11_7
        local l_12_0 = GetUserInputNumber
        l_12_0(50, 100, nil, function(l_13_0)
          -- upvalues: l_11_7
          local l_13_1 = table.insert
          local l_13_2 = l_11_7.tLife
          local l_13_3 = {}
          l_13_3.num = l_13_0
          l_13_3.tip = ""
          l_13_1(l_13_2, l_13_3)
        end)
      end
      l_11_14(l_11_15, l_11_16)
      l_11_14 = table
      l_11_14 = l_11_14.insert
      l_11_15 = l_11_12
      l_11_14(l_11_15, l_11_16)
      l_11_16 = {bDevide = true}
      l_11_14 = ipairs
      l_11_15 = l_11_13.tLife
      l_11_14 = l_11_14(l_11_15)
      for i_1,i_2 in l_11_14 do
        local l_11_19 = {}
        l_11_19.szOption = tostring(l_11_18.num) .. "%"
        local l_11_20 = table.insert
        local l_11_21 = l_11_19
        local l_11_22 = {}
        l_11_22.szOption = "�޸�"
        l_11_22.fnAction = function()
          -- upvalues: l_11_12 , l_11_7 , l_11_11
          local l_13_0 = GetUserInputNumber
          l_13_0(l_11_12.num, 100, nil, function(l_14_0)
            -- upvalues: l_11_7 , l_11_11
            l_11_7.tLife[l_11_11].num = l_14_0
          end)
        end
        l_11_20(l_11_21, l_11_22)
        l_11_20 = table
        l_11_20 = l_11_20.insert
        l_11_21 = l_11_19
        l_11_20(l_11_21, l_11_22)
        l_11_22 = {szOption = "ɾ��", fnAction = function()
          -- upvalues: l_11_7 , l_11_11
          table.remove(l_11_7.tLife, l_11_11)
        end}
        l_11_20 = table
        l_11_20 = l_11_20.insert
        l_11_21 = l_11_19
        l_11_20(l_11_21, l_11_22)
        l_11_22 = {bDevide = true}
        l_11_20 = l_11_18.tip
        l_11_21 = l_11_18.tip
        if l_11_21 == "" then
          l_11_20 = "��ʾΪ�գ�������ã�"
        end
        l_11_21 = table
        l_11_21 = l_11_21.insert
        l_11_22 = l_11_19
        local l_11_23 = {}
        l_11_23.szOption = l_11_20
        l_11_23.fnAction = function()
          -- upvalues: l_11_7 , l_11_11 , l_11_12
          local l_15_0 = GetUserInput
          l_15_0("��������ʾ����", function(l_16_0)
            -- upvalues: l_11_7 , l_11_11
            if l_16_0 == "" then
              return 
            end
            if not DBMPanel.CheckSpecialChar(l_16_0) then
              MsgBox("���󣬰��������ַ���|����")
              return 
            end
            l_16_0 = StringReplaceW(l_16_0, " ", "")
            l_11_7.tLife[l_11_11].tip = l_16_0
          end, nil, nil, nil, l_11_12.tip)
        end
        l_11_21(l_11_22, l_11_23)
        l_11_21 = table
        l_11_21 = l_11_21.insert
        l_11_22 = l_11_12
        l_11_23 = l_11_19
        l_11_21(l_11_22, l_11_23)
      end
      PopupMenu(l_11_12)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
end

l_0_1 = DBMSetPanel
l_0_1.SetValue = function(l_12_0, l_12_1)
  DBMSetPanel.GetCurrMod()[l_12_0] = l_12_1
end

l_0_1 = DBMSetPanel
l_0_1.OnCheckBoxCheck = function()
  local l_13_0 = this:GetName()
  if l_13_0 == "CheckBox_AttackArea" then
    DBMSetPanel.SetValue("bArea", true)
  elseif l_13_0 == "CheckBox_LifeTip" then
    DBMSetPanel.SetValue("bLife", true)
  elseif l_13_0 == "CheckBox_NpcEnter" then
    DBMSetPanel.SetValue("bEnter", true)
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnCheckBoxUncheck = function()
  local l_14_0 = this:GetName()
  if l_14_0 == "CheckBox_AttackArea" then
    DBMSetPanel.SetValue("bArea", false)
  elseif l_14_0 == "CheckBox_LifeTip" then
    DBMSetPanel.SetValue("bLife", false)
  elseif l_14_0 == "CheckBox_NpcEnter" then
    DBMSetPanel.SetValue("bEnter", false)
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnEditChanged = function()
  local l_15_0 = this:GetName()
  if l_15_0 == "Edit_AttackAngle" then
    DBMSetPanel.SetValue("nAngle", tonumber(this:GetText()))
  elseif l_15_0 == "Edit_AttackRange" then
    DBMSetPanel.SetValue("nRange", tonumber(this:GetText()))
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnItemLButtonClick = function()
  local l_16_0 = this:GetName()
  local l_16_1 = this
  if l_16_0 == "Image_CheckBox" then
    local l_16_2 = l_16_1:GetParent()
    if l_16_1:GetFrame() == 6 then
      l_16_1:SetFrame(5)
      if l_16_2.bSkill then
        DBMSetPanel.ToggleSkillOrBuff("skill", l_16_2.szName, false)
      end
    else
      DBMSetPanel.ToggleSkillOrBuff("buff", l_16_2.szName, false)
    end
  else
    l_16_1:SetFrame(6)
    if l_16_2.bSkill then
      DBMSetPanel.ToggleSkillOrBuff("skill", l_16_2.szName, true)
    end
  else
    DBMSetPanel.ToggleSkillOrBuff("buff", l_16_2.szName, true)
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnItemMouseEnter = function()
  local l_17_0 = this:GetName()
  local l_17_1 = this
  if l_17_1.bSkill or l_17_1.bBuff then
    l_17_1.bIn = true
  end
  if not l_17_1.bSel then
    l_17_1:Lookup("Image_Over"):Show()
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnItemMouseLeave = function()
  local l_18_0 = this:GetName()
  local l_18_1 = this
  if l_18_1.bSkill or l_18_1.bBuff then
    l_18_1.bIn = false
  end
  if not l_18_1.bSel then
    l_18_1:Lookup("Image_Over"):Hide()
  end
end

l_0_1 = DBMSetPanel
l_0_1.OnItemLButtonUp = function()
  local l_19_0 = this:GetName()
  local l_19_1 = this
  if l_19_1.bSkill or l_19_1.bBuff then
    l_19_1.bSel = true
    local l_19_2 = l_19_1:GetParent()
    local l_19_3 = l_19_2:GetItemCount() - 1
    for l_19_7 = 0, l_19_3 do
      local l_19_8 = l_19_2:Lookup(l_19_7)
      if l_19_8 then
        if l_19_8:GetName() == l_19_1:GetName() then
          l_19_1:Lookup("Image_Sel"):Show()
          l_19_1:Lookup("Image_Over"):Hide()
        end
      else
        l_19_8.bSel = false
        l_19_8:Lookup("Image_Sel"):Hide()
      end
    end
  end
end

l_0_1 = function(l_20_0, l_20_1)
  DBMSetPanel.showDungeon = l_20_0
  DBMSetPanel.showMod = l_20_1
  if IsDBMSetPanelOpened() then
    DBMSetPanel.UpdateAll()
    return 
  end
  local l_20_2 = Station.Lookup("Normal/DBMSetPanel")
  l_20_2:Show()
  DBMSetPanel.OnCorrectPos(l_20_2)
  DBMSetPanel.UpdateAll()
end

OpenDBMSetPanel = l_0_1
l_0_1 = function()
  local l_21_0 = Station.Lookup("Normal/DBMSetPanel")
  if l_21_0 and l_21_0:IsVisible() then
    return true
  end
  return false
end

IsDBMSetPanelOpened = l_0_1
l_0_1 = function()
  local l_22_0 = Station.Lookup("Normal/DBMPanel")
  if not IsDBMSetPanelOpened() then
    return 
  end
  l_22_0 = Station.Lookup("Normal/DBMSetPanel")
  l_22_0:Hide()
end

CloseDBMSetPanel = l_0_1
l_0_1 = BoxRegisterScroll
l_0_1("DBMSetPanel")
l_0_1 = BoxUnRegisterScroll
l_0_1("DBMSetPanel")
l_0_1 = "Normal/DBMSetPanel"
local l_0_2 = "Page_Total/Page_Skill"
local l_0_3 = BoxRegisterScrollControl
local l_0_4 = l_0_1
local l_0_5 = l_0_2 .. "/Btn_SkillUp"
local l_0_6 = l_0_2 .. "/Btn_SkillDown"
local l_0_7 = l_0_2 .. "/Scroll_SkillInfo"
local l_0_8 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_3(l_0_4, l_0_5, l_0_6, l_0_7, l_0_8)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3(l_0_4, l_0_5, l_0_6, l_0_7, l_0_8)
l_0_8 = {l_0_2 .. "/" .. "Handle_SkillList", "Handle_BuffList"}
l_0_1 = Wnd
l_0_1 = l_0_1.OpenWindow
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = l_0_1(l_0_2, l_0_3)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = l_0_1:Hide
l_0_1(l_0_2)

