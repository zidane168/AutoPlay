-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: yyLifeBarSettings.lua 

if not yyLifeBarSettings then
  yyLifeBarSettings = {}
end
yyLifeBarSettings.OnLButtonClick = function()
  local szName = this:GetName()
  do
    local nStep = -1
    if IsCtrlKeyDown() then
      nStep = -5
    end
    if szName:match("Right") then
      nStep = nStep * -1
    end
    if szName == "Btn_RangeZone_Left" or szName == "Btn_RangeZone_Right" then
      yyLifeBar.nRange = yyLifeBar.nRange + nStep
      if yyLifeBar.nRange <= 0 then
        yyLifeBar.nRange = 0
      else
        if yyLifeBar.nRangeMax <= yyLifeBar.nRange then
          yyLifeBar.nRange = yyLifeBar.nRangeMax
        end
      elseif szName == "Btn_MemberZone_Left" or szName == "Btn_MemberZone_Right" then
        yyLifeBar.nAllowMember = yyLifeBar.nAllowMember + nStep
        if yyLifeBar.nAllowMember <= 0 then
          yyLifeBar.nAllowMember = 0
        else
          if yyLifeBar.nAllowMemberMax <= yyLifeBar.nAllowMember then
            yyLifeBar.nAllowMember = yyLifeBar.nAllowMemberMax
          end
        elseif szName == "Btn_Close" then
          yyLifeBarSettings.ClosePanel()
          return 
        end
        yyLifeBarSettings.UpdateSettingPanelData()
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

yyLifeBarSettings.OnCheckBoxCheck = function(event)
  yyLifeBarSettings.CheckBoxEvent(this:GetName(), true)
end

yyLifeBarSettings.OnCheckBoxUncheck = function(event)
  yyLifeBarSettings.CheckBoxEvent(this:GetName(), false)
end

yyLifeBarSettings.CheckBoxEvent = function(szName, bFlag)
  if yyLifeBarSettings.bIgnoreCheckboxEvent then
    return 
  end
  if szName == "CheckBox_ShowDoodad" then
    yyLifeBar.bShowDoodad = bFlag
  elseif szName == "CheckBox_ShowNpc" then
    yyLifeBar.bShowNpc = bFlag
  elseif szName == "CheckBox_ShowPlayer" then
    yyLifeBar.bShowPlayer = bFlag
  elseif szName == "CheckBox_ForceColorName" then
    yyLifeBar.bForceColorName = bFlag
  elseif szName == "CheckBox_OnlyParty" then
    yyLifeBar.bOnlyParty = bFlag
  elseif szName == "CheckBox_ShowTitle" then
    yyLifeBar.bShowTitle = bFlag
  elseif szName == "CheckBox_PartyColor" then
    yyLifeBar.bPartyColor = bFlag
  elseif szName == "CheckBox_iForce" then
    yyLifeBar.biForce = bFlag
  elseif szName == "CheckBox_ShowDistance" then
    yyLifeBar.bShowDistance = bFlag
  elseif szName == "CheckBox_ShowSelf" then
    yyLifeBar.bShowSelf = bFlag
    if bFlag then
      yyLifeBar.CreateLifeBar(GetClientPlayer().dwID)
    else
      yyLifeBar.RemoveLifeBar(GetClientPlayer().dwID)
    end
    yyLifeBar.ReplaceTopHeadEx(GetClientPlayer().dwID, false)
  elseif szName == "CheckBox_ReplaceTopHeadEx" then
    yyLifeBar.bReplaceTopHeadEx = bFlag
  elseif szName == "CheckBox_ShowCastingBar" then
    yyLifeBar.bShowCastingBar = bFlag
  elseif szName == "CheckBox_ShowLifeBar" then
    yyLifeBar.bShowLifeBar = bFlag
  elseif szName == "CheckBox_ShowName" then
    yyLifeBar.bShowName = bFlag
  elseif szName == "CheckBox_SelectedBarMode" then
    yyLifeBar.bSelectedBarMode = bFlag
  elseif szName == "CheckBox_AutoSort" then
    yyLifeBar.bAutoSort = bFlag
  elseif szName == "CheckBox_ShowTNpc" then
    yyLifeBar.bShowTNpc = bFlag
  elseif szName == "CheckBox_ShowLevel" then
    yyLifeBar.bShowLevel = bFlag
  elseif szName == "CheckBox_ShowLife" then
    yyLifeBar.bShowLife = bFlag
  end
  yyLifeBarSettings.UpdateSettingPanelData()
end

yyLifeBarSettings.UpdateSettingPanelData = function()
  yyLifeBarSettings.bIgnoreCheckboxEvent = true
  yyLifeBarSettings.handleRangeZone:Lookup("Text_RangeZone_Value"):SetText(yyLifeBar.nRange)
  yyLifeBarSettings.handleMemberZone:Lookup("Text_MemberZone_Value"):SetText(yyLifeBar.nAllowMember)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowDoodad"):Check(yyLifeBar.bShowDoodad)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowNpc"):Check(yyLifeBar.bShowNpc)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowPlayer"):Check(yyLifeBar.bShowPlayer)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ForceColorName"):Check(yyLifeBar.bForceColorName)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_OnlyParty"):Check(yyLifeBar.bOnlyParty)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowTitle"):Check(yyLifeBar.bShowTitle)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_PartyColor"):Check(yyLifeBar.bPartyColor)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_iForce"):Check(yyLifeBar.biForce)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowDistance"):Check(yyLifeBar.bShowDistance)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowSelf"):Check(yyLifeBar.bShowSelf)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ReplaceTopHeadEx"):Check(yyLifeBar.bReplaceTopHeadEx)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowCastingBar"):Check(yyLifeBar.bShowCastingBar)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowLifeBar"):Check(yyLifeBar.bShowLifeBar)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowName"):Check(yyLifeBar.bShowName)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_SelectedBarMode"):Check(yyLifeBar.bSelectedBarMode)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_AutoSort"):Check(yyLifeBar.bAutoSort)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowLife"):Check(yyLifeBar.bShowLife)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowLevel"):Check(yyLifeBar.bShowLevel)
  yyLifeBarSettings.frameSelf:Lookup("CheckBox_ShowTNpc"):Check(yyLifeBar.bShowTNpc)
  yyLifeBarSettings.bIgnoreCheckboxEvent = false
end

yyLifeBarSettings.OpenPanel = function()
  local frame = Station.Lookup("Normal/yyLifeBarSettings")
  if not frame then
    frame = Wnd.OpenWindow("Interface\\yyLifeBar\\yyLifeBarSettings.ini", "yyLifeBarSettings")
  end
  frame:Show()
  yyLifeBarSettings.frameSelf = frame
  yyLifeBarSettings.handleMain = frame:Lookup("", "")
  yyLifeBarSettings.handleRangeZone = frame:Lookup("", "Handle_RangeZone")
  yyLifeBarSettings.handleMemberZone = frame:Lookup("", "Handle_MemberZone")
  frame:SetPoint("CENTER", 100, 0, "CENTER", 150, 0)
  yyLifeBarSettings.UpdateSettingPanelData()
end

yyLifeBarSettings.ClosePanel = function()
  local frame = Station.Lookup("Normal/yyLifeBarSettings")
  if not frame then
    return 
  end
  frame:Hide()
end

yyLifeBarSettings.IsOpend = function()
  local frame = Station.Lookup("Normal/yyLifeBarSettings")
  if frame and frame:IsVisible() then
    return true
  end
  return false
end

local menu = {}
table.insert(menu, {bDevide = true})
table.insert(menu, {
{szOption = "[���������]", bChecked = false, bCheck = true, fnAutoClose = function()
  return true
end
, fnAction = function()
  if yyLifeBarSettings.IsOpend() then
    yyLifeBarSettings.ClosePanel()
  else
    yyLifeBarSettings.OpenPanel()
  end
end
}, 
{bDevide = true}, 
{szOption = "�ж�Ŀ��ͷ����ǿ", bCheck = true, bChecked = yyLifeBar.bShowEnemy, fnAction = function()
  yyLifeBar.bShowEnemy = not yyLifeBar.bShowEnemy
end
, fnAutoClose = function()
  return true
end
, 
rgb = {255, 32, 32}}, 
{szOption = "�Ѻ�Ŀ��ͷ����ǿ", bCheck = true, bChecked = yyLifeBar.bShowAlly, fnAction = function()
  yyLifeBar.bShowAlly = not yyLifeBar.bShowAlly
end
, fnAutoClose = function()
  return true
end
, 
rgb = {32, 255, 32}}, 
{
{szOption = "��סCtrl�Ž���", bCheck = true, bChecked = function()
  return DoodadEx.bNeedCtrlKey
end
, fnAction = function()
  DoodadEx.bNeedCtrlKey = not DoodadEx.bNeedCtrlKey
end
, fnAutoClose = function()
  return true
end
}, 
{szOption = "��סAlt�Ž���", bCheck = true, bChecked = function()
  return DoodadEx.bNeedAltKey
end
, fnAction = function()
  DoodadEx.bNeedAltKey = not DoodadEx.bNeedAltKey
end
, fnAutoClose = function()
  return true
end
}, 
{szOption = "��סShift�Ž���", bCheck = true, bChecked = function()
  return DoodadEx.bNeedShiftKey
end
, fnAction = function()
  DoodadEx.bNeedShiftKey = not DoodadEx.bNeedShiftKey
end
, fnAutoClose = function()
  return true
end
}, 
{bDevide = true}, 
{szOption = "ս���в�����", bCheck = true, bChecked = function()
  return DoodadEx.bDoNotWhenFight
end
, fnAction = function()
  DoodadEx.bDoNotWhenFight = not DoodadEx.bDoNotWhenFight
end
, fnAutoClose = function()
  return true
end
}; szOption = "Doodad�Զ�����", bCheck = true, bChecked = function()
  return DoodadEx.bOn
end
, 
rgb = {128, 0, 255}, fnAction = function()
  DoodadEx.bOn = not DoodadEx.bOn
end
, fnAutoClose = function()
  return true
end
}, 
{bDevide = true}, 
{szOption = "�����Զ��Ի�", bCheck = true, bChecked = function()
  return AutoChat.On
end
, fnAction = function()
  AutoChat.BTNOPEN()
end
, fnAutoClose = function()
  return true
end
, 
rgb = {255, 254, 38}}, 
{bDevide = true}, 
{szOption = "ȥ�Ի���ť", bCheck = true, bChecked = function()
  return AutoChat.SellBTNOn
end
, fnAction = function()
  AutoChat.SellBTN()
end
, fnAutoClose = function()
  return true
end
}; szOption = "�� ͷ����ǿ��", szIcon = "UI/Image/Minimap/Minimap2.UITex", nFrame = 24, szLayer = "ICON_LEFT"})
Player_AppendAddonMenu(menu)
yyLifeBarSettings.GetReFreshTimeText = function()
  local nTotal = 21600 - GetLogicFrameCount() / 16 % 21600
  local nHours = math.floor(nTotal / 3600)
  local nMinutes = math.floor(nTotal / 60 % 60)
  local nSeconds = math.floor(nTotal % 60)
  return string.format("ϡ����Ʒ����ʱ:%d:%d:%d", nHours, nMinutes, nSeconds)
end

yyLifeBarSettings.OnFrameCreate = function()
  local frame = Station.Lookup("Normal/yyLifeBarSettings")
end

yyLifeBarSettings.OnFrameBreathe = function()
  local frame = Station.Lookup("Normal/yyLifeBarSettings")
  frame:Lookup("", "Text_Title"):SetText("ͷ����ǿ��by[������]���Ƿɽ�")
  local txt = frame:Lookup("", "Text_Time")
  txt:SetText(yyLifeBarSettings.GetReFreshTimeText())
  txt:SetFontColor(243, 160, 7)
end

yyLifeBarSettings.GetMenu = function()
  local menu = {szOption = "�� ͷ����ǿ��"}
  local menu_a1 = {szOption = "�ж�Ŀ��Ѫ��ģʽ", bCheck = true, bChecked = yyLifeBar.bShowEnemy, fnAction = function()
    yyLifeBar.bShowEnemy = not yyLifeBar.bShowEnemy
  end, fnAutoClose = function()
    return true
  end}
  local menu_a2 = {szOption = "�Ѿ�Ŀ��Ѫ��ģʽ", bCheck = true, bChecked = yyLifeBar.bShowAlly, fnAction = function()
    yyLifeBar.bShowAlly = not yyLifeBar.bShowAlly
  end, fnAutoClose = function()
    return true
  end}
  local menu_c = {szOption = "��/�ر��������", fnAction = function()
    if yyLifeBarSettings.IsOpend() then
      yyLifeBarSettings.ClosePanel()
    else
      yyLifeBarSettings.OpenPanel()
    end
  end}
  table.insert(menu, menu_c)
  table.insert(menu, menu_a1)
  table.insert(menu, menu_a2)
  return menu
end

TraceButton_AppendAddonMenu({function()
  return {yyLifeBarSettings.GetMenu()}
end
})
yyLifeBarSettings.Message = function(szMessage)
  OutputMessage("MSG_SYS", tostring(szMessage) .. "\n")
end

Hotkey.AddBinding("yyLifeBar_Settings", "��/�ر��������", "�� ͷ����ǿ��", function()
  if yyLifeBarSettings.IsOpend() then
    yyLifeBarSettings.ClosePanel()
  else
    yyLifeBarSettings.OpenPanel()
  end
end
, nil)
Hotkey.AddBinding("yyLifeBar_ShowEnemy", "��ʾ����Ѫ��", "", function()
  yyLifeBar.bShowEnemy = not yyLifeBar.bShowEnemy
  yyLifeBarSettings.Message("���ж�Ŀ��ͷ����ǿ��: " .. tostring(yyLifeBar.bShowEnemy))
end
, nil)
Hotkey.AddBinding("yyLifeBar_ShowAlly", "��ʾ�Ѿ�Ѫ��", "", function()
  yyLifeBar.bShowAlly = not yyLifeBar.bShowAlly
  yyLifeBarSettings.Message("���Ѿ�ͷ����ǿ��: " .. tostring(yyLifeBar.bShowAlly))
end
, nil)

