-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: QuestsStrength.lua 

QuestStength = {}
QuestStength.bLootItem = false
RegisterCustomData("QuestStength.bLootItem")
QuestStength.bMatchQuestDoodad = true
RegisterCustomData("QuestStength.bMatchQuestDoodad")
QuestStength.tQuestDoodad = {}
RegisterMoonButton("QuestStength", 244, "������ǿ", "General", function(l_1_0)
  BoxBoolCheckBox(l_1_0, "CheckBox_LootItem", "�Զ��ɼ�������Ʒ", QuestStength, "bLootItem")
  BoxBoolCheckBox(l_1_0, "CheckBox_LootItem", "����ƥ��������Ʒ", QuestStength, "bMatchQuestDoodad"):SetRelPos(30, 30)
end
)
local l_0_0 = function(l_2_0)
  local l_2_1 = GetDoodad(l_2_0)
  local l_2_2 = GetClientPlayer()
  if not l_2_2 or not l_2_1 then
    return false
  end
  if math.floor(l_2_2.nX - l_2_1.nX ^ 2 + l_2_2.nY - l_2_1.nY ^ 2 ^ 0.5) > 249 then
    return false
  end
  return true
end

local l_0_1 = function()
  QuestStength.tQuestDoodad = {}
  local l_3_0 = GetClientPlayer()
  local l_3_1 = l_3_0.GetQuestTree()
  for l_3_5,l_3_6 in pairs(l_3_1) do
    do break end
    do
      local l_3_7, l_3_8, l_3_9, l_3_10, l_3_11 = pairs(l_3_6)
      local l_3_12 = l_3_0.GetQuestID(l_3_11)
      local l_3_13 = Table_GetQuestStringInfo(l_3_12)
      local l_3_14 = l_3_0.GetQuestTraceInfo(l_3_12)
      for l_3_18,l_3_19 in pairs(l_3_14.need_item) do
        local l_3_20 = GetItemInfo(l_3_19.type, l_3_19.index)
        if l_3_20 then
          local l_3_21 = GetItemNameByItemInfo(l_3_20, l_3_19.need)
          QuestStength.tQuestDoodad[l_3_21] = true
        end
      end
      local l_3_22 = l_3_13.szDescription
      for l_3_26,l_3_27 in string.gfind(l_3_22, "<F17(%d)%s*(.-)>") do
        if tonumber(l_3_26) == 1 and not QuestStength.tQuestDoodad[l_3_27] then
          QuestStength.tQuestDoodad[l_3_27] = true
        end
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

local l_0_2 = function(l_4_0)
  if not QuestStength.bMatchQuestDoodad then
    return false
  end
  if (l_4_0.nKind == DOODAD_KIND.QUEST or l_4_0.nKind == DOODAD_KIND.TREASURE) and QuestStength.tQuestDoodad[l_4_0.szName] then
    return true
  end
  return false
end

local l_0_3 = function()
  local l_5_0 = Station.Lookup("Normal/DialoguePanel")
  if l_5_0 and l_5_0:IsVisible() then
    return true
  end
end

RegisterEvent("QUEST_ACCEPTED", l_0_1)
RegisterEvent("QUEST_CANCELED", l_0_1)
RegisterEvent("QUEST_FINISHED", l_0_1)
RegisterEvent("SYNC_ROLE_DATA_END", l_0_1)
RegisterEvent("Breathe", function()
  -- upvalues: l_0_3 , l_0_2 , l_0_0
  if not QuestStength.bLootItem then
    return 
  end
  if GetLogicFrameCount() % 8 ~= 0 then
    return 
  end
  local l_6_0 = GetClientPlayer()
  if not l_6_0 or l_0_3() then
    return 
  end
  local l_6_1 = false
  if l_6_0.nMoveState == MOVE_STATE.ON_STAND or l_6_0.nMoveState == MOVE_STATE.ON_FLOAT then
    l_6_1 = true
  end
  if not l_6_1 then
    return 
  end
  if l_6_0.bFightState then
    return 
  end
  if l_6_0.GetOTActionState() ~= 0 then
    return 
  end
  local l_6_2 = GetNearbyDoodadList()
  if l_6_2 then
    for l_6_6 = 1, table.getn(l_6_2) do
      local l_6_7 = l_6_2[l_6_6]
      local l_6_8 = GetDoodad(l_6_7)
      if l_6_8 and (l_6_8.nKind == DOODAD_KIND.QUEST or l_0_2(l_6_8)) and l_0_0(l_6_7) then
        InteractDoodad(l_6_7)
        return 
      end
    end
  end
end
)

