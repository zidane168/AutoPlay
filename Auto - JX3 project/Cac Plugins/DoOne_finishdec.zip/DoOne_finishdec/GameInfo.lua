-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: GameInfo.lua 

local l_0_0 = {}
l_0_0.bDurable = false
l_0_0.bXYZ = false
l_0_0.bTime = true
l_0_0.bDistance = true
l_0_0.bFps = true
l_0_0.bDelay = true
GameInfo = l_0_0
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bDurable")
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bXYZ")
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bTime")
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bDistance")
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bFps")
l_0_0 = RegisterCustomData
l_0_0("GameInfo.bDelay")
local l_0_1 = {}
l_0_1.y = -70
l_0_1.x = 2
l_0_1.s = "BOTTOMRIGHT"
l_0_1.r = "BOTTOMRIGHT"
l_0_1 = {y = -100, x = 2, s = "BOTTOMRIGHT", r = "BOTTOMRIGHT"}
l_0_1 = {y = -130, x = 2, s = "BOTTOMRIGHT", r = "BOTTOMRIGHT"}
l_0_1 = {y = -130, x = -140, s = "BOTTOMRIGHT", r = "BOTTOMRIGHT"}
l_0_1 = {y = -100, x = -140, s = "BOTTOMRIGHT", r = "BOTTOMRIGHT"}
l_0_1 = {y = -70, x = -140, s = "BOTTOMRIGHT", r = "BOTTOMRIGHT"}
GameInfo.Pos = {}
RegisterCustomData("GameInfo.Pos")
GameInfo.Create = function(l_1_0)
  local l_1_1 = l_1_0:Lookup("", "")
  BoxLabel(l_1_1, "label1", "��Ϣ����������", nil, 27)
  local l_1_2 = function(l_2_0, l_2_1, l_2_2)
    l_2_0:SetBoolValue(GameInfo, l_2_1)
    l_2_0:OnCheck(function()
      -- upvalues: l_1_2
      GameInfo.ShowBar(l_1_2)
    end)
    l_2_0:UnCheck(function()
      -- upvalues: l_1_2
      GameInfo.HideBar(l_1_2)
    end)
  end
  local l_1_3 = l_1_2
  local l_1_4 = BoxCheckBox
  local l_1_5 = l_1_0
  local l_1_6 = "CheckBox_Time"
  local l_1_7 = {}
  l_1_7.txt = "ϵͳʱ��"
  l_1_7.x = 0
  l_1_7.y = 30
  l_1_4 = l_1_4(l_1_5, l_1_6, l_1_7)
  l_1_5 = "bTime"
  l_1_6 = "Time"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3 = l_1_2
  l_1_4 = BoxCheckBox
  l_1_5 = l_1_0
  l_1_6 = "CheckBox_Distance"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "Ŀ�����", x = 150, y = 30}
  l_1_5 = "bDistance"
  l_1_6 = "Distance"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3 = l_1_2
  l_1_4 = BoxCheckBox
  l_1_5 = l_1_0
  l_1_6 = "CheckBox_XYZ"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "��������", x = 300, y = 30}
  l_1_5 = "bXYZ"
  l_1_6 = "XYZ"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3 = l_1_2
  l_1_4 = BoxCheckBox
  l_1_5 = l_1_0
  l_1_6 = "CheckBox_Fps"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "��ϷFPS", x = 0, y = 60}
  l_1_5 = "bFps"
  l_1_6 = "NFPS"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3 = l_1_2
  l_1_4 = BoxCheckBox
  l_1_5 = l_1_0
  l_1_6 = "CheckBox_Delay"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "��Ϸ�ӳ�", x = 150, y = 60}
  l_1_5 = "bDelay"
  l_1_6 = "Delay"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3 = l_1_2
  l_1_4 = BoxCheckBox
  l_1_5 = l_1_0
  l_1_6 = "CheckBox_Durable"
  l_1_4, l_1_7 = l_1_4(l_1_5, l_1_6, l_1_7), {txt = "װ���;�", x = 300, y = 60}
  l_1_5 = "bDurable"
  l_1_6 = "Durable"
  l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_3, l_1_4 = l_1_1:FormatAllItemPos, l_1_1
  l_1_3(l_1_4)
end

RegisterMoonButton("GameInfo", 380, "��Ϣ��", "General", GameInfo.Create)
GameInfo.UpdateAllPos = function()
  -- upvalues: l_0_1 , l_0_0
  for l_2_3,l_2_4 in ipairs(l_0_1) do
    local l_2_5 = Station.Lookup("Normal/" .. l_2_4)
    if l_2_5 then
      if not GameInfo.Pos[l_2_4] then
        local l_2_6, l_2_7, l_2_8, l_2_9 = l_0_0[l_2_4]
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_2_5:SetPoint(l_2_6.s, 0, 0, l_2_6.r, l_2_6.x, l_2_6.y)
    end
  end
end

GameInfo.Init = function()
  GameInfo.UpdateAllPos()
  local l_3_0 = {}
  local l_3_1 = {}
  l_3_1.name = "bTime"
  l_3_1.t = GameInfo
  l_3_1.frame = "Time"
  local l_3_2 = {}
  l_3_2.name = "bDistance"
  l_3_2.t = GameInfo
  l_3_2.frame = "Distance"
  local l_3_3 = {}
  l_3_3.name = "bFps"
  l_3_3.t = GameInfo
  l_3_3.frame = "NFPS"
  local l_3_4 = {}
  l_3_4.name = "bDelay"
  l_3_4.t = GameInfo
  l_3_4.frame = "Delay"
  local l_3_5 = {}
  l_3_5.name = "bXYZ"
  l_3_5.t = GameInfo
  l_3_5.frame = "XYZ"
  do
    local l_3_6 = {}
    l_3_6.name = "bDurable"
    l_3_6.t = GameInfo
    l_3_6.frame = "Durable"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_3_1 = ipairs
    l_3_2 = l_3_0
    l_3_1 = l_3_1(l_3_2)
    for l_3_4,l_3_5 in l_3_1 do
      l_3_6 = l_3_5.t
      l_3_6 = l_3_6[l_3_5.name]
      if l_3_6 then
        l_3_6 = GameInfo
        l_3_6 = l_3_6.ShowBar
        l_3_6(l_3_5.frame)
      else
        l_3_6 = GameInfo
        l_3_6 = l_3_6.HideBar
        l_3_6(l_3_5.frame)
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

RegisterEvent("AddonLoad", GameInfo.Init)
GameInfoLabel_Base = class()
GameInfoLabel_Base.OnFrameDragEnd = function()
  local l_4_0 = this:GetName()
  this:CorrectPos()
  GameInfo.Pos[l_4_0] = GetFrameAnchor(this)
end

CreateGameInfoBar = function(l_5_0)
  local l_5_1 = Wnd.OpenWindow("interface\\Moon_GameInfo\\GameInfoLabel.ini", l_5_0)
  l_5_1:Show()
  return l_5_1
end

GameInfo.SetBarText = function(l_6_0, l_6_1)
  local l_6_2 = Station.Lookup("Normal/" .. l_6_0)
  l_6_2:Lookup("", "Label_Text"):SetText(l_6_1)
end

GameInfo.ShowBar = function(l_7_0)
  local l_7_1 = Station.Lookup("Normal/" .. l_7_0)
  if l_7_1 then
    l_7_1:Show()
  end
end

GameInfo.HideBar = function(l_8_0)
  local l_8_1 = Station.Lookup("Normal/" .. l_8_0)
  if l_8_1 then
    l_8_1:Hide()
  end
end

CreateGameInfoBar("Durable")
GetDurability = function()
  local l_9_0 = GetClientPlayer()
  if not l_9_0 then
    return 
  end
  local l_9_1 = 0
  local l_9_2 = 0
  local l_9_3 = {}
  local l_9_4 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_5 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_6 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_7 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_8 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_9 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_9_10 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  do
    local l_9_11 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_9_8,l_9_9 in l_9_5 do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

    if l_9_10 and l_9_11 < l_9_10.nMaxDurability then
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_9_5 then
        item = l_9_0.GetItem(l_9_6.EQUIP, EQUIPMENT_INVENTORY.BIG_SWORD)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if item and item.nCurrentDurability < item.nMaxDurability then
        return math.floor((l_9_1) / (l_9_2) * 100), l_9_4
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 81 121 
end

Durable.OnFrameBreathe = function()
  local l_10_0 = GetDurability()
  if l_10_0 then
    GameInfo.SetBarText("Durable", "�;ã�" .. l_10_0 .. "%")
  end
end

Durable.OnMouseEnter = function()
  local l_11_0, l_11_1 = GetDurability()
  local l_11_2, l_11_3 = this:GetAbsPos()
  local l_11_4, l_11_5 = this:GetSize()
  if l_11_1 == "" then
    local l_11_6 = OutputTip
    local l_11_7 = GetFormatText("װ�������")
    local l_11_8 = 300
    local l_11_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_11_6(l_11_7, l_11_8, l_11_9)
  else
    local l_11_10 = OutputTip
    local l_11_11 = l_11_1
    local l_11_12 = 300
    local l_11_13 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_11_10(l_11_11, l_11_12, l_11_13)
  end
   -- WARNING: undefined locals caused missing assignments!
end

Durable.OnMouseLeave = function()
  HideTip()
end

CreateGameInfoBar("Time")
Moon_GetLocalTimeText = function()
  local l_13_0 = GetCurrentTime()
  local l_13_1 = TimeToDate(l_13_0)
  local l_13_2 = string.format
  local l_13_3 = "%d:%d:%d"
  local l_13_4 = l_13_1.hour
  local l_13_5 = l_13_1.minute
  local l_13_6 = l_13_1.second
  return l_13_2(l_13_3, l_13_4, l_13_5, l_13_6)
end

Time.OnFrameBreathe = function()
  GameInfo.SetBarText("Time", Moon_GetLocalTimeText())
end

CreateGameInfoBar("Distance")
GetDistance = function(l_15_0)
  if not l_15_0 then
    return false
  end
  local l_15_1 = GetClientPlayer()
  if not l_15_1 then
    return false
  end
  local l_15_2 = math.floor(l_15_1.nX - l_15_0.nX ^ 2 + l_15_1.nY - l_15_0.nY ^ 2 + l_15_1.nZ / 8 - l_15_0.nZ / 8 ^ 2 ^ 0.5)
  local l_15_3, l_15_4 = "%.2f":format, "%.2f"
  local l_15_5 = l_15_2 / 64
  return l_15_3(l_15_4, l_15_5)
end

Distance.OnFrameBreathe = function()
  local l_16_0 = GetClientPlayer()
  if not l_16_0 then
    return 
  end
  local l_16_1, l_16_2 = l_16_0.GetTarget()
  local l_16_3 = GetTargetHandle(l_16_1, l_16_2)
  if not l_16_2 or l_16_2 == l_16_0.dwID or not l_16_3 then
    GameInfo.SetBarText("Distance", "��Ŀ��")
  else
    local l_16_4 = GetDistance(l_16_3)
    if l_16_4 then
      GameInfo.SetBarText("Distance", "���룺" .. l_16_4 .. "��")
    end
  else
    GameInfo.SetBarText("Distance", "��Ŀ��")
  end
end

CreateGameInfoBar("Delay")
local l_0_2 = 0
Delay.OnFrameBreathe = function()
  -- upvalues: l_0_2
  local l_17_0 = GetPingValue()
  l_0_2 = l_0_2 * 0.95 + l_17_0 * 0.05
  nPingTime = math.floor(l_0_2 / 2)
  GameInfo.SetBarText("Delay", "�ӳ٣�" .. nPingTime .. "ms")
end

CreateGameInfoBar("NFPS")
NFPS.OnFrameBreathe = function()
  GameInfo.SetBarText("NFPS", "FPS��" .. GetFPS())
end

CreateGameInfoBar("XYZ")
XYZ.OnFrameBreathe = function()
  local l_19_0 = GetClientPlayer()
  if not l_19_0 then
    return 
  end
  GameInfo.SetBarText("XYZ", "x:" .. tonumber("%.1f":format(l_19_0.nX / 1000)) .. " " .. "y:" .. tonumber("%.1f":format(l_19_0.nY / 1000)))
end

RegisterEvent("UI_SCALED", GameInfo.UpdateAllPos)
RegisterEvent("CUSTOM_UI_MODE_SET_DEFAULT", function()
  -- upvalues: l_0_0
  GameInfo.Pos = clone(l_0_0)
  GameInfo.UpdateAllPos()
end
)

