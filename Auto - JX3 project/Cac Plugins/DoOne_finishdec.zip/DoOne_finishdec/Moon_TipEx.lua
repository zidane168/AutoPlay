-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon_TipEx.lua 

local l_0_0 = {}
l_0_0.bMouseFollow = false
l_0_0.bShowItemStack = true
Moon_TipEx = l_0_0
l_0_0 = RegisterCustomData
l_0_0("Moon_TipEx.bMouseFollow")
l_0_0 = RegisterCustomData
l_0_0("Moon_TipEx.bShowItemStack")
l_0_0 = Moon_TipEx
l_0_0.OnCreate = function(l_1_0)
  BoxBoolCheckBox(l_1_0, "CheckBox_bMouseFollow", "�����NPC�����ʾ����", Moon_TipEx, "bMouseFollow")
  BoxBoolCheckBox(l_1_0, "CheckBox_bShowItemStack", "������Ʒ��ʾ�Ķѵ�����", Moon_TipEx, "bShowItemStack"):SetRelPos(0, 30)
end

l_0_0 = RegisterMoonButton
l_0_0("TipEx", 1503, "��ʾ��ǿ", "General", Moon_TipEx.OnCreate)
l_0_0 = false
RegisterEvent("Breathe", function()
  -- upvalues: l_0_0
  if not Moon_TipEx.bMouseFollow then
    return 
  end
  local l_2_0 = Scene_SelectObject("nearest")
  if not l_2_0 then
    return 
  end
  local l_2_1 = l_2_0[1].Type
  local l_2_2 = l_2_0[1].ID
  if l_2_1 == TARGET.PLAYER or l_2_1 == TARGET.NPC then
    local l_2_3 = Station.Lookup("Topmost1/TipPanel_Normal")
    if l_2_3 then
      local l_2_4, l_2_5 = Cursor.GetPos()
      l_0_0 = true
      l_2_3:CorrectPos(l_2_4, l_2_5, 20, 20, ALW.CENTER)
    end
  else
    if l_2_1 == TARGET.NO_TARGET and l_0_0 then
      l_0_0 = false
      HideTip()
    end
  end
end
)
RegisterLinkTipFunc(function(l_3_0)
  if not Moon_TipEx.bShowItemStack or not l_3_0.bItem then
    return 
  end
  local l_3_1 = GetItem(l_3_0.dwItemID)
  do
    local l_3_2 = ""
    if l_3_1 and l_3_1.bCanStack and l_3_1.nMaxStackNum > 1 then
      local l_3_3 = table.hasVal
      do
        local l_3_4 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Overwrote pending register.

      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_3_3 or l_3_2 ~= "" then
      local l_3_5 = l_3_3:Lookup("", "Handle_Message")
      l_3_5:AppendItemFromString(l_3_2)
      l_3_5:FormatAllItemPos()
    end
    return true
  end
   -- WARNING: undefined locals caused missing assignments!
end
)

