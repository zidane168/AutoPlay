-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: CombatDnd.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.bhello = false
l_0_1.btong = true
l_0_1.bteam = true
l_0_1.braid = true
l_0_1.sztong = "cy��ӭ������bh~!"
l_0_1.szteam = "dy��ӭ������dz�Ķ���~!"
l_0_1.szraid = "dy��ӭ������dz���Ŷ�~!"
l_0_1.nChannel = PLAYER_TALK_CHANNEL.TONG
l_0_1.bkill = false
l_0_1.bkillplayer = true
l_0_1.bkillnpc = false
l_0_1.szkillNpc = "zj �ɹ���ɱ�� mb"
l_0_1.szkillPlayer = "zj �ɹ���ɱ�� mb"
l_0_1.bdnd = false
l_0_1.bboss = true
l_0_0.SaveSet = l_0_1
l_0_0.bBeKill = false
l_0_1 = PLAYER_TALK_CHANNEL
l_0_1 = l_0_1.TONG
l_0_0.nBeKillChannel = l_0_1
l_0_0.szBeKill = "���� $map �� $killer ���̵�ɱ����"
l_0_0.bReviveTalk = false
CombatDnd = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "CombatDnd.nBeKillChannel"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatDnd.bBeKill"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatDnd.bReviveTalk"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatDnd.SaveSet"
l_0_0(l_0_1)
l_0_0 = CombatDnd
l_0_0.DndPlayer, l_0_1 = l_0_1, {}
l_0_1 = PLAYER_TALK_CHANNEL
l_0_1 = l_0_1.TEAM
local l_0_2 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_2 = {g_tStrings.tChannelName.MSG_PARTY.tChannelName.MSG_TEAM, "MSG_PARTY"}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_2 = {g_tStrings.tChannelName.MSG_GUILD, "MSG_GUILD"}
local l_0_3 = {}
l_0_3.szName = g_tStrings.tChannelName.MSG_TEAM
l_0_3.nChannel = PLAYER_TALK_CHANNEL.RAID
l_0_3.szColor = "MSG_TEAM"
local l_0_4 = {}
l_0_4.szName = g_tStrings.tChannelName.MSG_GUILD
l_0_4.nChannel = PLAYER_TALK_CHANNEL.TONG
l_0_4.szColor = "MSG_GUILD"
l_0_2 = {szName = g_tStrings.tChannelName.MSG_PARTY, nChannel = PLAYER_TALK_CHANNEL.TEAM, szColor = "MSG_PARTY"}
l_0_2 = CombatDnd
l_0_3 = function(l_1_0)
  -- upvalues: l_0_1 , l_0_0
  BoxBoolCheckBox(l_1_0, "CheckBox_AutoHello", "�Զ����к�", CombatDnd.SaveSet, "bhello")
  local l_1_1 = BoxComboBox
  local l_1_2 = l_1_0
  local l_1_3 = "ComboBox_SetHello"
  local l_1_4 = {}
  l_1_4.x = 0
  l_1_4.y = 30
  l_1_4.txt = "���к�����"
  l_1_1 = l_1_1(l_1_2, l_1_3, l_1_4)
  l_1_1, l_1_2 = l_1_1:SetMenu, l_1_1
  l_1_3 = CombatDnd
  l_1_3 = l_1_3.AddHelloMenu
  l_1_1(l_1_2, l_1_3)
  l_1_1 = BoxBoolCheckBox
  l_1_2 = l_1_0
  l_1_3 = "CheckBox_KillPlayer"
  l_1_4 = "��ɱ����"
  l_1_1 = l_1_1(l_1_2, l_1_3, l_1_4, CombatDnd.SaveSet, "bkill")
  l_1_1, l_1_2 = l_1_1:SetRelPos, l_1_1
  l_1_3 = 0
  l_1_4 = 60
  l_1_1(l_1_2, l_1_3, l_1_4)
  l_1_1 = BoxComboBox
  l_1_2 = l_1_0
  l_1_3 = "DropList_SetKillPlayer"
  l_1_1, l_1_4 = l_1_1(l_1_2, l_1_3, l_1_4), {x = 0, y = 90, txt = "��ɱ��������"}
  l_1_1, l_1_2 = l_1_1:SetMenu, l_1_1
  l_1_3 = function(l_2_0)
    -- upvalues: l_0_1
    local l_2_1 = {}
    l_2_1.szOption = "��һ�ɱ����"
    l_2_1.bCheck = true
    l_2_1.bChecked = CombatDnd.SaveSet.bkillplayer
    l_2_1.fnAction = function()
      CombatDnd.SaveSet.bkillplayer = not CombatDnd.SaveSet.bkillplayer
    end
    table.insert(l_2_0, l_2_1)
    local l_2_2 = {}
    l_2_2.szOption = "NPC��ɱ����"
    l_2_2.bCheck = true
    l_2_2.bChecked = CombatDnd.SaveSet.bkillnpc
    l_2_2.fnAction = function()
      CombatDnd.SaveSet.bkillnpc = not CombatDnd.SaveSet.bkillnpc
    end
    table.insert(l_2_0, l_2_2)
    local l_2_3 = table.insert
    local l_2_4 = l_2_0
    local l_2_5 = {}
    l_2_5.bDevide = true
    l_2_3(l_2_4, l_2_5)
    l_2_4 = ipairs
    l_2_5 = l_0_1
    l_2_4 = l_2_4(l_2_5)
    for i_1,i_2 in l_2_4 do
      do
        local l_2_9 = table.insert
        local l_2_10 = l_2_3
        local l_2_11 = {}
        l_2_11.szOption = l_2_8.szName
        l_2_11.bMCheck = true
        l_2_11.bChecked = CombatDnd.SaveSet.nChannel == l_2_8.nChannel
        l_2_11.rgb = GetMsgFontColor(l_2_8.szColor, true)
        l_2_11.fnAction = function()
          -- upvalues: l_1_8
          CombatDnd.SaveSet.nChannel = l_1_8.nChannel
        end
        l_2_9(l_2_10, l_2_11)
      end
    end
    table.insert(l_2_0, l_2_3)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
  l_1_1(l_1_2, l_1_3)
  l_1_1 = BoxBoolCheckBox
  l_1_2 = l_1_0
  l_1_3 = "CheckBox_BeKill"
  l_1_4 = "����ɱ����"
  l_1_1 = l_1_1(l_1_2, l_1_3, l_1_4, CombatDnd, "bBeKill")
  l_1_1, l_1_2 = l_1_1:SetRelPos, l_1_1
  l_1_3 = 0
  l_1_4 = 120
  l_1_1(l_1_2, l_1_3, l_1_4)
  l_1_1 = BoxComboBox
  l_1_2 = l_1_0
  l_1_3 = "ComboBox_BeKill"
  l_1_1, l_1_4 = l_1_1(l_1_2, l_1_3, l_1_4), {x = 120, y = 120, txt = l_0_0[CombatDnd.nBeKillChannel][1]}
  l_1_2, l_1_3 = l_1_1:ui, l_1_1
  l_1_2 = l_1_2(l_1_3)
  l_1_2, l_1_3 = l_1_2:Lookup, l_1_2
  l_1_4 = ""
  l_1_2 = l_1_2(l_1_3, l_1_4, "Text_ComboBox")
  l_1_2, l_1_3 = l_1_2:SetFontColor, l_1_2
  l_1_4 = GetMsgFontColor
  l_1_2(l_1_3, l_1_4)
  l_1_2, l_1_3 = l_1_1:SetMenu, l_1_1
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_2(l_1_3, l_1_4)
  l_1_2 = BoxCheckBox
  l_1_3 = l_1_0
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_1_5 = {}
  l_1_5.txt = "ս�����Զ��ظ�"
  l_1_5.x = 0
  l_1_5.y = 150
  l_1_2 = l_1_2(l_1_3, l_1_4, l_1_5)
  l_1_3 = BoxBoolCheckBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_5 = "CheckBox_FightBoss"
  l_1_3 = l_1_3(l_1_4, l_1_5, "��Ŀ��Ϊ��Ӣ�֡�Boss�����", CombatDnd.SaveSet, "bboss")
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3 = l_1_3:SetRelPos
  l_1_5 = 30
  l_1_3(l_1_4, l_1_5, 180)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3 = l_1_2:OnCheck
  l_1_5 = function()
    -- upvalues: l_1_0
    CombatDnd.SaveSet.bdnd = true
    l_1_0:Lookup("CheckBox_FightBoss"):Lookup("", "Text_CheckBox"):SetFontColor(255, 255, 255)
  end
  l_1_3(l_1_4, l_1_5)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3 = l_1_2:UnCheck
  l_1_5 = function()
    -- upvalues: l_1_0
    CombatDnd.SaveSet.bdnd = false
    l_1_0:Lookup("CheckBox_FightBoss"):Lookup("", "Text_CheckBox"):SetFontColor(188, 188, 188)
  end
  l_1_3(l_1_4, l_1_5)
  l_1_3 = CombatDnd
  l_1_3 = l_1_3.SaveSet
  l_1_3 = l_1_3.bdnd
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_1_3 then
    l_1_3 = l_1_2:Check
    l_1_5 = true
    l_1_3(l_1_4, l_1_5)
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_1_3 = l_1_0:Lookup
    l_1_5 = "CheckBox_FightBoss"
    l_1_3 = l_1_3(l_1_4, l_1_5)
     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_3 = l_1_3:Lookup
    l_1_5 = ""
    l_1_3 = l_1_3(l_1_4, l_1_5, "Text_CheckBox")
     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_3 = l_1_3:SetFontColor
    l_1_5 = 188
    l_1_3(l_1_4, l_1_5, 188, 188)
  end
  l_1_3 = BoxBoolCheckBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_5 = "CheckBox_Revive"
  l_1_3 = l_1_3(l_1_4, l_1_5, "ʩչ�����ʱ����", CombatDnd, "bReviveTalk")
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3 = l_1_3:SetRelPos
  l_1_5 = 0
  l_1_3(l_1_4, l_1_5, 210)
end

l_0_2.Create = l_0_3
l_0_2 = CombatDnd
l_0_3 = function(l_2_0)
  local l_2_1 = {}
  l_2_1.szOption = "���ŶӴ��к�"
  l_2_1.bCheck = true
  l_2_1.bChecked = CombatDnd.SaveSet.braid
  l_2_1.fnAction = function()
    CombatDnd.SaveSet.braid = not CombatDnd.SaveSet.braid
  end
  local l_2_2 = table.insert
  local l_2_3 = l_2_1
  local l_2_4 = {}
  l_2_4.szOption = "�޸Ĵ��к�����"
  l_2_4.fnAction = function()
    GetUserInput("�������ӳ�(dz),��Ա(dy)", function(l_5_0)
      CombatDnd.SaveSet.szraid = l_5_0
    end, nil, nil, nil, CombatDnd.SaveSet.szraid)
  end
  l_2_2(l_2_3, l_2_4)
  l_2_2 = table
  l_2_2 = l_2_2.insert
  l_2_3 = l_2_1
  l_2_2(l_2_3, l_2_4)
  l_2_4 = {szOption = CombatDnd.SaveSet.szraid}
  l_2_2 = table
  l_2_2 = l_2_2.insert
  l_2_3 = l_2_0
  l_2_4 = l_2_1
  l_2_2(l_2_3, l_2_4)
  l_2_3 = CombatDnd
  l_2_3 = l_2_3.SaveSet
  l_2_3 = l_2_3.bteam
  l_2_3 = function()
    CombatDnd.SaveSet.bteam = not CombatDnd.SaveSet.bteam
  end
  l_2_3 = table
  l_2_3 = l_2_3.insert
  l_2_4, l_2_2 = l_2_2, {szOption = "�������к�", bCheck = true, bChecked = l_2_3, fnAction = l_2_3}
  local l_2_5 = {}
  l_2_5.szOption = "�޸Ĵ��к�����"
  l_2_5.fnAction = function()
    GetUserInput("�������ӳ�(dz),��Ա(dy)", function(l_7_0)
      CombatDnd.SaveSet.szteam = l_7_0
    end, nil, nil, nil, CombatDnd.SaveSet.szraid)
  end
  l_2_3(l_2_4, l_2_5)
  l_2_3 = table
  l_2_3 = l_2_3.insert
  l_2_4 = l_2_2
  l_2_3(l_2_4, l_2_5)
  l_2_5 = {szOption = CombatDnd.SaveSet.szteam}
  l_2_3 = table
  l_2_3 = l_2_3.insert
  l_2_4 = l_2_0
  l_2_5 = l_2_2
  l_2_3(l_2_4, l_2_5)
  l_2_4 = CombatDnd
  l_2_4 = l_2_4.SaveSet
  l_2_4 = l_2_4.btong
  l_2_4 = function()
    CombatDnd.SaveSet.btong = not CombatDnd.SaveSet.btong
  end
  l_2_4 = table
  l_2_4 = l_2_4.insert
  l_2_5, l_2_3 = l_2_3, {szOption = "������к�", bCheck = true, bChecked = l_2_4, fnAction = l_2_4}
  local l_2_6 = {}
  l_2_6.szOption = "�޸Ĵ��к�����"
  l_2_6.fnAction = function()
    GetUserInput("���������(bh),��Ա(cy)", function(l_9_0)
      CombatDnd.SaveSet.sztong = l_9_0
    end, nil, nil, nil, CombatDnd.SaveSet.szraid)
  end
  l_2_4(l_2_5, l_2_6)
  l_2_4 = table
  l_2_4 = l_2_4.insert
  l_2_5 = l_2_3
  l_2_4(l_2_5, l_2_6)
  l_2_6 = {szOption = CombatDnd.SaveSet.sztong}
  l_2_4 = table
  l_2_4 = l_2_4.insert
  l_2_5 = l_2_0
  l_2_6 = l_2_3
  l_2_4(l_2_5, l_2_6)
end

l_0_2.AddHelloMenu = l_0_3
l_0_2 = CombatDnd
l_0_3 = function(l_3_0)
  local l_3_1 = GetClientPlayer()
  if not l_3_1 then
    return 
  end
  if l_3_0 == "PARTY_ADD_MEMBER" then
    if not CombatDnd.SaveSet.bhello then
      return 
    end
    local l_3_2, l_3_3 = GetMapParams(l_3_1.GetMapID())
    if l_3_3 == 2 then
      return 
    end
    local l_3_4 = GetClientTeam()
    local l_3_5 = l_3_4.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER)
    local l_3_6 = l_3_4.GetMemberInfo(arg1)
    local l_3_7 = l_3_4.GetMemberInfo(l_3_5)
    if l_3_7 and l_3_6 then
      if l_3_4.nGroupNum == 1 and CombatDnd.SaveSet.bteam then
        local l_3_8 = CombatDnd.SaveSet.szteam
        l_3_8 = l_3_8:gsub("dz", "[" .. l_3_7.szName .. "]")
        l_3_8 = l_3_8:gsub("dy", "[" .. l_3_6.szName .. "]")
        local l_3_9 = l_3_1.Talk
        local l_3_10 = PLAYER_TALK_CHANNEL.TEAM
        local l_3_11 = ""
        local l_3_12 = {}
        local l_3_13 = {}
        l_3_13.type = "text"
        l_3_13.text = l_3_8
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_3_9(l_3_10, l_3_11, l_3_12)
      end
    elseif l_3_4.nGroupNum > 1 and CombatDnd.SaveSet.braid then
      local l_3_14 = CombatDnd.SaveSet.szraid
      l_3_14 = l_3_14:gsub("dz", "[" .. l_3_7.szName .. "]")
      l_3_14 = l_3_14:gsub("dy", "[" .. l_3_6.szName .. "]")
      local l_3_15 = l_3_1.Talk
      local l_3_16 = PLAYER_TALK_CHANNEL.RAID
      local l_3_17 = ""
      local l_3_18 = {}
      local l_3_19 = {}
      l_3_19.type = "text"
      l_3_19.text = l_3_14
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_3_15(l_3_16, l_3_17, l_3_18)
    end
  elseif l_3_0 == "TONG_MEMBER_JOIN" then
    if not CombatDnd.SaveSet.bhello or not CombatDnd.SaveSet.btong then
      return 
    end
    local l_3_20 = GetTongClient()
    local l_3_21 = l_3_20.ApplyGetTongName(l_3_1.dwTongID)
    local l_3_22 = CombatDnd.SaveSet.sztong
    l_3_22 = l_3_22:gsub("cy", "[" .. arg0 .. "]")
    l_3_22 = l_3_22:gsub("bh", "[" .. l_3_21 .. "]")
    local l_3_23 = l_3_1.Talk
    local l_3_24 = PLAYER_TALK_CHANNEL.TONG
    local l_3_25 = ""
    local l_3_26 = {}
    local l_3_27 = {}
    l_3_27.type = "text"
    l_3_27.text = l_3_22
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_3_23(l_3_24, l_3_25, l_3_26)
  elseif l_3_0 == "SYS_MSG" then
    if arg0 ~= "UI_OME_DEATH_NOTIFY" then
      return 
    end
    local l_3_28 = arg3
    local l_3_29 = arg1
    local l_3_30, l_3_31, l_3_32 = nil, nil, nil
    if CombatDnd.SaveSet.bkill and l_3_1.szName == l_3_28 then
      if IsPlayer(l_3_29) then
        if not CombatDnd.SaveSet.bkillplayer then
          return 
        end
        l_3_31 = GetPlayer(l_3_29)
        l_3_32 = "zj �ɹ���ɱ�� mb"
      else
        if not CombatDnd.SaveSet.bkillnpc then
          return 
        end
        l_3_31 = GetNpc(l_3_29)
        l_3_32 = "zj �ɹ���ɱ�� mb"
      end
      l_3_30 = CombatDnd.SaveSet.nChannel
    else
      if CombatDnd.bBeKill and l_3_29 == l_3_1.dwID then
        l_3_32 = CombatDnd.szBeKill
        l_3_30 = CombatDnd.nBeKillChannel
        l_3_31 = l_3_1
      end
    end
    if l_3_32 and l_3_31 then
      if l_3_28 == "" then
        l_3_28 = "<��������>"
      else
        l_3_28 = "[" .. l_3_28 .. "]"
      end
      l_3_32 = l_3_32:gsub("%$killer", l_3_28)
      l_3_32 = l_3_32:gsub("zj", "[" .. l_3_1.szName .. "]")
      l_3_32 = l_3_32:gsub("mb", "[" .. l_3_31.szName .. "]")
      l_3_32 = l_3_32:gsub("%$map", Table_GetMapName(l_3_1.GetMapID()))
      if (l_3_30 == PLAYER_TALK_CHANNEL.TEAM or l_3_30 == PLAYER_TALK_CHANNEL.RAID) and not l_3_1.IsInParty() then
        return 
      end
      local l_3_33 = l_3_1.Talk
      local l_3_34 = l_3_30
      local l_3_35 = ""
      local l_3_36 = {}
      local l_3_37 = {}
      l_3_37.type = "text"
      l_3_37.text = l_3_32
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_3_33(l_3_34, l_3_35, l_3_36)
    end
  elseif l_3_0 == "PLAYER_TALK" then
    if not CombatDnd.SaveSet.bdnd then
      return 
    end
    local l_3_38 = arg0
    local l_3_39 = arg1
    local l_3_40 = arg2
    local l_3_41 = arg3
    if not l_3_1.bFightState then
      return 
    end
    if l_3_39 ~= PLAYER_TALK_CHANNEL.WHISPER then
      return 
    end
    local l_3_42 = l_3_1.GetTalkData()
    local l_3_43 = l_3_42[1].text
    if l_3_43 == "BG_CHANNEL_MSG" then
      return 
    end
    if l_3_38 == l_3_1.dwID then
      if string.find(l_3_43, "�Զ��ظ�") then
        return 
      end
      if CombatDnd.DndPlayer[l_3_41] then
        CombatDnd.DndPlayer[l_3_41] = 2
      end
    else
      if CombatDnd.DndPlayer[l_3_41] then
        return 
      end
      if string.find(l_3_43, "<����>") or string.find(l_3_43, "<����Զ�����>") or string.find(l_3_43, "����ֵ+5��") then
        return 
      end
      if IsPlayerExist(l_3_38) then
        return 
      end
      local l_3_44 = "<�Զ��ظ�>����ս���С�"
      local l_3_45 = GetTargetHandle(l_3_1.GetTarget())
      if l_3_45 then
        local l_3_46 = false
        if CombatDnd.SaveSet.bboss and (IsPlayer(l_3_45.dwID) or IsPlayer(l_3_45.dwID) or GetNpcIntensity(l_3_45) >= 2) then
          l_3_46 = true
        end
        do return end
        l_3_46 = true
        if not l_3_46 then
          return 
        end
      end
      if IsEnemy(l_3_1.dwID, l_3_45.dwID) then
        local l_3_47 = l_3_45.nCurrentLife
        local l_3_48 = l_3_45.nMaxLife
        local l_3_49 = ""
        if tonumber(l_3_47) >= 10000 then
          l_3_49 = math.floor(l_3_47 / 10000) .. "��" .. l_3_47 % 10000
        else
          l_3_49 = l_3_47
        end
        local l_3_50 = "%.2f":format(100 * l_3_47 / l_3_48) .. "%"
        l_3_44 = FormatString("<�Զ��ظ�>������<D0>��ս��Ŀ�굱ǰѪ����<D1>(<D2>)", "[" .. l_3_45.szName .. "]", l_3_49, l_3_50)
      end
      CombatDnd.DndPlayer[l_3_41] = 1
      local l_3_51 = l_3_1.Talk
      local l_3_52 = PLAYER_TALK_CHANNEL.WHISPER
      local l_3_53 = l_3_41
      local l_3_54 = {}
      local l_3_55 = {}
      l_3_55.type = "text"
      l_3_55.text = l_3_44
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_3_51(l_3_52, l_3_53, l_3_54)
    end
  elseif l_3_0 == "FIGHT_HINT" then
    if arg0 then
      return 
    end
    if not CombatDnd.SaveSet.bdnd then
      return 
    end
    for l_3_59,l_3_60 in pairs(CombatDnd.DndPlayer) do
      if l_3_60 == 1 then
        local l_3_61 = l_3_1.Talk
        local l_3_62 = PLAYER_TALK_CHANNEL.WHISPER
        local l_3_63 = l_3_59
        local l_3_64 = {}
        local l_3_65 = {}
        l_3_65.type = "text"
        l_3_65.text = "<�Զ��ظ�>���Ѿ�������ս����"
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_3_61(l_3_62, l_3_63, l_3_64)
      end
    end
    CombatDnd.DndPlayer = {}
  elseif l_3_0 == "CUSTOM_DATA_LOADED" then
    if arg0 ~= "Role" then
      return 
    end
    local l_3_66 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    PLAYER_TALK_CHANNEL.SENCE.foreach(PLAYER_TALK_CHANNEL.FORCE, PLAYER_TALK_CHANNEL.CAMP)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_2.Event = l_0_3
l_0_2 = RegisterEvent
l_0_3 = "CUSTOM_DATA_LOADED"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_2 = RegisterEvent
l_0_3 = "FIGHT_HINT"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_2 = RegisterEvent
l_0_3 = "PLAYER_TALK"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_2 = RegisterEvent
l_0_3 = "SYS_MSG"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_2 = RegisterEvent
l_0_3 = "TONG_MEMBER_JOIN"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_2 = RegisterEvent
l_0_3 = "PARTY_ADD_MEMBER"
l_0_4 = CombatDnd
l_0_4 = l_0_4.Event
l_0_2(l_0_3, l_0_4)
l_0_3 = false
l_0_4 = ""
local l_0_5 = ""
CombatDnd.TalkMsg = function(l_4_0)
  local l_4_1 = GetClientPlayer()
  if not l_4_1.IsInParty() then
    return 
  end
  local l_4_2 = PLAYER_TALK_CHANNEL.TEAM
  if l_4_1.IsInRaid() then
    l_4_2 = PLAYER_TALK_CHANNEL.RAID
  end
  if l_4_1.GetScene().nType == MAP_TYPE.BATTLE_FIELD then
    l_4_2 = PLAYER_TALK_CHANNEL.BATTLE_FIELD
  end
  local l_4_3 = l_4_1.Talk
  local l_4_4 = l_4_2
  local l_4_5 = ""
  local l_4_6 = {}
  local l_4_7 = {}
  l_4_7.type = "text"
  l_4_7.text = l_4_0
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_4_3(l_4_4, l_4_5, l_4_6)
end

RegisterEvent("DO_SKILL_PREPARE_PROGRESS", function()
  -- upvalues: l_0_2 , l_0_3 , l_0_4 , l_0_5
  if not CombatDnd.bReviveTalk then
    return 
  end
  local l_5_0 = GetClientPlayer()
  local l_5_1 = Table_GetSkillName(arg1, 1)
  if l_0_2[l_5_1] then
    local l_5_2 = GetTargetHandle(l_5_0.GetTarget())
  end
  if l_5_0.IsInParty() then
    l_0_3 = true
    l_0_4 = l_5_1
    if l_5_2 then
      l_0_5 = tostring("[" .. l_5_2.szName .. "]")
      CombatDnd.TalkMsg("��ʼ�˹� [" .. l_0_4 .. "]" .. " ���� " .. l_0_5 .. " ��")
    end
  else
    CombatDnd.TalkMsg("��ʼ�˹� [" .. l_0_4 .. "] ��")
  end
end
)
do
  RegisterEvent("OT_ACTION_PROGRESS_BREAK", function()
  -- upvalues: l_0_3 , l_0_5 , l_0_6
  local l_7_0 = GetClientPlayer()
  if arg0 == l_7_0.dwID and l_7_0.IsInParty() and l_0_3 then
    CombatDnd.TalkMsg("��ֹ���� " .. l_0_5 .. " ��")
    l_0_6()
  end
end
)
  RegisterEvent("DO_SKILL_CAST", function()
  -- upvalues: l_0_4 , l_0_3 , l_0_2 , l_0_5 , l_0_6
  local l_8_0 = GetClientPlayer()
  local l_8_1 = Table_GetSkillName(arg1, 1)
  if not l_0_2[l_8_1] then
    local l_8_2, l_8_3, l_8_4 = arg0 ~= l_8_0.dwID or not l_8_0.IsInParty() or l_8_1 ~= l_0_4 or not l_0_3 or "�Ѹ��� "
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  CombatDnd.TalkMsg(l_8_2 .. l_0_5 .. "��")
  l_0_6()
end
)
  RegisterEvent("FIGHT_HINT", function()
  -- upvalues: l_0_3 , l_0_4 , l_0_5 , l_0_6
  local l_9_0 = GetClientPlayer()
  if l_9_0.bFightState and l_9_0.IsInParty() and l_0_3 and l_0_4 ~= "�Ĺ���" then
    local l_9_1 = l_9_0.Talk
    local l_9_2 = PLAYER_TALK_CHANNEL.RAID
    local l_9_3 = ""
    local l_9_4 = {}
    local l_9_5 = {}
    l_9_5.type = "text"
    l_9_5.text = "����ս����" .. l_0_4 .. " " .. l_0_5 .. " �жϣ�\n"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_9_1(l_9_2, l_9_3, l_9_4)
    l_9_1 = l_0_6
    l_9_1()
  end
end
)
  RegisterMoonButton("CombatDnd", 2003, "��������", "General", CombatDnd.Create)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

