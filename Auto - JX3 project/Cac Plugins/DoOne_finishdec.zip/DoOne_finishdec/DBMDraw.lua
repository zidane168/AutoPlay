-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMDraw.lua 

DBMDraw = {}
local l_0_0 = "interface\\Moon_DBM\\DBMDraw.ini"
DBMDraw.OnFrameCreate = function()
  this:RegisterEvent("RENDER_FRAME_UPDATE")
end

DBMDraw.OnEvent = function(l_2_0)
  if l_2_0 == "RENDER_FRAME_UPDATE" then
    DBMDraw.Draw()
  end
end

DBMDraw.Draw = function()
  local l_3_0 = GetClientPlayer()
  if not l_3_0 then
    return 
  end
  local l_3_1 = Station.Lookup("Lowest/DBMDraw")
  local l_3_2 = l_3_1:Lookup("", "")
  local l_3_3 = l_3_2:GetItemCount()
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if not l_3_0.bFightState and l_3_3 > 0 then
    l_3_2:Clear()
  end
  return 
  local l_3_4 = DBMLogic.GetCurrMod()
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if (not l_3_4 or not l_3_4.bOn) and l_3_3 > 0 then
    l_3_2:Clear()
  end
  return 
  local l_3_5 = {}
  for l_3_9,l_3_10 in ipairs(DBMLogic.WatchNpc) do
    local l_3_11 = GetNpc(l_3_10)
    if l_3_11 and l_3_4.bossData[l_3_11.szName] and l_3_11.bFightState then
      local l_3_12 = l_3_4.bossData[l_3_11.szName]
    end
    if l_3_12 and l_3_12.bOn and l_3_12.bArea then
      l_3_5[l_3_10] = true
      local l_3_13 = l_3_2:Lookup(tostring(l_3_10))
      if not l_3_13 then
        l_3_2:AppendItemFromString(string.format("<shadow>name=\"%s\"</shadow>", tostring(l_3_10)))
        l_3_13 = l_3_2:Lookup(tostring(l_3_10))
        l_3_13:SetTriangleFan(true)
      end
      local l_3_14 = DBMDraw.Circle
      local l_3_15 = l_3_13
      local l_3_16 = l_3_10
      local l_3_17 = l_3_12.nAngle
      local l_3_18 = l_3_12.nRange * 64
      local l_3_19 = {}
      l_3_19.r = 255
      l_3_19.g = 0
      l_3_19.b = 0
      l_3_19.a = 100
      l_3_14(l_3_15, l_3_16, l_3_17, l_3_18, l_3_19)
    end
  end
  l_3_3 = l_3_2:GetItemCount()
  for l_3_23 = 0, l_3_3 - 1 do
    local l_3_24 = l_3_2:Lookup(l_3_23)
    if l_3_24 then
      local l_3_25 = tonumber(l_3_24:GetName())
    end
    if l_3_25 and not l_3_5[l_3_25] then
      l_3_2:RemoveItem(l_3_24:GetIndex())
    end
  end
end

DBMDraw.GetEndpointByAngle = function(l_4_0, l_4_1, l_4_2)
  local l_4_3 = {}
  local l_4_4 = l_4_2
  local l_4_5 = l_4_0.nFaceDirection
  local l_4_6 = (l_4_5 / 256 * 360 + l_4_1 + 720) % 360
  local l_4_7 = math.rad(l_4_6)
  local l_4_8 = l_4_0.nX
  local l_4_9 = l_4_0.nY
  local l_4_10 = math.abs(math.sin(l_4_7) * l_4_4)
  local l_4_11 = (math.abs(math.cos(l_4_7) * l_4_4))
  local l_4_12, l_4_13 = nil, nil
  if l_4_6 < 90 then
    l_4_12 = l_4_8 + l_4_11
   -- DECOMPILER ERROR: Overwrote pending register.

  elseif l_4_6 < 180 then
    l_4_12 = l_4_8 - l_4_11
   -- DECOMPILER ERROR: Overwrote pending register.

  elseif l_4_6 < 270 then
    l_4_12 = l_4_8 - l_4_11
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_4_12 = l_4_8 + l_4_11
  end
  local l_4_14 = l_4_12
  local l_4_15 = l_4_13
  l_4_3.nZ = l_4_0.nZ
  l_4_3.nY = l_4_15
  l_4_3.nX = l_4_14
  return l_4_3
end

DBMDraw.Circle = function(l_5_0, l_5_1, l_5_2, l_5_3, l_5_4)
  if not l_5_0 or not l_5_2 or not l_5_3 or not l_5_4 then
    return 
  end
  local l_5_5 = nil
  if IsPlayer(l_5_1) then
    l_5_5 = GetPlayer(l_5_1)
  else
    l_5_5 = GetNpc(l_5_1)
  end
  Moon_Lib.ApplyScreenPoint(function(l_6_0, l_6_1, l_6_2)
    -- upvalues: l_5_4
    if not l_6_2 or not l_6_2:IsValid() then
      return 
    end
    if not l_6_0 then
      l_6_2:Hide()
    end
    l_6_2:ClearTriangleFanPoint()
    l_6_2:AppendTriangleFanPoint(l_6_0, l_6_1, l_5_4.r, l_5_4.g, l_5_4.b, l_5_4.a / 2)
  end, l_5_0, l_5_5)
  local l_5_6 = math.floor(l_5_2 / 2)
  local l_5_7 = 10
  local l_5_8 = math.floor(l_5_6 / l_5_7) * 2 + 1
  local l_5_9 = math.floor(l_5_6 / l_5_7) * l_5_7 * -1
  local l_5_10 = math.ceil((l_5_8 - 1) / 2) + 1
  for l_5_14 = 0, l_5_8 - 1 do
    local l_5_15 = DBMDraw.GetEndpointByAngle(l_5_5, l_5_9 + l_5_14 * l_5_7, l_5_3)
    Moon_Lib.ApplyScreenPoint(function(l_7_0, l_7_1, l_7_2)
      -- upvalues: l_5_4
      if not l_7_2 or not l_7_2:IsValid() then
        return 
      end
      if l_7_0 then
        l_7_2:AppendTriangleFanPoint(l_7_0, l_7_1, l_5_4.r, l_5_4.g, l_5_4.b, l_5_4.a)
      end
    end, l_5_0, l_5_15)
  end
  l_5_0:Show()
end

Wnd.OpenWindow(l_0_0, "DBMDraw")

