-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: superPaste.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.x = 300
l_0_1.y = 500
l_0_0.loc = l_0_1
l_0_0.AutoCL = true
l_0_0.edit = ""
l_0_0.isSucceed = nil
superPaste = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "superPaste.loc"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "superPaste.AutoCL"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "superPaste.edit"
l_0_0(l_0_1)
l_0_0 = superPaste
l_0_1 = function()
  local l_1_0 = GetClientPlayer()
  local l_1_1 = superPaste.edit
  local l_1_5 = EditBox_GetChannel()
  if not R3_PC7 then
    local l_1_4 = R3_PC7
  end
  if not l_1_5 then
    local l_1_2, l_1_3 = l_1_4, 1
  end
  local l_1_6 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if superPaste.isnChannelAvailable(l_1_5) == 1 then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if superPaste.isnChannelAvailable(l_1_5) == 0 then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if string.len(l_1_1) <= 200 then
    do return end
  end
  OutputMessage("MSG_SYS", "��������̫���ˣ���Ҫ�ڹ���Ƶ����ˮŶ~\n")
   -- DECOMPILER ERROR: Overwrote pending register.

  if 2 == 2 then
    local l_1_7 = nil
    do
      local l_1_8 = nil
      l_1_0.Talk(l_1_8, l_1_6, {
{type = "text", text = l_1_1}})
    end
    do break end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_1_7 == 1 then
    local l_1_9 = nil
  end
  if l_1_1 ~= nil and 1 == 1 and l_1_1 ~= "" then
    if string.find(l_1_1, "\n") == nil then
      if string.len(l_1_1) > 600 then
        local l_1_10, l_1_11, l_1_12, l_1_13 = , 600
      end
     -- DECOMPILER ERROR: Confused about usage of registers!

    else
      if 0 == 1 then
        l_1_1 = string.sub(l_1_1, string.len(l_1_1) + 1)
      end
      local l_1_14 = nil
      local l_1_15 = nil
      l_1_0.Talk(l_1_14, l_1_6, {
{type = "text", text = wordprint}})
    end
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 92 
end

l_0_0.speak = l_0_1
l_0_0 = superPaste
l_0_1 = function(l_2_0)
  if l_2_0 == PLAYER_TALK_CHANNEL.TEAM or l_2_0 == PLAYER_TALK_CHANNEL.NEARBY or l_2_0 == PLAYER_TALK_CHANNEL.WHISPER or l_2_0 == PLAYER_TALK_CHANNEL.TONG or l_2_0 == PLAYER_TALK_CHANNEL.TONG_ALLIANCE or l_2_0 == PLAYER_TALK_CHANNEL.BATTLE_FIELD or l_2_0 == PLAYER_TALK_CHANNEL.RAID then
    return 1
  else
    if l_2_0 == PLAYER_TALK_CHANNEL.WORLD or l_2_0 == PLAYER_TALK_CHANNEL.FORCE or l_2_0 == PLAYER_TALK_CHANNEL.CAMP or l_2_0 == PLAYER_TALK_CHANNEL.SENCE or l_2_0 == PLAYER_TALK_CHANNEL.MENTOR or l_2_0 == PLAYER_TALK_CHANNEL.FRIENDS then
      return -1
    end
  else
    return 0
  end
end

l_0_0.isnChannelAvailable = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_3_0 = Station.Lookup("Normal/superPaste")
  if l_3_0 and l_3_0:IsVisible() then
    return true
  end
  return false
end

l_0_0.IsPasteOpen = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_4_0 = Station.Lookup("Normal/superPaste")
  if l_4_0 then
    if l_4_0:IsVisible() then
      l_4_0:Hide()
    else
      l_4_0:Show()
    end
  else
    l_4_0 = Wnd.OpenWindow("Interface\\Moon_Chat\\superPaste.ini", "superPaste")
    l_4_0:Show()
  end
end

l_0_0.show = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  local l_5_0 = Station.Lookup("Normal/superPaste", "")
  Station.Lookup("Normal/superPaste"):SetRelPos(tonumber(superPaste.loc.x), tonumber(superPaste.loc.y))
  l_5_0:Lookup("Text_Title"):SetText("��������")
  l_5_0:Lookup("Text_Tip"):SetText("���ɣ���Ҫ��ˮŶ��")
  this:Lookup("Edit_TextFile"):SetText(superPaste.edit)
  this:Lookup("CheckBox_AutoHide", "Text_AutoHide"):SetText("�Զ����")
  this:Lookup("Btn_Speak", "Text_Speak"):SetText("����")
  this:Lookup("CheckBox_AutoHide"):Check(superPaste.AutoCL)
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_6_0 = superPaste.loc
  local l_6_1 = superPaste.loc
  local l_6_2 = Station.Lookup("Normal/superPaste"):GetRelPos()
  l_6_1.y = Station.Lookup("Normal/superPaste")
  l_6_0.x = l_6_2
end

l_0_0.OnFrameDragEnd = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_7_0 = this:GetName()
  if l_7_0 == "CheckBox_AutoHide" and superPaste.AutoCL ~= true then
    superPaste.AutoCL = true
  end
end

l_0_0.OnCheckBoxCheck = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_8_0 = this:GetName()
  if l_8_0 == "CheckBox_AutoHide" and superPaste.AutoCL == true then
    superPaste.AutoCL = false
  end
end

l_0_0.OnCheckBoxUncheck = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_9_0 = this:GetName()
  if l_9_0 == "Btn_Speak" then
    superPaste.speakPack()
  elseif l_9_0 == "Btn_Close" then
    Station.Lookup("Normal/superPaste"):Hide()
  end
end

l_0_0.OnLButtonDown = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  superPaste.isSucceed = true
  superPaste.speak()
  if superPaste.AutoCL == true and superPaste.isSucceed == true then
    Station.Lookup("Normal/superPaste"):Lookup("Edit_TextFile"):SetText("")
    superPaste.edit = ""
  end
end

l_0_0.speakPack = l_0_1
l_0_0 = superPaste
l_0_1 = function()
  local l_11_0 = this:GetName()
  if l_11_0 == "Edit_TextFile" then
    superPaste.edit = this:GetText()
  end
end

l_0_0.OnEditChanged = l_0_1
l_0_0 = superPaste
l_0_1 = function(l_12_0)
  if l_12_0 == "UI_SCALED" then
    this:SetRelPos(tonumber(superPaste.loc.x), tonumber(superPaste.loc.y))
  end
end

l_0_0.OnEvent = l_0_1

