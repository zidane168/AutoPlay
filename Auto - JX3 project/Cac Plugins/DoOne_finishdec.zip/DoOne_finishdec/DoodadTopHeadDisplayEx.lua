-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DoodadTopHeadDisplayEx.lua 

if not DoodadTopHeadDisplayEx then
  DoodadTopHeadDisplayEx = {}
end
DoodadTopHeadDisplayEx.nSteperCount = -1
DoodadTopHeadDisplayEx.szLoginText = "DOODAD��ʾ��ǿ V1.00"
DoodadTopHeadDisplayEx.szAuthor = "By Danexx [QQ: 24713503]"
DoodadTopHeadDisplayEx.frameSelf = nil
DoodadTopHeadDisplayEx.windowCheckBoxes = nil
DoodadTopHeadDisplayEx.frameContant = nil
DoodadTopHeadDisplayEx.handleTotal = nil
DoodadTopHeadDisplayEx.SavedCheckState = {}
RegisterCustomData("DoodadTopHeadDisplayEx.SavedCheckState")
DoodadTopHeadDisplayEx.DataList = {
A = {bDefault = true, bEnable = true, szName = "��ʯ"}, 
B = {bDefault = true, bEnable = true, szName = "ҩ��"}, 
C = {bDefault = true, bEnable = true, szName = "����"}, 
D = {bDefault = false, bEnable = true, szName = "����"}}
DoodadTopHeadDisplayEx.SynAnyDoodadList = {}
DoodadTopHeadDisplayEx.OnFrameCreate = function()
  DoodadTopHeadDisplayEx:Message(DoodadTopHeadDisplayEx.szLoginText .. "(��ݼ�������) ����...")
  DoodadTopHeadDisplayEx.frameSelf = Station.Lookup("Normal/DoodadTopHeadDisplayEx")
  DoodadTopHeadDisplayEx.windowCheckBoxes = DoodadTopHeadDisplayEx.frameSelf:Lookup("Window_Checkboxes")
  DoodadTopHeadDisplayEx.frameContant = Station.Lookup("Lowest/DoodadTopHeadHandle")
  if not DoodadTopHeadDisplayEx.frameContant then
    DoodadTopHeadDisplayEx.frameContant = Wnd.OpenWindow("Interface\\DoodadTopHeadDisplayEx\\DoodadTopHeadHandle.ini", "DoodadTopHeadHandle")
  end
  DoodadTopHeadDisplayEx.handleTotal = DoodadTopHeadDisplayEx.frameContant:Lookup("", "")
  DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("RENDER_FRAME_UPDATE")
  DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("DOODAD_ENTER_SCENE")
  DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("DOODAD_LEAVE_SCENE")
  DoodadTopHeadDisplayEx:SetTitleAndAuthor(DoodadTopHeadDisplayEx.szLoginText, DoodadTopHeadDisplayEx.szAuthor)
  DoodadTopHeadDisplayEx.frameSelf:Lookup("", "Text_Edit_Filtrate"):SetText("���ְ���")
  for szKeyName,tInfo in pairs(DoodadTopHeadDisplayEx.DataList) do
    local checkBox = DoodadTopHeadDisplayEx:GetCheckBox(szKeyName)
    DoodadTopHeadDisplayEx:SetCheckBoxText(szKeyName, tInfo.szName)
    checkBox:Enable(tInfo.bEnable)
  end
end

DoodadTopHeadDisplayEx.OnLButtonClick = function()
  local szName = this:GetName()
  if szName == "Button_MainSwitch" then
    DoodadTopHeadDisplayEx:ClosePanel()
  end
end

DoodadTopHeadDisplayEx.OnCheckBoxCheck = function(event)
  local szName = this:GetName():gsub("CheckBox_", "")
  if DoodadTopHeadDisplayEx.DataList[szName] and DoodadTopHeadDisplayEx.DataList[szName].funcCheck then
    DoodadTopHeadDisplayEx.DataList[szName].funcCheck()
  end
  if szName == "A" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("A", true)
  elseif szName == "B" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("B", true)
  elseif szName == "C" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("C", true)
  elseif szName == "D" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("D", true)
  end
end

DoodadTopHeadDisplayEx.OnCheckBoxUncheck = function(event)
  local szName = this:GetName():gsub("CheckBox_", "")
  if DoodadTopHeadDisplayEx.DataList[szName] and DoodadTopHeadDisplayEx.DataList[szName].funcUncheck then
    DoodadTopHeadDisplayEx.DataList[szName].funcUncheck()
  end
  if szName == "A" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("A", false)
  elseif szName == "B" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("B", false)
  elseif szName == "C" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("C", false)
  elseif szName == "D" then
    DoodadTopHeadDisplayEx:SetCheckBoxState("D", false)
  end
end

DoodadTopHeadDisplayEx.OnEditSpecialKeyDown = function()
  do
    local szKey = GetKeyName(Station.GetMessageKey())
  end
  if szKey == "Enter" then
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 8 
end

DoodadTopHeadDisplayEx.OnEvent = function(event)
  if event == "RENDER_FRAME_UPDATE" then
    DoodadTopHeadDisplayEx:RefreshDoodadTopHeadDisplay()
  elseif event == "DOODAD_ENTER_SCENE" then
    DoodadTopHeadDisplayEx:AppendAnyDoodadToList(arg0)
  elseif event == "DOODAD_LEAVE_SCENE" then
    DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(arg0)
  end
end

DoodadTopHeadDisplayEx.OnFrameBreathe = function()
  DoodadTopHeadDisplayEx:Steper()
  DoodadTopHeadDisplayEx:UpdateAllDoodadNameLable()
end

DoodadTopHeadDisplayEx.UpdateAllDoodadNameLable = function(self)
  for dwDoodadID,tInfo in pairs(DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    DoodadTopHeadDisplayEx:UpdateAnyDoodadNameLable(dwDoodadID)
  end
end

DoodadTopHeadDisplayEx.GetAnyDoodadListCount = function(self)
  local nCount = 0
  for dwDoodadID,_ in pairs(DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    nCount = nCount + 1
  end
  return nCount
end

DoodadTopHeadDisplayEx.AppendAnyDoodadToList = function(self, dwDoodadID)
  if not dwDoodadID then
    return 
  end
  local doodad = GetDoodad(dwDoodadID)
  if DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID] and not doodad then
    DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(dwDoodadID)
  end
  return 
  if not doodad or doodad.nKind == DOODAD_KIND.CORPSE then
    return 
  end
  DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID] = {dwID = dwDoodadID, szName = doodad.szName, szTopHead = doodad.szName, nDistance = 0, nCameraDistance = 0}
  local handle = DoodadTopHeadDisplayEx.handleTotal
  local szHandleLabelName_Name = "Name_DOODAD_" .. dwDoodadID
  local handleLabel_Name = handle:Lookup(szHandleLabelName_Name)
  if not handleLabel_Name then
    handle:AppendItemFromIni("Interface/DoodadTopHeadDisplayEx/DoodadTopHeadHandle.ini", "Handle_Label", szHandleLabelName_Name)
    handleLabel_Name = handle:Lookup(handle:GetItemCount() - 1)
    handleLabel_Name.dwDoodadID = dwDoodadID
    handleLabel_Name.textLable = handleLabel_Name:Lookup("Text_Content")
    handleLabel_Name.textLable:SetFontScheme(40)
    DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID].handleLabel_Name = handleLabel_Name
  end
  DoodadTopHeadDisplayEx:UpdateAnyDoodadNameLable(dwDoodadID)
end

DoodadTopHeadDisplayEx.RemoveAnyDoodadFromList = function(self, dwDoodadID)
  if not dwDoodadID or not DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID] then
    return 
  end
  local handle = DoodadTopHeadDisplayEx.handleTotal
  local handleLabel_Name = handle:Lookup("Name_DOODAD_" .. dwDoodadID)
  if handleLabel_Name then
    handle:RemoveItem(handleLabel_Name:GetIndex())
  end
  DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID] = nil
end

DoodadTopHeadDisplayEx.UpdateAnyDoodadNameLable = function(self, dwDoodadID)
  local tInfo = DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID]
  local doodad = GetDoodad(dwDoodadID)
  if not doodad and tInfo then
    DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(dwDoodadID)
  end
  return 
  if not tInfo then
    DoodadTopHeadDisplayEx:AppendAnyDoodadToList(dwDoodadID)
    return 
  end
  if not tInfo.handleLabel_Name then
    return 
  end
  tInfo.szName = doodad.szName
  local doodadTemplate = GetDoodadTemplate(doodad.dwTemplateID)
  tInfo.szTopHead = ""
  if DoodadTopHeadDisplayEx:GetCheckBoxState("A") and doodadTemplate.dwCraftID == 1 then
    tInfo.szTopHead = tInfo.szName
  else
    if DoodadTopHeadDisplayEx:GetCheckBoxState("B") and doodadTemplate.dwCraftID == 2 then
      tInfo.szTopHead = tInfo.szName
    end
  else
    if DoodadTopHeadDisplayEx:GetCheckBoxState("C") and doodadTemplate.dwCraftID == 12 then
      tInfo.szTopHead = tInfo.szName
    end
  else
    if DoodadTopHeadDisplayEx:GetCheckBoxState("D") and doodadTemplate.dwCraftID ~= 1 and doodadTemplate.dwCraftID ~= 2 and doodadTemplate.dwCraftID ~= 12 then
      tInfo.szTopHead = tInfo.szName
    end
  end
  local szFiltrate = DoodadTopHeadDisplayEx:GetEditValue()
  if tInfo.szTopHead ~= "" and szFiltrate and szFiltrate ~= "" and szFiltrate ~= "���á�/���ָ�������" then
    tInfo.szTopHead = ""
    szFiltrate = szFiltrate .. "/"
    do
      local nStartLoc = 1
      for i = 1, #szFiltrate do
        if szFiltrate:sub(i, i) == "/" and nStartLoc <= i then
          local szName = szFiltrate:sub(nStartLoc, i - 1):gsub("%s", "")
          if szName and szName ~= "" and tInfo.szName:match(szName) then
            tInfo.szTopHead = tInfo.szName
          end
          do break end
        end
        nStartLoc = i + 1
      end
    end
  end
  tInfo.handleLabel_Name.textLable:SetText(tInfo.szTopHead)
end

DoodadTopHeadDisplayEx.RefreshDoodadTopHeadDisplay = function(self)
  local playerClient = GetClientPlayer()
  if not playerClient then
    return 
  end
  local dwSelfID = playerClient.dwID
  for dwDoodadID,tInfo in pairs(DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    local doodad = GetDoodad(dwDoodadID)
    if not doodad then
      DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(dwDoodadID)
      return 
    end
    local nRed, nGreen, nBlue = 196, 64, 255
    local nDist2d = math.floor(playerClient.nX - doodad.nX ^ 2 + playerClient.nY - doodad.nY ^ 2 ^ 0.5)
    local nYShift = nDist2d * -0.001
    local nYShift = 0
    local nTopX, nTopY, nTopZ = Scene_GameWorldPositionToScenePosition(doodad.nX, doodad.nY, doodad.nZ, 0)
    local nScreenX, nScreenY, bSuccess = 0, 0, false
    if nTopX and nTopY and nTopZ then
      nScreenX = Scene_ScenePointToScreenPoint(nTopX, nTopY - nYShift, nTopZ)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if bSuccess then
      nScreenX = Station.AdjustToOriginalPos(nScreenX, nScreenY)
    elseif tInfo.handleLabel_Name then
      tInfo.handleLabel_Name:SetAbsPos(-4096, -4096)
    end
    if bSuccess then
      if DoodadTopHeadDisplayEx.nSteperCount % 4 == 0 or DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID].nCameraDistance == 0 then
        DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID].nCameraDistance = math.floor(playerClient.nX - doodad.nX ^ 2 + playerClient.nY - doodad.nY ^ 2 + playerClient.nZ / 8 - doodad.nZ / 8 ^ 2 ^ 0.5)
      end
      local nDist3D = DoodadTopHeadDisplayEx.SynAnyDoodadList[dwDoodadID].nCameraDistance
      local handleLabel_Name = tInfo.handleLabel_Name
      local textLable = nil
      if handleLabel_Name then
        textLable = handleLabel_Name.textLable
        local nWidth, nHeight = textLable:GetSize()
        local nX, nY = math.ceil(nScreenX - nWidth / 2) - 8, math.floor(nScreenY - nHeight / 2) - 80
        handleLabel_Name:SetAbsPos(nX, nY)
        textLable:Show()
        handleLabel_Name:SetUserData(-nDist3D)
      end
      local tFontScale = {16, 187, 40}
      if textLable and DoodadTopHeadDisplayEx.nSteperCount % 2 == 0 then
        if nDist3D < 800 then
          textLable:SetFontScheme(tFontScale[3])
          textLable:SetFontScale(1)
        end
      elseif nDist3D < 1600 then
        textLable:SetFontScheme(tFontScale[2])
        textLable:SetFontScale(1)
      elseif nDist3D < 2400 then
        textLable:SetFontScheme(tFontScale[1])
        textLable:SetFontScale(1)
      else
        local nDist3DDelta = nDist3D - 2400
        local nScale = 1 - nDist3DDelta / 4000
        if nScale <= 0.7 then
          nScale = 0.7
        end
        textLable:SetFontScheme(tFontScale[1])
        textLable:SetFontScale(nScale)
      end
      local bFade = true
      local nAlpha = 210
      if bFade then
        local nDistDelta = nDist3D - 900
        if nDistDelta <= 0 then
          nDistDelta = 0
        end
        nAlpha = nAlpha - math.floor(nDistDelta / 50)
      end
      if nAlpha <= 0 then
        nAlpha = 0
      end
      nAlpha = 210
    end
    if textLable then
      textLable:SetAlpha(nAlpha)
      textLable:SetFontColor(nRed, nGreen, nBlue)
    end
  end
  if DoodadTopHeadDisplayEx.nSteperCount % 16 == 0 then
    DoodadTopHeadDisplayEx.handleTotal:Sort()
  end
end

DoodadTopHeadDisplayEx.OnCustomDataLoaded = function(self)
  if arg0 ~= "Role" then
    return 
  end
  for szKeyName,tInfo in pairs(DoodadTopHeadDisplayEx.DataList) do
    local bState = nil
    if DoodadTopHeadDisplayEx.SavedCheckState[szKeyName] == nil then
      bState = tInfo.bDefault
    else
      bState = DoodadTopHeadDisplayEx.SavedCheckState[szKeyName]
    end
    DoodadTopHeadDisplayEx:SetCheckBoxState(szKeyName, bState)
  end
  DoodadTopHeadDisplayEx:SetEditValue("���á�/���ָ�������")
end

DoodadTopHeadDisplayEx.GetSelfFrame = function(self)
  return DoodadTopHeadDisplayEx.frameSelf
end

DoodadTopHeadDisplayEx.GetCheckboxesWindow = function(self)
  return DoodadTopHeadDisplayEx.windowCheckBoxes
end

DoodadTopHeadDisplayEx.GetEditValue = function(self)
  local edit = DoodadTopHeadDisplayEx.frameSelf:Lookup("Edit_Filtrate")
  local szValue = tostring(edit:GetText())
  return szValue
end

DoodadTopHeadDisplayEx.SetEditValue = function(self, szValue)
  local edit = DoodadTopHeadDisplayEx.frameSelf:Lookup("Edit_Filtrate")
  szValue = tostring(szValue) or "���á�/���ָ�������"
  edit:SetText(szValue)
end

DoodadTopHeadDisplayEx.GetCheckBox = function(self, szName)
  local window = self:GetCheckboxesWindow()
  return window:Lookup("CheckBox_" .. szName)
end

DoodadTopHeadDisplayEx.GetCheckBoxState = function(self, szName)
  local checkBox = self:GetCheckBox(szName)
  if checkBox:IsCheckBoxChecked() then
    return DoodadTopHeadDisplayEx.DataList[szName].bEnable
  end
end

DoodadTopHeadDisplayEx.SetCheckBoxState = function(self, szName, bState)
  local checkBox = self:GetCheckBox(szName)
  checkBox:Check(bState)
  DoodadTopHeadDisplayEx.SavedCheckState[szName] = bState
end

DoodadTopHeadDisplayEx.SetCheckBoxText = function(self, szName, szText)
  local checkBox = self:GetCheckBox(szName)
  local text = checkBox:Lookup("", "Text_" .. szName)
  text:SetText(szText)
end

DoodadTopHeadDisplayEx.GetCheckBoxText = function(self, szName)
  local checkBox = self:GetCheckBox(szName)
  local text = checkBox:Lookup("", "Text_" .. szName)
  return text:GetText()
end

DoodadTopHeadDisplayEx.SetTitleAndAuthor = function(self, szTitle, szAuthor)
  self.frameSelf:Lookup("", "Text_Title"):SetText(szTitle)
  self.frameSelf:Lookup("", "Text_Title"):SetFontColor(32, 255, 128)
  self.frameSelf:Lookup("", "Text_Author"):SetText(szAuthor)
end

DoodadTopHeadDisplayEx.FadeOptionPanel = function(self, nAlpha)
  if nAlpha < 0 then
    nAlpha = 0
  end
  if nAlpha > 255 then
    nAlpha = 255
  end
  for szKeyName,tInfo in pairs(ScreenShotHelper.DataList) do
    ScreenShotHelper:GetCheckBox(szKeyName):SetAlpha(nAlpha)
  end
  local edit = ScreenShotHelper.frameSelf:Lookup("Edit_Quality")
  if nAlpha <= 80 then
    edit:Hide()
  else
    edit:Show()
  end
  Station.Lookup("Normal/ScreenShotHelper", "Handle_Background_Texture/Image_Background"):SetAlpha(nAlpha)
  Station.Lookup("Normal/ScreenShotHelper", "Handle_Background_Texture/Image_Edit_Quality"):SetAlpha(nAlpha)
  ScreenShotHelper.frameSelf:Lookup("", "Text_Title"):SetAlpha(nAlpha)
  ScreenShotHelper.frameSelf:Lookup("", "Text_Author"):SetAlpha(nAlpha / 3.5)
  ScreenShotHelper.frameSelf:Lookup("", "Text_Edit_Quality"):SetAlpha(nAlpha)
  if nAlpha <= 80 then
    ScreenShotHelper.frameSelf:SetSize(32, 32)
    ScreenShotHelper.bOpened = false
  else
    ScreenShotHelper.frameSelf:SetSize(ScreenShotHelper.nOrgWidth, ScreenShotHelper.nOrgHeight)
    ScreenShotHelper.bOpened = true
  end
end

DoodadTopHeadDisplayEx.Message = function(self, szMessage)
  OutputMessage("MSG_SYS", "[DoodadTopHeadDisplayEx] " .. tostring(szMessage) .. "\n")
end

DoodadTopHeadDisplayEx.Steper = function(self)
  self.nSteperCount = self.nSteperCount + 1
  if self.nSteperCount >= 100000000 then
    self.nSteperCount = -1
  end
end

DoodadTopHeadDisplayEx.CheckSteper = function(self, nInterval)
  if not nInterval then
    nInterval = 8
  end
  if math.fmod(self.nSteperCount, nInterval) ~= 0 then
    return false
  end
  return true
end

DoodadTopHeadDisplayEx.SetPanelPos = function(self, nX, nY)
  if not nX or not nY then
    DoodadTopHeadDisplayEx.frameSelf:SetPoint("CENTER", 64, 0, "CENTER", -256, 0)
  else
    local nW, nH = Station.GetClientSize(true)
    if nX < 0 then
      nX = 0
    end
    if nW - 255 < nX then
      nX = nW - 255
    end
    if nY < 0 then
      nY = 0
    end
    if nH - 110 < nY then
      nY = nH - 110
    end
    DoodadTopHeadDisplayEx.frameSelf:SetRelPos(nX, nY)
  end
end

DoodadTopHeadDisplayEx.OpenPanel = function(self)
  if IsOptionOrOptionChildPanelOpened() then
    return 
  end
  local frame = Station.Lookup("Normal/DoodadTopHeadDisplayEx")
  if not frame then
    frame = Wnd.OpenWindow("Interface\\DoodadTopHeadDisplayEx\\DoodadTopHeadDisplayEx.ini", "DoodadTopHeadDisplayEx")
  end
  frame:Show()
  DoodadTopHeadDisplayEx:SetPanelPos()
end

DoodadTopHeadDisplayEx.ClosePanel = function(self)
  local frame = Station.Lookup("Normal/DoodadTopHeadDisplayEx")
  if not frame then
    return 
  end
  frame:Hide()
end

DoodadTopHeadDisplayEx.IsOpened = function(self)
  local frame = Station.Lookup("Normal/DoodadTopHeadDisplayEx")
  if frame and frame:IsVisible() then
    return true
  end
  return false
end

DoodadTopHeadDisplayEx.SwitchOpenState = function(self)
  if DoodadTopHeadDisplayEx:IsOpened() then
    DoodadTopHeadDisplayEx:ClosePanel()
  else
    DoodadTopHeadDisplayEx:OpenPanel()
  end
end

RegisterEvent("CUSTOM_DATA_LOADED", DoodadTopHeadDisplayEx.OnCustomDataLoaded)
DoodadTopHeadDisplayEx:OpenPanel()
DoodadTopHeadDisplayEx:ClosePanel()
Hotkey.AddBinding("DoodadTopHeadDisplayEx_Switch", "��/�ر��������", "DOODAD��ʾ��ǿ", DoodadTopHeadDisplayEx.SwitchOpenState, nil)

