-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ItemHelper.lua 

local l_0_0 = {}
l_0_0.bSellGrayItem = true
l_0_0.bAutoRepair = true
l_0_0.bAutoRollItem = true
l_0_0.bPlayerMenu = false
ItemHelper = l_0_0
l_0_0 = RegisterCustomData
l_0_0("ItemHelper.bSellGrayItem")
l_0_0 = RegisterCustomData
l_0_0("ItemHelper.bAutoRepair")
l_0_0 = RegisterCustomData
l_0_0("ItemHelper.bAutoRollItem")
l_0_0 = RegisterCustomData
l_0_0("ItemHelper.bPlayerMenu")
l_0_0 = ItemHelper
l_0_0.Print = function(l_1_0, l_1_1)
  OutputMessage("MSG_SYS", GetFormatText(string.format("[%s]��", l_1_0), 10, 0, 196, 196) .. l_1_1 .. GetFormatText("\n", 10), true)
end

l_0_0 = ItemHelper
l_0_0.GetUserInputItemName = function(l_2_0)
  GetUserInput("��������Ʒ����", function(l_3_0)
    -- upvalues: l_2_0
    l_3_0 = StringReplaceW(l_3_0, " ", "")
    if l_3_0 == "" then
      return 
    end
    local l_3_1 = {}
    if StringFindW(l_3_0, "[") then
      for l_3_5 in string.gfind(l_3_0, "[%[](.-)[%]]") do
        table.insert(l_3_1, l_3_5)
      end
    else
      table.insert(l_3_1, l_3_0)
    end
    for l_3_9,l_3_10 in pairs(l_3_1) do
      if not table.hasVal(l_2_0, l_3_10) then
        table.insert(l_2_0, l_3_10)
      end
    end
  end)
end

l_0_0 = ItemHelper
l_0_0.SellGrayItem = function(l_3_0, l_3_1)
  local l_3_2 = GetClientPlayer()
  for l_3_6 = 1, BIGBAGCOUNT do
    local l_3_7 = BagIndexToInventoryIndex(l_3_6)
    local l_3_8 = l_3_2.GetBoxSize(l_3_7)
    if l_3_8 and l_3_8 ~= 0 then
      for l_3_12 = 0, l_3_8 - 1 do
        local l_3_13 = l_3_2.GetItem(l_3_7, l_3_12)
        if l_3_13 and l_3_13.nQuality <= 0 then
          local l_3_14 = 1
          if l_3_13.bCanStack then
            l_3_14 = l_3_13.nStackNum
          end
          SellItem(l_3_0, l_3_1, l_3_7, l_3_12, l_3_14)
          ItemHelper.Print("�Զ�����", GetFormatText(string.format("%s x%d.", l_3_13.szName, l_3_14)))
        end
      end
    end
  end
end

l_0_0 = ItemHelper
l_0_0.OpenShop = function(l_4_0, l_4_1, l_4_2, l_4_3, l_4_4)
  local l_4_5 = GetClientPlayer()
  if not l_4_5 or l_4_5.nMoveState == MOVE_STATE.ON_DEATH then
    return 
  end
  if ItemHelper.bSellGrayItem then
    ItemHelper.SellGrayItem(l_4_4, l_4_0)
  end
  if not ItemHelper.bAutoRepair or not l_4_3 then
    return 
  end
  local l_4_6 = GetRepairAllItemsPrice(l_4_4, l_4_0)
  if not l_4_6 or l_4_6 == 0 then
    return 
  end
  if MoneyOptCmp(l_4_5.GetMoney(), l_4_6) >= 0 then
    RepairAllItems(l_4_4, l_4_0)
  else
    ItemHelper.Print("�Զ�����", GetFormatText("��û���㹻�Ľ�Ǯ�������е�װ����", 10))
  end
end

l_0_0 = RegisterEvent
l_0_0("SHOP_OPENSHOP", function()
  ItemHelper.OpenShop(arg0, arg1, arg2, arg3, arg4)
end
)
l_0_0 = RegisterEvent
l_0_0("BEGIN_ROLL_ITEM", function()
  if not ItemHelper.bAutoRollItem then
    return 
  end
  local l_6_0 = {}
  l_6_0["ݶ��ӡ"] = true
  l_6_0["�����ֻ�֮��"] = true
  l_6_0["������ѡƱ�һ�ȯ"] = true
  l_6_0["�ȷ���׹"] = true
  l_6_0["������Ƭ"] = true
  local l_6_1 = GetItem(arg1)
  local l_6_2 = GetItemInfo(l_6_1.dwTabType, l_6_1.dwIndex)
  if not l_6_1 then
    return 
  end
  if l_6_2.nGenre == 3 and l_6_2.nSub == 5 then
    return 
  end
  if l_6_2.nGenre == 4 then
    return 
  end
  if l_6_1.nBindType ~= ITEM_BIND.BIND_ON_PICKED or l_6_1.nBindType == ITEM_BIND.BIND_ON_PICKED and l_6_0[l_6_1.szName] then
    RollItem(arg0, arg1, 2)
    for l_6_6 = 1, 4 do
      do
        local l_6_7 = Station.Lookup("Normal/LootRoll" .. l_6_6)
        if l_6_7 and l_6_7.dwDoodadID == arg0 and l_6_7.dwItemID == arg1 then
          Wnd.CloseWindow(l_6_7:GetName())
        end
        do break end
      end
    end
    local l_6_8 = MakeItemLink("[" .. l_6_1.szName .. "]", " font=10 r=0 g=255 b=32 ", l_6_1.dwID)
    ItemHelper.Print("�Զ�Roll����", l_6_8 .. GetFormatText("��", 10))
  end
end
)
l_0_0 = ItemHelper
l_0_0.InsertLootMenu = function(l_7_0)
  local l_7_1 = {}
  l_7_1.szOption = "ֻʰȡָ����Ʒ"
  local l_7_2 = {}
  l_7_2.szOption = "����"
  l_7_2.bCheck = true
  l_7_2.bChecked = EasyLoot.bLootSpecified
  l_7_2.fnAction = function()
    EasyLoot.bLootSpecified = not EasyLoot.bLootSpecified
  end
  local l_7_3 = {}
  l_7_3.szOption = "����"
  l_7_3.fnAction = function()
    ItemHelper.GetUserInputItemName(EasyLoot.tLootSpecified)
  end
  local l_7_4 = {}
  l_7_4.bDevide = true
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_7_2 = EasyLoot
  l_7_2 = l_7_2.tLootSpecified
  l_7_2 = #l_7_2
  if l_7_2 == 0 then
    l_7_2 = table
    l_7_2 = l_7_2.insert
    l_7_3 = l_7_1
    l_7_2(l_7_3, l_7_4)
    l_7_4 = {szOption = "��"}
  else
    l_7_2 = ipairs
    l_7_3 = EasyLoot
    l_7_3 = l_7_3.tLootSpecified
    l_7_2 = l_7_2(l_7_3)
    for i_1,i_2 in l_7_2 do
      do
        local l_7_7 = table.insert
        local l_7_8 = l_7_1
        do
          local l_7_9 = {}
          l_7_9.szOption = l_7_6
          local l_7_10 = {}
          l_7_10.szOption = "ɾ��"
          l_7_10.fnAction = function()
            -- upvalues: l_7_5
            table.remove(EasyLoot.tLootSpecified, l_7_5)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_7_7(l_7_8, l_7_9)
        end
      end
    end
    table.insert(l_7_0, l_7_1)
    local l_7_11, l_7_29 = nil
    do
      local l_7_12, l_7_30 = nil
      local l_7_13 = nil
      l_7_11 = EasyLoot.tExcludeSetting.bExcludeGray
      l_7_11 = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeGray = not l_7_2.bExcludeGray
    end
      local l_7_14 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_7_29 = EasyLoot.tExcludeSetting.bExcludeWhite
      l_7_29 = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeWhite = not l_7_2.bExcludeWhite
    end
      local l_7_15 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_7_12 = EasyLoot.tExcludeSetting.bExcludeGreen
      l_7_12 = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeGreen = not l_7_2.bExcludeGreen
    end
      l_7_29, l_7_11 = {szOption = "������ɫװ��", bCheck = true, bChecked = l_7_12, fnAction = l_7_12}, {szOption = "���˰�ɫװ��", bCheck = true, bChecked = l_7_29, fnAction = l_7_29}
      for l_7_12,l_7_30 in pairs(l_7_11) do
        local l_7_16, l_7_17 = nil
        l_7_13 = EasyLoot
        l_7_13 = l_7_13.bLootSpecified
        l_7_30.bDisable = l_7_13
        l_7_13 = function()
        return EasyLoot.bLootSpecified
      end
        l_7_30.fnDisable = l_7_13
        l_7_13 = table
        l_7_13 = l_7_13.insert
        l_7_14 = l_7_0
        l_7_15 = l_7_30
        l_7_13(l_7_14, l_7_15)
      end
      do
        local l_7_18, l_7_28, l_7_31 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_7_19 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        local l_7_20 = nil
        local l_7_21 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        if #EasyLoot.tExcludeSetting.tExcludeSpecified == 0 then
          table.insert({
{szOption = "����", bCheck = true, bChecked = EasyLoot.tExcludeSetting.bExcludeSpecified, fnAction = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeSpecified = not l_7_2.bExcludeSpecified
    end}, 
{szOption = "����", fnAction = function()
      -- upvalues: l_7_2
      ItemHelper.GetUserInputItemName(l_7_2.tExcludeSpecified)
    end}, 
{bDevide = true}; szOption = "ʰȡ��Ʒ����", bDisable = l_7_11.bLootSpecified, fnDisable = function()
      return EasyLoot.bLootSpecified
    end}, {szOption = "��"})
          do break end
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        for i_1,l_7_13 in ipairs(EasyLoot.tExcludeSetting.tExcludeSpecified) do
          local l_7_22, l_7_23 = nil
          l_7_14 = table
          l_7_14 = l_7_14.insert
          local l_7_24 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_7_15 = {
{szOption = "����", bCheck = true, bChecked = EasyLoot.tExcludeSetting.bExcludeSpecified, fnAction = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeSpecified = not l_7_2.bExcludeSpecified
    end}, 
{szOption = "����", fnAction = function()
      -- upvalues: l_7_2
      ItemHelper.GetUserInputItemName(l_7_2.tExcludeSpecified)
    end}, 
{bDevide = true}; szOption = "ʰȡ��Ʒ����", bDisable = l_7_11.bLootSpecified, fnDisable = function()
      return EasyLoot.bLootSpecified
    end}
          local l_7_25 = nil
          local l_7_26 = nil
          local l_7_27 = nil
          l_7_31 = function()
        -- upvalues: l_7_2 , l_7_8
        table.remove(l_7_2.tExcludeSpecified, l_7_8)
      end
          l_7_28 = {szOption = "ɾ��", fnAction = l_7_31}
          l_7_14(l_7_15, l_7_18)
          l_7_18 = {l_7_28; szOption = l_7_13}
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    table.insert(l_7_0, {
{szOption = "����", bCheck = true, bChecked = EasyLoot.tExcludeSetting.bExcludeSpecified, fnAction = function()
      -- upvalues: l_7_2
      l_7_2.bExcludeSpecified = not l_7_2.bExcludeSpecified
    end}, 
{szOption = "����", fnAction = function()
      -- upvalues: l_7_2
      ItemHelper.GetUserInputItemName(l_7_2.tExcludeSpecified)
    end}, 
{bDevide = true}; szOption = "ʰȡ��Ʒ����", bDisable = l_7_11.bLootSpecified, fnDisable = function()
      return EasyLoot.bLootSpecified
    end})
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0 = ItemHelper
l_0_0.Create = function(l_8_0)
  BoxBoolCheckBox(l_8_0, "CheckBox_bRepairItem", "�Զ�����װ��", ItemHelper, "bAutoRepair")
  BoxBoolCheckBox(l_8_0, "CheckBox_bAutoRollItem", "�Զ�Roll����", ItemHelper, "bAutoRollItem"):SetRelPos(150, 0)
  BoxBoolCheckBox(l_8_0, "CheckBox_bSellGrayItem", "������ɫ��Ʒ", ItemHelper, "bSellGrayItem"):SetRelPos(0, 30)
  local l_8_1 = l_8_0:Lookup("", "")
  local l_8_2 = BoxLabel
  local l_8_3 = l_8_1
  local l_8_4 = "Label1"
  local l_8_5 = "��Ʒ����ʰȡ"
  local l_8_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_2(l_8_3, l_8_4, l_8_5, l_8_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5, l_8_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5, l_8_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5, l_8_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_6 = {txt = "ʰȡ��������", x = 150, y = 120}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4, l_8_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_3(l_8_4)
end

l_0_0 = RegisterMoonButton
l_0_0("ItemHelper", 538, "��Ʒ����", "General", ItemHelper.Create)
l_0_0 = RegisterPlayerMenu
l_0_0("loot", function()
  if not ItemHelper.bPlayerMenu then
    return {}
  end
  local l_9_0 = {}
  l_9_0.szOption = "ʰȡ����"
  local l_9_1 = {}
  l_9_1.szOption = "�����Զ�ʰȡ"
  l_9_1.bCheck = true
  l_9_1.bChecked = EasyLoot.bOn
  l_9_1.fnAction = function()
    EasyLoot.bOn = not EasyLoot.bOn
  end
  local l_9_2 = {}
  l_9_2.szOption = "ս���п�ʰȡ"
  l_9_2.bCheck = true
  l_9_2.bChecked = EasyLoot.bFightLoot
  l_9_2.fnAction = function()
    EasyLoot.bFightLoot = not EasyLoot.bFightLoot
  end
  local l_9_3 = {}
  l_9_3.bDevide = true
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_9_1 = ItemHelper
  l_9_1 = l_9_1.InsertLootMenu
  l_9_2 = l_9_0
  l_9_1(l_9_2)
  l_9_2 = l_9_0
  return l_9_1
  l_9_1 = {l_9_2}
end
)

