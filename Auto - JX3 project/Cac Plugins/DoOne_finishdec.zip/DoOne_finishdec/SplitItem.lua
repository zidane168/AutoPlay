-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SplitItem.lua 

SplitItem = {}
local l_0_0 = false
local l_0_1 = false
local l_0_2 = "interface\\Moon_SplitItem\\SplitItem.ini"
local l_0_3 = nil
local l_0_5 = function()
  -- upvalues: l_0_0 , l_0_1
  l_0_0 = false
  l_0_1 = false
  Cursor.Switch(CURSOR.NORMAL)
end

local l_0_6 = function()
  local l_10_0 = GetClientPlayer()
  local l_10_1, l_10_2, l_10_3 = this:GetObjectData()
  local l_10_4 = l_10_0.GetItem(l_10_2, l_10_3)
  if l_10_4 and l_10_4.nGenre ~= ITEM_GENRE.EQUIPMENT then
    OpenSplitItem(this)
  end
end

local l_0_7 = function()
  if this.OnItemMouseLeave then
    this.OnItemMouseLeave = nil
  end
  if this.OnItemLButtonClick then
    this.OnItemLButtonClick = nil
  end
  if this.OnItemMouseLeaveOrg then
    local l_11_0 = this.OnItemMouseLeaveOrg
    this.OnItemMouseLeaveOrg = nil
    l_11_0()
  end
  HideTip()
  this:SetObjectMouseOver(0)
  if UserSelect.IsSelectItem() then
    UserSelect.SatisfySelectItem(-1, -1, true)
    return 
  end
  if Cursor.GetCurrentIndex() == CURSOR.UNABLESPLIT then
    Cursor.Switch(CURSOR.SPLIT)
  else
    if Cursor.GetCurrentIndex() == CURSOR.UNABLEREPAIRE then
      Cursor.Switch(CURSOR.REPAIRE)
    end
  else
    if not IsCursorInExclusiveMode() then
      Cursor.Switch(CURSOR.NORMAL)
    end
  end
end

RegisterEvent("Breathe", function()
  -- upvalues: l_0_0 , l_0_3 , l_0_1 , l_0_8 , l_0_10 , l_0_6 , l_0_5
  if l_0_0 then
    local l_16_0 = Cursor.GetCurrentIndex()
    if not IsShiftKeyDown() and l_16_0 ~= CURSOR.SPLIT and l_16_0 ~= CURSOR.UNABLESPLIT then
      if l_0_3 and l_0_3.OnItemLButtonClick then
        l_0_3.OnItemLButtonClick = nil
        l_0_3.OnItemMouseLeave = nil
      end
      l_0_0 = false
      l_0_1 = false
      return 
    end
  else
    if not IsShiftKeyDown() then
      return 
    end
    do
      local l_16_1 = Station.GetMouseOverWindow()
      if not l_16_1 or l_16_1:GetName() ~= "BigBagPanel" then
        return 
      end
    end
    do return end
    l_0_0 = true
    l_0_1 = true
  end
  if not l_0_0 then
    return 
  end
  local l_16_2 = Station.Lookup("Normal/BigBagPanel")
  if not l_16_2:IsVisible() then
    return 
  end
  local l_16_3 = (l_16_2:Lookup("", "Handle_Box"))
  local l_16_4 = nil
  if l_16_3 then
    for l_16_8 = 0, l_16_3:GetItemCount() - 1 do
      do
        local l_16_9 = l_16_3:Lookup(l_16_8)
        if l_16_9 and l_0_8(l_16_9) then
          l_16_4 = l_16_9
        end
        do break end
      end
    end
  else
    l_16_4 = l_0_10(l_16_2)
  end
  if l_16_4 then
    if l_16_4.OnItemMouseLeave then
      l_16_4.OnItemMouseLeaveOrg = l_16_4.OnItemMouseLeave
    end
    l_0_3 = l_16_4
    l_16_4.OnItemMouseLeave = l_0_6
    l_16_4.OnItemLButtonClick = l_0_5
  end
end
)
local l_0_11 = function(l_12_0)
  local l_12_1 = GetClientPlayer()
  local l_12_2 = l_12_1.GetItem(l_12_0.dwBox, l_12_0.dwX)
  if not l_12_2 or not l_12_2.bCanStack or l_12_2.nStackNum < 2 then
    return false
  end
  return true
end

local l_0_12 = function(l_13_0)
  -- upvalues: l_0_1 , l_0_7
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if not l_13_0:IsEmpty() and l_13_0:IsObjectMouseOver() and not l_13_0.OnItemLButtonClick and Cursor.GetCurrentIndex() ~= CURSOR.SPLIT and l_0_1 then
    local l_13_1 = l_0_7(l_13_0)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_13_1
end

do
  local l_0_13 = function(l_14_0)
  -- upvalues: l_0_8
  local l_14_1 = l_14_0:GetItemCount()
  for l_14_5 = 0, l_14_1 - 1 do
    local l_14_6 = l_14_0:Lookup(l_14_5)
    if l_14_6 then
      local l_14_7 = l_14_6:GetItemCount()
      for l_14_11 = 0, l_14_7 - 1 do
        local l_14_12 = l_14_6:Lookup(l_14_11)
        if l_14_12 and l_14_12:GetType() == "Box" and l_0_8(l_14_12) then
          return l_14_12
        end
      end
    end
  end
end

  RegisterFrameHook("splitbtn_tip", {"Normal/BigBagPanel/Btn_Split"}, "OnMouseEnter", function()
  local l_17_0, l_17_1 = this:GetAbsPos()
  local l_17_2, l_17_3 = this:GetSize()
  local l_17_4 = GetFormatText("<���ٲ��>", 101) .. GetFormatText("�����ְ�ť���ٵ���ָ���Ʒ��", 106)
  local l_17_5 = OutputTip
  local l_17_6 = l_17_4
  local l_17_7 = 400
  do
    local l_17_8 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_17_5(l_17_6, l_17_7, l_17_8)
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
  RegisterFrameHook("splitbtn_click", {"Normal/BigBagPanel/Btn_Split"}, "OnLButtonClick", function()
  -- upvalues: l_0_0
  if not Hand_IsEmpty() then
    Hand_Clear()
  end
  Cursor.Switch(CURSOR.SPLIT)
  l_0_0 = true
  PlaySound(SOUND.UI_SOUND, g_sound.Button)
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

