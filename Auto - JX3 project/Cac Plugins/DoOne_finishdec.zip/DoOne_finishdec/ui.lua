-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ui.lua 

local l_0_0 = {}
classEx = function(l_1_0)
  -- upvalues: l_0_0
  local l_1_1 = {}
  l_1_1.ctor = false
  l_1_1.super = l_1_0
  l_1_1.new = function(...)
    -- upvalues: l_0_0 , l_1_1
    local l_2_1 = {}
    local l_2_2 = setmetatable
    local l_2_3 = l_2_1
    l_2_2(l_2_3, {__index = function(l_3_0, l_3_1)
      -- upvalues: l_0_0 , l_1_1 , l_1_1
      if l_0_0[l_1_1][l_3_1] then
        return l_0_0[l_1_1][l_3_1]
      else
        if l_0_0[l_1_1].ui then
          local l_3_2 = l_0_0[l_1_1].ui(l_1_1)
          do
            if l_3_2[l_3_1] and type(l_3_2[l_3_1]) == "function" then
              return function(l_4_0, ...)
              -- upvalues: l_1_2 , l_1_1
              local l_4_2 = l_1_2[l_1_1]
              local l_4_3 = l_1_2
              return l_4_2(l_4_3, ...)
            end
            end
          end
        end
      end
    end})
    l_2_2 = function(l_4_0, ...)
      -- upvalues: l_1_1
      if l_4_0.super then
        create(l_4_0.super, ...)
      end
      if l_4_0.ctor then
        l_4_0.ctor(l_1_1, ...)
      end
    end
    l_2_3 = l_2_2
    l_2_3(l_1_1, ...)
    return l_2_1
  end
  local l_1_2 = {}
  l_0_0[l_1_1] = l_1_2
  local l_1_3 = setmetatable
  local l_1_4 = l_1_1
  local l_1_5 = {}
  l_1_5.__newindex = function(l_3_0, l_3_1, l_3_2)
    -- upvalues: l_1_2
    l_1_2[l_3_1] = l_3_2
  end
  l_1_5.__call = function(l_4_0, ...)
    local l_4_2 = l_4_0.new
    return l_4_2(...)
  end
  l_1_3(l_1_4, l_1_5)
  if l_1_0 then
    l_1_3 = setmetatable
    l_1_4 = l_1_2
    l_1_3(l_1_4, l_1_5)
    l_1_5 = {__index = function(l_5_0, l_5_1)
      -- upvalues: l_0_0 , l_1_0 , l_1_2
      local l_5_2 = l_0_0[l_1_0][l_5_1]
      l_1_2[l_5_1] = l_5_2
      return l_5_2
    end}
  end
  return l_1_1
end

BoxFrame = classEx()
BoxFrame.ctor = function(l_2_0, l_2_1, l_2_2)
  if not l_2_2 then
    l_2_2 = {}
  end
  local l_2_3 = "interface/Moon_Lib/ini/BoxFrame.ini"
  local l_2_4 = nil
  if l_2_2.bglobal then
    l_2_4 = Wnd.OpenWindow(l_2_3, l_2_1)
  else
    l_2_4 = Wnd.OpenWindow(l_2_3)
  end
  l_2_4:Lookup("Btn_Close").OnLButtonClick = function()
    -- upvalues: l_2_1
    Wnd.CloseWindow(l_2_1)
  end
  l_2_4:SetName(l_2_1)
  l_2_4:Show()
  l_2_0.frame = l_2_4
  l_2_0.handle = l_2_4:Lookup("", "")
  if l_2_2.title then
    l_2_0:SetTitle(l_2_2.title)
  end
end

BoxFrame.ui = function(l_3_0)
  return l_3_0.frame
end

BoxFrame.SetTitle = function(l_4_0, l_4_1)
  l_4_0.frame:Lookup("", "Text_Title"):SetText(l_4_1)
end

BoxFrame.GetTitle = function(l_5_0)
  local l_5_3 = l_5_0.frame:Lookup
  local l_5_4 = l_5_0.frame
  l_5_3 = l_5_3(l_5_4, "", "Text_Title")
  l_5_3, l_5_4 = l_5_3:GetText, l_5_3
  local l_5_1, l_5_2 = nil
  return l_5_3(l_5_4)
end

BoxFrame.Center = function(l_6_0)
  l_6_0.frame:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
end

BoxSetFrame = classEx()
BoxSetFrame.ctor = function(l_7_0, l_7_1, l_7_2)
  if not l_7_2 then
    l_7_2 = {}
  end
  local l_7_3 = "interface/Moon_Lib/ini/BoxSetPanel.ini"
  local l_7_4 = nil
  if l_7_2.bglobal then
    l_7_4 = Wnd.OpenWindow(l_7_3, l_7_1)
  else
    l_7_4 = Wnd.OpenWindow(l_7_3)
  end
  l_7_4:SetName(l_7_1)
  l_7_4:Show()
  if not l_7_2.bglobal then
    l_7_4:Lookup("Btn_Close").OnLButtonClick = function()
    -- upvalues: l_7_1
    Wnd.CloseWindow(l_7_1)
  end
  end
  l_7_0.frame = l_7_4
  l_7_0.frame:EnableDrag(false)
  l_7_0.handle = l_7_4:Lookup("", "")
  if l_7_2.w and l_7_2.h then
    l_7_0:SetSize(l_7_2.w, l_7_2.h)
  end
  if l_7_2.bdrag ~= nil then
    l_7_0:EnableDrag(l_7_2.bdrag)
  end
end

BoxSetFrame.ui = function(l_8_0, ...)
  return l_8_0.frame
end

BoxSetFrame.SetSize = function(l_9_0, l_9_1, l_9_2)
  local l_9_3 = l_9_0.handle
  local l_9_4 = 340
  local l_9_5 = 155
  if l_9_1 < l_9_4 or l_9_2 < l_9_5 then
    return 
  end
  local l_9_6 = l_9_3:Lookup("Image_Bg1C")
  l_9_6:SetSize(l_9_1 - l_9_4, 70)
  local l_9_7 = l_9_3:Lookup("Image_Bg1R")
  l_9_7:SetRelPos(l_9_1 - 170 - 1, 0)
  l_9_3:Lookup("Image_Bg2L"):SetSize(8, l_9_2 - l_9_5)
  l_9_3:Lookup("Image_Bg2C"):SetSize(l_9_1 - 16, l_9_2 - l_9_5)
  local l_9_8 = l_9_3:Lookup("Image_Bg2R")
  l_9_8:SetSize(8, l_9_2 - l_9_5)
  l_9_8:SetRelPos(l_9_1 - 8, 70)
  local l_9_9 = 85
  local l_9_10 = l_9_2 - l_9_9
  local l_9_11 = l_9_3:Lookup("Image_Bg3L")
  l_9_11:SetRelPos(0, l_9_10)
  local l_9_12 = l_9_3:Lookup("Image_Bg3C")
  l_9_12:SetRelPos(124, l_9_10)
  l_9_12:SetSize(l_9_1 - 132, l_9_9)
  local l_9_13 = l_9_3:Lookup("Image_Bg3R")
  l_9_13:SetRelPos(l_9_1 - 8, l_9_10)
  l_9_0.frame:Lookup("Btn_Close"):SetRelPos(l_9_1 - 30, 10)
  l_9_0.handle:SetSize(l_9_1, l_9_2)
  l_9_0.handle:FormatAllItemPos()
  l_9_0.frame:SetSize(l_9_1, l_9_2)
  l_9_0.frame:SetDragArea(0, 0, l_9_1, l_9_2)
  return l_9_0
end

BoxSetFrame.Center = function(l_10_0)
  l_10_0.frame:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
end

local l_0_1 = function(l_11_0, l_11_1, l_11_2, l_11_3)
  local l_11_4 = Wnd.OpenWindow(l_11_1, l_11_3)
  local l_11_5 = l_11_4:Lookup(l_11_2)
  l_11_5:ChangeRelation(l_11_0, true, true)
  l_11_5:SetName(l_11_3)
  Wnd.CloseWindow(l_11_3)
  return l_11_5
end

local l_0_2 = function(l_12_0)
  local l_12_1 = l_12_0:GetName()
  local l_12_2 = l_12_0:GetParent()
  if not l_12_0.group or l_12_0.group == "" then
    return 
  end
  local l_12_3 = l_12_2:GetFirstChild()
  if l_12_3 then
    if l_12_3:GetType() == "WndCheckBox" and l_12_3.group and l_12_0.group == l_12_3.group and l_12_3:GetName() ~= l_12_1 then
      l_12_3:Check(false)
    end
    l_12_3 = l_12_3:GetNext()
  end
end
end

BoxWindow = classEx()
BoxWindow.ctor = function(l_13_0, l_13_1, l_13_2, l_13_3)
  -- upvalues: l_0_1
  local l_13_4 = "interface/Moon_Lib/ini/BoxWindow.ini"
  l_13_0.hwindow = l_0_1(l_13_1, l_13_4, "WndWindow", l_13_2)
  if not l_13_3 then
    l_13_3 = {}
  end
  if l_13_3.w and l_13_3.h then
    l_13_0:SetSize(l_13_3.w, l_13_3.h)
  end
  if l_13_3.x and l_13_3.y then
    l_13_0:SetRelPos(l_13_3.x, l_13_3.y)
  end
end

BoxWindow.ui = function(l_14_0)
  return l_14_0.hwindow
end

BoxWindow.SetSize = function(l_15_0, l_15_1, l_15_2)
  l_15_0.hwindow:SetSize(l_15_1, l_15_2)
  l_15_0.hwindow:Lookup("", ""):SetSize(l_15_1, l_15_2)
end

BoxWindow.GetSize = function(l_16_0)
  local l_16_1, l_16_2 = l_16_0.hwindow:GetSize, l_16_0.hwindow
  return l_16_1(l_16_2)
end

BoxComboBox = classEx()
BoxComboBox.ctor = function(l_17_0, l_17_1, l_17_2, l_17_3)
  -- upvalues: l_0_1
  if not l_17_3 then
    l_17_3 = {}
  end
  l_17_0.hwindow = l_0_1(l_17_1, "interface/Moon_Lib/ini/BoxComboBox.ini", "WndWindow", l_17_2)
  l_17_0.hwindow:Lookup("", "Text_ComboBox"):SetText(not l_17_3.txt or l_17_3.txt or "")
  if l_17_3.x and l_17_3.y then
    l_17_0:SetRelPos(l_17_3.x, l_17_3.y)
  end
  if l_17_3.w and l_17_3.h then
    l_17_0:SetSize(l_17_3.w, l_17_3.h)
  end
end

BoxComboBox.ui = function(l_18_0)
  return l_18_0.hwindow
end

BoxComboBox.SetSize = function(l_19_0, l_19_1, l_19_2)
  l_19_0.hwindow:SetSize(l_19_1, l_19_2)
  local l_19_3 = l_19_0.hwindow:Lookup("", "")
  l_19_3:SetSize(l_19_1, l_19_2)
  l_19_3:Lookup("Image_ComboBoxBg"):SetSize(l_19_1, l_19_2)
  l_19_3:Lookup("Text_ComboBox"):SetSize(l_19_1, l_19_2)
  local l_19_4, l_19_5 = l_19_3:GetAbsPos()
  local l_19_6 = l_19_0.hwindow:Lookup("Btn_ComboBox")
  l_19_6:SetRelPos(l_19_1 - 25, 3)
  local l_19_7 = l_19_6:Lookup("", "")
  l_19_7:SetSize(l_19_1, l_19_2)
  l_19_7:SetAbsPos(l_19_4, l_19_5)
end

BoxComboBox.SetText = function(l_20_0, l_20_1)
  l_20_0.hwindow:Lookup("", "Text_ComboBox"):SetText(l_20_1)
end

BoxComboBox.GetText = function(l_21_0)
  local l_21_3 = l_21_0.hwindow:Lookup
  local l_21_4 = l_21_0.hwindow
  l_21_3 = l_21_3(l_21_4, "", "Text_ComboBox")
  l_21_3, l_21_4 = l_21_3:GetText, l_21_3
  local l_21_1, l_21_2 = nil
  return l_21_3(l_21_4)
end

BoxComboBox.OnClick = function(l_22_0, l_22_1)
  l_22_0.hwindow:Lookup("Btn_ComboBox").OnLButtonClick = l_22_1
end

BoxComboBox.SetMenu = function(l_23_0, l_23_1)
  l_23_0.hwindow:Lookup("Btn_ComboBox").OnLButtonClick = function()
    -- upvalues: l_23_1
    local l_24_0 = this:GetParent()
    local l_24_1, l_24_2 = l_24_0:GetAbsPos()
    local l_24_3, l_24_4 = l_24_0:GetSize()
    local l_24_5 = {}
    l_24_5.nMiniWidth = l_24_3
    l_24_5.x = l_24_1
    l_24_5.y = l_24_2 + l_24_4
    l_23_1(l_24_5)
    PopupMenu(l_24_5)
  end
end

BoxEditComboBox = classEx()
BoxEditComboBox.ctor = function(l_24_0, l_24_1, l_24_2, l_24_3)
  -- upvalues: l_0_1
  local l_24_4 = "interface/Moon_Lib/ini/BoxEditComboBox.ini"
  l_24_0.hwindow = l_0_1(l_24_1, l_24_4, "Wnd_Window", l_24_2)
  l_24_0.hedit = l_24_0.hwindow:Lookup("Edit_Default")
  if not l_24_3 then
    l_24_3 = {}
  end
  if l_24_3.x and l_24_3.y then
    l_24_0.hwindow:SetRelPos(l_24_3.x, l_24_3.y)
  end
  if l_24_3.w and l_24_3.h then
    l_24_0:SetSize(l_24_3.w, l_24_3.h)
  end
end

BoxEditComboBox.ui = function(l_25_0)
  return l_25_0.hedit
end

BoxEditComboBox.OnChanged = function(l_26_0, l_26_1)
  l_26_0.hedit.OnEditChanged = l_26_1
end

BoxEditComboBox.SetValue = function(l_27_0, l_27_1, l_27_2)
  l_27_0.hedit:SetText(tostring(l_27_1[l_27_2]))
  l_27_0.hedit.OnEditChanged = function()
    -- upvalues: l_27_1 , l_27_2
    local l_28_0 = this:GetText()
    if l_28_0 ~= "" then
      if type(l_27_1[l_27_2]) == "number" then
        l_28_0 = tonumber(l_28_0)
      end
      l_27_1[l_27_2] = l_28_0
    end
  end
end

BoxEditComboBox.SetMenu = function(l_28_0, l_28_1)
  l_28_0.hwindow:Lookup("Btn_ComboBox").OnLButtonClick = function()
    -- upvalues: l_28_1 , l_28_0
    local l_29_0 = this:GetParent()
    local l_29_1, l_29_2 = l_29_0:GetAbsPos()
    local l_29_3, l_29_4 = l_29_0:GetSize()
    local l_29_5 = {}
    l_29_5.nMiniWidth = l_29_3
    l_29_5.x = l_29_1
    l_29_5.y = l_29_2 + l_29_4
    l_28_1(l_29_5, l_28_0.hedit)
    PopupMenu(l_29_5)
  end
end

BoxComboBox.OnClick = function(l_29_0, l_29_1)
  l_29_0.hwindow:Lookup("Btn_ComboBox").OnLButtonClick = function()
    -- upvalues: l_29_1 , l_29_0
    l_29_1(l_29_0.hedit)
  end
end

BoxEditComboBox.SetSize = function(l_30_0, l_30_1, l_30_2)
  local l_30_3 = l_30_1 + 15
  local l_30_4 = l_30_2
  l_30_0.hwindow:SetSize(l_30_3, l_30_4)
  l_30_0.hwindow:Lookup("", "Image_Edit_Bg"):SetSize(l_30_3, l_30_4)
  l_30_0.hedit:SetSize(l_30_1 - 20, l_30_2)
  local l_30_5 = l_30_0.hwindow:Lookup("Btn_ComboBox")
  l_30_5:SetRelPos(l_30_1 - 15, 0)
  l_30_5:SetSize(l_30_2, l_30_2)
  l_30_5:Lookup("", ""):SetSize(l_30_2 * 2, l_30_2)
end

BoxEdit = classEx()
BoxEdit.ctor = function(l_31_0, l_31_1, l_31_2, l_31_3)
  -- upvalues: l_0_1
  local l_31_4 = "interface/Moon_Lib/ini/BoxEdit.ini"
  l_31_0.hwindow = l_0_1(l_31_1, l_31_4, "Window_Edit", l_31_2)
  l_31_0.hedit = l_31_0.hwindow:Lookup("Edit_Default")
  if not l_31_3 then
    l_31_3 = {}
  end
  if l_31_3.w and l_31_3.h then
    l_31_0:SetSize(l_31_3.w, l_31_3.h)
  end
  if l_31_3.x and l_31_3.y then
    l_31_0.hwindow:SetRelPos(l_31_3.x, l_31_3.y)
  end
  if l_31_3.nmulti ~= nil then
    l_31_0:SetMultiLine(l_31_3.nmulti)
  end
  if l_31_3.nlimit then
    l_31_0:SetLimit(l_31_3.nlimit)
  end
  if l_31_3.txt then
    l_31_0:SetText(l_31_3.txt)
  end
  if l_31_3.benable ~= nil then
    l_31_0:Enable(l_31_3.benable)
  end
end

BoxEdit.ui = function(l_32_0)
  return l_32_0.hedit
end

BoxEdit.OnChanged = function(l_33_0, l_33_1)
  l_33_0.hedit.OnEditChanged = l_33_1
end

BoxEdit.SetValue = function(l_34_0, l_34_1, l_34_2)
  l_34_0.hedit:SetText(tostring(l_34_1[l_34_2]))
  l_34_0.hedit.OnEditChanged = function()
    -- upvalues: l_34_1 , l_34_2
    local l_35_0 = this:GetText()
    if l_35_0 ~= "" then
      if type(l_34_1[l_34_2]) == "number" then
        l_35_0 = tonumber(l_35_0)
      end
      l_34_1[l_34_2] = l_35_0
    end
  end
end

BoxEdit.SetSize = function(l_35_0, l_35_1, l_35_2)
  l_35_0.hwindow:SetSize(l_35_1 + 4, l_35_2)
  l_35_0.hwindow:Lookup("", ""):SetSize(l_35_1 + 4, l_35_2)
  l_35_0.hwindow:Lookup("", "Image_Edit"):SetSize(l_35_1 + 4, l_35_2)
  l_35_0.hedit:SetSize(l_35_1, l_35_2)
end

BoxUIButton = classEx()
local l_0_3 = function()
  this.bIn = true
  if not this.bSel then
    this:Lookup("Image_Bg"):Hide()
    this:Lookup("Image_BgOver"):Show()
  end
end

local l_0_4 = function()
  this.bIn = false
  if not this.bSel then
    this:Lookup("Image_Bg"):Show()
    this:Lookup("Image_BgOver"):Hide()
  end
end

do
  local l_0_5 = function()
  local l_38_0 = this:GetName()
  local l_38_1 = this:GetParent()
  local l_38_2 = l_38_1:GetItemCount()
  if l_38_2 > 0 then
    for l_38_6 = 0, l_38_2 - 1 do
      local l_38_7 = l_38_1:Lookup(l_38_6)
      if l_38_7 then
        if l_38_7:GetName() == this:GetName() then
          this:Lookup("Image_BgSel"):Show()
          this:Lookup("Image_BgOver"):Hide()
          this:Lookup("Image_Bg"):Hide()
        end
      else
        l_38_7:Lookup("Image_BgSel"):Hide()
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

  BoxUIButton.ctor = function(l_39_0, l_39_1, l_39_2, l_39_3)
  -- upvalues: l_0_3 , l_0_4 , l_0_5
  local l_39_4 = "interface/Moon_Lib/ini/BoxUIButton.ini"
  local l_39_5 = l_39_1:AppendItemFromIni(l_39_4, "Handle_Button", l_39_2)
  l_39_5.bBtn = true
  l_39_0.handle = l_39_5
  if l_39_3 then
    l_39_5:Lookup("Img_Sign"):FromIconID(l_39_3)
  end
  l_39_5.OnItemMouseEnter = l_0_3
  l_39_5.OnItemMouseLeave = l_0_4
  l_39_5.OnItemLButtonDown = l_0_5
end

  BoxUIButton.ui = function(l_40_0)
  return l_40_0.handle
end

  BoxUIButton.GetText = function(l_41_0)
  local l_41_3 = l_41_0.handle:Lookup
  l_41_3 = l_41_3(l_41_0.handle, "Text_Name")
  local l_41_1, l_41_2 = l_41_3
  return l_41_3(l_41_1)
end

  BoxUIButton.SetText = function(l_42_0, l_42_1)
  l_42_0.handle:Lookup("Text_Name"):SetText(l_42_1)
end

  BoxButton = classEx()
  BoxButton.ctor = function(l_43_0, l_43_1, l_43_2, l_43_3)
  -- upvalues: l_0_1
  if not l_43_3 then
    l_43_3 = {}
  end
  local l_43_4 = "Interface/Moon_Lib/ini/BoxButton.ini"
  l_43_0.hwnd = l_0_1(l_43_1, l_43_4, "Btn_Default", l_43_2)
  l_43_0.txt = l_43_0.hwnd:Lookup("", "Text_Btn")
  l_43_0.txt:SetText(l_43_3.txt or "")
  if l_43_3.x and l_43_3.y then
    l_43_0:SetRelPos(l_43_3.x, l_43_3.y)
  end
  if l_43_3.w and l_43_3.h then
    l_43_0:SetSize(l_43_3.w, l_43_3.h)
  end
  if l_43_3.benable ~= nil then
    l_43_0:Enable(l_43_3.benable)
  end
end

  BoxButton.ui = function(l_44_0)
  return l_44_0.hwnd
end

  BoxButton.SetAnimateGroup = function(l_45_0, l_45_1, l_45_2, l_45_3, l_45_4)
  l_45_0.hwnd:SetAnimateGroupNormal(l_45_1)
  l_45_0.hwnd:SetAnimateGroupMouseOver(l_45_2)
  l_45_0.hwnd:SetAnimateGroupMouseDown(l_45_3)
  l_45_0.hwnd:SetAnimateGroupDisable(l_45_4)
end

  BoxButton.SetSize = function(l_46_0, l_46_1, l_46_2)
  l_46_0.hwnd:SetSize(l_46_1, l_46_2)
  local l_46_3 = l_46_0.hwnd:Lookup("", "")
  l_46_3:SetSize(l_46_1, l_46_2)
  l_46_0.txt:SetSize(l_46_1, l_46_2)
end

  BoxButton.SetText = function(l_47_0, l_47_1)
  l_47_0.txt:SetText(l_47_1)
end

  BoxButton.GetText = function(l_48_0)
  local l_48_1, l_48_2 = l_48_0.txt:GetText, l_48_0.txt
  return l_48_1(l_48_2)
end

  BoxButton.SetFontScheme = function(l_49_0, ...)
  l_49_0.txt:SetFontScheme(...)
end

  BoxButton.GetFontScheme = function(l_50_0)
  local l_50_1, l_50_2 = l_50_0.txt:GetFontScheme, l_50_0.txt
  return l_50_1(l_50_2)
end

  BoxButton.SetFontColor = function(l_51_0, ...)
  l_51_0.txt:SetFontColor(...)
end

  BoxButton.GetFontColor = function(l_52_0)
  local l_52_1, l_52_2 = l_52_0.txt:GetFontColor, l_52_0.txt
  return l_52_1(l_52_2)
end

  BoxButton.OnClick = function(l_53_0, l_53_1)
  l_53_0.hwnd.OnLButtonClick = l_53_1
end

  BoxButton.OnMouseEnter = function(l_54_0, l_54_1)
  l_54_0.hwnd.OnMouseEnter = l_54_1
end

  BoxButton.OnMouseLeave = function(l_55_0, l_55_1)
  l_55_0.hwnd.OnMouseLeave = l_55_1
end

  BoxScroll = classEx()
  BoxScroll.ctor = function(l_56_0, l_56_1, l_56_2, l_56_3)
  -- upvalues: l_0_1
  if not l_56_3 then
    l_56_3 = {}
  end
  local l_56_4 = "interface/Moon_Lib/ini/BoxScroll.ini"
  l_56_0.hwindow = l_0_1(l_56_1, l_56_4, "WndWindow", l_56_2)
  l_56_0.handle = l_56_0.hwindow:Lookup("", "")
  local l_56_5 = l_56_0.hwindow
  local l_56_6 = l_56_0.handle
  l_56_5:Lookup("Btn_Up").OnLButtonHold = function()
    -- upvalues: l_56_5
    l_56_5:Lookup("Scroll_Info"):ScrollPrev(1)
  end
  l_56_5:Lookup("Btn_Up").OnLButtonDown = function()
    -- upvalues: l_56_5
    l_56_5:Lookup("Scroll_Info"):ScrollPrev(1)
  end
  l_56_5:Lookup("Btn_Down").OnLButtonHold = function()
    -- upvalues: l_56_5
    l_56_5:Lookup("Scroll_Info"):ScrollNext(1)
  end
  l_56_5:Lookup("Btn_Down").OnLButtonDown = function()
    -- upvalues: l_56_5
    l_56_5:Lookup("Scroll_Info"):ScrollNext(1)
  end
  if l_56_3.nstep then
    l_56_0.nStep = l_56_3.nstep
    l_56_0.bHome = l_56_3.bhome
    l_56_6.OnItemMouseWheel = function()
      local l_61_0 = Station.GetMessageWheelDelta()
      this:GetParent():Lookup("Scroll_Info"):ScrollNext(l_61_0)
      return 1
    end
    l_56_5:Lookup("Scroll_Info").OnScrollBarPosChanged = function()
      -- upvalues: l_56_5 , l_56_0
      local l_62_0 = this:GetScrollPos()
      if l_62_0 == 0 then
        l_56_5:Lookup("Btn_Up"):Enable(0)
      else
        l_56_5:Lookup("Btn_Up"):Enable(1)
      end
      if l_62_0 == this:GetStepCount() then
        l_56_5:Lookup("Btn_Down"):Enable(0)
      else
        l_56_5:Lookup("Btn_Down"):Enable(1)
      end
      local l_62_1 = l_56_5:Lookup("", "")
      l_62_1:SetItemStartRelPos(0, -l_62_0 * l_56_0.nStep)
    end
  end
  if l_56_3.x and l_56_3.y then
    l_56_0:SetRelPos(l_56_3.x, l_56_3.y)
  end
  if l_56_3.w and l_56_3.h then
    l_56_0:SetSize(l_56_3.w, l_56_3.h)
  end
end

  BoxScroll.ui = function(l_57_0)
  return l_57_0.hwindow
end

  BoxScroll.Update = function(l_58_0)
  if l_58_0.nStep then
    local l_58_1 = l_58_0.hwindow
    local l_58_2 = l_58_0.handle
    l_58_2:FormatAllItemPos()
    local l_58_3 = l_58_1:Lookup("Scroll_Info")
    if l_58_0.bHome then
      l_58_3:ScrollHome()
    end
    local l_58_4, l_58_5 = l_58_2:GetSize()
    local l_58_6, l_58_7 = l_58_2:GetAllItemSize()
    local l_58_8 = math.ceil((l_58_7 - l_58_5) / l_58_0.nStep)
    l_58_3:SetStepCount(l_58_8)
    if l_58_8 > 0 then
      l_58_3:Show()
      l_58_1:Lookup("Btn_Up"):Show()
      l_58_1:Lookup("Btn_Down"):Show()
    end
  else
    l_58_3:Hide()
    l_58_1:Lookup("Btn_Up"):Hide()
    l_58_1:Lookup("Btn_Down"):Hide()
  end
end

  BoxScroll.SetSize = function(l_59_0, l_59_1, l_59_2)
  l_59_0.hwindow:SetSize(l_59_1, l_59_2)
  l_59_0.hwindow:Lookup("", ""):SetSize(l_59_1, l_59_2)
  l_59_0.hwindow:Lookup("Scroll_Info"):SetSize(15, l_59_2 - 40)
  l_59_0.hwindow:Lookup("Scroll_Info"):SetRelPos(l_59_1 - 17, 20)
  l_59_0.hwindow:Lookup("Btn_Up"):SetRelPos(l_59_1 - 20, 3)
  l_59_0.hwindow:Lookup("Btn_Down"):SetRelPos(l_59_1 - 20, l_59_2 - 20)
end

  BoxCSlider = classEx()
  BoxCSlider.ctor = function(l_60_0, l_60_1, l_60_2, l_60_3)
  -- upvalues: l_0_1
  if not l_60_3 then
    l_60_3 = {}
  end
  l_60_0.nMin = l_60_3.min
  l_60_0.nMax = l_60_3.max
  l_60_0.nStep = l_60_3.step
  local l_60_4 = "interface/Moon_Lib/ini/BoxCSlider.ini"
  l_60_0.hwnd = l_0_1(l_60_1, l_60_4, "Scroll_Default", l_60_2)
  l_60_0.hwnd:SetStepCount(l_60_3.step)
  if l_60_3.w then
    l_60_0:SetSize(l_60_3.w)
  end
  if l_60_3.x and l_60_3.y then
    l_60_0:SetRelPos(l_60_3.x, l_60_3.y)
  end
  if l_60_3.val then
    l_60_0:UpdateScrollPos(l_60_3.val)
  end
end

  BoxCSlider.ui = function(l_61_0)
  return l_61_0.hwnd
end

  BoxCSlider.GetValue = function(l_62_0, l_62_1)
  return l_62_0.nMin + l_62_1 * (l_62_0.nMax - l_62_0.nMin) / l_62_0.nStep
end

  BoxCSlider.GetStep = function(l_63_0, l_63_1)
  return (l_63_1 - l_63_0.nMin) * l_63_0.nStep / (l_63_0.nMax - l_63_0.nMin)
end

  BoxCSlider.ChangeToArea = function(l_64_0, l_64_1, l_64_2, l_64_3)
  return l_64_1 + (l_64_2 - l_64_1) * (l_64_0:GetValue(l_64_3) - l_64_0.nMin) / (l_64_0.nMax - l_64_0.nMin)
end

  BoxCSlider.ChangeToAreaFromValue = function(l_65_0, l_65_1, l_65_2, l_65_3)
  return l_65_1 + (l_65_2 - l_65_1) * (l_65_3 - l_65_0.nMin) / (l_65_0.nMax - l_65_0.nMin)
end

  BoxCSlider.GetStepFromArea = function(l_66_0, l_66_1, l_66_2, l_66_3)
  local l_66_4, l_66_5 = l_66_0:GetStep, l_66_0
  local l_66_8 = l_66_0.nMin
  local l_66_7 = (l_66_0.nMax - l_66_0.nMin) * (l_66_3 - l_66_1) / (l_66_2 - l_66_1)
  l_66_8 = l_66_8 + l_66_7
  local l_66_6 = nil
  return l_66_4(l_66_5, l_66_8)
end

  BoxCSlider.OnChanged = function(l_67_0, l_67_1)
  l_67_0.hwnd.OnScrollBarPosChanged = function()
    -- upvalues: l_67_1 , l_67_0
    local l_68_0 = this:GetScrollPos()
    l_67_1(l_67_0:GetValue(l_68_0))
  end
end

  BoxCSlider.SetSize = function(l_68_0, l_68_1)
  l_68_0.hwnd:SetSize(l_68_1, 17)
  l_68_0.hwnd:Lookup("", ""):SetSize(l_68_1, 15)
  l_68_0.hwnd:Lookup("", "Image_Default"):SetSize(l_68_1, 11)
end

  BoxCSlider.UpdateScrollPos = function(l_69_0, l_69_1)
  l_69_0.hwnd:SetScrollPos(l_69_0:GetStep(l_69_1))
end

  BoxUICheckBox = classEx()
  BoxUICheckBox.ctor = function(l_70_0, l_70_1, l_70_2, l_70_3)
  -- upvalues: l_0_1
  local l_70_4 = "interface/Moon_Lib/ini/BoxUICheckBox.ini"
  l_70_0.hwnd = l_0_1(l_70_1, l_70_4, "CheckBox_Default", l_70_2)
  l_70_0.txt = l_70_0.hwnd:Lookup("", "Text_CheckBox")
  local l_70_5 = l_70_0.hwnd
  local l_70_6 = nil
  if not l_70_3 then
    l_70_6 = ""
  end
  l_70_5.group = l_70_6
end

  BoxUICheckBox.ui = function(l_71_0)
  return l_71_0.hwnd
end

  BoxUICheckBox.OnCheck = function(l_72_0, l_72_1)
  -- upvalues: l_0_2
  l_72_0.hwnd.OnCheckBoxCheck = function()
    -- upvalues: l_0_2 , l_72_1
    l_0_2(this)
    l_72_1()
  end
end

  BoxUICheckBox.UnCheck = function(l_73_0, l_73_1)
  l_73_0.hwnd.OnCheckBoxUncheck = l_73_1
end

  BoxUICheckBox.GetText = function(l_74_0)
  local l_74_1, l_74_2 = l_74_0.txt:GetText, l_74_0.txt
  return l_74_1(l_74_2)
end

  BoxUICheckBox.SetText = function(l_75_0, l_75_1)
  l_75_0.txt:SetText(l_75_1)
  local l_75_2 = l_75_0.txt:GetTextPosExtent()
  local l_75_3, l_75_4 = l_75_0.txt:GetTextExtent()
  local l_75_5, l_75_6 = l_75_0.hwnd:GetSize()
  l_75_0.hwnd:SetSize(l_75_3 + l_75_2 + 13, l_75_6)
  l_75_0.txt:SetSize(l_75_3 + l_75_2 + 13, l_75_6)
end

  BoxCheckBox = classEx()
  BoxCheckBox.ctor = function(l_76_0, l_76_1, l_76_2, l_76_3)
  -- upvalues: l_0_1
  if not l_76_3 then
    l_76_3 = {}
  end
  local l_76_4 = "interface/Moon_Lib/ini/BoxCheckBox.ini"
  l_76_0.hwnd = l_0_1(l_76_1, l_76_4, "CheckBox_Default", l_76_2)
  l_76_0.txt = l_76_0.hwnd:Lookup("", "Text_CheckBox")
  l_76_0.txt:SetText(l_76_3.txt or "")
  if l_76_3.x and l_76_3.y then
    l_76_0:SetRelPos(l_76_3.x, l_76_3.y)
  end
  if l_76_3.bchecked then
    l_76_0:Check(l_76_3.bcheck)
  end
end

  BoxCheckBox.SetBoolValue = function(l_77_0, l_77_1, l_77_2)
  l_77_0.tParent = l_77_1
  l_77_0.szBoolName = l_77_2
  if l_77_0.tParent and l_77_0.tParent[l_77_0.szBoolName] then
    l_77_0.hwnd:Check(true)
  end
end

  BoxCheckBox.ui = function(l_78_0)
  return l_78_0.hwnd
end

  BoxCheckBox.SetFontColor = function(l_79_0, ...)
  l_79_0.txt:SetFontColor(...)
end

  BoxCheckBox.SetFontScheme = function(l_80_0, ...)
  l_80_0.txt:SetFontScheme(...)
end

  BoxCheckBox.GetFontScheme = function(l_81_0)
  local l_81_1, l_81_2 = l_81_0.txt:GetFontScheme, l_81_0.txt
  return l_81_1(l_81_2)
end

  BoxCheckBox.GetFontColor = function(l_82_0)
  local l_82_1, l_82_2 = l_82_0.txt:GetFontColor, l_82_0.txt
  return l_82_1(l_82_2)
end

  BoxCheckBox.OnCheck = function(l_83_0, l_83_1)
  l_83_0.hwnd.OnCheckBoxCheck = function()
    -- upvalues: l_83_0 , l_83_1
    if l_83_0.tParent then
      l_83_0.tParent[l_83_0.szBoolName] = true
    end
    l_83_1()
  end
end

  BoxCheckBox.UnCheck = function(l_84_0, l_84_1)
  l_84_0.hwnd.OnCheckBoxUncheck = function()
    -- upvalues: l_84_0 , l_84_1
    if l_84_0.tParent then
      l_84_0.tParent[l_84_0.szBoolName] = false
    end
    l_84_1()
  end
end

  BoxCheckBox.GetText = function(l_85_0)
  local l_85_1, l_85_2 = l_85_0.txt:GetText, l_85_0.txt
  return l_85_1(l_85_2)
end

  BoxCheckBox.SetText = function(l_86_0, l_86_1)
  l_86_0.txt:SetText(l_86_1)
end

  BoxBoolCheckBox = classEx()
  BoxBoolCheckBox.ctor = function(l_87_0, l_87_1, l_87_2, l_87_3, l_87_4, l_87_5, l_87_6, l_87_7)
  -- upvalues: l_0_1
  local l_87_8 = "interface/Moon_Lib/ini/BoxCheckBox.ini"
  l_87_0.hwnd = l_0_1(l_87_1, l_87_8, "CheckBox_Default", l_87_2)
  l_87_0.txt = l_87_0.hwnd:Lookup("", "Text_CheckBox")
  local l_87_9, l_87_10 = l_87_0.txt:SetText, l_87_0.txt
  local l_87_11 = nil
  if not l_87_3 then
    l_87_11 = ""
  end
  l_87_9(l_87_10, l_87_11)
  if not l_87_4 then
    return 
  end
  l_87_9 = l_87_4[l_87_5]
  if l_87_9 then
    l_87_9 = l_87_0.hwnd
    l_87_9, l_87_10 = l_87_9:Check, l_87_9
    l_87_11 = true
    l_87_9(l_87_10, l_87_11)
  end
  l_87_9 = l_87_0.hwnd
  l_87_10 = function()
    -- upvalues: l_87_4 , l_87_5 , l_87_6
    l_87_4[l_87_5] = true
    if l_87_6 then
      l_87_6()
    end
  end
  l_87_9.OnCheckBoxCheck = l_87_10
  l_87_9 = l_87_0.hwnd
  l_87_10 = function()
    -- upvalues: l_87_4 , l_87_5 , l_87_7
    l_87_4[l_87_5] = false
    if l_87_7 then
      l_87_7()
    end
  end
  l_87_9.OnCheckBoxUncheck = l_87_10
end

  BoxBoolCheckBox.SetFontColor = function(l_88_0, ...)
  l_88_0.txt:SetFontColor(...)
end

  BoxBoolCheckBox.SetFontScheme = function(l_89_0, ...)
  l_89_0.txt:SetFontScheme(...)
end

  BoxBoolCheckBox.GetFontScheme = function(l_90_0)
  local l_90_1, l_90_2 = l_90_0.txt:GetFontScheme, l_90_0.txt
  return l_90_1(l_90_2)
end

  BoxBoolCheckBox.GetFontColor = function(l_91_0)
  local l_91_1, l_91_2 = l_91_0.txt:GetFontColor, l_91_0.txt
  return l_91_1(l_91_2)
end

  BoxBoolCheckBox.ui = function(l_92_0)
  return l_92_0.hwnd
end

  BoxRadioBox = classEx()
  BoxRadioBox.ctor = function(l_93_0, l_93_1, l_93_2, l_93_3)
  -- upvalues: l_0_1
  if not l_93_3 then
    l_93_3 = {}
  end
  local l_93_4 = "interface/Moon_Lib/ini/BoxRadioBox.ini"
  l_93_0.hwnd = l_0_1(l_93_1, l_93_4, "CheckBox_Default", l_93_2)
  l_93_0.hwnd.group = l_93_3.group
  l_93_0.txt = l_93_0.hwnd:Lookup("", "Text_CheckBox")
  l_93_0.txt:SetText(l_93_3.txt or "")
  if l_93_3.x and l_93_3.y then
    l_93_0:SetRelPos(l_93_3.x, l_93_3.y)
  end
  if l_93_3.bchecked then
    l_93_0:Check(l_93_3.bchecked)
  end
end

  BoxRadioBox.ui = function(l_94_0)
  return l_94_0.hwnd
end

  BoxRadioBox.OnCheck = function(l_95_0, l_95_1)
  -- upvalues: l_0_2
  l_95_0.hwnd.OnCheckBoxCheck = function()
    -- upvalues: l_0_2 , l_95_1
    l_0_2(this)
    l_95_1()
  end
end

  BoxRadioBox.UnCheck = function(l_96_0, l_96_1)
  l_96_0.hwnd.OnCheckBoxUncheck = l_96_1
end

  BoxRadioBox.SetText = function(l_97_0, l_97_1)
  l_97_0.txt:SetText(l_97_1)
end

  BoxRadioBox.GetText = function(l_98_0)
  local l_98_1, l_98_2 = l_98_0.txt:GetText, l_98_0.txt
  return l_98_1(l_98_2)
end

  BoxRadioBox.SetFontColor = function(l_99_0, ...)
  l_99_0.txt:SetFontColor(...)
end

  BoxRadioBox.SetFontScheme = function(l_100_0, ...)
  l_100_0.txt:SetFontScheme(...)
end

  BoxRadioBox.GetFontScheme = function(l_101_0)
  local l_101_1, l_101_2 = l_101_0.txt:GetFontScheme, l_101_0.txt
  return l_101_1(l_101_2)
end

  BoxRadioBox.GetFontColor = function(l_102_0)
  local l_102_1, l_102_2 = l_102_0.txt:GetFontColor, l_102_0.txt
  return l_102_1(l_102_2)
end

  BoxHandle = function(l_103_0, l_103_1, l_103_2, l_103_3, l_103_4)
  if not l_103_4 then
    l_103_4 = {}
  end
  local l_103_5 = ""
  if l_103_3 then
    l_103_5 = string.format(" w=%d h=%d", l_103_3[1], l_103_3[2])
  end
  local l_103_6 = " firstpostype=0"
  if l_103_4.firstpostype then
    l_103_6 = " firstpostype=" .. l_103_4.firstpostype
  end
  local l_103_7 = " handletype=0"
  if l_103_4.handletype then
    l_103_7 = " handletype=" .. l_103_4.handletype
  end
  local l_103_8 = ""
  if l_103_4.nEvent then
    l_103_8 = " eventid=" .. l_103_4.nEvent
  end
  local l_103_9 = ""
  if l_103_4.szScript then
    l_103_9 = " script=" .. EncodeComponentsString(l_103_4.szScript)
  end
  local l_103_10 = ""
  if l_103_1 then
    l_103_10 = " name=" .. EncodeComponentsString(l_103_1)
  end
  local l_103_11 = ""
  if l_103_2 then
    l_103_11 = string.format(" x=%d y=%d", l_103_2[1], l_103_2[2])
  end
  local l_103_15 = l_103_0:AppendItemFromString
  local l_103_16 = l_103_0
  local l_103_17 = "<handle>"
  local l_103_18 = l_103_7
  local l_103_19 = l_103_6
  local l_103_20 = l_103_10
  local l_103_21 = l_103_11
  local l_103_22 = l_103_5
  l_103_17 = l_103_17 .. l_103_18 .. l_103_19 .. l_103_20 .. l_103_21 .. l_103_22 .. l_103_8 .. l_103_9 .. "</handle>"
  l_103_15(l_103_16, l_103_17)
  l_103_15, l_103_16 = l_103_0:Lookup, l_103_0
  local l_103_12, l_103_13 = nil
  l_103_17 = l_103_1
  local l_103_14 = nil
  return l_103_15(l_103_16, l_103_17)
end

end
 -- WARNING: undefined locals caused missing assignments!

