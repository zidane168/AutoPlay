-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon_MailBank.lua 

local l_0_0 = {}
l_0_0.pageroom = 0
l_0_0.nRow = 7
l_0_0.nPageCount = 1
l_0_0.nCurrentPage = 1
l_0_0.GetMailInfoTime = 0
l_0_0.bMoneyMailFilter = false
Moon_MailBank = l_0_0
l_0_0 = Moon_MailBank
l_0_0.pageroom = Moon_MailBank.nRow * 14
l_0_0 = Moon_MailBank
l_0_0.mailItems = {}
l_0_0 = Moon_MailBank
l_0_0.showlist = {}
l_0_0 = Moon_MailBank
l_0_0.ReceiveList = {}
l_0_0 = RegisterCustomData
l_0_0("Moon_MailBank.mailItems")
l_0_0 = 0
Moon_MailBank.OnFrameCreate = function()
  local l_1_0 = this:Lookup("", "")
  l_1_0:Lookup("Text_Title"):SetText("�ʼ������ֿ�")
  l_1_0:Lookup("Text_2"):SetText("�а����ַ���")
  l_1_0:Lookup("Text_filt"):SetText("��Ʒ����")
  l_1_0:Lookup("Text_FilterTip"):SetText("ɸѡ������")
  this:Lookup("CheckBox_3", "Text_3"):SetText("����ʾ�����˻��ż�")
  this:BringToTop()
  if not Moon_MailBank.CheckMailNpc(true) then
    Moon_MailBank.format_all_item()
    Moon_MailBank.format_box()
  else
    Moon_MailBank.GetMailData()
  end
end

Moon_MailBank.OnFrameBreathe = function()
  -- upvalues: l_0_0
  local l_2_0 = GetTime()
  if Moon_MailBank.GetMailInfoTime and Moon_MailBank.GetMailInfoTime > 0 and Moon_MailBank.GetMailInfoTime + 500 + GetPingValue() <= l_2_0 then
    Moon_MailBank.GetMailInfoTime = 0
    Moon_MailBank.get_mail_item_data()
  end
  local l_2_1 = Station.Lookup("Normal/Moon_MailBank")
  local l_2_2 = l_2_1:Lookup("", "")
  local l_2_3 = l_2_2:Lookup("Text_Msg")
  local l_2_4 = l_2_3:GetAlpha()
  if l_2_4 > 0 and l_2_4 < 8 then
    l_2_4 = 8
  end
  if l_2_4 > 0 and l_2_0 - l_0_0 > 500 then
    l_2_3:SetAlpha(l_2_4 - 8)
  end
end

Moon_MailBank.GetMailData = function()
  local l_3_0 = GetClientPlayer()
  local l_3_1 = Moon_MailBank.CheckMailNpc(true)
  if not l_3_1 then
    return 
  end
  Moon_MailBank.OutputMsg("����ˢ�����丽�������Ժ򡭡�")
  if not GetMailClient().GetMailList("all") then
    local l_3_2, l_3_8, l_3_9 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_3_6 = 1, #l_3_2 do
    local l_3_3 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if not GetMailClient().GetMailInfo(l_3_3[R6_PC28]).bGotContentFlag or GetMailClient().GetMailInfo(l_3_3[R6_PC28]).bGotContentFlag == nil then
      GetMailClient().GetMailInfo(l_3_3[R6_PC28]).RequestContent(l_3_1)
    end
  end
  Moon_MailBank.GetMailInfoTime = GetTime()
  local l_3_10 = nil
  local l_3_11 = nil
  Station.Lookup("Normal/Moon_MailBank"):Lookup("", ""):Lookup("Text_Title"):SetText("���丽���ֿ�")
end

Moon_MailBank.filter_mail = function(l_4_0)
  local l_4_1 = Station.Lookup("Normal/Moon_MailBank")
  local l_4_2 = l_4_1:Lookup("", "")
  local l_4_3 = l_4_1:Lookup("CheckBox_3"):IsCheckBoxChecked()
  local l_4_4 = l_4_1:Lookup("Edit_KeyWords"):GetText()
  local l_4_5 = l_4_2:Lookup("Text_filt"):GetText()
  if not l_4_0 then
    return false
  end
  if l_4_0.GetType() == MAIL_TYPE.PLAYER and not l_4_0.bMoneyFlag then
    local l_4_6 = l_4_0.bItemFlag
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  do
    local l_4_7, l_4_8, l_4_10 = l_4_6
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_4_4 ~= "" then
    if l_4_5 == "�ż�����" then
      if string.find(l_4_0.szTitle, l_4_4) and (not l_4_3 or not l_4_7) then
        return true
      end
    else
      return false
    end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_4_5 == "������" then
    if string.find(l_4_0.szSenderName, l_4_4) and (not l_4_3 or not l_4_7) then
      return true
    else
      return false
    end
  elseif l_4_5 == "����ʱ��" then
    local l_4_9 = nil
    if not tonumber(l_4_4) then
      return true
    end
    if math.floor(l_4_0.GetLeftTime() / 86400) <= tonumber(l_4_4) and (not l_4_3 or not l_4_9) then
      return true
    end
  else
    return false
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_4_3 then
    if not l_4_9 then
      return true
    end
  else
    return false
  end
  return true
end

Moon_MailBank.get_mail_item_data = function()
  if Moon_MailBank.GetMailInfoTime > 0 then
    return 
  end
  local l_5_0 = Station.Lookup("Normal/Moon_MailBank")
  local l_5_1 = l_5_0:Lookup("", "")
  local l_5_2 = l_5_0:Lookup("Edit_KeyWords"):GetText()
  local l_5_3 = l_5_1:Lookup("Text_filt"):GetText()
  local l_5_4 = 0
  local l_5_6 = function(l_6_0)
    -- upvalues: l_5_3 , l_5_2
    if l_5_3 == "��Ʒ����" and l_5_2 ~= "" then
      if string.find(l_6_0, l_5_2) then
        return true
      end
    else
      return false
    end
    return true
  end
  local l_5_7 = {}
  do
    local l_5_8 = nil
    for l_5_12,l_5_13 in ipairs(GetMailClient().GetMailList("all")) do
      local l_5_9 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if not l_5_8.GetMailInfo(R13_PC38).bGotContentFlag or l_5_8.GetMailInfo(R13_PC38).bGotContentFlag == nil then
        local l_5_15 = nil
        if Moon_MailBank.CheckMailNpc() then
          Moon_MailBank.GetMailData()
        else
          Moon_MailBank.OutputMsg("��Ҫ������NPC������ִ��ˢ�£�")
          return 
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if Moon_MailBank.filter_mail(l_5_15) then
          if l_5_15.bGotContentFlag then
            l_5_15.Read()
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_5_15.nAllItemPrice and l_5_15.nAllItemPrice > 0 then
            l_5_4 = l_5_4 + 1
          end
        else
          for l_5_19 = 1, 8 do
            local l_5_16 = nil
             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_5_16.GetItem(R18_PC84 - 1) then
              local l_5_21 = nil
              local l_5_22 = l_5_16.GetItem(R18_PC84 - 1).nStackNum
              if l_5_21.nGenre == ITEM_GENRE.BOOK then
                local l_5_23, l_5_24 = l_5_21.szName, GlobelRecipeID2BookID(l_5_21.nBookID)
                l_5_23 = Table_GetSegmentName(l_5_24, R26_PC101)
                l_5_22 = l_5_21.nBookID
              end
               -- DECOMPILER ERROR: Confused about usage of registers!

            end
            if l_5_6(l_5_23) then
              local l_5_25 = nil
              local l_5_26 = table.insert
              local l_5_27 = l_5_7
              l_5_26(l_5_27, {stype = "item", name = l_5_25, mailid = l_5_14, mailindex = l_5_20 - 1, tabtype = l_5_21.dwTabType, tabindex = l_5_21.dwIndex, stacknum = l_5_22, npos = #l_5_7 + 1, item = l_5_21})
            end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

        end
        if l_5_16.nMoney ~= 0 and l_5_6("��Ǯ") then
          local l_5_28 = nil
          local l_5_29 = table.insert
          local l_5_30 = l_5_7
          l_5_29(l_5_30, {stype = "money", name = "��Ǯ", mailid = l_5_14, stacknum = l_5_28.nMoney, npos = #l_5_7 + 1})
        end
      end
      Moon_MailBank.mailItems = l_5_7
      Moon_MailBank.format_all_item()
      Moon_MailBank.format_box()
      if l_5_4 > 0 then
        Moon_MailBank.OutputMsg("��ʾ����" .. l_5_4 .. "���շ��ʼ�,�ʼ��ֿⲻ��ͳ���շѸ�����")
      else
        Moon_MailBank.OutputMsg("���丽��ˢ����ϣ�")
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
end

Moon_MailBank.GetTime = function(l_6_0)
  local l_6_1 = GetMailClient().GetMailInfo(l_6_0)
  local l_6_2 = l_6_1.GetLeftTime()
  local l_6_3 = ""
  if l_6_2 >= 86400 then
    local l_6_4 = math.floor(l_6_2 / 86400)
    if l_6_4 <= 6 then
      l_6_3 = FormatString(g_tStrings.STR_MAIL_LEFT_DAY, l_6_4)
    end
  else
    l_6_3 = "������"
  end
  return l_6_3
end

Moon_MailBank.format_all_item = function(l_7_0)
  Moon_MailBank.showlist = {}
  for l_7_4,l_7_5 in pairs(Moon_MailBank.mailItems) do
    if l_7_5.stype == "money" then
      if not Moon_MailBank.showlist[1] then
        local l_7_6 = Moon_MailBank.showlist
        local l_7_7 = {}
        l_7_7.stype = "money"
        l_7_7.name = l_7_5.name
        l_7_7.stacknum = 0
        l_7_7.data = {}
        l_7_6[1] = l_7_7
      end
      table.insert(Moon_MailBank.showlist[1].data, l_7_5)
      Moon_MailBank.showlist[1].stacknum = BigIntAdd(Moon_MailBank.showlist[1].stacknum, l_7_5.stacknum)
    end
  end
  local l_7_8, l_7_18 = {}
  l_7_18 = pairs
  l_7_18 = l_7_18(Moon_MailBank.mailItems)
  for l_7_12,l_7_13 in l_7_18 do
    local l_7_13 = nil
    l_7_13 = l_7_12.stype
    if l_7_13 ~= "money" then
      l_7_13 = l_7_12.name
      l_7_13 = l_7_8[l_7_13]
      if not l_7_13 then
        l_7_13 = Moon_MailBank
        l_7_13 = l_7_13.showlist
        l_7_13 = #l_7_13
        l_7_13 = l_7_13 + 1
        local l_7_14 = nil
        l_7_14 = Moon_MailBank
        l_7_14 = l_7_14.showlist
        local l_7_15 = nil
        local l_7_16 = nil
        l_7_16 = l_7_12.tabtype
        l_7_16 = l_7_12.tabindex
        l_7_16 = l_7_12.name
        l_7_16 = l_7_12.item
        l_7_16 = {}
        l_7_14[l_7_13], l_7_15 = l_7_15, {stype = "item", stacknum = 0, tabtype = l_7_16, tabindex = l_7_16, name = l_7_16, item = l_7_16, data = l_7_16}
        l_7_14 = l_7_12.name
        l_7_8[l_7_14] = l_7_13
      end
      l_7_13 = l_7_12.name
      l_7_13 = l_7_8[l_7_13]
      local l_7_17 = nil
      l_7_17 = table
      l_7_17 = l_7_17.insert
      l_7_17(Moon_MailBank.showlist[l_7_13].data, l_7_12)
      l_7_17 = l_7_12.item
      l_7_17 = l_7_17.bCanStack
      if not l_7_17 then
        l_7_17 = Moon_MailBank
        l_7_17 = l_7_17.showlist
        l_7_17 = l_7_17[l_7_13]
        l_7_17.stacknum = l_7_12.stacknum
      end
    else
      l_7_17 = Moon_MailBank
      l_7_17 = l_7_17.showlist
      l_7_17 = l_7_17[l_7_13]
      l_7_17.stacknum = Moon_MailBank.showlist[l_7_13].stacknum + l_7_12.stacknum
    end
  end
  Moon_MailBank.nPageCount = math.ceil(#Moon_MailBank.showlist / Moon_MailBank.pageroom)
  if Moon_MailBank.nPageCount == 0 then
    Moon_MailBank.nPageCount = 1
  end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_7_0 and Moon_MailBank.nPageCount < Moon_MailBank.nCurrentPage then
    Moon_MailBank.nCurrentPage = Moon_MailBank.nPageCount
  end
  do return end
  Moon_MailBank.nCurrentPage = 1
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  Moon_MailBank.InitPageText()
end

Moon_MailBank.format_box = function()
  local l_8_0 = Station.Lookup("Normal/Moon_MailBank")
  local l_8_1 = l_8_0:Lookup("", "")
  local l_8_2 = l_8_1:Lookup("Handle_Bg")
  local l_8_3 = l_8_1:Lookup("Handle_Box")
  l_8_2:Clear()
  l_8_3:Clear()
  local l_8_4 = Moon_MailBank.nCurrentPage
  local l_8_5 = Moon_MailBank.pageroom
  local l_8_6 = (l_8_4 - 1) * l_8_5 + 1
  local l_8_7 = (l_8_4 - 1) * l_8_5 + l_8_5
  for l_8_11 = l_8_6, l_8_7 do
    local l_8_12 = Moon_MailBank.showlist[l_8_11]
    if not l_8_12 then
      do return end
    end
    l_8_2:AppendItemFromString("<image>w=52 h=52 path=\"ui/Image/LootPanel/LootPanel.UITex\" frame=13 </image>")
    local l_8_13 = l_8_2:Lookup(l_8_2:GetItemCount() - 1)
    l_8_3:AppendItemFromString("<box>w=48 h=48 eventid=524607 </box>")
    local l_8_14 = l_8_3:Lookup(l_8_3:GetItemCount() - 1)
    local l_8_15 = (l_8_11 - 1) % 14 * 52
    local l_8_16 = (math.ceil((l_8_11 - l_8_5 * (l_8_4 - 1)) / 14) - 1) * 52
    l_8_13:SetRelPos(l_8_15, l_8_16)
    l_8_14:SetRelPos(l_8_15 + 2, l_8_16 + 2)
    l_8_14:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
    l_8_14:SetOverTextFontScheme(0, 15)
    l_8_14:SetOverTextPosition(1, 2)
    l_8_14:SetOverTextFontScheme(1, 14)
    for l_8_20,l_8_21 in pairs(l_8_12.data) do
      do
        local l_8_22 = GetMailClient().GetMailInfo(l_8_21.mailid)
        if l_8_22 and l_8_22.GetLeftTime() < 86400 and (l_8_22.GetType() ~= MAIL_TYPE.PLAYER or l_8_22.bMoneyFlag or not l_8_22.bItemFlag) then
          l_8_14:SetOverText(1, "������")
        end
        do break end
      end
    end
    if l_8_12.stype == "money" then
      l_8_14.bMoney = true
      l_8_14.info = l_8_12
      l_8_14:SetObject(UI_OBJECT_NOT_NEED_KNOWN, 0)
      l_8_14:SetObjectIcon(582)
    else
      l_8_14.bItemBox = true
      l_8_14.info = l_8_12
      local l_8_23, l_8_24 = GetItemInfo(l_8_12.tabtype, l_8_12.tabindex)
      l_8_24(l_8_14, UI_OBJECT_ITEM_INFO, 1, l_8_12.tabtype, l_8_12.tabindex, l_8_12.stacknum)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_8_24(l_8_14, Table_GetItemIconID(l_8_12.item.nUiId))
       -- DECOMPILER ERROR: Overwrote pending register.

      l_8_24(l_8_14, l_8_23)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_8_24(l_8_14, 0, ITEM_POSITION.RIGHT_BOTTOM)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_8_24(l_8_14, 0, 15)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_8_24 == 1 then
        l_8_24(l_8_14, 0, "")
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if not l_8_24 then
        if l_8_24 == 1 then
          l_8_24(l_8_14, 0, "")
        end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_8_24(l_8_14, 0, #l_8_12.data)
      end
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_8_24(l_8_14, 0, l_8_12.stacknum)
    end
  end
  l_8_2:FormatAllItemPos()
  l_8_3:FormatAllItemPos()
end

Moon_MailBank.OnLButtonClick = function()
  local l_9_0 = this:GetName()
  if l_9_0 == "Btn_filt" then
    if this.bIgnore then
      this.bIgnore = nil
      return 
    end
    if not this:IsEnabled() then
      return 
    end
    local l_9_1 = this:GetParent():Lookup("", "Text_filt")
    local l_9_2, l_9_3 = l_9_1:GetAbsPos()
    local l_9_4, l_9_5 = l_9_1:GetSize()
    local l_9_6 = {}
    l_9_6.nMiniWidth = l_9_4
    l_9_6.x = l_9_2
    l_9_6.y = l_9_3 + l_9_5
    l_9_6.fnCancelAction = function()
      local l_10_0 = Station.Lookup("Normal/Moon_MailBank/Btn_filt")
      if l_10_0 then
        local l_10_1, l_10_2 = Cursor.GetPos()
        local l_10_3, l_10_4 = l_10_0:GetAbsPos()
      end
      if l_10_3 <= l_10_1 and l_10_1 < l_10_3 + l_10_0:GetSize() and l_10_4 <= l_10_2 and l_10_2 <= l_10_4 + l_10_0 then
        l_10_0.bIgnore = true
      end
    end
    l_9_6.fnAction = function(l_11_0, l_11_1)
      local l_11_2 = Station.Lookup("Normal/Moon_MailBank")
      if l_11_2 then
        local l_11_3 = l_11_2:Lookup("", "Text_filt")
        local l_11_4 = l_11_2:Lookup("", "")
        if l_11_0[1] == "����ʱ��" then
          l_11_4:Lookup("Text_2"):SetText("���ڣ��죩��")
        else
          l_11_4:Lookup("Text_2"):SetText("�а����ַ���")
        end
        l_11_3:SetText(l_11_0[1])
        l_11_3.bEnable = true
      end
    end
    local l_9_7 = table.insert
    local l_9_8 = l_9_6
    local l_9_9 = {}
    l_9_9.szOption = "��Ʒ����"
    local l_9_10 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_9_7(l_9_8, l_9_9)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_10 = {"��Ʒ����"}
    l_9_7(l_9_8, l_9_9)
    l_9_9 = {szOption = "�ż�����", UserData = l_9_10}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_10 = {"������"}
    l_9_7(l_9_8, l_9_9)
    l_9_9 = {szOption = "������", UserData = l_9_10}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_10 = {"����ʱ��"}
    l_9_7(l_9_8, l_9_9)
    l_9_9 = {szOption = "����ʱ��", UserData = l_9_10}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_7(l_9_8)
     -- DECOMPILER ERROR: Overwrote pending register.

    return l_9_7
  elseif l_9_0 == "Btn_Refresh" then
    if Moon_MailBank.GetMailInfoTime > 0 then
      OutputMessage("MSG_ANNOUNCE_RED", "���丽������ˢ����")
      return 
    end
    if not Moon_MailBank.CheckMailNpc(true) then
      return 
    end
    Moon_MailBank.GetMailData()
  elseif l_9_0 == "Btn_Close" then
    Moon_MailBank.ClosePanel()
  elseif l_9_0 == "Btn_PageNext" then
    if Moon_MailBank.nCurrentPage < Moon_MailBank.nPageCount then
      Moon_MailBank.nCurrentPage = Moon_MailBank.nCurrentPage + 1
    end
    Moon_MailBank.InitPageText()
    Moon_MailBank.format_box()
  elseif l_9_0 == "Btn_PagePrev" then
    if Moon_MailBank.nCurrentPage > 1 then
      Moon_MailBank.nCurrentPage = Moon_MailBank.nCurrentPage - 1
    end
    Moon_MailBank.InitPageText()
    Moon_MailBank.format_box()
  end
end

Moon_MailBank.InitPageText = function()
  local l_10_0 = Station.Lookup("Normal/Moon_MailBank")
  local l_10_1 = l_10_0:Lookup("", "")
  local l_10_2 = l_10_1:Lookup("Text_PageNum")
  l_10_2:SetText(Moon_MailBank.nCurrentPage .. "/" .. Moon_MailBank.nPageCount)
  local l_10_3 = l_10_0:Lookup("Btn_PagePrev")
  local l_10_4 = l_10_0:Lookup("Btn_PageNext")
  l_10_3:Enable(true)
  l_10_4:Enable(true)
  if Moon_MailBank.nCurrentPage == 1 then
    l_10_3:Enable(false)
  end
  if Moon_MailBank.nCurrentPage == Moon_MailBank.nPageCount then
    l_10_4:Enable(false)
  end
end

Moon_MailBank.OnItemRefreshTip = function()
  Moon_MailBank.OnItemMouseEnter()
end

Moon_MailBank.OnItemMouseEnter = function()
  this:SetObjectMouseOver(1)
  local l_12_0, l_12_1 = this:GetAbsPos()
  local l_12_2, l_12_3 = this:GetSize()
  if IsAltKeyDown() then
    if this.bItemBox then
      local l_12_4, l_12_5, l_12_6, l_12_7 = this:GetObjectData()
      local l_12_8 = OutputItemTip
      local l_12_9 = UI_OBJECT_ITEM_INFO
      local l_12_10 = l_12_4
      local l_12_11 = l_12_5
      local l_12_12 = l_12_6
      local l_12_13 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_12_8(l_12_9, l_12_10, l_12_11, l_12_12, l_12_13, l_12_0, l_12_1, l_12_2, l_12_3, l_12_7)
    else
      if this.bMoney then
        local l_12_14 = this.info.stacknum
        local l_12_15 = "<text>text=" .. EncodeComponentsString(g_tStrings.STR_MAIL_HAVE_MONEY) .. "</text>" .. GetMoneyTipText(l_12_14, 106)
        local l_12_16 = OutputTip
        local l_12_17 = l_12_15
        local l_12_18 = 300
        local l_12_19 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_12_16(l_12_17, l_12_18, l_12_19)
      end
    end
  else
    local l_12_20 = ""
    local l_12_21 = ""
    local l_12_22 = this.info
    if this.bItemBox then
      local l_12_23 = GetItemInfo(l_12_22.tabtype, l_12_22.tabindex)
      local l_12_24 = GetItemFontColorByQuality(l_12_23.nQuality, true)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_12_21 = "<Text>text=" .. EncodeComponentsString(l_12_1 .. l_12_2 .. l_12_3) .. " font=101 " .. l_12_24 .. " </text>"
    else
      l_12_21 = "<text>text=" .. EncodeComponentsString(g_tStrings.STR_MAIL_HAVE_MONEY) .. "</text>" .. GetMoneyTipText(l_12_22.stacknum, 106) .. GetFormatText("\n", 166)
    end
    l_12_20 = l_12_20 .. l_12_21
    local l_12_25 = {}
    for l_12_29,l_12_30 in pairs(l_12_22.data) do
      local l_12_31 = table.insert
      local l_12_32 = l_12_25
      local l_12_33 = {}
      l_12_33.mailid = l_12_30.mailid
      l_12_33.nstacknum = l_12_30.stacknum
      l_12_31(l_12_32, l_12_33)
    end
    local l_12_34, l_12_58 = {}
    l_12_58 = 0
    local l_12_35, l_12_59 = nil
    l_12_35 = pairs
    l_12_59 = l_12_25
    l_12_35 = l_12_35(l_12_59)
    for l_12_39,l_12_40 in l_12_35 do
      local l_12_39, l_12_40 = nil
      l_12_39 = l_12_38.mailid
      l_12_39 = l_12_34[l_12_39]
      if not l_12_39 then
        l_12_39 = l_12_38.mailid
        l_12_34[l_12_39] = 0
        l_12_58 = l_12_58 + 1
      end
      l_12_39 = this
      l_12_39 = l_12_39.bItemBox
      if l_12_39 then
        l_12_39 = l_12_22.item
        l_12_39 = l_12_39.bCanStack
      end
      if not l_12_39 then
        l_12_39 = l_12_38.mailid
        local l_12_41 = nil
        l_12_40 = l_12_38.mailid
        l_12_40 = l_12_34[l_12_40]
        l_12_40 = l_12_40 + 1
        l_12_34[l_12_39] = l_12_40
      else
        l_12_39 = l_12_38.mailid
        local l_12_42 = nil
        l_12_40 = l_12_38.mailid
        l_12_40 = l_12_34[l_12_40]
        l_12_42 = l_12_38.nstacknum
        l_12_40 = l_12_40 + l_12_42
        l_12_34[l_12_39] = l_12_40
      end
    end
    local l_12_43, l_12_60 = nil
    for l_12_47,l_12_48 in pairs(l_12_43) do
      local l_12_46, l_12_47, l_12_48 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      do
        local l_12_49 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if not l_12_46 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_47 == l_12_48 and not l_12_47 then
          local l_12_50 = nil
        end
         -- DECOMPILER ERROR: Overwrote pending register.

        do
          local l_12_51 = nil
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_12_52, l_12_53 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_47 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_12_54 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_12_55 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_12_56 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_54 >= 86400 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_54 >= 3600 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_54 >= 60 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        do
          local l_12_57 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_12_47 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

      end
       -- DECOMPILER ERROR: unhandled construct in 'if'

      if 0 + 1 == 7 and 0 + 1 < l_12_58 then
        do break end
      end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_12_61 = nil
    local l_12_62 = nil
    local l_12_63 = l_12_46
    do
      local l_12_64 = l_12_47
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    OutputTip(l_12_20, 345, {l_12_62, l_12_63, l_12_64, l_12_48})
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

Moon_MailBank.OnItemRButtonClick = function()
  if not this.bItemBox and not this.bMoney then
    return 
  end
  if not Moon_MailBank.CheckMailNpc(true) then
    return 
  end
  local l_13_0 = this.info.data
  local l_13_1 = GetItemInfo(this.info.tabtype, this.info.tabindex)
  local l_13_2 = {}
  if this.bItemBox then
    local l_13_3 = table.insert
    local l_13_4 = l_13_2
    local l_13_5 = {}
    l_13_5.szOption = "��ȡȫ��"
    l_13_5.fnAction = function()
      -- upvalues: l_13_0
      Moon_MailBank.Receive(l_13_0)
    end
    l_13_3(l_13_4, l_13_5)
    l_13_3 = table
    l_13_3 = l_13_3.insert
    l_13_4 = l_13_2
    l_13_3(l_13_4, l_13_5)
    l_13_5 = {bDevide = true}
    l_13_3 = GetMailClient
    l_13_3 = l_13_3()
    l_13_4 = ipairs
    l_13_5 = l_13_0
    l_13_4 = l_13_4(l_13_5)
    for i_1,i_2 in l_13_4 do
      do
        local l_13_9 = l_13_3.GetMailInfo(l_13_8.mailid)
        local l_13_10 = Moon_MailBank.GetTime(l_13_8.mailid)
        local l_13_11 = string.format("[%s]", l_13_9.szTitle)
        if l_13_10 ~= "" then
          l_13_11 = l_13_11 .. string.format("(%s)", l_13_10)
        end
        if l_13_1.nGenre ~= ITEM_GENRE.BOOK and l_13_1.nGenre ~= ITEM_GENRE.EQUIPMENT then
          l_13_11 = string.format("%s  ������%s", l_13_11, tostring(l_13_8.stacknum))
        end
        local l_13_12 = table.insert
        local l_13_13 = l_13_2
        local l_13_14 = {}
        l_13_14.szOption = l_13_11
        l_13_14.fnAction = function()
          -- upvalues: l_13_8
          Moon_MailBank.Receive(l_13_8, true)
        end
        l_13_12(l_13_13, l_13_14)
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    do break end
  end
  l_13_3 = this
  l_13_3 = l_13_3.bMoney
  if l_13_3 then
    l_13_3 = table
    l_13_3 = l_13_3.insert
    local l_13_15 = nil
    local l_13_16 = nil
    local l_13_17 = nil
    l_13_3(l_13_2, l_13_15)
    l_13_15 = {szOption = "��ȡȫ��", fnAction = l_13_16}
    l_13_3 = GetMailClient
    l_13_3 = l_13_3()
    for l_13_17,i_2 in ipairs(l_13_15) do
      local l_13_19, l_13_20 = nil
      l_13_19 = l_13_3.GetMailInfo
      l_13_20 = l_13_18.mailid
      l_13_19 = l_13_19(l_13_20)
      local l_13_21 = nil
      l_13_20 = string
      l_13_20 = l_13_20.format
      l_13_21 = "[%s]"
      l_13_20 = l_13_20(l_13_21, l_13_19.szTitle)
      local l_13_22 = nil
      l_13_21 = Moon_MailBank
      l_13_21 = l_13_21.GetTime
      l_13_22 = l_13_18.mailid
      l_13_21 = l_13_21(l_13_22)
      local l_13_23 = nil
      if l_13_21 ~= "" then
        l_13_22 = l_13_20
        l_13_23 = string
        l_13_23 = l_13_23.format
        l_13_23 = l_13_23("(%s)", l_13_21)
        l_13_20 = l_13_22 .. l_13_23
      end
      l_13_22 = MoneyToGoldSilverAndCopper
      l_13_23 = l_13_18.stacknum
      l_13_22 = l_13_22(l_13_23)
      local l_13_24, l_13_25, l_13_26 = nil
      l_13_25 = ""
      local l_13_27 = nil
      if l_13_22 > 0 then
        l_13_26 = l_13_25
        l_13_27 = string
        l_13_27 = l_13_27.format
        l_13_27 = l_13_27("%s��", tostring(l_13_22))
        l_13_25 = l_13_26 .. l_13_27
      end
      if l_13_23 > 0 then
        l_13_26 = l_13_25
        l_13_27 = string
        l_13_27 = l_13_27.format
        l_13_27 = l_13_27("%s��", tostring(R20_PC169), R20_PC169)
        l_13_25 = l_13_26 .. l_13_27
      end
      if l_13_25 ~= "" then
        l_13_26 = l_13_20
        l_13_27 = "  "
        l_13_20 = l_13_26 .. l_13_27 .. l_13_25
      end
      l_13_26 = table
      l_13_26 = l_13_26.insert
      local l_13_28 = nil
      l_13_27 = l_13_2
      local l_13_29 = nil
      local l_13_30 = R20_PC169
      l_13_29 = function()
        -- upvalues: l_13_8
        Moon_MailBank.Receive(l_13_8, true, true)
      end
      l_13_26(l_13_27, l_13_28)
      l_13_28 = {szOption = l_13_20, fnAction = l_13_29}
    end
  end
  l_13_3 = PopupMenu
  l_13_3(l_13_2)
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

Moon_MailBank.OnItemLButtonClick = function()
  if not this.bItemBox and not this.bMoney then
    return 
  end
  if IsCtrlKeyDown() and this.bItemBox then
    local l_14_0, l_14_1, l_14_2, l_14_3 = this:GetObjectData()
    EditBox_AppendLinkItemInfo(l_14_0, l_14_1, l_14_2, l_14_3)
    return 
  end
  if not Moon_MailBank.CheckMailNpc(true) then
    return 
  end
  local l_14_4 = this.info.data
  if this.bMoney then
    Moon_MailBank.Receive(l_14_4, nil, true)
  else
    if this.bItemBox then
      Moon_MailBank.Receive(l_14_4, nil, false)
    end
  end
end

Moon_MailBank.Receive = function(l_15_0, l_15_1, l_15_2)
  local l_15_3 = GetClientPlayer()
  if not l_15_2 then
    local l_15_4, l_15_5 = nil, nil
    local l_15_6 = 0
    if l_15_1 then
      l_15_4 = l_15_0.tabtype
      l_15_6 = 1
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_15_4 = l_15_0[1].tabtype
      l_15_6 = #l_15_0
    end
    local l_15_7 = GetItemInfo(l_15_4, l_15_5)
  end
  if l_15_7.nMaxExistAmount ~= 0 and l_15_7.nMaxExistAmount <= l_15_3.GetItemAmount(l_15_4, l_15_5) then
    Moon_MailBank.OutputMsg("�޷���ӵ�и���ĸ���Ʒ��")
    return 
  end
  if l_15_1 then
    local l_15_8 = table.insert
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_15_9 = l_15_5.ReceiveList
    do
      local l_15_10 = {}
      l_15_10.data = l_15_0
      l_15_10.bMoney = l_15_2
      l_15_8(l_15_9, l_15_10)
    end
    do break end
  end
  for l_15_14,l_15_15 in pairs(l_15_0) do
    local l_15_16 = table.insert
    local l_15_17 = Moon_MailBank.ReceiveList
    local l_15_18 = {}
    l_15_18.data = l_15_15
    l_15_18.bMoney = l_15_2
    l_15_16(l_15_17, l_15_18)
  end
end

local l_0_1 = function()
  local l_16_0 = Station.Lookup("Normal/MailPanel/PageSet_Total/Page_Receive")
  if not l_16_0 or l_16_0:Lookup("Btn_Receive") then
    return 
  end
  local l_16_1 = BoxButton
  local l_16_2 = l_16_0
  local l_16_3 = "Btn_Receive"
  local l_16_4 = {}
  l_16_4.x = 50
  l_16_4.y = 10
  l_16_4.txt = "�ʼ��ֿ�"
  l_16_1 = l_16_1(l_16_2, l_16_3, l_16_4)
  l_16_2, l_16_3 = l_16_1:SetAnimateGroup, l_16_1
  l_16_4 = 56
  l_16_2(l_16_3, l_16_4, 57, 58, 55)
  l_16_2 = l_16_1.hwnd
  l_16_2, l_16_3 = l_16_2:SetSize, l_16_2
  l_16_4 = 100
  l_16_2(l_16_3, l_16_4, 35)
  l_16_2, l_16_3 = l_16_1:OnClick, l_16_1
  l_16_4 = function()
    if Moon_MailBank.IsPanelOpened() then
      Moon_MailBank.ClosePanel()
    else
      Moon_MailBank.OpenPanel()
    end
  end
  l_16_2(l_16_3, l_16_4)
  l_16_2, l_16_3 = l_16_0:Lookup, l_16_0
  l_16_4 = ""
  l_16_2 = l_16_2(l_16_3, l_16_4, "")
  l_16_3, l_16_4 = l_16_2:Lookup, l_16_2
  l_16_3 = l_16_3(l_16_4, "Image_Loot")
  if not l_16_3 then
    l_16_3, l_16_4 = l_16_2:AppendItemFromString, l_16_2
    l_16_3(l_16_4, "<image>path=\"ui/Image/UICommon/CommonPanel.UITex\" name=\"Image_Loot\" alpha=200\tw=35 h=35 eventid=272 frame=76 </image>")
    l_16_3, l_16_4 = l_16_2:Lookup, l_16_2
    l_16_3 = l_16_3(l_16_4, "Image_Loot")
    l_16_4(l_16_3, 695, 390)
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_3.OnItemMouseEnter = l_16_4
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_3.OnItemLButtonClick = l_16_4
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_3.OnItemMouseLeave = l_16_4
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_4(l_16_2)
  end
end

local l_0_2 = 0
local l_0_3 = 0
local l_0_4 = 0
RegisterEvent("Breathe", function()
  -- upvalues: l_0_1 , l_0_2 , l_0_4
  l_0_1()
  local l_17_0 = GetTime()
  if #Moon_MailBank.ReceiveList > 0 then
    local l_17_1 = Moon_MailBank.CheckMailNpc(true)
    if not l_17_1 or l_17_0 - l_0_2 < 100 then
      return 
    end
    l_0_2 = l_17_0
    local l_17_2 = Moon_MailBank.ReceiveList[1]
    local l_17_3 = GetMailClient().GetMailInfo(l_17_2.data.mailid)
    if l_17_3 and not l_17_2.bMoney and l_17_3 and l_17_3.GetItem(l_17_2.data.mailindex) then
      l_17_3.TakeItem(l_17_2.data.mailindex)
      Moon_MailBank.mailItems[l_17_2.data.npos] = nil
      Moon_MailBank.OutputMsg("��ȡ[" .. l_17_3.szSenderName .. "]���͵�[" .. l_17_3.szTitle .. "]�е�[" .. l_17_2.data.name .. "]")
    end
    do return end
    if l_17_3 and l_17_3.nMoney then
      l_17_3.TakeMoney()
      Moon_MailBank.mailItems[l_17_2.data.npos] = nil
      Moon_MailBank.OutputMsg("��ȡ[" .. l_17_3.szSenderName .. "]���͵�[" .. l_17_3.szTitle .. "]�еĽ�Ǯ")
    end
    table.remove(Moon_MailBank.ReceiveList, 1)
  end
  if table.getn(Moon_MailBank.ReceiveList) == 0 then
    l_0_4 = l_17_0 + 400
  end
  if l_0_4 > 0 and l_0_4 < l_17_0 then
    l_0_4 = 0
    Moon_MailBank.format_all_item(true)
    Moon_MailBank.format_box()
  end
end
)
Moon_MailBank.OnItemMouseLeave = function()
  HideTip()
  this:SetObjectMouseOver(0)
end

Moon_MailBank.OnFrameKeyDown = function()
  if GetKeyName(Station.GetMessageKey()) == "Esc" then
    local l_19_0 = Station.Lookup("Normal/Moon_MailBank")
    l_19_0:Hide()
    return 1
  end
end

Moon_MailBank.ClosePanel = function()
  local l_20_0 = Station.Lookup("Normal/Moon_MailBank")
  if l_20_0 and l_20_0:IsVisible() then
    l_20_0:Hide()
  end
end

Moon_MailBank.OnCheckBoxCheck = function()
  local l_21_1 = nil
  local l_21_0 = Moon_MailBank.get_mail_item_data
  return l_21_0()
end

Moon_MailBank.OpenPanel = function()
  local l_22_0 = Station.Lookup("Normal/Moon_MailBank")
  if l_22_0 then
    l_22_0:Show()
    l_22_0:BringToTop()
  else
    Wnd.OpenWindow("interface\\Moon_MailBank\\Moon_MailBank.ini", "Moon_MailBank")
  end
end

Moon_MailBank.IsPanelOpened = function()
  local l_23_0 = Station.Lookup("Normal/Moon_MailBank")
  if l_23_0 and l_23_0:IsVisible() then
    return true
  end
  return false
end

Moon_MailBank.ClosePanel = function()
  local l_24_0 = Station.Lookup("Normal/Moon_MailBank")
  if l_24_0 and l_24_0:IsVisible() then
    l_24_0:Hide()
  end
end

Moon_MailBank.OutputMsg = function(l_25_0)
  -- upvalues: l_0_0
  local l_25_1 = Station.Lookup("Normal/Moon_MailBank")
  if l_25_1 then
    local l_25_2 = l_25_1:Lookup("", "")
    local l_25_3 = l_25_2:Lookup("Text_Msg")
    l_25_3:SetAlpha(255)
    l_25_3:SetText(tostring(l_25_0))
    l_0_0 = GetTime()
  end
end

Moon_MailBank.OnCheckBoxUncheck = function()
  local l_26_1 = nil
  local l_26_0 = Moon_MailBank.get_mail_item_data
  return l_26_0()
end

Moon_MailBank.OnEditChanged = function()
  local l_27_0 = Station.Lookup("Normal/Moon_MailBank")
  local l_27_1 = l_27_0:Lookup("Edit_KeyWords"):GetText()
  local l_27_2 = l_27_0:Lookup("", "Text_Title")
  if l_27_1 == "" then
    l_27_2:SetText("�ʼ������ֿ�")
  else
    local l_27_4 = l_27_2:SetText
    local l_27_5 = l_27_2
    l_27_4(l_27_5, "�ʼ������ֿ⣨������")
  end
  local l_27_3 = Moon_MailBank.get_mail_item_data
  return l_27_3()
end

Hotkey.AddBinding("MoonMailBank", "�ʼ��ֿ�", "����ֿ�", function()
  if Moon_MailBank.IsPanelOpened() then
    Moon_MailBank.ClosePanel()
  else
    Moon_MailBank.OpenPanel()
  end
end
, nil)
GetBigBagFreeSize = function()
  local l_29_0 = GetClientPlayer()
  local l_29_1 = 0
  for l_29_5 = 1, BIGBAGCOUNT do
    local l_29_6 = BagIndexToInventoryIndex(l_29_5)
    local l_29_7 = l_29_0.GetBoxSize(l_29_6)
    if l_29_7 and l_29_7 ~= 0 then
      l_29_1 = l_29_1 + l_29_0.GetBoxFreeRoomSize(l_29_6)
    end
  end
  return l_29_1
end

Moon_MailBank.GetTheMailItems = function(l_30_0)
  if not l_30_0.dwSelID then
    return 
  end
  local l_30_1 = {}
  local l_30_2 = GetMailClient().GetMailInfo(l_30_0.dwSelID)
  if not l_30_2 then
    return 
  end
  for l_30_6 = 1, 8 do
    local l_30_7 = l_30_0:Lookup("Box_Item0" .. l_30_6)
    do
      local l_30_8 = l_30_2.GetItem(l_30_6 - 1)
      if l_30_8 then
        table.insert(l_30_1, l_30_6 - 1)
      end
    end
  end
  if l_30_2.nMoney ~= 0 then
    l_30_2.TakeMoney()
  end
  local l_30_9 = GetBigBagFreeSize()
  if l_30_9 < #l_30_1 then
    Msg("�ﱳ��λ�ò�����")
    do break end
  end
  for l_30_13,l_30_14 in pairs(l_30_1) do
    DelayCall(0.2 * l_30_13, function()
      -- upvalues: l_30_2 , l_30_8
      l_30_2.TakeItem(l_30_8)
    end)
  end
end

local l_0_5 = 0
RegisterEvent("OPEN_WINDOW", function()
  -- upvalues: l_0_5
  local l_31_0 = arg0
  local l_31_1 = arg1
  local l_31_2 = arg2
  local l_31_3 = arg3
  if not IsPlayer(l_31_3) then
    return 
  end
  local l_31_4 = Station.Lookup("Normal/DialoguePanel")
  if not l_31_4 then
    return 
  end
  local l_31_5 = l_31_4.aInfo
  for l_31_9,l_31_10 in pairs(l_31_5) do
    if l_31_10.name == "L" then
      l_0_5 = l_31_3
    end
  end
end
)
RegisterEvent("NPC_LEAVE_SCENE", function()
  -- upvalues: l_0_5
  if l_0_5 ~= 0 and arg0 == l_0_5 then
    l_0_5 = 0
  end
end
)
Moon_MailBank.GetMailNpcID = function()
  -- upvalues: l_0_5
  local l_33_0 = nil
  if l_0_5 ~= 0 then
    do break end
  end
  if not GetAllNpc() then
    local l_33_1, l_33_2 = Station.Lookup("Normal/MailPanel"), {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_33_6,l_33_7 in pairs(l_33_2) do
    local l_33_3, l_33_4 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

    if StringFindW(R7_PC19.szTitle, "��ʹ") or StringFindW(R7_PC19.szName, "��ʹ") then
      do break end
    end
  end
  return l_33_0
end

Moon_MailBank.CheckMailNpc = function(l_34_0)
  local l_34_1 = Moon_MailBank.GetMailNpcID()
  if not l_34_1 then
    if l_34_0 then
      Moon_MailBank.OutputMsg("�޷��������Ҳ����ʼ�NPC��")
    end
    return false
  end
  local l_34_2 = GetNpc(l_34_1)
  if Moon_Lib.GetDistance(GetClientPlayer(), l_34_2) > 4.5 then
    if l_34_0 then
      Moon_MailBank.OutputMsg("�޷������������ʼ�NPC̫Զ��")
    end
    return false
  end
  return l_34_1
end


