-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: xCDhelperAnchor.lua 

xCDhelperAnchor = {bDragable = false, 
Anchor = {s = "CENTER", r = "CENTER", x = 0, y = 0}}
RegisterCustomData("xCDhelperAnchor.Anchor")
xCDhelperAnchor.OnFrameCreate = function()
  this:RegisterEvent("UI_SCALED")
end

xCDhelperAnchor.OnEvent = function(event)
  if event == "UI_SCALED" then
    xCDhelperAnchor.UpdateAnchor(this)
    xCDhelperAnchor.UpdateDrag()
    FireEvent("seBuffTimerAnchorChanged")
  end
end

xCDhelperAnchor.OnFrameDrag = function()
end

xCDhelperAnchor.UpdateDrag = function()
end

xCDhelperAnchor.OnFrameDragSetPosEnd = function()
  this:CorrectPos()
  xCDhelperAnchor.Anchor = GetFrameAnchor(this)
  FireEvent("xCDhelperAnchorChanged")
end

xCDhelperAnchor.OnFrameDragEnd = function()
  this:CorrectPos()
  xCDhelperAnchor.Anchor = GetFrameAnchor(this)
  FireEvent("xCDhelperAnchorChanged")
end

xCDhelperAnchor.UpdateAnchor = function(frame)
  local anchor = xCDhelperAnchor.Anchor
  frame:SetPoint(anchor.s, 0, 0, anchor.r, anchor.x, anchor.y)
  frame:CorrectPos()
end

Wnd.OpenWindow("interface\\xHelp\\xCDhelperAnchor.ini", "xCDhelperAnchor")

