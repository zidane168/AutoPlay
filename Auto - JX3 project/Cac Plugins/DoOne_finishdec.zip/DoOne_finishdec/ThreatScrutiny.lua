-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ThreatScrutiny.lua 

local l_0_0 = {}
l_0_0.nSteper = -1
l_0_0.frameSelf = nil
l_0_0.handleMain = nil
l_0_0.handleImages = nil
l_0_0.handleThreatBar = nil
l_0_0.handleThreatBar = nil
l_0_0.handleTargetInfo = nil
l_0_0.handleCombatTarget = nil
l_0_0.bFocusTargetLocked = false
l_0_0.dwFocusTargetID = 0
l_0_0.dwLastFocusTargetID = 0
l_0_0.bCastAlertFlag = false
l_0_0.bSelfTreatRank = 0
l_0_0.tOptions = {}
l_0_0.bOn = false
local l_0_1 = {}
l_0_1.x = -306
l_0_1.y = 40
l_0_1.s = "TOPRIGHT"
l_0_1.r = "TOPRIGHT"
l_0_0.Anchor = l_0_1
l_0_0.bLockPanel = false
l_0_0.nBGAlpha = 40
l_0_0.szThreatPercentAccuracy = "%.0f%%"
l_0_0.bShowThreatPercent = false
l_0_0.bShowThreatbalancePercent = true
l_0_0.bShowThreatAnykindPercent = false
l_0_0.bHideThreatPercent = false
l_0_0.nMaxBarCount = 5
l_0_0.bForceColor = true
l_0_0.bShowScrutinyDist = true
l_0_0.bShowHPPercent = true
l_0_0.bFoucsPartyTarget = true
l_0_0.szCastAlertRelation = "Enemy"
l_0_0.szCastAlertCharType = "All"
l_0_0.nCastAlertIntensity = 5
l_0_0.nCastAlertChannel = -1
l_0_0.nOTAlertLevel = 1
l_0_0.bOTAlertSound = true
l_0_0.ShowInPart = true
l_0_0.ShowinMiji = true
l_0_0.ShowEnd = false
ThreatScrutiny = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bLockPanel"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.nBGAlpha"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.szThreatPercentAccuracy"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bShowThreatPercent"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bShowThreatbalancePercent"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bShowThreatAnykindPercent"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bHideThreatPercent"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.nMaxBarCount"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bForceColor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bShowScrutinyDist"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bShowHPPercent"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bFoucsPartyTarget"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.szCastAlertRelation"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.szCastAlertCharType"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.nCastAlertIntensity"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.nCastAlertChannel"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.nOTAlertLevel"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.bOTAlertSound"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.ShowInPart"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.ShowinMiji"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.ShowEnd"
l_0_0(l_0_1)
l_0_0 = ThreatScrutiny
l_0_1 = function()
  this:RegisterEvent("CHARACTER_THREAT_RANKLIST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_2_0 = GetClientPlayer()
  if not l_2_0 then
    return 
  end
  if not ThreatScrutiny.bOn then
    return 
  end
  local l_2_1 = Station.Lookup("Normal/ThreatScrutiny")
  if ThreatScrutiny.canShow() then
    l_2_1:Show()
  else
    l_2_1:Hide()
    return 
  end
  ThreatScrutiny.nSteper = ThreatScrutiny.nSteper + 1
  local l_2_2 = GetTargetHandle(l_2_0.GetTarget())
  if l_2_2 then
    if not IsPlayer(l_2_2.dwID) then
      ApplyCharacterThreatRankList(l_2_2.dwID)
    else
      local l_2_3, l_2_4 = l_2_2.GetTarget()
      if l_2_4 ~= 0 and l_2_3 == TARGET.NPC then
        ApplyCharacterThreatRankList(l_2_4)
      end
    else
      ThreatScrutiny.UpdateThreatBars()
      ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
    end
  else
    if ThreatScrutiny.bFocusTargetLocked and not IsPlayer(ThreatScrutiny.dwFocusTargetID) and ThreatScrutiny.dwFocusTargetID and ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID) and ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID).nX then
      ApplyCharacterThreatRankList(ThreatScrutiny.dwFocusTargetID)
    end
  end
  do return end
  ThreatScrutiny.UpdateThreatBars()
  ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  ThreatScrutiny.UpdateTargetInfo()
  if ThreatScrutiny.dwLastFocusTargetID ~= ThreatScrutiny.dwFocusTargetID then
    ThreatScrutiny.bSelfTreatRank = 0
  end
  ThreatScrutiny.dwLastFocusTargetID = ThreatScrutiny.dwFocusTargetID
end

l_0_0.OnFrameBreathe = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function(l_3_0)
  do
    if l_3_0 == "CHARACTER_THREAT_RANKLIST" then
      local l_3_1 = GetClientPlayer()
      if not l_3_1 then
        return 
      end
      ThreatScrutiny.UpdateThreatBars(arg0, arg1)
  end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_3_0 == "SYS_MSG" and arg0 == "UI_OME_DEATH_NOTIFY" and arg1 == ThreatScrutiny.dwFocusTargetID then
    ThreatScrutiny.UpdateThreatBars()
  end
  do return end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_3_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    ThreatScrutiny.UpdateAnchor(this)
    this:Lookup("CheckBox_ScrutinyLock"):Check(false)
    this:EnableDrag(not ThreatScrutiny.bLockPanel)
    ThreatScrutiny.SetBGAlpha()
  end
  do return end
  if l_3_0 == "UI_SCALED" then
    ThreatScrutiny.UpdateAnchor(this)
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  this:CorrectPos()
  ThreatScrutiny.Anchor = GetFrameAnchor(this)
end

l_0_0.OnFrameDragEnd = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function(l_5_0)
  l_5_0:SetPoint(ThreatScrutiny.Anchor.s, 0, 0, ThreatScrutiny.Anchor.r, ThreatScrutiny.Anchor.x, ThreatScrutiny.Anchor.y)
  l_5_0:CorrectPos()
end

l_0_0.UpdateAnchor = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_6_0 = this:GetName()
  if l_6_0 == "Image_Options" then
    this:SetAlpha(255)
    local l_6_1, l_6_2 = Cursor.GetPos()
    local l_6_3 = "�����ͳ�ơ�" .. "\n" .. "* ����������˴������á�" .. "\n"
    local l_6_4 = OutputTip
    local l_6_5 = "<Text>text=" .. EncodeComponentsString(l_6_3) .. " font=100 </text>"
    local l_6_6 = 1000
    local l_6_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_6_4(l_6_5, l_6_6, l_6_7)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.OnItemMouseEnter = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_7_0 = this:GetName()
  if l_7_0 == "Image_Options" then
    this:SetAlpha(200)
    HideTip()
  end
end

l_0_0.OnItemMouseLeave = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  ThreatScrutiny.bFocusTargetLocked = true
  ThreatScrutiny.handleImages:Lookup("Image_ScrutinyLock"):Show()
end

l_0_0.OnCheckBoxCheck = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  ThreatScrutiny.bFocusTargetLocked = false
  ThreatScrutiny.handleImages:Lookup("Image_ScrutinyLock"):Hide()
end

l_0_0.OnCheckBoxUncheck = l_0_1
l_0_0 = 0
l_0_1 = ThreatScrutiny
l_0_1.OnItemLButtonDown = function()
  -- upvalues: l_0_0
  l_0_0 = ThreatScrutiny.nSteper
end

l_0_1 = ThreatScrutiny
l_0_1.OnItemLButtonClick = function()
  -- upvalues: l_0_0
  local l_11_0 = this:GetName()
  if l_11_0 == "Image_Options" then
    ThreatScrutiny.PopOptions()
  elseif l_11_0 == "Text_TargetName" and ThreatScrutiny.nSteper - l_0_0 < 4 and ThreatScrutiny.dwFocusTargetID and ThreatScrutiny.dwFocusTargetID > 0 then
    Moon_Lib.SetTarget(ThreatScrutiny.dwFocusTargetID)
  end
end

l_0_1 = ThreatScrutiny
l_0_1.InitThreatBars = function(l_12_0, l_12_1)
  if not l_12_0 then
    l_12_0 = 30
  end
  if not l_12_1 then
    l_12_1 = 35
  end
  ThreatScrutiny.tForceIconList = {}
  ThreatScrutiny.handleThreatBar:Clear()
  local l_12_2 = "Interface/Moon_ThreatScrutiny/ThreatScrutiny.ini"
  for l_12_6 = 1, l_12_0 do
    local l_12_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Image_Treat_Pad_A", "Image_Treat_Pad_A_" .. l_12_6):Hide()
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_12_7[1]:SetRelPos(ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Image_Treat_Bar_White", "Image_Treat_Bar_White_" .. l_12_6), ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Image_Treat_Bar_Green", "Image_Treat_Bar_Green_" .. l_12_6) * 24)
    l_12_7[2]:Hide()
    l_12_7[2]:SetRelPos(160, (l_12_6 - 1) * 24 + 3)
    l_12_7[3]:Hide()
    l_12_7[3]:SetRelPos(3, (l_12_6 - 1) * 24 + 3)
    l_12_7[4]:Hide()
    l_12_7[4]:SetRelPos(3, (l_12_6 - 1) * 24 + 3)
    l_12_7[5]:Hide()
    l_12_7[5]:SetRelPos(3, (l_12_6 - 1) * 24 + 3)
    l_12_7[6]:Hide()
    l_12_7[6]:SetRelPos(3, (l_12_6 - 1) * 24 + 3)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_12_8 = ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Text_ThreatName", ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Image_Treat_Bar_Yellow", "Image_Treat_Bar_Yellow_" .. l_12_6) .. ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Image_Treat_Bar_Red", "Image_Treat_Bar_Red_" .. l_12_6))
    l_12_8:SetAlpha(200)
    l_12_8:Hide()
    l_12_8:SetRelPos(20, (l_12_6 - 1) * 24 + 3)
    l_12_8:SetText("û��Ŀ��")
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_12_9 = ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_12_2, "Text_ThreatValue", "Text_ThreatValue_" .. .end)
    l_12_9:SetAlpha(200)
    l_12_9:Hide()
    l_12_9:SetRelPos(115, (l_12_6 - 1) * 24 + 3)
    l_12_9:SetText("100%")
  end
  ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  ThreatScrutiny.handleImages:Lookup("Image_Background"):SetSize(208, 90)
  ThreatScrutiny.handleThreatBar:FormatAllItemPos()
end

l_0_1 = ThreatScrutiny
l_0_1.UpdateThreatBars = function(l_13_0, l_13_1)
  local l_13_2 = ThreatScrutiny.GetCharacter(l_13_0)
  local l_13_3 = 0
  if l_13_2 and l_13_2.nX then
    _ = l_13_2.GetTarget()
  end
  local l_13_4 = {}
  if l_13_1 then
    for l_13_8,l_13_9 in pairs(l_13_1) do
      if l_13_3 == l_13_8 then
        local l_13_10 = table.insert
        local l_13_11 = l_13_4
        local l_13_12 = 1
        local l_13_13 = {}
        l_13_13.key = l_13_8
        l_13_13.value = l_13_9
        l_13_10(l_13_11, l_13_12, l_13_13)
      else
        local l_13_14 = table.insert
        local l_13_15 = l_13_4
        local l_13_16 = {}
        l_13_16.key = l_13_8
        l_13_16.value = l_13_9
        l_13_14(l_13_15, l_13_16)
      end
    end
  end
  local l_13_17 = false
  if not IsEmpty(l_13_4) and l_13_4[1] then
    local l_13_18 = 1
    l_13_17 = l_13_3 == l_13_4[1].key
    if l_13_17 then
      ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Show()
      l_13_18 = 2
    else
      ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
    end
    for l_13_22 = l_13_18, #l_13_4 do
      for l_13_26 = l_13_22 + 1, #l_13_4 do
        if l_13_4[l_13_22].value < l_13_4[l_13_26].value then
          local l_13_27 = l_13_4[l_13_26]
          l_13_4[l_13_26] = l_13_4[l_13_22]
          l_13_4[l_13_22] = l_13_27
        end
      end
    end
  else
    ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  end
  ThreatScrutiny.handleImages:Lookup("Image_Background"):SetSize(208, 90 + 24 * math.min(#l_13_4, ThreatScrutiny.nMaxBarCount))
  local l_13_28 = {}
  if ThreatScrutiny.ShowEnd and ThreatScrutiny.nMaxBarCount < #l_13_4 then
    local l_13_29 = math.floor(ThreatScrutiny.nMaxBarCount / 2)
    local l_13_30 = ThreatScrutiny.nMaxBarCount - l_13_29
    for l_13_34 = 1, l_13_30 do
      l_13_28[l_13_34] = l_13_4[l_13_34]
    end
    for l_13_38 = 1, l_13_29 do
      local l_13_39 = l_13_30 + l_13_38
      l_13_28[l_13_39] = l_13_4[#l_13_4 - l_13_29 + l_13_38]
    end
  else
    l_13_28 = l_13_4
  end
  for l_13_43 = 1, 30 do
    local l_13_44 = ThreatScrutiny.handleThreatBar:Lookup("Text_ThreatName_" .. l_13_43)
    local l_13_45 = ThreatScrutiny.handleThreatBar:Lookup("Text_ThreatValue_" .. l_13_43)
    local l_13_46 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    if ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Pad_A_" .. l_13_43) and l_13_43 <= ThreatScrutiny.nMaxBarCount then
      local l_13_47 = l_13_28[l_13_43].key
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_13_48 = ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Pad_B_" .. l_13_43).value
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_13_49 = ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_White_" .. l_13_43).GetCharacter(ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Green_" .. l_13_43))
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_13_50 = "[" .. ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Yellow_" .. l_13_43) .. ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Red_" .. l_13_43)
      local l_13_51 = ""
      local l_13_52 = 6
       -- DECOMPILER ERROR: Overwrote pending register.

      if (not l_13_49 or l_13_48 > 0.01) and .end and l_13_28[1].value and l_13_28[1].value > 0.01 then
        if ThreatScrutiny.bShowThreatbalancePercent then
          l_13_51 = ThreatScrutiny.szThreatPercentAccuracy:format(100 * l_13_48 / l_13_28[1].value)
        end
      else
        if ThreatScrutiny.bShowThreatPercent then
          l_13_51 = ThreatScrutiny.szThreatPercentAccuracy:format(l_13_48 / 655.35)
        end
      else
        if ThreatScrutiny.bShowThreatAnykindPercent then
          l_13_51 = ThreatScrutiny.szThreatPercentAccuracy:format(l_13_48 / 655.35) .. " / " .. ThreatScrutiny.szThreatPercentAccuracy:format(100 * l_13_48 / l_13_4[1].value)
        end
      end
      local l_13_53 = 255
      local l_13_54 = 255
      local l_13_55 = 0
      if ThreatScrutiny.bForceColor then
        l_13_53 = ThreatScrutiny.GetCharacterColor(l_13_47)
      end
      l_13_46[1]:Show()
      l_13_46[2]:Show()
      l_13_44:SetText(l_13_50)
      l_13_44:SetFontColor(l_13_53, l_13_54, l_13_55)
      l_13_44:Show()
      l_13_45:SetText(l_13_51)
      l_13_45:SetFontColor(l_13_53, l_13_54, l_13_55)
      l_13_45:Show()
      local l_13_56 = l_13_48 / l_13_28[1].value
      local l_13_57 = l_13_56 * 0.80645161290323
      if GetClientPlayer().dwID == l_13_47 then
        if ThreatScrutiny.nOTAlertLevel >= 0 and l_13_17 and l_13_3 ~= GetClientPlayer().dwID and ThreatScrutiny.bSelfTreatRank < ThreatScrutiny.nOTAlertLevel and ThreatScrutiny.nOTAlertLevel <= l_13_56 then
          OutputMessage("MSG_ANNOUNCE_YELLOW", "**��%s������ĳ�޳����� %.1f��, �ﵽ 120�� ��ϣԣ�**":format(l_13_2.szName, ThreatScrutiny.nOTAlertLevel * 100))
        end
        if ThreatScrutiny.bOTAlertSound then
          PlaySound(1, "data\\sound\\����\\view\\nat_view2.wav")
        end
        ThreatScrutiny.bSelfTreatRank = l_13_56
      end
      l_13_46[3]:Hide()
      l_13_46[4]:Hide()
      l_13_46[5]:Hide()
      l_13_46[6]:Hide()
      if l_13_57 >= 0.83 then
        l_13_46[6]:Show()
        l_13_46[6]:SetPercentage(l_13_57)
      elseif l_13_57 >= 0.54 then
        l_13_46[5]:Show()
        l_13_46[5]:SetPercentage(l_13_57)
      elseif l_13_57 >= 0.3 then
        l_13_46[4]:Show()
        l_13_46[4]:SetPercentage(l_13_57)
      elseif l_13_57 >= 0.01 then
        l_13_46[3]:Show()
        l_13_46[3]:SetPercentage(l_13_57)
      end
    else
      l_13_44:Hide()
      l_13_45:Hide()
      l_13_46[1]:Hide()
      l_13_46[2]:Hide()
      l_13_46[3]:Hide()
      l_13_46[4]:Hide()
      l_13_46[5]:Hide()
      l_13_46[6]:Hide()
    end
    ThreatScrutiny.handleImages:FormatAllItemPos()
  end
end

l_0_1 = function(l_14_0)
  if l_14_0 > 100000000 then
    return "%.1f":format(l_14_0 / 100000000) .. "��"
  elseif l_14_0 > 100000 then
    return "%d":format(l_14_0 / 10000) .. "��"
  elseif l_14_0 > 100000 then
    local l_14_3 = "%.1f":format
    l_14_3 = l_14_3("%.1f", l_14_0 / 10000)
    l_14_3 = l_14_3 .. "��"
    return l_14_3
  else
    local l_14_1 = tostring
    local l_14_2 = l_14_0
    return l_14_1(l_14_2)
  end
end

ThreatScrutiny.UpdateTargetInfo = function()
  -- upvalues: l_0_1
  local l_15_0 = GetClientPlayer()
  if not l_15_0 then
    return 
  end
  local l_15_1, l_15_2 = l_15_0.GetTarget()
  if l_15_1 > 1 and not ThreatScrutiny.bFocusTargetLocked then
    ThreatScrutiny.dwFocusTargetID = l_15_2
  end
  local l_15_3 = ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID)
  local l_15_4 = false
  if IsPlayer(ThreatScrutiny.dwFocusTargetID) then
    l_15_4 = IsPlayerExist(ThreatScrutiny.dwFocusTargetID)
  else
    l_15_4 = IsNpcExist(ThreatScrutiny.dwFocusTargetID)
  end
  if ThreatScrutiny.bFoucsPartyTarget and l_15_0.IsPlayerInMyParty(ThreatScrutiny.dwFocusTargetID) and l_15_3 and l_15_3.nX then
    local l_15_5, l_15_6 = l_15_3.GetTarget()
  end
  if l_15_5 > 1 and l_15_6 ~= l_15_0.dwID and not l_15_0.IsPlayerInMyParty(l_15_6) then
    ThreatScrutiny.dwFocusTargetID = l_15_6
    l_15_3 = ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID)
  end
  local l_15_7 = "???? (??��)"
  local l_15_8 = "???? / ???? (?? %)"
  local l_15_9 = "???? / ????"
  local l_15_10 = 1
  local l_15_11 = 1
  local l_15_12 = ""
  local l_15_13 = false
  local l_15_14 = 0
  local l_15_15 = 1
  local l_15_16 = 0
  local l_15_17 = 0
  local l_15_18 = 255
  local l_15_19 = 0
  if not ThreatScrutiny.bShowScrutinyDist then
    l_15_7 = "????"
  end
  if not ThreatScrutiny.bShowHPPercent then
    l_15_8 = "???? / ????"
  end
  if l_15_3 then
    l_15_10 = l_15_3.nCurrentLife / l_15_3.nMaxLife
    l_15_7 = l_15_3.szName
    if IsCtrlKeyDown() then
      l_15_7 = l_15_7 .. " (" .. l_15_3.dwID .. ")"
    else
      if ThreatScrutiny.bShowScrutinyDist and l_15_4 then
        l_15_7 = l_15_7 .. " (%.1f��)":format(math.floor(l_15_0.nX - l_15_3.nX ^ 2 + l_15_0.nY - l_15_3.nY ^ 2 + l_15_0.nZ / 8 - l_15_3.nZ / 8 ^ 2 ^ 0.5) / 64)
      end
    end
    local l_15_20 = l_0_1(l_15_3.nMaxLife)
    local l_15_21 = l_0_1(l_15_3.nCurrentLife)
    local l_15_22 = l_0_1(l_15_3.nMaxMana)
    local l_15_23 = l_0_1(l_15_3.nCurrentMana)
    if ThreatScrutiny.bShowHPPercent then
      l_15_8 = "%s / %s (%.1f%%)":format(l_15_21, l_15_20, l_15_10 * 100)
    else
      l_15_8 = "%s / %s":format(l_15_21, l_15_20)
    end
    if l_15_0.IsPlayerInMyParty(l_15_3.dwID) or ThreatScrutiny.dwFocusTargetID == l_15_2 then
      l_15_11 = l_15_3.nCurrentMana / l_15_3.nMaxMana
      l_15_9 = "%s / %s":format(l_15_23, l_15_22)
    else
      l_15_9 = "???? / %s":format(l_15_22)
    end
    if l_15_4 then
      l_15_17 = GetHeadTextForceFontColor(l_15_0.dwID, l_15_3.dwID)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_15_17, l_15_18, l_15_19)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_15_17, l_15_18, l_15_19)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
      l_15_13 = l_15_3.GetSkillPrepareState()
      l_15_12 = Table_GetSkillName(l_15_14, l_15_15)
      if not ThreatScrutiny.bCastAlertFlag and l_15_13 and ThreatScrutiny.nCastAlertChannel >= 0 and l_15_12 and l_15_12 ~= "" then
        local l_15_24 = {}
        local l_15_25 = {}
        l_15_25.type = "text"
        l_15_25.text = "�� [" .. l_15_3.szName .. "]��ʼ����: " .. l_15_12 .. "��"
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_15_25 = l_15_0.IsInParty
        l_15_25 = l_15_25()
      end
      if l_15_25 then
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.szCastAlertRelation
        if l_15_25 ~= "All" then
          l_15_25 = ThreatScrutiny
          l_15_25 = l_15_25.szCastAlertRelation
          if l_15_25 == "Enemy" then
            l_15_25 = IsEnemy
            l_15_25 = l_15_25(l_15_0.dwID, l_15_3.dwID)
          end
        if not l_15_25 then
          end
        end
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.szCastAlertRelation
      end
      if l_15_25 == "Friendly" then
        l_15_25 = IsEnemy
        l_15_25 = l_15_25(l_15_0.dwID, l_15_3.dwID)
      end
      if not l_15_25 then
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.szCastAlertCharType
        if l_15_25 ~= "All" then
          l_15_25 = ThreatScrutiny
          l_15_25 = l_15_25.szCastAlertCharType
          if l_15_25 == "Player" then
            l_15_25 = IsPlayer
            l_15_25 = l_15_25(l_15_3.dwID)
          end
        if not l_15_25 then
          end
        end
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.szCastAlertCharType
      end
      if l_15_25 == "Npc" then
        l_15_25 = IsPlayer
        l_15_25 = l_15_25(l_15_3.dwID)
      end
      if not l_15_25 then
        l_15_25 = IsPlayer
        l_15_25 = l_15_25(l_15_3.dwID)
        if not l_15_25 then
          l_15_25 = ThreatScrutiny
          l_15_25 = l_15_25.nCastAlertIntensity
        end
        if l_15_25 ~= 1 then
          l_15_25 = ThreatScrutiny
          l_15_25 = l_15_25.nCastAlertIntensity
          if l_15_25 == 2 then
            l_15_25 = l_15_3.nIntensity
          end
          if l_15_25 ~= 1 then
            l_15_25 = l_15_3.nIntensity
          end
          if l_15_25 ~= 3 then
            l_15_25 = l_15_3.nIntensity
          end
        if l_15_25 <= 6 then
          end
        end
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.nCastAlertIntensity
        if l_15_25 == 3 then
          l_15_25 = l_15_3.nIntensity
        if l_15_25 ~= 4 then
          end
        end
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.nCastAlertIntensity
        if l_15_25 == 4 then
          l_15_25 = l_15_3.nIntensity
        if l_15_25 ~= 5 then
          end
        end
        l_15_25 = ThreatScrutiny
        l_15_25 = l_15_25.nCastAlertIntensity
      end
      if l_15_25 == 5 then
        l_15_25 = l_15_3.nIntensity
        if l_15_25 ~= 2 then
          l_15_25 = l_15_3.nIntensity
        end
      if l_15_25 == 6 then
        end
      end
      l_15_25 = l_15_0.Talk
      l_15_25(PLAYER_TALK_CHANNEL.RAID, "", l_15_24)
    else
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_15_17, l_15_18, l_15_19)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_15_17, l_15_18, l_15_19)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
    end
  else
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_15_17, l_15_18, l_15_19)
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_15_17, l_15_18, l_15_19)
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
    ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(false)
  end
  if l_15_17 == 0 and l_15_18 >= 255 and l_15_19 == 0 then
    ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Show()
  elseif l_15_17 == 0 and l_15_18 == 200 and l_15_19 == 72 then
    ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Show()
  elseif l_15_17 >= 255 and l_15_18 == 0 and l_15_19 == 0 then
    ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Show()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Hide()
  else
    ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Show()
    ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Hide()
  end
  ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetText(l_15_7)
  ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetText(l_15_8)
  ThreatScrutiny.handleImages:Lookup("Image_Life_Bar"):SetPercentage(l_15_10)
  ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetText(l_15_9)
  ThreatScrutiny.handleImages:Lookup("Image_Mana_Bar"):SetPercentage(l_15_11)
  ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetCast"):SetText(l_15_12)
  ThreatScrutiny.handleImages:Lookup("Image_Cast_Bar"):SetPercentage(l_15_16)
  ThreatScrutiny.bCastAlertFlag = l_15_13
  if ThreatScrutiny.bCastAlertFlag then
    ThreatScrutiny.handleImages:Lookup("Animate_Cast_Flash"):Show()
  else
    ThreatScrutiny.handleImages:Lookup("Animate_Cast_Flash"):Hide()
  end
end

ThreatScrutiny.GetCharacterColor = function(l_16_0)
  local l_16_1 = GetClientPlayer()
  if not l_16_1 then
    return 128, 128, 128
  end
  if not IsPlayer(l_16_0) then
    return 220, 220, 220
  end
  local l_16_2 = ThreatScrutiny.GetCharacter(l_16_0)
  if not l_16_2 then
    return 128, 128, 128
  end
  local l_16_3 = l_16_2.dwForceID
  if not l_16_3 then
    return 220, 220, 220
  end
  local l_16_4 = GetForceTitle(l_16_3)
  local l_16_5 = {}
  local l_16_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_16_5["���"], l_16_6 = l_16_6, {255, 255, 255}
  l_16_5["��"], l_16_6 = l_16_6, {196, 152, 255}
  l_16_5["����"], l_16_6 = l_16_6, {89, 224, 232}
  l_16_5["����"], l_16_6 = l_16_6, {255, 129, 176}
  l_16_5["����"], l_16_6 = l_16_6, {255, 178, 95}
  l_16_5["�ؽ�"], l_16_6 = l_16_6, {214, 249, 93}
  l_16_5["�嶾"], l_16_6 = l_16_6, {55, 147, 255}
  l_16_5["����"], l_16_6 = l_16_6, {121, 183, 54}
  l_16_5["����"], l_16_6 = l_16_6, {240, 70, 96}
  l_16_5["ؤ��"], l_16_6 = l_16_6, {205, 133, 63}
  l_16_6 = l_16_5[l_16_4]
  if l_16_6 then
    l_16_6 = l_16_5[l_16_4]
    l_16_6 = l_16_6[1]
    return l_16_6, l_16_5[l_16_4][2], l_16_5[l_16_4][3]
  end
  l_16_6 = 220
  return l_16_6, 220, 220
end

ThreatScrutiny.GetCharacter = function(l_17_0)
  if IsPlayer(l_17_0) then
    local l_17_1 = GetPlayer(l_17_0)
    if not l_17_1 then
      local l_17_2 = GetClientPlayer()
      if not l_17_2 then
        return 
      end
      local l_17_3, l_17_13 = GetClientTeam()
    end
    if l_17_3 then
      l_17_13 = l_17_3.GetMemberGroupIndex
      l_17_13 = l_17_13(l_17_2.dwID)
      local l_17_4, l_17_14 = nil
    end
    if l_17_13 and l_17_13 >= 0 then
      l_17_4 = l_17_3.GetGroupInfo
      l_17_14 = l_17_13
      l_17_4 = l_17_4(l_17_14)
      local l_17_5, l_17_15 = nil
      l_17_14 = pairs
      l_17_5 = l_17_4.MemberList
      l_17_14 = l_17_14(l_17_5)
      for l_17_9,l_17_10 in l_17_14 do
        local l_17_8, l_17_9, l_17_10 = nil
        do
          if l_17_0 == l_17_7 then
            local l_17_16, l_17_17, l_17_18, l_17_19, l_17_20 = nil
          end
          l_17_8 = l_17_3.GetMemberInfo
          l_17_9 = l_17_0
          local l_17_22 = nil
          l_17_8 = l_17_8(l_17_9)
          local l_17_21 = nil
          l_17_1 = l_17_8
        end
        do break end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    return l_17_1
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  else
    l_17_1 = GetNpc
    local l_17_11 = nil
    l_17_2 = l_17_0
    do
      local l_17_12 = nil
      return l_17_1(l_17_2)
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

ThreatScrutiny.Message = function(l_18_0, l_18_1)
  OutputMessage("MSG_SYS", "[ThreatScrutiny] " .. tostring(l_18_1) .. "\n")
end

ThreatScrutiny.OpenPanel = function()
  if not Station.Lookup("Normal/ThreatScrutiny") then
    local l_19_0, l_19_1, l_19_2, l_19_3, l_19_4, l_19_5, l_19_6, l_19_7, l_19_8, l_19_9, l_19_10, l_19_11, l_19_12, l_19_13 = Wnd.OpenWindow("Interface\\Moon_ThreatScrutiny\\ThreatScrutiny.ini", "ThreatScrutiny")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_19_0:Hide()
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.frameSelf = l_19_0
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleMain = l_19_0:Lookup("", "")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleImages = l_19_0:Lookup("", "Handle_Images")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleThreatBar = l_19_0:Lookup("", "Handle_ThreatBar")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleTargetInfo = l_19_0:Lookup("", "Handle_TargetInfo")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleCombatTarget = l_19_0:Lookup("", "Handle_CombatTarget")
  ThreatScrutiny.InitThreatBars()
end

ThreatScrutiny.OpenPanel()

