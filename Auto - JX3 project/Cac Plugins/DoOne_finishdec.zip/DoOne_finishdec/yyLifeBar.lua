-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: yyLifeBar.lua 

yyLifeBar = {}
yyLifeBar.nSteper = -1
yyLifeBar.tLifeBarList = {}
yyLifeBar.tDoodadList = {}
yyLifeBar.tSortedVisibleLifeBarList = {}
yyLifeBar.bShowDoodad = true
RegisterCustomData("yyLifeBar.bShowDoodad")
yyLifeBar.bShowEnemy = true
RegisterCustomData("yyLifeBar.bShowEnemy")
yyLifeBar.bShowAlly = true
RegisterCustomData("yyLifeBar.bShowAlly")
yyLifeBar.bShowTNpc = true
RegisterCustomData("yyLifeBar.bShowTNpc")
yyLifeBar.bShowLevel = false
RegisterCustomData("yyLifeBar.bShowLevel")
yyLifeBar.bShowLife = true
RegisterCustomData("yyLifeBar.bShowLife")
yyLifeBar.bShowNpc = true
RegisterCustomData("yyLifeBar.bShowNpc")
yyLifeBar.bShowPlayer = true
RegisterCustomData("yyLifeBar.bShowPlayer")
yyLifeBar.bOnlyParty = false
RegisterCustomData("yyLifeBar.bOnlyParty")
yyLifeBar.bForceColorName = true
RegisterCustomData("yyLifeBar.bForceColorName")
yyLifeBar.bShowTitle = false
RegisterCustomData("yyLifeBar.bShowTitle")
yyLifeBar.bShowDistance = true
RegisterCustomData("yyLifeBar.bShowDistance")
yyLifeBar.bPartyColor = false
RegisterCustomData("yyLifeBar.bPartyColor")
yyLifeBar.biForce = true
RegisterCustomData("yyLifeBar.biForce")
yyLifeBar.bShowSelf = true
RegisterCustomData("yyLifeBar.bShowSelf")
yyLifeBar.bReplaceTopHeadEx = true
RegisterCustomData("yyLifeBar.bReplaceTopHeadEx")
yyLifeBar.bShowLifeBar = true
RegisterCustomData("yyLifeBar.bShowLifeBar")
yyLifeBar.bShowCastingBar = true
RegisterCustomData("yyLifeBar.bShowCastingBar")
yyLifeBar.bSelectedBarMode = true
RegisterCustomData("yyLifeBar.bSelectedBarMode")
yyLifeBar.bShowName = true
RegisterCustomData("yyLifeBar.bShowName")
yyLifeBar.bAutoSort = true
RegisterCustomData("yyLifeBar.bAutoSort")
yyLifeBar.nRange = 35
RegisterCustomData("yyLifeBar.nRange")
yyLifeBar.nRangeMax = 150
yyLifeBar.nAllowMember = 80
RegisterCustomData("yyLifeBar.nAllowMember")
yyLifeBar.nAllowMemberMax = 200
yyLifeBar.bLastMouseVisibleState = nil
yyLifeBar.OnFrameCreate = function()
  this:RegisterEvent("RENDER_FRAME_UPDATE")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("PLAYER_ENTER_SCENE")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("PLAYER_LEAVE_SCENE")
  this:RegisterEvent("DOODAD_ENTER_SCENE")
  this:RegisterEvent("DOODAD_LEAVE_SCENE")
end

yyLifeBar.OnEvent = function(szEvent)
  if szEvent == "RENDER_FRAME_UPDATE" then
    yyLifeBar.RefreshLifeBarDisplay()
    yyLifeBar.CheckMouseVisibleState()
  elseif szEvent == "NPC_ENTER_SCENE" or szEvent == "PLAYER_ENTER_SCENE" or szEvent == "DOODAD_ENTER_SCENE" then
    yyLifeBar.CreateLifeBar(arg0)
  elseif szEvent == "NPC_LEAVE_SCENE" or szEvent == "PLAYER_LEAVE_SCENE" or szEvent == "DOODAD_LEAVE_SCENE" then
    yyLifeBar.RemoveLifeBar(arg0)
  end
end

yyLifeBar.OnFrameBreathe = function()
  yyLifeBar.nSteper = yyLifeBar.nSteper + 1
  local player = GetClientPlayer()
  if not player then
    return 
  end
  yyLifeBar.SortVisibleFrameByDistance()
end

GetDoodadList = function()
  return tDoodadList
end

GetDoodaddwID = function(szDoodadName)
  for k,v in pairs(GetDoodadList()) do
    local Doodad = GetDoodad(v)
    if Doodad.szName == szDoodadName then
      return v
    end
  end
end

local frameLastDown, nLastSteper = nil, nil
local nLastMousePos = {nX = 0, nY = 0}
yyLifeBar.CheckMouseVisibleState = function()
  -- upvalues: nLastMousePos , frameLastDown , nLastSteper
  local bMouseVisibleState = Cursor.IsVisible()
  if bMouseVisibleState then
    nLastMousePos.nX = Cursor.GetPos()
  end
  if yyLifeBar.bLastMouseVisibleState == bMouseVisibleState then
    return 
  end
  yyLifeBar.bLastMouseVisibleState = bMouseVisibleState
  if bMouseVisibleState then
    local frameLastUp = yyLifeBar.GetRectFrameOnMouse()
    if frameLastUp and frameLastUp == frameLastDown and yyLifeBar.nSteper - nLastSteper <= 4 and frameLastUp:IsVisible() then
      local nType = TARGET.NPC
      if IsPlayer(R4_PC10) then
        nType = TARGET.PLAYER
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if GetClientPlayer().dwID == R4_PC10 then
        SetTarget(R4_PC10, GetClientPlayer().dwID)
      end
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      SetTarget(R4_PC10, frameLastUp.dwID)
    end
  else
    frameLastDown = yyLifeBar.GetRectFrameOnMouse()
    nLastSteper = yyLifeBar.nSteper
  end
end

yyLifeBar.GetRectFrameOnMouse = function()
  -- upvalues: nLastMousePos
  for i = 1, yyLifeBar.nAllowMember do
    local frame = yyLifeBar.tSortedVisibleLifeBarList[i]
    if frame and frame:IsVisible() then
      local target = yyLifeBar.GetCharacter(frame.dwID)
    end
    if target then
      local nFX, nFY = frame:GetRelPos()
      local nX, nY = nLastMousePos.nX, nLastMousePos.nY
    end
    if nFX < nX and nX < nFX + 115 and nFY < nY and nY < nFY + 28 then
      return frame
    end
  end
end

yyLifeBar.RefreshLifeBarDisplay = function()
  local player = GetClientPlayer()
  if not player then
    return 
  end
  local tPlacedRectsZone = {}
  local nRecursionCount = 0
  local GetShortestPathLoc = function(nX, nY, nMode)
    -- upvalues: nRecursionCount , tPlacedRectsZone , GetShortestPathLoc
    nRecursionCount = nRecursionCount + 1
    if nRecursionCount >= 40 then
      return nX, nY
    end
    local nW = 120
    for i = 1, #tPlacedRectsZone do
      local nPlacedX = tPlacedRectsZone[i].nX
      local nPlacedY = tPlacedRectsZone[i].nY
      local nH = tPlacedRectsZone[i].nH
      local bIntersection = nPlacedX < nX + nW and nX < nPlacedX + nW and nPlacedY < nY + nH and nY < nPlacedY + nH
      if bIntersection then
        if nMode == 8 then
          return GetShortestPathLoc(nX, nPlacedY - nH - 1, nMode)
        end
      elseif nMode == 2 then
        return GetShortestPathLoc(nX, nPlacedY + nH + 1, nMode)
      elseif nMode == 4 then
        return GetShortestPathLoc(nPlacedX - nW - 1, nY, nMode)
      elseif nMode == 6 then
        return GetShortestPathLoc(nPlacedX + nW + 1, nY, nMode)
      elseif nMode == 7 then
        return GetShortestPathLoc(nPlacedX - nW - 1, nPlacedY - nH - 1, nMode)
      elseif nMode == 3 then
        return GetShortestPathLoc(nPlacedX + nW + 1, nPlacedY + nH + 1, nMode)
      elseif nMode == 9 then
        return GetShortestPathLoc(nPlacedX + nW + 1, nPlacedY - nH - 1, nMode)
      elseif nMode == 1 then
        return GetShortestPathLoc(nPlacedX - nW - 1, nPlacedY + nH + 1, nMode)
      else
        return nX, nY
      end
    end
    return nX, nY
  end
  for dwID,frame in pairs(yyLifeBar.tLifeBarList) do
    if frame then
      if yyLifeBar.bReplaceTopHeadEx then
        yyLifeBar.ReplaceTopHeadEx(dwID, frame.bVisible)
      end
      if frame.bVisible then
        frame:Show()
        local target = yyLifeBar.GetCharacter(dwID)
        if target then
          local nTopX, nTopY, nTopZ = Scene_GetCharacterTop(dwID)
          local nScreenX, nScreenY, bSuccess = 0, 0, false
          if nTopX and nTopY and nTopZ then
            nScreenX = Scene_ScenePointToScreenPoint(nTopX, nTopY, nTopZ)
          end
           -- DECOMPILER ERROR: Overwrote pending register.

          if bSuccess then
            nScreenX = Station.AdjustToOriginalPos(nScreenX, nScreenY)
           -- DECOMPILER ERROR: Overwrote pending register.

          else
            nScreenX = -4096
          end
          local nShiftMax = 14
          local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
          local nAlpha = handleCastingBar:GetAlpha()
          local nHShift = 32 + nAlpha / 255 * nShiftMax
          local nNewX, nNewY = nScreenX - 57.5, nScreenY - nHShift
          local tDifLevel = {8, 2, 4, 6, 7, 9, 3, 1}
          local tClostLoc = {nX = nNewX, nY = nNewY, nDist = 99999999}
          if yyLifeBar.bAutoSort and yyLifeBar.bShowLifeBar then
            local nLoopEnd = #tDifLevel
            for i = 1, nLoopEnd do
              local nMode = tDifLevel[i]
              local nDifX, nDifY = GetShortestPathLoc(nNewX, nNewY, nMode)
              nRecursionCount = 0
              local nDist = math.floor(nNewX - nDifX ^ 2 + nNewY - nDifY ^ 2 ^ 0.5)
              if nDist + 2 < tClostLoc.nDist then
                tClostLoc.nX = nDifX
                tClostLoc.nY = nDifY
                tClostLoc.nDist = nDist
              end
            end
          end
          local nRectH = 36
          if not yyLifeBar.bShowName and not yyLifeBar.bShowDistance then
            nRectH = 26
          end
          table.insert(tPlacedRectsZone, {nX = tClostLoc.nX, nY = tClostLoc.nY, nH = nRectH})
          frame:SetRelPos(tClostLoc.nX, tClostLoc.nY)
          local nX, nY = Cursor.GetPos()
          local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
          if tClostLoc.nX < nX and nX < tClostLoc.nX + 120 and tClostLoc.nY < nY and nY < tClostLoc.nY + 28 and Cursor.IsVisible() then
            handleLifeBar:Lookup("Image_LifeBar_L_Cover"):Show()
            handleLifeBar:Lookup("Image_LifeBar_M_Cover"):Show()
            handleLifeBar:Lookup("Image_LifeBar_R_Cover"):Show()
          else
            handleLifeBar:Lookup("Image_LifeBar_L_Cover"):Hide()
            handleLifeBar:Lookup("Image_LifeBar_M_Cover"):Hide()
            handleLifeBar:Lookup("Image_LifeBar_R_Cover"):Hide()
          end
        else
          yyLifeBar.RemoveLifeBar(dwID)
        end
      else
        local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
        handleLifeBar:SetAlpha(0)
        frame:Hide()
      end
    else
      yyLifeBar.RemoveLifeBar(dwID)
    end
  end
end

yyLifeBar.GetFrameVisibleDistance = function(frame)
  local player = GetClientPlayer()
  if not player then
    return 
  end
  if not frame then
    return 
  end
  frame.nDist3D = 99999999
  local dwID = frame.dwID
  local target = yyLifeBar.GetCharacter(dwID)
  if not target then
    yyLifeBar.RemoveLifeBar(dwID)
    return 
  end
  if IsEnemy(player.dwID, dwID) and not yyLifeBar.bShowEnemy then
    return 
  end
  do return end
  if not yyLifeBar.bShowAlly then
    return 
  end
  if IsPlayer(dwID) then
    if not yyLifeBar.bShowPlayer then
      return 
    end
    if yyLifeBar.bOnlyParty and not player.IsPlayerInMyParty(dwID) then
      return 
    end
  else
    if not yyLifeBar.bShowNpc then
      return 
    end
  end
  local nDist3D = math.floor(player.nX - target.nX ^ 2 + player.nY - target.nY ^ 2 + player.nZ / 8 - target.nZ / 8 ^ 2 ^ 0.5)
  frame.nDist3D = nDist3D
  local nCampDist = math.min(yyLifeBar.nRange * 64, yyLifeBar.nRangeMax * 64)
  if not yyLifeBar.bShowLifeBar then
    nCampDist = yyLifeBar.nRangeMax * 64
  end
  if nCampDist < nDist3D then
    return false, nDist3D
  end
  return true, nDist3D
end

yyLifeBar.SortVisibleFrameByDistance = function()
  local player = GetClientPlayer()
  if not player then
    return 
  end
  do
    local _, dwSelectedTargetID = player.GetTarget()
    yyLifeBar.tSortedVisibleLifeBarList = {}
    if yyLifeBar.bSelectedBarMode and dwSelectedTargetID and dwSelectedTargetID > 0 and yyLifeBar.tLifeBarList[dwSelectedTargetID] then
      table.insert(yyLifeBar.tSortedVisibleLifeBarList, yyLifeBar.tLifeBarList[dwSelectedTargetID])
    end
    do break end
    do
      local (for generator), (for state), (for control), dwID, frame = pairs(yyLifeBar.tLifeBarList)
      if frame then
        frame.bVisible = false
        if yyLifeBar.GetFrameVisibleDistance(frame) and (not yyLifeBar.bSelectedBarMode or frame.dwID ~= dwSelectedTargetID) then
          if #yyLifeBar.tSortedVisibleLifeBarList == 0 then
            table.insert(yyLifeBar.tSortedVisibleLifeBarList, frame)
          end
          do break end
        end
        local nCurrentLen = math.min(#yyLifeBar.tSortedVisibleLifeBarList, yyLifeBar.nAllowMember)
        yyLifeBar.tSortedVisibleLifeBarList[nCurrentLen + 1] = frame
        for i = nCurrentLen, 1, -1 do
          local nCampDist = yyLifeBar.tSortedVisibleLifeBarList[i + 1].nDist3D
          local nSelfDist = yyLifeBar.tSortedVisibleLifeBarList[i].nDist3D
          if nCampDist < nSelfDist and (not yyLifeBar.bSelectedBarMode or yyLifeBar.tSortedVisibleLifeBarList[i].dwID ~= dwSelectedTargetID) then
            yyLifeBar.tSortedVisibleLifeBarList[i + 1] = yyLifeBar.tSortedVisibleLifeBarList[i]
          else
            do break end
          end
        end
      else
        yyLifeBar.RemoveLifeBar(dwID)
      end
    end
  end
  yyLifeBar.tSortedVisibleLifeBarList[yyLifeBar.nAllowMember + 1] = nil
  for i = 1, #yyLifeBar.tSortedVisibleLifeBarList do
    yyLifeBar.tSortedVisibleLifeBarList[i].bVisible = true
    yyLifeBar.UpdateVisibleLifeBarData(yyLifeBar.tSortedVisibleLifeBarList[i])
  end
  return yyLifeBar.tSortedVisibleLifeBarList
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

yyLifeBar.UpdateVisibleLifeBarData = function(frame)
  if not frame then
    return 
  end
  local player = GetClientPlayer()
  if not player then
    return 
  end
  local dwID = frame.dwID
  local _, dwSelectedTargetID = player.GetTarget()
  local target = yyLifeBar.GetCharacter(dwID)
  if not target then
    yyLifeBar.RemoveLifeBar(dwID)
    return 
  end
  local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
  local nCastingBarAlpha = handleCastingBar:GetAlpha()
  local imageCastingBarIcon = handleCastingBar:Lookup("Image_SkillIcon")
  local imageCastingBar = handleCastingBar:Lookup("Image_CastingBar")
  local iForce = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Image_Force")
  if yyLifeBar.biForce and IsPlayer(dwID) then
    iForce:Show()
    iForce:FromUITex(GetForceImage(target.dwForceID))
  else
    iForce:Hide()
  end
  local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
  local imageLifeBar = handleLifeBar:Lookup("Image_LifeBar")
  local aniSelected = handleLifeBar:Lookup("Animate_Selected")
  aniSelected:Hide()
  if dwSelectedTargetID == target.dwID then
    aniSelected:Show()
    frame.nFrameAlpha = 255
  elseif frame.nDist3D <= 640 then
    frame.nFrameAlpha = 175
  else
    frame.nFrameAlpha = 175
  end
  if yyLifeBar.nSteper % 4 == 0 then
    yyLifeBar.UpdateLifeBarColor(imageLifeBar, target)
    local textName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_TargetName")
    local szName = target.szName
    local title, xinfa = nil, nil
    if IsPlayer(target.dwID) then
      title = GetTongClient().ApplyGetTongName(target.dwTongID)
    else
      title = target.szTitle
    end
    local TitleName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_Title")
    if yyLifeBar.bShowTitle and title ~= nil and title ~= "" then
      TitleName:Show()
      TitleName:SetText("��" .. title .. "��")
      TitleName:SetFontColor(textName:GetFontColor())
    else
      TitleName:Hide()
    end
    if not yyLifeBar.bShowName then
      szName = ""
    end
    if yyLifeBar.bShowDistance and dwID ~= player.dwID then
      local nDistTarget = frame.nDist3D
      if not frame.nDist3D or frame.nDist3D > 99999 then
        local target = yyLifeBar.GetCharacter(dwID)
        if target then
          nDistTarget = math.floor(player.nX - target.nX ^ 2 + player.nY - target.nY ^ 2 + player.nZ / 8 - target.nZ / 8 ^ 2 ^ 0.5)
        end
      else
        nDistTarget = 0
      end
      local dwlevel = target.nLevel
      if yyLifeBar.bShowLevel and dwlevel ~= nil then
        szName = "(" .. dwlevel .. ")" .. "" .. szName .. " " .. "%.1f":format(nDistTarget / 64) .. ""
      end
    else
      szName = szName .. " " .. "%.1f":format(nDistTarget / 64) .. ""
    end
    textName:SetText(szName)
    local r, g, b = yyLifeBar.GetCharacterColor(dwID)
    textName:SetFontColor(r, g, b)
  end
  local nPercentage = target.nCurrentLife / target.nMaxLife
  if nPercentage > 1 then
    nPercentage = 1
  elseif nPercentage < 0 then
    nPercentage = 0
  end
  local txtLife = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_LifeBar")
  local textName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_TargetName")
  local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
  if yyLifeBar.bShowLife then
    txtLife:Show()
    if target.nMoveState == MOVE_STATE.ON_DEATH then
      if IsEnemy(dwID, player.dwID) then
        txtLife:SetText("���ɹ��Ƶ���")
        txtLife:SetFontColor(249, 147, 2)
        imageLifeBar:Hide()
        handleLifeBar:Lookup("Image_LifeBar_L"):Hide()
        handleLifeBar:Lookup("Image_LifeBar_M"):Hide()
        handleLifeBar:Lookup("Image_LifeBar_R"):Hide()
      else
        txtLife:SetText("������ץ����")
        txtLife:SetFontColor(249, 147, 2)
        imageLifeBar:Hide()
        handleLifeBar:Lookup("Image_LifeBar_L"):Hide()
        handleLifeBar:Lookup("Image_LifeBar_M"):Hide()
        handleLifeBar:Lookup("Image_LifeBar_R"):Hide()
      end
    else
      local nlife = string.format("%.0f", nPercentage * 100)
      txtLife:SetText(nlife .. "%")
      txtLife:SetFontColor(textName:GetFontColor())
      imageLifeBar:SetPercentage(nPercentage)
      imageLifeBar:Show()
      handleLifeBar:Lookup("Image_LifeBar_L"):Show()
      handleLifeBar:Lookup("Image_LifeBar_M"):Show()
      handleLifeBar:Lookup("Image_LifeBar_R"):Show()
    end
  else
    txtLife:Hide()
    imageLifeBar:SetPercentage(nPercentage)
  end
  if yyLifeBar.bShowCastingBar then
    handleCastingBar:Show()
    local bPrePare, dwSkillID, dwSkillLevel, fCastPercent = target.GetSkillPrepareState()
    local textSkillName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_SkillName")
    if bPrePare then
      local szSkillIconID = Table_GetSkillIconID(dwSkillID, dwSkillLevel)
      imageCastingBarIcon:FromIconID(szSkillIconID)
      imageCastingBar:SetPercentage(fCastPercent)
      nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
      do
        if not Table_GetSkillName(dwSkillID, dwSkillLevel) then
          local szSkillName = not yyLifeBar.bShowName or ""
        end
        textSkillName:SetText(szSkillName)
        textSkillName:Show()
      end
      do return end
      textSkillName:Hide()
    else
      textSkillName:Hide()
      nCastingBarAlpha = nCastingBarAlpha - 45 * (frame.nFrameAlpha / 255)
    end
    imageCastingBarIcon:SetSize(25, 25)
    if nCastingBarAlpha <= 0 then
      handleCastingBar:SetAlpha(0)
    elseif frame.nFrameAlpha <= nCastingBarAlpha then
      handleCastingBar:SetAlpha(frame.nFrameAlpha)
    else
      handleCastingBar:SetAlpha(nCastingBarAlpha)
    end
    if bPrePare then
      local nSize = 16
      local nSizeMax = 116
      local nScale = math.min(fCastPercent * 8 * (frame.nFrameAlpha / 255), 1)
      nSize = nSizeMax - nScale * (nSizeMax - nSize)
      imageCastingBarIcon:SetSize(nSize, nSize)
    end
  else
    handleCastingBar:Hide()
  end
  local nLifeBarAlpha = handleLifeBar:GetAlpha()
  nLifeBarAlpha = math.min(nLifeBarAlpha + 30, frame.nFrameAlpha)
  if not yyLifeBar.bShowLifeBar then
    nLifeBarAlpha = 0
  end
  handleLifeBar:SetAlpha(nLifeBarAlpha)
  aniSelected:SetAlpha(nLifeBarAlpha * 0.5)
end

yyLifeBar.ReplaceTopHeadEx = function(dwCharacterID, bHideTHE)
  if not yyLifeBar.bShowLifeBar then
    bHideTHE = false
  end
  if TopHeadDisplayEx then
    local handle = TopHeadDisplayEx.handleTotal
    if not handle then
      return 
    end
    local handleLabel_Hp = handle:Lookup("Hp_" .. dwCharacterID)
    if handleLabel_Hp then
      if bHideTHE then
        handleLabel_Hp:SetAlpha(0)
      end
    else
      handleLabel_Hp:SetAlpha(255)
    end
    local handleLabel_Mp = handle:Lookup("Mp_" .. dwCharacterID)
    if handleLabel_Mp then
      if bHideTHE then
        handleLabel_Mp:SetAlpha(0)
      end
    else
      handleLabel_Mp:SetAlpha(255)
    end
    local handleLabel_Name = handle:Lookup("Name_" .. dwCharacterID)
  end
  if handleLabel_Name then
    if bHideTHE then
      handleLabel_Name:Hide()
    end
  else
    handleLabel_Name:Show()
  end
  if Head then
    local frame = Station.Lookup("Lowest/Head")
  end
  if frame then
    local handle = frame:Lookup("", "")
  end
  if handle then
    local item = handle:Lookup(tostring(dwCharacterID))
  end
  if item then
    if bHideTHE then
      item:Hide()
    end
  else
    item:Show()
  end
  if XuHead then
    local handle = XuHead.handleTotal
    if not handle then
      return 
    end
    local handleLabel_Name = handle:Lookup("Name_xNPC_" .. dwCharacterID)
  end
  if handleLabel_Name then
    if bHideTHE then
      handleLabel_Name:Hide()
    end
  else
    handleLabel_Name:Show()
  end
end

yyLifeBar.GetCharacterColor = function(dwCharacterID)
  local player = GetClientPlayer()
  if not player then
    return 128, 128, 128
  end
  if yyLifeBar.bShowEnemy and IsEnemy(dwCharacterID, player.dwID) then
    return 255, 0, 0
  end
  if not yyLifeBar.bPartyColor and player.IsPlayerInMyParty(dwCharacterID) then
    return 0, 128, 255
  end
  if not yyLifeBar.bForceColorName then
    if IsEnemy(dwCharacterID, player.dwID) then
      return 255, 0, 0
    end
  else
    if IsNeutrality(dwCharacterID, player.dwID) then
      return 216, 216, 32
    end
  else
    if IsAlly(dwCharacterID, player.dwID) then
      return 0, 166, 0
    end
  elseif dwCharacterID == player.dwID then
    return 0, 166, 0
  end
  if yyLifeBar.bForceColorName then
    if IsEnemy(dwCharacterID, player.dwID) and not IsPlayer(dwCharacterID) then
      return 255, 0, 0
    else
      if IsNeutrality(dwCharacterID, player.dwID) and not IsPlayer(dwCharacterID) then
        return 216, 216, 32
      end
    else
      if IsAlly(dwCharacterID, player.dwID) and not IsPlayer(dwCharacterID) then
        return 0, 166, 0
      end
    end
    local target = yyLifeBar.GetCharacter(dwCharacterID)
    if not target then
      return 128, 128, 128
    end
    local nForceID = target.dwForceID
    if not nForceID then
      return 128, 0, 255
    end
    if nForceID == 0 then
      return 255, 255, 255
    end
  elseif nForceID == 1 then
    return 223, 223, 150
  elseif nForceID == 2 then
    return 196, 152, 255
  elseif nForceID == 3 then
    return 230, 100, 85
  elseif nForceID == 4 then
    return 89, 224, 232
  elseif nForceID == 5 then
    return 236, 164, 191
  elseif nForceID == 8 then
    return 247, 194, 93
  elseif nForceID == 6 then
    return 99, 134, 214
  elseif nForceID == 7 then
    return 121, 183, 54
  elseif nForceID == 10 then
    return 247, 150, 49
  end
  return 250, 250, 250
end

yyLifeBar.UpdateLifeBarColor = function(imageBar, target)
  if not imageBar or not target then
    return 
  end
  local player = GetClientPlayer()
  if not player then
    return 
  end
  local nImageFrame = 227
  if IsNeutrality(target.dwID, player.dwID) then
    nImageFrame = 219
  else
    if IsAlly(target.dwID, player.dwID) then
      if IsPlayer(target.dwID) then
        if player.IsPlayerInMyParty(target.dwID) then
          nImageFrame = 213
        end
      else
        nImageFrame = 217
      end
    else
      nImageFrame = 214
    end
  else
    if IsEnemy(target.dwID, player.dwID) then
      nImageFrame = 222
    end
  end
  if imageBar.nImageFrame ~= nImageFrame then
    imageBar:SetFrame(nImageFrame)
    imageBar.nImageFrame = nImageFrame
  end
end

yyLifeBar.GetCharacter = function(dwID)
  local target = nil
  if IsPlayer(dwID) then
    target = GetPlayer(dwID)
  else
    target = GetNpc(dwID)
  end
  if target and not target.CanSeeName() and not yyLifeBar.bShowTNpc then
    return 
  end
  return target
end

yyLifeBar.CreateLifeBar = function(dwTargetID)
  if not dwTargetID then
    return 
  end
  if not yyLifeBar.bShowSelf and dwTargetID == GetClientPlayer().dwID then
    return 
  end
  local target = yyLifeBar.GetCharacter(dwTargetID)
  if not target then
    return 
  end
  local frame = Station.Lookup("Lowest1/yyLifeBar_" .. dwTargetID)
  if frame then
    return 
  end
  frame = Wnd.OpenWindow("Interface\\yyLifeBar\\yyLifeBar.ini", "yyLifeBar_" .. dwTargetID)
  if not frame then
    return 
  end
  frame:Show()
  frame.dwID = dwTargetID
  yyLifeBar.tLifeBarList[dwTargetID] = frame
  local textName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_TargetName")
  if yyLifeBar.bShowName then
    textName:SetText(target.szName)
  else
    textName:SetText("")
  end
  local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
  local imageBar = handleLifeBar:Lookup("Image_LifeBar")
  yyLifeBar.UpdateLifeBarColor(imageBar, target)
  handleLifeBar:SetAlpha(0)
  local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
  handleCastingBar:SetAlpha(0)
end

yyLifeBar.RemoveLifeBar = function(dwTargetID)
  local frame = Station.Lookup("Lowest1/yyLifeBar_" .. dwTargetID)
  if frame then
    yyLifeBar.tLifeBarList[dwTargetID] = nil
    Wnd.CloseWindow(frame:GetName())
  end
end

yyLifeBar.OpenPanel = function()
  local frame = Station.Lookup("Lowest1/yyLifeBar")
  if not frame then
    frame = Wnd.OpenWindow("Interface\\yyLifeBar\\yyLifeBar.ini", "yyLifeBar")
  end
  frame:Show()
  frame:SetSize(0, 0)
  frame:Lookup("", ""):Hide()
end

yyLifeBar.OpenPanel()
OutputMessage("MSG_SYS", "����������������������������\n")
OutputMessage("MSG_SYS", "ͷ����ǿ������� by ���Ƿɽ�\n")
OutputMessage("MSG_SYS", "����������������������������\n")

