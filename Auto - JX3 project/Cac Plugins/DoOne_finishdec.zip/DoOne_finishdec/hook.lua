-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: hook.lua 

local l_0_0 = {}
l_0_0.nPingValue = 0
l_0_0.nPingTime = 0
BoxHook = l_0_0
local l_0_1 = setmetatable
local l_0_2 = l_0_0
local l_0_3 = {}
l_0_3.__mode = "v"
l_0_1(l_0_2, l_0_3)
l_0_1 = setmetatable
l_0_2 = BoxHook
l_0_1(l_0_2, l_0_3)
l_0_3 = {__newindex = function(l_1_0, l_1_1, l_1_2)
  -- upvalues: l_0_0
  if _G[l_1_1] then
    l_0_0[l_1_1] = l_1_2
  else
    _G[l_1_1] = l_1_2
  end
end
}
l_0_1 = BoxHook
l_0_1.ALL_CRAFT_TYPE, l_0_2 = l_0_2, {COPY = 6, READ = 3, TOTAL = 8, RADAR = 5, ENCHANT = 4, PRODUCE = 2, COLLECTION = 1}
l_0_1 = BoxHook
l_0_1.DOODAD_KIND, l_0_2 = l_0_2, {NORMAL = 1, CORPSE = 2, QUEST = 3, READ = 4, DIALOG = 5, ACCEPT_QUEST = 6, TREASURE = 7, ORNAMENT = 8, CRAFT_TARGET = 9, CLIENT_ONLY = 10, CHAIR = 12}
l_0_1 = BoxHook
l_0_1.UI_OBJECT_SKILL = 5
l_0_1 = BoxHook
l_0_1.UI_OBJECT_ITEM = 0
l_0_1 = BoxHook
l_0_1.UI_OBJECT_SHOP_ITEM = 1
l_0_1 = BoxHook
l_0_1.UI_OBJECT_OTER_PLAYER_ITEM = 2
l_0_1 = BoxHook
l_0_1.UI_OBJECT_ITEM_ONLY_ID = 3
l_0_1 = BoxHook
l_0_1.UI_OBJECT_ITEM_INFO = 4
l_0_1 = BoxHook
l_0_1.UI_OBJECT_SKILL = 5
l_0_1 = BoxHook
l_0_1.UI_OBJECT_CRAFT = 6
l_0_1 = BoxHook
l_0_1.UI_OBJECT_SKILL_RECIPE = 7
l_0_1 = BoxHook
l_0_1.UI_OBJECT_SYS_BTN = 8
l_0_1 = BoxHook
l_0_1.UI_OBJECT_MACRO = 9
l_0_1 = BoxHook
l_0_1.UI_OBJECT_MOUNT = 10
l_0_1 = BoxHook
l_0_1.UI_OBJECT_ENCHANT = 11
l_0_1 = BoxHook
l_0_1.UI_OBJECT_NOT_NEED_KNOWN = 15
l_0_1 = BoxHook
l_0_1.ITEM_SUBTYPE_SKILL_RECIPE = 4
l_0_1 = BoxHook
l_0_1.ITEM_SUBTYPE_RECIPE = 5
l_0_1 = BoxHook
l_0_1.ITEM_RESULT_CODE, l_0_2 = l_0_2, {SUCCESS = 1, FAILED = 2}
l_0_1 = BoxHook
l_0_1.ACTION_STATE, l_0_2 = l_0_2, {NONE = 1, PREPARE = 2, DONE = 3, BREAK = 4, FADE = 5}
l_0_1 = BoxHook
l_0_2 = function(l_2_0, l_2_1)
  local l_2_2 = ""
  local l_2_3 = GetRecipe(l_2_0, l_2_1)
  if l_2_3.nCraftType == ALL_CRAFT_TYPE.COPY or l_2_3.nCraftType == ALL_CRAFT_TYPE.READ then
    local l_2_4, l_2_5 = GlobelRecipeID2BookID(l_2_1)
    l_2_2 = Table_GetBookName(l_2_4, l_2_5)
  else
    local l_2_6 = g_tTable.UICraft:Search(l_2_0)
    if l_2_6.szPath ~= "" then
      local l_2_7 = KG_Table.Load
      local l_2_8 = l_2_6.szPath
      local l_2_9 = {}
      local l_2_10 = {}
      l_2_10.f = "i"
      l_2_10.t = "dwID"
      local l_2_11 = {}
      l_2_11.f = "s"
      l_2_11.t = "szName"
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_2_10 = FILE_OPEN_MODE
      l_2_10 = l_2_10.NORMAL
      l_2_7 = l_2_7(l_2_8, l_2_9, l_2_10)
      l_2_8, l_2_9 = l_2_7:Search, l_2_7
      l_2_10 = l_2_1
      l_2_8 = l_2_8(l_2_9, l_2_10)
    end
    if l_2_8 then
      l_2_2 = l_2_8.szName
    end
  else
    Trace("KLUA[ERROR] uiScript\table.lua dwCraftID = " .. l_2_0 .. "dwRecipeID = " .. l_2_1 .. " craft Path is nil!!\n")
  end
  return l_2_2
end

l_0_1.Table_GetRecipeName = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_3_0, l_3_1)
  local l_3_2 = ""
  local l_3_3 = g_tTable.CraftBelongName:Search(l_3_0, l_3_1)
  if l_3_3 then
    l_3_2 = l_3_3.szBelongName
  end
  return l_3_2
end

l_0_1.Table_GetCraftBelongName = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_4_0, l_4_1, l_4_2)
  local l_4_3 = -1
  local l_4_4 = g_tTable.CraftEnchant:Search(l_4_0, l_4_1, l_4_2)
  if l_4_4 then
    l_4_3 = l_4_4.nQuality
  end
  return l_4_3
end

l_0_1.Table_GetEnchantQuality = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_5_0, l_5_1, l_5_2)
  local l_5_3 = ""
  local l_5_4 = g_tTable.CraftEnchant:Search(l_5_0, l_5_1, l_5_2)
  if l_5_4 then
    l_5_3 = l_5_4.szName
  end
  return l_5_3
end

l_0_1.Table_GetEnchantName = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_6_0)
  return g_tTable.Quests:Search(l_6_0)
end

l_0_1.Table_GetQuestStringInfo = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_7_0, l_7_1)
  local l_7_2 = ""
  local l_7_3 = g_tTable.BookSegment:Search(l_7_0, l_7_1)
  if l_7_3 then
    l_7_2 = l_7_3.szBookName
  end
  return l_7_2
end

l_0_1.Table_GetBookName = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_8_0, l_8_1)
  local l_8_2 = ""
  local l_8_3 = g_tTable.BookSegment:Search(l_8_0, l_8_1)
  if l_8_3 then
    l_8_2 = l_8_3.szSegmentName
  end
  return l_8_2
end

l_0_1.Table_GetSegmentName = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_9_0, l_9_1)
  local l_9_2 = -1
  local l_9_3 = g_tTable.BookSegment:Search(l_9_0, l_9_1)
  if l_9_3 then
    l_9_2 = l_9_3.nSort
  end
  return l_9_2
end

l_0_1.Table_GetBookSort = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_10_0, l_10_1)
  local l_10_2 = -1
  local l_10_3 = g_tTable.BookSegment:Search(l_10_0, l_10_1)
  if l_10_3 then
    l_10_2 = l_10_3.nSubSort
  end
  return l_10_2
end

l_0_1.Table_GetBookSubSort = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_11_0, l_11_1)
  local l_11_2 = 0
  local l_11_3 = g_tTable.BookSegment:Search(l_11_0, l_11_1)
  if l_11_3 then
    l_11_2 = l_11_3.dwBookNumber
  end
  return l_11_2
end

l_0_1.Table_GetBookNumber = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_12_0, l_12_1)
  local l_12_2 = ""
  local l_12_3 = g_tTable.BookSegment:Search(l_12_0, l_12_1)
  if l_12_3 then
    l_12_2 = l_12_3.szDesc
  end
  return l_12_2
end

l_0_1.Table_GetBookDesc = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_13_0, l_13_1)
  local l_13_2 = 0
  local l_13_3 = g_tTable.BookSegment:Search(l_13_0, l_13_1)
  if l_13_3 then
    l_13_2 = l_13_3.dwBookItemIndex
  end
  return l_13_2
end

l_0_1.Table_GetBookItemIndex = l_0_2
l_0_1 = BoxHook
l_0_2 = function(l_14_0)
  local l_14_1 = ""
  local l_14_2 = g_tTable.ProfessionName:Search(l_14_0)
  if l_14_2 then
    l_14_1 = l_14_2.szName
  end
  return l_14_1
end

l_0_1.Table_GetProfessionName = l_0_2
l_0_2 = 42
l_0_3 = 53
l_0_2 = 13
l_0_3 = 125
l_0_2 = 473
l_0_3 = 27
l_0_2 = 12
l_0_3 = 124
l_0_2 = 356
l_0_3 = 59
l_0_2 = 45
l_0_3 = 49
l_0_2 = 47
l_0_3 = 48
l_0_2 = 232
l_0_3 = 89
l_0_2 = 257
l_0_3 = 107
l_0_2 = 462
l_0_3 = 7
l_0_2 = 470
l_0_3 = 4
l_0_2 = 36
l_0_3 = 32
l_0_2 = 15
l_0_3 = 11
l_0_2 = 236
l_0_3 = 85
l_0_2 = BoxHook
l_0_3 = "GetAttribute"
l_0_2[l_0_3] = function(l_15_0)
  -- upvalues: l_0_1
  local l_15_1 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_0_1[l_15_0] then
    l_15_1 = g_tTable.Attribute:GetRow(l_0_1[l_15_0])
  end
  return l_15_1
end

l_0_2 = BoxHook
l_0_3 = "Table_GetMagicAttributeInfo"
l_0_2[l_0_3] = function(l_16_0, l_16_1)
  local l_16_2 = ""
  local l_16_3 = GetAttribute(l_16_0)
  if l_16_3 and l_16_1 then
    l_16_2 = l_16_3.szGeneratedMagic
  else
    l_16_2 = l_16_3.szPreviewMagic
  end
  return l_16_2
end

l_0_2 = BoxHook
l_0_3 = "Table_IsBattleFieldMap"
l_0_2[l_0_3] = function(l_17_0)
  local l_17_1 = false
  if g_tTable.BattleField:Search(l_17_0) then
    l_17_1 = true
  end
  return l_17_1
end

l_0_2 = BoxHook
l_0_3 = "IsInBattleField"
l_0_2[l_0_3] = function()
  local l_18_0 = GetClientPlayer()
  if l_18_0 then
    local l_18_1 = Table_IsBattleFieldMap
    local l_18_2 = l_18_0.GetMapID()
    return l_18_1(l_18_2)
  end
end

l_0_2 = BoxHook
l_0_3 = "IsInArena"
l_0_2[l_0_3] = function()
  local l_19_0 = GetClientPlayer()
  if l_19_0 then
    return l_19_0.GetScene().bIsArenaMap
  end
end

l_0_2 = BoxHook
l_0_3 = "Table_GetDoodadTemplateName"
l_0_2[l_0_3] = function(l_20_0)
  local l_20_1 = ""
  local l_20_2 = g_tTable.DoodadTemplate:Search(l_20_0)
  if l_20_2 then
    l_20_1 = l_20_2.szName
  end
  return l_20_1
end

l_0_2 = BoxHook
l_0_3 = "Table_GetDoodadName"
l_0_2[l_0_3] = function(l_21_0, l_21_1)
  local l_21_2 = ""
  if l_21_1 ~= 0 then
    l_21_2 = Table_GetNpcTemplateName(l_21_1)
  else
    l_21_2 = Table_GetDoodadTemplateName(l_21_0)
  end
  return l_21_2
end

l_0_2 = BoxHook
l_0_3 = "GetTargetName"
l_0_2[l_0_3] = function(l_22_0, l_22_1)
  local l_22_2 = ""
  if l_22_0 == TARGET.NPC then
    local l_22_3 = GetNpc(l_22_1)
    if l_22_3 then
      l_22_2 = l_22_3.szName
    end
  else
    if l_22_0 == TARGET.DOODAD then
      local l_22_4 = GetDoodad(l_22_1)
    end
    if l_22_4 then
      l_22_2 = Table_GetDoodadName(l_22_4.dwTemplateID, l_22_4.dwNpcTemplateID)
    end
  else
    if l_22_0 == TARGET.ITEM then
      local l_22_5 = GetItem(l_22_1)
    end
    if l_22_5 then
      l_22_2 = GetItemNameByItem(l_22_5)
    end
  else
    if l_22_0 == TARGET.PLAYER then
      local l_22_6 = GetPlayer(l_22_1)
    end
  end
  if l_22_6 then
    l_22_2 = l_22_6.szName
  end
  return l_22_2
end

l_0_2 = BoxHook
l_0_3 = "GetTargetUIName"
l_0_2[l_0_3] = function(l_23_0, l_23_1)
  local l_23_2 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_23_0 == TARGET.PLAYER then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_23_0 == TARGET.NPC and l_23_2.dwEmployer ~= 0 then
    local l_23_3 = ""
    if not GetPlayer(l_23_2.dwEmployer) then
      l_23_3 = g_tStrings.STR_SOME_BODY .. g_tStrings.STR_PET_SKILL_LOG .. l_23_2.szName
    end
  else
    l_23_3 = GetPlayer(l_23_2.dwEmployer).szName .. g_tStrings.STR_PET_SKILL_LOG .. l_23_2.szName
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_23_3
end

l_0_2 = BoxHook
l_0_3 = "GetCampImageFrame"
l_0_2[l_0_3] = function(l_24_0, l_24_1)
  local l_24_2 = nil
  if l_24_0 == CAMP.GOOD then
    if l_24_1 then
      l_24_2 = 117
    else
      l_24_2 = 7
    end
  else
    if l_24_0 == CAMP.EVIL then
      if l_24_1 then
        l_24_2 = 116
      end
    end
  else
    l_24_2 = 5
  end
  return l_24_2
end

l_0_2 = BoxHook
l_0_3 = "SetImage"
l_0_2[l_0_3] = function(l_25_0, l_25_1)
  assert(l_25_0)
  if l_25_1 then
    l_25_0:SetFrame(l_25_1)
    l_25_0:Show()
  else
    l_25_0:Hide()
  end
end

l_0_2 = BoxHook
l_0_3 = "GetTargetLevelFont"
l_0_2[l_0_3] = function(l_26_0)
  local l_26_1 = 16
  if l_26_0 > 4 then
    l_26_1 = 159
  elseif l_26_0 > 2 then
    l_26_1 = 168
  elseif l_26_0 > -3 then
    l_26_1 = 16
  elseif l_26_0 > -6 then
    l_26_1 = 167
  else
    l_26_1 = 169
  end
  return l_26_1
end

l_0_2 = BoxHook
l_0_3 = "GetNpcIntensity"
l_0_2[l_0_3] = function()
  local l_27_0, l_27_1 = Target_GetTargetData()
  if l_27_0 and l_27_0 == TARGET.NPC then
    local l_27_2 = Station.Lookup("Normal/Target")
  end
  if l_27_2 then
    return l_27_2.nIntensity
  end
end

l_0_2 = BoxHook
l_0_3 = "IsActionBarOpened"
l_0_2[l_0_3] = function(l_28_0)
  do
    if l_28_0 == 1 or l_28_0 == 2 then
      local l_28_1, l_28_2, l_28_3 = Station.Lookup("Lowest/ActionBar" .. l_28_0)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    if Station.Lookup("Lowest/ActionBar" .. l_28_0) and Station.Lookup("Lowest/ActionBar" .. l_28_0):IsVisible() then
      return true
    end
    return false
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 20 
end

l_0_2 = BoxHook
l_0_3 = "GetActionBarFrame"
l_0_2[l_0_3] = function(l_29_0)
  if l_29_0 == 1 or l_29_0 == 2 then
    local l_29_1 = Station.Lookup
    local l_29_3 = "Lowest/ActionBar"
    l_29_3 = l_29_3 .. l_29_0
    local l_29_2 = nil
    return l_29_1(l_29_3)
  else
    local l_29_4 = Station.Lookup
    local l_29_6 = "Lowest/ActionBar"
    l_29_6 = l_29_6 .. l_29_0
    local l_29_5 = nil
    return l_29_4(l_29_6)
  end
end

l_0_2 = BoxHook
l_0_3 = "GetSkillActionBarBox"
l_0_2[l_0_3] = function(l_30_0)
  local l_30_1 = nil
  for i = 1, 4 do
    if IsActionBarOpened(i) and GetActionBarFrame(i) then
      local l_30_6 = nil
      for l_30_10 = 0, 15 do
        local l_30_7 = GetActionBarFrame(i):Lookup("", "Handle_Box")
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_30_1 = l_30_7:Lookup(R11_PC23)
        if l_30_1 and not l_30_1:IsEmpty() and l_30_1:GetObjectType() == UI_OBJECT_SKILL and l_30_1:GetObjectData() == l_30_0 then
          return l_30_1
        end
      end
    end
  end
end

l_0_2 = BoxHook
l_0_3 = "GetMinimapFrame"
l_0_2[l_0_3] = function()
  local l_31_0 = Station.Lookup
  local l_31_1 = "Topmost/Minimap"
  return l_31_0(l_31_1)
end

l_0_2 = BoxHook
l_0_3 = "IsTeammateOpened"
l_0_2[l_0_3] = function()
  local l_32_0 = Station.Lookup("Normal/Teammate")
  if l_32_0 then
    local l_32_1, l_32_2 = l_32_0:IsVisible, l_32_0
    return l_32_1(l_32_2)
  end
end

l_0_2 = BoxHook
l_0_3 = "OpenTeammate"
l_0_2[l_0_3] = function()
  local l_33_0 = Station.Lookup("Normal/Teammate")
  if l_33_0 then
    l_33_0:Show()
  end
end

l_0_2 = BoxHook
l_0_3 = "CloseTeammate"
l_0_2[l_0_3] = function()
  local l_34_0 = Station.Lookup("Normal/Teammate")
  if l_34_0 then
    l_34_0:Hide()
  end
end

l_0_2 = BoxHook
l_0_3 = "CloseCraftManagePanel"
l_0_2[l_0_3] = function(l_35_0)
  if IsCraftManagePanelOpened() then
    Wnd.CloseWindow("CraftManagePanel")
  end
  if not l_35_0 then
    PlaySound(SOUND.UI_SOUND, g_sound.CloseFrame)
  end
end

l_0_2 = BoxHook
l_0_3 = "IsCraftManagePanelOpened"
l_0_2[l_0_3] = function()
  local l_36_0 = Station.Lookup("Normal/CraftManagePanel")
  if l_36_0 and l_36_0:IsVisible() then
    return true
  end
  return false
end

l_0_2 = 6
BIGBAGCOUNT = l_0_2
l_0_2 = function(l_37_0)
  return INVENTORY_INDEX.PACKAGE + l_37_0 - 1
end

BagIndexToInventoryIndex = l_0_2
l_0_2 = function(l_38_0)
  return l_38_0 - INVENTORY_INDEX.PACKAGE + 1
end

InventoryIndexToBagIndex = l_0_2
l_0_2 = BoxHook
l_0_3 = "IsBigBagFull"
l_0_2[l_0_3] = function()
  local l_39_0 = GetClientPlayer()
  local l_39_1 = 0
  local l_39_2 = false
  for l_39_6 = 1, BIGBAGCOUNT do
    local l_39_7 = BagIndexToInventoryIndex(l_39_6)
    local l_39_8 = l_39_0.GetBoxSize(l_39_7)
    if l_39_8 and l_39_8 ~= 0 then
      l_39_1 = l_39_1 + l_39_0.GetBoxFreeRoomSize(l_39_7)
    end
  end
  if l_39_1 == 0 then
    l_39_2 = true
  end
  return l_39_2
end

l_0_2 = function()
  if Station.Lookup("Normal/BigBagPanel") then
    return true
  end
  return false
end

IsBackpackOpened = l_0_2
l_0_2 = function()
  if not IsBackpackOpened() then
    OutputMessage("MSG_ANNOUNCE_RED", "������δ�򿪹������ܵ������ݲ�׼ȷ��")
  end
end

WarnBackpackOpen = l_0_2
l_0_2 = function()
  local l_42_0 = Station.Lookup("Normal/BigBagPanel")
  if l_42_0 then
    local l_42_1 = l_42_0:Lookup("", "Handle_BagList")
    local l_42_2 = l_42_1:Lookup("Image_BagBox6")
  end
  if l_42_2:GetFrame() == 44 then
    return false
  end
  return true
end

CanUseMiBaoPackage = l_0_2
l_0_2 = BoxHook
l_0_3 = "RaidDragPanel"
l_0_2[l_0_3] = {}
l_0_2 = BoxHook
l_0_3 = "OpenRaidDragPanel"
l_0_2[l_0_3] = function(l_43_0)
  local l_43_1 = GetClientTeam()
  local l_43_2 = l_43_1.GetMemberInfo(l_43_0)
  if not l_43_2 then
    return 
  end
  local l_43_3 = Wnd.OpenWindow("RaidDragPanel")
  local l_43_4, l_43_5 = Cursor.GetPos()
  l_43_3:SetAbsPos(l_43_4, l_43_5)
  l_43_3:StartMoving()
  l_43_3.dwID = l_43_0
  local l_43_6 = l_43_3:Lookup("", "")
  local l_43_7, l_43_8 = GetForceImage(l_43_2.dwForceID)
  l_43_6:Lookup("Image_Force"):FromUITex(l_43_7, l_43_8)
  local l_43_9 = l_43_6:Lookup("Text_Name")
  l_43_9:SetText(l_43_2.szName)
  local l_43_10 = l_43_6:Lookup("Image_Health")
  local l_43_11 = l_43_6:Lookup("Image_Mana")
  if l_43_2.bIsOnLine then
    if l_43_2.nMaxLife > 0 then
      l_43_10:SetPercentage(l_43_2.nCurrentLife / l_43_2.nMaxLife)
    end
    if l_43_2.nMaxMana > 0 and l_43_2.nMaxMana ~= 1 then
      l_43_11:SetPercentage(l_43_2.nCurrentMana / l_43_2.nMaxMana)
    end
  else
    l_43_10:SetPercentage(0)
    l_43_11:SetPercentage(0)
  end
  l_43_6:Show()
end

l_0_2 = BoxHook
l_0_3 = "CloseRaidDragPanel"
l_0_2[l_0_3] = function()
  local l_44_0 = Station.Lookup("Normal/RaidDragPanel")
  if l_44_0 then
    l_44_0:EndMoving()
    Wnd.CloseWindow(l_44_0)
  end
end

l_0_2 = BoxHook
l_0_3 = "MakeNameLink"
l_0_2[l_0_3] = function(l_45_0, l_45_1)
  return "<text>text=" .. EncodeComponentsString(l_45_0) .. l_45_1 .. " name=\"namelink\" eventid=515</text>"
end

l_0_2 = BoxHook
l_0_3 = "MakeItemLink"
l_0_2[l_0_3] = function(l_46_0, l_46_1, l_46_2)
  return "<text>text=" .. EncodeComponentsString(l_46_0) .. l_46_1 .. "name=\"itemlink\" eventid=513 userdata=" .. l_46_2 .. "</text>"
end

l_0_2 = BoxHook
l_0_3 = "MakeItemInfoLink"
l_0_2[l_0_3] = function(l_47_0, l_47_1, l_47_2, l_47_3, l_47_4)
  return "<text>text=" .. EncodeComponentsString(l_47_0) .. l_47_1 .. "name=\"iteminfolink\" eventid=513 script=" .. EncodeComponentsString("this.nVersion=" .. l_47_2 .. "\nthis.dwTabType=" .. l_47_3 .. "\nthis.dwIndex=" .. l_47_4) .. "</text>"
end

l_0_2 = BoxHook
l_0_3 = "MakeQuestLink"
l_0_2[l_0_3] = function(l_48_0, l_48_1, l_48_2)
  return "<text>text=" .. EncodeComponentsString(l_48_0) .. l_48_1 .. "name=\"questlink\" eventid=513 userdata=" .. l_48_2 .. "</text>"
end

l_0_2 = BoxHook
l_0_3 = "EditBox_AppendLinkItem"
l_0_2[l_0_3] = function(l_49_0, l_49_1)
  if not IsEditBoxOpened() then
    OpenEditBox()
  end
  local l_49_2 = nil
  if l_49_1 then
    l_49_2 = GetPlayerItem(GetClientPlayer(), l_49_0, l_49_1)
  else
    l_49_2 = GetItem(l_49_0)
  end
  if not l_49_2 then
    return false
  end
  local l_49_3 = "[" .. GetItemNameByItem(l_49_2) .. "]"
  local l_49_4 = Station.Lookup("Lowest2/EditBox/Edit_Input")
  local l_49_5, l_49_6 = l_49_4:InsertObj, l_49_4
  local l_49_7 = l_49_3
  local l_49_8 = {}
  l_49_8.type = "item"
  l_49_8.text = l_49_3
  l_49_8.item = l_49_2.dwID
  l_49_5(l_49_6, l_49_7, l_49_8)
  l_49_5 = Station
  l_49_5 = l_49_5.SetFocusWindow
  l_49_6 = l_49_4
  l_49_5(l_49_6)
  l_49_5 = true
  return l_49_5
end

l_0_2 = BoxHook
l_0_3 = "EditBox_AppendLinkItemInfo"
l_0_2[l_0_3] = function(l_50_0, l_50_1, l_50_2, l_50_3)
  if not IsEditBoxOpened() then
    OpenEditBox()
  end
  local l_50_4 = GetItemInfo(l_50_1, l_50_2)
  if not l_50_4 then
    return false
  end
  if l_50_4.nGenre == ITEM_GENRE.BOOK then
    if not l_50_3 then
      return false
    end
    local l_50_5, l_50_6 = GlobelRecipeID2BookID(l_50_3)
    local l_50_7 = "[" .. Table_GetSegmentName(l_50_5, l_50_6) .. "]"
    local l_50_8 = Station.Lookup("Lowest2/EditBox/Edit_Input")
    local l_50_9, l_50_10 = l_50_8:InsertObj, l_50_8
    local l_50_11 = l_50_7
    local l_50_12 = {}
    l_50_12.type = "book"
    l_50_12.text = l_50_7
    l_50_12.version = l_50_0
    l_50_12.tabtype = l_50_1
    l_50_12.index = l_50_2
    l_50_12.bookinfo = l_50_3
    l_50_9(l_50_10, l_50_11, l_50_12)
    l_50_9 = Station
    l_50_9 = l_50_9.SetFocusWindow
    l_50_10 = l_50_8
    l_50_9(l_50_10)
  else
    local l_50_13 = "[" .. GetItemNameByItemInfo(l_50_4) .. "]"
    local l_50_14 = Station.Lookup("Lowest2/EditBox/Edit_Input")
    local l_50_15, l_50_16 = l_50_14:InsertObj, l_50_14
    local l_50_17 = l_50_13
    local l_50_18 = {}
    l_50_18.type = "iteminfo"
    l_50_18.text = l_50_13
    l_50_18.version = l_50_0
    l_50_18.tabtype = l_50_1
    l_50_18.index = l_50_2
    l_50_15(l_50_16, l_50_17, l_50_18)
    l_50_15 = Station
    l_50_15 = l_50_15.SetFocusWindow
    l_50_16 = l_50_14
    l_50_15(l_50_16)
  end
  return true
end

l_0_2 = BoxHook
l_0_3 = "EditBox_AppendLinkBook"
l_0_2[l_0_3] = function(l_51_0)
  if not IsEditBoxOpened() then
    OpenEditBox()
  end
  if not l_51_0 then
    return false
  end
  local l_51_1, l_51_2 = GlobelRecipeID2BookID(l_51_0)
  local l_51_3 = GLOBAL.CURRENT_ITEM_VERSION
  local l_51_4 = 5
  local l_51_5 = Table_GetBookItemIndex(l_51_1, l_51_2)
  local l_51_6 = "[" .. Table_GetSegmentName(l_51_1, l_51_2) .. "]"
  local l_51_7 = GetItemInfo(l_51_4, l_51_5)
  if not l_51_7 or l_51_7.nGenre ~= ITEM_GENRE.BOOK then
    return false
  end
  local l_51_8 = Station.Lookup("Lowest2/EditBox/Edit_Input")
  local l_51_9, l_51_10 = l_51_8:InsertObj, l_51_8
  local l_51_11 = l_51_6
  local l_51_12 = {}
  l_51_12.type = "book"
  l_51_12.text = l_51_6
  l_51_12.version = l_51_3
  l_51_12.tabtype = l_51_4
  l_51_12.index = l_51_5
  l_51_12.bookinfo = l_51_0
  l_51_9(l_51_10, l_51_11, l_51_12)
  l_51_9 = Station
  l_51_9 = l_51_9.SetFocusWindow
  l_51_10 = l_51_8
  l_51_9(l_51_10)
  l_51_9 = true
  return l_51_9
end

l_0_2 = BoxHook
l_0_3 = "EditBox_AppendLinkPlayer"
l_0_2[l_0_3] = function(l_52_0)
  if not IsEditBoxOpened() then
    OpenEditBox()
  end
  local l_52_1 = Station.Lookup("Lowest2/EditBox/Edit_Input")
  local l_52_2, l_52_3 = l_52_1:InsertObj, l_52_1
  local l_52_4 = "[" .. l_52_0 .. "]"
  local l_52_5 = {}
  l_52_5.type = "name"
  l_52_5.text = "[" .. l_52_0 .. "]"
  l_52_5.name = l_52_0
  l_52_2(l_52_3, l_52_4, l_52_5)
  l_52_2 = Station
  l_52_2 = l_52_2.SetFocusWindow
  l_52_3 = l_52_1
  l_52_2(l_52_3)
  l_52_2 = true
  return l_52_2
end

l_0_2 = BoxHook
l_0_3 = "EditBox_SetEditTextStruct"
l_0_2[l_0_3] = function(l_53_0, l_53_1)
  l_53_0:ClearText()
  for l_53_5,l_53_6 in ipairs(l_53_1) do
    if l_53_6.type == "text" then
      l_53_0:InsertText(l_53_6.text)
    else
      l_53_0:InsertObj(l_53_6.text, l_53_6)
    end
  end
end

l_0_2 = BoxHook
l_0_3 = "IsEditBoxOpened"
l_0_2[l_0_3] = function()
  local l_54_0 = Station.Lookup("Lowest2/EditBox")
  if l_54_0 and l_54_0:IsVisible() then
    return true
  end
  return false
end

l_0_2 = BoxHook
l_0_3 = "OpenEditBox"
l_0_2[l_0_3] = function()
  local l_55_0 = Station.Lookup("Lowest2/EditBox")
  if not l_55_0:IsVisible() then
    l_55_0:Show()
  end
  Station.SetFocusWindow(l_55_0:Lookup("Edit_Input"))
end

l_0_2 = BoxHook
l_0_3 = "GetPing"
l_0_2[l_0_3] = function()
  if BoxHook.nPingTime == 0 then
    local l_56_0 = math.floor
    local l_56_1 = GetPingValue() / 2
    return l_56_0(l_56_1)
  end
  return BoxHook.nPingTime
end

l_0_3 = BoxHook
local l_0_4 = "GetNearbyPlayerList"
l_0_3[l_0_4] = function()
  -- upvalues: l_0_2
  local l_57_0 = {}
  for l_57_4,l_57_5 in pairs(l_0_2) do
    table.insert(l_57_0, l_57_5)
  end
  return l_57_0
end

l_0_3 = BoxHook
l_0_4 = "GetAllPlayer"
l_0_3[l_0_4] = function()
  -- upvalues: l_0_2
  local l_58_0 = {}
  for l_58_4,l_58_5 in pairs(l_0_2) do
    local l_58_6 = GetPlayer(l_58_5)
    if l_58_6 then
      table.insert(l_58_0, l_58_6)
    end
  end
  return l_58_0
end

l_0_3 = BoxHook
l_0_4 = "GetPlayerByName"
l_0_3[l_0_4] = function(l_59_0)
  -- upvalues: l_0_2
  for l_59_4,l_59_5 in pairs(l_0_2) do
    local l_59_6 = GetPlayer(l_59_5)
    if l_59_6 and l_59_6.szName == l_59_0 then
      return l_59_6
    end
  end
end

l_0_3 = RegisterEvent
l_0_4 = "PLAYER_ENTER_SCENE"
l_0_3(l_0_4, function()
  -- upvalues: l_0_2
  local l_60_0 = l_0_2
  local l_60_1 = arg0
  l_60_0[l_60_1] = arg0
end
)
l_0_3 = RegisterEvent
l_0_4 = "PLAYER_LEAVE_SCENE"
l_0_3(l_0_4, function()
  -- upvalues: l_0_2
  l_0_2[arg0] = nil
end
)
l_0_4 = function()
  -- upvalues: l_0_3
  local l_62_0 = {}
  for l_62_4,l_62_5 in pairs(l_0_3) do
    table.insert(l_62_0, l_62_5)
  end
  return l_62_0
end

BoxHook.GetNearbyNpcList = l_0_4
BoxHook.GetNpcList = l_0_4
local l_0_5 = BoxHook
local l_0_6 = "GetAllNpc"
l_0_5[l_0_6] = function()
  -- upvalues: l_0_3
  local l_63_0 = {}
  for l_63_4,l_63_5 in pairs(l_0_3) do
    local l_63_6 = GetNpc(l_63_5)
    if l_63_6 then
      table.insert(l_63_0, l_63_6)
    end
  end
  return l_63_0
end

l_0_5 = RegisterEvent
l_0_6 = "NPC_ENTER_SCENE"
l_0_5(l_0_6, function()
  -- upvalues: l_0_3
  local l_64_0 = l_0_3
  local l_64_1 = arg0
  l_64_0[l_64_1] = arg0
end
)
l_0_5 = RegisterEvent
l_0_6 = "NPC_LEAVE_SCENE"
l_0_5(l_0_6, function()
  -- upvalues: l_0_3
  l_0_3[arg0] = nil
end
)
l_0_6 = BoxHook
local l_0_7 = "GetNearbyDoodadList"
l_0_6[l_0_7] = function()
  -- upvalues: l_0_5
  local l_66_0 = {}
  for l_66_4,l_66_5 in pairs(l_0_5) do
    table.insert(l_66_0, l_66_5)
  end
  return l_66_0
end

l_0_6 = RegisterEvent
l_0_7 = "DOODAD_ENTER_SCENE"
l_0_6(l_0_7, function()
  -- upvalues: l_0_5
  local l_67_0 = l_0_5
  local l_67_1 = arg0
  l_67_0[l_67_1] = arg0
end
)
l_0_6 = RegisterEvent
l_0_7 = "DOODAD_LEAVE_SCENE"
l_0_6(l_0_7, function()
  -- upvalues: l_0_5
  l_0_5[arg0] = nil
end
)
l_0_7 = BoxHook
local l_0_8 = "DelayCall"
l_0_7[l_0_8] = function(l_69_0, l_69_1)
  -- upvalues: l_0_6
  local l_69_2 = table.insert
  local l_69_3 = l_0_6
  local l_69_4 = {}
  l_69_4.fnAction = l_69_1
  l_69_4.time = GetTickCount() + l_69_0 * 1000
  l_69_2(l_69_3, l_69_4)
end

l_0_8 = function(l_70_0, l_70_1, l_70_2, l_70_3)
  -- upvalues: l_0_7
  local l_70_4 = l_0_7
  local l_70_5 = {}
  l_70_5.path = l_70_1
  l_70_5.name = l_70_2
  l_70_5.fn = l_70_3
  l_70_4[l_70_0] = l_70_5
end

RegisterFrameHook = l_0_8
l_0_8 = function(l_71_0)
  -- upvalues: l_0_7
  local l_71_1 = l_0_7[l_71_0]
  if not l_71_1 then
    return 
  end
  l_71_1.bUnRegister = true
  local l_71_2 = Station.Lookup(unpack(l_71_1.path))
  if l_71_2 and l_71_2[l_71_1.name] then
    l_71_2[l_71_1.name] = nil
  end
  l_0_7[l_71_0] = nil
end

UnRegisterFrameHook = l_0_8
l_0_8 = RegisterEvent
l_0_8("Breathe", function()
  -- upvalues: l_0_6 , l_0_7
  BoxHook.nPingValue = BoxHook.nPingValue * 0.95 + GetPingValue() * 0.05
  BoxHook.nPingTime = math.floor(BoxHook.nPingValue / 2)
  for l_72_3,l_72_4 in pairs(l_0_6) do
    do
      local l_72_5 = GetTickCount()
      if l_72_4.time <= l_72_5 then
        local l_72_6 = l_72_4.fnAction
        table.remove(l_0_6, l_72_3)
        l_72_6()
      end
    end
  end
  for l_72_10,l_72_11 in pairs(l_0_7) do
    if not l_72_11.bUnRegister then
      local l_72_12 = Station.Lookup(unpack(l_72_11.path))
    end
    if l_72_12 and not l_72_12[l_72_11.name] then
      if l_72_11.fn then
        local l_72_13 = l_72_11.name
        l_72_12[l_72_13] = l_72_11.fn
      end
    else
      local l_72_14 = l_72_11.name
      l_72_12[l_72_14] = function()
        -- upvalues: l_72_3
        FireUIEvent("BOX_FRAME_HOOK", l_72_3)
      end
    end
  end
end
)
RegisterPlayerMenu = function(l_73_0, l_73_1)
  -- upvalues: l_0_8
  l_0_8[l_73_0] = l_73_1
end

if Player_AppendAddonMenu then
  RegisterEvent("AddonLoad", function()
  -- upvalues: l_0_8
  if not IsEmpty(l_0_8) then
    for l_74_3,l_74_4 in table.pairsByKeys(l_0_8) do
      local l_74_5 = Player_AppendAddonMenu
      local l_74_6 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_74_5(l_74_6)
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
else
  local l_0_10 = function()
  -- upvalues: l_0_8
  local l_75_0 = {}
  InsertPlayerMenu(l_75_0)
  local l_75_1 = {}
  if not IsEmpty(l_0_8) then
    for l_75_5,l_75_6 in table.pairsByKeys(l_0_8) do
      local l_75_7 = l_75_6()
      if l_75_7 and type(l_75_7) == "table" and #l_75_7 > 0 then
        for l_75_11,l_75_12 in pairs(l_75_7) do
          table.insert(l_75_1, l_75_12)
        end
      end
    end
  end
  if not IsEmpty(l_75_1) then
    local l_75_13 = nil
    local l_75_14 = nil
    local l_75_15 = nil
    table.insert(l_75_13, l_75_14)
    l_75_14 = {bDevide = true}
     -- DECOMPILER ERROR: Overwrote pending register.

    for l_75_15,i_2 in ipairs(l_75_13) do
      local l_75_17 = nil
      l_75_17 = table
      l_75_17 = l_75_17.insert
      l_75_17(l_75_0, l_75_16)
    end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_75_0 and #l_75_0 > 0 then
    PopupMenu(l_75_13)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

  local l_0_11 = RegisterFrameHook
  local l_0_12 = "hookplayermenu"
  l_0_11(l_0_12, {"Normal/Player", ""}, "OnItemRButtonDown", l_0_10)
end
local l_0_13 = {}
RegisterTraceButtonMenu = function(l_76_0, l_76_1)
  -- upvalues: l_0_9
  l_0_9[l_76_0] = l_76_1
end

RegisterEvent("AddonLoad", function()
  -- upvalues: l_0_9
  if not IsEmpty(l_0_9) then
    for l_77_3,l_77_4 in table.pairsByKeys(l_0_9) do
      local l_77_5 = TraceButton_AppendAddonMenu
      local l_77_6 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_77_5(l_77_6)
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
local l_0_14 = {}
RegisterTargetMenu = function(l_78_0, l_78_1)
  -- upvalues: l_0_10
  l_0_10[l_78_0] = l_78_1
end

if Target_AppendAddonMenu then
  RegisterEvent("AddonLoad", function()
  -- upvalues: l_0_10
  if not IsEmpty(l_0_10) then
    for l_79_3,l_79_4 in table.pairsByKeys(l_0_10) do
      local l_79_5 = Target_AppendAddonMenu
      local l_79_6 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_79_5(l_79_6)
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
else
  local l_0_16 = {}
  local l_0_17 = function()
  -- upvalues: l_0_10
  local l_80_0 = {}
  local l_80_1 = Station.Lookup("Normal/Target")
  local l_80_2 = {}
  if not IsEmpty(l_0_10) then
    for l_80_6,l_80_7 in table.pairsByKeys(l_0_10) do
      local l_80_8 = l_80_7(l_80_1.dwID, l_80_1.dwType)
      if l_80_8 and type(l_80_8) == "table" and #l_80_8 > 0 then
        for l_80_12,l_80_13 in pairs(l_80_8) do
          table.insert(l_80_2, l_80_13)
        end
      end
    end
  end
  if not IsEmpty(l_80_2) then
    for l_80_17,l_80_18 in ipairs(l_80_2) do
      local l_80_18 = nil
      l_80_18 = table
      l_80_18 = l_80_18.insert
      l_80_18(l_80_0, l_80_17)
    end
    local l_80_19, l_80_21 = nil
    local l_80_20, l_80_22 = nil
    do
      local l_80_23 = nil
    end
    table.insert(l_80_19, {bDevide = true})
  end
  InsertTargetMenu(l_80_0)
  if l_80_0 and #l_80_0 > 0 then
    PopupMenu(l_80_0)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

  local l_0_18 = RegisterFrameHook
  l_0_18("hooktargetmenu", {"Normal/Target", ""}, "OnItemRButtonDown", l_0_17)
end
MiddleMapShowMap = MiddleMap.ShowMap
local l_0_19 = nil
local l_0_20 = nil
MiddleMap.ShowMap = function(...)
  MiddleMapShowMap(...)
  FireEvent("OnMiddleMapShowMap")
end

UpdateCurrentMap = MiddleMap.UpdateCurrentMap
MiddleMap.UpdateCurrentMap = function(...)
  UpdateCurrentMap(...)
  FireEvent("OnMiddleMapUpdateCurrentMap")
end

local l_0_21 = "ui/Image/UICommon/Talk_face.UITex"
local l_0_22 = 10
local l_0_23 = {}
GetFaceIconCommand = function(l_83_0)
  -- upvalues: l_0_13
  for l_83_4,l_83_5 in pairs(l_0_13) do
    if l_83_5.nFrame == l_83_0 then
      return l_83_5.szCommand
    end
  end
end

local l_0_24 = {}
local l_0_25 = {}
BoxHook.Table_GetFaceIconList = function()
  local l_84_0 = {}
  local l_84_1 = g_tTable.FaceIcon:GetRowCount()
  for l_84_5 = 1, l_84_1 do
    local l_84_6 = g_tTable.FaceIcon:GetRow(l_84_5)
    table.insert(l_84_0, l_84_6)
  end
  return l_84_0
end

function()
  -- upvalues: l_0_13 , l_0_14 , l_0_15
  l_0_13 = Table_GetFaceIconList()
  l_0_14 = {}
  l_0_15 = {}
  for l_85_3,l_85_4 in ipairs(l_0_13) do
    l_0_15[l_85_4.szCommand] = l_85_3
    local l_85_5 = table.insert
    local l_85_6 = l_0_14
    local l_85_7 = {}
    l_85_7.nFaceID = l_85_3
    l_85_7.nLen = string.len(l_85_4.szCommand)
    l_85_5(l_85_6, l_85_7)
  end
  table.sort(l_0_14, function(l_86_0, l_86_1)
    return l_86_1.nLen < l_86_0.nLen
  end)
end
()
local l_0_26 = nil
local l_0_27 = function(l_86_0)
  -- upvalues: l_0_14 , l_0_15
  local l_86_1 = {}
  local l_86_2 = 1
  local l_86_3 = 0
  local l_86_4 = ""
  local l_86_5 = string.len(l_86_0)
  local l_86_6 = l_0_14[1].nLen
  do
    repeat
      if l_86_2 <= l_86_5 then
        local l_86_8, l_86_9 = function(l_87_0)
    -- upvalues: l_86_3 , l_86_1
    if not l_87_0 or l_87_0 == "" then
      return 
    end
    if l_86_3 ~= 0 and l_86_1[l_86_3].type == "text" then
      l_86_1[l_86_3].text = l_86_1[l_86_3].text .. l_87_0
    else
      local l_87_1 = table.insert
      local l_87_2 = l_86_1
      local l_87_3 = {}
      l_87_3.text = l_87_0
      l_87_3.type = "text"
      l_87_1(l_87_2, l_87_3)
      l_87_1 = l_86_3
      l_87_1 = l_87_1 + 1
      l_86_3 = l_87_1
    end
  end, StringFindW(l_86_0, "#", l_86_2)
        if not l_86_9 then
          l_86_4 = string.sub(l_86_0, l_86_2)
          l_86_8(l_86_4)
        end
      elseif l_86_2 < l_86_9 then
        l_86_4 = string.sub(l_86_0, l_86_2, l_86_9 - 1)
        l_86_8(l_86_4)
      end
      local l_86_10 = nil
      for l_86_14 = l_86_6 - 1, 1, -1 do
        local l_86_11 = false
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_86_4 = string.sub(l_86_0, l_86_9, l_86_9 + R14_PC54)
        if l_86_4 and l_0_15[l_86_4] then
          local l_86_16 = table.insert
          do
            local l_86_17 = l_86_1
            l_86_16(l_86_17, {text = l_86_4, type = "faceicon"})
            l_86_3 = l_86_3 + 1
            l_86_16 = l_86_9 + l_86_15
            l_86_2 = l_86_16 + 1
            l_86_11 = true
          end
          do break end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

    until not l_86_11
    l_86_2 = l_86_9 + 1
  end
  return l_86_1
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

BoxHook.EmotionPanel_ParseBallonText = function(l_87_0, l_87_1, l_87_2, l_87_3)
  -- upvalues: l_0_11 , l_0_17 , l_0_12 , l_0_15 , l_0_13
  local l_87_4 = ""
  local l_87_5 = "<animate>path=" .. EncodeComponentsString(l_0_11) .. " disablescale=1 group="
  local l_87_6 = " </animate>"
  local l_87_7 = "<image>path=" .. EncodeComponentsString(l_0_11) .. " disablescale=1 frame="
  local l_87_8 = " </image>"
  local l_87_9 = l_0_17(l_87_0)
  local l_87_10 = 0
  for l_87_14,l_87_15 in ipairs(l_87_9) do
    if l_87_15.type == "faceicon" then
      if l_87_10 < l_0_12 then
        local l_87_16 = l_0_15[l_87_15.text]
        local l_87_17 = l_0_13[l_87_16].nFrame
        local l_87_18 = l_0_13[l_87_16].szType
        if l_87_18 == "animate" then
          l_87_4 = l_87_4 .. l_87_5 .. l_87_17 .. l_87_6
        elseif l_87_18 == "image" then
          l_87_4 = l_87_4 .. l_87_7 .. l_87_17 .. l_87_8
        end
      else
        l_87_4 = l_87_4 .. GetFormatText(l_87_15.text, nil, l_87_1, l_87_2, l_87_3)
      end
      l_87_10 = l_87_10 + 1
    elseif l_87_15.type == "text" then
      l_87_4 = l_87_4 .. GetFormatText(l_87_15.text, nil, l_87_1, l_87_2, l_87_3)
    end
  end
  return l_87_4
end

UpdataItemBoxObject = function(l_88_0, l_88_1, l_88_2, l_88_3)
  if l_88_3 then
    l_88_0:SetObject(UI_OBJECT_ITEM, l_88_3.nUiId, l_88_1, l_88_2, l_88_3.nVersion, l_88_3.dwTabType, l_88_3.dwIndex)
    l_88_0:SetObjectIcon(Table_GetItemIconID(l_88_3.nUiId))
    if l_88_0:IsObjectMouseOver() then
      local l_88_4, l_88_5 = l_88_0:GetAbsPos()
      local l_88_6, l_88_7 = l_88_0:GetSize()
      local l_88_8 = OutputItemTip
      local l_88_9 = UI_OBJECT_ITEM
      local l_88_10 = l_88_1
      local l_88_11 = l_88_2
      local l_88_12 = nil
      local l_88_13 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_88_8(l_88_9, l_88_10, l_88_11, l_88_12, l_88_13)
    end
    if l_88_3.bCanStack and l_88_3.nStackNum > 1 then
      l_88_0:SetOverText(0, l_88_3.nStackNum)
    else
      l_88_0:SetOverText(0, "")
    end
    UpdateItemBoxExtend(l_88_0, l_88_3)
  else
    l_88_0:ClearObject()
    if l_88_0:IsObjectMouseOver() then
      HideTip()
    end
    l_88_0:SetOverText(0, "")
  end
  if not Hand_IsEmpty() then
    local l_88_14 = Hand_Get()
  end
  if l_88_14:GetObjectType() == UI_OBJECT_ITEM then
    local l_88_15, l_88_16, l_88_17 = l_88_14:GetObjectData()
  end
  if l_88_16 == l_88_1 and l_88_17 == l_88_2 then
    if l_88_3 then
      Hand_Pick(l_88_0)
    end
  else
    Hand_Clear()
  end
   -- WARNING: undefined locals caused missing assignments!
end

GetItemNameByItem = function(l_89_0)
  if l_89_0.nGenre == ITEM_GENRE.BOOK then
    local l_89_1, l_89_2 = GlobelRecipeID2BookID(l_89_0.nBookID)
    local l_89_6 = Table_GetSegmentName
    local l_89_7 = l_89_1
    l_89_6 = l_89_6(l_89_7, l_89_2)
    if not l_89_6 then
      l_89_6 = g_tStrings
      l_89_6 = l_89_6.BOOK
      local l_89_5 = nil
    end
    return l_89_6
  else
    local l_89_3 = Table_GetItemName
    local l_89_4 = l_89_0.nUiId
    return l_89_3(l_89_4)
  end
end

GetItemNameByItemInfo = function(l_90_0, l_90_1)
  if l_90_0.nGenre == ITEM_GENRE.BOOK then
    if l_90_1 then
      local l_90_2, l_90_3 = GlobelRecipeID2BookID(l_90_1)
      local l_90_7, l_90_12 = Table_GetSegmentName, l_90_2
      local l_90_8, l_90_13 = l_90_3
      l_90_7 = l_90_7(l_90_12, l_90_8)
      if not l_90_7 then
        l_90_7 = g_tStrings
        l_90_7 = l_90_7.BOOK
        local l_90_6, l_90_11 = nil
      end
      return l_90_7
    else
      local l_90_4 = Table_GetItemName
      local l_90_5 = l_90_0.nUiId
      return l_90_4(l_90_5)
    end
  else
    local l_90_9 = Table_GetItemName
    local l_90_10 = l_90_0.nUiId
    return l_90_9(l_90_10)
  end
end

GetBookTipByItemInfo = function(l_91_0, l_91_1, l_91_2, l_91_3)
  local l_91_4 = ""
  local l_91_5 = GetClientPlayer()
  local l_91_6 = Table_GetBookSort(l_91_1, l_91_2)
  local l_91_7 = GetRecipe(8, l_91_1, l_91_2)
  local l_91_8 = l_91_7.dwRequireProfessionLevel
  l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(Table_GetSegmentName(l_91_1, l_91_2) .. "\n") .. " font=106" .. GetItemFontColorByQuality(l_91_0.nQuality, true) .. " </text>"
  if l_91_0.nGenre == ITEM_GENRE.TASK_ITEM then
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_ITEM_H_QUEST_ITEM) .. " font=106 </text>"
  else
    if l_91_0.nBindType == ITEM_BIND.INVALID then
      do return end
    end
  end
  if l_91_0.nBindType == ITEM_BIND.NEVER_BIND then
    do return end
  end
  if l_91_0.nBindType == ITEM_BIND.BIND_ON_EQUIPPED then
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_ITEM_H_BIND_AFTER_EQUIP) .. " font=106 </text>"
  else
    if l_91_0.nBindType == ITEM_BIND.BIND_ON_PICKED then
      l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_ITEM_H_BIND_AFTER_PICK) .. " font=106 </text>"
    end
  end
  l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_CRAFT_READ_BOOK_SORT_NAME_TABLE[Table_GetBookSort(l_91_1, l_91_2)] .. "\n") .. " font=106 </text> "
  if l_91_7.dwRequireProfessionLevel <= l_91_5.GetProfessionLevel(8) then
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.CRAFT_READING_REQUIRE_LEVEL1, l_91_8)) .. " font=106 </text>"
  else
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.CRAFT_READING_REQUIRE_LEVEL1, l_91_8)) .. " font=166 </text>"
  end
  if l_91_7.nStamina <= l_91_5.nCurrentStamina then
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.STR_CRAFT_COST_STAMINA_ENTER, l_91_7.nStamina)) .. " font=106 </text>"
  else
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.STR_CRAFT_COST_STAMINA_ENTER, l_91_7.nStamina)) .. " font=166 </text>"
  end
  if l_91_3 then
    if l_91_5.IsBookMemorized(l_91_1, l_91_2) then
      l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.TIP_ALREADY_READ) .. " font=108 </text>"
    end
  else
    l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.TIP_UNREAD) .. " font=105 </text>"
  end
  l_91_4 = l_91_4 .. "<Text>text=" .. EncodeComponentsString(Table_GetBookDesc(l_91_1, l_91_2) .. "\n") .. " font=163 </text>"
  return l_91_4
end

BoxHook.Table_GetMKungfuList = function(l_92_0)
  local l_92_1 = g_tTable.MKungfuKungfu:Search(l_92_0)
  local l_92_2 = {}
  if l_92_1 and l_92_1.szKungfu then
    local l_92_3 = l_92_1.szKungfu
    for l_92_7 in string.gmatch(l_92_3, "%d+") do
      local l_92_8 = tonumber(l_92_7)
      if l_92_8 then
        table.insert(l_92_2, l_92_8)
      end
    end
  end
  return l_92_2
end

BoxHook.Table_GetKungfuSkillList = function(l_93_0)
  local l_93_1 = {}
  local l_93_2 = g_tTable.KungfuSkill:Search(l_93_0)
  if l_93_2 then
    local l_93_3 = l_93_2.szSkill
    for l_93_7 in string.gmatch(l_93_3, "%d+") do
      local l_93_8 = tonumber(l_93_7)
      if l_93_8 then
        table.insert(l_93_1, l_93_8)
      end
    end
  end
  return l_93_1
end

g_BoxSkillNameToID = {}
local l_0_28 = function(l_94_0, l_94_1)
  local l_94_2 = GetClientPlayer()
  if not l_94_2 then
    return 
  end
  local l_94_3 = Table_GetSkill(l_94_0, l_94_1)
  if not l_94_3 then
    return 
  end
  if l_94_3.dwSkillRelyOnShow > 0 and l_94_2.GetSkillLevel(l_94_3.dwSkillRelyOnShow) <= 0 then
    return false
  end
  if l_94_3.dwSkillRelyOnNotShow > 0 and l_94_2.GetSkillLevel(l_94_3.dwSkillRelyOnNotShow) > 0 then
    return false
  end
  return true
end

RegisterEvent("SYNC_ROLE_DATA_END", function(l_95_0, l_95_1)
  -- upvalues: l_0_18
  local l_95_2 = GetClientPlayer()
  if not l_95_2 then
    return 
  end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_95_0 and l_95_1 and l_95_1 > 0 and Table_IsSkillShow(l_95_0, l_95_1) then
    local l_95_3 = Table_GetSkillName(l_95_0, l_95_1)
  end
  if l_95_3 then
    g_BoxSkillNameToID[l_95_3] = l_95_0
  end
  do return end
  if not l_95_2.GetAllSkillList() then
    local l_95_4, l_95_5 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_95_9,l_95_10 in pairs(l_95_4) do
    local l_95_6 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if Table_IsSkillShow(l_95_10, R8_PC37) and Table_GetSkillName(l_95_10, R8_PC37) then
      g_BoxSkillNameToID[Table_GetSkillName(l_95_10, R8_PC37)] = l_95_10
    end
  end
  local l_95_12 = l_95_2.GetKungfuMount()
  local l_95_13 = Table_GetMKungfuList(l_95_12.dwSkillID)
  do break end
  local l_95_14, l_95_15, l_95_16, l_95_17, l_95_18 = ipairs(l_95_13)
  local l_95_19 = Table_GetKungfuSkillList(l_95_18)
  for l_95_23,l_95_24 in pairs(l_95_19) do
    do
      local l_95_25, l_95_26, l_95_27 = l_95_2.GetSkillLevel(l_95_24) or 0
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_0_18(l_95_24, l_95_25) then
      g_BoxSkillNameToID[Table_GetSkillName(l_95_24, l_95_25)] = l_95_24
    end
  end
end
end
)
RegisterEvent("PLAYER_ENTER_GAME", function()
  g_BoxSkillNameToID = {}
  local l_96_0 = g_tTable.Skill:GetRowCount()
  for l_96_4 = 1, l_96_0 do
    local l_96_5 = g_tTable.Skill:GetRow(l_96_4)
    if l_96_5.bShow and l_96_5.dwSkillID > 0 and not g_BoxSkillNameToID[l_96_5.szName] then
      local l_96_6 = GetSkill(l_96_5.dwSkillID, 1)
    end
    if l_96_6 and l_96_6.dwBelongSchool >= 0 and l_96_6.dwBelongSchool <= 10 then
      local l_96_7 = g_BoxSkillNameToID
      local l_96_8 = l_96_5.szName
      l_96_7[l_96_8] = l_96_5.dwSkillID
    end
  end
end
)
RegisterEvent("SKILL_UPDATE", function()
  -- upvalues: l_0_19
  l_0_19(arg0, arg1)
end
)
BoxGetSkillID = function(l_98_0)
  return g_BoxSkillNameToID[l_98_0]
end

local l_0_29 = nil
RegisterEvent("Breathe", function()
  -- upvalues: l_0_21 , l_0_22
  local l_99_0 = Station.Lookup("Topmost1/TipPanel_Normal")
  if not l_99_0 then
    return 
  end
  local l_99_1 = l_99_0:Lookup("", "Handle_Message")
  l_99_1.AppendItemFromStringOrg = l_99_1.AppendItemFromString
  l_99_1.AppendItemFromString = function(l_100_0, l_100_1)
    -- upvalues: l_0_21
    local l_100_2 = {}
    for l_100_6,l_100_7 in ipairs(l_0_21) do
      if l_100_7.fnCondition() then
        local l_100_8 = l_100_7.fnAppend(l_100_1)
      end
      if l_100_8 then
        local l_100_15 = table.insert
        local l_100_16 = l_100_2
        local l_100_17 = l_100_8
        l_100_15(l_100_16, l_100_17)
      end
    end
    local l_100_9, l_100_10 = l_100_0:AppendItemFromStringOrg, l_100_0
    local l_100_13 = l_100_1
    local l_100_14 = table.concat
    l_100_14 = l_100_14(l_100_2, "")
    local l_100_12 = nil
    l_100_13 = l_100_13 .. l_100_14
    local l_100_11 = nil
    return l_100_9(l_100_10, l_100_13)
  end
  UnRegisterEvent("Breathe", l_0_22)
end
)
RegisterTipFunc = function(l_100_0, l_100_1, l_100_2)
  -- upvalues: l_0_21
  local l_100_3 = table.insert
  local l_100_4 = l_0_21
  local l_100_5 = {}
  l_100_5.fnCondition = l_100_0
  l_100_5.fnAppend = l_100_1
  local l_100_6 = nil
  if not l_100_2 then
    l_100_6 = 0
  end
  l_100_5.nLevel = l_100_6
  l_100_3(l_100_4, l_100_5)
  l_100_3 = table
  l_100_3 = l_100_3.sort
  l_100_4 = l_0_21
  l_100_5 = function(l_101_0, l_101_1)
    return l_101_1.nLevel < l_101_0.nLevel
  end
  l_100_3(l_100_4, l_100_5)
end

GetTipFrames = function()
  local l_101_0 = {}
  local l_101_1 = Station.Lookup("Topmost")
  if l_101_1 then
    local l_101_2 = l_101_1:GetFirstChild()
  end
  if l_101_2 then
    if l_101_2:IsVisible() and l_101_2.bTipLink and not l_101_2.bAppendTip then
      local l_101_3 = string.match(l_101_2:GetName(), "^TL_item(%d+)")
    end
    if l_101_3 then
      local l_101_4 = table.insert
      local l_101_5 = l_101_0
      local l_101_6 = {}
      l_101_6.bItem = true
      l_101_6.frame = l_101_2
      l_101_6.dwItemID = tonumber(l_101_3)
      l_101_4(l_101_5, l_101_6)
    end
    l_101_2 = l_101_2:GetNext()
  end
end
return l_101_0
end

local l_0_31 = nil
do
  local l_0_32 = {}
  RegisterEvent("Breathe", function()
  -- upvalues: l_0_24 , l_0_23
  if GetLogicFrameCount() % 2 == 0 then
    local l_103_0 = GetTipFrames()
    for l_103_4,l_103_5 in ipairs(l_103_0) do
      for l_103_9,l_103_10 in ipairs(l_0_24) do
        if l_103_10.fnAppend(l_103_5) then
          l_0_23(l_103_5.frame, l_103_5.frame.bTipLink)
          l_103_5.frame:CorrectPos()
        end
      end
      l_103_5.frame.bAppendTip = true
    end
  end
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

