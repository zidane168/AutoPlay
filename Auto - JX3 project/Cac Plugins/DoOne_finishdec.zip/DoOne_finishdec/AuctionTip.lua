-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: AuctionTip.lua 

local l_0_0 = {}
l_0_0.bFilter = true
l_0_0.bBook = false
l_0_0.bRecipe = false
l_0_0.nBookLevel = 0
l_0_0.bSkillRecipe = false
l_0_0.bLearnSkillRecipe = false
l_0_0.bAllLearnSkillRecipe = false
l_0_0.tSearchHistory = {}
l_0_0.bShowGuiStone = true
AuctionTip = l_0_0
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bFilter")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bBook")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bRecipe")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.nBookLevel")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bSkillRecipe")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bLearnSkillRecipe")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bAllLearnSkillRecipe")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.tSearchHistory")
l_0_0 = RegisterCustomData
l_0_0("AuctionTip.bShowGuiStone")
l_0_0 = AuctionTip
local l_0_1 = {}
l_0_1.Physics = false
l_0_1.Neigong = false
l_0_1.Poison = false
l_0_1.Lunar = false
l_0_1.Solar = false
l_0_1.Neutral = false
l_0_1.Therapy = false
l_0_0.tSpiStoneAttr = l_0_1
l_0_0 = AuctionTip
l_0_0.MoonSun = false
l_0_0 = RegisterCustomData
l_0_1 = "AuctionTip.MoonSun"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "AuctionTip.tSpiStoneAttr"
l_0_0(l_0_1)
l_0_0 = AuctionTip
l_0_0.nDiamondTypeOne = 5
l_0_0 = AuctionTip
l_0_0.nDiamondTypeTwo = 5
l_0_0 = RegisterCustomData
l_0_1 = "AuctionTip.nDiamondTypeOne"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "AuctionTip.nDiamondTypeTwo"
l_0_0(l_0_1)
l_0_0 = false
l_0_1 = AuctionTip
l_0_1.OnCreate = function(l_1_0)
  local l_1_1 = BoxCheckBox
  local l_1_2 = l_1_0
  local l_1_3 = "CheckBox_Filter"
  local l_1_4 = {}
  l_1_4.txt = "���������и�������"
  l_1_1 = l_1_1(l_1_2, l_1_3, l_1_4)
  l_1_2, l_1_3 = l_1_1:SetBoolValue, l_1_1
  l_1_4 = AuctionTip
  l_1_2(l_1_3, l_1_4, "bFilter")
  l_1_2, l_1_3 = l_1_1:OnCheck, l_1_1
  l_1_4 = function()
    local l_2_0 = Station.Lookup("Normal/AuctionPanel")
    if l_2_0 then
      l_2_0:Lookup("PageSet_Totle/Page_Business/ComboBox_Filter"):Show()
    end
  end
  l_1_2(l_1_3, l_1_4)
  l_1_2, l_1_3 = l_1_1:UnCheck, l_1_1
  l_1_4 = function()
    local l_3_0 = Station.Lookup("Normal/AuctionPanel")
    if l_3_0 then
      l_3_0:Lookup("PageSet_Totle/Page_Business/ComboBox_Filter"):Hide()
    end
  end
  l_1_2(l_1_3, l_1_4)
  l_1_2 = BoxBoolCheckBox
  l_1_3 = l_1_0
  l_1_4 = "CheckBox_bShowGuiStone"
  l_1_2 = l_1_2(l_1_3, l_1_4, "�鿴��ʯ����װ��", AuctionTip, "bShowGuiStone")
  l_1_2, l_1_3 = l_1_2:SetRelPos, l_1_2
  l_1_4 = 0
  l_1_2(l_1_3, l_1_4, 30)
end

l_0_1 = RegisterMoonButton
l_0_1("AuctionTip", 2598, "������", "General", AuctionTip.OnCreate)
local l_0_2 = {}
l_0_2.Key = "Physics"
l_0_2.Content = "�⹦"
local l_0_3 = {}
l_0_3.Key = "Neigong"
l_0_3.Content = "�ڹ�"
local l_0_4 = {}
l_0_4.Key = "Lunar"
l_0_4.Content = "����"
local l_0_5 = {}
l_0_5.Key = "Solar"
l_0_5.Content = "����"
local l_0_6 = {}
l_0_6.Key = "Poison"
l_0_6.Content = "����"
local l_0_7 = {}
l_0_7.Key = "Neutral"
l_0_7.Content = "��Ԫ��"
local l_0_8 = {}
l_0_8.Key = "Therapy"
l_0_8.Content = "����"
l_0_2 = "UI/Config/Default/AuctionItem.ini"
l_0_3 = AuctionPanel
l_0_4 = function(l_2_0, l_2_1, l_2_2)
  -- upvalues: l_0_1 , l_0_2
  if not l_2_2 then
    l_2_2 = {}
  end
  local l_2_3 = (GetClientPlayer())
  local l_2_4, l_2_5 = nil, nil
  if l_2_1 == "Search" then
    l_2_4 = l_2_0:Lookup("PageSet_Totle/Page_Business/Wnd_Result2", "Handle_List")
    l_2_5 = "Handle_ItemList"
  elseif l_2_1 == "Bid" then
    l_2_4 = l_2_0:Lookup("PageSet_Totle/Page_State/Wnd_Bid", "Handle_BidList")
    l_2_5 = "Handle_BidItemList"
  elseif l_2_1 == "Sell" then
    l_2_4 = l_2_0:Lookup("PageSet_Totle/Page_Auction/Wnd_Auction", "Handle_AList")
    l_2_5 = "Handle_AItemList"
  end
  l_2_4:Clear()
  local l_2_6 = 0
  local l_2_7 = 0
  for l_2_11,l_2_12 in pairs(l_2_2) do
    if l_2_12.Item then
      l_2_7 = l_2_7 + 1
      local l_2_13 = true
      if AuctionTip.bFilter and l_2_1 == "Search" then
        local l_2_14 = l_2_12.Item
        if l_2_14.nGenre == 4 then
          local l_2_15, l_2_16 = GlobelRecipeID2BookID(l_2_14.nBookID)
          if AuctionTip.bBook then
            l_2_13 = not l_2_3.IsBookMemorized(l_2_15, l_2_16)
          end
        end
        if AuctionTip.nBookLevel ~= 0 then
          local l_2_17 = GetRecipe(8, l_2_15, l_2_16)
          local l_2_18 = l_2_17.dwRequireProfessionLevel
        if l_2_18 >= AuctionTip.nBookLevel then
          end
        if l_2_18 >= AuctionTip.nBookLevel then
          end
        end
        l_2_13 = false
      elseif l_2_14.nGenre == 3 then
        if l_2_14.nSub == ITEM_SUBTYPE_RECIPE and AuctionTip.bRecipe then
          l_2_13 = not IsMystiqueRecipeRead(l_2_14)
        else
          if l_2_14.nSub == ITEM_SUBTYPE_SKILL_RECIPE then
            local l_2_19, l_2_20 = IsMystiqueSkillRead(l_2_14)
            if AuctionTip.bSkillRecipe and l_2_20 then
              l_2_13 = false
            end
          end
        end
        if (AuctionTip.bLearnSkillRecipe and l_2_19) or AuctionTip.bAllLearnSkillRecipe then
          l_2_13 = false
        end
      elseif l_2_14.nGenre == 11 then
        local l_2_21 = Table_GetItemDesc(l_2_14.nUiId)
        local l_2_22 = tonumber(string.match(l_2_21, "<SpiStone (%d+)>"))
        local l_2_23 = GetFEAInfoByEnchantID(l_2_22)
      end
      if l_2_23 and #l_2_23 > 0 then
        local l_2_24 = {}
        for l_2_28,l_2_29 in pairs(l_2_23) do
          local l_2_30 = Table_GetMagicAttributeInfo(l_2_29.nID, true)
          local l_2_31 = true
          for l_2_35,l_2_36 in ipairs(l_0_1) do
            if AuctionTip.tSpiStoneAttr[l_2_36.Key] and StringFindW(l_2_30, l_2_36.Content) then
              l_2_31 = false
              do break end
            end
          end
          if AuctionTip.MoonSun and StringFindW(l_2_30, "����") then
            l_2_31 = false
          end
          if not l_2_31 then
            l_2_13 = false
            do break end
          end
          if l_2_29.nDiamondType ~= 5 then
            l_2_24[l_2_29.nDiamondType] = true
          end
        end
      end
      if not IsEmpty(l_2_24) and l_2_13 then
        if not l_2_24[AuctionTip.nDiamondTypeTwo] and AuctionTip.nDiamondTypeOne == 5 and AuctionTip.nDiamondTypeTwo ~= 5 then
          l_2_13 = false
        end
      else
        if not l_2_24[AuctionTip.nDiamondTypeOne] and AuctionTip.nDiamondTypeTwo == 5 and AuctionTip.nDiamondTypeOne ~= 5 then
          l_2_13 = false
        end
      else
        if AuctionTip.nDiamondTypeOne ~= 5 and AuctionTip.nDiamondTypeTwo ~= 5 then
          if l_2_24[AuctionTip.nDiamondTypeOne] and l_2_24[AuctionTip.nDiamondTypeTwo] then
            l_2_13 = true
          end
        end
      else
        l_2_13 = false
      end
      if l_2_13 then
        local l_2_37 = l_2_4:AppendItemFromIni(l_0_2, l_2_5)
        AuctionPanel.SetSaleInfo(l_2_37, l_2_1, l_2_12)
        AuctionTip.AppendGuiStoneBox(l_2_37, l_2_12.Item)
        l_2_6 = l_2_6 + 1
      end
    else
      Trace("KLUA[ERROR] ui/Config/Default/AuctionPanel.lua UpdateItemList item is nil!!\n")
    end
  end
  AuctionPanel.OnUpdateItemList(l_2_4, l_2_1, true)
  AuctionPanel.UpdateItemPriceInfo(l_2_4, l_2_1)
  AuctionPanel.UpdateSelectedInfo(l_2_0, l_2_1)
  do
    local l_2_38, l_2_39 = l_2_4:GetParent():GetParent()
    l_2_39 = AuctionPanel
    l_2_39 = l_2_39.OnItemDataInfoUpdate
    l_2_39(l_2_38, l_2_1)
    l_2_39 = AuctionTip
    l_2_39 = l_2_39.bFilter
    if l_2_39 and l_2_7 > 0 and l_2_6 == 0 then
      l_2_39 = OutputMessage
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_2_39("MSG_ANNOUNCE_YELLOW", "��ҳ�Ѿ���<���ӽ�����>ȫ�����ˣ�������һҳ��")
  end
end

l_0_3.UpdateItemList = l_0_4
l_0_3 = AuctionTip
l_0_4 = function(l_3_0, l_3_1)
  if not AuctionTip.bShowGuiStone then
    return 
  end
  local l_3_2 = Table_GetItemDesc(l_3_1.nUiId)
  if not string.find(l_3_2, "�ɶ������") then
    return 
  end
  local l_3_3 = 1
  string.gsub(l_3_2, "this%.dwTabType=(%d+) this%.dwIndex=(%d+)", function(l_4_0, l_4_1)
    -- upvalues: l_3_0 , l_3_3
    l_4_0 = tonumber(l_4_0)
    local l_4_2 = GetItemInfo(l_4_0, l_4_1)
    l_3_0:AppendItemFromString("<box>w=25 h=25 eventid=524607 </box>")
    local l_4_3 = l_3_0:Lookup(l_3_0:GetItemCount() - 1)
    if l_3_3 == 1 then
      l_4_3:SetRelPos(182, 17)
    else
      l_4_3:SetRelPos(208, 17)
    end
    l_4_3:SetObject(UI_OBJECT_ITEM_INFO, GLOBAL.CURRENT_ITEM_VERSION, l_4_0, l_4_1)
    local l_4_4 = Table_GetItemIconID(l_4_2.nUiId)
    l_4_3:SetObjectIcon(l_4_4)
    l_4_3.dwTabType = l_4_0
    l_4_3.dwIndex = l_4_1
    UpdateItemBoxExtend(l_4_3, l_4_2)
    l_4_3.OnItemMouseEnter = function()
      local l_5_0, l_5_1 = this:GetAbsPos()
      local l_5_2, l_5_3 = this:GetSize()
      local l_5_4 = this.dwTabType
      local l_5_5 = this.dwIndex
      local l_5_6 = OutputItemTip
      local l_5_7 = UI_OBJECT_ITEM_INFO
      local l_5_8 = GLOBAL.CURRENT_ITEM_VERSION
      local l_5_9 = l_5_4
      local l_5_10 = l_5_5
      do
        local l_5_11 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_5_6(l_5_7, l_5_8, l_5_9, l_5_10, l_5_11)
      end
       -- WARNING: undefined locals caused missing assignments!
    end
    l_4_3.OnItemMouseLeave = function()
      HideTip()
    end
    l_3_0:FormatAllItemPos()
    l_3_3 = l_3_3 + 1
  end)
end

l_0_3.AppendGuiStoneBox = l_0_4
l_0_3 = AuctionPanel
l_0_3 = l_0_3.OnLButtonClick
g_AuctionPanelClick = l_0_3
l_0_3 = AuctionPanel
l_0_4 = function()
  local l_4_0 = this:GetName()
  if l_4_0 == "Btn_Search" then
    local l_4_1 = this:GetParent()
    local l_4_2 = l_4_1:Lookup("Edit_ItemName")
    local l_4_3 = l_4_2:GetText()
  end
  if l_4_3 ~= "��Ʒ����" and l_4_3 ~= "" and not table.hasVal(AuctionTip.tSearchHistory, l_4_3) then
    if #AuctionTip.tSearchHistory == 10 then
      table.remove(AuctionTip.tSearchHistory, 10)
    end
    table.insert(AuctionTip.tSearchHistory, 1, l_4_3)
  end
  g_AuctionPanelClick()
end

l_0_3.OnLButtonClick = l_0_4
l_0_3 = RegisterEvent
l_0_4 = "OPEN_AUCTION"
l_0_5 = function()
  -- upvalues: l_0_0
  local l_5_0 = Station.Lookup("Normal/AuctionPanel")
  local l_5_1 = l_5_0:Lookup("PageSet_Totle/Page_Business/Wnd_Search/")
  if not l_5_1:Lookup("Btn_History") then
    local l_5_2 = BoxButton
    local l_5_3 = l_5_1
    local l_5_4 = "Btn_History"
    local l_5_5 = {}
    l_5_5.x = 148
    l_5_5.y = 30
    l_5_5.w = 25
    l_5_5.h = 25
    l_5_2 = l_5_2(l_5_3, l_5_4, l_5_5)
    l_5_3, l_5_4 = l_5_2:SetAnimateGroup, l_5_2
    l_5_5 = 51
    l_5_3(l_5_4, l_5_5, 52, 46, 53)
    l_5_3, l_5_4 = l_5_2:OnClick, l_5_2
    l_5_5 = function()
      -- upvalues: l_5_1
      local l_6_0 = l_5_1:Lookup("", "Image_ItemNameBg")
      local l_6_1 = l_5_1:Lookup("Edit_ItemName")
      local l_6_2, l_6_3 = l_6_0:GetAbsPos()
      local l_6_4, l_6_5 = l_6_0:GetSize()
      local l_6_6 = {}
      l_6_6.nMiniWidth = l_6_4
      l_6_6.x = l_6_2
      l_6_6.y = l_6_3 + l_6_5
      l_6_6.fnAction = function(l_7_0, l_7_1)
        -- upvalues: l_1_1
        AuctionPanel.bEditItemName = true
        l_1_1:SetText(l_7_0)
      end
      for l_6_10 = 1, #AuctionTip.tSearchHistory do
        local l_6_11 = table.insert
        local l_6_12 = l_6_6
        local l_6_13 = {}
        l_6_13.szOption = AuctionTip.tSearchHistory[l_6_10]
        l_6_13.UserData = AuctionTip.tSearchHistory[l_6_10]
        l_6_11(l_6_12, l_6_13)
      end
      PopupMenu(l_6_6)
    end
    l_5_3(l_5_4, l_5_5)
  end
  local l_5_6 = l_5_0:Lookup("PageSet_Totle/Page_Business")
  if not l_5_6:Lookup("ComboBox_Filter") then
    local l_5_7 = BoxComboBox
    local l_5_8 = l_5_6
    local l_5_9 = "ComboBox_Filter"
    local l_5_10 = {}
    l_5_10.txt = "���ù���"
    l_5_10.x = 620
    l_5_10.y = 0
    l_5_10.w = 115
    l_5_10.h = 25
    l_5_7 = l_5_7(l_5_8, l_5_9, l_5_10)
    l_5_8, l_5_9 = l_5_7:OnClick, l_5_7
    l_5_10 = function()
      local l_7_0 = this:GetParent()
      local l_7_1, l_7_2 = l_7_0:GetAbsPos()
      local l_7_3, l_7_4 = l_7_0:GetSize()
      local l_7_5 = {}
      l_7_5.nMiniWidth = l_7_3
      l_7_5.x = l_7_1
      l_7_5.y = l_7_2 + l_7_4
      local l_7_6 = {}
      l_7_6.szOption = "�鼮����"
      local l_7_7 = {}
      l_7_7.szOption = "�����Ѷ�"
      l_7_7.bCheck = true
      l_7_7.bChecked = AuctionTip.bBook
      l_7_7.fnAction = function()
        AuctionTip.bBook = not AuctionTip.bBook
      end
      local l_7_8 = {}
      l_7_8.szOption = "��ʾ�ȼ�"
      local l_7_9 = {}
      l_7_9.szOption = "���еȼ�"
      l_7_9.bMCheck = true
      l_7_9.bChecked = AuctionTip.nBookLevel == 0
      l_7_9.fnAction = function()
        AuctionTip.nBookLevel = 0
      end
      local l_7_12 = {}
      l_7_12.szOption = "10~20��"
      l_7_12.bMCheck = true
      l_7_12.bChecked = AuctionTip.nBookLevel == 10
      l_7_12.fnAction = function()
        AuctionTip.nBookLevel = 10
      end
      local l_7_15 = {}
      l_7_15.szOption = "20~30��"
      l_7_15.bMCheck = true
      l_7_15.bChecked = AuctionTip.nBookLevel == 20
      l_7_15.fnAction = function()
        AuctionTip.nBookLevel = 20
      end
      local l_7_18 = {}
      l_7_18.szOption = "30~40��"
      l_7_18.bMCheck = true
      l_7_18.bChecked = AuctionTip.nBookLevel == 30
      l_7_18.fnAction = function()
        AuctionTip.nBookLevel = 30
      end
      local l_7_21 = {}
      l_7_21.szOption = "40~50��"
      l_7_21.bMCheck = true
      l_7_21.bChecked = AuctionTip.nBookLevel == 40
      l_7_21.fnAction = function()
        AuctionTip.nBookLevel = 40
      end
      local l_7_24 = {}
      l_7_24.szOption = "50~60��"
      l_7_24.bMCheck = true
      l_7_24.bChecked = AuctionTip.nBookLevel == 50
      l_7_24.fnAction = function()
        AuctionTip.nBookLevel = 50
      end
      local l_7_27 = {}
      l_7_27.szOption = "60~70��"
      l_7_27.bMCheck = true
      l_7_27.bChecked = AuctionTip.nBookLevel == 60
      l_7_27.fnAction = function()
        AuctionTip.nBookLevel = 60
      end
      local l_7_30 = {}
      l_7_30.szOption = "70~80��"
      l_7_30.bMCheck = true
      l_7_30.bChecked = AuctionTip.nBookLevel == 70
      l_7_30.fnAction = function()
        AuctionTip.nBookLevel = 70
      end
      local l_7_33 = {}
      l_7_33.szOption = "80~90��"
      l_7_33.bMCheck = true
      l_7_33.bChecked = AuctionTip.nBookLevel == 80
      l_7_33.fnAction = function()
        AuctionTip.nBookLevel = 80
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_7_9 = AuctionTip
      l_7_9 = l_7_9.bRecipe
      l_7_9 = function()
        AuctionTip.bRecipe = not AuctionTip.bRecipe
      end
      l_7_12 = AuctionTip
      l_7_12 = l_7_12.bSkillRecipe
      l_7_12 = function()
        AuctionTip.bSkillRecipe = not AuctionTip.bSkillRecipe
      end
      l_7_15 = AuctionTip
      l_7_15 = l_7_15.bAllLearnSkillRecipe
      l_7_15 = function()
        AuctionTip.bAllLearnSkillRecipe = not AuctionTip.bAllLearnSkillRecipe
      end
      l_7_18 = AuctionTip
      l_7_18 = l_7_18.bLearnSkillRecipe
      l_7_18 = function()
        AuctionTip.bLearnSkillRecipe = not AuctionTip.bLearnSkillRecipe
      end
      l_7_15, l_7_12, l_7_9, l_7_8 = {szOption = "�����Ѷ�����ѧϰ�ؼ�", bCheck = true, bChecked = l_7_18, fnAction = l_7_18}, {szOption = "�������м���ѧϰ�ؼ�", bCheck = true, bChecked = l_7_15, fnAction = l_7_15}, {szOption = "�����������ؼ�", bCheck = true, bChecked = l_7_12, fnAction = l_7_12}, {szOption = "�����Ѷ�", bCheck = true, bChecked = l_7_9, fnAction = l_7_9}
      l_7_15 = AuctionTip
      l_7_15 = l_7_15.tSpiStoneAttr
      l_7_15 = l_7_15.Therapy
      l_7_15 = function()
        AuctionTip.tSpiStoneAttr.Therapy = not AuctionTip.tSpiStoneAttr.Therapy
      end
      l_7_18 = AuctionTip
      l_7_18 = l_7_18.tSpiStoneAttr
      l_7_18 = l_7_18.Physics
      l_7_18 = function()
        AuctionTip.tSpiStoneAttr.Physics = not AuctionTip.tSpiStoneAttr.Physics
      end
      l_7_21 = AuctionTip
      l_7_21 = l_7_21.tSpiStoneAttr
      l_7_21 = l_7_21.Neigong
      l_7_21 = function()
        AuctionTip.tSpiStoneAttr.Neigong = not AuctionTip.tSpiStoneAttr.Neigong
      end
      l_7_27 = AuctionTip
      l_7_27 = l_7_27.tSpiStoneAttr
      l_7_27 = l_7_27.Poison
      l_7_27 = function()
        AuctionTip.tSpiStoneAttr.Poison = not AuctionTip.tSpiStoneAttr.Poison
      end
      l_7_30 = AuctionTip
      l_7_30 = l_7_30.tSpiStoneAttr
      l_7_30 = l_7_30.Lunar
      l_7_30 = function()
        AuctionTip.tSpiStoneAttr.Lunar = not AuctionTip.tSpiStoneAttr.Lunar
      end
      l_7_33 = AuctionTip
      l_7_33 = l_7_33.tSpiStoneAttr
      l_7_33 = l_7_33.Solar
      l_7_33 = function()
        AuctionTip.tSpiStoneAttr.Solar = not AuctionTip.tSpiStoneAttr.Solar
      end
      local l_7_36 = {}
      l_7_36.szOption = "�����ڹ�"
      l_7_36.bCheck = true
      l_7_36.bChecked = AuctionTip.MoonSun
      l_7_36.fnAction = function()
        AuctionTip.MoonSun = not AuctionTip.MoonSun
      end
      l_7_33, l_7_30, l_7_27, l_7_24, l_7_21, l_7_18, l_7_15, l_7_12 = {szOption = "��Ԫ�ڹ�", bCheck = true, bChecked = AuctionTip.tSpiStoneAttr.Neutral, fnAction = function()
        AuctionTip.tSpiStoneAttr.Neutral = not AuctionTip.tSpiStoneAttr.Neutral
      end}, {szOption = "�����ڹ�", bCheck = true, bChecked = l_7_33, fnAction = l_7_33}, {szOption = "�����ڹ�", bCheck = true, bChecked = l_7_30, fnAction = l_7_30}, {szOption = "�����ڹ�", bCheck = true, bChecked = l_7_27, fnAction = l_7_27}, {bDevide = true}, {szOption = "�����ڹ�", bCheck = true, bChecked = l_7_21, fnAction = l_7_21}, {szOption = "�����⹦", bCheck = true, bChecked = l_7_18, fnAction = l_7_18}, {szOption = "��������", bCheck = true, bChecked = l_7_15, fnAction = l_7_15}
      l_7_21 = AuctionTip
      l_7_21 = l_7_21.nDiamondTypeOne
      l_7_21 = l_7_21 == 0
      l_7_21 = function()
        AuctionTip.nDiamondTypeOne = 0
      end
      l_7_24 = AuctionTip
      l_7_24 = l_7_24.nDiamondTypeOne
      l_7_24 = l_7_24 == 1
      l_7_24 = function()
        AuctionTip.nDiamondTypeOne = 1
      end
      l_7_27 = AuctionTip
      l_7_27 = l_7_27.nDiamondTypeOne
      l_7_27 = l_7_27 == 2
      l_7_27 = function()
        AuctionTip.nDiamondTypeOne = 2
      end
      l_7_30 = AuctionTip
      l_7_30 = l_7_30.nDiamondTypeOne
      l_7_30 = l_7_30 == 3
      l_7_30 = function()
        AuctionTip.nDiamondTypeOne = 3
      end
      l_7_33 = AuctionTip
      l_7_33 = l_7_33.nDiamondTypeOne
      l_7_33 = l_7_33 == 4
      l_7_33 = function()
        AuctionTip.nDiamondTypeOne = 4
      end
      l_7_36 = AuctionTip
      l_7_36 = l_7_36.nDiamondTypeOne
      l_7_36 = l_7_36 == 5
      l_7_36 = function()
        AuctionTip.nDiamondTypeOne = 5
      end
      l_7_33, l_7_30, l_7_27, l_7_24, l_7_21, l_7_18 = {szOption = "����", bMCheck = true, bChecked = l_7_36, fnAction = l_7_36}, {szOption = "��", bMCheck = true, bChecked = l_7_33, fnAction = l_7_33}, {szOption = "��", bMCheck = true, bChecked = l_7_30, fnAction = l_7_30}, {szOption = "ˮ", bMCheck = true, bChecked = l_7_27, fnAction = l_7_27}, {szOption = "ľ", bMCheck = true, bChecked = l_7_24, fnAction = l_7_24}, {szOption = "��", bMCheck = true, bChecked = l_7_21, fnAction = l_7_21}
      l_7_24 = AuctionTip
      l_7_24 = l_7_24.nDiamondTypeTwo
      l_7_24 = l_7_24 == 0
      l_7_24 = function()
        AuctionTip.nDiamondTypeTwo = 0
      end
      l_7_27 = AuctionTip
      l_7_27 = l_7_27.nDiamondTypeTwo
      l_7_27 = l_7_27 == 1
      l_7_27 = function()
        AuctionTip.nDiamondTypeTwo = 1
      end
      l_7_30 = AuctionTip
      l_7_30 = l_7_30.nDiamondTypeTwo
      l_7_30 = l_7_30 == 2
      l_7_30 = function()
        AuctionTip.nDiamondTypeTwo = 2
      end
      l_7_33 = AuctionTip
      l_7_33 = l_7_33.nDiamondTypeTwo
      l_7_33 = l_7_33 == 3
      l_7_33 = function()
        AuctionTip.nDiamondTypeTwo = 3
      end
      l_7_36 = AuctionTip
      l_7_36 = l_7_36.nDiamondTypeTwo
      l_7_36 = l_7_36 == 4
      l_7_36 = function()
        AuctionTip.nDiamondTypeTwo = 4
      end
      l_7_36, l_7_33, l_7_30, l_7_27, l_7_24, l_7_21 = {szOption = "����", bMCheck = true, bChecked = AuctionTip.nDiamondTypeTwo == 5, fnAction = function()
        AuctionTip.nDiamondTypeTwo = 5
      end}, {szOption = "��", bMCheck = true, bChecked = l_7_36, fnAction = l_7_36}, {szOption = "��", bMCheck = true, bChecked = l_7_33, fnAction = l_7_33}, {szOption = "ˮ", bMCheck = true, bChecked = l_7_30, fnAction = l_7_30}, {szOption = "ľ", bMCheck = true, bChecked = l_7_27, fnAction = l_7_27}, {szOption = "��", bMCheck = true, bChecked = l_7_24, fnAction = l_7_24}
      l_7_18, l_7_15 = {l_7_21, l_7_24, l_7_27, l_7_30, l_7_33, l_7_36; szOption = "ʯͷ(2)"}, {l_7_18, l_7_21, l_7_24, l_7_27, l_7_30, l_7_33; szOption = "ʯͷ(1)"}
      l_7_12, l_7_9 = {l_7_15, l_7_18; szOption = "������ʯ������ʾ"}, {l_7_12, l_7_15, l_7_18, l_7_21, l_7_24, l_7_27, l_7_30, l_7_33, l_7_36; szOption = "�����ʯ���Թ���"}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_7_6 = PopupMenu
       -- DECOMPILER ERROR: Overwrote pending register.

      l_7_6(l_7_7)
      l_7_7 = {l_7_8, l_7_9, l_7_12, l_7_15; szOption = "�ؼ�����"}
    end
    l_5_8(l_5_9, l_5_10)
    l_5_8 = AuctionTip
    l_5_8 = l_5_8.bFilter
  end
  if not l_5_8 then
    l_5_8, l_5_9 = l_5_7:Hide, l_5_7
    l_5_8(l_5_9)
  end
  if not l_5_6:Lookup("Btn_AcSerch") then
    local l_5_11 = BoxButton
    local l_5_12 = l_5_6
    local l_5_13 = "Btn_AcSerch"
    local l_5_14 = {}
    l_5_14.txt = "Сҩ�͸�ħ"
    l_5_14.x = 750
    l_5_14.y = 0
    l_5_14.w = 100
    l_5_14.h = 25
    l_5_11 = l_5_11(l_5_12, l_5_13, l_5_14)
    l_5_12, l_5_13 = l_5_11:OnClick, l_5_11
    l_5_14 = function()
      -- upvalues: l_5_0
      local l_8_0, l_8_1 = l_5_0:GetAbsPos()
      local l_8_2, l_8_3 = l_5_0:GetSize()
      local l_8_4 = OpenAcSearchPanel()
      l_8_4:SetAbsPos(l_8_0 + l_8_2, l_8_1 + 100)
      l_8_4:Show()
    end
    l_5_12(l_5_13, l_5_14)
    l_5_12 = l_0_0
    if not l_5_12 then
      l_5_12, l_5_13 = l_5_11:OnMouseEnter, l_5_11
      l_5_14 = function()
        local l_9_0, l_9_1 = this:GetAbsPos()
        local l_9_2, l_9_3 = this:GetSize()
        local l_9_4 = OutputTip
        local l_9_5 = GetFormatText("Сҩ������Ҫ�������䷽��������ܿ�����")
        local l_9_6 = 400
        do
          local l_9_7 = {}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_9_4(l_9_5, l_9_6, l_9_7)
        end
         -- WARNING: undefined locals caused missing assignments!
      end
      l_5_12(l_5_13, l_5_14)
      l_5_12, l_5_13 = l_5_11:OnMouseLeave, l_5_11
      l_5_14 = function()
        HideTip()
      end
      l_5_12(l_5_13, l_5_14)
    end
    l_5_12, l_5_13 = l_5_11:Enable, l_5_11
    l_5_14 = true
    l_5_12(l_5_13, l_5_14)
  end
end

l_0_3(l_0_4, l_0_5)
l_0_3 = function()
  -- upvalues: l_0_0 , l_0_3
  l_0_0 = Moon.CheckAddon("Moon_CraftRecipePlus")
  UnRegisterEvent("LOADING_END", l_0_3)
end

l_0_4 = RegisterEvent
l_0_5 = "LOADING_END"
l_0_6 = l_0_3
l_0_4(l_0_5, l_0_6)
l_0_4 = _AuctionSell
if not l_0_4 then
  l_0_4 = AuctionPanel
  l_0_4 = l_0_4.AuctionSell
end
l_0_5 = AuctionPanel
l_0_6 = function(l_7_0)
  -- upvalues: l_0_4
  if IsShiftKeyDown() then
    AuctionTip.AuctionSell(l_7_0)
  else
    l_0_4(l_7_0)
  end
end

l_0_5.AuctionSell = l_0_6
l_0_5 = function(l_8_0, l_8_1)
  local l_8_2 = 0
  if l_8_1 then
    l_8_2 = l_8_0
  else
    l_8_2 = l_8_0:GetText()
  end
  if not l_8_2 or l_8_2 == "" then
    l_8_2 = 0
  end
  local l_8_3 = tonumber
  local l_8_4 = l_8_2
  return l_8_3(l_8_4)
end

l_0_6 = AuctionTip
l_0_7 = function(l_9_0)
  -- upvalues: l_0_5
  local l_9_1 = l_9_0:Lookup("PageSet_Totle/Page_Auction/Wnd_Sale")
  local l_9_2 = l_9_1:Lookup("", "")
  local l_9_3 = l_9_2:Lookup("Box_Item")
  local l_9_4 = l_9_2:Lookup("Text_Time")
  local l_9_5 = l_9_4:GetText()
  local l_9_6 = tonumber(string.sub(l_9_5, 1, 2))
  local l_9_7 = GetClientPlayer()
  local l_9_8 = l_9_7.GetItem(l_9_3.dwBox, l_9_3.dwX)
  if not l_9_8 or l_9_8.szName ~= l_9_3.szName then
    AuctionPanel.ClearBox(l_9_3)
    AuctionPanel.UpdateSaleInfo(l_9_0, true)
    RemoveUILockItem("Auction")
    OutputMessage("MSG_ANNOUNCE_RED", g_tAuctionString.STR_AUCTION_ITEM_INFO_CHANGE)
    return 
  end
  local l_9_9 = l_0_5(l_9_1:Lookup("Edit_OPGold"))
  local l_9_10 = l_0_5(l_9_1:Lookup("Edit_OPSilver"))
  local l_9_11 = l_0_5(l_9_1:Lookup("Edit_OPCopper"))
  local l_9_12 = PackMoney(l_9_9, l_9_10, l_9_11)
  l_9_9 = l_0_5(l_9_1:Lookup("Edit_PGold"))
  l_9_10 = l_0_5(l_9_1:Lookup("Edit_PSilver"))
  l_9_11 = l_0_5(l_9_1:Lookup("Edit_PCopper"))
  local l_9_13 = PackMoney(l_9_9, l_9_10, l_9_11)
  l_9_3.szTime = l_9_5
  l_9_3.tBidPrice = l_9_12
  l_9_3.tBuyPrice = l_9_13
  local l_9_14 = l_9_8.nStackNum
  if not l_9_8.bCanStack then
    l_9_14 = 1
  end
  local l_9_15 = MoneyOptDiv(l_9_12, l_9_14)
  local l_9_16 = MoneyOptDiv(l_9_13, l_9_14)
  local l_9_17 = GetAuctionClient()
  FireEvent("SELL_AUCTION_ITEM")
  for l_9_21 = 1, BIGBAGCOUNT do
    local l_9_22 = BagIndexToInventoryIndex(l_9_21)
    local l_9_23 = l_9_7.GetBoxSize(l_9_22)
    if l_9_23 and l_9_23 ~= 0 then
      for l_9_27 = 0, l_9_23 - 1 do
        local l_9_28 = l_9_7.GetItem(l_9_22, l_9_27)
        if l_9_28 and GetItemNameByItem(l_9_28) == GetItemNameByItem(l_9_8) and not l_9_28.bBind then
          local l_9_29 = l_9_28.nStackNum
          if not l_9_28.bCanStack then
            l_9_29 = 1
          end
          local l_9_30 = MoneyOptMult(l_9_15, l_9_29)
          local l_9_31 = MoneyOptMult(l_9_16, l_9_29)
          l_9_17.Sell(AuctionPanel.dwTargetID, l_9_22, l_9_27, l_9_30.nGold, l_9_30.nSilver, l_9_30.nCopper, l_9_31.nGold, l_9_31.nSilver, l_9_31.nCopper, l_9_6)
        end
      end
    end
  end
  PlaySound(SOUND.UI_SOUND, g_sound.Trade)
end

l_0_6.AuctionSell = l_0_7
l_0_6 = RegisterFrameHook
l_0_7 = "sellitem_tip"
l_0_6(l_0_7, l_0_8, "OnMouseEnter", function()
  local l_10_0, l_10_1 = this:GetAbsPos()
  local l_10_2, l_10_3 = this:GetSize()
  local l_10_4 = GetFormatText("<���ټ���>", 101) .. GetFormatText("��סShift�����ٵ���˰�ť��", 106)
  local l_10_5 = OutputTip
  local l_10_6 = l_10_4
  local l_10_7 = 400
  do
    local l_10_8 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_10_5(l_10_6, l_10_7, l_10_8)
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
l_0_8 = {"Normal/AuctionPanel/PageSet_Totle/Page_Auction/Wnd_Sale/Btn_Sale"}
l_0_6 = RegisterFrameHook
l_0_7 = "sellitem_hidetip"
l_0_6(l_0_7, l_0_8, "OnMouseLeave", function()
  HideTip()
end
)
l_0_8 = {"Normal/AuctionPanel/PageSet_Totle/Page_Auction/Wnd_Sale/Btn_Sale"}

