-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetLine.lua 

TargetLine = {}
TargetLine.nLineAlpha = 40
RegisterCustomData("TargetLine.nLineAlpha")
TargetLine.nStartWidth = 2
RegisterCustomData("TargetLine.nStartWidth")
TargetLine.nEndWidth = 1
RegisterCustomData("TargetLine.nEndWidth")
TargetLine.btargetline = false
RegisterCustomData("TargetLine.btargetline")
TargetLine.bPoint = false
RegisterCustomData("TargetLine.bPoint")
TargetLine.bttargetline = false
RegisterCustomData("TargetLine.bttargetline")
TargetLine.OnFrameCreate = function()
  local l_1_0 = Station.Lookup("Lowest/TargetLine")
  local l_1_1 = l_1_0:Lookup("", "")
  l_1_1:Lookup("Animate_Selection_Green"):Hide()
  l_1_1:Lookup("Animate_Selection_Yellow"):Hide()
  l_1_1:Lookup("Animate_Selection_Red"):Hide()
  local l_1_2 = l_1_1:Lookup("Shadow_Info")
  l_1_1:RemoveItem(l_1_2:GetIndex())
  local l_1_3 = l_1_1:AppendItemFromIni("Interface/Moon_TargetEx/TargetLine.ini", "Shadow_Info", "Shadow_Target")
  local l_1_4 = l_1_1:AppendItemFromIni("Interface/Moon_TargetEx/TargetLine.ini", "Shadow_Info", "Shadow_TTarget")
  l_1_3:Hide()
  l_1_3:SetTriangleFan(true)
  l_1_4:Hide()
  l_1_4:SetTriangleFan(true)
  l_1_1:FormatAllItemPos()
  l_1_0:RegisterEvent("RENDER_FRAME_UPDATE")
end

TargetLine.PointHide = function()
  local l_2_0 = Station.Lookup("Lowest/TargetLine")
  local l_2_1 = l_2_0:Lookup("", "")
  l_2_1:Lookup("Animate_Selection_Green"):Hide()
  l_2_1:Lookup("Animate_Selection_Yellow"):Hide()
  l_2_1:Lookup("Animate_Selection_Red"):Hide()
end

TargetLine.LineHide = function(l_3_0)
  local l_3_1 = Station.Lookup("Lowest/TargetLine")
  local l_3_2 = (l_3_1:Lookup("", ""))
  local l_3_3 = nil
  if l_3_0 == "target" then
    l_3_3 = l_3_2:Lookup("Shadow_Target")
  elseif l_3_0 == "ttarget" then
    l_3_3 = l_3_2:Lookup("Shadow_TTarget")
  end
  l_3_3:Hide()
end

TargetLine.OnEvent = function(l_4_0)
  if l_4_0 == "RENDER_FRAME_UPDATE" then
    TargetLine.update_line()
  end
end

TargetLine.AdjustAniPos = function(l_5_0, l_5_1, l_5_2)
  if l_5_0 then
    local l_5_3, l_5_4 = l_5_2:GetSize()
    local l_5_5 = math.ceil(l_5_0 - l_5_3 / 2)
    local l_5_6 = math.floor(l_5_1 - l_5_4 / 2) - 3
    l_5_2:SetAbsPos(l_5_5, l_5_6)
    l_5_2:Show()
  else
    l_5_2:SetAbsPos(-4096, -4096)
    l_5_2:Hide()
  end
end

TargetLine.update_line = function()
  local l_6_0 = GetClientPlayer()
  if not l_6_0 then
    return 
  end
  local l_6_1 = GetTargetHandle(l_6_0.GetTarget())
  local l_6_2 = Station.Lookup("Lowest/TargetLine")
  local l_6_3 = l_6_2:Lookup("", "")
  local l_6_4 = l_6_3:Lookup("Animate_Selection_Red")
  local l_6_5 = l_6_3:Lookup("Animate_Selection_Green")
  local l_6_6 = l_6_3:Lookup("Animate_Selection_Yellow")
  local l_6_7 = l_6_3:Lookup("Shadow_Target")
  local l_6_8 = l_6_3:Lookup("Shadow_TTarget")
  if l_6_1 then
    local l_6_9, l_6_10, l_6_11 = GetHeadTextForceFontColor(l_6_1.dwID, l_6_0.dwID)
    local l_6_12 = "green"
    if l_6_9 >= 255 and l_6_10 >= 255 and l_6_11 == 0 then
      l_6_12 = "yellow"
    elseif l_6_9 >= 255 and l_6_10 == 0 and l_6_11 == 0 then
      l_6_12 = "red"
    end
    local l_6_13 = {}
    local l_6_14 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_6_15 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_6_16 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_6_14 then
      for i_1,i_2 in l_6_15 do
        if l_6_12 ~= l_6_19[1] then
          l_6_19[2]:Hide()
         -- DECOMPILER ERROR: Overwrote pending register.

      else
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_6_14 then
        Moon_Lib.ApplyTargetTopScreenPos(l_6_16.AdjustAniPos, l_6_14, l_6_14.id)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_6_14 ~= l_6_1.dwID and l_6_14 then
        l_6_14(l_6_7, l_6_0.dwID, l_6_1.dwID)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      else
        if l_6_14 == l_6_1.dwID then
          l_6_14(l_6_7)
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_6_14 and TargetLine.bttargetline then
        TargetLine.UpdateLine(l_6_8, l_6_1.dwID, l_6_14.dwID)
      else
        l_6_8:Hide()
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
    else
      l_6_9, l_6_10 = l_6_4:Hide, l_6_4
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_5:Hide, l_6_5
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_6:Hide, l_6_6
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_7:Hide, l_6_7
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_8:Hide, l_6_8
      l_6_9(l_6_10)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 86 
end

TargetLine.GetRole = function(l_7_0)
  if IsPlayer(l_7_0) then
    local l_7_1 = GetPlayer
    local l_7_2 = l_7_0
    return l_7_1(l_7_2)
  else
    local l_7_3 = GetNpc
    local l_7_4 = l_7_0
    return l_7_3(l_7_4)
  end
end

TargetLine.GetCharacterColor = function(l_8_0)
  local l_8_1 = GetClientPlayer()
  if not l_8_1 then
    return 128, 128, 128
  end
  if not IsPlayer(l_8_0) then
    return 168, 168, 168
  end
  local l_8_2 = TargetLine.GetRole(l_8_0)
  if not l_8_2 then
    return 128, 128, 128
  end
  local l_8_3 = l_8_2.dwForceID
  if not l_8_3 then
    return 168, 168, 168
  end
  local l_8_4 = {}
  local l_8_5 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_4["���"], l_8_5 = l_8_5, {255, 255, 255}
  l_8_4["��"], l_8_5 = l_8_5, {175, 25, 255}
  l_8_4["����"], l_8_5 = l_8_5, {100, 125, 255}
  l_8_4["����"], l_8_5 = l_8_5, {255, 125, 255}
  l_8_4["����"], l_8_5 = l_8_5, {255, 255, 75}
  l_8_4["�ؽ�"], l_8_5 = l_8_5, {202, 248, 44}
  l_8_4["�嶾"], l_8_5 = l_8_5, {55, 147, 255}
  l_8_4["����"], l_8_5 = l_8_5, {121, 183, 54}
  l_8_4["����"], l_8_5 = l_8_5, {240, 70, 96}
  l_8_4["ؤ��"], l_8_5 = l_8_5, {205, 133, 63}
  l_8_5 = GetForceTitle
  l_8_5 = l_8_5(l_8_3)
  if l_8_4[l_8_5] then
    return l_8_4[l_8_5][1], l_8_4[l_8_5][2], l_8_4[l_8_5][3]
  end
  return 168, 168, 168
end

TargetLine.DrawLine = function(l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5, l_9_6)
  local l_9_7 = TargetLine.nStartWidth
  local l_9_8 = TargetLine.nEndWidth
  local l_9_9 = l_9_3 - l_9_1
  local l_9_10 = l_9_4 - l_9_2
  local l_9_11 = 0
  local l_9_12 = 0
  local l_9_13 = 0
  local l_9_14 = 0
  local l_9_15 = 0
  local l_9_16 = 0
  local l_9_17 = 0
  local l_9_18 = 0
  if (l_9_9 >= 0 and l_9_10 >= 0) or l_9_9 < 0 and l_9_10 < 0 then
    l_9_11 = l_9_1 + l_9_7
    l_9_13 = l_9_1 - l_9_7
    l_9_15 = l_9_3 + l_9_8
    l_9_17 = l_9_3 - l_9_8
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_9_11 = l_9_1 - l_9_7
     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_13 = l_9_1 + l_9_7
     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_15 = l_9_3 - l_9_8
     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_17 = l_9_3 + l_9_8
  end
  if not l_9_0:IsVisible() then
    l_9_0:Show()
  end
  l_9_0:ClearTriangleFanPoint()
  local l_9_19 = 0
  local l_9_20 = TargetLine.nLineAlpha
  l_9_0:AppendTriangleFanPoint(l_9_11, l_9_12 - l_9_19, l_9_5[1], l_9_5[2], l_9_5[3], l_9_20 * 2.55)
  l_9_0:AppendTriangleFanPoint(l_9_13, l_9_14 - l_9_19, l_9_5[1], l_9_5[2], l_9_5[3], l_9_20 * 2.55)
  l_9_0:AppendTriangleFanPoint(l_9_15, l_9_16 - l_9_19, l_9_6[1], l_9_6[2], l_9_6[3], l_9_20 * 2.55)
  l_9_0:AppendTriangleFanPoint(l_9_17, l_9_18 - l_9_19, l_9_6[1], l_9_6[2], l_9_6[3], l_9_20 * 2.55)
end

TargetLine.UpdateLine = function(l_10_0, l_10_1, l_10_2)
  if not l_10_1 or not l_10_2 or l_10_1 == 0 or l_10_2 == 0 then
    return 
  end
  local l_10_3 = TargetLine.GetRole(l_10_1)
  local l_10_4 = TargetLine.GetRole(l_10_2)
  if not l_10_3 or not l_10_4 or not l_10_3.nX or not l_10_4.nX then
    return 
  end
  local l_10_5, l_10_6, l_10_7, l_10_8 = nil, nil, nil, nil
  local l_10_9, l_10_10, l_10_11 = TargetLine.GetCharacterColor(l_10_1)
  local l_10_12, l_10_13, l_10_14 = TargetLine.GetCharacterColor(l_10_2)
  Moon_Lib.ApplyTargetTopScreenPos(function(l_11_0, l_11_1)
    -- upvalues: l_10_0 , l_10_5 , l_10_6 , l_10_7 , l_10_8 , l_10_9 , l_10_10 , l_10_11 , l_10_12 , l_10_13 , l_10_14
    local l_11_4, l_11_5, l_11_6, l_11_7, l_11_8, l_11_9, l_11_10, l_11_11, l_11_12 = nil
    if not l_11_0 then
      local l_11_2, l_11_3 = l_10_0:Hide, l_10_0
      return l_11_2(l_11_3)
    end
    l_10_5 = l_11_0
    if l_10_7 and l_10_8 then
      local l_11_13 = TargetLine.DrawLine
      local l_11_14 = l_10_0
      local l_11_15 = l_10_5
      local l_11_16 = l_10_6
      local l_11_17 = l_10_7
      local l_11_18 = l_10_8
      local l_11_19 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_11_20 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_11_13(l_11_14, l_11_15, l_11_16, l_11_17, l_11_18, l_11_19, l_11_20)
    end
     -- WARNING: undefined locals caused missing assignments!
  end, nil, l_10_1)
  Moon_Lib.ApplyTargetTopScreenPos(function(l_12_0, l_12_1)
    -- upvalues: l_10_0 , l_10_7 , l_10_8 , l_10_5 , l_10_6 , l_10_9 , l_10_10 , l_10_11 , l_10_12 , l_10_13 , l_10_14
    local l_12_4, l_12_5, l_12_6, l_12_7, l_12_8, l_12_9, l_12_10, l_12_11, l_12_12 = nil
    if not l_12_0 then
      local l_12_2, l_12_3 = l_10_0:Hide, l_10_0
      return l_12_2(l_12_3)
    end
    l_10_7 = l_12_0
    if l_10_5 and l_10_6 then
      local l_12_13 = TargetLine.DrawLine
      local l_12_14 = l_10_0
      local l_12_15 = l_10_5
      local l_12_16 = l_10_6
      local l_12_17 = l_10_7
      local l_12_18 = l_10_8
      local l_12_19 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_12_20 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_12_13(l_12_14, l_12_15, l_12_16, l_12_17, l_12_18, l_12_19, l_12_20)
    end
     -- WARNING: undefined locals caused missing assignments!
  end, nil, l_10_2)
end

Wnd.OpenWindow("Interface\\Moon_TargetEx\\TargetLine.ini", "TargetLine")

