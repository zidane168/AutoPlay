-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetList.lua 

local l_0_0 = "interface\\Moon_TargetList\\TargetList.ini"
local l_0_1 = {}
l_0_1.npcList = {}
l_0_1.playerList = {}
l_0_1.mode = "enemy_npc"
l_0_1.bShow = false
l_0_1.lifeType = "fight"
l_0_1.sortType = "no"
l_0_1.bplayerdis = false
l_0_1.bplayerschool = true
l_0_1.bplayerlevel = false
l_0_1.bnpcdis = false
l_0_1.bnpclevel = true
l_0_1.bnpctitle = false
l_0_1.bspecialnpc = false
local l_0_2 = {}
l_0_2.s = "BOTTOMCENTER"
l_0_2.r = "BOTTOMCENTER"
l_0_2.x = 318
l_0_2.y = -198
l_0_1.Anchor = l_0_2
l_0_1.nBgAlpha = 30
l_0_1.bTherapyTop = false
l_0_1.Filter, l_0_2 = l_0_2, {
Npc = {}, 
Player = {}}
l_0_1.tTipHorse, l_0_2 = l_0_2, {["����"] = true, ["���"] = true, ["����"] = true, ["����"] = true, ["����"] = true, ["���ɳ"] = true}
TargetList = l_0_1
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bReadNameMini"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bDeathMini"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.tTipHorse"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bTherapyTop"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.breadnametip"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.nBgAlpha"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bShow"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.mode"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.lifeType"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.sortType"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.Anchor"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bplayerdis"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bplayerschool"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bplayerlevel"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bnpcdis"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bnpclevel"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bnpctitle"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.bspecialnpc"
l_0_1(l_0_2)
l_0_1 = RegisterCustomData
l_0_2 = "TargetList.Filter"
l_0_1(l_0_2)
l_0_1 = TargetList
l_0_1.modeList, l_0_2 = l_0_2, {all_npc = "����NPC", enemy_npc = "�ж�NPC", friend_npc = "�Ѻ�NPC", all_player = "�������", enemy_player = "�ж����", friend_player = "�Ѻ����", horse = "����"}
l_0_2 = "����"
TargetList.OnFrameCreate = function()
  TargetList.frame = this
  TargetList.handle = TargetList.frame:Lookup("", "")
  TargetList.hlist = TargetList.handle:Lookup("Handle_List")
  TargetList.txt = TargetList.handle:Lookup("Handle_Title/Caption_Title")
  TargetList.SetBgAlpha(TargetList.nBgAlpha)
  TargetList.updateBtnState()
  TargetList.txt:SetText(TargetList.modeList[TargetList.mode])
  TargetList.UpdateAnchor()
  if TargetList.bShow then
    TargetList.Update()
  end
  BoxUpdateScroll("Handle_List", "TargetList", true)
  this:RegisterEvent("PLAYER_ENTER_SCENE")
  this:RegisterEvent("PLAYER_LEAVE_SCENE")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
end

TargetList.GetDis = function(l_2_0, l_2_1)
  local l_2_2 = tostring(l_2_0.nX - l_2_1.nX ^ 2 + l_2_0.nY - l_2_1.nY ^ 2 + l_2_0.nZ - l_2_1.nZ ^ 2 / 144 ^ 0.5 / 64)
  local l_2_3 = string.format
  local l_2_4 = "%.1f"
  local l_2_5 = l_2_2
  return l_2_3(l_2_4, l_2_5)
end

TargetList.OnFrameBreathe = function()
  local l_3_0 = GetClientPlayer()
  if not l_3_0 then
    return 
  end
  local l_3_1 = TargetList.hlist
  local l_3_2 = TargetList.updateSeeList()
  local l_3_3 = l_3_1:GetItemCount()
  local l_3_4 = {}
  local l_3_5 = {}
  for l_3_9 = 0, l_3_3 do
    local l_3_10 = l_3_1:Lookup(l_3_9)
    if l_3_10 then
      local l_3_11 = nil
      local l_3_12 = false
      if IsPlayer(l_3_10.id) then
        l_3_11 = GetPlayer(l_3_10.id)
      else
        l_3_11 = GetNpc(l_3_10.id)
        l_3_12 = true
      end
      if not l_3_11 then
        l_3_1:RemoveItem(l_3_10:GetIndex())
        l_3_2 = true
      end
    else
      if GetHeadTextForceFontColor(l_3_10.id, l_3_0.dwID) == 255 and l_3_10.id == 0 and l_3_0.dwID == 0 then
        local l_3_15, l_3_18 = nil
        local l_3_14 = 243
        l_3_15 = 243
        local l_3_13 = nil
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_3_11.nMoveState == MOVE_STATE.ON_DEATH then
        local l_3_17 = nil
        local l_3_16 = l_3_18
      end
      local l_3_19 = l_3_17
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_3_10:Lookup("Text_Name"):SetFontColor(l_3_19, l_3_16, 128)
      local l_3_20 = nil
      if math.floor(100 * l_3_11.nCurrentLife / l_3_11.nMaxLife) > 100 then
        local l_3_21, l_3_33, l_3_34, l_3_38, l_3_39 = , tonumber(TargetList.GetDis(l_3_0, l_3_11)), 100
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if string.match(TargetList.mode, "player") and l_3_38 > 0 then
        local l_3_22 = nil
        if TargetList.bTherapyTop and GetForceTitle(l_3_11.dwForceID) == "�嶾" or GetForceTitle(l_3_11.dwForceID) == "����" or GetForceTitle(l_3_11.dwForceID) == "��" then
          local l_3_26 = nil
          local l_3_27 = nil
          local l_3_28 = nil
          table.insert(l_3_5, {l_3_11.dwID, l_3_27, l_3_28})
        else
          local l_3_30 = nil
          local l_3_31 = nil
          local l_3_32 = nil
          table.insert(l_3_4, {l_3_11.dwID, l_3_31, l_3_32})
        end
      else
        if TargetList.mode == "horse" or string.match(TargetList.mode, "npc") then
          local l_3_35 = nil
          local l_3_36 = nil
          local l_3_37 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          table.insert(l_3_4, {l_3_11.dwID, l_3_37, l_3_32})
        end
      end
      local l_3_40 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

      if (TargetList.lifeType ~= "skip" and not l_3_11.bFightState) or l_3_12 then
        local l_3_41 = nil
        local l_3_42 = nil
        local l_3_43 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if (TargetList.bnpclevel and not TargetList.bnpctitle) or TargetList.bnpcdis then
          l_3_41:SetText(string.format("%s%s%s%s%s", "", l_3_11.szName, "", "", ""))
        end
      else
        local l_3_44 = nil
        local l_3_45 = nil
        local l_3_46 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

        if (TargetList.bplayerlevel and not TargetList.bplayerschool) or TargetList.bplayerdis then
          l_3_44:SetText(string.format("%s%s%s%s%s", "", l_3_11.szName, "", "", ""))
        end
      end
      if #l_3_4 > 0 then
        local l_3_47 = false
        if TargetList.sortType == "life" then
          table.sort(l_3_4, function(l_4_0, l_4_1)
          local l_4_2 = false
          if l_4_0[1] >= l_4_1[1] then
            l_4_2 = l_4_0[3] ~= l_4_1[3]
            do return end
          end
          l_4_2 = l_4_0[3] < l_4_1[3]
          return l_4_2
        end)
          l_3_47 = true
        else
          if TargetList.sortType == "distance" then
            table.sort(l_3_4, function(l_5_0, l_5_1)
          local l_5_2 = false
          if l_5_0[1] >= l_5_1[1] then
            l_5_2 = l_5_0[2] ~= l_5_1[2]
            do return end
          end
          l_5_2 = l_5_0[2] < l_5_1[2]
          return l_5_2
        end)
            l_3_47 = true
          end
        end
      end
      if l_3_47 then
        if #l_3_5 > 0 then
          table.sort(l_3_5, function(l_6_0, l_6_1)
        return l_6_0[1] < l_6_1[1]
      end)
          for l_3_51 = #l_3_5, 1, -1 do
            table.insert(l_3_4, 1, l_3_5[l_3_51])
          end
        end
        for l_3_55,l_3_56 in ipairs(l_3_4) do
          local l_3_57 = l_3_1:Lookup(tostring(l_3_56[1]))
          l_3_57:SetIndex(l_3_55 - 1)
        end
        l_3_1:FormatAllItemPos()
      end
      if l_3_2 then
        BoxUpdateScroll("Handle_List", "TargetList", false)
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 231 279 
end

TargetList.updateSeeList = function()
  -- upvalues: l_0_0
  local l_4_0 = TargetList.hlist
  do
    local l_4_1 = false
    if TargetList.mode == "horse" or string.match(TargetList.mode, "npc") then
      list = TargetList.npcList
    else
      list = TargetList.playerList
    end
    for l_4_5,l_4_6 in pairs(list) do
      if TargetList.canInsert(l_4_5) and not l_4_0:Lookup(tostring(l_4_5)) then
        local l_4_7 = l_4_0:AppendItemFromIni(l_0_0, "Handle_Target", tostring(l_4_5))
        l_4_7.id = l_4_5
        l_4_7.btarget = true
        l_4_1 = true
      end
      for l_4_5,l_4_6 in l_4_2 do
        if l_4_0:Lookup(tostring(l_4_5)) then
          l_4_0:RemoveItem(tostring(l_4_5))
          l_4_1 = true
        end
      end
      return l_4_1
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

TargetList.OnFrameDragEnd = function()
  this:CorrectPos()
  TargetList.Anchor = GetFrameAnchor(this)
end

TargetList.UpdateAnchor = function()
  local l_6_0 = Station.Lookup("Normal/TargetList")
  l_6_0:SetPoint(TargetList.Anchor.s, 0, 0, TargetList.Anchor.r, TargetList.Anchor.x, TargetList.Anchor.y)
  l_6_0:CorrectPos()
end

TargetList.SetBgAlpha = function(l_7_0)
  local l_7_1 = Station.Lookup("Normal/TargetList")
  local l_7_2 = l_7_1:Lookup("", "Shadow_List")
  l_7_2:SetAlpha(255 * (l_7_0 / 100))
end

TargetList.OnEvent = function(l_8_0)
  if l_8_0 == "PLAYER_ENTER_SCENE" then
    local l_8_1 = TargetList.playerList
    local l_8_2 = arg0
    l_8_1[l_8_2] = arg0
    l_8_1 = TargetList
    l_8_1 = l_8_1.appendTarget
    l_8_2 = arg0
    l_8_1(l_8_2, "player")
  elseif l_8_0 == "PLAYER_LEAVE_SCENE" then
    TargetList.removeTarget(arg0, "player")
    TargetList.playerList[arg0] = nil
  elseif l_8_0 == "NPC_ENTER_SCENE" then
    local l_8_3 = TargetList.npcList
    local l_8_4 = arg0
    l_8_3[l_8_4] = arg0
    l_8_3 = GetNpc
    l_8_4 = arg0
    l_8_3 = l_8_3(l_8_4)
    if l_8_3 then
      l_8_4 = TargetList
      l_8_4 = l_8_4.tTipHorse
      l_8_4 = l_8_4[l_8_3.szName]
    end
    if l_8_4 then
      l_8_4 = l_8_3.szTitle
    end
    if l_8_4 == "Ұ����" then
      l_8_4 = GetClientPlayer
      l_8_4 = l_8_4()
      local l_8_5 = string.format("������ʾ������[%s]������%s�ߡ�", l_8_3.szName, TargetList.GetDis(l_8_4, l_8_3))
      OutputWarningMessage("MSG_NOTICE_GREEN", l_8_5, 5)
    end
    if not l_8_4.bFightState then
      Moon_Lib.SetTarget(l_8_3.dwID)
    end
    l_8_4 = l_8_3.CanSeeName
    l_8_4 = l_8_4()
    if l_8_4 then
      l_8_4 = TargetList
      l_8_4 = l_8_4.appendTarget
      l_8_4(arg0, "npc")
    end
  elseif l_8_0 == "NPC_LEAVE_SCENE" then
    TargetList.npcList[arg0] = nil
    TargetList.removeTarget(arg0, "npc")
  elseif l_8_0 == "UI_SCALED" then
    TargetList.UpdateAnchor()
  end
end

TargetList.OnLButtonClick = function()
  -- upvalues: l_0_1 , l_0_2
  local l_9_0 = this:GetName()
  if l_9_0 == "Btn_Left" then
    TargetList.changeMode("left")
    TargetList.Update()
  elseif l_9_0 == "Btn_Right" then
    TargetList.changeMode("right")
    TargetList.Update()
  elseif l_9_0 == "Btn_Option" then
    local l_9_1 = {}
    local l_9_2 = {}
    local l_9_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_4 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_5 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_6 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_7 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_8 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_9_9 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_9_7,l_9_8 in l_9_4 do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_9_10 = "friend_player"
      local l_9_11 = {}
      l_9_11.szOption = l_9_8[1]
      l_9_11.bMCheck = true
      l_9_11.bChecked = TargetList.mode == l_9_8[2]
      l_9_11.UserData = l_9_8[2]
      l_9_11.fnAction = function(l_10_0)
        TargetList.mode = l_10_0
        TargetList.txt:SetText(TargetList.modeList[TargetList.mode])
        TargetList.Update()
        TargetList.updateBtnState()
      end
      l_9_9(l_9_10, l_9_11)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_9_14, l_9_43 = {}
    do
      l_9_14.szOption = "����NPC"
      l_9_43 = TargetList
      l_9_43 = l_9_43.bspecialnpc
      l_9_14.bChecked = l_9_43
      l_9_14.UserData = "bspecialnpc"
      l_9_14.bCheck = true
      l_9_14.fnAction = l_9_4
      l_9_9 = {szOption = "����", bChecked = TargetList.bnpcdis, UserData = "bnpcdis", bCheck = true, fnAction = l_9_4}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_9_17 = nil
      l_9_17 = "lifeType"
      l_9_43 = {l_9_17, "no"}
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_9_17 = TargetList
      l_9_17 = l_9_17.lifeType
      l_9_17 = l_9_17 == "fight"
      local l_9_20 = nil
      l_9_20 = "lifeType"
      l_9_17 = {l_9_20, "fight"}
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_9_43, l_9_14, l_9_9 = {szOption = "��ս��Ŀ��Ѫ��", bMCheck = true, bChecked = l_9_17, UserData = l_9_17, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}, {szOption = "����ʾѪ��", bMCheck = true, bChecked = l_9_43, UserData = l_9_43, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}, {szOption = "����ʾѪ��", bMCheck = true, bChecked = l_9_14, UserData = l_9_14, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}
      l_9_43 = TargetList
      l_9_43 = l_9_43.sortType
      l_9_43 = l_9_43 == "no"
      l_9_17 = "sortType"
      l_9_20 = "no"
      l_9_43 = {l_9_17, l_9_20}
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_9_17 = TargetList
      l_9_17 = l_9_17.sortType
      l_9_17 = l_9_17 == "life"
      l_9_20 = "sortType"
      l_9_17 = {l_9_20, "life"}
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_9_20 = TargetList
      l_9_20 = l_9_20.sortType
      l_9_20 = l_9_20 == "distance"
      local l_9_23 = nil
      l_9_23 = "sortType"
      l_9_20 = {l_9_23, "distance"}
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_9_24 = nil
      l_9_24 = TargetList
      l_9_24 = l_9_24.bTherapyTop
      l_9_24 = function()
        TargetList.bTherapyTop = not TargetList.bTherapyTop
      end
      l_9_23, l_9_20, l_9_17, l_9_43, l_9_14 = {szOption = "����ְҵ�ö�", bCheck = true, bChecked = l_9_24, fnAction = l_9_24}, {bDevide = true}, {szOption = "����������", bMCheck = true, bChecked = l_9_20, UserData = l_9_20, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}, {szOption = "��Ѫ������", bMCheck = true, bChecked = l_9_17, UserData = l_9_17, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}, {szOption = "������", bMCheck = true, bChecked = l_9_43, UserData = l_9_43, fnAction = function(l_12_0)
        local l_12_1 = TargetList
        local l_12_2 = l_12_0[1]
        l_12_1[l_12_2] = l_12_0[2]
      end}
      l_9_14 = table
      l_9_14 = l_9_14.insert
      l_9_43 = l_9_1
      l_9_17 = l_9_3
      l_9_14(l_9_43, l_9_17)
      l_9_14 = table
      l_9_14 = l_9_14.insert
      l_9_43 = l_9_1
      l_9_17 = 
      l_9_14(l_9_43, l_9_17)
      l_9_14 = table
      l_9_14 = l_9_14.insert
      l_9_43 = l_9_1
      l_9_17 = {
{szOption = "�ȼ�", bChecked = TargetList.bnpclevel, UserData = "bnpclevel", bCheck = true, fnAction = l_9_4}, 
{szOption = "�ƺ�", bChecked = l_9_9, UserData = "bnpctitle", bCheck = true, fnAction = l_9_4}, l_9_9, l_9_14; szOption = "�鿴NPC"}
      l_9_14(l_9_43, l_9_17)
      l_9_14 = table
      l_9_14 = l_9_14.insert
      l_9_43 = l_9_1
      l_9_17 = {l_9_9, l_9_14, l_9_43; szOption = "Ѫ����ʾ"}
      l_9_14(l_9_43, l_9_17)
      l_9_14 = table
      l_9_14 = l_9_14.insert
      l_9_43 = l_9_1
      l_9_17, l_9_9 = l_9_9, {l_9_14, l_9_43, l_9_17, l_9_20, l_9_23; szOption = "��������"}
      l_9_14(l_9_43, l_9_17)
      l_9_43 = ipairs
      l_9_17 = l_0_1
      l_9_43 = l_9_43(l_9_17)
      for l_9_23,l_9_24 in l_9_43 do
        local l_9_25 = nil
        l_9_25 = table
        l_9_25 = l_9_25.insert
        local l_9_26 = nil
        l_9_26, l_9_14 = l_9_14, {szOption = "������ʾ"}
        local l_9_27 = nil
        local l_9_28 = nil
        l_9_28 = string
        l_9_28 = l_9_28.format
        l_9_28 = l_9_28("%s(%s)", l_9_24, l_0_2[l_9_24])
        l_9_28 = TargetList
        l_9_28 = l_9_28.tTipHorse
        l_9_28 = l_9_28[l_9_24]
        if not l_9_28 then
          l_9_28 = false
        end
        l_9_28 = function()
          -- upvalues: l_9_15
          if TargetList.tTipHorse[l_9_15] then
            TargetList.tTipHorse[l_9_15] = nil
          else
            TargetList.tTipHorse[l_9_15] = true
          end
        end
        l_9_25(l_9_26, l_9_27)
        l_9_27 = {szOption = l_9_28, bCheck = true, bChecked = l_9_28, fnAction = l_9_28}
      end
      table.insert(l_9_1, l_9_14)
      local l_9_29, l_9_44 = nil
      local l_9_30, l_9_45 = nil
      local l_9_31 = nil
      table.insert(l_9_1, {bDevide = true})
      TargetList.InsertFilterMenu(l_9_1)
      table.insert(l_9_1, {bDevide = true})
      TargetList.InsertDataMenu(l_9_1)
      table.insert(l_9_1, {bDevide = true})
      for l_9_29 = 10, 50, 5 do
        do
          local l_9_32, l_9_33, l_9_34 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_9_35 = nil
          local l_9_36 = nil
          local l_9_37 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_9_44(l_9_30, l_9_45)
          l_9_45 = {szOption = l_9_31, UserData = l_9_29, bMCheck = true, bChecked = l_9_31, fnAction = function(l_15_0)
        TargetList.SetBgAlpha(l_15_0)
        TargetList.nBgAlpha = l_15_0
      end}
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      table.insert(l_9_1, {szOption = "����͸����"})
      do
        local l_9_40, l_9_46 = l_9_32
        local l_9_41 = nil
        local l_9_42 = nil
        table.insert(l_9_1, {bDevide = true})
        table.insert(l_9_1, {szOption = "�ر�", fnAction = TargetList.toggle})
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    PopupMenu(l_9_1)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

TargetList.InsertFilterMenu = function(l_10_0)
  local l_10_1 = {}
  l_10_1.szOption = "�����б�"
  local l_10_2 = {}
  l_10_2.szOption = "���"
  if IsEmpty(TargetList.Filter.Player) then
    local l_10_3 = table.insert
    local l_10_4 = l_10_2
    local l_10_5 = {}
    l_10_5.szOption = "��"
    l_10_3(l_10_4, l_10_5)
  else
    local l_10_6 = table.insert
    local l_10_7 = l_10_2
    local l_10_8 = {}
    l_10_8.szOption = "����б�"
    l_10_8.fnAction = function()
      TargetList.Filter.Player = {}
      TargetList.Update()
    end
    l_10_6(l_10_7, l_10_8)
    l_10_6 = table
    l_10_6 = l_10_6.insert
    l_10_7 = l_10_2
    l_10_6(l_10_7, l_10_8)
    l_10_8 = {bDevide = true}
    l_10_6 = pairs
    l_10_7 = TargetList
    l_10_7 = l_10_7.Filter
    l_10_7 = l_10_7.Player
    l_10_6 = l_10_6(l_10_7)
    for i_1,i_2 in l_10_6 do
      local l_10_11 = table.insert
      local l_10_12 = l_10_2
      local l_10_13 = {}
      l_10_13.szOption = l_10_10
      local l_10_14 = {}
      l_10_14.szOption = "ɾ��"
      l_10_14.UserData = l_10_9
      l_10_14.fnAction = function(l_12_0)
        TargetList.Filter.Player[l_12_0] = nil
        TargetList.Update()
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_10_11(l_10_12, l_10_13)
    end
  end
  table.insert(l_10_1, l_10_2)
  do
    local l_10_15, l_10_28 = nil
    if IsEmpty(TargetList.Filter.Npc) then
      local l_10_16 = nil
      local l_10_17 = nil
      do
        local l_10_18 = nil
        table.insert({szOption = "NPC"}, l_10_15)
        l_10_15 = {szOption = "��"}
      end
      do break end
    end
    local l_10_19 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_10_20 = nil
    local l_10_21 = nil
    table.insert({szOption = "NPC"}, l_10_15)
    l_10_15 = {szOption = "����б�", fnAction = l_10_28}
     -- DECOMPILER ERROR: Confused about usage of registers!

    table.insert({szOption = "NPC"}, l_10_15)
    l_10_15 = {bDevide = true}
    for l_10_28,l_10_19 in pairs(TargetList.Filter.Npc) do
      local l_10_22, l_10_23 = nil
      l_10_20 = table
      l_10_20 = l_10_20.insert
      local l_10_24 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_10_21 = {szOption = "NPC"}
      local l_10_25 = nil
      local l_10_26 = nil
      local l_10_27 = nil
      l_10_24 = function(l_14_0)
      TargetList.Filter.Npc[l_14_0] = nil
      TargetList.Update()
    end
      l_10_23 = {szOption = "ɾ��", UserData = l_10_28, fnAction = l_10_24}
      l_10_20(l_10_21, l_10_22)
      l_10_22 = {l_10_23; szOption = l_10_19}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    table.insert(l_10_1, {szOption = "NPC"})
  end
  table.insert(l_10_0, l_10_1)
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

local l_0_3 = function(l_11_0)
  local l_11_1 = GetClientPlayer()
  local l_11_2 = EditBox_GetChannel()
  if R3_PC4 == nil then
    R3_PC4 = ""
    local l_11_3, l_11_4 = nil
  end
  local l_11_5 = nil
  local l_11_6 = l_11_1.Talk
  local l_11_7 = l_11_2
  local l_11_8 = l_11_5
  local l_11_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_11_6(l_11_7, l_11_8, l_11_9)
end

RegisterMoonButton("targetlist", 281, "Ŀ���б�", "General", function(l_33_0)
  local l_33_1 = BoxCheckBox
  local l_33_2 = l_33_0
  local l_33_3 = "CheckBox_TargetList"
  local l_33_4 = {}
  l_33_4.txt = "����Ŀ���б�"
  l_33_1 = l_33_1(l_33_2, l_33_3, l_33_4)
  l_33_2, l_33_3 = l_33_1:SetBoolValue, l_33_1
  l_33_4 = TargetList
  l_33_2(l_33_3, l_33_4, "bShow")
  l_33_2, l_33_3 = l_33_1:OnCheck, l_33_1
  l_33_4 = function()
    TargetList.frame:Show()
    TargetList.Update()
  end
  l_33_2(l_33_3, l_33_4)
  l_33_2, l_33_3 = l_33_1:UnCheck, l_33_1
  l_33_4 = function()
    TargetList.frame:Hide()
  end
  l_33_2(l_33_3, l_33_4)
end
)
RegisterEvent("AddonLoad", function()
  -- upvalues: l_0_0
  if TargetList.bShow then
    Wnd.OpenWindow(l_0_0, "TargetList"):Show()
  else
    Wnd.OpenWindow(l_0_0, "TargetList"):Hide()
  end
end
)
AppendCommand("targetlist", TargetList.toggle)
local l_0_6 = function(l_12_0)
  -- upvalues: l_0_3
  local l_12_1 = l_12_0()
  for l_12_5,l_12_6 in pairs(l_12_1) do
    if l_12_6 ~= "-" then
      l_0_3(l_12_6)
    end
  end
end

local l_0_7 = nil
local l_0_8 = RegisterMoonMenu
l_0_8("targetlist", {szName = "Ŀ���б�", szImage = "\\interface\\Moon_TargetList\\sign.UiTex", nFrame = 0, fnAction = TargetList.toggle})
l_0_8 = BoxRegisterScroll
l_0_8("TargetList")
l_0_8 = BoxUnRegisterScrollAllControl
l_0_8("TargetList")
l_0_8 = "Normal/TargetList"
local l_0_9 = BoxRegisterScrollControl
local l_0_10 = l_0_8
local l_0_11 = "Btn_Up"
do
  local l_0_12 = "Btn_Down"
  l_0_9(l_0_10, l_0_11, l_0_12, "Scroll_List", {"/", "Handle_List"})
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.


