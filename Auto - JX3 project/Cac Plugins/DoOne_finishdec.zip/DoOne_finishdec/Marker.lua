-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Marker.lua 

local l_0_0 = {}
l_0_0.Markers = {}
l_0_0.bIsOpen = false
l_0_0.bInParty = false
local l_0_1 = {}
l_0_1.x = 39
l_0_1.y = 232
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_0.Anchor = l_0_1
l_0_0.bConvergeTarget = true
l_0_0.bSelectConverge = true
l_0_0.bConvergeGuild = false
l_0_0.bTipIgnore = true
l_0_0.bIgnoreTLife = true
l_0_0.nIgnoreTLife = 30
l_0_0.bIgnoreMPrepare = true
l_0_0.bIgnoreTPrepare = true
l_0_0.bIgnoreTDis = true
l_0_0.nIgnoreTDis = 25
l_0_0.tForceOrder, l_0_1 = l_0_1, {0, 5, 2, 6, 4, 7, 10, 8, 9, 1, 3}
l_0_0.tMarkForce, l_0_1 = l_0_1, {[0] = true, [5] = true, [2] = true, [6] = true}
l_0_0.bKeepAlly = true
l_0_0.bTherapyTop = true
l_0_0.bPlayerMenu = true
l_0_0.nSteperCount = -1
Moon_Marker = l_0_0
l_0_0 = Moon_Marker
l_0_0.frameSelf = nil
l_0_0 = Moon_Marker
l_0_0.handleTotal = nil
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bIsOpen"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bInParty"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bConvergeGuild"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bConvergeTarget"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bSelectConverge"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bTipIgnore"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bIgnoreTLife"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.nIgnoreTLife"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bIgnoreMPrepare"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bIgnoreTPrepare"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bIgnoreTDis"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.nIgnoreTDis"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bPlayerMenu"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.tMarkForce"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bKeepAlly"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_Marker.bTherapyTop"
l_0_0(l_0_1)
l_0_1 = "��"
l_0_1 = "Interface\\Moon_Marker\\Marker.ini"
Moon_Marker.OnFrameCreate = function()
  -- upvalues: l_0_1
  this:RegisterEvent("ON_BG_CHANNEL_MSG")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("LOADING_END")
  Moon_Marker.UpdateAnchor()
  Moon_Marker.frameSelf = Station.Lookup("Normal/Moon_Marker")
  Moon_Marker.handleTotal = Moon_Marker.frameSelf:Lookup("", "")
  Moon_Marker.handleMarker = Moon_Marker.handleTotal:Lookup("Handle_Maker")
  Moon_Marker.frameSelf:EnableDrag(false)
  Moon_Marker.handleMarker:RemoveItem("Handle_Item")
  for l_1_3 = 0, 9 do
    Moon_Marker.Markers[l_1_3] = Moon_Marker.handleMarker:AppendItemFromIni(l_0_1, "Handle_Item", "Handle_Marker_" .. l_1_3)
    Moon_Marker.Markers[l_1_3].imgBox = Moon_Marker.Markers[l_1_3]:Lookup("Image_Box")
    Moon_Marker.Markers[l_1_3].txtLife = Moon_Marker.Markers[l_1_3]:Lookup("Text_Life")
    Moon_Marker.Markers[l_1_3].imgMarker = Moon_Marker.Markers[l_1_3]:Lookup("Image_Maker")
    Moon_Marker.Markers[l_1_3].txtForce = Moon_Marker.Markers[l_1_3]:Lookup("Text_Force")
    Moon_Marker.Markers[l_1_3].imgMarker:SetAlpha(156)
    Moon_Marker.Markers[l_1_3].imgMarker.nKey = l_1_3 + 1
    local l_1_4 = PARTY_MARK_ICON_FRAME_LIST[l_1_3 + 1]
    Moon_Marker.Markers[l_1_3].imgMarker:FromUITex(PARTY_MARK_ICON_PATH, l_1_4)
    Moon_Marker.Markers[l_1_3]:SetRelPos(48 * l_1_3, 0)
  end
  Moon_Marker.handleTotal:FormatAllItemPos()
  Moon_Marker.txtTip = Moon_Marker.handleTotal:Lookup("Text_DragTip")
  Moon_Marker.imgSel = Moon_Marker.handleTotal:Lookup("Image_Sel")
  Moon_Marker.aniCover = Moon_Marker.handleTotal:Lookup("Animate_Cover")
  Moon_Marker.aniCover:SetAlpha(96)
end

local l_0_2 = false
Moon_Marker.OnEvent = function(l_2_0)
  -- upvalues: l_0_2
  if l_2_0 == "ON_BG_CHANNEL_MSG" then
    local l_2_1 = GetClientPlayer()
    if arg0 == l_2_1.dwID then
      return 
    end
    if not Moon_Marker.bSelectConverge then
      return 
    end
    if arg1 == PLAYER_TALK_CHANNEL.TEAM or arg1 == PLAYER_TALK_CHANNEL.RAID or arg1 == PLAYER_TALK_CHANNEL.BATTLE_FIELD or arg1 == PLAYER_TALK_CHANNEL.TONG then
      local l_2_2 = GetClientPlayer()
      local l_2_3 = l_2_2.GetTalkData()
    if l_2_3[2].text ~= "convergetarget" then
      end
    if l_2_3[2].text ~= "convergetarget" then
      end
    end
    if Moon_Marker.IsAuthorityer(arg0) or arg1 == PLAYER_TALK_CHANNEL.TONG then
      local l_2_4 = Moon_Marker.GetCharacter(tonumber(l_2_3[3].text))
      local l_2_5 = GetTargetHandle(l_2_2.GetTarget())
    end
    if l_2_4 then
      if l_2_5 and l_2_5.dwID == l_2_4.dwID then
        return 
      end
      local l_2_6 = Moon_Marker.IsDps(l_2_2)
      local l_2_7 = IsEnemy(l_2_2.dwID, l_2_4.dwID)
      if not l_2_6 and l_2_7 then
        return 
      end
      if l_2_6 and not l_2_7 then
        return 
      end
      local l_2_8, l_2_9 = Moon_Marker.CanSelect(l_2_4)
      if l_2_8 then
        OutputWarningMessage("MSG_WARNING_RED", "[%s]������������л�Ŀ����[%s]��":format(arg3, l_2_4.szName))
        Moon_Lib.SetTarget(l_2_4.dwID)
      end
    else
      if Moon_Marker.bTipIgnore then
        Moon_Marker.Talk("���Լ���[%s]��%s":format(l_2_4.szName, l_2_9))
      end
    elseif l_2_0 == "UI_SCALED" then
      Moon_Marker.UpdateAnchor()
    elseif l_2_0 == "LOADING_END" then
      if l_0_2 then
        return 
      end
      l_0_2 = true
      Moon_Marker.UpdateAnchor()
      Moon_Marker.ClosePanel()
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

Moon_Marker.HideButton = function()
  local l_3_0 = GetClientTeam()
  local l_3_1 = GetClientPlayer()
  if not l_3_0 or not l_3_1.IsInParty() or l_3_1.dwID ~= l_3_0.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
    Moon_Marker.frameSelf:Lookup("Btn_Clear"):Hide()
    Moon_Marker.frameSelf:Lookup("Btn_Mark"):Hide()
    return 
  end
  Moon_Marker.frameSelf:Lookup("Btn_Clear"):Show()
  Moon_Marker.frameSelf:Lookup("Btn_Mark"):Show()
end

Moon_Marker.OnFrameBreathe = function()
  if not Moon_Marker.frameSelf or not Moon_Marker.bIsOpen then
    return 
  end
  local l_4_0 = GetClientPlayer()
  if not l_4_0 then
    return 
  end
  if IsCtrlKeyDown() and IsAltKeyDown() then
    Moon_Marker.frameSelf:EnableDrag(true)
  else
    if Moon_Marker.frameSelf:IsDragable() then
      Moon_Marker.frameSelf:EnableDrag(false)
    end
  end
  Moon_Marker.nSteperCount = Moon_Marker.nSteperCount + 1
  if Moon_Marker.nSteperCount >= 100000000 then
    Moon_Marker.nSteperCount = -1
  end
  if Moon_Marker.nSteperCount % 3 ~= 0 then
    return 
  end
  if Moon_Marker.ClosePanel() then
    return 
  end
  Moon_Marker.frameSelf:Show()
  for l_4_4 = 0, 9 do
    if not Moon_Marker.Markers[l_4_4] then
      return 
    end
    Moon_Marker.Markers[l_4_4].txtLife:Hide()
    Moon_Marker.Markers[l_4_4].txtForce:Hide()
    Moon_Marker.Markers[l_4_4].imgMarker:Hide()
    Moon_Marker.Markers[l_4_4].imgMarker.dwID = nil
  end
  Moon_Marker.imgSel:Hide()
  Moon_Marker.HideButton()
  local l_4_5 = true
  local l_4_6 = GetClientTeam()
  if l_4_0.IsInParty() then
    local l_4_7, l_4_8 = l_4_0.GetTarget()
    if not l_4_6.GetTeamMark() then
      local l_4_9, l_4_10 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_4_14,l_4_15 in pairs(l_4_9) do
      local l_4_11 = nil
      if Moon_Marker.GetCharacter(l_4_15) then
        local l_4_17 = nil
        local l_4_18 = nil
        Moon_Marker.Markers[l_4_16 - 1].imgMarker:Show()
         -- DECOMPILER ERROR: Confused about usage of registers!

        Moon_Marker.Markers[l_4_16 - 1].imgMarker.dwID = l_4_15
         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_4_8 and l_4_8 ~= 0 and l_4_15 == l_4_8 then
          local l_4_19, l_4_20 = , Moon_Marker.Markers[l_4_16 - 1]:GetRelPos()
          Moon_Marker.imgSel:SetRelPos(l_4_20, Moon_Marker.Markers[l_4_16 - 1] + 18)
          Moon_Marker.imgSel:Show()
          Moon_Marker.handleTotal:FormatAllItemPos()
        end
        local l_4_21 = nil
        l_4_21.txtLife:SetText("%d%%":format(math.min(1, l_4_17.nCurrentLife / l_4_17.nMaxLife) * 100))
        if math.min(1, l_4_17.nCurrentLife / l_4_17.nMaxLife) > 0.66 then
          l_4_21.txtLife:SetFontColor(255, 255, 255)
        elseif math.min(1, l_4_17.nCurrentLife / l_4_17.nMaxLife) > 0.33 then
          l_4_21.txtLife:SetFontColor(255, 128, 0)
        else
          l_4_21.txtLife:SetFontColor(255, 0, 0)
        end
        l_4_21.txtLife:Show()
      end
      if IsPlayer(l_4_17.dwID) then
        local l_4_22 = nil
        local l_4_23 = GetForceTitle(l_4_17.dwForceID)
        if l_4_17.GetKungfuMount() then
          l_4_23 = string.sub(Table_GetSkillName(l_4_17.GetKungfuMount().dwSkillID, l_4_17.GetKungfuMount().dwLevel), 1, 4)
        end
        l_4_21.txtForce:SetText(l_4_23)
        l_4_21.txtForce:Show()
      end
    end
  end
  if l_4_5 then
    l_4_7 = Moon_Marker
    l_4_7 = l_4_7.txtTip
    l_4_7, l_4_8 = l_4_7:Show, l_4_7
    l_4_7(l_4_8)
  else
    l_4_7 = Moon_Marker
    l_4_7 = l_4_7.txtTip
    l_4_7, l_4_8 = l_4_7:Hide, l_4_7
    l_4_7(l_4_8)
  end
end

Moon_Marker.Talk = function(l_5_0, l_5_1)
  local l_5_2 = GetClientPlayer()
  local l_5_3 = PLAYER_TALK_CHANNEL.NEARBY
  if l_5_2.IsInParty() then
    l_5_3 = PLAYER_TALK_CHANNEL.TEAM
  end
  if l_5_2.IsInRaid() then
    l_5_3 = PLAYER_TALK_CHANNEL.RAID
  end
  if Moon_Marker.bConvergeGuild and l_5_1 then
    l_5_3 = PLAYER_TALK_CHANNEL.TONG
  end
  if l_5_2.GetScene().nType == MAP_TYPE.BATTLE_FIELD then
    l_5_3 = PLAYER_TALK_CHANNEL.BATTLE_FIELD
  end
  if type(l_5_0) == "table" then
    l_5_2.Talk(l_5_3, "", l_5_0)
  else
    local l_5_4 = l_5_2.Talk
    local l_5_5 = l_5_3
    local l_5_6 = ""
    local l_5_7 = {}
    local l_5_8 = {}
    l_5_8.type = "text"
    l_5_8.text = l_5_0
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_5_4(l_5_5, l_5_6, l_5_7)
  end
end

Moon_Marker.IsAuthorityer = function(l_6_0)
  if Moon_Marker.IsMaster(l_6_0) then
    return true
  end
  if Moon_Marker.IsMatrix(l_6_0) and Moon_Marker.GetGroupIndex(GetClientPlayer().dwID) == l_6_0 then
    return true
  end
  return false
end

Moon_Marker.GetGroupIndex = function(l_7_0)
  local l_7_1 = GetClientTeam()
  local l_7_2 = l_7_1.GetMemberGroupIndex
  local l_7_3 = l_7_0
  return l_7_2(l_7_3)
end

Moon_Marker.IsMatrix = function(l_8_0)
  local l_8_1 = GetClientPlayer()
  if not l_8_1.IsInRaid() then
    return false
  end
  if not l_8_0 then
    l_8_0 = l_8_1.dwID
  end
  local l_8_2 = GetClientTeam()
  if not l_8_2 then
    return false
  end
  local l_8_3 = l_8_2.GetMemberGroupIndex(l_8_0)
  local l_8_4 = l_8_2.GetGroupInfo(l_8_3)
  if l_8_4 and #l_8_4.MemberList > 1 and l_8_4.dwFormationLeader == l_8_0 then
    return true, l_8_3
  end
  return false
end

Moon_Marker.IsMaster = function(l_9_0)
  local l_9_1 = GetClientPlayer()
  if not l_9_0 then
    l_9_0 = l_9_1.dwID
  end
  local l_9_2 = GetClientTeam()
  if not l_9_2 then
    return false
  end
  return l_9_0 == l_9_2.dwTeamLeader or l_9_0 == l_9_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK)
end

Moon_Marker.IsDps = function(l_10_0)
  if not l_10_0 then
    l_10_0 = GetClientPlayer()
  end
  local l_10_1 = l_10_0.GetKungfuMount()
  return not l_10_1 or (l_10_1.dwSkillID ~= 10080 and l_10_1.dwSkillID ~= 10028 and l_10_1.dwSkillID ~= 10176)
end

Moon_Marker.CanFocus = function(l_11_0)
  if not l_11_0 or l_11_0.nMoveState == MOVE_STATE.ON_DEATH then
    return false
  end
  return true
end

Moon_Marker.ConvergeTarget = function(l_12_0)
  -- upvalues: l_0_0
  local l_12_1 = GetClientPlayer()
  if not l_12_0 then
    l_12_0 = GetTargetHandle(l_12_1.GetTarget())
  end
  if not l_12_0 or not l_12_1.IsInParty() then
    return 
  end
  local l_12_2 = Moon_Marker.IsMaster(l_12_1.dwID)
  local l_12_3, l_12_4 = Moon_Marker.IsMatrix(l_12_1.dwID)
  if (l_12_2 or l_12_3) and Moon_Marker.CanFocus(l_12_0) then
    local l_12_5 = {}
    local l_12_6 = {}
    l_12_6.type = "text"
    l_12_6.text = "BG_CHANNEL_MSG"
    local l_12_7 = {}
    l_12_7.type = "text"
    l_12_7.text = "convergetarget"
    local l_12_8 = {}
    l_12_8.type = "text"
    l_12_8.text = tostring(l_12_0.dwID)
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_12_6 = "�Ｏ��"
    if not l_12_2 and l_12_3 then
      l_12_7 = string
      l_12_7 = l_12_7.format
      l_12_8 = "���%sС�ӣ�����"
      l_12_7 = l_12_7(l_12_8, NumberToChinese(l_12_4 + 1))
      l_12_6 = l_12_7
    end
    l_12_7 = GetClientTeam
    l_12_7 = l_12_7()
    l_12_7 = l_12_7.GetTeamMark
    l_12_7 = l_12_7()
    if not l_12_7 then
      l_12_8 = l_12_0.dwID
    end
    l_12_8, l_12_7 = l_12_7[l_12_8], {}
    if l_12_8 and l_12_8 > 0 then
      l_12_6 = string.format("%s���Ϊ[%s]��", l_12_6, l_0_0[l_12_8])
    end
    l_12_6 = l_12_6 .. "[%s]":format(l_12_0.szName)
    Moon_Marker.Talk(l_12_6, true)
    Moon_Marker.Talk(l_12_5, true)
  end
end

Moon_Marker.Jihuo = function(l_13_0)
  if l_13_0 then
    local l_13_1 = Moon_Marker.GetCharacter(l_13_0)
  end
  if l_13_1 then
    Moon_Lib.SetTarget(l_13_0)
  end
  if Moon_Marker.bConvergeTarget then
    Moon_Marker.ConvergeTarget(l_13_1)
  end
end

Moon_Marker.OnItemLButtonDBClick = function()
  Moon_Marker.Jihuo(this.dwID)
end

Moon_Marker.UpdateAnchor = function()
  local l_15_0 = Station.Lookup("Normal/Moon_Marker")
  l_15_0:SetPoint(Moon_Marker.Anchor.s, 0, 0, Moon_Marker.Anchor.r, Moon_Marker.Anchor.x, Moon_Marker.Anchor.y)
  l_15_0:CorrectPos()
end

Moon_Marker.OnFrameDragEnd = function()
  this:CorrectPos()
  Moon_Marker.Anchor = GetFrameAnchor(this)
end

Moon_Marker.OnItemLButtonClick = function()
  if IsCtrlKeyDown() and IsAltKeyDown() then
    return 
  end
  if this.dwID then
    Moon_Lib.SetTarget(this.dwID)
  end
end

Moon_Marker.OnItemRButtonClick = function()
  local l_18_0 = GetClientTeam()
  local l_18_1 = GetClientPlayer()
  if not l_18_1.IsInParty() then
    return 
  end
  if l_18_1.dwID ~= l_18_0.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
    return 
  end
  if this.dwID then
    local l_18_2 = this.dwID
    do
      local l_18_3 = {}
      local l_18_4 = {}
      l_18_4.szOption = "������"
      l_18_4.fnAction = function()
        -- upvalues: l_18_2
        local l_19_0 = GetClientTeam()
        l_19_0.SetTeamMark(0, l_18_2)
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_18_4 = PopupMenu
      l_18_4(l_18_3)
    end
  end
end

Moon_Marker.OnItemMouseEnter = function()
  if this:GetAlpha() == 156 then
    this:SetAlpha(255)
    local l_19_0, l_19_1 = this:GetParent():GetRelPos()
    Moon_Marker.aniCover:Show()
    Moon_Marker.aniCover:SetRelPos(l_19_0, l_19_1 + 18)
    Moon_Marker.handleTotal:FormatAllItemPos()
  end
end

Moon_Marker.OnItemMouseLeave = function()
  if this:GetAlpha() == 255 then
    this:SetAlpha(156)
    Moon_Marker.aniCover:Hide()
  end
end

Moon_Marker.OnLButtonClick = function()
  local l_21_0 = this:GetName()
  if l_21_0 == "Btn_Mark" then
    Moon_Marker.QuickMark()
  elseif l_21_0 == "Btn_Clear" then
    Moon_Marker.QuickMark(true, true)
  end
end

Moon_Marker.GetCharacter = function(l_22_0)
  local l_22_1 = nil
  if IsPlayer(l_22_0) then
    l_22_1 = GetPlayer(l_22_0)
  else
    l_22_1 = GetNpc(l_22_0)
  end
  return l_22_1
end

Moon_Marker.CanSelect = function(l_23_0)
  local l_23_1 = GetClientPlayer()
  if l_23_0.nMoveState == MOVE_STATE.ON_DEATH then
    return false, "Ŀ����������"
  end
  if Moon_Marker.bIgnoreMPrepare and l_23_1.GetOTActionState() ~= 0 then
    return false, "���ڶ�����"
  end
  if Moon_Marker.bIgnoreTPrepare and IsPlayer(l_23_0.dwID) and l_23_0.GetOTActionState() ~= 0 then
    return false, "Ŀ���ڶ�����"
  end
  if Moon_Marker.bIgnoreTDis and Moon_Marker.nIgnoreTDis < Moon_Lib.GetDistance(l_23_1, l_23_0) then
    return false, "����Ŀ����ҵľ���̫Զ��"
  end
  if Moon_Marker.bIgnoreTLife and math.ceil(100 * l_23_0.nCurrentLife / l_23_0.nMaxLife) < Moon_Marker.nIgnoreTLife then
    return false, "��ǰĿ���Ѫ�����١�"
  end
  return true
end

Moon_Marker.ClosePanel = function()
  local l_24_0 = Station.Lookup("Normal/Moon_Marker")
  local l_24_1 = GetClientPlayer()
  if not l_24_1 then
    return 
  end
  if l_24_0 and (not Moon_Marker.bIsOpen or not Moon_Marker.bInParty or not l_24_1.IsInParty()) then
    l_24_0:Hide()
    return true
  end
  return false
end

Wnd.OpenWindow(l_0_1, "Moon_Marker")
Moon_Marker.MarkerPlayer = function(l_25_0, l_25_1)
  -- upvalues: l_0_0
  local l_25_2 = l_25_0.GetKungfuMount()
  local l_25_3 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if string.format("[%s]", l_25_0.szName) > 255 then
    table.insert()
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  table.insert(l_25_3, string.format("Ѫ��%.1f���", l_25_0.nMaxLife / 10000)())
  if l_25_2 then
    table.insert(l_25_3, "��%s��":format(Table_GetSkillName(l_25_2.dwSkillID, l_25_2.dwLevel)))
  end
  local l_25_4 = GetClientTeam()
  l_25_4.SetTeamMark(l_25_1, l_25_0.dwID)
  table.insert(l_25_3, "���ѱ�[%s]��":format(l_0_0[l_25_1]))
  Moon_Marker.Talk(table.concat(l_25_3))
end

Moon_Marker.SortByDistance = function(l_26_0, l_26_1)
  local l_26_2 = GetClientPlayer()
  return Moon_Lib.GetDistance(l_26_2, l_26_0) < Moon_Lib.GetDistance(l_26_2, l_26_1)
end

Moon_Marker.GetAllPlayer = function()
  local l_27_0 = GetAllPlayer()
  local l_27_1 = {}
  local l_27_2 = {}
  for l_27_6,l_27_7 in ipairs(l_27_0) do
    local l_27_8 = GetForceTitle(l_27_7.dwForceID)
    if l_27_8 == "�嶾" or l_27_8 == "����" or l_27_8 == "��" and Moon_Marker.bTherapyTop then
      local l_27_12 = nil
      if not l_27_7.GetKungfuMount() or l_27_7.GetKungfuMount().dwSkillID == 10080 and l_27_7.GetKungfuMount().dwSkillID == 10028 and l_27_7.GetKungfuMount().dwSkillID == 10176 then
        table.insert(l_27_2, l_27_7)
      else
        table.insert(l_27_1, l_27_7)
      end
    else
      table.insert(l_27_1, l_27_7)
    end
  end
  table.sort(l_27_2, Moon_Marker.SortByDistance)
  table.sort(l_27_1, Moon_Marker.SortByDistance)
  for l_27_17 = #l_27_2, 1, -1 do
    table.insert(l_27_1, 1, l_27_2[l_27_17])
  end
  return l_27_1
end

Moon_Marker.QuickMark = function(l_28_0, l_28_1)
  -- upvalues: l_0_0
  local l_28_7, l_28_8, l_28_9, l_28_10, l_28_11, l_28_12, l_28_13, l_28_14, l_28_15, l_28_16, l_28_17, l_28_18, l_28_19 = nil
  local l_28_2 = GetClientTeam()
  local l_28_3 = GetClientPlayer()
  if not l_28_3.IsInParty() then
    return 
  end
  if l_28_3.dwID ~= l_28_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
    local l_28_4 = OutputMessage
    local l_28_5 = "MSG_ANNOUNCE_RED"
    local l_28_6 = "�ޱ��Ȩ��"
    return l_28_4(l_28_5, l_28_6)
  end
  local l_28_20 = {}
  local l_28_21 = 0
  if not l_28_2.GetTeamMark() then
    local l_28_22, l_28_23, l_28_31, l_28_32, l_28_33, l_28_44 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_28_27,l_28_28 in pairs(l_28_22) do
    local l_28_24 = nil
    if l_28_0 and Moon_Marker.bKeepAlly then
      local l_28_30 = l_28_0
    end
    if Moon_Marker.GetCharacter(l_28_28) and (IsAlly(l_28_3.dwID, Moon_Marker.GetCharacter(l_28_28).dwID) or l_28_3.dwID == Moon_Marker.GetCharacter(l_28_28).dwID) then
      l_28_30 = false
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_28_30 then
      l_28_24[l_28_28] = nil
      l_28_2.SetTeamMark(0, l_28_28)
    else
      l_28_20[l_28_29] = l_28_28
      l_28_21 = l_28_21 + 1
    end
  end
  if l_28_0 and l_28_1 then
    Msg("��������ɡ�")
    return 
  end
  if #l_0_0 <= l_28_21 then
    Msg("����Ѿ������ˡ�")
    return 
  end
  do
    local l_28_34, l_28_45 = , Moon_Marker.GetAllPlayer()
    for l_28_38,l_28_39 in pairs(l_28_45) do
      if Moon_Marker.tMarkForce[l_28_39.dwForceID] and not l_28_34[l_28_39.dwID] and IsEnemy(l_28_3.dwID, l_28_39.dwID) then
        for l_28_43 = 1, 10 do
          if not l_28_20[l_28_43] then
            l_28_20[l_28_43] = l_28_39.dwID
            l_28_21 = l_28_21 + 1
            Moon_Marker.MarkerPlayer(l_28_39, l_28_43)
          end
          do break end
        end
      end
      if l_28_21 >= 10 then
        do break end
      end
    end
  end
  Msg("��ɱ��,��ǰ��%d�����":format(l_28_21))
end

local l_0_3 = 0
Moon_Marker.QuickKeyMark = function()
  -- upvalues: l_0_3
  local l_29_0 = GetLogicFrameCount()
  if l_29_0 - l_0_3 > 8 then
    l_0_3 = l_29_0
    Moon_Marker.QuickMark()
  else
    Moon_Marker.QuickMark(true)
  end
end

Moon_Marker.InsertForceMenu = function(l_30_0)
  local l_30_1 = table.insert
  local l_30_2 = l_30_0
  local l_30_3 = {}
  l_30_3.szOption = "�ж����"
  l_30_3.bNotHead = true
  l_30_1(l_30_2, l_30_3)
  l_30_1 = table
  l_30_1 = l_30_1.insert
  l_30_2 = l_30_0
  l_30_1(l_30_2, l_30_3)
  l_30_3 = {bDevide = true}
  l_30_1 = ipairs
  l_30_2 = Moon_Marker
  l_30_2 = l_30_2.tForceOrder
  l_30_1 = l_30_1(l_30_2)
  for i_1,i_2 in l_30_1 do
    do
      local l_30_6 = table.insert
      local l_30_7 = l_30_0
      local l_30_8 = {}
      l_30_8.szOption = g_tStrings.tForceTitle[l_30_5]
      l_30_8.bCheck = true
      l_30_8.bChecked = Moon_Marker.tMarkForce[l_30_5]
      l_30_8.fnAction = function(l_31_0, l_31_1)
        -- upvalues: l_30_5
        Moon_Marker.tMarkForce[l_30_5] = l_31_1
      end
      l_30_6(l_30_7, l_30_8)
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

Moon_Marker.Create = function(l_31_0)
  local l_31_1 = l_31_0:Lookup("", "")
  BoxBoolCheckBox(l_31_0, "CheckBox_bOpenPanel", "�������ѡ�����", Moon_Marker, "bIsOpen", nil, Moon_Marker.ClosePanel)
  BoxBoolCheckBox(l_31_0, "CheckBox_bInParty", "��������������ʾ", Moon_Marker, "bInParty"):SetRelPos(230, 0)
  BoxBoolCheckBox(l_31_0, "CheckBox_bConvergeTarget", "����˫����Ƿ�����������", Moon_Marker, "bConvergeTarget"):SetRelPos(0, 30)
  BoxBoolCheckBox(l_31_0, "CheckBox_bSelectConverge", "�������ղ�ִ�м�������", Moon_Marker, "bSelectConverge"):SetRelPos(230, 30)
  BoxBoolCheckBox(l_31_0, "CheckBox_bConvergeGuild", "Ұ��ʱ���ð��Ƶ������", Moon_Marker, "bConvergeGuild"):SetRelPos(0, 60)
  local l_31_2 = BoxLabel
  local l_31_3 = l_31_1
  local l_31_4 = "label1"
  local l_31_5 = "���Լ�������"
  local l_31_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_2(l_31_3, l_31_4, l_31_5, l_31_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_2(l_31_3, l_31_4, l_31_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_2(l_31_3, l_31_4, l_31_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_2(l_31_3, l_31_4, l_31_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_2(l_31_3, l_31_4, l_31_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_31_7 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_4(l_31_5, l_31_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_4(l_31_5, l_31_6, l_31_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_7 = {min = 5, max = 40, step = 7, val = Moon_Marker.nIgnoreTDis, x = 165, y = 218}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_7 = "labelDis"
  local l_31_8 = tostring(Moon_Marker.nIgnoreTDis .. "��")
  local l_31_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_31_10 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8, l_31_9, l_31_10, 213)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8, l_31_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8, l_31_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8, l_31_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7, l_31_8, l_31_9, l_31_10, 27)
  l_31_10 = {0, 240}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_31_6(l_31_7)
end

RegisterMoonButton("Marker", 1457, "��Ǻͼ���", "General", Moon_Marker.Create)
RegisterPlayerMenu("marker", function()
  if not Moon_Marker.bPlayerMenu then
    return {}
  end
  local l_32_0 = {}
  l_32_0.szOption = "���ٱ��"
  local l_32_1 = {}
  l_32_1.szOption = "���ٱ��"
  l_32_1.fnAction = function()
    Moon_Marker.QuickMark()
  end
  local l_32_2 = {}
  l_32_2.szOption = "���±��"
  l_32_2.fnAction = function()
    Moon_Marker.QuickMark(true)
  end
  local l_32_3 = {}
  l_32_3.szOption = "��ձ��"
  l_32_3.fnAction = function()
    Moon_Marker.QuickMark(true, true)
  end
  local l_32_4 = {}
  l_32_4.bDevide = true
  local l_32_5 = {}
  l_32_5.szOption = "�����ѷ�"
  l_32_5.bCheck = true
  l_32_5.bChecked = Moon_Marker.bKeepAlly
  l_32_5.fnAction = function()
    Moon_Marker.bKeepAlly = not Moon_Marker.bKeepAlly
  end
  local l_32_6 = {}
  l_32_6.szOption = "��������"
  l_32_6.bCheck = true
  l_32_6.bChecked = Moon_Marker.bTherapyTop
  l_32_6.fnAction = function()
    Moon_Marker.bTherapyTop = not Moon_Marker.bTherapyTop
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_32_2 = Moon_Marker
  l_32_2 = l_32_2.InsertForceMenu
  l_32_3, l_32_1 = l_32_1, {szOption = "���ְҵ"}
  l_32_2(l_32_3)
  l_32_2 = table
  l_32_2 = l_32_2.insert
  l_32_3 = l_32_0
  l_32_4 = l_32_1
  l_32_2(l_32_3, l_32_4)
  l_32_3 = l_32_0
  return l_32_2
  l_32_2 = {l_32_3}
end
)
RegisterTraceButtonMenu("marker", function()
  local l_33_0 = {}
  l_33_0.szOption = "���ѡ�����"
  l_33_0.bCheck = true
  l_33_0.bChecked = Moon_Marker.bIsOpen
  l_33_0.fnAction = function()
    if Moon_Marker.bIsOpen then
      Moon_Marker.bIsOpen = false
      Moon_Marker.ClosePanel()
    else
      local l_34_0 = GetClientPlayer()
      if not l_34_0.IsInParty() and Moon_Marker.bInParty then
        Moon_Marker.bInParty = false
      end
      Moon_Marker.bIsOpen = true
    end
  end
  do
    local l_33_1 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_33_1
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
Hotkey.AddBinding("Marker_QuickMark", "����/����2���ر�", "��Ǻͼ���", Moon_Marker.QuickKeyMark, nil)
Hotkey.AddBinding("Marker_ClearMark", "��ձ��", nil, function()
  Moon_Marker.QuickMark(true, true)
end
, nil)
Hotkey.AddBinding("Marker_ConvergeTarget", "����ǰĿ��", nil, Moon_Marker.ConvergeTarget, nil)
for l_0_7,l_0_8 in ipairs(l_0_0) do
  do
    Hotkey.AddBinding("Marker_Jihuo" .. l_0_7, "ѡ��/����[" .. l_0_8 .. "]", nil, function()
      -- upvalues: l_0_7
      Moon_Marker.Jihuo(Moon_Marker.Markers[l_0_7 - 1].imgMarker.dwID)
    end, nil)
  end
end

