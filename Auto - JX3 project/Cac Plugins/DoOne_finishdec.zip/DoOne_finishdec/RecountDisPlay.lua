-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RecountDisPlay.lua 

Recount.GetTime = function()
  local l_1_0 = GetClientPlayer().bFightState
  local l_1_1 = nil
  if l_1_0 then
    l_1_1 = Recount.totalfighttime + (GetTime() - Recount.startfighttime)
  else
    l_1_1 = Recount.totalfighttime
  end
  return l_1_1
end

Recount.FormatHandle = function()
  if #Recount.PlayerDataDisplayList == 0 then
    Recount.hputwnd:Clear()
    return false
  end
  if Recount.hputwnd:GetItemCount() ~= #Recount.PlayerDataDisplayList then
    Recount.hputwnd:Clear()
    for l_2_3 = 1, #Recount.PlayerDataDisplayList do
      local l_2_4 = Recount.hputwnd:AppendItemFromIni("interface/Moon_zRecount/Recount.ini", "Handle_Text", l_2_3)
      l_2_4:SetRelPos(0, (l_2_3 - 1) * 26)
      l_2_4.bTip = true
    end
    Recount.hputwnd:FormatAllItemPos()
  end
  return true
end

Recount.DisplayByDamage = function()
  if Recount.PlayerDataRecordList == nil then
    return 
  end
  local l_3_0 = 0
  local l_3_1 = 0
  Recount.PlayerDataDisplayList = {}
  for l_3_5,l_3_6 in pairs(Recount.PlayerDataRecordList) do
    if l_3_6.DamageRecordList and not IsEmpty(l_3_6.DamageRecordList) then
      Recount.PlayerDataDisplayList[#Recount.PlayerDataDisplayList + 1] = l_3_6
      l_3_0 = l_3_0 + l_3_6.nTotalDamage
    end
  end
  if not Recount.FormatHandle() then
    return 
  end
  table.sort(Recount.PlayerDataDisplayList, function(l_4_0, l_4_1)
    return l_4_1.nTotalDamage < l_4_0.nTotalDamage
  end)
  for l_3_10,l_3_11 in ipairs(Recount.PlayerDataDisplayList) do
    if l_3_10 == 1 then
      if l_3_11.nTotalDamage == 0 then
        return 
      end
      l_3_1 = l_3_11.nTotalDamage
    end
    local l_3_12 = Recount.hputwnd:Lookup(tostring(l_3_10))
    l_3_12:Lookup("Text_Entry_L"):SetText(l_3_11.szName)
    l_3_12.szName = l_3_11.szName
    local l_3_13 = l_3_12:Lookup("Text_Entry_R")
    if RECOUNT_FANGSHI.fangshi == "TotalDamage" then
      local l_3_14 = l_3_11.nTotalDamage / (l_3_0) * 100
      l_3_13:SetText(l_3_11.nTotalDamage .. "(" .. string.format("%.1f", l_3_14) .. "%)")
    else
      local l_3_15 = math.floor(Recount.GetTime() / 1000)
      if l_3_15 > 0 then
        l_3_13:SetText(math.floor(l_3_11.nTotalDamage / l_3_15) .. "DPS")
      end
    else
      l_3_13:SetText(l_3_11.nTotalDamage .. "DPS")
    end
    local l_3_16 = l_3_12:Lookup("Shadow_Entry")
    local l_3_17 = l_3_11.nTotalDamage / l_3_1 * 300
    local l_3_18, l_3_19 = l_3_16:GetSize()
    l_3_16:SetSize(l_3_17, l_3_19)
    l_3_16:SetColorRGB(l_3_11.tClassColor[1], l_3_11.tClassColor[2], l_3_11.tClassColor[3])
    l_3_16:SetAlpha(l_3_11.tClassColor[4])
    if not l_3_12:IsVisible() then
      l_3_12:Show()
    end
  end
end

Recount.DisplayByHeal = function()
  if Recount.PlayerDataRecordList == nil then
    return 
  end
  local l_4_0 = 0
  local l_4_1 = 0
  Recount.PlayerDataDisplayList = {}
  for l_4_5,l_4_6 in pairs(Recount.PlayerDataRecordList) do
    if l_4_6.HealRecordList and not IsEmpty(l_4_6.HealRecordList) then
      Recount.PlayerDataDisplayList[#Recount.PlayerDataDisplayList + 1] = l_4_6
      l_4_0 = l_4_0 + l_4_6.nTotalHeal
    end
  end
  if not Recount.FormatHandle() then
    return 
  end
  table.sort(Recount.PlayerDataDisplayList, function(l_5_0, l_5_1)
    return l_5_1.nTotalHeal < l_5_0.nTotalHeal
  end)
  for l_4_10,l_4_11 in ipairs(Recount.PlayerDataDisplayList) do
    if l_4_10 == 1 then
      if l_4_11.nTotalHeal == 0 then
        return 
      end
      l_4_1 = l_4_11.nTotalHeal
    end
    local l_4_12 = Recount.hputwnd:Lookup(tostring(l_4_10))
    l_4_12:Lookup("Text_Entry_L"):SetText(l_4_11.szName)
    l_4_12.szName = l_4_11.szName
    local l_4_13 = l_4_12:Lookup("Text_Entry_R")
    if RECOUNT_FANGSHI.fangshi == "TotalDamage" then
      local l_4_14 = l_4_11.nTotalHeal / (l_4_0) * 100
      l_4_13:SetText(l_4_11.nTotalHeal .. "(" .. string.format("%.1f", l_4_14) .. "%)")
    else
      local l_4_15 = math.floor(Recount.GetTime() / 1000)
      if l_4_15 > 0 then
        l_4_13:SetText(math.floor(l_4_11.nTotalHeal / l_4_15) .. "HPS")
      end
    else
      l_4_13:SetText(l_4_11.nTotalHeal .. "HPS")
    end
    local l_4_16 = l_4_12:Lookup("Shadow_Entry")
    local l_4_17 = l_4_11.nTotalHeal / l_4_1 * 300
    local l_4_18, l_4_19 = l_4_16:GetSize()
    l_4_16:SetSize(l_4_17, l_4_19)
    l_4_16:SetColorRGB(l_4_11.tClassColor[1], l_4_11.tClassColor[2], l_4_11.tClassColor[3])
    l_4_16:SetAlpha(l_4_11.tClassColor[4])
    if not l_4_12:IsVisible() then
      l_4_12:Show()
    end
  end
end

Recount.DisplayByBeDamage = function()
  if Recount.PlayerDataRecordList == nil then
    return 
  end
  local l_5_0 = 0
  local l_5_1 = 0
  Recount.PlayerDataDisplayList = {}
  for l_5_5,l_5_6 in pairs(Recount.PlayerDataRecordList) do
    if l_5_6.nTotalBeDamage > 0 then
      Recount.PlayerDataDisplayList[#Recount.PlayerDataDisplayList + 1] = l_5_6
      l_5_0 = l_5_0 + l_5_6.nTotalBeDamage
    end
  end
  if not Recount.FormatHandle() then
    return 
  end
  table.sort(Recount.PlayerDataDisplayList, function(l_6_0, l_6_1)
    return l_6_1.nTotalBeDamage < l_6_0.nTotalBeDamage
  end)
  for l_5_10,l_5_11 in ipairs(Recount.PlayerDataDisplayList) do
    if l_5_10 == 1 then
      if l_5_11.nTotalBeDamage == 0 then
        return 
      end
      l_5_1 = l_5_11.nTotalBeDamage
    end
    local l_5_12 = Recount.hputwnd:Lookup(tostring(l_5_10))
    l_5_12.szName = l_5_11.szName
    l_5_12:Lookup("Text_Entry_L"):SetText(l_5_11.szName)
    local l_5_13 = l_5_12:Lookup("Text_Entry_R")
    if RECOUNT_FANGSHI.fangshi == "TotalDamage" then
      local l_5_14 = l_5_11.nTotalBeDamage / (l_5_0) * 100
      l_5_13:SetText(l_5_11.nTotalBeDamage .. "(" .. string.format("%.1f", l_5_14) .. "%)")
    else
      local l_5_15 = math.floor(Recount.GetTime() / 1000)
      if l_5_15 > 0 then
        l_5_13:SetText(math.floor(l_5_11.nTotalBeDamage / l_5_15) .. "DPS")
      end
    else
      l_5_13:SetText(l_5_11.nTotalBeDamage .. "DPS")
    end
    local l_5_16 = l_5_12:Lookup("Shadow_Entry")
    local l_5_17 = l_5_11.nTotalBeDamage / l_5_1 * 300
    local l_5_18, l_5_19 = l_5_16:GetSize()
    l_5_16:SetSize(l_5_17, l_5_19)
    l_5_16:SetColorRGB(l_5_11.tClassColor[1], l_5_11.tClassColor[2], l_5_11.tClassColor[3])
    l_5_16:SetAlpha(l_5_11.tClassColor[4])
    if not l_5_12:IsVisible() then
      l_5_12:Show()
    end
  end
end

Recount.DisplayByBeHeal = function()
  if Recount.PlayerDataRecordList == nil then
    return 
  end
  local l_6_0 = 0
  local l_6_1 = 0
  Recount.PlayerDataDisplayList = {}
  for l_6_5,l_6_6 in pairs(Recount.PlayerDataRecordList) do
    if l_6_6.nTotalBeHeal > 0 then
      Recount.PlayerDataDisplayList[#Recount.PlayerDataDisplayList + 1] = l_6_6
      l_6_0 = l_6_0 + l_6_6.nTotalBeHeal
    end
  end
  if not Recount.FormatHandle() then
    return 
  end
  table.sort(Recount.PlayerDataDisplayList, function(l_7_0, l_7_1)
    return l_7_1.nTotalBeHeal < l_7_0.nTotalBeHeal
  end)
  for l_6_10,l_6_11 in ipairs(Recount.PlayerDataDisplayList) do
    if l_6_10 == 1 then
      if l_6_11.nTotalBeHeal == 0 then
        return 
      end
      l_6_1 = l_6_11.nTotalBeHeal
    end
    local l_6_12 = Recount.hputwnd:Lookup(tostring(l_6_10))
    l_6_12:Lookup("Text_Entry_L"):SetText(l_6_11.szName)
    l_6_12.szName = l_6_11.szName
    local l_6_13 = l_6_12:Lookup("Text_Entry_R")
    if RECOUNT_FANGSHI.fangshi == "TotalDamage" then
      local l_6_14 = l_6_11.nTotalBeHeal / (l_6_0) * 100
      l_6_13:SetText(l_6_11.nTotalBeHeal .. "(" .. string.format("%.1f", l_6_14) .. "%)")
    else
      local l_6_15 = math.floor(Recount.GetTime() / 1000)
      if l_6_15 > 0 then
        l_6_13:SetText(math.floor(l_6_11.nTotalBeHeal / l_6_15) .. "DPS")
      end
    else
      l_6_13:SetText(l_6_11.nTotalBeHeal .. "DPS")
    end
    local l_6_16 = l_6_12:Lookup("Shadow_Entry")
    local l_6_17 = l_6_11.nTotalBeHeal / l_6_1 * 300
    local l_6_18, l_6_19 = l_6_16:GetSize()
    l_6_16:SetSize(l_6_17, l_6_19)
    l_6_16:SetColorRGB(l_6_11.tClassColor[1], l_6_11.tClassColor[2], l_6_11.tClassColor[3])
    l_6_16:SetAlpha(l_6_11.tClassColor[4])
    if not l_6_12:IsVisible() then
      l_6_12:Show()
    end
  end
end


