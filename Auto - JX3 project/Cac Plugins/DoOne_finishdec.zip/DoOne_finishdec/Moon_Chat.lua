-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon_Chat.lua 

local l_0_0 = function(l_1_0, l_1_1, l_1_2, l_1_3)
  local l_1_4 = Wnd.OpenWindow(l_1_1, l_1_3)
  local l_1_5 = l_1_4:Lookup(l_1_2)
  l_1_5:ChangeRelation(l_1_0, true, true)
  l_1_5:SetName(l_1_3)
  Wnd.CloseWindow(l_1_3)
  return l_1_5
end

local l_0_1 = classEx()
l_0_1.ctor = function(l_2_0, l_2_1, l_2_2, l_2_3)
  -- upvalues: l_0_0
  l_2_0.hwnd = l_0_0(l_2_1, "interface/Moon_Chat/ChatCheckBox.ini", l_2_3, l_2_2)
  l_2_0.type = l_2_3
end

l_0_1.ui = function(l_3_0)
  return l_3_0.hwnd
end

l_0_1.stxt = function(l_4_0, ...)
  if l_4_0.type == "CheckBox" then
    l_4_0.hwnd:Lookup("", "Text_CheckBox"):SetText(...)
  else
    l_4_0.hwnd:Lookup("", "Text_RadioBox"):SetText(...)
  end
end

l_0_1.txtColor = function(l_5_0, ...)
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_5_0.type == "CheckBox" then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  nil:SetFontColor(...)
   -- DECOMPILER ERROR: Confused about usage of registers!

  nil:SetFontBorder(1, 0, 0, 0)
end

l_0_1.OnCheck = function(l_6_0, l_6_1)
  l_6_0.hwnd.OnCheckBoxCheck = l_6_1
end

l_0_1.UnCheck = function(l_7_0, l_7_1)
  l_7_0.hwnd.OnCheckBoxUncheck = l_7_1
end

local l_0_2 = {}
local l_0_3 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_2["���"], l_0_3 = l_0_3, {255, 255, 255}
l_0_2["��"], l_0_3 = l_0_3, {196, 152, 255}
l_0_2["����"], l_0_3 = l_0_3, {89, 224, 232}
l_0_2["����"], l_0_3 = l_0_3, {255, 129, 176}
l_0_2["����"], l_0_3 = l_0_3, {255, 178, 95}
l_0_2["�ؽ�"], l_0_3 = l_0_3, {214, 249, 93}
l_0_2["�嶾"], l_0_3 = l_0_3, {55, 147, 255}
l_0_2["����"], l_0_3 = l_0_3, {121, 183, 54}
l_0_2["����"], l_0_3 = l_0_3, {240, 70, 96}
l_0_2["ؤ��"], l_0_3 = l_0_3, {205, 133, 63}
ChatDefaultColor = l_0_2
local l_0_4 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_5 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_6 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_7 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_8 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_9 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_10 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_11 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_12 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

do
  local l_0_13 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, l_0_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, l_0_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_3(l_0_4, l_0_5, l_0_6, l_0_7, l_0_8)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

end
 -- WARNING: undefined locals caused missing assignments!

