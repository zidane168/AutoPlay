-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: FlashAlarm.lua 

local l_0_0 = {}
l_0_0.times = 0
l_0_0.maxAlpha = 128
l_0_0.minAlpha = 0
l_0_0.alpha = 0
l_0_0.bFlash = true
l_0_0.bMsg = true
FlashAlarm = l_0_0
FlashAlarm.OnFrameCreate = function()
  local l_1_0 = this
  FlashAlarm.img = l_1_0:Lookup("", "Image_Tip")
  FlashAlarm.img:Hide()
  this:RegisterEvent("UI_SCALED")
end

FlashAlarm.OnEvent = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    local l_2_1 = this
    local l_2_2, l_2_3 = Station.GetClientSize(true)
    FlashAlarm.img:SetSize(l_2_2, l_2_3)
  end
end

FlashAlarm.OnFrameRender = function()
  local l_3_0 = GetFPS()
  local l_3_1 = 1000 / l_3_0
  if FlashAlarm.times > 0 then
    if FlashAlarm.img.bAdd then
      FlashAlarm.alpha = FlashAlarm.alpha + 16 * l_3_1 / 67
      if FlashAlarm.maxAlpha <= FlashAlarm.alpha then
        FlashAlarm.alpha = FlashAlarm.maxAlpha
        FlashAlarm.img.bAdd = false
      end
    else
      FlashAlarm.alpha = FlashAlarm.alpha - 16 * l_3_1 / 67
    end
    if FlashAlarm.alpha <= FlashAlarm.minAlpha then
      FlashAlarm.alpha = FlashAlarm.minAlpha
      FlashAlarm.img.bAdd = true
      FlashAlarm.times = FlashAlarm.times - 1
    end
    local l_3_2 = FlashAlarm.alpha
    if not DBMPanel_Set.bFlashAlarm or not FlashAlarm.bFlash then
      l_3_2 = 0
    end
    if l_3_2 > 0 then
      FlashAlarm.Draw(l_3_2)
      FlashAlarm.img:Show()
    end
    local l_3_3 = FlashAlarm.alpha + 128
    if not DBMPanel_Set.bMsgAlarm or not FlashAlarm.bMsg then
      l_3_3 = 0
    end
    if l_3_3 > 0 then
      MsgAlarm.UpdateAlpha(l_3_3)
      MsgAlarm.hmsg:Show()
    end
  else
    if FlashAlarm.img:IsVisible() then
      FlashAlarm.Draw(0)
      FlashAlarm.img:Hide()
    end
  end
  if MsgAlarm.hmsg:IsVisible() then
    MsgAlarm.UpdateAlpha(0)
    MsgAlarm.hmsg:Hide()
  end
end

FlashAlarm.Draw = function(l_4_0)
  FlashAlarm.img:SetAlpha(l_4_0)
end

CreateDBMAlarm = function(l_5_0, l_5_1, l_5_2, l_5_3, l_5_4)
  -- upvalues: l_0_0
  FlashAlarm.bFlash = l_5_1
  FlashAlarm.bMsg = l_5_3
  local l_5_5 = FlashAlarm
  local l_5_6 = nil
  if not l_5_0 then
    l_5_6 = 3
  end
  l_5_5.times = l_5_6
  l_5_5 = FlashAlarm
  l_5_5 = l_5_5.img
  l_5_5.bAdd = true
  l_5_5 = FlashAlarm
  l_5_6 = FlashAlarm
  l_5_6 = l_5_6.minAlpha
  l_5_5.alpha = l_5_6
  if l_5_2 and l_5_2 ~= "" then
    l_5_5 = FlashAlarm
    l_5_5 = l_5_5.img
    l_5_5, l_5_6 = l_5_5:SetFrame, l_5_5
    l_5_5(l_5_6, l_0_0[l_5_2])
  end
  l_5_5 = FlashAlarm
  l_5_5 = l_5_5.bMsg
  if l_5_5 then
    l_5_5 = MsgAlarm
    l_5_5 = l_5_5.UpdateMsg
    l_5_6 = l_5_4
    l_5_5(l_5_6)
  end
end

Wnd.OpenWindow("interface\\Moon_DBM\\FlashAlarm.ini", "FlashAlarm")

