-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Options.lua 

local l_0_0 = function(l_1_0, l_1_1)
  if l_1_1 < R3_PC3 / 3 then
    return "TOP"
  else
    return "BOTTOM"
  end
   -- WARNING: undefined locals caused missing assignments!
end

local l_0_1 = function()
  local l_2_0 = Station.Lookup("Normal1/WorldMark")
  if l_2_0 and l_2_0:IsVisible() then
    return true
  end
  return false
end

local l_0_3 = function()
  -- upvalues: l_0_1 , l_0_0
  if l_0_1() then
    return 
  end
  local l_3_0 = GetClientPlayer()
  local l_3_1, l_3_2 = GetMapParams(l_3_0.GetMapID())
  if not l_3_2 or l_3_2 ~= MAP_TYPE.DUNGEON then
    OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.STR_WORLD_MARK)
    return 
  end
  local l_3_3 = Wnd.OpenWindow("WorldMark")
  local l_3_4 = Station.Lookup("Normal/RaidGridEx")
  local l_3_5, l_3_6 = l_3_4:GetAbsPos()
  local l_3_7, l_3_8 = l_3_4:GetSize()
  local l_3_9 = l_0_0(l_3_5, l_3_6)
  if l_3_9 == "TOP" then
    l_3_3:SetAbsPos(l_3_5, l_3_6 + l_3_8)
  else
    l_3_3:SetAbsPos(l_3_5, l_3_6 - 67)
  end
end

local l_0_4 = RaidGridEx
local l_0_5 = RaidGridEx
local l_0_6 = RaidGridEx
local l_0_7 = RaidGridEx
do
  local l_0_8 = ""
  l_0_5.szMark = ""
  l_0_4.szLeader = l_0_8
  l_0_4 = RaidGridEx
  l_0_5 = function()
  local l_10_5, l_10_6, l_10_7, l_10_8, l_10_9, l_10_10, l_10_11, l_10_12, l_10_13, l_10_14, l_10_15, l_10_16, l_10_17, l_10_18 = nil
  local l_10_0 = {}
  local l_10_1 = GetClientPlayer()
  local l_10_2 = GetClientTeam()
  if not l_10_1 or not l_10_1.IsInParty() then
    local l_10_3 = Msg
    local l_10_4 = "�㲻���Ŷ��С�"
    return l_10_3(l_10_4)
  end
  local l_10_19 = l_10_2.GetClientTeamMemberName
  RaidGridEx.szLeader = l_10_19(l_10_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER))
  RaidGridEx.szMark = l_10_19(l_10_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK))
  RaidGridEx.szDistribute = l_10_19(l_10_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE))
  RaidGridEx.nLootMode = l_10_2.nLootMode
  local l_10_20 = l_10_2.GetTeamMark()
  for l_10_24 = 0, l_10_2.nGroupNum - 1 do
    local l_10_25 = l_10_2.GetGroupInfo(l_10_24)
    if not l_10_25.MemberList then
      local l_10_26, l_10_27 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_10_31,l_10_32 in ipairs(l_10_26) do
      local l_10_28 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_10_19(R15_PC62) then
        local l_10_34 = nil
        l_10_0[l_10_34] = {nGroup = l_10_24, nMark = l_10_20[l_10_33], bForm = l_10_33 == l_10_25.dwFormationLeader}
      end
    end
  end
  RaidGridEx.tSavedRaid = l_10_0
  Msg("����Ŷ��б����档")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

  l_0_4.SaveRaid = l_0_5
  l_0_4 = RaidGridEx
  l_0_5 = function(l_11_0, l_11_1, l_11_2, l_11_3)
  if RaidGridEx.bKeepFormation and l_11_3.bForm then
    l_11_0.SetTeamFormationLeader(l_11_1, l_11_3.nGroup)
  end
  if RaidGridEx.bKeepAllyMark and l_11_3.nMark then
    l_11_0.SetTeamMark(l_11_3.nMark, l_11_1)
  end
end

  l_0_4.RestoreMember = l_0_5
  l_0_4 = RaidGridEx
  l_0_5 = function(l_12_0, l_12_1)
  for l_12_5,l_12_6 in ipairs(l_12_0) do
    if not l_12_1 or l_12_6.state then
      return l_12_5
    end
  end
end

  l_0_4.GetWrongIndex = l_0_5
  l_0_4 = RaidGridEx
  l_0_5 = function()
  local l_13_4, l_13_5, l_13_6, l_13_7, l_13_8, l_13_9, l_13_10, l_13_11, l_13_12, l_13_13, l_13_14, l_13_15, l_13_16, l_13_17, l_13_18, l_13_19, l_13_20, l_13_21, l_13_22, l_13_23, l_13_24, l_13_27, l_13_28, l_13_29, l_13_30, l_13_31, l_13_32, l_13_33, l_13_34, l_13_35, l_13_36, l_13_37, l_13_38, l_13_39, l_13_40, l_13_41, l_13_42, l_13_43, l_13_44, l_13_45, l_13_46, l_13_47, l_13_51, l_13_52, l_13_53, l_13_54, l_13_55, l_13_56, l_13_57, l_13_58, l_13_59, l_13_60, l_13_61, l_13_62, l_13_63, l_13_64, l_13_65, l_13_66, l_13_67, l_13_68, l_13_69, l_13_70 = nil
  local l_13_0 = GetClientPlayer()
  local l_13_1 = GetClientTeam()
  if not l_13_0 or not l_13_0.IsInParty() then
    local l_13_2 = Msg
    local l_13_3 = "�㲻���Ŷ��У��޷�������"
    return l_13_2(l_13_3)
  else
    if IsEmpty(RaidGridEx.tSavedRaid) then
      local l_13_25 = Msg
      local l_13_26 = "���ȱ����Ŷ��б����ݡ�"
      return l_13_25(l_13_26)
    end
  end
  local l_13_48 = l_13_1.GetClientTeamMemberName
  if l_13_1.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) ~= l_13_0.dwID then
    local l_13_49 = Msg
    local l_13_50 = "�㲻�Ƕӳ����޷�������"
    return l_13_49(l_13_50)
  end
  if l_13_1.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) ~= l_13_0.dwID then
    l_13_1.SetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK, l_13_0.dwID)
  end
  local l_13_71 = RaidGridEx.tSavedRaid
  local l_13_72 = {}
  local l_13_73 = 0
  local l_13_74 = 0
  for l_13_78 = 0, l_13_1.nGroupNum - 1 do
    l_13_72[l_13_78] = {}
    local l_13_79 = l_13_1.GetGroupInfo(l_13_78)
    if not l_13_79.MemberList then
      local l_13_80, l_13_81 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_13_85,l_13_86 in pairs(l_13_80) do
      local l_13_82 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_13_48(l_13_21) then
        if not l_13_71[l_13_48(l_13_21)] then
          local l_13_88 = nil
        end
        if not l_13_71[string.gsub(l_13_48(l_13_21), "@.*", "")] then
          local l_13_89 = nil
          local l_13_90 = table.insert
          do
            local l_13_91 = l_13_72[l_13_78]
            l_13_90(l_13_91, {dwID = l_13_87, szName = l_13_88, state = nil})
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        elseif l_13_89.nGroup == l_13_78 then
          RaidGridEx.RestoreMember(l_13_1, l_13_87, l_13_88, l_13_89)
        else
          local l_13_92 = nil
          local l_13_93 = table.insert
          local l_13_94 = l_13_72[l_13_78]
          l_13_93(l_13_94, {dwID = l_13_87, szName = l_13_88, state = l_13_92})
        end
        if l_13_88 == RaidGridEx.szLeader then
          l_13_73 = l_13_87
        end
        if l_13_88 == RaidGridEx.szMark then
          l_13_74 = l_13_87
        end
      end
      if l_13_88 == RaidGridEx.szDistribute and l_13_87 ~= l_13_1.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE) then
        l_13_1.SetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE, l_13_87)
      end
    end
  end
  for l_13_98 = 0, l_13_1.nGroupNum - 1 do
    local l_13_98 = nil
    l_13_98 = RaidGridEx
    l_13_98 = l_13_98.GetWrongIndex
    l_13_98 = l_13_98(l_13_72[l_13_97], true)
    local l_13_99 = nil
    if l_13_98 then
      l_13_99 = l_13_72[l_13_97]
      l_13_99 = l_13_99[l_13_98]
      local l_13_100 = nil
      l_13_100 = RaidGridEx
      l_13_100 = l_13_100.GetWrongIndex
      l_13_100 = l_13_100(l_13_72[l_13_99.state.nGroup], false)
      local l_13_101 = nil
      l_13_101 = table
      l_13_101 = l_13_101.remove
      l_13_101(l_13_72[l_13_97], l_13_98)
      if not l_13_100 then
        l_13_101 = l_13_1.ChangeMemberGroup
        l_13_101(l_13_99.dwID, l_13_99.state.nGroup, 0)
      else
        l_13_101 = l_13_99.state
        l_13_101 = l_13_101.nGroup
        l_13_101 = l_13_72[l_13_101]
        l_13_101 = l_13_101[l_13_100]
        do
          local l_13_102 = nil
          l_13_102 = table
          l_13_102 = l_13_102.remove
          l_13_102(l_13_72[l_13_99.state.nGroup], l_13_100)
          l_13_102 = l_13_1.ChangeMemberGroup
          l_13_102(l_13_99.dwID, l_13_99.state.nGroup, l_13_101.dwID)
          l_13_102 = l_13_101.state
          if l_13_102 then
            l_13_102 = l_13_101.state
            l_13_102 = l_13_102.nGroup
          if l_13_102 ~= l_13_97 then
            end
          end
          l_13_102 = table
          l_13_102 = l_13_102.insert
          l_13_102(l_13_72[l_13_97], l_13_101)
        end
        do return end
        l_13_102 = RaidGridEx
        l_13_102 = l_13_102.RestoreMember
        l_13_102(l_13_1, l_13_101.dwID, l_13_101.szName, l_13_101.state)
      end
      l_13_101 = RaidGridEx
      l_13_101 = l_13_101.RestoreMember
      l_13_101(l_13_1, l_13_99.dwID, l_13_99.szName, l_13_99.state)
      l_13_101 = RaidGridEx
      l_13_101 = l_13_101.GetWrongIndex
      l_13_101 = l_13_101(l_13_72[l_13_97], true)
      l_13_98 = l_13_101
    end
  end
end
if l_13_1.nLootMode ~= RaidGridEx.nLootMode then
  l_13_1.SetTeamLootMode(RaidGridEx.nLootMode)
end
if l_13_73 ~= 0 and l_13_73 ~= l_13_0.dwID then
  l_13_1.SetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER, l_13_73)
end
if l_13_74 ~= 0 and l_13_74 ~= l_13_0.dwID then
  l_13_1.SetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK, l_13_74)
end
Msg("��ɻ�ԭ�Ŷ��б���")
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

  l_0_4.RestoreRaid = l_0_5
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.


