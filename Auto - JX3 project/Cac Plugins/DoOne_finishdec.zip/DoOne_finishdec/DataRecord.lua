-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DataRecord.lua 

Recount.InitPlayerData = function(l_1_0)
  if not Recount.bOn then
    return 
  end
  local l_1_1 = Recount.PlayerDataRecordList
  local l_1_2 = l_1_0.szName
  local l_1_3 = {}
  l_1_3.szName = l_1_0.szName
  l_1_3.tClassColor = Recount.GetColor(l_1_0)
  l_1_3.nTotalDamage = 0
  l_1_3.nTotalBeDamage = 0
  l_1_3.nTotalHeal = 0
  l_1_3.nTotalBeHeal = 0
  l_1_3.DamageRecordList = {}
  l_1_3.BeDamageRecordList = {}
  l_1_3.HealRecordList = {}
  l_1_3.BeHealRecordList = {}
  l_1_1[l_1_2] = l_1_3
end

Recount.TalkPetSkill = function(l_2_0)
  local l_2_1 = GetClientPlayer()
  if not l_2_1.IsInParty() then
    return 
  end
  local l_2_2 = table.concat(l_2_0, "|")
  local l_2_3 = PLAYER_TALK_CHANNEL.RAID
  local l_2_4 = l_2_1.Talk
  local l_2_5 = l_2_3
  local l_2_6 = ""
  local l_2_7 = {}
  local l_2_8 = {}
  l_2_8.type = "text"
  l_2_8.text = "BG_CHANNEL_MSG"
  local l_2_9 = {}
  l_2_9.type = "text"
  l_2_9.text = "recount_petskill"
  local l_2_10 = {}
  l_2_10.type = "text"
  l_2_10.text = tostring(l_2_1.dwID)
  local l_2_11 = {}
  l_2_11.type = "text"
  l_2_11.text = l_2_2
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_2_4(l_2_5, l_2_6, l_2_7)
end

Recount.RecivePetSKill = function(l_3_0, l_3_1)
  local l_3_2 = GetPlayer(l_3_0)
  if not l_3_2 then
    return 
  end
  local l_3_3 = string.split(l_3_1, "|")
  local l_3_4, l_3_5, l_3_6, l_3_7, l_3_8, l_3_9, l_3_10 = unpack(l_3_3)
  if (l_3_10 == "Damage" or l_3_10 == "Heal") and Recount.PlayerDataRecordList[l_3_4] == nil then
    Recount.InitPlayerData(l_3_2)
  end
  Recount.AddRecord(l_3_4, l_3_5, l_3_6, tonumber(l_3_7), tonumber(l_3_8), tonumber(l_3_9), l_3_10)
end

Recount.FileterSkillEffect = function(l_4_0)
  local l_4_1 = {}
  local l_4_5 = SKILL_RESULT_TYPE.ABSORB_DAMAGE
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_4_2 = SKILL_RESULT_TYPE.SHIELD_DAMAGE
  local l_4_3 = SKILL_RESULT_TYPE.PARRY_DAMAGE
  local l_4_4 = SKILL_RESULT_TYPE.STEAL_LIFE
  return l_4_5(l_4_2, l_4_3)
end

Recount.IsFriendlyTarget = function(l_5_0)
  local l_5_1 = GetClientPlayer()
  local l_5_2 = GetClientTeam()
  return l_5_1.IsPlayerInMyParty(l_5_0) or l_5_2.IsPlayerInTeam(l_5_0) or l_5_0 == l_5_1.dwID
end

Recount.SaveDamageAndHeal = function(l_6_0, l_6_1, l_6_2, l_6_3, l_6_4, l_6_5, l_6_6, l_6_7)
  local l_6_8 = l_6_0.szName
  if Recount.PlayerDataRecordList[l_6_8] == nil then
    Recount.InitPlayerData(l_6_0)
  end
  if l_6_5 ~= SKILL_RESULT_TYPE.THERAPY and l_6_1.dwID ~= l_6_0.dwID and not Recount.FileterSkillEffect(l_6_5) then
    if l_6_7 then
      local l_6_9 = string.format("%s(%s)", l_6_2, l_6_7.szName)
      local l_6_10 = Recount.TalkPetSkill
      do
        local l_6_11 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_6_10(l_6_11)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_6_10(l_6_11, l_6_8, l_6_1.szName, l_6_9, l_6_3, l_6_6, l_6_4)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      Recount.AddRecord(l_6_10, l_6_11, l_6_2, l_6_3, l_6_6, l_6_4, "Damage")
    end
  else
    if l_6_5 == SKILL_RESULT_TYPE.THERAPY then
      if l_6_7 then
        local l_6_12 = string.format("%s(%s)", l_6_2, l_6_7.szName)
        local l_6_13 = Recount.TalkPetSkill
        local l_6_14 = {}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_6_13(l_6_14)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_6_13(l_6_14, l_6_8, l_6_1.szName, l_6_12, l_6_3, l_6_6, l_6_4)
      end
    end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    Recount.AddRecord(l_6_13, l_6_14, l_6_2, l_6_3, l_6_6, l_6_4, "Heal")
  end
   -- WARNING: undefined locals caused missing assignments!
end

Recount.SaveBeDamageAndBeHeal = function(l_7_0, l_7_1, l_7_2, l_7_3, l_7_4, l_7_5, l_7_6)
  local l_7_7 = l_7_1.szName
  if Recount.PlayerDataRecordList[l_7_7] == nil then
    Recount.InitPlayerData(l_7_1)
  end
  local l_7_8 = l_7_2
  if l_7_2 ~= l_7_0.szName then
    l_7_8 = "%s(%s)":format(l_7_2, l_7_0.szName)
  end
  if l_7_5 ~= SKILL_RESULT_TYPE.THERAPY and l_7_1.dwID ~= l_7_0.dwID and not Recount.FileterSkillEffect(l_7_5) then
    if l_7_5 == SKILL_RESULT_TYPE.REFLECTIED_DAMAGE then
      Recount.AddRecord(l_7_1.szName, l_7_0.szName, "����", l_7_3, l_7_6, l_7_4, "Damage")
    end
    Recount.AddRecord(l_7_0.szName, l_7_1.szName, l_7_8, l_7_3, l_7_6, l_7_4, "BeDamage")
  else
    if l_7_5 == SKILL_RESULT_TYPE.THERAPY then
      Recount.AddRecord(l_7_0.szName, l_7_1.szName, l_7_8, l_7_3, l_7_6, l_7_4, "BeHeal")
    end
  end
end

Recount.OnSkillEffect = function(l_8_0, l_8_1, l_8_2, l_8_3, l_8_4, l_8_5, l_8_6, l_8_7)
  local l_8_8 = Recount.GetFromID(l_8_0)
  local l_8_9 = (Recount.GetFromID(l_8_1))
  local l_8_10 = nil
  if not l_8_8 then
    return 
  end
  if not l_8_9 then
    return 
  end
  if l_8_2 == SKILL_EFFECT_TYPE.SKILL then
    l_8_10 = Table_GetSkillName(l_8_3, l_8_4)
  else
    if l_8_2 == SKILL_EFFECT_TYPE.BUFF then
      l_8_10 = Table_GetBuffName(l_8_3, l_8_4)
    end
  end
  if not l_8_10 then
    return 
  end
  local l_8_11 = GetClientPlayer()
  local l_8_12 = IsPlayer(l_8_0)
  local l_8_13 = IsPlayer(l_8_1)
  if l_8_12 and Recount.IsFriendlyTarget(l_8_0) then
    Recount.SaveDamageAndHeal(l_8_8, l_8_9, l_8_10, l_8_2, l_8_5, l_8_6, l_8_7)
  end
  if not l_8_13 and GetNpcIntensity(l_8_9) == 4 and Recount.countboss then
    Recount.SaveBeDamageAndBeHeal(l_8_8, l_8_9, l_8_8.szName, l_8_2, l_8_5, l_8_6, l_8_7)
  end
  do return end
  if l_8_13 and Recount.countboss and Recount.IsFriendlyTarget(l_8_1) and GetNpcIntensity(l_8_8) == 4 then
    Recount.SaveDamageAndHeal(l_8_8, l_8_9, l_8_10, l_8_2, l_8_5, l_8_6, l_8_7)
  elseif l_8_8.dwEmployer ~= 0 and l_8_8.dwEmployer == l_8_11.dwID then
    local l_8_14 = GetPlayer(l_8_8.dwEmployer)
  end
  if l_8_14 then
    Recount.SaveDamageAndHeal(l_8_14, l_8_9, l_8_10, l_8_2, l_8_5, l_8_6, l_8_7, l_8_8)
  end
  if l_8_13 and Recount.IsFriendlyTarget(l_8_1) then
    Recount.SaveBeDamageAndBeHeal(l_8_8, l_8_9, l_8_10, l_8_2, l_8_5, l_8_6, l_8_7)
  end
end

Recount.AddRecord = function(l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5, l_9_6)
  if not Recount.bOn then
    return 
  end
  local l_9_7 = nil
  if l_9_6 == "Damage" then
    l_9_7 = Recount.PlayerDataRecordList[l_9_0].DamageRecordList
  elseif l_9_6 == "BeDamage" then
    l_9_7 = Recount.PlayerDataRecordList[l_9_1].BeDamageRecordList
  elseif l_9_6 == "Heal" then
    l_9_7 = Recount.PlayerDataRecordList[l_9_0].HealRecordList
  elseif l_9_6 == "BeHeal" then
    l_9_7 = Recount.PlayerDataRecordList[l_9_1].BeHealRecordList
  end
  if l_9_7 == nil then
    return 
  end
  if l_9_7[l_9_2] == nil then
    local l_9_8 = {}
    l_9_8.Name = l_9_2
    l_9_8.nMinHit = 0
    l_9_8.nMaxHit = 0
    l_9_8.nTotalHit = 0
    l_9_8.nMinCritical = 0
    l_9_8.nMaxCritical = 0
    l_9_8.nTotalCritical = 0
    l_9_8.Total = 0
    l_9_8.nTotal = 0
    l_9_8.nHit = 0
    l_9_8.nBlock = 0
    l_9_8.nShield = 0
    l_9_8.nMiss = 0
    l_9_8.nDodge = 0
    l_9_8.nCritical = 0
    l_9_8.nShipo = 0
    l_9_7[l_9_2] = l_9_8
  end
  l_9_7[l_9_2].Total = l_9_7[l_9_2].Total + l_9_4
  l_9_7[l_9_2].nTotal = l_9_7[l_9_2].nTotal + 1
  if l_9_5 == SKILL_RESULT.HIT then
    l_9_7[l_9_2].nTotalHit = l_9_7[l_9_2].nTotalHit + l_9_4
    l_9_7[l_9_2].nHit = l_9_7[l_9_2].nHit + 1
    if l_9_7[l_9_2].nMinHit == 0 or l_9_4 < l_9_7[l_9_2].nMinHit then
      l_9_7[l_9_2].nMinHit = l_9_4
    end
    if l_9_7[l_9_2].nMaxHit < l_9_4 then
      l_9_7[l_9_2].nMaxHit = l_9_4
    end
  else
    if l_9_5 == SKILL_RESULT.CRITICAL then
      l_9_7[l_9_2].nTotalCritical = l_9_7[l_9_2].nTotalCritical + l_9_4
      l_9_7[l_9_2].nCritical = l_9_7[l_9_2].nCritical + 1
      if l_9_7[l_9_2].nMinCritical == 0 or l_9_4 < l_9_7[l_9_2].nMinCritical then
        l_9_7[l_9_2].nMinCritical = l_9_4
      end
    end
    if l_9_7[l_9_2].nMaxCritical < l_9_4 then
      l_9_7[l_9_2].nMaxCritical = l_9_4
    end
  else
    if l_9_5 == SKILL_RESULT.BLOCK then
      l_9_7[l_9_2].nBlock = l_9_7[l_9_2].nBlock + 1
    end
  else
    if l_9_5 == SKILL_RESULT.SHIELD then
      l_9_7[l_9_2].nShield = l_9_7[l_9_2].nShield + 1
    end
  else
    if l_9_5 == SKILL_RESULT.MISS then
      l_9_7[l_9_2].nMiss = l_9_7[l_9_2].nMiss + 1
    end
  else
    if l_9_5 == SKILL_RESULT.DODGE then
      l_9_7[l_9_2].nDodge = l_9_7[l_9_2].nDodge + 1
    end
  else
    if l_9_5 == SKILL_RESULT.ShIPO then
      l_9_7[l_9_2].nShipo = l_9_7[l_9_2].nShipo + 1
    end
  end
  if l_9_5 == SKILL_RESULT.HIT or l_9_5 == SKILL_RESULT.CRITICAL then
    if l_9_6 == "Damage" then
      Recount.PlayerDataRecordList[l_9_0].DamageRecordList = l_9_7
      Recount.PlayerDataRecordList[l_9_0].nTotalDamage = Recount.PlayerDataRecordList[l_9_0].nTotalDamage + l_9_4
    end
  elseif l_9_6 == "BeDamage" then
    Recount.PlayerDataRecordList[l_9_1].nTotalBeDamage = Recount.PlayerDataRecordList[l_9_1].nTotalBeDamage + l_9_4
    Recount.PlayerDataRecordList[l_9_1].BeDamageRecordList = l_9_7
  elseif l_9_6 == "Heal" then
    Recount.PlayerDataRecordList[l_9_0].nTotalHeal = Recount.PlayerDataRecordList[l_9_0].nTotalHeal + l_9_4
    Recount.PlayerDataRecordList[l_9_0].HealRecordList = l_9_7
  elseif l_9_6 == "BeHeal" then
    Recount.PlayerDataRecordList[l_9_1].nTotalBeHeal = Recount.PlayerDataRecordList[l_9_1].nTotalBeHeal + l_9_4
    Recount.PlayerDataRecordList[l_9_1].BeHealRecordList = l_9_7
  end
  Recount.Display()
  local l_9_9 = Station.Lookup("Normal/ShowDetail")
  if l_9_9 and l_9_9:IsVisible() then
    ShowDetail.Display()
  end
end


