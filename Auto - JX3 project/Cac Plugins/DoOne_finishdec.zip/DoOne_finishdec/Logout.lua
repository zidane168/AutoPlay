-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Logout.lua 

Moon_Logout = {}
Moon_Logout.bOn = true
RegisterCustomData("Moon_Logout.bUse")
Moon_Logout.Create = function(l_1_0)
  local l_1_1 = l_1_0:Lookup("", "")
  BoxBoolCheckBox(l_1_0, "CheckBox_bOn", "�������ٵǳ��˵�", Moon_Logout, "bOn")
  local l_1_2 = BoxLabel
  local l_1_3 = l_1_1
  local l_1_4 = "label_tip"
  local l_1_5 = "ע��Ҳ��ͨ����ݼ����п��ٵǳ�"
  do
    local l_1_6 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_1_2(l_1_3, l_1_4, l_1_5, l_1_6)
    l_1_2(l_1_3)
  end
   -- WARNING: undefined locals caused missing assignments!
end

RegisterMoonButton("Logout", 97, "���ٵǳ�", "General", Moon_Logout.Create)
RegisterPlayerMenu("a_logout", function(l_2_0)
  if not Moon_Logout.bOn then
    return {}
  end
  local l_2_1 = {}
  local l_2_2 = {}
  l_2_2.szOption = "���ٵǳ�"
  local l_2_3 = {}
  l_2_3.szOption = "��������ѡ��"
  l_2_3.fnAction = function()
    ReInitUI(LOAD_LOGIN_REASON.RETURN_ROLE_LIST)
  end
  local l_2_4 = {}
  l_2_4.szOption = "������¼����"
  l_2_4.fnAction = function()
    ReInitUI(LOAD_LOGIN_REASON.RETURN_GAME_LOGIN)
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  return l_2_1
end
)
Hotkey.AddBinding("logout_role", "��������ѡ��", "���ٵǳ�", function()
  ReInitUI(LOAD_LOGIN_REASON.RETURN_ROLE_LIST)
end
, nil)
Hotkey.AddBinding("logout_login", "������¼����", nil, function()
  ReInitUI(LOAD_LOGIN_REASON.RETURN_GAME_LOGIN)
end
, nil)
RegisterBoxAddonVersion("Moon_Logout", 0.6)

