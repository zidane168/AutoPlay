-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetShow.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
local l_0_27 = string.format
local l_0_28 = {}
local l_0_29 = {}
l_0_29.s = "TOPLEFT"
l_0_29.r = "TOPLEFT"
l_0_29.x = 350
l_0_29.y = 10
l_0_28.DefaultAnchor = l_0_29
l_0_28.Anchor, l_0_29 = l_0_29, {s = "TOPLEFT", r = "TOPLEFT", x = 350, y = 10}
TargetShow = l_0_28
l_0_28 = RegisterCustomData
l_0_29 = "TargetShow.Anchor"
l_0_28(l_0_29)
l_0_28 = 1
if l_0_28 == 1 and l_0_28 == 1 then
  l_0_28 = 0
  l_0_29 = function()
    -- upvalues: l_0_28
    return l_0_28 == 2 or l_0_28 == 3
  end
end
end
end
l_0_29 = function()
local l_2_0 = 1
if l_2_0 == 1 and l_2_0 == 1 then
l_2_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_2_2 = nil
if function()
  -- upvalues: l_2_0
  return l_2_0 == 2 or l_2_0 == 3
end
.modelView == nil then
TargetShow.modelView = PlayerModelView.new()
TargetShow.modelView:init()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
local l_0_30 = function()
local l_3_0 = 1
if l_3_0 == 1 and l_3_0 == 1 then
l_3_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_3_2 = nil
if function()
  -- upvalues: l_3_0
  return l_3_0 == 2 or l_3_0 == 3
end
.modelView then
TargetShow.modelView:UnloadModel()
TargetShow.modelView:release()
TargetShow.modelView = nil
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
TargetShow.OnFrameDestroy = function()
-- upvalues: l_0_30
if PrettyShow.Options.TargetEnable == true then
l_0_30()
end
end
local l_0_31 = {}
l_0_31.NONE = 1
l_0_31.PREPARE = 2
l_0_31.DONE = 3
l_0_31.BREAK = 4
l_0_31.FADE = 5
ACTION_STATE = l_0_31
l_0_31 = TargetShow
l_0_31.OnFrameCreate = function()
-- upvalues: l_0_29
this:RegisterEvent("NPC_STATE_UPDATE")
this:RegisterEvent("NPC_LEAVE_SCENE")
this:RegisterEvent("BUFF_UPDATE")
this:RegisterEvent("PLAYER_STATE_UPDATE")
this:RegisterEvent("PLAYER_ENTER_SCENE")
this:RegisterEvent("PLAYER_LEAVE_SCENE")
this:RegisterEvent("UPDATE_RELATION")
this:RegisterEvent("UPDATE_ALL_RELATION")
this:RegisterEvent("PLAYER_LEVEL_UP")
this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
this:RegisterEvent("PARTY_UPDATE_BASE_INFO")
this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
this:RegisterEvent("SET_SHOW_VALUE_BY_PERCENTAGE")
this:RegisterEvent("SET_TARGET_SHOW_STATE_VALUE")
this:RegisterEvent("PARTY_SET_MARK")
this:RegisterEvent("SET_SHOW_STANDARD_TARGET")
this:RegisterEvent("UI_SCALED")
this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
this:RegisterEvent("TARGET_ANCHOR_CHANGED")
this:RegisterEvent("NPC_DROP_TARGET_UPDATE")
this:RegisterEvent("CUSTOM_DATA_LOADED")
this:RegisterEvent("CHANGE_CAMP")
this:RegisterEvent("UI_ON_DAMAGE_EVENT")
this:RegisterEvent("CHANGE_CAMP_FLAG")
TargetShow.UpdateAnchor(this)
l_0_29()
UpdateCustomModeWindow(this, g_tStrings.TARGET)
end
l_0_31 = function(l_6_0, l_6_1, l_6_2, l_6_3, l_6_4, l_6_5, l_6_6, l_6_7, l_6_8)
-- upvalues: l_0_0 , l_0_1 , l_0_2 , l_0_3 , l_0_4 , l_0_5 , l_0_6 , l_0_7
if not l_0_0(l_6_4, l_6_7) then
return 
end
if PrettyShow.Options.nFilters[l_6_4] == true and PrettyShow.Options.TargetFilter == true then
return 
end
local l_6_9 = l_0_1()
if PrettyShow.Options.bOwnOnly and (not l_6_8 or l_6_9.dwID ~= l_6_8) then
return 
end
if l_6_1 then
l_6_0:RemoveItem("b" .. l_6_2)
l_6_0:FormatAllItemPos()
else
local l_6_10 = l_6_0:Lookup("b" .. l_6_2)
if l_6_10 then
  l_6_10.nCount = l_6_5
  l_6_10.nEndFrame = l_6_6
  l_6_10.bCanCancel = l_6_3
  l_6_10.dwBuffID = l_6_4
  l_6_10.nLevel = l_6_7
  l_6_10.bSparking = l_0_2(l_6_4, l_6_7)
  l_6_10.bShowTime = l_0_3(l_6_4, l_6_7)
  l_6_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_6_4)
  l_6_10:SetObjectIcon(l_0_4(l_6_4, l_6_7))
  l_6_10.nStartFrame = l_0_5(l_6_4, l_6_7)
  l_6_10.bCool = true
  if l_6_5 > 1 then
    l_6_10:SetOverText(0, l_6_5)
  end
  if l_6_8 and l_6_9.dwID == l_6_8 then
    l_6_10:SetIndex(0)
  end
else
  if PrettyShow.Options.bCool_Own == true then
    l_6_10.bCool = false
  end
else
  local l_6_11 = string.gsub("<box>w=40 h=40 eventid=525311</box>", "40", PrettyShow.Options.nSize)
  l_6_0:AppendItemFromString(l_6_11)
  l_6_10 = l_6_0:Lookup(l_6_0:GetItemCount() - 1)
  l_6_10.bCool = true
  if l_6_8 and l_6_9.dwID == l_6_8 then
    l_6_10:SetIndex(0)
  else
    if PrettyShow.Options.bCool_Own == true then
      l_6_10.bCool = false
    end
  end
  l_6_10:SetName("b" .. l_6_2)
  l_6_10.nCount = l_6_5
  l_6_10.nEndFrame = l_6_6
  l_6_10.nStartFrame = l_0_5(l_6_4, l_6_7)
  l_6_10.bCanCancel = l_6_3
  l_6_10.dwBuffID = l_6_4
  l_6_10.nLevel = l_6_7
  l_6_10.nIndex = l_6_2
  l_6_10.bSparking = l_0_2(l_6_4, l_6_7)
  l_6_10.bShowTime = l_0_3(l_6_4, l_6_7)
  l_6_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_6_4)
  l_6_10:SetObjectIcon(l_0_4(l_6_4, l_6_7))
  l_6_10:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP + 4)
  l_6_10:SetOverTextFontScheme(0, 15)
  l_6_10:SetOverTextFontScheme(1, 16)
  if l_6_5 > 1 then
    l_6_10:SetOverText(0, l_6_5)
  end
  if l_6_0:GetName() == "Handle_Debuff" then
    local l_6_12 = "\\ui\\Image\\Common\\Box.UITex"
    local l_6_13 = 1
    l_6_10:SetExtentImage(l_6_12, l_6_13)
  else
    local l_6_14 = "\\ui\\Image\\Common\\Box.UITex"
    local l_6_15 = 13
    l_6_10:SetExtentImage(l_6_14, l_6_15)
  end
  l_6_10.OnItemMouseEnter = function()
    -- upvalues: l_0_6
    local l_7_0 = this:GetRoot()
    this:SetObjectMouseOver(1)
    local l_7_1 = math.floor(this.nEndFrame - l_0_6()) / 16 + 1
    local l_7_2, l_7_3 = this:GetAbsPos()
    local l_7_4, l_7_5 = this:GetSize()
    local l_7_6 = OutputBuffTip
    local l_7_7 = l_7_0.dwID
    local l_7_8 = this.dwBuffID
    local l_7_9 = this.nLevel
    local l_7_10 = this.nCount
    local l_7_11 = this.bShowTime
    local l_7_12 = l_7_1
    do
      local l_7_13 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_7_6(l_7_7, l_7_8, l_7_9, l_7_10, l_7_11, l_7_12, l_7_13)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_6_10.OnItemMouseHover = l_6_10.OnItemMouseEnter
  l_6_10.OnItemMouseLeave = function()
    HideTip()
    this:SetObjectMouseOver(0)
  end
  l_6_10.OnItemRButtonDown = function()
    -- upvalues: l_0_7 , l_6_4 , l_6_7
    local l_9_0 = {}
    do
      local l_9_1 = l_0_7(l_6_4, l_6_7) or "δ֪"
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_9_2 = "  [" .. l_9_1 .. "]   "
    local l_9_3 = {}
    l_9_3.szOption = l_9_2
    local l_9_4 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_9_4(255, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

    table.insert(l_9_0, 0)
    do
      local l_9_6 = function(l_10_0, l_10_1)
      -- upvalues: l_3_1
      PrettyShow.Options.nFilters[l_10_0] = true
      FireEvent("BUFF_RESET")
      OutputMessage("MSG_SYS", l_3_1 .. "�Ѽ��������б�\n")
    end
      table.insert(l_9_0, {szOption = "���������б�(������ʾ)", UserData = l_6_4, fnAction = l_9_6})
      PopupMenu(l_9_0)
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
  l_6_10.OnItemLButtonDown = function()
    -- upvalues: l_0_7 , l_6_4 , l_6_7
    if not l_0_7(l_6_4, l_6_7) then
      local l_10_0 = not IsCtrlKeyDown() or "δ֪"
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_10_1 = "  [" .. l_10_0 .. "]   "
    PrettyShow.Options.nFilters[l_6_4] = true
    FireEvent("BUFF_RESET")
    OutputMessage("MSG_SYS", l_10_1 .. "�Ѽ��������б�\n")
  end
  l_6_0:FormatAllItemPos()
end
if PrettyShow.Options.nCol ~= -1 then
  local l_6_16 = l_6_0:GetItemCount()
  local l_6_17, l_6_18 = l_6_0:GetAbsPos()
  for l_6_22 = 0, l_6_16 - 1 do
    local l_6_23 = l_6_0:Lookup(l_6_22)
    local l_6_24 = math.floor(l_6_22 / PrettyShow.Options.nCol)
    local l_6_25 = l_6_22 % PrettyShow.Options.nCol
    local l_6_26 = l_6_17 + l_6_25 * (PrettyShow.Options.nSize + 1)
    local l_6_27 = l_6_18 + l_6_24 * (PrettyShow.Options.nSize + 1)
    if (PrettyShow.Options.BuffPos == 2 and l_6_0:GetName() == "Handle_Buff") or PrettyShow.Options.DebuffPos == 2 and l_6_0:GetName() == "Handle_Debuff" then
      l_6_27 = l_6_18 - l_6_24 * (PrettyShow.Options.nSize + 1)
    end
    l_6_23:SetAbsPos(l_6_26, l_6_27)
  end
  if l_6_0:GetName() == "Handle_Buff" and PrettyShow.Options.BuffPos == PrettyShow.Options.DebuffPos then
    local l_6_28 = math.ceil(l_6_16 / PrettyShow.Options.nCol)
    local l_6_29 = l_6_17
    local l_6_30 = l_6_18 + l_6_28 * (PrettyShow.Options.nSize + 6)
    if PrettyShow.Options.BuffPos == 2 then
      l_6_30 = l_6_18 - l_6_28 * (PrettyShow.Options.nSize + 6)
    end
    l_6_0:GetRoot():Lookup("", "Handle_Debuff"):SetAbsPos(l_6_29, l_6_30)
  end
else
  local l_6_31 = l_6_0:GetItemCount()
  local l_6_32, l_6_33 = l_6_0:GetAbsPos()
  for l_6_37 = 0, l_6_31 - 1 do
    local l_6_38 = l_6_0:Lookup(l_6_37)
    local l_6_39 = l_6_37
    local l_6_40 = l_6_32 + l_6_39 * (PrettyShow.Options.nSize + 1)
    local l_6_41 = l_6_33
    l_6_38:SetAbsPos(l_6_40, l_6_41)
  end
end
if l_6_0:GetName() == "Handle_Buff" and PrettyShow.Options.BuffPos == PrettyShow.Options.DebuffPos then
  local l_6_42 = l_6_32
  local l_6_43 = l_6_33
  if l_6_31 > 0 then
    if PrettyShow.Options.BuffPos == 1 then
      l_6_43 = l_6_33 + PrettyShow.Options.nSize + 6
    end
  else
    l_6_43 = l_6_33 - PrettyShow.Options.nSize + 6
  end
  l_6_0:GetRoot():Lookup("", "Handle_Debuff"):SetAbsPos(l_6_42, l_6_43)
end
 -- WARNING: missing end command somewhere! Added here
end
end
TargetShow.OnFrameDrag = function()
end
TargetShow.OnFrameDragSetPosEnd = function()
end
TargetShow.OnFrameDragEnd = function()
this:CorrectPos()
TargetShow.Anchor = GetFrameAnchor(this, "TOPLEFT")
end
TargetShow.UpdateAnchor = function(l_10_0)
l_10_0:SetPoint(TargetShow.Anchor.s, 0, 0, TargetShow.Anchor.r, TargetShow.Anchor.x, TargetShow.Anchor.y)
l_10_0:CorrectPos()
end
TargetShow.ShowDigit = function(l_11_0)
if PrettyShow.Options.ShowDamage_Target ~= true then
return 
end
local l_11_1 = l_11_0:Lookup("WndDigit"):Lookup("", "")
if not l_11_1 then
return 
end
local l_11_2 = l_11_1:GetItemCount() - 1
local l_11_3 = Pretty_CriticalScale
for l_11_7 = 0, l_11_2 do
local l_11_8 = l_11_1:Lookup(l_11_7)
if l_11_8 and l_11_8.bShow then
  local l_11_9 = l_11_8.nFrameCount
  local l_11_10 = P_COMBAT_TEXT_FADE_IN_FRAME
  local l_11_11 = P_COMBAT_TEXT_HOLD_FRAME
  local l_11_12 = P_COMBAT_TEXT_FADE_OUT_FRAME
  local l_11_13 = l_11_8.fScale
  if l_11_8.bCrit and l_11_3[l_11_9] then
    l_11_13 = l_11_3[l_11_9]
  end
  l_11_9 = l_11_9 + 2
  l_11_8.nFrameCount = l_11_9
  if l_11_13 ~= l_11_8.fScale then
    l_11_8.fScale = l_11_13
  end
  l_11_8:SetFontScale(l_11_13)
  l_11_8:AutoSize()
  local l_11_14, l_11_15 = l_11_8:GetSize()
  local l_11_16 = l_11_14 - l_11_8.x
  local l_11_17 = l_11_15 - l_11_8.y
  l_11_8.x = l_11_14
  l_11_8.y = l_11_15
  local l_11_18, l_11_19 = l_11_8:GetAbsPos()
  l_11_8:SetAbsPos(l_11_18 - l_11_16 / 2, l_11_19 - l_11_17 / 2)
  if l_11_9 < l_11_10 then
    l_11_8:SetAlpha(255 * (l_11_9) / l_11_10)
  end
elseif l_11_9 < l_11_10 + l_11_11 then
  l_11_8:SetAlpha(255)
else
  if l_11_9 < l_11_10 + l_11_11 + l_11_12 then
    l_11_8:SetAlpha(255 * (1 - (l_11_9 - l_11_10 - l_11_11) / l_11_12))
  end
else
  l_11_1:RemoveItem(l_11_7)
end
end
end
TargetShow.OnFrameBreathe = function()
-- upvalues: l_0_1 , l_0_27 , l_0_6 , l_0_9
local l_12_0 = l_0_1()
if not l_12_0 then
return 
end
TargetShow.UpdateAction(this)
local l_12_1 = GetCharacterDistance(l_12_0.dwID, this.dwID)
local l_12_2 = l_0_27("%d��", math.ceil(l_12_1 / 64))
TargetShow.ShowDigit(this)
if PrettyShow.Options.ShowTargetBuff ~= true then
this:Lookup("", "Handle_Buff"):Hide()
this:Lookup("", "Handle_Debuff"):Hide()
return 
else
this:Lookup("", "Handle_Buff"):Show()
this:Lookup("", "Handle_Debuff"):Show()
end
local l_12_3 = this:Lookup("", "Handle_Buff")
local l_12_4 = l_12_3:GetItemCount() - 1
local l_12_5 = l_0_6()
local l_12_6 = PrettyShow.Options.bCool
local l_12_7 = PrettyShow.Options.bCool_Dir
local l_12_8 = PrettyShow.Options.bText
for l_12_12 = 0, l_12_4 do
local l_12_13 = l_12_3:Lookup(l_12_12)
if not l_12_13:IsVisible() then
  return 
end
local l_12_14 = ""
if l_12_13.bShowTime then
  local l_12_15 = l_12_13.nEndFrame - l_12_5
  if l_12_6 and l_12_13.bCool then
    l_12_13:SetObjectCoolDown(1)
    if l_12_7 then
      l_12_13:SetCoolDownPercentage(1 - l_12_15 / l_12_13.nStartFrame)
    end
  else
    l_12_13:SetCoolDownPercentage(l_12_15 / l_12_13.nStartFrame)
  end
  if l_12_15 < 0 then
    l_12_15 = 0
  end
  local l_12_17, l_12_18 = l_0_9(l_12_15, true)
  if l_12_17 >= 1 then
    if l_12_18 >= 1 or true >= 1 then
      l_12_17 = l_12_17 + 1
      local l_12_16 = nil
    end
    l_12_14 = ""
  end
 -- DECOMPILER ERROR: Confused about usage of registers!

elseif l_12_18 >= 1 then
  if l_12_16 >= 1 then
    l_12_18 = l_12_18 + 1
  end
  l_12_14 = l_12_18 .. "'"
 -- DECOMPILER ERROR: Confused about usage of registers!

else
  l_12_14 = l_12_16 .. ""
end
if l_12_8 then
  l_12_13:SetOverText(1, l_12_14)
end
end
local l_12_19 = this:Lookup("", "Handle_Debuff")
local l_12_20 = l_12_19:GetItemCount() - 1
local l_12_21 = l_0_6()
for l_12_25 = 0, l_12_20 do
local l_12_26 = l_12_19:Lookup(l_12_25)
if not l_12_26:IsVisible() then
  return 
end
local l_12_27 = ""
if l_12_26.bShowTime then
  local l_12_28 = l_12_26.nEndFrame - l_12_21
  if l_12_6 and l_12_26.bCool then
    l_12_26:SetObjectCoolDown(1)
    if l_12_7 then
      l_12_26:SetCoolDownPercentage(1 - l_12_28 / l_12_26.nStartFrame)
    end
  else
    l_12_26:SetCoolDownPercentage(l_12_28 / l_12_26.nStartFrame)
  end
  if l_12_28 < 0 then
    l_12_28 = 0
  end
  local l_12_30, l_12_31 = l_0_9(l_12_28, true)
  if l_12_30 >= 1 then
    if l_12_31 >= 1 or true >= 1 then
      l_12_30 = l_12_30 + 1
      local l_12_29 = nil
    end
    l_12_27 = ""
    nFont = 162
  end
 -- DECOMPILER ERROR: Confused about usage of registers!

elseif l_12_31 >= 1 then
  if l_12_29 >= 1 then
    l_12_31 = l_12_31 + 1
  end
  l_12_27 = l_12_31 .. "'"
 -- DECOMPILER ERROR: Confused about usage of registers!

else
  l_12_27 = l_12_29 .. ""
end
if l_12_8 then
  l_12_26:SetOverText(1, l_12_27)
end
end
end
TargetShow.UpdateState = function(l_13_0)
TargetShow.UpdateLM(l_13_0)
TargetShow.UpdateName(l_13_0)
TargetShow.UpdateLevel(l_13_0)
TargetShow.UpdateBuff(l_13_0)
TargetShow.UpdateAction(l_13_0)
TargetShow.UpdateHead(l_13_0)
TargetShow.UpdateTargetMark(l_13_0)
TargetShow.UpdateCamp(l_13_0)
end
TargetShow.UpdateTargetMark = function(l_14_0)
-- upvalues: l_0_1 , l_0_10
local l_14_1 = l_0_1()
local l_14_2 = (l_14_0:Lookup("", "Image_NPCMark"))
local l_14_3 = nil
if l_14_1.IsInParty() then
local l_14_4 = l_0_10().GetTeamMark()
assert(l_14_4)
end
if l_14_4 and l_14_4[l_14_0.dwID] then
local l_14_5 = l_14_4[l_14_0.dwID]
local l_14_6 = assert
l_14_6(l_14_5 > 0 and l_14_5 <= #PARTY_MARK_ICON_FRAME_LIST)
l_14_6 = PARTY_MARK_ICON_FRAME_LIST
l_14_3 = l_14_6[l_14_5]
end
if l_14_3 then
l_14_2:FromUITex(PARTY_MARK_ICON_PATH, l_14_3)
l_14_2:Show()
else
l_14_2:Hide()
end
end
local l_0_33 = function(l_15_0, l_15_1)
-- upvalues: l_0_27
local l_15_2 = l_0_27("%d", l_15_1)
local l_15_3 = l_0_27("%d", l_15_0)
local l_15_4 = l_0_27("%.1f%%", l_15_0 * 100 / l_15_1)
if PrettyShow.Options.nActHealth == 2 then
if l_15_1 > 100000 then
  l_15_2 = l_0_27("%.1f��", l_15_1 / 10000)
end
if l_15_0 > 100000 then
  l_15_3 = l_0_27("%.1f��", l_15_0 / 10000)
end
else
if PrettyShow.Options.nActHealth == 3 then
  if l_15_1 > 100000 then
    l_15_2 = l_0_27("%.1fW", l_15_1 / 10000)
  end
end
end
if l_15_0 > 100000 then
l_15_3 = l_0_27("%.1fW", l_15_0 / 10000)
end
if PrettyShow.Options.nHealthMode == 1 then
return l_15_3
end
if PrettyShow.Options.nHealthMode == 2 then
return l_15_3 .. "(" .. l_15_4 .. ")"
end
if PrettyShow.Options.nHealthMode == 3 then
return l_15_3, l_15_4
end
if PrettyShow.Options.nHealthMode == 4 then
return l_15_3 .. "/" .. l_15_2
end
if PrettyShow.Options.nHealthMode == 5 then
local l_15_8 = l_15_3
local l_15_9 = "/"
local l_15_10 = l_15_2
l_15_8 = l_15_8 .. l_15_9 .. l_15_10 .. "(" .. l_15_4 .. ")"
return l_15_8
end
if PrettyShow.Options.nHealthMode == 6 then
return l_15_3 .. "/" .. l_15_2, l_15_4
end
if PrettyShow.Options.nHealthMode == 7 then
if l_15_0 - l_15_1 < 0 then
  local l_15_5 = l_0_27
  local l_15_6 = "%d"
  local l_15_7 = l_15_0 - l_15_1
  return l_15_5(l_15_6, l_15_7)
end
else
return ""
end
end
local l_0_34 = function(l_16_0)
if l_16_0 <= 0 or l_16_0 >= 1 then
return 0.09, 0.7, 0.03
end
if l_16_0 >= 0.5 then
return (1 - l_16_0) * 2, 0.7, 0
else
return 1, l_16_0 * 2, 0
end
end
local l_0_37 = nil
local l_0_39 = function(l_33_0)
-- upvalues: l_0_11
local l_33_1 = 1
if l_33_1 == 1 and l_33_1 == 1 then
l_33_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_33_3 = nil
local l_33_4 = function()
  -- upvalues: l_33_1
  return l_33_1 == 2 or l_33_1 == 3
end
(l_33_0)
if not Station.Lookup("Normal/TargetShow") then
return 
end
local l_33_5 = nil
if not l_33_4 then
Station.Lookup("Normal/TargetShow"):Lookup("", "Image_Target"):SetAlpha(255)
TargetShow.modelView:UnloadModel()
return 
end
Station.Lookup("Normal/TargetShow"):Lookup("", "Image_Target"):SetAlpha(0)
local l_33_6 = nil
l_33_5:Lookup("Show_Role"):Show()
local l_33_7 = nil
TargetShow.modelView:SetCamera(SelfPortraitCameraInfo[l_33_4.nRoleType])
l_33_7:SetScene(TargetShow.modelView.m_scene)
TargetShow.modelView:UnloadModel()
local l_33_8 = nil
do
local l_33_9 = TargetShow.modelView
l_33_9.m_aRoleAnimation = {Idle = 41}
l_33_9 = TargetShow
l_33_9 = l_33_9.modelView
l_33_9(l_33_9, l_33_0, false)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_33_9(l_33_9)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_33_9(l_33_9, "Idle", "loop")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
local l_0_40 = function(l_34_0)
-- upvalues: l_0_12
local l_34_1 = l_0_12(l_34_0)
local l_34_2 = Station.Lookup("Normal/TargetShow")
if not l_34_2 then
return 
end
local l_34_3 = l_34_2:Lookup("", "Image_Target")
local l_34_4 = l_34_2:Lookup("Show_Role")
l_34_3:SetAlpha(255)
l_34_4:Hide()
end
RegisterEvent("BGFRAME_RESET", function()
local l_38_0 = Station.Lookup("Normal/TargetShow")
if l_38_0 then
local l_38_1 = l_38_0:Lookup("", "")
local l_38_2 = l_38_1:Lookup("Image_Frame")
if PrettyShow.Options.bShowFrame then
  l_38_2:Show()
end
else
l_38_2:Hide()
end
end)
local l_0_43 = function()
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_35_0 = Station.Lookup("Normal/TargetShow")
if l_35_0 then
local l_35_1 = l_35_0:Lookup("", "Image_Progress")
local l_35_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nCaster]
if l_35_1 and l_35_2 then
  l_35_1:FromUITex(l_35_2[1], l_35_2[2])
end
local l_35_3 = PrettyShow.Options.tCasterText[1]
local l_35_4 = PrettyShow.Options.tCasterText[2]
end
if l_35_3 and l_35_4 then
local l_35_5 = l_35_0:Lookup("", "Text_SkillName")
local l_35_6 = l_35_0:Lookup("", "Text_SkillTime")
l_35_5:SetFontScheme(l_35_3)
l_35_6:SetFontScheme(l_35_3)
l_35_5:SetFontColor(l_35_4[1], l_35_4[2], l_35_4[3])
l_35_6:SetFontColor(l_35_4[1], l_35_4[2], l_35_4[3])
end
end
local l_0_45 = function()
-- upvalues: l_0_13
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_36_0 = Station.Lookup("Normal/TargetShow")
if l_36_0 then
local l_36_1 = l_36_0:Lookup("", "")
if PrettyShow.Options.nMode == 1 then
  l_36_1:Lookup("Shadow_Health"):Hide()
  l_36_1:Lookup("Shadow_Mana"):Hide()
  l_36_1:Lookup("Image_Health"):Show()
  l_36_1:Lookup("Image_Mana"):Show()
  local l_36_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nHealthBar]
  if l_36_2 then
    l_36_1:Lookup("Image_Health"):FromUITex(l_36_2[1], l_36_2[2])
  end
  local l_36_3 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nManaBar]
  if l_36_3 then
    l_36_1:Lookup("Image_Mana"):FromUITex(l_36_3[1], l_36_3[2])
  end
else
  if PrettyShow.Options.nMode == 2 then
    l_36_1:Lookup("Image_Health"):Hide()
    l_36_1:Lookup("Image_Mana"):Hide()
    local l_36_4 = PrettyShow.Options.tHealthColor[1]
    l_36_1:Lookup("Shadow_Health"):SetColorRGB(l_36_4[1], l_36_4[2], l_36_4[3])
    local l_36_5 = PrettyShow.Options.tHealthColor[2]
    l_36_1:Lookup("Shadow_Mana"):SetColorRGB(l_36_5[1], l_36_5[2], l_36_5[3])
    l_36_1:Lookup("Shadow_Health"):Show()
    l_36_1:Lookup("Shadow_Mana"):Show()
  end
else
  if PrettyShow.Options.nMode == 3 then
    l_36_1:Lookup("Shadow_Health"):Show()
    l_36_1:Lookup("Shadow_Mana"):Show()
    l_36_1:Lookup("Image_Health"):Hide()
    l_36_1:Lookup("Image_Mana"):Hide()
    local l_36_6 = l_0_13(l_36_0.dwType, l_36_0.dwID)
    if l_36_6 then
      local l_36_7 = l_36_6.dwForceID
      if l_36_0.dwType == TARGET.NPC then
        l_36_7 = 999
      end
    end
    if l_36_7 then
      if not PrettyShow.Options.tForceColor[l_36_7] then
        local l_36_8, l_36_9, l_36_10, l_36_11 = {}
        l_36_9 = 0
        l_36_10 = 255
        l_36_11 = 0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_36_1:Lookup("Shadow_Health"):SetColorRGB(l_36_8[1], l_36_8[2], l_36_8[3])
    end
    local l_36_12 = PrettyShow.Options.tHealthColor[2]
    l_36_1:Lookup("Shadow_Mana"):SetColorRGB(l_36_12[1], l_36_12[2], l_36_12[3])
  end
else
  l_36_1:Lookup("Shadow_Health"):Show()
  l_36_1:Lookup("Shadow_Mana"):Show()
  l_36_1:Lookup("Image_Health"):Hide()
  l_36_1:Lookup("Image_Mana"):Hide()
  local l_36_13 = PrettyShow.Options.tHealthColor[2]
  l_36_1:Lookup("Shadow_Mana"):SetColorRGB(l_36_13[1], l_36_13[2], l_36_13[3])
end
local l_36_14 = l_36_0:Lookup("", "")
local l_36_15 = l_36_14:Lookup("Text_Health")
local l_36_16 = l_36_14:Lookup("Text_Mana")
local l_36_17 = l_36_14:Lookup("Text_HealthPer")
local l_36_18 = l_36_14:Lookup("Text_ManaPer")
if PrettyShow.Options.nHealthMode == 1 then
  l_36_15:SetHAlign(1)
  l_36_16:SetHAlign(1)
else
  if PrettyShow.Options.nHealthMode == 2 then
    l_36_15:SetHAlign(1)
    l_36_16:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 3 then
    l_36_15:SetHAlign(0)
    l_36_16:SetHAlign(0)
  end
else
  if PrettyShow.Options.nHealthMode == 4 then
    l_36_15:SetHAlign(1)
    l_36_16:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 5 then
    l_36_15:SetHAlign(1)
    l_36_16:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 6 then
    l_36_15:SetHAlign(0)
    l_36_16:SetHAlign(0)
  end
else
  if PrettyShow.Options.nHealthMode == 7 then
    l_36_15:SetHAlign(2)
    l_36_16:SetHAlign(2)
  end
end
local l_36_19 = PrettyShow.Options.tHealth[1]
local l_36_20 = PrettyShow.Options.tHealth[2]
l_36_15:SetFontScheme(l_36_19)
l_36_15:SetFontColor(l_36_20[1], l_36_20[2], l_36_20[2])
l_36_17:SetFontScheme(l_36_19)
l_36_17:SetFontColor(l_36_20[1], l_36_20[2], l_36_20[2])
l_36_16:SetFontScheme(l_36_19)
l_36_16:SetFontColor(l_36_20[1], l_36_20[2], l_36_20[2])
l_36_18:SetFontScheme(l_36_19)
l_36_18:SetFontColor(l_36_20[1], l_36_20[2], l_36_20[2])
TargetShow.UpdateLM(l_36_0)
end
end
local l_0_46 = function()
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_37_0 = Station.Lookup("Normal/TargetShow")
if l_37_0 then
local l_37_1 = l_37_0:Lookup("", "")
local l_37_2 = l_37_1:Lookup("Image_BgMidC")
end
if l_37_2 then
l_37_2:SetAlpha(PrettyShow.Options.Bg)
end
end
RegisterEvent("FORCE_RESET", function()
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_46_0 = Station.Lookup("Normal/TargetShow")
if l_46_0 then
TargetShow.UpdateHead(l_46_0)
end
end)
RegisterEvent("CASTER_STYLE_RESET", l_0_43)
RegisterEvent("CUSTOM_DATA_LOADED", function()
-- upvalues: l_0_42 , l_0_43 , l_0_1
Wnd.CloseWindow("Target")
Wnd.CloseWindow("TargetShow")
if PrettyShow.Options.TargetEnable == true then
l_0_42()
else
l_0_43()
end
local l_44_0 = l_0_1()
if not l_44_0 then
return 
end
local l_44_1, l_44_2 = l_44_0.GetTarget()
if l_44_1 == TARGET.PLAYER or l_44_1 == TARGET.NPC then
OpenTargetPanel(l_44_1, l_44_2)
end
end)
 -- DECOMPILER ERROR: Confused about usage of registers!

RegisterEvent("TARGET_ENABLE", function()
-- upvalues: l_0_42 , l_0_43 , l_0_1
Wnd.CloseWindow("Target")
Wnd.CloseWindow("TargetShow")
if PrettyShow.Options.TargetEnable == true then
l_0_42()
else
l_0_43()
end
local l_44_0 = l_0_1()
if not l_44_0 then
return 
end
local l_44_1, l_44_2 = l_44_0.GetTarget()
if l_44_1 == TARGET.PLAYER or l_44_1 == TARGET.NPC then
OpenTargetPanel(l_44_1, l_44_2)
end
end)
RegisterEvent("BUFF_RESET", function()
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_45_0 = Station.Lookup("Normal/TargetShow")
if l_45_0 then
TargetShow.UpdateBuff(l_45_0)
end
end)
RegisterEvent("HEAD_ALPHA_RESET", l_0_46)
RegisterEvent("HEALTH_MODE_RESET", l_0_45)
do
RegisterEvent("FRAME_SIZE_RESET", function()
-- upvalues: l_0_41
if arg0 ~= "Target" then
return 
end
local l_47_0 = Station.Lookup("Normal/TargetShow")
Wnd.CloseWindow("TargetShow")
if l_47_0 then
local l_47_1 = l_47_0.dwType
local l_47_2 = l_47_0.dwID
l_0_41(l_47_1, l_47_2)
end
end)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

