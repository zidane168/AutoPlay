-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: CD.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = 0
l_0_1.y = 0
l_0_0.Anchor = l_0_1
l_0_0.tSkill, l_0_1 = l_0_1, {}
l_0_0.nBoxSize = 200
l_0_0.bCenterShow = false
l_0_0.nCenterDelay = 700
l_0_0.nMaxCenterAlpha = 192
l_0_0.nCenterAlpha = 0
l_0_0.nCenterEndTime = 0
CD = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "CD.nBoxSize"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CD.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CD.bCenterShow"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CD.nCenterDelay"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CD.nMaxCenterAlpha"
l_0_0(l_0_1)
SkillSparking, l_0_0 = l_0_0, {bOn = false, nMaxAlpha = 255, nShowType = 2, nBoxSize = 256, nDelay = 1000}
l_0_0 = RegisterCustomData
l_0_1 = "SkillSparking.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "SkillSparking.nMaxAlpha"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "SkillSparking.nDelay"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "SkillSparking.nShowType"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "SkillSparking.nBoxSize"
l_0_0(l_0_1)
l_0_0 = CD
l_0_1 = function()
  CD.box = this:Lookup("", "Box_Skill")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("CUSTOM_UI_MODE_SET_DEFAULT")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = CD
l_0_1 = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    CD.UpdateAnchor(this)
  elseif l_2_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_2_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "������ȴ��ʾ", true)
    CD.UpdateAnchor(this)
  elseif l_2_0 == "CUSTOM_UI_MODE_SET_DEFAULT" then
    local l_2_1 = CD
    local l_2_2 = {}
    l_2_2.s = "CENTER"
    l_2_2.r = "CENTER"
    l_2_2.x = 0
    l_2_2.y = 0
    l_2_1.Anchor = l_2_2
    l_2_1 = CD
    l_2_1 = l_2_1.UpdateAnchor
    l_2_2 = this
    l_2_1(l_2_2)
  elseif l_2_0 == "CUSTOM_DATA_LOADED" then
    if arg0 ~= "Role" then
      return 
    end
    CD.UpdateCenterBoxSize()
    CD.UpdateAnchor(this)
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = CD
l_0_1 = function()
  local l_3_0 = Station.Lookup("Normal/CD")
  l_3_0:SetSize(CD.nBoxSize, CD.nBoxSize)
  local l_3_1 = l_3_0:Lookup("", "")
  l_3_1:Lookup("Box_Skill"):SetSize(CD.nBoxSize, CD.nBoxSize)
  l_3_1:FormatAllItemPos()
end

l_0_0.UpdateCenterBoxSize = l_0_1
l_0_0 = CD
l_0_1 = function(l_4_0)
  local l_4_1 = CD.Anchor
  l_4_0:SetPoint(l_4_1.s, 0, 0, l_4_1.r, l_4_1.x, l_4_1.y)
end

l_0_0.UpdateAnchor = l_0_1
l_0_0 = CD
l_0_1 = function()
  this:CorrectPos()
  CD.Anchor = GetFrameAnchor(this)
end

l_0_0.OnFrameDragEnd = l_0_1
l_0_0 = CD
l_0_1 = function()
  if not CD.bCenterShow and not SkillSparking.bOn then
    return 
  end
  if CD.bCenterShow then
    CD.nCenterAlpha = (CD.nCenterEndTime - GetTime()) * CD.nMaxCenterAlpha / CD.nCenterDelay
    if CD.nCenterAlpha < 0 then
      CD.nCenterAlpha = 0
    end
    CD.box:SetAlpha(CD.nCenterAlpha)
  end
  local l_6_0 = Station.Lookup("Topmost/SkillSparking")
  local l_6_1 = l_6_0:Lookup("", "")
  if SkillSparking.bOn then
    local l_6_2 = 0
  end
  if l_6_2 < l_6_1:GetItemCount() then
    local l_6_3 = l_6_1:Lookup(l_6_2)
    if l_6_3 then
      if l_6_3.nEndTime < GetTime() then
        l_6_1:RemoveItem(l_6_3:GetIndex())
      end
    else
      local l_6_4 = (l_6_3.nEndTime - GetTime()) / SkillSparking.nDelay
      local l_6_5 = l_6_3.tBox
      local l_6_6, l_6_7 = l_6_5:GetAbsPos()
      local l_6_8, l_6_9 = l_6_5:GetSize()
      l_6_3:SetAlpha(SkillSparking.nMaxAlpha * l_6_4)
      l_6_3:SetSize(SkillSparking.nBoxSize * l_6_4, SkillSparking.nBoxSize * l_6_4)
      l_6_3:SetRelPos(l_6_6 + l_6_8 / 2 - SkillSparking.nBoxSize * l_6_4 / 2, l_6_7 + l_6_9 / 2 - SkillSparking.nBoxSize * l_6_4 / 2)
    end
    l_6_2 = l_6_2 + 1
    l_6_1:Show()
    l_6_1:FormatAllItemPos()
  end
end
end

l_0_0.OnFrameRender = l_0_1
l_0_0 = CD
l_0_1 = function()
  local l_7_0 = GetClientPlayer()
  if not l_7_0 then
    return 
  end
  for l_7_4 = 1, 4 do
    if IsActionBarOpened(l_7_4) then
      local l_7_5 = GetActionBarFrame(l_7_4)
      local l_7_6 = l_7_5:Lookup("", "Handle_Box")
      local l_7_7 = l_7_6:GetItemCount() - 1
      for l_7_11 = 0, l_7_7 do
        local l_7_12 = l_7_6:Lookup(l_7_11)
        if not l_7_12:IsEmpty() then
          local l_7_13 = l_7_12:GetObjectType()
        end
        if l_7_13 == UI_OBJECT_SKILL then
          local l_7_14, l_7_15 = l_7_12:GetObjectData()
          local l_7_16, l_7_17, l_7_18 = l_7_0.GetSkillCDProgress(l_7_14, l_7_15)
          local l_7_19 = GetSkillInfo(l_7_0.GetSkillRecipeKey(l_7_14, l_7_15))
          local l_7_20 = 0
          for l_7_24 = 1, 3 do
            local l_7_25 = "CoolDown" .. l_7_24
            if l_7_20 < l_7_19[l_7_25] then
              l_7_20 = l_7_19[l_7_25]
            end
          end
        end
        if l_7_18 > 24 and l_7_18 == l_7_20 then
          CD.tSkill[l_7_14] = true
        end
      end
    end
  end
  for l_7_29,l_7_30 in pairs(CD.tSkill) do
    local l_7_31 = l_7_0.GetSkillLevel(l_7_29)
    local l_7_32, l_7_33, l_7_34 = l_7_0.GetSkillCDProgress(l_7_29, l_7_31)
    if l_7_33 <= 0 then
      if l_7_30 then
        if CD.bCenterShow then
          CD.nCenterAlpha = CD.nMaxCenterAlpha
          CD.nCenterEndTime = GetTime() + CD.nCenterDelay
          CD.box:SetObject(UI_OBJECT_SKILL, l_7_29, l_7_31)
          CD.box:SetObjectIcon(Table_GetSkillIconID(l_7_29, l_7_31))
        end
      end
      if SkillSparking.bOn then
        SkillSparking.Create(l_7_29, l_7_31)
      end
      CD.tSkill[l_7_29] = false
    end
  end
end

l_0_0.OnFrameBreathe = l_0_1
l_0_0 = SkillSparking
l_0_1 = function(l_8_0, l_8_1)
  local l_8_2 = GetSkillActionBarBox(l_8_0)
  if not l_8_2 then
    return 
  end
  local l_8_3 = Station.Lookup("Topmost/SkillSparking")
  local l_8_4 = (l_8_3:Lookup("", ""))
  local l_8_5 = nil
  if SkillSparking.nShowType == 1 then
    l_8_4:AppendItemFromString("<box>w=" .. SkillSparking.nBoxSize .. " h=" .. SkillSparking.nBoxSize .. " lockshowhide=1 </box>")
    l_8_5 = l_8_4:Lookup(l_8_4:GetItemCount() - 1)
    l_8_5:SetObject(UI_OBJECT_SKILL, l_8_0, l_8_1)
    l_8_5:SetObjectIcon(Table_GetSkillIconID(l_8_0, l_8_1))
  else
    l_8_4:AppendItemFromString("<image> w=" .. SkillSparking.nBoxSize .. " h=" .. SkillSparking.nBoxSize .. " path=\"Interface\\Moon_CD\\img\\tip.UiTex\" frame=" .. SkillSparking.nShowType - 2 .. "</image>")
    l_8_5 = l_8_4:Lookup(l_8_4:GetItemCount() - 1)
  end
  l_8_5:SetName(l_8_0)
  l_8_5:Show()
  l_8_5.tBox = l_8_2
  l_8_5.nEndTime = GetTime() + SkillSparking.nDelay
  l_8_5:SetAlpha(SkillSparking.nMaxAlpha)
  local l_8_6, l_8_7 = l_8_2:GetAbsPos()
  local l_8_8, l_8_9 = l_8_2:GetSize()
  l_8_5:SetRelPos(l_8_6 + l_8_8 / 2 - SkillSparking.nBoxSize / 2, l_8_7 + l_8_9 / 2 - SkillSparking.nBoxSize / 2)
  l_8_4:FormatAllItemPos()
end

l_0_0.Create = l_0_1
l_0_0 = SkillSparking
l_0_1 = function()
  local l_9_0 = Station.Lookup("Topmost/SkillSparking")
  local l_9_1 = l_9_0:Lookup("", "")
  if l_9_1 then
    l_9_1:Show()
  end
end

l_0_0.Show = l_0_1
l_0_0 = SkillSparking
l_0_1 = function()
  local l_10_0 = Station.Lookup("Topmost/SkillSparking")
  local l_10_1 = l_10_0:Lookup("", "")
  if l_10_1 then
    l_10_1:Hide()
  end
end

l_0_0.Hide = l_0_1
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "interface\\Moon_CD\\CD.ini"
l_0_0(l_0_1, "CD")
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "interface\\Moon_CD\\SkillSparking.ini"
l_0_0(l_0_1, "SkillSparking")
l_0_0 = function(l_11_0)
  local l_11_1 = l_11_0:Lookup("", "")
  BoxBoolCheckBox(l_11_0, "CheckBox_CenterIcon", "��Ļ������ȴͼ��", CD, "bCenterShow")
  local l_11_2 = BoxComboBox
  local l_11_3 = l_11_0
  local l_11_4 = "ComboBox_CenterShowStyle"
  local l_11_5 = {}
  l_11_5.txt = "����ͼ������"
  l_11_5.x = 0
  l_11_5.y = 30
  l_11_2 = l_11_2(l_11_3, l_11_4, l_11_5)
  l_11_2, l_11_3 = l_11_2:OnClick, l_11_2
  l_11_4 = function()
    local l_12_0 = this:GetParent()
    local l_12_1, l_12_2 = l_12_0:GetAbsPos()
    local l_12_3, l_12_4 = l_12_0:GetSize()
    local l_12_5 = {}
    l_12_5.nMiniWidth = l_12_3
    l_12_5.x = l_12_1
    l_12_5.y = l_12_2 + l_12_4
    local l_12_6 = {}
    l_12_6.szOption = "��ʼ͸����"
    local l_12_7 = {}
    l_12_7.szOption = "Lv 1"
    l_12_7.bMCheck = true
    l_12_7.bChecked = CD.nMaxCenterAlpha == 128
    l_12_7.fnAction = function()
      CD.nMaxCenterAlpha = 128
    end
    local l_12_10 = {}
    l_12_10.szOption = "Lv 2"
    l_12_10.bMCheck = true
    l_12_10.bChecked = CD.nMaxCenterAlpha == 160
    l_12_10.fnAction = function()
      CD.nMaxCenterAlpha = 160
    end
    local l_12_13 = {}
    l_12_13.szOption = "Lv 3"
    l_12_13.bMCheck = true
    l_12_13.bChecked = CD.nMaxCenterAlpha == 192
    l_12_13.fnAction = function()
      CD.nMaxCenterAlpha = 192
    end
    local l_12_16 = {}
    l_12_16.szOption = "Lv 4"
    l_12_16.bMCheck = true
    l_12_16.bChecked = CD.nMaxCenterAlpha == 224
    l_12_16.fnAction = function()
      CD.nMaxCenterAlpha = 224
    end
    local l_12_19 = {}
    l_12_19.szOption = "Lv 5"
    l_12_19.bMCheck = true
    l_12_19.bChecked = CD.nMaxCenterAlpha == 256
    l_12_19.fnAction = function()
      CD.nMaxCenterAlpha = 256
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_12_13 = CD
    l_12_13 = l_12_13.nBoxSize
    l_12_13 = l_12_13 == 160
    l_12_13 = function()
      CD.nBoxSize = 160
      CD.UpdateCenterBoxSize()
    end
    l_12_16 = CD
    l_12_16 = l_12_16.nBoxSize
    l_12_16 = l_12_16 == 180
    l_12_16 = function()
      CD.nBoxSize = 180
      CD.UpdateCenterBoxSize()
    end
    l_12_19 = CD
    l_12_19 = l_12_19.nBoxSize
    l_12_19 = l_12_19 == 200
    l_12_19 = function()
      CD.nBoxSize = 200
      CD.UpdateCenterBoxSize()
    end
    local l_12_24 = {}
    l_12_24.szOption = "Lv 5"
    l_12_24.bMCheck = true
    l_12_24.bChecked = CD.nBoxSize == 240
    l_12_24.fnAction = function()
      CD.nBoxSize = 240
      CD.UpdateCenterBoxSize()
    end
    l_12_19, l_12_16, l_12_13, l_12_10 = {szOption = "Lv 4", bMCheck = true, bChecked = CD.nBoxSize == 220, fnAction = function()
      CD.nBoxSize = 220
      CD.UpdateCenterBoxSize()
    end}, {szOption = "Lv 3", bMCheck = true, bChecked = l_12_19, fnAction = l_12_19}, {szOption = "Lv 2", bMCheck = true, bChecked = l_12_16, fnAction = l_12_16}, {szOption = "Lv 1", bMCheck = true, bChecked = l_12_13, fnAction = l_12_13}
    l_12_16 = CD
    l_12_16 = l_12_16.nCenterDelay
    l_12_16 = l_12_16 == 300
    l_12_16 = function()
      CD.nCenterDelay = 300
    end
    l_12_19 = CD
    l_12_19 = l_12_19.nCenterDelay
    l_12_19 = l_12_19 == 500
    l_12_19 = function()
      CD.nCenterDelay = 500
    end
    l_12_24 = CD
    l_12_24 = l_12_24.nCenterDelay
    l_12_24 = l_12_24 == 700
    l_12_24 = function()
      CD.nCenterDelay = 700
    end
    local l_12_29 = {}
    l_12_29.szOption = "����"
    l_12_29.bMCheck = true
    l_12_29.bChecked = CD.nCenterDelay == 1000
    l_12_29.fnAction = function()
      CD.nCenterDelay = 1000
    end
    l_12_24, l_12_19, l_12_16, l_12_13 = {szOption = "��", bMCheck = true, bChecked = CD.nCenterDelay == 800, fnAction = function()
      CD.nCenterDelay = 800
    end}, {szOption = "һ��", bMCheck = true, bChecked = l_12_24, fnAction = l_12_24}, {szOption = "��", bMCheck = true, bChecked = l_12_19, fnAction = l_12_19}, {szOption = "�ܿ�", bMCheck = true, bChecked = l_12_16, fnAction = l_12_16}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_12_6 = PopupMenu
     -- DECOMPILER ERROR: Overwrote pending register.

    l_12_6(l_12_7)
    l_12_7 = {l_12_10, l_12_13, l_12_16, l_12_19, l_12_24; szOption = "��ʼ��С"}
  end
  l_11_2(l_11_3, l_11_4)
  l_11_2 = BoxCheckBox
  l_11_3 = l_11_0
  l_11_4 = "CheckBox_SkillSparking"
  l_11_2, l_11_5 = l_11_2(l_11_3, l_11_4, l_11_5), {txt = "��������ȴЧ��", x = 0, y = 60}
  l_11_3, l_11_4 = l_11_2:SetBoolValue, l_11_2
  l_11_5 = SkillSparking
  l_11_3(l_11_4, l_11_5, "bOn")
  l_11_3, l_11_4 = l_11_2:OnCheck, l_11_2
  l_11_5 = SkillSparking
  l_11_5 = l_11_5.Show
  l_11_3(l_11_4, l_11_5)
  l_11_3, l_11_4 = l_11_2:UnCheck, l_11_2
  l_11_5 = SkillSparking
  l_11_5 = l_11_5.Hide
  l_11_3(l_11_4, l_11_5)
  l_11_3 = BoxComboBox
  l_11_4 = l_11_0
  l_11_5 = "ComboBox_SkillSparking"
  local l_11_6 = {}
  l_11_6.txt = "��ȴЧ������"
  l_11_6.x = 0
  l_11_6.y = 90
  l_11_3 = l_11_3(l_11_4, l_11_5, l_11_6)
  l_11_3, l_11_4 = l_11_3:OnClick, l_11_3
  l_11_5 = function()
    local l_13_0 = this:GetParent()
    local l_13_1, l_13_2 = l_13_0:GetAbsPos()
    local l_13_3, l_13_4 = l_13_0:GetSize()
    local l_13_5 = {}
    l_13_5.nMiniWidth = l_13_3
    l_13_5.x = l_13_1
    l_13_5.y = l_13_2 + l_13_4
    local l_13_6 = {}
    l_13_6.szOption = "��ʼ͸����"
    local l_13_7 = {}
    l_13_7.szOption = "Lv 1"
    l_13_7.bMCheck = true
    l_13_7.bChecked = SkillSparking.nMaxAlpha == 128
    l_13_7.fnAction = function()
      SkillSparking.nMaxAlpha = 128
    end
    local l_13_10 = {}
    l_13_10.szOption = "Lv 2"
    l_13_10.bMCheck = true
    l_13_10.bChecked = SkillSparking.nMaxAlpha == 160
    l_13_10.fnAction = function()
      SkillSparking.nMaxAlpha = 160
    end
    local l_13_13 = {}
    l_13_13.szOption = "Lv 3"
    l_13_13.bMCheck = true
    l_13_13.bChecked = SkillSparking.nMaxAlpha == 192
    l_13_13.fnAction = function()
      SkillSparking.nMaxAlpha = 192
    end
    local l_13_16 = {}
    l_13_16.szOption = "Lv 4"
    l_13_16.bMCheck = true
    l_13_16.bChecked = SkillSparking.nMaxAlpha == 224
    l_13_16.fnAction = function()
      SkillSparking.nMaxAlpha = 224
    end
    local l_13_19 = {}
    l_13_19.szOption = "Lv 5"
    l_13_19.bMCheck = true
    l_13_19.bChecked = SkillSparking.nMaxAlpha == 255
    l_13_19.fnAction = function()
      SkillSparking.nMaxAlpha = 255
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_13_13 = SkillSparking
    l_13_13 = l_13_13.nBoxSize
    l_13_13 = l_13_13 == 128
    l_13_13 = function()
      SkillSparking.nBoxSize = 128
    end
    l_13_16 = SkillSparking
    l_13_16 = l_13_16.nBoxSize
    l_13_16 = l_13_16 == 192
    l_13_16 = function()
      SkillSparking.nBoxSize = 192
    end
    l_13_19 = SkillSparking
    l_13_19 = l_13_19.nBoxSize
    l_13_19 = l_13_19 == 256
    l_13_19 = function()
      SkillSparking.nBoxSize = 256
    end
    local l_13_24 = {}
    l_13_24.szOption = "Lv 5"
    l_13_24.bMCheck = true
    l_13_24.bChecked = SkillSparking.nBoxSize == 384
    l_13_24.fnAction = function()
      SkillSparking.nBoxSize = 384
    end
    l_13_19, l_13_16, l_13_13, l_13_10 = {szOption = "Lv 4", bMCheck = true, bChecked = SkillSparking.nBoxSize == 320, fnAction = function()
      SkillSparking.nBoxSize = 320
    end}, {szOption = "Lv 3", bMCheck = true, bChecked = l_13_19, fnAction = l_13_19}, {szOption = "Lv 2", bMCheck = true, bChecked = l_13_16, fnAction = l_13_16}, {szOption = "Lv 1", bMCheck = true, bChecked = l_13_13, fnAction = l_13_13}
    l_13_16 = SkillSparking
    l_13_16 = l_13_16.nDelay
    l_13_16 = l_13_16 == 300
    l_13_16 = function()
      SkillSparking.nDelay = 300
    end
    l_13_19 = SkillSparking
    l_13_19 = l_13_19.nDelay
    l_13_19 = l_13_19 == 500
    l_13_19 = function()
      SkillSparking.nDelay = 500
    end
    l_13_24 = SkillSparking
    l_13_24 = l_13_24.nDelay
    l_13_24 = l_13_24 == 800
    l_13_24 = function()
      SkillSparking.nDelay = 800
    end
    local l_13_29 = {}
    l_13_29.szOption = "����"
    l_13_29.bMCheck = true
    l_13_29.bChecked = SkillSparking.nDelay == 2000
    l_13_29.fnAction = function()
      SkillSparking.nDelay = 2000
    end
    l_13_24, l_13_19, l_13_16, l_13_13 = {szOption = "��", bMCheck = true, bChecked = SkillSparking.nDelay == 1000, fnAction = function()
      SkillSparking.nDelay = 1000
    end}, {szOption = "һ��", bMCheck = true, bChecked = l_13_24, fnAction = l_13_24}, {szOption = "��", bMCheck = true, bChecked = l_13_19, fnAction = l_13_19}, {szOption = "�ܿ�", bMCheck = true, bChecked = l_13_16, fnAction = l_13_16}
    l_13_19 = SkillSparking
    l_13_19 = l_13_19.nShowType
    l_13_19 = l_13_19 == 1
    l_13_19 = function()
      SkillSparking.nShowType = 1
    end
    l_13_24 = SkillSparking
    l_13_24 = l_13_24.nShowType
    l_13_24 = l_13_24 == 2
    l_13_24 = function()
      SkillSparking.nShowType = 2
    end
    l_13_29 = SkillSparking
    l_13_29 = l_13_29.nShowType
    l_13_29 = l_13_29 == 3
    l_13_29 = function()
      SkillSparking.nShowType = 3
    end
    local l_13_34 = {}
    l_13_34.szOption = "��ը"
    l_13_34.bMCheck = true
    l_13_34.bChecked = SkillSparking.nShowType == 5
    l_13_34.fnAction = function()
      SkillSparking.nShowType = 5
    end
    l_13_29, l_13_24, l_13_19, l_13_16 = {szOption = "����", bMCheck = true, bChecked = SkillSparking.nShowType == 4, fnAction = function()
      SkillSparking.nShowType = 4
    end}, {szOption = "ԲȦ", bMCheck = true, bChecked = l_13_29, fnAction = l_13_29}, {szOption = "����", bMCheck = true, bChecked = l_13_24, fnAction = l_13_24}, {szOption = "ͼ��", bMCheck = true, bChecked = l_13_19, fnAction = l_13_19}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_13_6 = PopupMenu
     -- DECOMPILER ERROR: Overwrote pending register.

    l_13_6(l_13_7)
    l_13_7 = {l_13_10, l_13_13, l_13_16, l_13_19, l_13_24; szOption = "��ʼ��С"}
  end
  l_11_3(l_11_4, l_11_5)
end

CD_Create = l_0_0
l_0_0 = RegisterMoonButton
l_0_1 = "CD"
l_0_0(l_0_1, 2795, "������ȴ", "General", CD_Create)

