-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: scroll.lua 

local l_0_0 = {}
local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = function(l_1_0)
  local l_1_1 = 1
  while 1 do
    local l_1_5 = string.find
    l_1_5 = l_1_5(l_1_0, "/", l_1_1)
    local l_1_2 = nil
    if not l_1_5 then
      do break end
    end
    l_1_1 = l_1_5 + 1
  end
  l_1_5 = string
  l_1_5 = l_1_5.sub
  l_1_2 = l_1_0
  local l_1_3 = nil
  l_1_3 = l_1_1
  local l_1_4 = nil
  return l_1_5(l_1_2, l_1_3)
end

end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

