-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon_CampTimer.lua 

local l_0_0 = {}
l_0_0["����"] = 5
l_0_0["��ͼ"] = 5
l_0_0["������"] = 5
l_0_0["������"] = 5
l_0_0["������"] = 3
l_0_0["������"] = 3
l_0_0["�����й�"] = 3
l_0_0["���˹�������"] = 4
local l_0_1 = "Interface\\Moon_CampTimer\\Moon_CampTimer.ini"
local l_0_2 = {}
local l_0_3 = {}
l_0_3.s = "CENTER"
l_0_3.r = "CENTER"
l_0_3.x = -215
l_0_3.y = 164
l_0_2.Anchor = l_0_3
l_0_2.tBossList, l_0_3 = l_0_3, {}
l_0_2.tDeadBoss, l_0_3 = l_0_3, {}
l_0_2.bOn = false
l_0_2.bCampBoss = true
l_0_2.bSay = false
l_0_2.bLock = false
l_0_2.bShowOutput = true
l_0_2.bAutoHide = true
l_0_2.bJiuGongBox = true
l_0_2.nVersion = 0
l_0_2.nCurrentVersion = 1
Moon_CampTimer = l_0_2
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.nVersion"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bCampBoss"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bJiuGongBox"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bAutoHide"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bOn"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.tBossList"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.Anchor"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bLock"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bShowOutput"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "Moon_CampTimer.bSay"
l_0_2(l_0_3)
l_0_2 = Moon_CampTimer
l_0_3 = function()
  Moon_CampTimer.frame = this
  Moon_CampTimer.wndOutput = this:Lookup("Wnd_Output")
  Moon_CampTimer.wndOutput:Lookup("", ""):Clear()
  Moon_CampTimer.UpdateBgSize(0)
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("LOADING_END")
end

l_0_2.OnFrameCreate = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_2_0)
  if not l_2_0 then
    l_2_0 = Moon_CampTimer.wndOutput:Lookup("", ""):GetItemCount()
  end
  Moon_CampTimer.frame:Lookup("", "Image_Bg"):SetSize(250, 30 + l_2_0 * 30)
  Moon_CampTimer.wndOutput:SetSize(250, l_2_0 * 30)
end

l_0_2.UpdateBgSize = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function()
  local l_3_0 = this:GetName()
  if l_3_0 == "Btn_Setting" then
    local l_3_1 = {}
    local l_3_2 = {}
    l_3_2.szOption = "�������λ��"
    l_3_2.bCheck = true
    l_3_2.bChecked = Moon_CampTimer.bLock
    l_3_2.fnAction = function()
      Moon_CampTimer.bLock = not Moon_CampTimer.bLock
      Moon_CampTimer.frame:EnableDrag(not Moon_CampTimer.bLock)
    end
    local l_3_3 = {}
    l_3_3.szOption = "����ˢ��ʱ��"
    l_3_3.bCheck = true
    l_3_3.bChecked = Moon_CampTimer.bSay
    l_3_3.fnAction = function()
      Moon_CampTimer.bSay = not Moon_CampTimer.bSay
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_3_2 = PopupMenu
    l_3_3 = l_3_1
    l_3_2(l_3_3)
  end
end

l_0_2.OnLButtonClick = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function()
  local l_4_0 = this:GetName()
  if l_4_0 == "CheckBox_Minimize" then
    Moon_CampTimer.bShowOutput = true
    Moon_CampTimer.wndOutput:Show()
    Moon_CampTimer.UpdateBgSize()
  end
end

l_0_2.OnCheckBoxCheck = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "CheckBox_Minimize" then
    Moon_CampTimer.bShowOutput = false
    Moon_CampTimer.wndOutput:Hide()
    Moon_CampTimer.UpdateBgSize(0)
  end
end

l_0_2.OnCheckBoxUncheck = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_6_0)
  -- upvalues: l_0_0
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_6_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    if Moon_CampTimer.nVersion < Moon_CampTimer.nCurrentVersion then
      Moon_CampTimer.tBossList = l_0_0
      Moon_CampTimer.nVersion = Moon_CampTimer.nCurrentVersion
    end
    Moon_CampTimer.UpdateAnchor(this)
    if Moon_CampTimer.bOn then
      this:Show()
    else
      this:Hide()
    end
    Moon_CampTimer.frame:EnableDrag(not Moon_CampTimer.bLock)
    Moon_CampTimer.frame:Lookup("CheckBox_Minimize"):Check(Moon_CampTimer.bShowOutput)
  end
  do return end
  if l_6_0 == "UI_SCALED" then
    Moon_CampTimer.UpdateAnchor(this)
  elseif l_6_0 == "SYS_MSG" then
    if not Moon_CampTimer.bOn or not Moon_CampTimer.bCampBoss then
      return 
    end
    if arg0 ~= "UI_OME_DEATH_NOTIFY" then
      return 
    end
    if IsPlayer(arg1) then
      return 
    end
    local l_6_1 = GetClientPlayer()
    local l_6_2 = GetNpc(arg1)
    if l_6_2 and Moon_CampTimer.tBossList[l_6_2.szName] then
      local l_6_3 = Moon_CampTimer.tBossList[l_6_2.szName]
      local l_6_4 = GetLogicFrameCount()
      local l_6_5 = Moon_CampTimer.tDeadBoss
      local l_6_6 = l_6_2.szName
      local l_6_7 = {}
      l_6_7.dwID = l_6_2.dwID
      l_6_7.dwMapID = l_6_1.GetMapID()
      l_6_7.tSayFrameCount = Moon_CampTimer.GetBossTime(l_6_3, true)
      l_6_7.nEndFrameCount = l_6_4 + l_6_3 * 960
      l_6_7.nStartFrameCount = l_6_4
      l_6_7.bNpc = true
      l_6_7.nX = l_6_2.nX
      l_6_7.nY = l_6_2.nY
      l_6_7.nZ = l_6_2.nZ
      l_6_5[l_6_6] = l_6_7
      l_6_5 = Moon_CampTimer
      l_6_5 = l_6_5.AppendTimer
      l_6_6 = l_6_2.szName
      l_6_5(l_6_6)
    end
  elseif l_6_0 == "NPC_ENTER_SCENE" then
    if not Moon_CampTimer.bOn or not Moon_CampTimer.bCampBoss then
      return 
    end
    local l_6_8 = GetNpc(arg0)
    if l_6_8 and Moon_CampTimer.tDeadBoss[l_6_8.szName] then
      Moon_CampTimer.RemoveTimer(l_6_8.szName)
      local l_6_9 = GetClientPlayer()
      if not l_6_9 or l_6_9.GetOTActionState() ~= 0 or l_6_9.bFightState then
        return 
      end
      Moon_Lib.SetTarget(l_6_8.dwID)
      if not Moon_CampTimer.bSay then
        return 
      end
      Moon_CampTimer.tDeadBoss[l_6_8.szName] = nil
      Moon_CampTimer.Talk(string.format("��� [%s] �����ˣ��ٶ�����", l_6_8.szName))
    end
  elseif l_6_0 == "LOADING_END" then
    if not Moon_CampTimer.bOn or not Moon_CampTimer.bJiuGongBox then
      return 
    end
    local l_6_10 = GetClientPlayer()
    if l_6_10 and l_6_10.GetMapID() == 48 then
      local l_6_11 = RegisterMsgMonitor
      local l_6_12 = Moon_CampTimer.OnMonitorMsg
      local l_6_13 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_6_11(l_6_12, l_6_13)
    end
  else
    local l_6_14 = UnRegisterMsgMonitor
    local l_6_15 = Moon_CampTimer.OnMonitorMsg
    local l_6_16 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_6_14(l_6_15, l_6_16)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_2.OnEvent = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_7_0)
  if not Moon_CampTimer.bOn or not Moon_CampTimer.bJiuGongBox then
    return 
  end
  if StringFindW(l_7_0, "��������籦��") then
    local l_7_1 = 180
    local l_7_2, l_7_3, l_7_4, l_7_5 = GetBattleFieldPQInfo()
    local l_7_6 = GetCurrentTime()
    if BigIntSub(l_7_5, l_7_6) < l_7_1 then
      return 
    end
    local l_7_7 = GetLogicFrameCount()
    for l_7_11,l_7_12 in ipairs({"һ�ű���", "���ű���"}) do
      if not Moon_CampTimer.tDeadBoss[l_7_12] then
        local l_7_13 = Moon_CampTimer.tDeadBoss
        local l_7_14 = {}
        l_7_14.dwID = l_7_11
        l_7_14.dwMapID = 48
        l_7_14.tSayFrameCount = Moon_CampTimer.GetBossTime(3)
        l_7_14.nEndFrameCount = l_7_7 + l_7_1 * 16
        l_7_14.nStartFrameCount = l_7_7
        l_7_14.bNpc = false
        l_7_13[l_7_12] = l_7_14
        l_7_13 = Moon_CampTimer
        l_7_13 = l_7_13.AppendTimer
        l_7_14 = l_7_12
        l_7_13(l_7_14)
      end
      do break end
    end
  end
end

l_0_2.OnMonitorMsg = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_8_0)
  l_8_0:SetPoint(Moon_CampTimer.Anchor.s, 0, 0, Moon_CampTimer.Anchor.r, Moon_CampTimer.Anchor.x, Moon_CampTimer.Anchor.y)
  l_8_0:CorrectPos()
end

l_0_2.UpdateAnchor = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_9_0, l_9_1)
  local l_9_2 = GetLogicFrameCount()
  local l_9_3 = {}
  local l_9_4 = l_9_0 * 960
  local l_9_5 = math.ceil(l_9_0) - 1
  if l_9_5 > 0 then
    local l_9_6 = l_9_2 + l_9_4 - l_9_5 * 960
    local l_9_7 = table.insert
    local l_9_8 = l_9_3
    local l_9_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_9_7(l_9_8, l_9_9)
  do
    else
      local l_9_10 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      if l_9_1 then
        local l_9_11 = {}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Overwrote pending register.

      for l_9_15,l_9_16 in ipairs(320) do
         -- DECOMPILER ERROR: Overwrote pending register.

        if l_9_16 < l_9_4 then
          local l_9_17 = 64 - l_9_16
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_9_18 = 48.insert
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_9_19 = 32
          local l_9_20 = {}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_9_18(l_9_19, l_9_20)
        end
      end
      return l_9_3
    end
     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 10 
end

l_0_2.GetBossTime = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function()
  this:CorrectPos()
  Moon_CampTimer.Anchor = GetFrameAnchor(this)
end

l_0_2.OnFrameDragEnd = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_11_0)
  -- upvalues: l_0_1
  local l_11_1 = Moon_CampTimer.tDeadBoss[l_11_0]
  if not l_11_1 then
    return 
  end
  local l_11_2 = Moon_CampTimer.wndOutput:Lookup("", "")
  local l_11_3 = l_11_2:AppendItemFromIni(l_0_1, "Handle_Item", tostring(l_11_1.dwID))
  l_11_3.Info = l_11_1
  l_11_3.szName = l_11_0
  l_11_2:FormatAllItemPos()
  Moon_CampTimer.UpdateBgSize()
end

l_0_2.AppendTimer = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_12_0)
  local l_12_1 = Moon_CampTimer.tDeadBoss[l_12_0]
  if not l_12_1 then
    return 
  end
  local l_12_2 = Moon_CampTimer.wndOutput:Lookup("", "")
  local l_12_3 = l_12_2:Lookup(tostring(l_12_1.dwID))
  if l_12_3 then
    l_12_2:RemoveItem(l_12_3:GetName())
  end
  l_12_2:FormatAllItemPos()
  Moon_CampTimer.UpdateBgSize()
end

l_0_2.RemoveTimer = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_13_0, l_13_1)
  if l_13_1 then
    l_13_0 = l_13_0 / GLOBAL.GAME_FPS
  end
  local l_13_2 = math.floor(l_13_0 / 3600)
  l_13_0 = l_13_0 - l_13_2 * 3600
  local l_13_3 = math.floor((l_13_0) / 60)
  l_13_0 = l_13_0 - l_13_3 * 60
  local l_13_4 = math.floor(l_13_0)
  return l_13_2, l_13_3, l_13_4
end

l_0_2.GetTimeToHourMinuteSecond = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_14_0, l_14_1)
  if l_14_0.nEndFrameCount < l_14_1 or GetClientPlayer().GetMapID() ~= l_14_0.dwMapID then
    return false
  end
  return true
end

l_0_2.CanShow = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function(l_15_0)
  local l_15_1 = GetClientPlayer()
  if not l_15_1.IsInParty() then
    return 
  end
  local l_15_2 = PLAYER_TALK_CHANNEL.TEAM
  if l_15_1.IsInRaid() then
    l_15_2 = PLAYER_TALK_CHANNEL.RAID
  end
  if l_15_1.GetScene().nType == MAP_TYPE.BATTLE_FIELD then
    l_15_2 = PLAYER_TALK_CHANNEL.BATTLE_FIELD
  end
  if type(l_15_0) == "table" then
    l_15_1.Talk(l_15_2, "", l_15_0)
  else
    local l_15_3 = l_15_1.Talk
    local l_15_4 = l_15_2
    local l_15_5 = ""
    local l_15_6 = {}
    local l_15_7 = {}
    l_15_7.type = "text"
    l_15_7.text = l_15_0
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_15_3(l_15_4, l_15_5, l_15_6)
  end
end

l_0_2.Talk = l_0_3
l_0_2 = Moon_CampTimer
l_0_3 = function()
  if not Moon_CampTimer.bOn then
    return 
  end
  local l_16_0 = GetClientPlayer()
  if not l_16_0 then
    return 
  end
  local l_16_1 = Moon_CampTimer.wndOutput:Lookup("", "")
  local l_16_2 = l_16_1:GetItemCount()
  if l_16_2 == 0 then
    return 
  end
  local l_16_3 = false
  local l_16_4 = GetLogicFrameCount()
  for l_16_8 = 0, l_16_2 - 1 do
    local l_16_9 = l_16_1:Lookup(l_16_8)
    if l_16_9 then
      if Moon_CampTimer.CanShow(l_16_9.Info, l_16_4) then
        local l_16_10 = l_16_9:Lookup("Text_Name")
        local l_16_11 = l_16_9:Lookup("Text_Time")
        local l_16_12 = l_16_9:Lookup("Image_Progress")
        local l_16_13 = l_16_9.Info
        l_16_10:SetText(l_16_9.szName)
        local l_16_14 = l_16_13.nEndFrameCount - l_16_4
        local l_16_15 = l_16_14 / (l_16_13.nEndFrameCount - l_16_13.nStartFrameCount)
        l_16_12:SetPercentage(l_16_15)
        local l_16_16, l_16_17, l_16_18 = GetTimeToHourMinuteSecond(l_16_14, true)
        if l_16_16 > 0 then
          l_16_11:SetText(string.format("%02d:%02d:%02d", l_16_16, l_16_17, l_16_18))
        else
          l_16_11:SetText(string.format("%02d:%02d", l_16_17, l_16_18))
        end
        if l_16_17 == 0 and l_16_18 < 15 then
          l_16_12:SetFrame(1)
        end
        local l_16_19 = l_16_13.tSayFrameCount[1]
      end
      if l_16_19 and l_16_19[1] <= l_16_4 then
        if ((l_16_13.bNpc and Moon_Lib.GetDistance(l_16_0, l_16_13) < 100) or not l_16_13.bNpc) and Moon_CampTimer.bSay then
          Moon_CampTimer.Talk(string.format("��� [%s]����%s����֡�", l_16_9.szName, l_16_19[2]))
        end
        table.remove(l_16_13.tSayFrameCount, 1)
      end
    else
      l_16_1:RemoveItem(l_16_9:GetIndex())
      l_16_3 = true
    end
  end
  if l_16_3 then
    l_16_1:FormatAllItemPos()
  end
  if Moon_CampTimer.bShowOutput then
    Moon_CampTimer.UpdateBgSize()
  end
end

l_0_2.OnFrameBreathe = l_0_3
l_0_2 = RegisterEvent
l_0_3 = "Breathe"
l_0_2(l_0_3, function()
  if GetLogicFrameCount() % 4 ~= 0 then
    return 
  end
  local l_17_0 = Station.Lookup("Normal/Moon_CampTimer")
  if not l_17_0 then
    return 
  end
  if not Moon_CampTimer.bOn then
    l_17_0:Hide()
    return 
  end
  local l_17_1 = GetLogicFrameCount()
  for l_17_5,l_17_6 in pairs(Moon_CampTimer.tDeadBoss) do
    if l_17_1 - l_17_6.nEndFrameCount > 32 then
      Moon_CampTimer.tDeadBoss[l_17_5] = nil
    end
  end
  if not Moon_CampTimer.bAutoHide then
    l_17_0:Show()
  else
    local l_17_7, l_17_8 = l_17_0:Lookup("Wnd_Output", "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_17_8 > 0 then
      l_17_8(l_17_0)
    end
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_17_8(l_17_0)
  end
end
)
l_0_2 = Wnd
l_0_2 = l_0_2.OpenWindow
l_0_3 = l_0_1
l_0_2(l_0_3, "Moon_CampTimer")
l_0_2 = 0
l_0_3 = function(l_18_0)
  -- upvalues: l_0_2
  local l_18_1 = "Moon_CampTimerPanel" .. l_0_2
  local l_18_2 = BoxSetFrame
  local l_18_3 = l_18_1
  local l_18_4 = {}
  l_18_4.w = 350
  l_18_4.h = 270
  l_18_4.bdrag = true
  l_18_2 = l_18_2(l_18_3, l_18_4)
  l_18_3, l_18_4 = l_18_2:Center, l_18_2
  l_18_3(l_18_4)
  l_18_3, l_18_4 = l_18_2:ui, l_18_2
  l_18_3 = l_18_3(l_18_4)
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_18_5 = BoxLabel
  local l_18_6 = l_18_4
  local l_18_7 = "Text_Title"
  local l_18_8 = "����Npcˢ��ʱ��"
  local l_18_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_18_10 = 0
  local l_18_11 = {}
  l_18_11.nW = 350
  l_18_11.nH = 30
  l_18_11.nHAlign = 1
  l_18_5 = l_18_5(l_18_6, l_18_7, l_18_8, l_18_9, l_18_10, l_18_11)
  l_18_6 = BoxLabel
  l_18_7 = l_18_4
  l_18_8 = "Text_Name"
  l_18_9 = "Npc���ƣ�"
  l_18_11 = 40
  l_18_6(l_18_7, l_18_8, l_18_9, l_18_10)
  l_18_10 = {l_18_11, 50}
  l_18_6 = BoxEdit
  l_18_7 = l_18_3
  l_18_8 = "Edit_Name"
  l_18_6, l_18_9 = l_18_6(l_18_7, l_18_8, l_18_9), {x = 40, y = 80, w = 250, h = 30}
  l_18_7 = BoxLabel
  l_18_8 = l_18_4
  l_18_9 = "Text_Time"
  l_18_10 = "ˢ��ʱ�䣺"
  l_18_7(l_18_8, l_18_9, l_18_10, l_18_11)
  l_18_11 = {40, 120}
  l_18_7 = BoxEdit
  l_18_8 = l_18_3
  l_18_9 = "Edit_Time"
  l_18_7, l_18_10 = l_18_7(l_18_8, l_18_9, l_18_10), {x = 40, y = 150, w = 250, h = 30}
  l_18_8 = BoxButton
  l_18_9 = l_18_3
  l_18_10 = "Btn_Sure"
  l_18_8, l_18_11 = l_18_8(l_18_9, l_18_10, l_18_11), {x = 60, w = 90, h = 30, y = 210, txt = "ȷ��"}
  l_18_8, l_18_9 = l_18_8:OnClick, l_18_8
  l_18_10 = function()
    -- upvalues: l_18_6 , l_18_7 , l_18_0 , l_18_1
    local l_19_0 = l_18_6:GetText()
    local l_19_1 = l_18_7:GetText()
    if l_19_0 == "" or l_19_1 == "" then
      MsgBox("Npc���ƺ�ˢ��ʱ�䶼����Ϊ�գ�")
      return 
    end
    local l_19_2 = tonumber(l_19_1)
    if not l_19_2 then
      MsgBox("Npcˢ��ʱ��ֻ��Ϊ���֣�")
      return 
    end
    if l_18_0 and l_19_0 ~= l_18_0 then
      Moon_CampTimer.tBossList[l_18_0] = nil
    end
    Moon_CampTimer.tBossList[l_19_0] = l_19_2
    Wnd.CloseWindow(l_18_1)
  end
  l_18_8(l_18_9, l_18_10)
  l_18_8 = BoxButton
  l_18_9 = l_18_3
  l_18_10 = "Btn_Cancel"
  l_18_8, l_18_11 = l_18_8(l_18_9, l_18_10, l_18_11), {x = 180, w = 90, h = 30, y = 210, txt = "ȡ��"}
  l_18_8, l_18_9 = l_18_8:OnClick, l_18_8
  l_18_10 = function()
    -- upvalues: l_18_1
    Wnd.CloseWindow(l_18_1)
  end
  l_18_8(l_18_9, l_18_10)
  if l_18_0 then
    l_18_8, l_18_9 = l_18_5:SetText, l_18_5
    l_18_10 = "�޸�Npcˢ��ʱ��"
    l_18_8(l_18_9, l_18_10)
    l_18_8, l_18_9 = l_18_6:SetText, l_18_6
    l_18_10 = l_18_0
    l_18_8(l_18_9, l_18_10)
    l_18_8, l_18_9 = l_18_7:SetText, l_18_7
    l_18_10 = Moon_CampTimer
    l_18_10 = l_18_10.tBossList
    l_18_10 = l_18_10[l_18_0]
    l_18_8(l_18_9, l_18_10)
  end
  l_18_8 = l_0_2
  l_18_8 = l_18_8 + 1
  l_0_2 = l_18_8
  l_18_8, l_18_9 = l_18_4:FormatAllItemPos, l_18_4
  l_18_8(l_18_9)
end

Moon_CampTimer.AddBossTimeMenu = function(l_19_0)
  -- upvalues: l_0_3
  local l_19_1 = table.insert
  local l_19_2 = l_19_0
  local l_19_3 = {}
  l_19_3.szOption = "����"
  l_19_3.fnAction = function()
    -- upvalues: l_0_3
    l_0_3()
  end
  l_19_1(l_19_2, l_19_3)
  l_19_1 = table
  l_19_1 = l_19_1.insert
  l_19_2 = l_19_0
  l_19_1(l_19_2, l_19_3)
  l_19_3 = {bDevide = true}
  l_19_1 = pairs
  l_19_2 = Moon_CampTimer
  l_19_2 = l_19_2.tBossList
  l_19_1 = l_19_1(l_19_2)
  for i_1,i_2 in l_19_1 do
    do
      local l_19_6 = table.insert
      local l_19_7 = l_19_0
      local l_19_8 = {}
      l_19_8.szOption = string.format("%s��%s���ӣ�", l_19_4, tostring(l_19_5))
      local l_19_9 = {}
      l_19_9.szOption = "�޸�"
      l_19_9.fnAction = function()
        -- upvalues: l_0_3 , l_19_4
        l_0_3(l_19_4)
      end
      local l_19_10 = {}
      l_19_10.szOption = "ɾ��"
      l_19_10.fnAction = function()
        -- upvalues: l_19_4
        Moon_CampTimer.tBossList[l_19_4] = nil
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_19_6(l_19_7, l_19_8)
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

Moon_CampTimer.Create = function(l_20_0)
  local l_20_1 = l_20_0:Lookup("", "")
  BoxBoolCheckBox(l_20_0, "CheckBox_bOn", "��������ʱ������", Moon_CampTimer, "bOn", function()
    Moon_CampTimer.frame:Show()
  end, function()
    Moon_CampTimer.frame:Hide()
  end)
  BoxBoolCheckBox(l_20_0, "CheckBox_bSay", "�Զ���������ʱ", Moon_CampTimer, "bSay"):SetRelPos(200, 0)
  BoxBoolCheckBox(l_20_0, "Checkbox_bAutoHide", "������ʱ�Զ�����", Moon_CampTimer, "bAutoHide"):SetRelPos(0, 30)
  BoxBoolCheckBox(l_20_0, "CheckBox_bCampBoss", "��ӪNpcˢ�µ���ʱ", Moon_CampTimer, "bCampBoss"):SetRelPos(0, 60)
  local l_20_2 = BoxComboBox
  local l_20_3 = l_20_0
  local l_20_4 = "ComboBox_BossTime"
  local l_20_5 = {}
  l_20_5.txt = "����Npcˢ��ʱ��"
  l_20_5.x = 160
  l_20_5.y = 60
  l_20_2 = l_20_2(l_20_3, l_20_4, l_20_5)
  l_20_2, l_20_3 = l_20_2:SetMenu, l_20_2
  l_20_4 = Moon_CampTimer
  l_20_4 = l_20_4.AddBossTimeMenu
  l_20_2(l_20_3, l_20_4)
  l_20_2 = BoxBoolCheckBox
  l_20_3 = l_20_0
  l_20_4 = "CheckBox_bJiuGongBox"
  l_20_5 = "���þŹ����䵹��ʱ"
  l_20_2 = l_20_2(l_20_3, l_20_4, l_20_5, Moon_CampTimer, "bJiuGongBox")
  l_20_2, l_20_3 = l_20_2:SetRelPos, l_20_2
  l_20_4 = 0
  l_20_5 = 90
  l_20_2(l_20_3, l_20_4, l_20_5)
end

RegisterMoonButton("CampTimer", 444, "����ʱ��", "General", Moon_CampTimer.Create)

