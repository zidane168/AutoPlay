-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BagTipEx.lua 

local l_0_0 = {}
l_0_0.bShow = true
l_0_0.bTipCraft = true
l_0_0.bTipLearnCraft = true
l_0_0.bTipLearnCraftColor = false
l_0_0.bTipFilterCraftLow = true
l_0_0.bStackBag = true
l_0_0.bStackBank = true
BagTipEx = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bStackBag")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bStackBank")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bShow")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bTipCraft")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bTipLearnCraft")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bTipLearnCraftColor")
l_0_0 = RegisterCustomData
l_0_0("BagTipEx.bTipFilterCraftLow")
l_0_0 = false
local l_0_1 = {}
local l_0_2 = false
BagTipEx.Create = function(l_1_0)
  -- upvalues: l_0_0
  local l_1_1 = l_1_0:Lookup("", "")
  BoxBoolCheckBox(l_1_0, "CheckBox_bShow", "���ñ���������ʾ", BagTipEx, "bShow")
  local l_1_2 = 30
  if l_0_0 then
    BoxBoolCheckBox(l_1_0, "CheckBox_bTipCraft", "�����䷽��ʾ", BagTipEx, "bTipCraft"):SetRelPos(20, l_1_2)
    BoxBoolCheckBox(l_1_0, "CheckBox_bLearn", "����ʾ��ѧ�䷽", BagTipEx, "bTipLearnCraft"):SetRelPos(40, l_1_2 + 30)
    BoxBoolCheckBox(l_1_0, "CheckBox_bFilterLow", "���˵ͼ��䷽", BagTipEx, "bTipFilterCraftLow"):SetRelPos(40, l_1_2 + 60)
    BoxBoolCheckBox(l_1_0, "CheckBox_bColor", "���䷽ѧϰ״̬��ɫ", BagTipEx, "bTipLearnCraftColor"):SetRelPos(40, l_1_2 + 90)
    l_1_2 = l_1_2 + 120
  end
  local l_1_3 = BoxLabel
  local l_1_4 = l_1_1
  local l_1_5 = "label2"
  local l_1_6 = "��Ʒ�ѵ�"
  local l_1_7 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3(l_1_4, l_1_5, l_1_6, l_1_7, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3(l_1_4, l_1_5, l_1_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3(l_1_4, l_1_5, l_1_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_3(l_1_4)
end

RegisterMoonButton("BagTipEx", 2361, "��������", "General", BagTipEx.Create)
RegisterEvent("LOADING_END", function()
  -- upvalues: l_0_0 , l_0_3
  l_0_0 = Moon.CheckAddon("Moon_CraftRecipePlus")
  UnRegisterEvent("LOADING_END", l_0_3)
end
)
local l_0_4 = nil
RegisterTipFunc(function()
  if not BagTipEx.bShow then
    return false
  end
  local l_5_0 = Station.GetMouseOverWindow()
  if not l_5_0 or l_5_0:GetName() ~= "BigBagPanel" then
    return false
  end
  return true
end
, function(l_6_0)
  -- upvalues: l_0_0
  local l_6_1 = GetBigBagSelBox()
  if not l_6_1 then
    return 
  end
  local l_6_2 = GetClientPlayer()
  local l_6_3 = l_6_2.GetItem(l_6_1.dwBox, l_6_1.dwX)
  if l_6_3 then
    local l_6_4 = table.hasVal
    local l_6_5 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_6_4 then
    if l_6_5 then
      l_6_5(l_6_4, GetFormatText("\n"))
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_6_6 = l_6_2.GetItemAmountInAllPackages(l_6_3.dwTabType, l_6_3.dwIndex)
    local l_6_7 = l_6_6 - l_6_5
    table.insert(l_6_4, GetFormatText("������", 101) .. GetFormatText(l_6_5) .. GetFormatText("  �ֿ⣺", 101) .. GetFormatText(l_6_7) .. GetFormatText("\n"))
    if BagTipEx.bTipCraft and l_6_3.nGenre == ITEM_GENRE.MATERIAL and l_0_0 then
      local l_6_11, l_6_12, l_6_13, l_6_14, l_6_15 = table.insert, l_6_4, CraftRecipePlus.GetItemRecipeTip(l_6_3.szName, BagTipEx.bTipLearnCraft, BagTipEx.bTipLearnCraftColor, BagTipEx.bTipFilterCraftLow), .end
      l_6_11(l_6_12, l_6_13, l_6_14, l_6_15)
    end
    local l_6_8 = table.concat
    local l_6_9 = l_6_4
    local l_6_10 = ""
    return l_6_8(l_6_9, l_6_10)
  end
end
)
local l_0_5 = function(l_3_0)
  local l_3_1 = l_3_0:GetItemCount()
  for l_3_5 = 0, l_3_1 - 1 do
    local l_3_6 = l_3_0:Lookup(l_3_5)
    if l_3_6 then
      local l_3_7 = l_3_6:GetItemCount()
      for l_3_11 = 0, l_3_7 - 1 do
        local l_3_12 = l_3_6:Lookup(l_3_11)
        if l_3_12 and l_3_12:GetType() == "Box" and l_3_12:IsObjectMouseOver() then
          return l_3_12
        end
      end
    end
  end
end

local l_0_9 = function(l_9_0)
  return INVENTORY_INDEX.BANK + l_9_0 - 1
end

do
  local l_0_11 = function(l_10_0)
  -- upvalues: l_0_5
  local l_10_1 = {}
  local l_10_2 = GetClientPlayer()
  if not l_10_0 then
    l_10_0 = 0
  end
  local l_10_3, l_10_4 = nil, nil
  if l_10_0 == 0 then
    l_10_3 = BIGBAGCOUNT
    l_10_4 = BagIndexToInventoryIndex
  else
    l_10_3 = 6
    l_10_4 = l_0_5
  end
  for l_10_8 = 1, l_10_3 do
    local l_10_9 = l_10_4(l_10_8)
    local l_10_10 = l_10_2.GetBoxSize(l_10_9)
    if l_10_10 and l_10_10 ~= 0 then
      for l_10_14 = 0, l_10_10 - 1 do
        local l_10_15 = l_10_2.GetItem(l_10_9, l_10_14)
        if l_10_15 and l_10_15.bCanStack and l_10_15.nStackNum < l_10_15.nMaxStackNum then
          local l_10_16 = l_10_15.szName
          local l_10_17 = l_10_15.nStackNum
          local l_10_18 = l_10_15.nMaxStackNum
          if not l_10_1[l_10_16] then
            l_10_1[l_10_16] = {}
          end
          local l_10_19 = table.insert
          local l_10_20 = l_10_1[l_10_16]
          local l_10_21 = {}
          l_10_21.dwBox = l_10_9
          l_10_21.dwX = l_10_14
          l_10_21.nStackNum = l_10_17
          l_10_21.nMaxStackNum = l_10_18
          l_10_21.dwTabType = l_10_15.dwTabType
          l_10_21.dwIndex = l_10_15.dwIndex
          l_10_19(l_10_20, l_10_21)
        end
      end
    end
  end
  return l_10_1
end

  RegisterEvent("Breathe", function()
  -- upvalues: l_0_8 , l_0_2 , l_0_10 , l_0_1
  l_0_8(Station.Lookup("Normal/BigBagPanel"), BagTipEx.bStackBag, 0, 50, -50)
  local l_15_0 = Station.Lookup("Normal/BigBankPanel")
  l_0_8(l_15_0, BagTipEx.bStackBank, 1, 91, 90)
  if l_0_2 then
    if l_15_0 then
      l_0_10(l_0_1)
    end
  else
    l_0_2 = false
  end
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

