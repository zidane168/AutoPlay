-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetEx.lua 

local l_0_0 = {}
l_0_0.bAdjustTargetBuff = true
l_0_0.nTargetBuffSize = 35
l_0_0.bAdjustTTargetBuff = true
l_0_0.nTTargetBuffSize = 30
l_0_0.bName = false
l_0_0.bMana = true
l_0_0.bAdjustBar = true
l_0_0.nBuffBreathe = 0
l_0_0.bShieldBuff = false
l_0_0.bShieldTTBuff = false
l_0_0.bShowFace = false
l_0_0.tChannel = {}
TargetEx = l_0_0
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bShowFace")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bShieldBuff")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bShieldTTBuff")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bAdjustTTargetBuff")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.nTTargetBuffSize")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.nTargetBuffSize")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bAdjustTargetBuff")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bName")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bMana")
l_0_0 = RegisterCustomData
l_0_0("TargetEx.bAdjustBar")
l_0_0 = TargetEx
l_0_0.UpdateName = function(l_1_0, l_1_1, l_1_2)
  local l_1_3 = GetTargetHandle(l_1_0.dwType, l_1_0.dwID)
  if not l_1_3 then
    return 
  end
  local l_1_4 = TargetEx.GetIniFile(l_1_2)
  local l_1_5 = l_1_0:Lookup("", "")
  local l_1_6 = l_1_5:Lookup("Text_Target")
  if not l_1_5:Lookup("Text_TargetEx") then
    local l_1_7, l_1_8 = l_1_5:AppendItemFromIni(l_1_4, "Text_Target", "Text_TargetEx")
    l_1_8(l_1_7, l_1_6:GetSize())
     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_8(l_1_7, l_1_6:GetRelPos())
     -- DECOMPILER ERROR: Overwrote pending register.

    l_1_8(l_1_5)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_1_9 = nil
  if l_1_1 then
    if l_1_6:IsVisible() then
      l_1_6:Hide()
    end
    if l_1_0.dwType == TARGET.PLAYER then
      local l_1_10 = "%.1f":format(Moon_Lib.GetTargetDistance(l_1_3)) .. "��" .. l_1_8(l_1_0.dwType, l_1_0.dwID)
      if l_1_3.GetKungfuMount() then
        l_1_10 = l_1_10 .. "��" .. string.sub(Table_GetSkillName(l_1_3.GetKungfuMount().dwSkillID, l_1_3.GetKungfuMount().dwLevel), 1, 4)
      end
    else
      if l_1_0.dwType == TARGET.NPC and l_1_3.dwDropTargetPlayerID and l_1_3.dwDropTargetPlayerID ~= 0 then
        local l_1_11 = nil
      end
    end
    if GetPlayer(l_1_3.dwDropTargetPlayerID) then
      l_1_11 = l_1_11 .. "��" .. GetPlayer(l_1_3.dwDropTargetPlayerID).szName
    end
    l_1_9:SetFontColor(GetForceFontColor(l_1_0.dwID, GetClientPlayer().dwID))
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_1_9:SetText(l_1_11)
    if not l_1_9:IsVisible() then
      l_1_9:Show()
    end
  else
    if not l_1_6:IsVisible() then
      l_1_6:Show()
    end
  end
  if l_1_9:IsVisible() then
    l_1_9:Hide()
  end
end

l_0_0 = TargetEx
l_0_0.GetIniFile = function(l_2_0)
  if l_2_0 then
    return "ui/config/default/targettarget.ini"
  end
  local l_2_1 = Station.Lookup("Normal/Target")
  local l_2_2 = "ui/config/default/"
  local l_2_3 = ""
  local l_2_4 = GetClientPlayer()
  if l_2_1.dwType == TARGET.PLAYER then
    l_2_3 = "TargetPlayer10"
    if IsEnemy(l_2_1.dwID, l_2_4.dwID) then
      l_2_3 = "TargetPlayer11"
    end
  else
    if l_2_1.dwType == TARGET.NPC then
      if not GetNpc(l_2_1.dwID) then
        return 
      end
      l_2_3 = "Target" .. l_2_1.nIntensity
      if IsEnemy(l_2_1.dwID, l_2_4.dwID) then
        l_2_3 = l_2_3 .. "2"
      end
    end
  else
    if IsNeutrality(l_2_1.dwID, l_2_4.dwID) then
      l_2_3 = l_2_3 .. "1"
    end
  else
    l_2_3 = l_2_3 .. "0"
  end
  return l_2_2 .. l_2_3 .. ".ini"
end

local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_2 = function(l_16_0)
  if not l_16_0.bInitHook then
    if l_16_0:IsVisible() then
      l_16_0.bShow = true
    else
      l_16_0.bShow = false
      l_16_0.bInitHook = true
    end
    if not l_16_0.ShowOrg then
      l_16_0.ShowOrg = l_16_0.Show
      l_16_0.Show = function()
        -- upvalues: l_16_0
        l_16_0.bShow = true
      end
    end
    if not l_16_0.HideOrg then
      l_16_0.HideOrg = l_16_0.Hide
      l_16_0.Hide = function()
        -- upvalues: l_16_0
        l_16_0.bShow = false
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_3 = function(l_22_0)
  if not l_22_0 then
    return 
  end
  local l_22_1 = l_22_0:Lookup("", "Handle_Box")
  if not l_22_1 then
    return 
  end
  local l_22_2 = l_22_1:GetItemCount()
  for l_22_6 = 0, l_22_2 - 1 do
    local l_22_7 = l_22_1:Lookup(l_22_6)
    if l_22_7 and not l_22_7.bFont then
      l_22_7:SetOverTextFontScheme(0, 16)
      l_22_7.bFont = true
    end
  end
end

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_4 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

RegisterEvent("SYS_MSG", "TarBgF")
RegisterEvent("DO_SKILL_CAST", function(l_26_0)
  TargetEx.OnSkillCast(arg0, arg1, arg2, l_26_0)
end
)
RegisterEvent("BUFF_UPDATE", function()
  TargetEx.OnBuffUpdate(Station.Lookup("Normal/Target"))
  TargetEx.OnBuffUpdate(Station.Lookup("Normal/TargetTarget"), true)
end
)
for l_0_8,l_0_9 in pairs({"PLAYER_STATE_UPDATE", "NPC_STATE_UPDATE"}) do
  RegisterEvent(l_0_9, function()
    if not TargetEx.bMana then
      return 
    end
    local l_28_0 = Station.Lookup("Normal/Target")
    if l_28_0 and l_28_0:IsVisible() and l_28_0.dwType == TARGET.PLAYER and l_28_0.dwID == arg0 then
      TargetEx.OnManaUpdate(l_28_0, false)
    end
  end)
end
RegisterEvent("Breathe", TargetEx.OnBreathe)
do
  local l_0_10, l_0_11 = function(l_29_0)
  TargetEx.UpdateDefaultMana(l_29_0)
  TargetEx.UpdateDefaultBgImage(l_29_0)
end

  l_0_11 = TargetEx
  l_0_11.OnCreate = function(l_30_0)
  -- upvalues: l_0_5
  local l_30_1 = l_30_0:Lookup("", "")
  BoxBoolCheckBox(l_30_0, "CheckBox_bName", "Ŀ��������ʾ������Ϣ", TargetEx, "bName")
  BoxBoolCheckBox(l_30_0, "CheckBox_bAdjustBar", "Ŀ�������ʾ��Buff�Ϸ�", TargetEx, "bAdjustBar"):SetRelPos(200, 0)
  BoxBoolCheckBox(l_30_0, "CheckBox_bMana", "����Ŀ��������ǿ", TargetEx, "bMana", nil, function()
    -- upvalues: l_0_5
    l_0_5(Station.Lookup("Normal/Target"))
    l_0_5(Station.Lookup("Normal/TargetTarget"))
  end):SetRelPos(0, 30)
  BoxBoolCheckBox(l_30_0, "CheckBox_bShowFace", "��ʾĿ�������Լ��ĽǶ�", TargetEx, "bShowFace"):SetRelPos(200, 30)
  local l_30_2 = BoxLabel
  local l_30_3 = l_30_1
  local l_30_4 = "label1"
  local l_30_5 = "Buff��С����"
  local l_30_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_2(l_30_3, l_30_4, l_30_5, l_30_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_3(l_30_4, l_30_5, l_30_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_3(l_30_4, l_30_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_3(l_30_4, l_30_5)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_4(l_30_5, l_30_6, 25)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_4(l_30_5, l_30_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_4(l_30_5, l_30_6, 92)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_30_7 = {}
  l_30_7.txt = "Ŀ���Ŀ��Buff��С"
  l_30_7.x = 0
  l_30_7.y = 120
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = TargetEx
  l_30_5(l_30_6, l_30_7, "bAdjustTTargetBuff")
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = TargetEx
  l_30_7 = l_30_7.RefreshBuff
  l_30_5(l_30_6, l_30_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = TargetEx
  l_30_7 = l_30_7.RefreshBuff
  l_30_5(l_30_6, l_30_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = "ComboBox_TTBuffSize"
  local l_30_8 = {}
  l_30_8.txt = TargetEx.nTTargetBuffSize
  l_30_8.x = 165
  l_30_8.y = 122
  l_30_8.w = 60
  l_30_8.h = 25
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_5
  l_30_8 = ""
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_6
  l_30_8 = 50
  l_30_6(l_30_7, l_30_8, 25)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_5
  l_30_8 = function(l_33_0)
    -- upvalues: l_30_5
    for l_33_4 = 25, 60, 5 do
      do
        local l_33_5 = table.insert
        local l_33_6 = l_33_0
        local l_33_7 = {}
        l_33_7.szOption = tostring(l_33_4)
        l_33_7.fnAction = function()
          -- upvalues: l_3_4 , l_30_5
          TargetEx.nTTargetBuffSize = l_3_4
          l_30_5:SetText(tostring(l_3_4))
          if TargetEx.bAdjustTTargetBuff then
            TargetEx.RefreshBuff()
          end
        end
        l_33_5(l_33_6, l_33_7)
      end
    end
  end
  l_30_6(l_30_7, l_30_8)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_0
  l_30_8 = "CheckBox_bShieldTTBuff"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_6
  l_30_8 = 228
  l_30_6(l_30_7, l_30_8, 122)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7 = l_30_1
  l_30_8 = "label2"
  local l_30_9 = "Ŀ�귽���ѡ���ʾ"
  local l_30_10 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_6(l_30_7, l_30_8, l_30_9, l_30_10, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_7(l_30_8, l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10 = {x = 300, y = 210, txt = "��ʾͷ��������"}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_30_8 then
    l_30_10 = true
    l_30_8(l_30_9, l_30_10)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10 = function()
    TargetLine.bPoint = true
  end
  l_30_8(l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10 = function()
    TargetLine.bPoint = false
    TargetLine.PointHide()
  end
  l_30_8(l_30_9, l_30_10)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10 = "label3"
  local l_30_11 = "Ŀ��׷����"
  local l_30_12 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_8(l_30_9, l_30_10, l_30_11, l_30_12, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_30_9 then
    l_30_9(l_30_10, l_30_11)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_9(l_30_10, l_30_11)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_9(l_30_10, l_30_11)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_30_10 then
    l_30_10(l_30_11, l_30_12)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10(l_30_11, l_30_12)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_10(l_30_11, l_30_12)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_30_13 = "ComboBox_LineSet"
  local l_30_14 = {}
  l_30_14.x = 0
  l_30_14.y = 300
  l_30_14.txt = "׷�����趨"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_13 = l_30_11
  l_30_14 = l_30_10
  l_30_12(l_30_13, l_30_14)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_30_13 = l_30_1
  l_30_12(l_30_13)
end

  l_0_11 = RegisterMoonButton
end
 -- DECOMPILER ERROR: Confused about usage of registers!

l_0_11("TargetEx", 2019, "Ŀ����ǿ", "General", TargetEx.OnCreate)

