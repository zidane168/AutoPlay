-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: GuildSort.lua 

local l_0_0 = INVENTORY_INDEX.TOTAL + 1
local l_0_1 = 100
local l_0_2 = {}
l_0_2.nPage = 0
GuildSort = l_0_2
local l_0_3 = false
GuildSort.Create = function(l_1_0)
  local l_1_1 = l_1_0:Lookup("", "")
  local l_1_2 = BoxButton
  local l_1_3 = l_1_0
  local l_1_4 = "Btn_Sort"
  local l_1_5 = {}
  l_1_5.txt = "����"
  l_1_5.w = 127
  l_1_5.h = 26
  l_1_5.x = 480
  l_1_5.y = 475
  l_1_2 = l_1_2(l_1_3, l_1_4, l_1_5)
  l_1_3, l_1_4 = l_1_2:Lookup, l_1_2
  l_1_5 = ""
  l_1_3 = l_1_3(l_1_4, l_1_5, "Text_Btn")
  l_1_3, l_1_4 = l_1_3:SetSize, l_1_3
  l_1_5 = 127
  l_1_3(l_1_4, l_1_5, 23)
  l_1_3, l_1_4 = l_1_2:OnClick, l_1_2
  l_1_5 = function()
    GuildSort.StartAccess(true)
  end
  l_1_3(l_1_4, l_1_5)
  l_1_3 = BoxButton
  l_1_4 = l_1_0
  l_1_5 = "Btn_Stack"
  local l_1_6 = {}
  l_1_6.txt = "�ѵ�"
  l_1_6.w = 127
  l_1_6.h = 26
  l_1_6.x = 345
  l_1_6.y = 475
  l_1_3 = l_1_3(l_1_4, l_1_5, l_1_6)
  l_1_4, l_1_5 = l_1_3:Lookup, l_1_3
  l_1_6 = ""
  l_1_4 = l_1_4(l_1_5, l_1_6, "Text_Btn")
  l_1_4, l_1_5 = l_1_4:SetSize, l_1_4
  l_1_6 = 127
  l_1_4(l_1_5, l_1_6, 23)
  l_1_4, l_1_5 = l_1_3:OnClick, l_1_3
  l_1_6 = function()
    GuildSort.StartAccess()
  end
  l_1_4(l_1_5, l_1_6)
  l_1_4 = BoxLabel
  l_1_5 = l_1_1
  l_1_6 = "Text_SortMsg"
  local l_1_7 = ""
  local l_1_8 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_1_9 = 30
  local l_1_10 = {}
  l_1_10.nW = 300
  l_1_10.nH = 25
  l_1_4(l_1_5, l_1_6, l_1_7, l_1_8, l_1_9, l_1_10)
  l_1_4, l_1_5 = l_1_1:FormatAllItemPos, l_1_1
  l_1_4(l_1_5)
end

GuildSort.StartAccess = function(l_2_0)
  -- upvalues: l_0_3 , l_0_2
  local l_2_1 = Station.Lookup("Normal/GuildBankPanel")
  if not l_2_1 then
    return 
  end
  local l_2_2 = GetClientPlayer()
  local l_2_3 = GetTongClient()
  local l_2_4 = l_2_3.GetMemberInfo(l_2_2.dwID)
  if not l_2_4 then
    return 
  end
  local l_2_5 = 6 + l_2_1.nPage * 2
  local l_2_6 = l_2_3.CheckBaseOperationGroup(l_2_4.nGroupID, l_2_5)
  if not l_2_6 then
    GuildSort.OutputMsg("Ȩ�޲��㣡")
    return 
  end
  if l_2_0 then
    GuildSort.OutputMsg("��ʼ����...")
    l_2_1.SortState = true
    l_0_3 = false
  else
    GuildSort.Stack()
  end
  if #l_0_2 > 0 then
    GuildSort.OutputMsg("��ʼ�ѵ�...")
    l_2_1.StackState = true
  end
  if l_2_1.SortState or l_2_1.StackState then
    l_2_1:Lookup("Btn_Sort"):Enable(false)
    l_2_1:Lookup("Btn_Stack"):Enable(false)
  end
end

local l_0_5 = function(l_3_0, l_3_1)
  -- upvalues: l_0_0 , l_0_1
  return l_0_0, l_3_0 * l_0_1 + l_3_1
end

do
  RegisterEvent("Breathe", function()
  -- upvalues: l_0_6 , l_0_3
  local l_10_0 = Station.Lookup("Normal/GuildBankPanel")
  if not l_10_0 then
    return 
  end
  if not l_10_0:Lookup("Btn_Sort") then
    GuildSort.Create(l_10_0)
    local l_10_1 = GetTongClient()
    l_10_1.ApplyTongInfo()
    l_10_1.ApplyTongRoster()
    return 
  end
  if GuildSort.nPage ~= l_10_0.nPage then
    if l_10_0.StackState or l_10_0.SortState then
      l_10_0:Lookup("Btn_Sort"):Enable(true)
      l_10_0:Lookup("Btn_Stack"):Enable(true)
    end
    if l_10_0.SortState then
      l_10_0.SortState = false
      GuildSort.OutputMsg("ֹͣ������")
    elseif l_10_0.StackState then
      l_10_0.StackState = false
      GuildSort.OutputMsg("ֹͣ�ѵ���")
    end
    GuildSort.nPage = l_10_0.nPage
  end
  local l_10_2 = l_10_0:Lookup("", "")
  local l_10_3 = l_10_2:Lookup("Text_SortMsg")
  local l_10_4 = l_10_3:GetAlpha()
  if l_10_4 > 0 then
    if l_10_4 < 8 then
      l_10_4 = 8
    end
  else
    l_10_3:SetAlpha(l_10_4 - 8)
  end
  if l_10_0.StackState then
    l_0_6(l_10_0)
  end
  if l_10_0.SortState and not l_0_3 then
    GuildSort.Sort()
    l_0_3 = true
  end
end
)
  RegisterEvent("UPDATE_TONG_REPERTORY_PAGE", function()
  -- upvalues: l_0_3
  local l_11_0 = Station.Lookup("Normal/GuildBankPanel")
  if l_11_0 and l_11_0.SortState then
    l_0_3 = false
  end
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

