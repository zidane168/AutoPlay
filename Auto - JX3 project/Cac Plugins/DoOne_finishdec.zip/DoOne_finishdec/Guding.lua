-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Guding.lua 

local l_0_0 = "Interface\\Moon_Guding\\Guding.ini"
local l_0_1 = {}
l_0_1.bOn = true
l_0_1.bTalk = true
l_0_1.bAutoUse = false
l_0_1.nEatLife = 80
l_0_1.nEatMana = 80
l_0_1.nEatEndFrame = 0
l_0_1.dwSkillID = 2234
l_0_1.nExistTime = 60
l_0_1.dwTemplateID = 2418
l_0_1.nMaxDelay = 500
l_0_1.tCast = {}
l_0_1.tShowList = {}
local l_0_2 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1(l_0_2)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_2(l_0_0, 255)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_2("Guding", 2747, 0, "General", function(l_11_0)
  local l_11_1 = l_11_0:Lookup("", "")
  BoxBoolCheckBox(l_11_0, "CheckBox_bShow", "��ʾ�Լ����Ŷӵ��嶾�ƶ�", Guding, "bOn", nil, Guding.Clear)
  local l_11_2 = BoxShadow
  local l_11_3 = l_11_1
  local l_11_4 = "Shadow_targetColor"
  local l_11_5 = function(l_12_0)
    OpenColorTablePanel(function(l_13_0, l_13_1, l_13_2)
      -- upvalues: l_1_0
      l_1_0:SetColorRGB(l_13_0, l_13_1, l_13_2)
      local l_13_3 = Guding
      do
        local l_13_4 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- WARNING: undefined locals caused missing assignments!
    end)
  end
  local l_11_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_11_7 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_11_8 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_11_8.tRGB = 18.tRGB
  l_11_8.szColor = "white"
  l_11_2(l_11_3, l_11_4, l_11_5, l_11_6, l_11_7, l_11_8)
  l_11_2 = BoxBoolCheckBox
  l_11_3 = l_11_0
  l_11_4 = "CheckBox_bTalk"
  l_11_5 = "ʩչ�������ƶ����󣬺�����ʾ"
  l_11_6 = Guding
  l_11_7 = "bTalk"
  l_11_2 = l_11_2(l_11_3, l_11_4, l_11_5, l_11_6, l_11_7)
  l_11_2, l_11_3 = l_11_2:SetRelPos, l_11_2
  l_11_4 = 0
  l_11_5 = 30
  l_11_2(l_11_3, l_11_4, l_11_5)
  l_11_2 = BoxBoolCheckBox
  l_11_3 = l_11_0
  l_11_4 = "CheckBox_bAutoUse"
  l_11_5 = "��Ѫ������������ʱ���Զ�ʹ�ùƶ�"
  l_11_6 = Guding
  l_11_7 = "bAutoUse"
  l_11_2 = l_11_2(l_11_3, l_11_4, l_11_5, l_11_6, l_11_7)
  l_11_2, l_11_3 = l_11_2:SetRelPos, l_11_2
  l_11_4 = 0
  l_11_5 = 60
  l_11_2(l_11_3, l_11_4, l_11_5)
  l_11_2 = BoxLabel
  l_11_3 = l_11_1
  l_11_4 = "label1"
  l_11_5 = "��Ѫ������"
  l_11_7 = 0
  l_11_8 = 90
  l_11_2(l_11_3, l_11_4, l_11_5, l_11_6)
  l_11_6 = {l_11_7, l_11_8}
  l_11_2 = BoxCSlider
  l_11_3 = l_11_0
  l_11_4 = "Slider_Life"
  l_11_6 = Guding
  l_11_6 = l_11_6.nEatLife
  l_11_2, l_11_5 = l_11_2(l_11_3, l_11_4, l_11_5), {min = 10, max = 100, step = 18, val = l_11_6, x = 82, y = 95}
  l_11_3 = BoxLabel
  l_11_4 = l_11_1
  l_11_5 = "labelLife"
  l_11_6 = Guding
  l_11_6 = l_11_6.nEatLife
  l_11_7 = "%"
  l_11_6 = l_11_6 .. l_11_7
  l_11_8 = 270
  l_11_3, l_11_7 = l_11_3(l_11_4, l_11_5, l_11_6, l_11_7), {l_11_8, 90}
  l_11_4, l_11_5 = l_11_2:OnChanged, l_11_2
  l_11_6 = function(l_13_0)
    -- upvalues: l_11_3
    l_11_3:SetText(l_13_0 .. "%")
    Guding.nEatLife = l_13_0
  end
  l_11_4(l_11_5, l_11_6)
  l_11_4 = BoxLabel
  l_11_5 = l_11_1
  l_11_6 = "label2"
  l_11_7 = "����������"
  l_11_4(l_11_5, l_11_6, l_11_7, l_11_8)
  l_11_8 = {0, 120}
  l_11_4 = BoxCSlider
  l_11_5 = l_11_0
  l_11_6 = "Slider_Mana"
  l_11_8 = Guding
  l_11_8 = l_11_8.nEatMana
  l_11_4, l_11_7 = l_11_4(l_11_5, l_11_6, l_11_7), {min = 10, max = 100, step = 18, val = l_11_8, x = 82, y = 125}
  l_11_5 = BoxLabel
  l_11_6 = l_11_1
  l_11_7 = "labelMana"
  l_11_8 = Guding
  l_11_8 = l_11_8.nEatMana
  l_11_8 = l_11_8 .. "%"
  do
    local l_11_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_11_6(l_11_7, l_11_8)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_6(l_11_7)
  end
   -- WARNING: undefined locals caused missing assignments!
end
)

