-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Option.lua 

Head.switch = function()
end

local l_0_0 = function()
  local l_2_0 = this:GetParent()
  local l_2_1, l_2_2 = l_2_0:GetAbsPos()
  local l_2_3, l_2_4 = l_2_0:GetSize()
  local l_2_5 = function(l_3_0)
    Head.nHead = tonumber(l_3_0)
  end
  local l_2_6 = {}
  l_2_6.nMiniWidth = l_2_3
  l_2_6.x = l_2_1
  l_2_6.y = l_2_2 + l_2_4
  local l_2_7 = {}
  l_2_7.szOption = "ͷ�����ָ߶ȣ�" .. Head.nHeight
  local l_2_8 = {}
  l_2_8.szOption = "�޸�"
  l_2_8.fnAction = function()
    GetUserInputNumber(Head.nHeight, 150, nil, function(l_5_0)
      Head.nHeight = tonumber(l_5_0)
    end, nil, nil)
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_2_9 = {}
  l_2_9.szOption = 30
  l_2_9.bCheck = true
  l_2_9.bChecked = Head.nHead == 30
  l_2_9.bMCheck = true
  l_2_9.UserData = 30
  l_2_9.fnAction = l_2_5
  local l_2_12 = {}
  l_2_12.szOption = 40
  l_2_12.bCheck = true
  l_2_12.bChecked = Head.nHead == 40
  l_2_12.bMCheck = true
  l_2_12.UserData = 40
  l_2_12.fnAction = l_2_5
  local l_2_15 = {}
  l_2_15.szOption = 50
  l_2_15.bCheck = true
  l_2_15.bChecked = Head.nHead == 50
  l_2_15.bMCheck = true
  l_2_15.UserData = 50
  l_2_15.fnAction = l_2_5
  local l_2_18 = {}
  l_2_18.szOption = 60
  l_2_18.bCheck = true
  l_2_18.bChecked = Head.nHead == 60
  l_2_18.bMCheck = true
  l_2_18.UserData = 60
  l_2_18.fnAction = l_2_5
  local l_2_21 = {}
  l_2_21.szOption = 70
  l_2_21.bCheck = true
  l_2_21.bChecked = Head.nHead == 70
  l_2_21.bMCheck = true
  l_2_21.UserData = 70
  l_2_21.fnAction = l_2_5
  local l_2_24 = {}
  l_2_24.szOption = 80
  l_2_24.bCheck = true
  l_2_24.bChecked = Head.nHead == 80
  l_2_24.bMCheck = true
  l_2_24.UserData = 80
  l_2_24.fnAction = l_2_5
  local l_2_27 = {}
  l_2_27.szOption = 90
  l_2_27.bCheck = true
  l_2_27.bChecked = Head.nHead == 90
  l_2_27.bMCheck = true
  l_2_27.UserData = 90
  l_2_27.fnAction = l_2_5
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_2_7 = PopupMenu
   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_7(l_2_8)
  l_2_8 = {l_2_9, l_2_12, l_2_15, l_2_18, l_2_21, l_2_24, l_2_27; szOption = "��ʾ��Χ"}
end

local l_0_1 = function()
  local l_3_0 = this:GetParent()
  local l_3_1, l_3_2 = l_3_0:GetAbsPos()
  local l_3_3, l_3_4 = l_3_0:GetSize()
  local l_3_5 = {}
  l_3_5.nMiniWidth = l_3_3
  l_3_5.x = l_3_1
  l_3_5.y = l_3_2 + l_3_4
  local l_3_6 = {}
  l_3_6.szOption = "��ʾNPCͷ��"
  l_3_6.bCheck = true
  l_3_6.bChecked = Head.bnpc
  l_3_6.fnAction = function()
    Head.bnpc = not Head.bnpc
  end
  local l_3_7 = {}
  l_3_7.szOption = "��ʾNPC�ȼ�"
  l_3_7.bCheck = true
  l_3_7.bChecked = Head.n_level
  l_3_7.fnAction = function()
    Head.n_level = not Head.n_level
  end
  local l_3_8 = {}
  l_3_8.szOption = "��ʾNPC�ƺ�"
  l_3_8.bCheck = true
  l_3_8.bChecked = Head.n_title
  l_3_8.fnAction = function()
    Head.n_title = not Head.n_title
  end
  local l_3_9 = {}
  l_3_9.szOption = "����NPC��־(" .. Head.questSign .. ")"
  l_3_9.bCheck = true
  l_3_9.bChecked = Head.bquest
  l_3_9.fnAction = function()
    Head.bquest = not Head.bquest
  end
  local l_3_10 = {}
  l_3_10.szOption = Head.questSign
  local l_3_11 = {}
  l_3_11.bDevide = true
  local l_3_12 = {}
  l_3_12.szOption = "�޸ı�־"
  l_3_12.fnAction = function()
    GetUserInput("���������־��", function(l_9_0)
      l_9_0 = StringReplaceW(l_9_0, " ", "")
      if l_9_0 == "" then
        msgbox("�����־����Ϊ�ա�")
        return 
      end
      Head.questSign = l_9_0
    end, nil, nil, nil, Head.questSign, 20)
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_3_12 = Head
  l_3_12 = l_3_12.bspecialNpc
  l_3_12 = function()
    Head.bspecialNpc = not Head.bspecialNpc
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_3_6 = PopupMenu
  l_3_7 = l_3_5
  l_3_6(l_3_7)
end

local l_0_2 = function()
  local l_4_0 = this:GetParent()
  local l_4_1, l_4_2 = l_4_0:GetAbsPos()
  local l_4_3, l_4_4 = l_4_0:GetSize()
  local l_4_5 = {}
  l_4_5.nMiniWidth = l_4_3
  l_4_5.x = l_4_1
  l_4_5.y = l_4_2 + l_4_4
  local l_4_6 = {}
  l_4_6.szOption = "��������Ƕ�"
  l_4_6.bCheck = true
  l_4_6.bChecked = Head.tAngleConfig.bOn
  l_4_6.fnAction = function(l_5_0, l_5_1)
    Head.tAngleConfig.bOn = l_5_1
  end
  local l_4_7 = {}
  l_4_7.szOption = "��ʾ�����趨"
  local l_4_8 = {}
  l_4_8.szOption = "��ʾ��/��"
  l_4_8.bMCheck = true
  l_4_8.bChecked = Head.tAngleConfig.nType == 2
  l_4_8.fnAction = function(l_6_0, l_6_1)
    Head.tAngleConfig.nType = 2
  end
  local l_4_11 = {}
  l_4_11.szOption = "��ʾ�Ƕ���"
  l_4_11.bMCheck = true
  l_4_11.bChecked = Head.tAngleConfig.nType == 1
  l_4_11.fnAction = function(l_7_0, l_7_1)
    Head.tAngleConfig.nType = 1
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_4_14 = {}
  l_4_14.szOption = "��ʾ�����ˣ������Լ��ĽǶȣ�"
  l_4_14.bCheck = true
  l_4_14.bChecked = Head.tAngleConfig.bAll
  l_4_14.fnAction = function(l_9_0, l_9_1)
    Head.tAngleConfig.bAll = l_9_1
  end
  local l_4_15 = {}
  l_4_15.szOption = "����ʾĿ�꣨�����Լ��ĽǶȣ�"
  l_4_15.bCheck = true
  l_4_15.bChecked = Head.tAngleConfig.bOnlyTarget
  l_4_15.fnAction = function(l_10_0, l_10_1)
    Head.tAngleConfig.bOnlyTarget = l_10_1
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_4_6 = PopupMenu
  l_4_7 = l_4_5
  l_4_6(l_4_7)
end

Head.Create = function(l_5_0)
  -- upvalues: l_0_0 , l_0_1 , l_0_2
  local l_5_1 = l_5_0:Lookup("", "")
  local l_5_2 = Station.Lookup("Lowest/Head")
  local l_5_3 = BoxCheckBox
  local l_5_4 = l_5_0
  local l_5_5 = "Checkbox_bOn"
  local l_5_6 = {}
  l_5_6.txt = "��������ͷ����ʾ"
  l_5_3 = l_5_3(l_5_4, l_5_5, l_5_6)
  l_5_4, l_5_5 = l_5_3:SetBoolValue, l_5_3
  l_5_6 = Head
  l_5_4(l_5_5, l_5_6, "enable")
  l_5_4, l_5_5 = l_5_3:OnCheck, l_5_3
  l_5_6 = function()
    -- upvalues: l_5_2
    Head.switch()
    if not l_5_2:IsVisible() then
      l_5_2:Show()
    end
  end
  l_5_4(l_5_5, l_5_6)
  l_5_4, l_5_5 = l_5_3:UnCheck, l_5_3
  l_5_6 = function()
    -- upvalues: l_5_2
    Head.switch()
    l_5_2:Hide()
  end
  l_5_4(l_5_5, l_5_6)
  l_5_4 = BoxComboBox
  l_5_5 = l_5_0
  l_5_6 = "Combobox_Set"
  local l_5_7 = {}
  l_5_7.txt = "ͷ����Χ�͸߶�"
  l_5_7.x = 150
  l_5_7.y = 0
  l_5_4 = l_5_4(l_5_5, l_5_6, l_5_7)
  l_5_4, l_5_5 = l_5_4:OnClick, l_5_4
  l_5_6 = l_0_0
  l_5_4(l_5_5, l_5_6)
  l_5_4 = BoxLabel
  l_5_5 = l_5_1
  l_5_6 = "label1"
  l_5_7 = "������ʾ"
  local l_5_8 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, 27)
  l_5_8 = {0, 30}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = {txt = "����Ƕ��趨", x = 300, y = 120, w = 150, h = 25}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5, l_5_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "Ѫ����ʾ"
  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, 27)
  l_5_8 = {0, 150}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "��ʾNpcѪ��"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 180
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "��ʾ���Ѫ��"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 180
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "��ս����"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 180
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "����Ѫ�����"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 210
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "�����������"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 210
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "��ɫѡ��"
  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, 27)
  l_5_8 = {0, 240}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "��ǰĿ���ɫ"
  l_5_8 = Head
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 270
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = function(l_9_0)
    OpenColorTablePanel(function(l_10_0, l_10_1, l_10_2)
      -- upvalues: l_4_0
      l_4_0:SetColorRGB(l_10_0, l_10_1, l_10_2)
      local l_10_3 = Head
      do
        local l_10_4 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- WARNING: undefined locals caused missing assignments!
    end)
  end
  local l_5_9 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_5_10 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_10.tRGB = 18.TColor
  l_5_10.szColor = "white"
  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, l_5_9, l_5_10)
  l_5_8 = {125, 275}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "�ж������߱�ɫ"
  l_5_8 = Head
  l_5_9 = "bdcolor"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 270
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = function(l_10_0)
    OpenColorTablePanel(function(l_11_0, l_11_1, l_11_2)
      -- upvalues: l_5_0
      l_5_0:SetColorRGB(l_11_0, l_11_1, l_11_2)
      local l_11_3 = Head
      do
        local l_11_4 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- WARNING: undefined locals caused missing assignments!
    end)
  end
  l_5_9 = 340
  l_5_10 = 275
  l_5_10 = 18
  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, l_5_9, l_5_10)
  l_5_10, l_5_9, l_5_8 = {tRGB = Head.DColor, szColor = "white"}, {l_5_10, 18}, {l_5_9, l_5_10}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = "�Ѻ������߱�ɫ"
  l_5_8 = Head
  l_5_9 = "bfdcolor"
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = 300
  l_5_4(l_5_5, l_5_6, l_5_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_7 = function(l_11_0)
    OpenColorTablePanel(function(l_12_0, l_12_1, l_12_2)
      -- upvalues: l_6_0
      l_6_0:SetColorRGB(l_12_0, l_12_1, l_12_2)
      local l_12_3 = Head
      do
        local l_12_4 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- WARNING: undefined locals caused missing assignments!
    end)
  end
  l_5_9 = 140
  l_5_10 = 305
  l_5_10 = 18
  l_5_4(l_5_5, l_5_6, l_5_7, l_5_8, l_5_9, l_5_10)
  l_5_10, l_5_9, l_5_8 = {tRGB = Head.fDColor, szColor = "white"}, {l_5_10, 18}, {l_5_9, l_5_10}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_5_4(l_5_5)
end

RegisterMoonButton("Head", 536, "ͷ����ʾ", "General", Head.Create)
Hotkey.AddBinding("MooHead", "�����͹ر�", "ͷ����ʾ", function()
  local l_6_0 = Station.Lookup("Lowest/Head")
  if Head.enable then
    Head.enable = false
    l_6_0:Hide()
    Head.switch()
  else
    Head.enable = true
    l_6_0:Show()
    Head.switch()
  end
end
, nil)
Hotkey.AddBinding("MoonHeadEnemy", "����ʾ�ж�", nil, function()
  if Head.bEnemy then
    Head.bEnemy = false
  else
    Head.bEnemy = true
    Head.bOnlySelf = false
  end
end
, nil)
Hotkey.AddBinding("MoonHeadSelf", "����ʾĿ��", nil, function()
  if Head.bOnlySelf then
    Head.bOnlySelf = false
  else
    Head.bOnlySelf = true
    Head.bEnemy = false
  end
end
, nil)

