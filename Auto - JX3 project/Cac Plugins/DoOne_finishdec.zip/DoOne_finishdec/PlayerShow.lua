-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: PlayerShow.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
local l_0_27 = string.format
local l_0_28 = {}
local l_0_29 = {}
local l_0_30 = {}
local l_0_31 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_32 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_33 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_34 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_35 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_36 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_37 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_38 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_39 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_40 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30 = {"10", "20", "30", "40", "51"}, {l_0_40, "20", "30", "40", "51"}, {l_0_39, l_0_40, "30", "40", "50", "50"}, {l_0_38, l_0_39, l_0_40, "41", "50", "51"}, {l_0_37, l_0_38, l_0_39, l_0_40, "41", "50", "41"}, {l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, "50", "51"}, {l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, "50", "41"}, {l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, "51"}, {l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, "40"}, {l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40}, {l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40}
l_0_28.aAccumulateHide, l_0_29 = l_0_29, {l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40}
l_0_28.DefaultAnchor, l_0_29 = l_0_29, {s = "TOPLEFT", r = "TOPLEFT", x = 5, y = 10}
l_0_28.Anchor, l_0_29 = l_0_29, {s = "TOPLEFT", r = "TOPLEFT", x = 5, y = 10}
PlayerShow = l_0_28
l_0_28 = RegisterCustomData
l_0_29 = "PlayerShow.Anchor"
l_0_28(l_0_29)
l_0_28 = 1
if l_0_28 == 1 and l_0_28 == 1 then
  l_0_28 = 0
  l_0_29 = function()
    -- upvalues: l_0_28
    return l_0_28 == 2 or l_0_28 == 3
  end
end
end
end
l_0_29 = function()
local l_2_0 = 1
if l_2_0 == 1 and l_2_0 == 1 then
l_2_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_2_2 = nil
if function()
  -- upvalues: l_2_0
  return l_2_0 == 2 or l_2_0 == 3
end
.modelView == nil then
PlayerShow.modelView = PlayerModelView.new()
PlayerShow.modelView:init()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
l_0_30 = function()
local l_3_0 = 1
if l_3_0 == 1 and l_3_0 == 1 then
l_3_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_3_2 = nil
if function()
  -- upvalues: l_3_0
  return l_3_0 == 2 or l_3_0 == 3
end
.modelView then
PlayerShow.modelView:UnloadModel()
PlayerShow.modelView:release()
PlayerShow.modelView = nil
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
l_0_31 = PlayerShow
l_0_32 = function()
-- upvalues: l_0_29
this:RegisterEvent("PLAYER_STATE_UPDATE")
this:RegisterEvent("PLAYER_LEVEL_UPDATE")
this:RegisterEvent("SYNC_ROLE_DATA_END")
this:RegisterEvent("PLAYER_DISPLAY_DATA_UPDATE")
this:RegisterEvent("UI_SCALED")
this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
this:RegisterEvent("CURRENT_PLAYER_FORCE_CHANGED")
this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
this:RegisterEvent("PARTY_DISBAND")
this:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
this:RegisterEvent("PARTY_SET_FORMATION_LEADER")
this:RegisterEvent("FIGHT_HINT")
this:RegisterEvent("UI_UPDATE_ACCUMULATE")
this:RegisterEvent("SKILL_MOUNT_KUNG_FU")
this:RegisterEvent("SKILL_UNMOUNT_KUNG_FU")
this:RegisterEvent("SET_SHOW_VALUE_BY_PERCENTAGE")
this:RegisterEvent("SET_SHOW_PLAYER_STATE_VALUE")
this:RegisterEvent("PARTY_SET_MARK")
this:RegisterEvent("CUSTOM_DATA_LOADED")
this:RegisterEvent("PARTY_CAMP_CHANGE")
this:RegisterEvent("CHANGE_CAMP")
this:RegisterEvent("PARTY_DELETE_MEMBER")
this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
this:RegisterEvent("UI_ON_DAMAGE_EVENT")
this:RegisterEvent("CHANGE_CAMP_FLAG")
l_0_29()
PlayerShow.Update(this)
PlayerShow.UpdateAnchor(this)
UpdateCustomModeWindow(this, g_tStrings.PLAYER_HEAD, nil, nil, true)
end
l_0_31.OnFrameCreate = l_0_32
l_0_31 = PlayerShow
l_0_32 = function()
-- upvalues: l_0_30
l_0_30()
end
l_0_31.OnFrameDestroy = l_0_32
l_0_31 = PlayerShow
l_0_32 = function(l_6_0)
-- upvalues: l_0_1
local l_6_1 = l_0_1()
if not l_6_1 then
return 
end
PlayerShow.UpdateLFData(l_6_0)
PlayerShow.UpdateHFData(l_6_0)
PlayerShow.UpdatePlayerMark(l_6_0)
PlayerShow.OnFightFlagUpdate(l_6_0)
PlayerShow.UpdatePlayerStateValueShow(l_6_0)
PlayerShow.OnMountKF(l_6_0)
end
l_0_31.Update = l_0_32
l_0_31 = PlayerShow
l_0_32 = function(l_7_0)
-- upvalues: l_0_1 , l_0_10 , l_0_14 , l_0_17 , l_0_22 , l_0_23
local l_7_1 = l_0_1()
if not l_7_1 then
return 
end
local l_7_2 = l_0_10()
local l_7_3 = l_7_0:Lookup("", "")
local l_7_4 = l_7_1.IsInParty()
local l_7_5 = l_7_3:Lookup("Text_Player")
l_7_5:SetText(l_7_1.szName)
local l_7_6, l_7_7, l_7_8 = l_0_14(l_7_1.dwID, l_7_1.dwID)
l_7_5:SetFontColor(l_7_6, l_7_7, l_7_8)
l_7_3:Lookup("Text_Level"):SetText(l_7_1.nLevel)
local l_7_9, l_7_10 = l_0_17(l_7_1.dwForceID)
l_7_3:Lookup("Image_Force"):FromUITex(l_7_9, l_7_10)
if PrettyShow.Options.ForceHigh == true then
l_7_3:Lookup("Image_Force"):FromUITex(l_7_9, l_7_10)
else
local l_7_11 = l_7_1.GetKungfuMount()
if l_7_11 then
  local l_7_12 = l_7_11.dwSkillID
  local l_7_13 = Table_GetSkillIconID(l_7_12, 1)
  l_7_3:Lookup("Image_Force"):FromIconID(l_7_13)
end
else
l_7_3:Lookup("Image_Force"):FromUITex(l_7_9, l_7_10)
end
local l_7_14 = l_7_3:Lookup("Image_Flag")
if l_7_4 and l_7_1.dwID == l_7_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) then
l_7_14:Show()
else
l_7_14:Hide()
end
local l_7_15 = l_7_3:Lookup("Image_Boss")
if l_7_4 and l_7_1.dwID == l_7_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE) then
l_7_15:Show()
else
l_7_15:Hide()
end
local l_7_16 = l_7_3:Lookup("Image_Mark")
if l_7_4 and l_7_1.dwID == l_7_2.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
l_7_16:Show()
else
l_7_16:Hide()
end
local l_7_17 = false
if l_7_4 then
local l_7_18 = l_7_2.GetMemberGroupIndex(l_7_1.dwID)
end
if l_7_2.GetGroupInfo(l_7_18).dwFormationLeader == l_7_1.dwID then
l_7_17 = true
end
local l_7_19 = l_7_3:Lookup("Image_Center")
if l_7_17 then
l_7_19:Show()
else
l_7_19:Hide()
end
local l_7_20 = l_0_22(l_7_1.nCamp, l_7_1.bCampFlag)
local l_7_21 = l_7_3:Lookup("Image_Camp")
l_0_23(l_7_21, l_7_20)
end
l_0_31.UpdateLFData = l_0_32
l_0_31 = function(l_8_0, l_8_1)
-- upvalues: l_0_27
local l_8_2 = l_0_27("%d", l_8_1)
local l_8_3 = l_0_27("%d", l_8_0)
local l_8_4 = l_0_27("%.1f%%", l_8_0 * 100 / l_8_1)
if PrettyShow.Options.nActHealth == 2 then
if l_8_1 > 100000 then
  l_8_2 = l_0_27("%.1f��", l_8_1 / 10000)
end
if l_8_0 > 100000 then
  l_8_3 = l_0_27("%.1f��", l_8_0 / 10000)
end
else
if PrettyShow.Options.nActHealth == 3 then
  if l_8_1 > 100000 then
    l_8_2 = l_0_27("%.1fW", l_8_1 / 10000)
  end
end
end
if l_8_0 > 100000 then
l_8_3 = l_0_27("%.1fW", l_8_0 / 10000)
end
if PrettyShow.Options.nHealthMode == 1 then
return l_8_3
end
if PrettyShow.Options.nHealthMode == 2 then
return l_8_3 .. "(" .. l_8_4 .. ")"
end
if PrettyShow.Options.nHealthMode == 3 then
return l_8_3, l_8_4
end
if PrettyShow.Options.nHealthMode == 4 then
return l_8_3 .. "/" .. l_8_2
end
if PrettyShow.Options.nHealthMode == 5 then
local l_8_8 = l_8_3
local l_8_9 = "/"
local l_8_10 = l_8_2
l_8_8 = l_8_8 .. l_8_9 .. l_8_10 .. "(" .. l_8_4 .. ")"
return l_8_8
end
if PrettyShow.Options.nHealthMode == 6 then
return l_8_3 .. "/" .. l_8_2, l_8_4
end
if PrettyShow.Options.nHealthMode == 7 then
if l_8_0 - l_8_1 < 0 then
  local l_8_5 = l_0_27
  local l_8_6 = "%d"
  local l_8_7 = l_8_0 - l_8_1
  return l_8_5(l_8_6, l_8_7)
end
else
return ""
end
end
l_0_32 = function(l_9_0)
if l_9_0 <= 0 or l_9_0 >= 1 then
return 0.09, 0.7, 0.03
end
if l_9_0 >= 0.5 then
return (1 - l_9_0) * 2, 0.7, 0
else
return 1, l_9_0 * 2, 0
end
end
l_0_33 = PlayerShow
l_0_34 = function(l_10_0)
-- upvalues: l_0_1 , l_0_31 , l_0_32
local l_10_1 = l_0_1()
if not l_10_1 then
return 
end
local l_10_2 = PrettyShow.Options.nMode
local l_10_3 = l_10_0:Lookup("", "")
local l_10_4 = l_10_3:Lookup("Text_Health")
local l_10_5 = l_10_3:Lookup("Image_Health")
local l_10_6 = l_10_3:Lookup("Text_HealthP")
local l_10_7 = l_10_3:Lookup("Shadow_Health")
local l_10_8 = l_10_3:Lookup("Shadow_Mana")
if l_10_1.nMaxLife > 0 then
local l_10_9 = l_10_1.nCurrentLife / l_10_1.nMaxLife
local l_10_10 = l_10_1.nMaxLife
local l_10_11 = l_10_1.nCurrentLife
local l_10_12, l_10_13 = l_0_31(l_10_11, l_10_10)
l_10_4:SetText(l_10_12)
if l_10_2 == 1 then
  l_10_5:SetPercentage(l_10_9)
else
  local l_10_14, l_10_15 = l_10_3:Lookup("Shadow_Health_Ref"):GetSize()
  l_10_7:SetSize(l_10_14 * l_10_9, l_10_15)
  if l_10_2 == 3 then
    if not PrettyShow.Options.tForceColor[l_10_1.dwForceID] then
      local l_10_16, l_10_17, l_10_18, l_10_19 = {}
      l_10_17 = 0
      l_10_18 = 255
      l_10_19 = 0
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_10_3:Lookup("Shadow_Health"):SetColorRGB(l_10_16[1], l_10_16[2], l_10_16[3])
  end
elseif l_10_2 == 4 then
  local l_10_20, l_10_21, l_10_22 = l_0_32(l_10_9)
  l_10_7:SetColorRGB(l_10_20 * 255, l_10_21 * 255, l_10_22 * 255)
end
if l_10_13 then
  l_10_6:SetText(l_10_13)
else
  l_10_6:SetText("")
end
elseif l_10_2 == 1 then
l_10_5:SetPercentage(0)
else
l_10_7:SetSize(0, 0)
end
l_10_4:SetText("")
l_10_6:SetText("")
local l_10_23 = l_10_3:Lookup("Image_Mana")
local l_10_24 = l_10_3:Lookup("Text_Mana")
local l_10_25 = l_10_3:Lookup("Text_ManaP")
if l_10_1.nMaxMana > 0 and l_10_1.nMaxMana ~= 1 then
local l_10_26 = l_10_1.nCurrentMana / l_10_1.nMaxMana
local l_10_27, l_10_28 = l_0_31(l_10_1.nCurrentMana, l_10_1.nMaxMana)
l_10_24:SetText(l_10_27)
if l_10_2 == 1 then
  l_10_23:SetPercentage(l_10_26)
else
  local l_10_29, l_10_30 = l_10_3:Lookup("Shadow_Mana_Ref"):GetSize()
  l_10_8:SetSize(l_10_29 * l_10_26, l_10_30)
end
if l_10_28 then
  l_10_25:SetText(l_10_28)
else
  l_10_25:SetText("")
end
elseif l_10_2 == 1 then
l_10_23:SetPercentage(0)
else
l_10_8:SetSize(0, 0)
end
l_10_24:SetText("")
l_10_25:SetText("")
local l_10_31 = l_0_1()
local l_10_32 = l_10_3:Lookup("Handle_CangJian")
local l_10_33 = l_10_3:GetRoot():Lookup("CheckBox_SwitchSword")
if l_10_31 and l_10_31.bCanUseBigSword then
l_10_32:Show()
l_10_33:Show()
PlayerShow.UpdateCangjianRage(l_10_32)
PlayerShow.UpdateCangjianSwitchSword(l_10_33, l_10_31.bBigSwordSelected)
else
l_10_32:Hide()
l_10_33:Hide()
end
PlayerShow.OnUpdateTangmenEnergy(l_10_0)
end
l_0_33.UpdateHFData = l_0_34
l_0_33 = PlayerShow
l_0_34 = function(l_11_0, l_11_1)
if not l_11_0 then
return 
end
if l_11_1 then
l_11_0:Check(true)
else
l_11_0:Check(false)
end
end
l_0_33.UpdateCangjianSwitchSword = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
Player.OnCheckBoxCheck()
end
l_0_33.OnCheckBoxCheck = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
Player.OnCheckBoxUncheck()
end
l_0_33.OnCheckBoxUncheck = l_0_34
l_0_33 = PlayerShow
l_0_34 = function(l_14_0)
-- upvalues: l_0_1
if not l_14_0 then
return 
end
local l_14_1 = l_0_1()
local l_14_2 = l_14_0:Lookup("Image_Short")
local l_14_3 = l_14_0:Lookup("Text_Short")
local l_14_4 = l_14_0:Lookup("Animate_Short")
local l_14_5 = l_14_0:Lookup("Image_Long")
local l_14_6 = l_14_0:Lookup("Text_Long")
local l_14_7 = (l_14_0:Lookup("Animate_Long"))
local l_14_8 = nil
if l_14_1.nMaxRage > 100 then
l_14_2:Hide()
l_14_3:Hide()
l_14_4:Hide()
l_14_5:Show()
l_14_6:Show()
l_14_7:Show()
l_14_8 = "Long"
else
l_14_2:Show()
l_14_3:Show()
l_14_4:Show()
l_14_5:Hide()
l_14_6:Hide()
l_14_7:Hide()
l_14_8 = "Short"
end
if l_14_1.nMaxRage > 0 then
local l_14_9 = l_14_1.nCurrentRage / l_14_1.nMaxRage
l_14_0:Lookup("Image_" .. l_14_8):SetPercentage(l_14_9)
if IsShowStateValueByPercentage() then
  l_14_0:Lookup("Text_" .. l_14_8):SetText(string.format("%d%%", 100 * l_14_9))
else
  l_14_0:Lookup("Text_" .. l_14_8):SetText(l_14_1.nCurrentRage .. "/" .. l_14_1.nMaxRage)
end
else
l_14_0:Lookup("Image_" .. l_14_8):SetPercentage(0)
l_14_0:Lookup("Text_" .. l_14_8):SetText("")
end
end
l_0_33.UpdateCangjianRage = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
end
l_0_33.OnFrameDrag = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
end
l_0_33.OnFrameDragSetPosEnd = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
this:CorrectPos()
PlayerShow.Anchor = GetFrameAnchor(this)
end
l_0_33.OnFrameDragEnd = l_0_34
l_0_33 = PlayerShow
l_0_34 = function(l_18_0)
l_18_0:SetPoint(PlayerShow.Anchor.s, 0, 0, PlayerShow.Anchor.r, PlayerShow.Anchor.x, PlayerShow.Anchor.y)
l_18_0:CorrectPos()
end
l_0_33.UpdateAnchor = l_0_34
l_0_33 = PlayerShow
l_0_34 = function(l_19_0)
-- upvalues: l_0_1 , l_0_10
return 
local l_19_1 = l_0_1()
local l_19_2 = (l_19_0:Lookup("", "Image_NPCMark"))
local l_19_3 = nil
if l_19_1.IsInParty() then
local l_19_4 = l_0_10().GetTeamMark()
end
if l_19_4 and l_19_4[l_19_1.dwID] then
local l_19_5 = l_19_4[l_19_1.dwID]
local l_19_6 = assert
l_19_6(l_19_5 > 0 and l_19_5 <= #PARTY_MARK_ICON_FRAME_LIST)
l_19_6 = PARTY_MARK_ICON_FRAME_LIST
l_19_3 = l_19_6[l_19_5]
end
if l_19_3 then
l_19_2:FromUITex(PARTY_MARK_ICON_PATH, l_19_3)
l_19_2:Show()
else
l_19_2:Hide()
end
end
l_0_33.UpdatePlayerMark = l_0_34
l_0_33 = PlayerShow
l_0_34 = function()
end
l_0_33.OnFrameBreathe = l_0_34
l_0_33 = function()
-- upvalues: l_0_1
local l_21_0 = 1
if l_21_0 == 1 and l_21_0 == 1 then
l_21_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_21_2 = nil
if not function()
  -- upvalues: l_21_0
  return l_21_0 == 2 or l_21_0 == 3
end
() then
return 
end
local l_21_3 = nil
local l_21_4 = nil
local l_21_5 = Station.Lookup("Normal/PlayerShow"):Lookup("Show_Role")
PlayerShow.modelView:SetCamera(SelfPortraitCameraInfo[l_21_3.nRoleType])
l_21_5:SetScene(PlayerShow.modelView.m_scene)
PlayerShow.modelView:UnloadModel()
local l_21_6 = nil
do
local l_21_7 = PlayerShow.modelView
l_21_7.m_aRoleAnimation = {Idle = 41}
l_21_7 = PlayerShow
l_21_7 = l_21_7.modelView
l_21_7(l_21_7, l_21_3.dwID, false)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_21_7(l_21_7)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_21_7(l_21_7, "Idle", "loop")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
l_0_34 = PlayerShow
l_0_35 = function(l_22_0)
-- upvalues: l_0_1 , l_0_33 , l_0_10
 -- DECOMPILER ERROR: unhandled construct in 'if'

if l_22_0 == "PLAYER_STATE_UPDATE" and arg0 == l_0_1().dwID then
PlayerShow.UpdateHFData(this)
end
do return end
if l_22_0 == "PLAYER_DISPLAY_DATA_UPDATE" then
if arg0 ~= l_0_1().dwID then
  return 
end
l_0_33()
 -- DECOMPILER ERROR: unhandled construct in 'if'

elseif (l_22_0 == "PLAYER_LEVEL_UPDATE" or l_22_0 == "CHANGE_CAMP_FLAG") and arg0 == l_0_1().dwID then
PlayerShow.UpdateLFData(this)
end
do return end
if l_22_0 == "SYNC_ROLE_DATA_END" then
PlayerShow.Update(this)
l_0_33()
elseif l_22_0 == "CURRENT_PLAYER_FORCE_CHANGED" then
PlayerShow.Update(this)
elseif l_22_0 == "TEAM_AUTHORITY_CHANGED" then
local l_22_1 = l_0_1()
if arg2 == l_22_1.dwID or arg3 == l_22_1.dwID then
  PlayerShow.UpdateLFData(this)
end
elseif l_22_0 == "PARTY_SET_FORMATION_LEADER" then
PlayerShow.UpdateLFData(this)
elseif l_22_0 == "PARTY_SYNC_MEMBER_DATA" then
PlayerShow.UpdateLFData(this)
elseif l_22_0 == "PARTY_DISBAND" then
PlayerShow.UpdateLFData(this)
PlayerShow.UpdatePlayerMark(this)
elseif l_22_0 == "FIGHT_HINT" then
PlayerShow.OnFightFlagUpdate(this)
elseif l_22_0 == "UI_UPDATE_ACCUMULATE" then
PlayerShow.OnUpdateAccumulateValue(this)
elseif l_22_0 == "SKILL_MOUNT_KUNG_FU" then
PlayerShow.UpdateLFData(this)
PlayerShow.OnMountKF(this)
elseif l_22_0 == "SKILL_UNMOUNT_KUNG_FU" then
PlayerShow.OnMountKF(this)
elseif l_22_0 == "SET_SHOW_VALUE_BY_PERCENTAGE" then
PlayerShow.UpdatePlayerStateValueShow(this)
PlayerShow.UpdateHFData(this)
elseif l_22_0 == "SET_SHOW_PLAYER_STATE_VALUE" then
PlayerShow.UpdatePlayerStateValueShow(this)
PlayerShow.UpdateHFData(this)
elseif l_22_0 == "PARTY_SET_MARK" then
PlayerShow.UpdatePlayerMark(this)
elseif l_22_0 == "UI_SCALED" then
PlayerShow.UpdateAnchor(this)
elseif l_22_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_22_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
UpdateCustomModeWindow(this, nil, nil, nil, true)
elseif l_22_0 == "CUSTOM_DATA_LOADED" then
PlayerShow.UpdateAnchor(this)
elseif l_22_0 == "PARTY_CAMP_CHANGE" then
PlayerShow.UpdateLFData(this)
local l_22_2 = l_0_10().nCamp
if g_tStrings.STR_TEAM_CAMP_MSG[l_22_2] then
  OutputMessage("MSG_SYS", g_tStrings.STR_TEAM_CAMP_MSG[l_22_2])
end
elseif l_22_0 == "PARTY_DELETE_MEMBER" then
local l_22_3 = l_0_1()
if arg1 == l_22_3.dwID then
  PlayerShow.UpdateLFData(this)
  PlayerShow.UpdatePlayerMark(this)
end
elseif l_22_0 == "CHANGE_CAMP" then
local l_22_4 = l_0_1()
if l_22_4 and arg0 == l_22_4.dwID then
  PlayerShow.UpdateLFData(this)
end
elseif l_22_0 == "UI_ON_DAMAGE_EVENT" then
local l_22_5 = l_0_1()
if l_22_5.dwID == arg0 then
  PlayerShow.OnDamageEvent(this, arg1, arg2)
end
elseif l_22_0 == "SWITCH_BIGSWORD" then
local l_22_6 = l_0_1()
local l_22_7 = this:Lookup("CheckBox_SwitchSword")
end
if l_22_6 and l_22_6.bCanUseBigSword then
local l_22_8 = Player.UpdateCangjianSwitchSword
local l_22_9 = l_22_7
l_22_8(l_22_9, arg0 ~= 0)
end
end
l_0_34.OnEvent = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_23_0, l_23_1, l_23_2)
end
l_0_34.OnDamageEvent = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_24_0)
-- upvalues: l_0_1
local l_24_1 = l_0_1()
local l_24_2 = l_24_1.GetKungfuMount()
local l_24_3 = ""
local l_24_4 = ""
if l_24_2 then
if l_24_2.dwMountType == 3 then
  l_24_3 = "Handle_ChunYang"
  l_24_4 = "CY_"
end
elseif l_24_2.dwMountType == 5 then
l_24_3 = "Handle_ShaoLin"
l_24_4 = "SL_"
elseif l_24_2.dwMountType == 10 then
l_24_3 = "Handle_TangMen"
l_24_4 = "TM_"
end
local l_24_5 = l_24_0:Lookup("", "")
if l_24_3 == "" then
l_24_5:Lookup("Handle_ChunYang"):Hide()
l_24_5:Lookup("Handle_ShaoLin"):Hide()
l_24_5:Lookup("Handle_TangMen"):Hide()
do break end
end
local l_24_6 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

for l_24_10,l_24_11 in "Handle_ChunYang"("Handle_ShaoLin") do
if l_24_3 == l_24_11 then
  l_24_5:Lookup(l_24_11):Show()
else
  l_24_5:Lookup(l_24_11):Hide()
end
end
l_24_6 = this
l_24_6.szShow = l_24_3
l_24_6 = this
l_24_6.szShowSub = l_24_4
if l_24_3 == "Handle_ChunYang" or l_24_3 == "Handle_ShaoLin" then
l_24_6 = PlayerShow
l_24_6 = l_24_6.OnUpdateAccumulateValue
l_24_6(this)
elseif l_24_3 == "Handle_TangMen" then
l_24_6 = PlayerShow
l_24_6 = l_24_6.OnUpdateTangmenEnergy
l_24_6(this)
end
end
l_0_34.OnMountKF = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_25_0)
-- upvalues: l_0_1
if not l_25_0.szShow or l_25_0.szShow ~= "Handle_TangMen" then
return 
end
local l_25_1 = l_25_0:Lookup("", "Handle_TangMen")
local l_25_2 = l_25_1:Lookup("Text_Number")
local l_25_3 = l_25_1:Lookup("Image_Strip")
local l_25_4 = l_0_1()
if l_25_4.nMaxEnergy > 0 then
local l_25_5 = l_25_4.nCurrentEnergy / l_25_4.nMaxEnergy
l_25_3:SetPercentage(l_25_5)
if IsShowStateValueByPercentage() then
  l_25_2:SetText(string.format("%d%%", 100 * l_25_5))
else
  l_25_2:SetText(l_25_4.nCurrentEnergy .. "/" .. l_25_4.nMaxEnergy)
end
else
l_25_3:SetPercentage(0)
l_25_2:SetText("")
end
end
l_0_34.OnUpdateTangmenEnergy = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_26_0)
-- upvalues: l_0_1
if not l_26_0.szShow or l_26_0.szShow == "" then
return 
end
local l_26_1 = l_26_0:Lookup("", l_26_0.szShow)
if l_26_1 then
if l_0_1().nAccumulateValue >= 0 or l_26_0.szShow == "Handle_ShaoLin" then
  if 0 > 3 then
    local l_26_2, l_26_3, l_26_13 = 3
  end
  local l_26_4 = nil
  for l_26_8 = 1, l_26_4 do
    local l_26_5 = l_26_0.szShowSub
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_26_1:Lookup(l_26_5 .. R7_PC32):Show()
  end
  for l_26_12 = l_26_4 + 1, 3 do
    local l_26_9 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_26_1:Lookup(l_26_9 .. R7_PC32):Hide()
  end
end
do break end
end
 -- DECOMPILER ERROR: Confused about usage of registers!

if l_26_4 > 10 then
local l_26_14 = 10 + 1
end
local l_26_15 = l_26_0.szShowSub
local l_26_16 = Player.aAccumulateShow[l_26_14]
local l_26_17 = Player.aAccumulateHide[l_26_14]
for l_26_21,l_26_22 in pairs(l_26_16) do
l_26_1:Lookup(l_26_15 .. l_26_22):Show()
end
for l_26_26,l_26_27 in pairs(l_26_17) do
l_26_1:Lookup(l_26_15 .. l_26_27):Hide()
end
end
l_0_34.OnUpdateAccumulateValue = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_27_0)
-- upvalues: l_0_1
local l_27_1 = l_27_0:Lookup("", "Image_Fight")
if l_0_1().bFightState then
l_27_1:Show()
else
l_27_1:Hide()
end
end
l_0_34.OnFightFlagUpdate = l_0_35
l_0_34 = PlayerShow
l_0_35 = function(l_28_0)
end
l_0_34.UpdatePlayerStateValueShow = l_0_35
l_0_34 = PlayerShow
l_0_35 = function()
-- upvalues: l_0_1
if UserSelect.IsSelectCharacter() then
UserSelect.SatisfySelectCharacter(TARGET.PLAYER, l_0_1().dwID)
end
end
l_0_34.OnItemMouseEnter = l_0_35
l_0_34 = PlayerShow
l_0_35 = function()
HideTip()
if UserSelect.IsSelectCharacter() then
UserSelect.SatisfySelectCharacter(TARGET.NO_TARGET, 0, true)
end
end
l_0_34.OnItemMouseLeave = l_0_35
l_0_34 = PlayerShow
l_0_35 = function()
-- upvalues: l_0_1
local l_31_0, l_31_1 = Station.GetMessagePos()
local l_31_2, l_31_3 = this:GetAbsPos()
if l_31_2 + 20 < l_31_0 and l_31_3 + 100 < l_31_1 then
local l_31_4 = l_0_1()
local l_31_5 = l_31_4.GetKungfuMount()
if l_31_5 and l_31_5.dwMountType == 10 then
  if IsCanWeaponBagOpen() then
    if IsWeaponBagOpen() then
      CloseWeaponBag()
    end
  else
    OpenWeaponBag(nil, false)
  end
else
  OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.STR_EQUIP_TM_QIANJIXIA)
end
else
Player.OnItemLButtonDown()
end
end
l_0_34.OnLButtonDown = l_0_35
l_0_34 = PlayerShow
l_0_35 = function()
local l_32_0, l_32_1 = Station.GetMessagePos()
local l_32_2, l_32_3 = this:GetAbsPos()
if l_32_3 + 100 < l_32_1 then
return 
end
local l_32_4 = {}
InsertPlayerMenu(l_32_4)
if l_32_4 and #l_32_4 > 0 then
PopupMenu(l_32_4)
end
end
l_0_34.OnRButtonDown = l_0_35
l_0_34 = function()
-- upvalues: l_0_1
if PrettyShow.Options.PlayerEnable ~= true then
return 
end
local l_33_0 = Station.Lookup("Normal/PlayerShow")
if l_33_0 then
local l_33_1 = l_33_0:Lookup("", "")
if PrettyShow.Options.nMode == 1 then
  l_33_1:Lookup("Shadow_Health"):Hide()
  l_33_1:Lookup("Shadow_Mana"):Hide()
  l_33_1:Lookup("Image_Health"):Show()
  l_33_1:Lookup("Image_Mana"):Show()
  local l_33_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nHealthBar]
  if l_33_2 then
    l_33_1:Lookup("Image_Health"):FromUITex(l_33_2[1], l_33_2[2])
  end
  local l_33_3 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nManaBar]
  if l_33_3 then
    l_33_1:Lookup("Image_Mana"):FromUITex(l_33_3[1], l_33_3[2])
  end
else
  if PrettyShow.Options.nMode == 2 then
    l_33_1:Lookup("Image_Health"):Hide()
    l_33_1:Lookup("Image_Mana"):Hide()
    local l_33_4 = PrettyShow.Options.tHealthColor[1]
    l_33_1:Lookup("Shadow_Health"):SetColorRGB(l_33_4[1], l_33_4[2], l_33_4[3])
    local l_33_5 = PrettyShow.Options.tHealthColor[2]
    l_33_1:Lookup("Shadow_Mana"):SetColorRGB(l_33_5[1], l_33_5[2], l_33_5[3])
    l_33_1:Lookup("Shadow_Health"):Show()
    l_33_1:Lookup("Shadow_Mana"):Show()
  end
else
  if PrettyShow.Options.nMode == 3 then
    l_33_1:Lookup("Shadow_Health"):Show()
    l_33_1:Lookup("Shadow_Mana"):Show()
    l_33_1:Lookup("Image_Health"):Hide()
    l_33_1:Lookup("Image_Mana"):Hide()
    local l_33_6 = l_0_1()
    if l_33_6 then
      if not PrettyShow.Options.tForceColor[l_33_6.dwForceID] then
        local l_33_7, l_33_8, l_33_9, l_33_10 = {}
        l_33_8 = 0
        l_33_9 = 255
        l_33_10 = 0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_33_1:Lookup("Shadow_Health"):SetColorRGB(l_33_7[1], l_33_7[2], l_33_7[3])
    end
    local l_33_11 = PrettyShow.Options.tHealthColor[2]
    l_33_1:Lookup("Shadow_Mana"):SetColorRGB(l_33_11[1], l_33_11[2], l_33_11[3])
  end
else
  l_33_1:Lookup("Shadow_Health"):Show()
  l_33_1:Lookup("Shadow_Mana"):Show()
  l_33_1:Lookup("Image_Health"):Hide()
  l_33_1:Lookup("Image_Mana"):Hide()
  local l_33_12 = PrettyShow.Options.tHealthColor[2]
  l_33_1:Lookup("Shadow_Mana"):SetColorRGB(l_33_12[1], l_33_12[2], l_33_12[3])
end
local l_33_13 = l_33_0:Lookup("", "")
local l_33_14 = l_33_13:Lookup("Text_Health")
local l_33_15 = l_33_13:Lookup("Text_Mana")
local l_33_16 = l_33_13:Lookup("Text_HealthP")
local l_33_17 = l_33_13:Lookup("Text_ManaP")
if PrettyShow.Options.nHealthMode == 1 then
  l_33_14:SetHAlign(1)
  l_33_15:SetHAlign(1)
else
  if PrettyShow.Options.nHealthMode == 2 then
    l_33_14:SetHAlign(1)
    l_33_15:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 3 then
    l_33_14:SetHAlign(0)
    l_33_15:SetHAlign(0)
  end
else
  if PrettyShow.Options.nHealthMode == 4 then
    l_33_14:SetHAlign(1)
    l_33_15:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 5 then
    l_33_14:SetHAlign(1)
    l_33_15:SetHAlign(1)
  end
else
  if PrettyShow.Options.nHealthMode == 6 then
    l_33_14:SetHAlign(0)
    l_33_15:SetHAlign(0)
  end
else
  if PrettyShow.Options.nHealthMode == 7 then
    l_33_14:SetHAlign(2)
    l_33_15:SetHAlign(2)
  end
end
local l_33_18 = PrettyShow.Options.tHealth[1]
local l_33_19 = PrettyShow.Options.tHealth[2]
l_33_14:SetFontScheme(l_33_18)
l_33_14:SetFontColor(l_33_19[1], l_33_19[2], l_33_19[2])
l_33_16:SetFontScheme(l_33_18)
l_33_16:SetFontColor(l_33_19[1], l_33_19[2], l_33_19[2])
l_33_15:SetFontScheme(l_33_18)
l_33_15:SetFontColor(l_33_19[1], l_33_19[2], l_33_19[2])
l_33_17:SetFontScheme(l_33_18)
l_33_17:SetFontColor(l_33_19[1], l_33_19[2], l_33_19[2])
PlayerShow.UpdateHFData(l_33_0)
end
end
l_0_35 = function()
if PrettyShow.Options.PlayerEnable ~= true then
return 
end
local l_34_0 = Station.Lookup("Normal/PlayerShow")
if l_34_0 then
local l_34_1 = l_34_0:Lookup("", "")
local l_34_2 = l_34_1:Lookup("Image_BgMidC")
end
if l_34_2 then
l_34_2:SetAlpha(PrettyShow.Options.Bg)
end
end
l_0_36 = function()
local l_35_0 = Station.Lookup("Normal/PlayerShow")
if l_35_0 then
local l_35_1 = l_35_0:Lookup("", "")
local l_35_2 = l_35_1:Lookup("Image_Frame")
if PrettyShow.Options.bShowFrame then
  l_35_2:Show()
end
else
l_35_2:Hide()
end
end
l_0_37 = RegisterEvent
l_0_38 = "BGFRAME_RESET"
l_0_39 = l_0_36
l_0_37(l_0_38, l_0_39)
l_0_37 = function()
-- upvalues: l_0_34 , l_0_35 , l_0_33 , l_0_36
if PrettyShow.Options.PlayerEnable == true then
Player_GetFrame():Hide()
Wnd.CloseWindow("PlayerShow")
local l_36_0 = Wnd.OpenWindow("Interface\\PrettyShow\\PlayerShow.ini", "PlayerShow")
l_0_34()
l_0_35()
l_0_33()
l_0_36()
l_36_0:Scale(PrettyShow.Options.nScale_Player, PrettyShow.Options.nScale_Player)
PlayerShow.UpdateAnchor(l_36_0)
else
Wnd.CloseWindow("PlayerShow")
Player_GetFrame():Show()
end
end
l_0_38 = RegisterEvent
l_0_39 = "CUSTOM_DATA_LOADED"
l_0_40 = l_0_37
l_0_38(l_0_39, l_0_40)
l_0_38 = RegisterEvent
l_0_39 = "PLAYER_ENABLE"
l_0_40 = l_0_37
l_0_38(l_0_39, l_0_40)
l_0_38 = function()
if PrettyShow.Options.PlayerEnable ~= true then
return 
end
local l_37_0 = Station.Lookup("Normal/PlayerShow")
if l_37_0 then
PlayerShow.UpdateLFData(l_37_0)
end
end
l_0_39 = function()
end
UpdatePlayerImage = l_0_39
l_0_39 = SelfPortraitCameraInfo
l_0_39[6], l_0_40 = l_0_40, {-18, 115, -78, -1, 116, 0, 30, 30}
l_0_39 = SelfPortraitCameraInfo
l_0_39[2], l_0_40 = l_0_40, {-34, 159, -52, 0, 165, 4, 31, 31}
l_0_39 = function()
-- upvalues: l_0_37
if arg0 ~= "Player" then
return 
end
l_0_37()
end
l_0_40 = RegisterEvent
l_0_40("FRAME_SIZE_RESET", l_0_39)
l_0_40 = RegisterEvent
l_0_40("HEAD_ALPHA_RESET", l_0_35)
l_0_40 = RegisterEvent
l_0_40("HEALTH_MODE_RESET", l_0_34)

