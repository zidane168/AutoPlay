-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DoodadEx.lua 

if not DoodadEx then
  DoodadEx = {}
end
DoodadEx.nSteperCount = -1
DoodadEx.frameContant = nil
DoodadEx.handleTotal = nil
DoodadEx.SynAnyDoodadList = {}
yyLifeBar.bShowDoodad = true
RegisterCustomData("yyLifeBar.bShowDoodad")
DoodadEx.bOn = false
RegisterCustomData("DoodadEx.bOn")
DoodadEx.bNeedCtrlKey = true
RegisterCustomData("DoodadEx.bNeedCtrlKey")
DoodadEx.bNeedAltKey = false
RegisterCustomData("DoodadEx.bNeedAltKey")
DoodadEx.bNeedShiftKey = false
RegisterCustomData("DoodadEx.bNeedShiftKey")
DoodadEx.bDoNotWhenFight = false
RegisterCustomData("DoodadEx.bDoNotWhenFight")
DoodadEx.tDoodadList = {}
DoodadEx.OnFrameCreate = function()
  DoodadEx.frameContant = Station.Lookup("Lowest/DoodadHandle")
  if not DoodadEx.frameContant then
    DoodadEx.frameContant = Wnd.OpenWindow("Interface\\yyLifeBar\\DoodadHandle.ini", "DoodadHandle")
    this:RegisterEvent("RENDER_FRAME_UPDATE")
    this:RegisterEvent("DOODAD_ENTER_SCENE")
    this:RegisterEvent("DOODAD_LEAVE_SCENE")
  end
  DoodadEx.handleTotal = DoodadEx.frameContant:Lookup("", "")
end

DoodadEx.OnEvent = function(event)
  if event == "RENDER_FRAME_UPDATE" then
    DoodadEx:RefreshDoodadTopHeadDisplay()
  elseif event == "DOODAD_ENTER_SCENE" then
    DoodadEx:AppendAnyDoodadToList(arg0)
    DoodadEx.tDoodadList[arg0] = 0
  elseif event == "DOODAD_LEAVE_SCENE" then
    DoodadEx.tDoodadList[arg0] = nil
    DoodadEx:RemoveAnyDoodadFromList(arg0)
  end
end

DoodadEx.OnFrameBreathe = function()
  DoodadEx:Steper()
  DoodadEx:UpdateAllDoodadNameLable()
  if DoodadEx.bOn then
    if DoodadEx.bNeedCtrlKey and not IsCtrlKeyDown() then
      return 
    end
    if DoodadEx.bNeedAltKey and not IsAltKeyDown() then
      return 
    end
    if DoodadEx.bNeedShiftKey and not IsShiftKeyDown() then
      return 
    end
    local player = GetClientPlayer()
    if not player or ((player.nMoveState ~= MOVE_STATE.ON_STAND and player.nMoveState ~= MOVE_STATE.ON_FLOAT) or not DoodadEx.bDoNotInteractWhenFight or player.bFightState) then
      return 
    end
    for i,v in pairs(DoodadEx.tDoodadList) do
      local doodad = GetDoodad(i)
      if doodad and doodad.CanDialog(player) then
        InteractDoodad(i)
      end
    end
  end
end

DoodadEx.UpdateAllDoodadNameLable = function(self)
  for dwDoodadID,tInfo in pairs(DoodadEx.SynAnyDoodadList) do
    DoodadEx:UpdateAnyDoodadNameLable(dwDoodadID)
  end
end

DoodadEx.GetAnyDoodadListCount = function(self)
  local nCount = 0
  for dwDoodadID,_ in pairs(DoodadEx.SynAnyDoodadList) do
    nCount = nCount + 1
  end
  return nCount
end

DoodadEx.AppendAnyDoodadToList = function(self, dwDoodadID)
  if not dwDoodadID then
    return 
  end
  local doodad = GetDoodad(dwDoodadID)
  if DoodadEx.SynAnyDoodadList[dwDoodadID] and not doodad then
    DoodadEx:RemoveAnyDoodadFromList(dwDoodadID)
  end
  return 
  if not doodad or doodad.nKind == DOODAD_KIND.CORPSE then
    return 
  end
  DoodadEx.SynAnyDoodadList[dwDoodadID] = {dwID = dwDoodadID, szName = doodad.szName, szTopHead = doodad.szName, nDistance = 0, nCameraDistance = 0}
  local handle = DoodadEx.handleTotal
  local szHandleLabelName_Name = "Name_DOODAD_" .. dwDoodadID
  local handleLabel_Name = handle:Lookup(szHandleLabelName_Name)
  if not handleLabel_Name then
    handle:AppendItemFromIni("Interface/yyLifeBar/DoodadHandle.ini", "Handle_Label", szHandleLabelName_Name)
    handleLabel_Name = handle:Lookup(handle:GetItemCount() - 1)
    handleLabel_Name.dwDoodadID = dwDoodadID
    handleLabel_Name.textLable = handleLabel_Name:Lookup("Text_Content")
    handleLabel_Name.textLable:SetFontScheme(40)
    DoodadEx.SynAnyDoodadList[dwDoodadID].handleLabel_Name = handleLabel_Name
  end
  DoodadEx:UpdateAnyDoodadNameLable(dwDoodadID)
end

DoodadEx.RemoveAnyDoodadFromList = function(self, dwDoodadID)
  if not dwDoodadID or not DoodadEx.SynAnyDoodadList[dwDoodadID] then
    return 
  end
  local handle = DoodadEx.handleTotal
  local handleLabel_Name = handle:Lookup("Name_DOODAD_" .. dwDoodadID)
  if handleLabel_Name then
    handle:RemoveItem(handleLabel_Name:GetIndex())
  end
  DoodadEx.SynAnyDoodadList[dwDoodadID] = nil
end

DoodadEx.UpdateAnyDoodadNameLable = function(self, dwDoodadID)
  local tInfo = DoodadEx.SynAnyDoodadList[dwDoodadID]
  local doodad = GetDoodad(dwDoodadID)
  if not doodad and tInfo then
    DoodadEx:RemoveAnyDoodadFromList(dwDoodadID)
  end
  return 
  if not tInfo then
    DoodadEx:AppendAnyDoodadToList(dwDoodadID)
    return 
  end
  if not tInfo.handleLabel_Name then
    return 
  end
  tInfo.szName = doodad.szName
  local doodadTemplate = GetDoodadTemplate(doodad.dwTemplateID)
  tInfo.szTopHead = ""
  if yyLifeBar.bShowDoodad then
    tInfo.szTopHead = tInfo.szName
  end
  tInfo.handleLabel_Name.textLable:SetText(tInfo.szTopHead)
end

DoodadEx.RefreshDoodadTopHeadDisplay = function(self)
  local playerClient = GetClientPlayer()
  if not playerClient then
    return 
  end
  local dwSelfID = playerClient.dwID
  for dwDoodadID,tInfo in pairs(DoodadEx.SynAnyDoodadList) do
    local doodad = GetDoodad(dwDoodadID)
    if not doodad then
      DoodadEx:RemoveAnyDoodadFromList(dwDoodadID)
      return 
    end
    local nRed, nGreen, nBlue = 196, 64, 255
    local nDist2d = math.floor(playerClient.nX - doodad.nX ^ 2 + playerClient.nY - doodad.nY ^ 2 ^ 0.5)
    local nYShift = nDist2d * -0.001
    local nYShift = 0
    local nTopX, nTopY, nTopZ = Scene_GameWorldPositionToScenePosition(doodad.nX, doodad.nY, doodad.nZ, 0)
    local nScreenX, nScreenY, bSuccess = 0, 0, false
    if nTopX and nTopY and nTopZ then
      nScreenX = Scene_ScenePointToScreenPoint(nTopX, nTopY - nYShift, nTopZ)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if bSuccess then
      nScreenX = Station.AdjustToOriginalPos(nScreenX, nScreenY)
    elseif tInfo.handleLabel_Name then
      tInfo.handleLabel_Name:SetAbsPos(-4096, -4096)
    end
    if bSuccess then
      if DoodadEx.nSteperCount % 4 == 0 or DoodadEx.SynAnyDoodadList[dwDoodadID].nCameraDistance == 0 then
        DoodadEx.SynAnyDoodadList[dwDoodadID].nCameraDistance = math.floor(playerClient.nX - doodad.nX ^ 2 + playerClient.nY - doodad.nY ^ 2 + playerClient.nZ / 8 - doodad.nZ / 8 ^ 2 ^ 0.5)
      end
      local nDist3D = DoodadEx.SynAnyDoodadList[dwDoodadID].nCameraDistance
      local handleLabel_Name = tInfo.handleLabel_Name
      local textLable = nil
      if handleLabel_Name then
        textLable = handleLabel_Name.textLable
        local nWidth, nHeight = textLable:GetSize()
        local nX, nY = math.ceil(nScreenX - nWidth / 2) - 8, math.floor(nScreenY - nHeight / 2) - 80
        handleLabel_Name:SetAbsPos(nX, nY)
        textLable:Show()
        handleLabel_Name:SetUserData(-nDist3D)
      end
      local tFontScale = {16, 187, 40}
      if textLable and DoodadEx.nSteperCount % 2 == 0 then
        if nDist3D < 800 then
          textLable:SetFontScheme(tFontScale[3])
          textLable:SetFontScale(1)
        end
      elseif nDist3D < 1600 then
        textLable:SetFontScheme(tFontScale[2])
        textLable:SetFontScale(1)
      elseif nDist3D < 2400 then
        textLable:SetFontScheme(tFontScale[1])
        textLable:SetFontScale(1)
      else
        local nDist3DDelta = nDist3D - 2400
        local nScale = 1 - nDist3DDelta / 4000
        if nScale <= 0.7 then
          nScale = 0.7
        end
        textLable:SetFontScheme(tFontScale[1])
        textLable:SetFontScale(nScale)
      end
      local bFade = true
      local nAlpha = 210
      if bFade then
        local nDistDelta = nDist3D - 900
        if nDistDelta <= 0 then
          nDistDelta = 0
        end
        nAlpha = nAlpha - math.floor(nDistDelta / 50)
      end
      if nAlpha <= 0 then
        nAlpha = 0
      end
      nAlpha = 210
    end
    if textLable then
      textLable:SetAlpha(nAlpha)
      textLable:SetFontColor(nRed, nGreen, nBlue)
    end
  end
  if DoodadEx.nSteperCount % 16 == 0 then
    DoodadEx.handleTotal:Sort()
  end
end

DoodadEx.Steper = function(self)
  self.nSteperCount = self.nSteperCount + 1
  if self.nSteperCount >= 100000000 then
    self.nSteperCount = -1
  end
end

DoodadEx.CheckSteper = function(self, nInterval)
  if not nInterval then
    nInterval = 8
  end
  if math.fmod(self.nSteperCount, nInterval) ~= 0 then
    return false
  end
  return true
end

DoodadEx.OpenPanel = function(self)
  if IsOptionOrOptionChildPanelOpened() then
    return 
  end
  local frame = Station.Lookup("Normal/DoodadEx")
  if not frame then
    frame = Wnd.OpenWindow("Interface\\yyLifeBar\\DoodadEx.ini", "DoodadEx")
  end
  frame:Show()
end

DoodadEx:OpenPanel()

