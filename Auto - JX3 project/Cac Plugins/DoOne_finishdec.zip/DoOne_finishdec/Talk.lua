-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Talk.lua 

local l_0_0 = function()
  local l_1_0 = GetCurrentTime()
  local l_1_1 = TimeToDate(l_1_0)
  if Chat.nTimeType == 1 then
    local l_1_2 = string.format
    local l_1_3 = "[%02d:%02d:%02d]"
    local l_1_4 = l_1_1.hour
    local l_1_5 = l_1_1.minute
    local l_1_6, l_1_11 = l_1_1.second
    return l_1_2(l_1_3, l_1_4, l_1_5, l_1_6)
  else
    if Chat.nTimeType == 2 then
      local l_1_7 = string.format
      local l_1_8 = "[%02d:%02d]"
      local l_1_9 = l_1_1.hour
      local l_1_10 = l_1_1.minute
      return l_1_7(l_1_8, l_1_9, l_1_10)
    end
  end
end

local l_0_1 = function(l_2_0, l_2_1)
  local l_2_2 = l_2_0:Lookup(l_2_1:GetIndex() + 1)
  if l_2_2 and l_2_2:GetType() == "Text" then
    local l_2_3 = l_2_2:GetText()
    if string.len(l_2_3) >= 4 and StringSubW(l_2_3, 1, 2) == "˵��" then
      local l_2_4 = l_2_0:Lookup(l_2_1:GetIndex() - 1)
      if l_2_4 and l_2_4:GetType() == "Text" and l_2_4:GetText() == "�����ĵض�" then
        return 1
      end
    else
      return 2
    end
  else
    if string.len(l_2_3) >= 10 and StringSubW(l_2_3, 1, 5) == "���ĵ�˵��" then
      return 3
    end
  end
end

local l_0_2 = function(l_3_0)
  if l_3_0 == "namelink" or #l_3_0 > 8 and string.sub(l_3_0, 1, 8) == "namelink" then
    return true
  end
end

local l_0_5 = function(l_4_0, l_4_1)
  -- upvalues: l_0_2
  if l_4_1.szName ~= "[���]" then
    return 
  end
  local l_4_2 = l_4_0:Lookup(l_4_1:GetIndex() + 1)
  if l_4_2 and not l_0_2(l_4_2:GetName()) then
    return true
  end
end

do
  local l_0_7 = function(l_5_0, l_5_1)
  -- upvalues: l_0_3 , l_0_2 , l_0_1
  local l_5_2 = l_5_1:GetName()
  if l_5_2 == "msglink" then
    if l_5_1.szName == "[��Ӫ]" then
      return 0
    else
      if l_0_3(l_5_0, l_5_1) then
        return 1
      end
    else
      return 2
    end
  else
    if l_0_2(l_5_2) then
      local l_5_3 = l_0_1(l_5_0, l_5_1)
    end
  end
  if l_5_3 then
    return l_5_3 + 2
  end
end

  RegisterEvent("RENDER_FRAME_UPDATE", function()
  -- upvalues: l_0_7 , l_0_6
  if IsEmpty(Chat.tChannelEx) then
    return 
  end
  local l_11_0 = false
  for l_11_4,l_11_5 in ipairs({"bTime", "bColor", "bCopy", "bFilter"}) do
    if Chat[l_11_5] then
      l_11_0 = true
  else
    end
  end
  if not l_11_0 then
    return 
  end
  local l_11_6 = l_0_7()
  for l_11_10,l_11_11 in pairs(Chat.tChannelEx) do
    if l_11_6[l_11_10] then
      l_0_6(Station.Lookup("Lowest2/ChatPanel" .. l_11_6[l_11_10]))
    end
  end
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

