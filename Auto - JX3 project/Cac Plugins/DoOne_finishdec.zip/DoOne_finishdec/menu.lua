-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: menu.lua 

BoxMenu = {}
local l_0_0 = function(l_1_0, l_1_1)
  local l_1_2, l_1_3 = Station.GetClientSize()
  if l_1_0 < l_1_2 / 2 and l_1_1 < l_1_3 / 2 then
    return "TOP_LEFT"
  elseif l_1_2 / 2 <= l_1_0 and l_1_1 < l_1_3 / 2 then
    return "TOP_RIGHT"
  elseif l_1_0 < l_1_2 / 2 and l_1_3 / 2 <= l_1_1 then
    return "BOTTOM_LEFT"
  else
    return "BOTTOM_RIGHT"
  end
end

BoxMenu.UpdateHLight = function(l_2_0)
  local l_2_1 = l_2_0:Lookup("Image_HighLight")
  if not l_2_1 then
    return 
  end
  if l_2_0.bOver then
    l_2_1:Show()
  else
    l_2_1:Hide()
  end
end

BoxMenu.OnItemLButtonClick = function()
  if this.fnAction then
    this.fnAction()
  end
end

BoxMenu.OnItemMouseEnter = function()
  if this:GetName() == "Handle_ListMod" then
    this.bOver = true
    BoxMenu.UpdateHLight(this)
  end
end

BoxMenu.OnItemMouseLeave = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "Handle_ListMod" then
    this.bOver = false
    BoxMenu.UpdateHLight(this)
  end
end

BoxMenu.OnKillFocus = function()
  HideBoxMenu()
end

HideBoxMenu = function()
  local l_7_0 = Station.Lookup("Normal/BoxMenu")
  l_7_0:Hide()
end

BoxMenu.UpdatePos = function(l_8_0, l_8_1, l_8_2)
  local l_8_3, l_8_4 = l_8_0:GetSize()
  local l_8_5, l_8_6 = Station.GetClientSize()
  if l_8_6 < l_8_2 + l_8_4 then
    l_8_2 = l_8_6 - l_8_4
  end
  if l_8_5 < l_8_1 + l_8_3 then
    l_8_1 = l_8_5 - l_8_3
  end
  l_8_0:SetAbsPos(l_8_1, l_8_2)
end

PopBoxMenu = function(l_9_0, l_9_1)
  -- upvalues: l_0_0
  local l_9_2 = "interface/Moon_Base/boxmenu.ini"
  if not Station.Lookup("Normal/BoxMenu") then
    local l_9_3, l_9_4, l_9_5, l_9_6 = Wnd.OpenWindow(l_9_2, "BoxMenu")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_9_3:SetAlpha(255)
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_9_7 = nil
  local l_9_8 = nil
  l_9_3:Lookup("", ""):Lookup("Handle_List"):Clear()
  local l_9_9 = nil
  for l_9_13,l_9_14 in ipairs(l_9_0) do
    local l_9_10 = 125
    local l_9_16 = nil
    l_9_16:Lookup("Image_Icon"):FromUITex(l_9_15.szImage, l_9_15.nFrame)
    l_9_9:AppendItemFromIni(l_9_2, "Handle_ListMod"):Lookup("Text_Name"):SetText(l_9_15.szName)
    l_9_9:AppendItemFromIni(l_9_2, "Handle_ListMod"):Lookup("Text_Name"):AutoSize()
    l_9_10 = math.max(l_9_10, l_9_9:AppendItemFromIni(l_9_2, "Handle_ListMod"):Lookup("Text_Name"):GetRelPos() + l_9_9:AppendItemFromIni(l_9_2, "Handle_ListMod"):Lookup("Text_Name"):GetSize() + 10)
  end
  for l_9_20 = 0, l_9_9:GetItemCount() - 1 do
    local l_9_17 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_9_9:Lookup(l_9_14) then
      l_9_9:Lookup(l_9_14):SetSize(l_9_17, 30)
      l_9_9:Lookup(l_9_14):Lookup("Image_HighLight"):SetSize(l_9_17, 43)
    end
  end
  l_9_9:FormatAllItemPos()
  l_9_9:SetSizeByAllItemSize()
  local l_9_22, l_9_23, l_9_28, l_9_29 = , l_9_9:GetSize()
  l_9_29 = l_9_28 + 10
  local l_9_24, l_9_30 = nil
  l_9_24, l_9_30 = l_9_8:SetSize, l_9_8
  l_9_24(l_9_30, l_9_23, l_9_29)
  l_9_24, l_9_30 = l_9_8:Lookup, l_9_8
  l_9_24 = l_9_24(l_9_30, "Image_Bg")
  l_9_24, l_9_30 = l_9_24:SetSize, l_9_24
  l_9_24(l_9_30, l_9_23, l_9_29)
  l_9_24, l_9_30 = l_9_7:SetSize, l_9_7
  l_9_24(l_9_30, l_9_23, l_9_29)
  l_9_24 = unpack
  l_9_30 = l_9_1
  l_9_24 = l_9_24(l_9_30)
  local l_9_25, l_9_26, l_9_31, l_9_32 = nil
  l_9_25 = l_0_0
  l_9_26 = l_9_24
  l_9_31 = 
  l_9_25 = l_9_25(l_9_26, l_9_31)
  do
    local l_9_27, l_9_33 = nil
    if l_9_25 == "TOP_LEFT" or l_9_25 == "TOP_RIGHT" then
      l_9_30 = l_9_30 + 36
    else
      l_9_30 = l_9_30 - (l_9_29)
    end
    l_9_26, l_9_31 = l_9_7:SetAbsPos, l_9_7
    l_9_32 = l_9_24
    l_9_27 = l_9_30
    l_9_26(l_9_31, l_9_32, l_9_27)
    l_9_26, l_9_31 = l_9_7:Show, l_9_7
    l_9_26(l_9_31)
    l_9_26 = Station
    l_9_26 = l_9_26.SetFocusWindow
    l_9_31 = l_9_7
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_9_26(l_9_31)
end


