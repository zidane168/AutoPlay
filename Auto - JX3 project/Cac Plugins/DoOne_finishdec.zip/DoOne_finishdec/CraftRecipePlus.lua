-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: CraftRecipePlus.lua 

local l_0_0 = {}
l_0_0.showType = 2
l_0_0.bFilteringLower = true
CraftRecipePlus = l_0_0
l_0_0 = RegisterCustomData
l_0_0("CraftRecipePlus.showType")
l_0_0 = RegisterCustomData
l_0_0("CraftRecipePlus.bFilteringLower")
local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = {}
l_0_3[3] = 198
l_0_2[4] = l_0_3
l_0_2[5], l_0_3 = l_0_3, {"����ר��", "ӡȾר��", 713}
l_0_2[6], l_0_3 = l_0_3, {"����ר��", "�Ƽ�ר��", 506}
l_0_2[7], l_0_3 = l_0_3, {"��ҽ��", "����ҽ��", 210}
l_0_3 = function(l_1_0)
  local l_1_1 = {}
  local l_1_2 = KG_Table.Load
  local l_1_3 = l_1_0
  local l_1_4 = {}
  local l_1_5 = {}
  l_1_5.f = "i"
  l_1_5.t = "dwID"
  local l_1_6 = {}
  l_1_6.f = "s"
  l_1_6.t = "szName"
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_1_5 = FILE_OPEN_MODE
  l_1_5 = l_1_5.NORMAL
  l_1_2 = l_1_2(l_1_3, l_1_4, l_1_5)
  l_1_3 = 2
  l_1_4, l_1_5 = l_1_2:GetRowCount, l_1_2
  l_1_4 = l_1_4(l_1_5)
  l_1_5 = 1
  for l_1_6 = l_1_3, l_1_4, l_1_5 do
    local l_1_7 = l_1_2:GetRow(l_1_6)
    table.insert(l_1_1, l_1_7.dwID)
  end
  return l_1_1
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

CraftRecipePlus.LoadAllRecipe = function()
  -- upvalues: l_0_2 , l_0_3
  for l_2_3,l_2_4 in pairs(l_0_2) do
    if l_2_3 == 5 then
      l_0_2[l_2_3][3] = l_0_3("/ui/Scheme/Case/recipe/tailoring.tab")
    elseif l_2_3 == 4 then
      l_0_2[l_2_3][3] = l_0_3("/ui/Scheme/Case/recipe/cooking.tab")
    elseif l_2_3 == 6 then
      l_0_2[l_2_3][3] = l_0_3("/ui/Scheme/Case/recipe/founding.tab")
    elseif l_2_3 == 7 then
      l_0_2[l_2_3][3] = l_0_3("/ui/Scheme/Case/recipe/medicine.tab")
    end
  end
end

CraftRecipePlus.LoadAllRecipe()
function()
  -- upvalues: l_0_0 , l_0_1
  do break end
  do
    local l_3_0, l_3_1, l_3_2, l_3_3, l_3_4 = pairs(l_0_0)
    local l_3_5 = GetMasterRecipeList(l_3_3, true, true, true)
    for l_3_9,l_3_10 in pairs(l_3_5) do
      if not l_0_1[l_3_10.dwCraftID] then
        local l_3_11 = l_0_1
        local l_3_12 = l_3_10.dwCraftID
        l_3_11[l_3_12] = {}
      end
      local l_3_13 = l_0_1[l_3_10.dwCraftID]
      local l_3_14 = l_3_10.dwRecipeID
      local l_3_15 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
  end
end
 -- WARNING: undefined locals caused missing assignments!
end
()
CraftRecipePlus.GetAllRecipe = function()
  -- upvalues: l_0_2
  do
    local l_4_0 = {}
    for l_4_4,l_4_5 in pairs(l_0_2) do
      do break end
      local l_4_6, l_4_7, l_4_8, l_4_9, l_4_10 = pairs(l_4_5[3])
      do
        local l_4_11 = GetRecipe(l_4_4, l_4_10)
        if l_4_11 then
          for l_4_15 = 1, 6 do
            local l_4_16 = l_4_11["dwRequireItemType" .. l_4_15]
            local l_4_17 = l_4_11["dwRequireItemIndex" .. l_4_15]
            local l_4_18 = l_4_11["dwRequireItemCount" .. l_4_15]
            if l_4_18 > 0 then
              local l_4_19 = GetItemInfo(l_4_16, l_4_17)
            end
            if l_4_19 then
              local l_4_20 = l_4_19.szName
              local l_4_21 = l_4_4
              if not l_4_0[l_4_20] then
                l_4_0[l_4_20] = {}
              end
              if not l_4_0[l_4_20][l_4_4] then
                l_4_0[l_4_20][l_4_4] = {}
              end
              table.insert(l_4_0[l_4_20][l_4_4], l_4_10)
            end
          end
        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  do break end
  local l_4_22, l_4_23, l_4_24, l_4_25, l_4_26 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_4_30,l_4_31 in l_4_25 do
    local l_4_30, l_4_31 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

    l_4_30(l_4_31, function(l_5_0, l_5_1)
    -- upvalues: l_4_9
    local l_5_2 = GetRecipe(l_4_9, l_5_0)
    local l_5_3 = GetRecipe(l_4_9, l_5_1)
    return l_5_3.dwRequireProfessionLevel < l_5_2.dwRequireProfessionLevel
  end)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- DECOMPILER ERROR: Confused about usage of registers!

return l_4_0
end
 -- WARNING: undefined locals caused missing assignments!
end

do
  local l_0_5 = nil
  if CraftRecipePlus.CraftManagePanel_UpdateRecipeTable or not CraftRecipePlus.Craft_OnItemMouseEnter then
    RegisterBoxAddonVersion("Moon_CraftRecipePlus", 2.8)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- WARNING: undefined locals caused missing assignments!
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 120 

