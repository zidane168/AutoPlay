-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DyyLifebarSettings.lua 


