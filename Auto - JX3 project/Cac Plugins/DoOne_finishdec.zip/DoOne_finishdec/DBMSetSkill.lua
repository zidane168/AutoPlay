-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMSetSkill.lua 

local l_0_0 = {}
l_0_0.type = ""
l_0_0.szName = ""
l_0_0.szColor = "red"
DBMSetSkill = l_0_0
l_0_0 = DBMSetSkill
l_0_0.OnFrameCreate = function()
end

l_0_0 = DBMSetSkill
l_0_0.OnLButtonClick = function()
  local l_2_0 = this:GetName()
  if l_2_0 == "Btn_Close" or l_2_0 == "Btn_Cancle" then
    Wnd.CloseWindow("DBMSetSkill")
  elseif l_2_0 == "Btn_Submit" then
    local l_2_1 = {}
    local l_2_2 = Station.Lookup("Normal/DBMSetSkill")
    local l_2_3 = l_2_2:Lookup("Edit_Name/Edit_Default"):GetText()
    local l_2_4 = l_2_2:Lookup("Edit_Desc/Edit_Default"):GetText()
    if l_2_3 == "" then
      MsgBox("�������Ʋ���Ϊ�գ�")
      return 
    end
    if l_2_4 == "" then
      MsgBox("������������Ϊ�գ�")
      return 
    end
    if not DBMPanel.CheckSpecialChar(l_2_3) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    if not DBMPanel.CheckSpecialChar(l_2_4) then
      MsgBox("���󣬰��������ַ���|����")
      return 
    end
    l_2_1.type = 1
    if l_2_2:Lookup("CheckBox_Prepare"):IsCheckBoxChecked() then
      l_2_1.type = 2
    end
    l_2_1.nTarget = 1
    if l_2_2:Lookup("CheckBox_All"):IsCheckBoxChecked() then
      l_2_1.nTarget = 2
    end
    l_2_1.szName = l_2_3
    l_2_1.szDesc = l_2_4
    l_2_1.bFlash = l_2_2:Lookup("CheckBox_FlashAlarm"):IsCheckBoxChecked()
    l_2_1.bMsg = l_2_2:Lookup("CheckBox_MsgAlarm"):IsCheckBoxChecked()
    l_2_1.bSay = l_2_2:Lookup("CheckBox_SayAlarm"):IsCheckBoxChecked()
    l_2_1.szrgb = DBMSetSkill.szColor
    local l_2_5 = DBMSetPanel.GetCurrMod()
    if DBMSetSkill.type == "modify" then
      for l_2_9,l_2_10 in pairs(l_2_5.Skill) do
        if l_2_10.szName == DBMSetSkill.szName then
          l_2_1.bOn = l_2_10.bOn
          table.remove(l_2_5.Skill, l_2_9)
          do break end
        end
      end
      do break end
    end
    l_2_1.bOn = true
    for l_2_14,l_2_15 in pairs(l_2_5.Skill) do
      if l_2_15.szName == l_2_3 then
        MsgBox("�Ѵ��ڸü��ܵ����ݣ�")
        return 
      end
    end
    table.insert(l_2_5.Skill, l_2_1)
    Wnd.CloseWindow("DBMSetSkill")
    DBMSetPanel.UpdateSkill()
  end
end

l_0_0 = function(l_3_0)
  if Station.Lookup("Normal/DBMSetSkill") then
    return 
  end
  DBMSetSkill.szColor = "red"
  DBMSetSkill.type = "new"
  DBMSetSkill.szName = ""
  local l_3_1 = {}
  local l_3_2 = DBMSetPanel.GetCurrMod()
  if l_3_0 then
    DBMSetSkill.type = "modify"
    DBMSetSkill.szName = l_3_0
    for l_3_6,l_3_7 in pairs(l_3_2.Skill) do
      if l_3_7.szName == l_3_0 then
        l_3_1 = l_3_7
      end
    end
  end
  local l_3_8, l_3_23 = BoxSetFrame
  l_3_23 = "DBMSetSkill"
  local l_3_9, l_3_24 = nil
  local l_3_10, l_3_25 = nil
  l_3_8, l_3_9 = l_3_8(l_3_23, l_3_9), {w = 400, h = 390, bdrag = true, bglobal = true}
  l_3_23, l_3_9 = l_3_8:Center, l_3_8
  l_3_23(l_3_9)
  l_3_23 = l_3_8.handle
  l_3_9 = BoxLabel
  l_3_24 = l_3_23
  local l_3_11, l_3_26 = nil
  l_3_10 = "Label_Title"
  local l_3_12, l_3_27 = nil
  l_3_25 = "��������"
  local l_3_13, l_3_28 = nil
  local l_3_14, l_3_29 = nil
  l_3_26 = 0
  l_3_12 = 10
  l_3_26 = nil
  local l_3_15, l_3_30 = nil
  local l_3_16, l_3_31 = nil
  l_3_9(l_3_24, l_3_10, l_3_25, l_3_11, l_3_26, l_3_12)
  l_3_12, l_3_11 = {nW = 400, nH = 30, nHAlign = 1}, {l_3_26, l_3_12}
  l_3_9 = BoxLabel
  l_3_24 = l_3_23
  l_3_10 = "Label1"
  l_3_25 = "�������ƣ�"
  l_3_26 = 30
  l_3_12 = 50
  l_3_9(l_3_24, l_3_10, l_3_25, l_3_11)
  l_3_11 = {l_3_26, l_3_12}
  l_3_9 = BoxEdit
  l_3_24 = l_3_8.frame
  l_3_10 = "Edit_Name"
  l_3_9, l_3_25 = l_3_9(l_3_24, l_3_10, l_3_25), {x = 120, y = 50, w = 200, h = 30}
  l_3_24 = BoxLabel
  l_3_10 = l_3_23
  l_3_25 = "Label2"
  l_3_11 = "�������ͣ�"
  l_3_12 = 30
  l_3_27 = 93
  l_3_24(l_3_10, l_3_25, l_3_11, l_3_26)
  l_3_26 = {l_3_12, l_3_27}
  l_3_24 = BoxRadioBox
  l_3_10 = l_3_8.frame
  l_3_25 = "CheckBox_General"
  l_3_24, l_3_11 = l_3_24(l_3_10, l_3_25, l_3_11), {x = 120, y = 95, txt = "��ͨ����"}
  l_3_10, l_3_25 = l_3_24:OnCheck, l_3_24
  l_3_11 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_Prepare"):Check(false)
  end
  l_3_10(l_3_25, l_3_11)
  l_3_10 = BoxRadioBox
  l_3_25 = l_3_8.frame
  l_3_11 = "CheckBox_Prepare"
  l_3_10, l_3_26 = l_3_10(l_3_25, l_3_11, l_3_26), {x = 220, y = 95, txt = "��������"}
  l_3_25, l_3_11 = l_3_10:OnCheck, l_3_10
  l_3_26 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_General"):Check(false)
  end
  l_3_25(l_3_11, l_3_26)
  l_3_25 = BoxLabel
  l_3_11 = l_3_23
  l_3_26 = "Label3"
  l_3_12 = "����Ŀ�꣺"
  local l_3_17, l_3_32 = nil
  l_3_13 = 30
  l_3_28 = 130
  l_3_25(l_3_11, l_3_26, l_3_12, l_3_27)
  l_3_27 = {l_3_13, l_3_28}
  l_3_25 = BoxRadioBox
  l_3_11 = l_3_8.frame
  l_3_26 = "CheckBox_Self"
  l_3_25, l_3_12 = l_3_25(l_3_11, l_3_26, l_3_12), {x = 120, y = 132, txt = "�Լ�"}
  l_3_11, l_3_26 = l_3_25:OnCheck, l_3_25
  l_3_12 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_All"):Check(false)
  end
  l_3_11(l_3_26, l_3_12)
  l_3_11 = BoxRadioBox
  l_3_26 = l_3_8.frame
  l_3_12 = "CheckBox_All"
  l_3_11, l_3_27 = l_3_11(l_3_26, l_3_12, l_3_27), {x = 220, y = 132, txt = "������"}
  l_3_26, l_3_12 = l_3_11:OnCheck, l_3_11
  l_3_27 = function()
    -- upvalues: l_3_3
    l_3_3.frame:Lookup("CheckBox_Self"):Check(false)
  end
  l_3_26(l_3_12, l_3_27)
  l_3_26 = BoxLabel
  l_3_12 = l_3_23
  l_3_27 = "Label4"
  l_3_13 = "��ʾ���ã�"
  local l_3_18, l_3_33 = nil
  local l_3_19, l_3_34 = nil
  l_3_14 = 30
  l_3_29 = 160
  l_3_26(l_3_12, l_3_27, l_3_13, l_3_28)
  l_3_28 = {l_3_14, l_3_29}
  l_3_26 = BoxCheckBox
  l_3_12 = l_3_8.frame
  l_3_27 = "CheckBox_FlashAlarm"
  l_3_26, l_3_13 = l_3_26(l_3_12, l_3_27, l_3_13), {x = 65, y = 190, txt = "ȫ������"}
  l_3_12 = BoxComboBox
  l_3_27 = l_3_8.frame
  l_3_13 = "ComboBox_FlashColor"
  l_3_12, l_3_28 = l_3_12(l_3_27, l_3_13, l_3_28), {txt = "������ɫ", x = 200, y = 190, w = 150, h = 25}
  l_3_12, l_3_27 = l_3_12:SetMenu, l_3_12
  l_3_13 = function(l_8_0)
    local l_8_1 = {}
    local l_8_2 = {}
    l_8_2.Name = "��"
    l_8_2.Val = "red"
    local l_8_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_8_4 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_8_5 = {}
    do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_8_6 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_8_7 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      do
        local l_8_8 = {}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for l_8_5,l_8_6 in l_8_2 do
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_9 = 0
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_10 = 255.insert
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_8_11 = 255
          local l_8_12 = {}
          l_8_12.szOption = l_8_6.Name .. " ��"
          l_8_12.bMCheck = true
          l_8_12.bChecked = DBMSetSkill.szColor == l_8_6.Val
          l_8_12.r = l_8_7
          l_8_12.g = l_8_8
          l_8_12.b = l_8_9
          l_8_12.fnAction = function()
          -- upvalues: l_5_6
          DBMSetSkill.szColor = l_5_6.Val
        end
          l_8_10(l_8_11, l_8_12)
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
  l_3_12(l_3_27, l_3_13)
  l_3_12 = BoxCheckBox
  l_3_27 = l_3_8.frame
  l_3_13 = "CheckBox_MsgAlarm"
  l_3_12, l_3_28 = l_3_12(l_3_27, l_3_13, l_3_28), {x = 65, y = 220, txt = "��������"}
  l_3_27 = BoxCheckBox
  l_3_13 = l_3_8.frame
  l_3_28 = "CheckBox_SayAlarm"
  do
    local l_3_20, l_3_35 = nil
    l_3_27, l_3_14 = l_3_27(l_3_13, l_3_28, l_3_14), {x = 200, y = 220, txt = "���챨��"}
    l_3_13 = BoxLabel
    l_3_28 = l_3_23
    l_3_14 = "Label5"
    l_3_29 = "��ʾ���ݣ�"
    local l_3_21 = nil
    local l_3_22 = nil
    l_3_30 = 30
    l_3_16 = 250
    l_3_13(l_3_28, l_3_14, l_3_29, l_3_15)
    l_3_15 = {l_3_30, l_3_16}
    l_3_13 = BoxEdit
    l_3_28 = l_3_8.frame
    l_3_14 = "Edit_Desc"
    l_3_13, l_3_29 = l_3_13(l_3_28, l_3_14, l_3_29), {nmulti = 10, nlimit = 100, w = 300, h = 60, y = 280, x = 45}
    l_3_28 = BoxButton
    l_3_14 = l_3_8.frame
    l_3_29 = "Btn_Submit"
    l_3_28(l_3_14, l_3_29, l_3_15)
    l_3_15 = {txt = "ȷ��", y = 350, x = 70}
    l_3_28 = BoxButton
    l_3_14 = l_3_8.frame
    l_3_29 = "Btn_Cancle"
    l_3_28(l_3_14, l_3_29, l_3_15)
    l_3_15 = {txt = "ȡ��", y = 350, x = 230}
    l_3_28 = DBMSetSkill
    l_3_28 = l_3_28.type
    if l_3_28 == "modify" then
      l_3_28, l_3_14 = l_3_9:SetText, l_3_9
      l_3_29 = l_3_1.szName
      l_3_28(l_3_14, l_3_29)
      l_3_28 = l_3_24
      l_3_14 = l_3_1.type
      if l_3_14 == 2 then
        l_3_28 = l_3_10
      end
      l_3_14, l_3_29 = l_3_28:Check, l_3_28
      l_3_15 = true
      l_3_14(l_3_29, l_3_15)
      l_3_28 = l_3_25
      l_3_14 = l_3_1.nTarget
      if l_3_14 == 2 then
        l_3_28 = l_3_11
      end
      l_3_14, l_3_29 = l_3_28:Check, l_3_28
      l_3_15 = true
      l_3_14(l_3_29, l_3_15)
      l_3_14, l_3_29 = l_3_13:SetText, l_3_13
      l_3_15 = l_3_1.szDesc
      l_3_14(l_3_29, l_3_15)
      l_3_14 = l_3_1.szrgb
      if l_3_14 then
        l_3_14 = DBMSetSkill
        l_3_29 = l_3_1.szrgb
        l_3_14.szColor = l_3_29
      else
        l_3_14 = DBMSetSkill
        l_3_14.szColor = "red"
      end
      l_3_14, l_3_29 = l_3_26:Check, l_3_26
      l_3_15 = l_3_1.bFlash
      l_3_14(l_3_29, l_3_15)
      l_3_14, l_3_29 = l_3_12:Check, l_3_12
      l_3_15 = l_3_1.bMsg
      l_3_14(l_3_29, l_3_15)
      l_3_14, l_3_29 = l_3_27:Check, l_3_27
      l_3_15 = l_3_1.bSay
      l_3_14(l_3_29, l_3_15)
    else
      l_3_28, l_3_14 = l_3_24:Check, l_3_24
      l_3_29 = true
      l_3_28(l_3_14, l_3_29)
      l_3_28, l_3_14 = l_3_12:Check, l_3_12
      l_3_29 = true
      l_3_28(l_3_14, l_3_29)
      l_3_28, l_3_14 = l_3_25:Check, l_3_25
      l_3_29 = true
      l_3_28(l_3_14, l_3_29)
    end
    l_3_28, l_3_14 = l_3_23:FormatAllItemPos, l_3_23
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_3_28(l_3_14)
end

OpenDBMSetSkill = l_0_0

