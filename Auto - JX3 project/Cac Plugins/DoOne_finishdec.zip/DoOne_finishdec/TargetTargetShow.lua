-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetTargetShow.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
local l_0_27 = string.format
local l_0_28 = {}
local l_0_29 = {}
l_0_29.s = "TOPLEFT"
l_0_29.r = "TOPLEFT"
l_0_29.x = 700
l_0_29.y = 65
l_0_28.DefaultAnchor = l_0_29
l_0_28.Anchor, l_0_29 = l_0_29, {s = "TOPLEFT", r = "TOPLEFT", x = 700, y = 65}
TargetTargetShow = l_0_28
l_0_28 = RegisterCustomData
l_0_29 = "TargetTargetShow.Anchor"
l_0_28(l_0_29)
l_0_28 = 1
if l_0_28 == 1 and l_0_28 == 1 then
  l_0_28 = 0
  l_0_29 = function()
    -- upvalues: l_0_28
    return l_0_28 == 2 or l_0_28 == 3
  end
end
end
end
l_0_29 = function()
local l_2_0 = 1
if l_2_0 == 1 and l_2_0 == 1 then
l_2_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_2_2 = nil
if function()
  -- upvalues: l_2_0
  return l_2_0 == 2 or l_2_0 == 3
end
.modelView == nil then
TargetTargetShow.modelView = PlayerModelView.new()
TargetTargetShow.modelView:init()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
local l_0_30 = function()
local l_3_0 = 1
if l_3_0 == 1 and l_3_0 == 1 then
l_3_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_3_2 = nil
if function()
  -- upvalues: l_3_0
  return l_3_0 == 2 or l_3_0 == 3
end
.modelView then
TargetTargetShow.modelView:UnloadModel()
TargetTargetShow.modelView:release()
TargetTargetShow.modelView = nil
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
TargetTargetShow.OnFrameDestroy = function()
-- upvalues: l_0_30
l_0_30()
end
TargetTargetShow.OnFrameCreate = function()
-- upvalues: l_0_29
this:RegisterEvent("NPC_STATE_UPDATE")
this:RegisterEvent("BUFF_UPDATE")
this:RegisterEvent("PLAYER_STATE_UPDATE")
this:RegisterEvent("PLAYER_ENTER_SCENE")
this:RegisterEvent("PLAYER_LEVEL_UP")
this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
this:RegisterEvent("PARTY_SET_MARK")
this:RegisterEvent("UI_SCALED")
this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
this:RegisterEvent("CUSTOM_DATA_LOADED")
this:RegisterEvent("CHANGE_CAMP")
this:RegisterEvent("CHANGE_CAMP_FLAG")
TargetTargetShow.UpdateAnchor(this)
UpdateCustomModeWindow(this, g_tStrings.TARGET_TARGET)
l_0_29()
end
TargetTargetShow.OnFrameDrag = function()
end
TargetTargetShow.OnFrameDragSetPosEnd = function()
end
local l_0_33 = function(l_8_0, l_8_1, l_8_2, l_8_3, l_8_4, l_8_5, l_8_6, l_8_7, l_8_8)
-- upvalues: l_0_0 , l_0_1 , l_0_2 , l_0_3 , l_0_4 , l_0_6
if not l_0_0(l_8_4, l_8_7) then
return 
end
if PrettyShow.Options.nFilters[l_8_4] == true and PrettyShow.Options.TargetTargetFilter == true then
return 
end
if l_8_1 then
l_8_0:RemoveItem("b" .. l_8_2)
l_8_0:FormatAllItemPos()
else
local l_8_9 = l_0_1()
local l_8_10 = l_8_0:Lookup("b" .. l_8_2)
if l_8_10 then
  l_8_10.nCount = l_8_5
  l_8_10.nEndFrame = l_8_6
  l_8_10.bCanCancel = l_8_3
  l_8_10.dwBuffID = l_8_4
  l_8_10.nLevel = l_8_7
  l_8_10.bSparking = l_0_2(l_8_4, l_8_7)
  l_8_10.bShowTime = l_0_3(l_8_4, l_8_7)
  l_8_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_8_4)
  l_8_10:SetObjectIcon(l_0_4(l_8_4, l_8_7))
  if l_8_8 and l_8_9.dwID == l_8_8 then
    l_8_10:SetIndex(0)
  end
end
if l_8_5 > 1 then
  l_8_10:SetOverText(0, l_8_5)
end
else
l_8_0:AppendItemFromIni("Interface\\PrettyShow\\TargetTargetShow.ini", "Box", "b" .. l_8_2)
l_8_10 = l_8_0:Lookup(l_8_0:GetItemCount() - 1)
l_8_10:SetName("b" .. l_8_2)
l_8_10.nCount = l_8_5
l_8_10.nEndFrame = l_8_6
l_8_10.bCanCancel = l_8_3
l_8_10.dwBuffID = l_8_4
l_8_10.nLevel = l_8_7
l_8_10.nIndex = l_8_2
l_8_10.bSparking = l_0_2(l_8_4, l_8_7)
l_8_10.bShowTime = l_0_3(l_8_4, l_8_7)
l_8_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_8_4)
l_8_10:SetObjectIcon(l_0_4(l_8_4, l_8_7))
l_8_10:SetOverTextFontScheme(0, 15)
l_8_10:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP + 1)
l_8_10:SetOverTextFontScheme(1, 16)
if l_8_8 and l_8_9.dwID == l_8_8 then
  l_8_10:SetIndex(0)
end
if l_8_0:GetName() == "Handle_Debuff" then
  local l_8_11 = "\\ui\\Image\\Common\\Box.UITex"
  local l_8_12 = 1
  l_8_10:SetExtentImage(l_8_11, l_8_12)
else
  local l_8_13 = "\\ui\\Image\\Common\\Box.UITex"
  local l_8_14 = 13
  l_8_10:SetExtentImage(l_8_13, l_8_14)
end
if l_8_5 > 1 then
  l_8_10:SetOverText(0, l_8_5)
end
l_8_10.OnItemMouseEnter = function()
  -- upvalues: l_0_6
  local l_9_0 = this:GetRoot()
  this:SetObjectMouseOver(1)
  local l_9_1 = math.floor(this.nEndFrame - l_0_6()) / 16 + 1
  local l_9_2, l_9_3 = this:GetAbsPos()
  local l_9_4, l_9_5 = this:GetSize()
  local l_9_6 = OutputBuffTip
  local l_9_7 = l_9_0.dwID
  local l_9_8 = this.dwBuffID
  local l_9_9 = this.nLevel
  local l_9_10 = this.nCount
  local l_9_11 = this.bShowTime
  local l_9_12 = l_9_1
  do
    local l_9_13 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_9_6(l_9_7, l_9_8, l_9_9, l_9_10, l_9_11, l_9_12, l_9_13)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_8_10.OnItemMouseHover = l_8_10.OnItemMouseEnter
l_8_10.OnItemMouseLeave = function()
  HideTip()
  this:SetObjectMouseOver(0)
end

l_8_0:FormatAllItemPos()
end
local l_8_15 = l_8_0:GetItemCount()
local l_8_16, l_8_17 = l_8_0:GetAbsPos()
local l_8_18 = PrettyShow.Options.nScale_TargetTarget
for l_8_22 = 0, l_8_15 - 1 do
local l_8_23 = l_8_0:Lookup(l_8_22)
local l_8_24 = math.floor(l_8_22 / 8)
local l_8_25 = l_8_22 % 8
local l_8_26 = l_8_16 + l_8_25 * 29 * l_8_18
local l_8_27 = l_8_17 + l_8_24 * 29 * l_8_18
l_8_23:SetSize(28 * l_8_18, 28 * l_8_18)
l_8_23:SetAbsPos(l_8_26, l_8_27)
end
if l_8_0:GetName() == "Handle_Buff" then
local l_8_28 = math.ceil(l_8_15 / 8)
local l_8_29 = l_8_16
local l_8_30 = l_8_17 + l_8_28 * 31 * l_8_18
l_8_0:GetRoot():Lookup("", "Handle_Debuff"):SetAbsPos(l_8_29, l_8_30)
end
end
local l_0_34 = function(l_14_0, l_14_1)
-- upvalues: l_0_27
local l_14_2 = l_0_27("%d", l_14_1)
local l_14_3 = l_0_27("%d", l_14_0)
local l_14_4 = l_0_27("%.1f%%", l_14_0 * 100 / l_14_1)
if PrettyShow.Options.nActHealth == 2 then
if l_14_1 > 100000 then
  l_14_2 = l_0_27("%.1f��", l_14_1 / 10000)
end
if l_14_0 > 100000 then
  l_14_3 = l_0_27("%.1f��", l_14_0 / 10000)
end
else
if PrettyShow.Options.nActHealth == 3 then
  if l_14_1 > 100000 then
    l_14_2 = l_0_27("%.1fW", l_14_1 / 10000)
  end
end
end
if l_14_0 > 100000 then
l_14_3 = l_0_27("%.1fW", l_14_0 / 10000)
end
if PrettyShow.Options.nHealthMode == 1 or PrettyShow.Options.nHealthMode == 2 or PrettyShow.Options.nHealthMode == 3 then
return l_14_3
end
if PrettyShow.Options.nHealthMode == 4 or PrettyShow.Options.nHealthMode == 5 or PrettyShow.Options.nHealthMode == 6 then
return l_14_3 .. "/" .. l_14_2
end
if PrettyShow.Options.nHealthMode == 7 then
if l_14_0 - l_14_1 < 0 then
  local l_14_5 = l_0_27
  local l_14_6 = "%d"
  local l_14_7 = l_14_0 - l_14_1
  return l_14_5(l_14_6, l_14_7)
end
else
return ""
end
end
local l_0_37 = function(l_15_0)
if l_15_0 <= 0 or l_15_0 >= 1 then
return 0.09, 0.7, 0.03
end
if l_15_0 >= 0.5 then
return (1 - l_15_0) * 2, 0.7, 0
else
return 1, l_15_0 * 2, 0
end
end
local l_0_39 = nil
local l_0_40 = function(l_28_0)
-- upvalues: l_0_11
local l_28_1 = 1
if l_28_1 == 1 and l_28_1 == 1 then
l_28_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_28_3 = nil
local l_28_4 = function()
  -- upvalues: l_28_1
  return l_28_1 == 2 or l_28_1 == 3
end
(l_28_0)
if not Station.Lookup("Normal/TargetTargetShow") then
return 
end
local l_28_5 = nil
if not l_28_4 then
Station.Lookup("Normal/TargetTargetShow"):Lookup("", "Image_Target"):SetAlpha(255)
TargetTargetShow.modelView:UnloadModel()
return 
end
Station.Lookup("Normal/TargetTargetShow"):Lookup("", "Image_Target"):SetAlpha(0)
local l_28_6 = nil
l_28_5:Lookup("Show_Role"):Show()
local l_28_7 = nil
TargetTargetShow.modelView:SetCamera(SelfPortraitCameraInfo[l_28_4.nRoleType])
l_28_7:SetScene(TargetTargetShow.modelView.m_scene)
TargetTargetShow.modelView:UnloadModel()
local l_28_8 = nil
do
local l_28_9 = TargetTargetShow.modelView
l_28_9.m_aRoleAnimation = {Idle = 41}
l_28_9 = TargetTargetShow
l_28_9 = l_28_9.modelView
l_28_9(l_28_9, l_28_0, false)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_28_9(l_28_9)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_28_9(l_28_9, "Idle", "loop")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
RegisterEvent("BGFRAME_RESET", function()
local l_33_0 = Station.Lookup("Normal/TargetTargetShow")
if l_33_0 then
local l_33_1 = l_33_0:Lookup("", "")
local l_33_2 = l_33_1:Lookup("Image_Frame")
if PrettyShow.Options.bShowFrame then
  l_33_2:Show()
end
else
l_33_2:Hide()
end
end)
local l_0_42 = function(l_29_0)
-- upvalues: l_0_12
local l_29_1 = 1
if l_29_1 == 1 and l_29_1 == 1 then
l_29_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_29_3 = nil
local l_29_4 = function()
  -- upvalues: l_29_1
  return l_29_1 == 2 or l_29_1 == 3
end
(l_29_0)
if not Station.Lookup("Normal/TargetTargetShow") then
return 
end
local l_29_5 = nil
do
local l_29_6 = Station.Lookup("Normal/TargetTargetShow"):Lookup("", "Image_Target")
l_29_6:SetAlpha(255)
l_29_5:Lookup("Show_Role"):Hide()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
RegisterEvent("CUSTOM_DATA_LOADED", function()
-- upvalues: l_0_42 , l_0_41 , l_0_1
Wnd.CloseWindow("TargetTarget")
Wnd.CloseWindow("TargetTargetShow")
if not l_0_42 then
l_0_42 = PrettyShow.Options.TargetEnable ~= true or UpdateTargetTarget
end
UpdateTargetTarget = l_0_41
do return end
UpdateTargetTarget = l_0_42 or UpdateTargetTarget
local l_35_0 = l_0_1()
if not l_35_0 then
return 
end
local l_35_1, l_35_2 = l_35_0.GetTarget()
if l_35_1 == TARGET.PLAYER or l_35_1 == TARGET.NPC then
OpenTargetPanel(l_35_1, l_35_2)
end
end)
 -- DECOMPILER ERROR: Confused about usage of registers!

RegisterEvent("TARGET_ENABLE", function()
-- upvalues: l_0_42 , l_0_41 , l_0_1
Wnd.CloseWindow("TargetTarget")
Wnd.CloseWindow("TargetTargetShow")
if not l_0_42 then
l_0_42 = PrettyShow.Options.TargetEnable ~= true or UpdateTargetTarget
end
UpdateTargetTarget = l_0_41
do return end
UpdateTargetTarget = l_0_42 or UpdateTargetTarget
local l_35_0 = l_0_1()
if not l_35_0 then
return 
end
local l_35_1, l_35_2 = l_35_0.GetTarget()
if l_35_1 == TARGET.PLAYER or l_35_1 == TARGET.NPC then
OpenTargetPanel(l_35_1, l_35_2)
end
end)
local l_0_44 = function()
local l_30_0 = Station.Lookup("Normal/TargetTargetShow")
if l_30_0 then
local l_30_1 = l_30_0:Lookup("", "Image_Progress")
local l_30_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nCaster]
if l_30_1 and l_30_2 then
  l_30_1:FromUITex(l_30_2[1], l_30_2[2])
end
local l_30_3 = PrettyShow.Options.tCasterText[1]
local l_30_4 = PrettyShow.Options.tCasterText[2]
end
if l_30_3 and l_30_4 then
local l_30_5 = l_30_0:Lookup("", "Text_SkillName")
local l_30_6 = l_30_0:Lookup("", "Text_SkillTime")
l_30_5:SetFontScheme(l_30_3)
l_30_6:SetFontScheme(l_30_3)
l_30_5:SetFontColor(l_30_4[1], l_30_4[2], l_30_4[3])
l_30_6:SetFontColor(l_30_4[1], l_30_4[2], l_30_4[3])
end
end
RegisterEvent("BUFF_RESET", function()
local l_36_0 = Station.Lookup("Normal/TargetTargetShow")
if l_36_0 then
TargetTargetShow.UpdateBuff(l_36_0)
end
end)
local l_0_45 = function()
-- upvalues: l_0_13
local l_31_0 = Station.Lookup("Normal/TargetTargetShow")
if l_31_0 then
local l_31_1 = l_31_0:Lookup("", "")
if PrettyShow.Options.nMode == 1 then
  l_31_1:Lookup("Shadow_Health"):Hide()
  l_31_1:Lookup("Shadow_Mana"):Hide()
  l_31_1:Lookup("Image_Health"):Show()
  l_31_1:Lookup("Image_Mana"):Show()
  local l_31_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nHealthBar]
  if l_31_2 then
    l_31_1:Lookup("Image_Health"):FromUITex(l_31_2[1], l_31_2[2])
  end
  local l_31_3 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nManaBar]
  if l_31_3 then
    l_31_1:Lookup("Image_Mana"):FromUITex(l_31_3[1], l_31_3[2])
  end
else
  if PrettyShow.Options.nMode == 2 then
    l_31_1:Lookup("Image_Health"):Hide()
    l_31_1:Lookup("Image_Mana"):Hide()
    local l_31_4 = PrettyShow.Options.tHealthColor[1]
    l_31_1:Lookup("Shadow_Health"):SetColorRGB(l_31_4[1], l_31_4[2], l_31_4[3])
    local l_31_5 = PrettyShow.Options.tHealthColor[2]
    l_31_1:Lookup("Shadow_Mana"):SetColorRGB(l_31_5[1], l_31_5[2], l_31_5[3])
    l_31_1:Lookup("Shadow_Health"):Show()
    l_31_1:Lookup("Shadow_Mana"):Show()
  end
else
  if PrettyShow.Options.nMode == 3 then
    l_31_1:Lookup("Shadow_Health"):Show()
    l_31_1:Lookup("Shadow_Mana"):Show()
    l_31_1:Lookup("Image_Health"):Hide()
    l_31_1:Lookup("Image_Mana"):Hide()
    local l_31_6 = l_0_13(l_31_0.dwType, l_31_0.dwID)
    if l_31_6 then
      local l_31_7 = l_31_6.dwForceID
      if l_31_0.dwType == TARGET.NPC then
        l_31_7 = 999
      end
    end
    if l_31_7 then
      if not PrettyShow.Options.tForceColor[l_31_7] then
        local l_31_8, l_31_9, l_31_10, l_31_11 = {}
        l_31_9 = 0
        l_31_10 = 255
        l_31_11 = 0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_31_1:Lookup("Shadow_Health"):SetColorRGB(l_31_8[1], l_31_8[2], l_31_8[3])
    end
    local l_31_12 = PrettyShow.Options.tHealthColor[2]
    l_31_1:Lookup("Shadow_Mana"):SetColorRGB(l_31_12[1], l_31_12[2], l_31_12[3])
  end
else
  l_31_1:Lookup("Shadow_Health"):Show()
  l_31_1:Lookup("Shadow_Mana"):Show()
  l_31_1:Lookup("Image_Health"):Hide()
  l_31_1:Lookup("Image_Mana"):Hide()
  local l_31_13 = PrettyShow.Options.tHealthColor[2]
  l_31_1:Lookup("Shadow_Mana"):SetColorRGB(l_31_13[1], l_31_13[2], l_31_13[3])
end
local l_31_14 = l_31_0:Lookup("", "")
local l_31_15 = l_31_14:Lookup("Text_Health")
local l_31_16 = l_31_14:Lookup("Text_Mana")
if PrettyShow.Options.nHealthMode == 7 then
  l_31_15:SetHAlign(2)
  l_31_16:SetHAlign(2)
else
  l_31_15:SetHAlign(1)
  l_31_16:SetHAlign(1)
end
local l_31_17 = PrettyShow.Options.tHealth[1]
local l_31_18 = PrettyShow.Options.tHealth[2]
l_31_15:SetFontScheme(l_31_17)
l_31_15:SetFontColor(l_31_18[1], l_31_18[2], l_31_18[2])
l_31_16:SetFontScheme(l_31_17)
l_31_16:SetFontColor(l_31_18[1], l_31_18[2], l_31_18[2])
TargetTargetShow.UpdateLM(l_31_0)
end
end
RegisterEvent("FORCE_RESET", function()
if PrettyShow.Options.TargetEnable ~= true then
return 
end
local l_37_0 = Station.Lookup("Normal/TargetTargetShow")
if l_37_0 then
TargetTargetShow.UpdateHead(l_37_0)
end
end)
RegisterEvent("HEAD_ALPHA_RESET", function()
local l_32_0 = Station.Lookup("Normal/TargetTargetShow")
if l_32_0 then
local l_32_1 = l_32_0:Lookup("", "")
local l_32_2 = l_32_1:Lookup("Image_BgMidC")
end
if l_32_2 then
l_32_2:SetAlpha(PrettyShow.Options.Bg)
end
end)
RegisterEvent("CASTER_STYLE_RESET", l_0_44)
RegisterEvent("HEALTH_MODE_RESET", l_0_45)
do
RegisterEvent("FRAME_SIZE_RESET", function()
-- upvalues: l_0_41
if arg0 ~= "TargetTarget" then
return 
end
Wnd.CloseWindow("TargetTargetShow")
l_0_41()
end)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

