-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: QucikHotkey.lua 

local l_0_0 = {}
l_0_0.nNormalFrame = 53
l_0_0.nMouseOverFrame = 54
l_0_0.nDownFrame = 55
l_0_0.nDisableFrame = 56
l_0_0.nAutoModifiedFrame = 54
l_0_0.nSelfModifiedFrame = 56
l_0_0.nSelFrame = 55
l_0_0.nUnchangeableFrame = 56
local l_0_1 = false
local l_0_2 = {}
local l_0_3 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_5 = "�������"
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_8 = "�������"
local l_0_11 = "�Զ�������һ"
local l_0_13 = "�Զ���������"
local l_0_16 = function(l_5_0)
  for l_5_4 = 1, 4 do
    local l_5_5 = Station.Lookup("Lowest/ActionBar" .. l_5_4)
    if l_5_5 then
      local l_5_6 = l_5_5:Lookup("", "Handle_Text")
      for l_5_10 = 1, 16 do
        local l_5_11 = l_5_6:Lookup(l_5_10 .. "Key")
        local l_5_12 = l_5_11:GetText()
        if l_5_11 and l_5_12 == l_5_0 and not l_5_11.bSet then
          if not l_5_11.szOld then
            l_5_11.szOld = l_5_12
          end
          l_5_11:SetText("")
        elseif l_5_11.bSet then
          l_5_11.bSet = nil
        end
      end
    end
  end
end

local l_0_17 = function(l_6_0, l_6_1)
  -- upvalues: l_0_3 , l_0_8
  l_6_0.SetTextOrg(l_6_0, l_6_1)
  local l_6_2, l_6_3, l_6_4, l_6_5 = Hotkey.GetCaptureKey()
  l_6_1 = GetKeyShow(l_6_2, l_6_3, l_6_4, l_6_5, true)
  local l_6_6 = l_6_0:GetRoot()
  local l_6_7 = l_6_6:Lookup("", "Handle_List")
  local l_6_8 = (l_6_7:GetItemCount())
  local l_6_9 = nil
  for l_6_13 = 0, l_6_8 - 1 do
    local l_6_14 = l_6_7:Lookup(l_6_13)
    do
      if l_6_14 and l_6_14.bSel then
        local l_6_15 = l_6_14:Lookup("Text_Group"):GetText()
        for l_6_19,l_6_20 in ipairs(l_0_3) do
          if l_6_20 == l_6_15 then
            l_6_9 = l_6_19
            do break end
          end
        end
      end
    end
    if l_6_9 then
      do break end
    end
  end
  local l_6_21 = l_6_0:GetParent():GetParent():GetIndex()
  local l_6_22 = Station.Lookup("Lowest/ActionBar" .. l_6_9)
  local l_6_23 = l_6_22:Lookup("", "Handle_Text")
  local l_6_24 = l_6_23:Lookup(l_6_21 .. "Key")
  if l_6_24 then
    if not l_6_24.szOld then
      l_6_24.szOld = l_6_24:GetText()
    end
    l_6_24:SetText(l_6_1)
    l_6_24.bSet = true
    l_0_8(l_6_1)
  end
end

local l_0_18 = function(l_7_0)
  -- upvalues: l_0_6 , l_0_9
  if l_7_0.bSel then
    return false
  end
  local l_7_1 = l_7_0:GetParent()
  local l_7_2 = l_7_1:GetItemCount() - 1
  for l_7_6 = 0, l_7_2 do
    local l_7_7 = l_7_1:Lookup(l_7_6)
    if l_7_7.bSel then
      l_7_7.bSel = false
      if l_7_7.IsOver then
        l_7_7:Lookup("Image_Sel"):SetAlpha(128)
        l_7_7:Lookup("Image_Sel"):Show()
      end
    else
      l_7_7:Lookup("Image_Sel"):Hide()
    end
  end
  l_7_0.bSel = true
  l_7_0:Lookup("Image_Sel"):SetAlpha(255)
  l_7_0:Lookup("Image_Sel"):Show()
  l_0_6(l_7_0:GetParent():GetParent():Lookup("Handle_Hotkey"), l_7_0.nGroupIndex)
  local l_7_8 = l_7_0:GetRoot()
  local l_7_9 = l_7_8:Lookup("", "")
  local l_7_10 = l_7_9:Lookup("Handle_Hotkey")
  local l_7_11 = l_7_10:GetItemCount()
  for l_7_15 = 0, l_7_11 - 1 do
    local l_7_16 = l_7_10:Lookup(l_7_15)
    if l_7_16 and l_7_16:GetType() == "Handle" then
      local l_7_17 = l_7_16:Lookup("Handle_Key1")
      local l_7_18 = l_7_17:Lookup("Text_Key1")
      l_7_18.SetTextOrg = l_7_18.SetText
      l_7_18.SetText = l_0_9
    end
  end
end

local l_0_19 = function()
  local l_8_0 = Station.Lookup("Topmost/HotkeyPanel")
  local l_8_1 = l_8_0:Lookup("", "")
  local l_8_2 = l_8_1:Lookup("Handle_Hotkey")
  local l_8_3 = l_8_2:GetItemCount()
  for l_8_7 = 0, l_8_3 - 1 do
    local l_8_8 = l_8_2:Lookup(l_8_7)
    if l_8_8 and l_8_8:GetType() == "Handle" then
      local l_8_9 = l_8_8:Lookup("Handle_Key1")
      local l_8_10 = l_8_9:Lookup("Text_Key1")
    end
    if l_8_10.SetTextOrg then
      l_8_10.SetTextOrg = nil
      l_8_10.SetText = nil
    end
  end
end

do
  RegisterPlayerMenu("zhotkey", function()
  -- upvalues: l_0_1 , l_0_19 , l_0_20 , l_0_21
  local l_19_0 = {}
  l_19_0.szOption = "����������"
  local l_19_1 = {}
  l_19_1.szOption = "��ݼ���������"
  l_19_1.fnAction = function()
    -- upvalues: l_0_1 , l_0_19 , l_0_20 , l_0_21
    local l_20_2 = nil
    if l_0_1 then
      return 
    end
    if l_0_19() then
      local l_20_0 = MsgBox
      local l_20_1 = "���ȹرտ�ݼ�������塣"
      return l_20_0(l_20_1)
    end
    l_0_20()
    local l_20_3 = MessageBox
    local l_20_4 = {}
    l_20_4.szName = "QuickHotkey"
    l_20_4.fnCancelAction = l_0_21
    l_20_4.fnAction = l_0_21
    l_20_4.szMessage = "�������ڼ������ϣ�����ֱ�����ÿ�ݼ�"
    local l_20_5 = {}
    l_20_5.szOption = "���"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_20_3(l_20_4)
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  return l_19_1
  l_19_1 = {l_19_0}
end
)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

