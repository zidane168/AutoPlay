-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ChenYu_OptionFrame.lua 

ChenYu_OptionFrame_Base = class()
ChenYu_OptionFrame_Base.OnFrameCreate = function()
  this:RegisterEvent("CUSTOM_DATA_LOADED")
end

ChenYu_OptionFrame_Base.OnFrameBreathe = function()
end

ChenYu_OptionFrame_Base.OnLButtonClick = function()
  local l_3_0 = this:GetName()
  if l_3_0 == "Btn_Option" then
    local l_3_1 = {}
    for l_3_5,l_3_6 in ipairs(ChenYuOption) do
      l_3_6(l_3_1)
    end
    do
      local l_3_7, l_3_8 = {}
      l_3_7.szOption = "���ڳ�����ϵ��"
      l_3_7.bCheck = true
      l_3_8 = function()
      local l_4_0 = "������ϵ�н�������178���վ,��ӭ�κ�����뽨��(bbs.178.com)"
      local l_4_1, l_4_2 = Station.GetClientSize()
      local l_4_3 = {}
      l_4_3.x = l_4_1 / 2
      l_4_3.y = l_4_2 / 2
      l_4_3.szMessage = l_4_0
      l_4_3.szName = "����"
      local l_4_4 = {}
      l_4_4.szOption = g_tStrings.STR_HOTKEY_SURE
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_4_4 = MessageBox
      l_4_4(l_4_3)
      l_4_4 = GetPopupMenu
      l_4_4 = l_4_4()
      l_4_4(l_4_4)
    end
      l_3_7.fnAction = l_3_8
      l_3_8 = table
      l_3_8 = l_3_8.insert
      l_3_8(l_3_1, l_3_7)
      l_3_8 = #l_3_1
    end
    if l_3_8 > 0 then
      l_3_8 = PopupMenu
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_3_8(l_3_1)
  end
end

local l_0_0 = {}
l_0_0.nX = 300
l_0_0.nY = 400
ChenYu_OptionFrame_Pos = l_0_0
l_0_0 = RegisterCustomData
l_0_0("ChenYu_OptionFrame_Pos")
l_0_0 = ChenYu_OptionFrame_Base
l_0_0.OnFrameDragEnd = function()
  local l_4_0 = {}
  local l_4_1 = this:GetRelPos()
  l_4_0.nY = this
  l_4_0.nX = l_4_1
  l_4_1 = ChenYu_OptionFrame_Pos
  l_4_1.nX = l_4_0.nX
  l_4_1 = ChenYu_OptionFrame_Pos
  l_4_1.nY = l_4_0.nY
end

l_0_0 = ChenYu_OptionFrame_Base
l_0_0.OnEvent = function(l_5_0)
  if l_5_0 == "CUSTOM_DATA_LOADED" then
    if not Station.Lookup("Normal/ChenYu_OptionFrame_Center") then
      local l_5_1, l_5_2, l_5_3, l_5_4 = Wnd.OpenWindow("interface\\PrettyShow\\ChenYu_OptionFrame.ini", "ChenYu_OptionFrame_Center")
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_5_1:SetRelPos(ChenYu_OptionFrame_Pos.nX, ChenYu_OptionFrame_Pos.nY)
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_5_5 = nil
    l_5_1:Lookup("Wnd_Team", "Handle_TeamTitle/Text_TeamTitle"):SetText("����������")
  end
end

l_0_0 = Station
l_0_0 = l_0_0.Lookup
l_0_0 = l_0_0("Normal/ChenYu_OptionFrame_Center")
if not l_0_0 then
  l_0_0 = Wnd.OpenWindow("interface\\PrettyShow\\ChenYu_OptionFrame.ini", "ChenYu_OptionFrame_Center")
end

