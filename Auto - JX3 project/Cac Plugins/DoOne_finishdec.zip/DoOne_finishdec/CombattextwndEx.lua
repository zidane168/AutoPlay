-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: CombattextwndEx.lua 

COMBAT_TEXT_FADE_IN_FRAME = 4
COMBAT_TEXT_HOLD_FRAME = 20
COMBAT_TEXT_FADE_OUT_FRAME = 8
COMBAT_TEXT_IMMUNE_SCALE = 1
COMBAT_TEXT_BLOCK_SCALE = 1
COMBAT_TEXT_ABSORB_SCALE = 1
COMBAT_TEXT_SHIELD_SCALE = 1
COMBAT_TEXT_PARRY_SCALE = 1
COMBAT_TEXT_INSIGHT_SCALE = 1
local l_0_0 = {}
local l_0_1 = {}
local l_0_2 = {}
l_0_2.X = {}
l_0_2.Y = {}
local l_0_3 = {}
l_0_3.X = {}
l_0_3.Y = {}
local l_0_4 = {}
l_0_4.X = {}
l_0_4.Y = {}
local l_0_5 = {}
l_0_5.X = {}
l_0_5.Y = {}
local l_0_6 = {}
l_0_6.X = {}
l_0_6.Y = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_0.g_OtherCommonDamage = l_0_1
l_0_0.g_OtherCommonDamageScale, l_0_1 = l_0_1, {}
l_0_2 = 1
l_0_3 = 2
l_0_4 = 3
l_0_5 = 5
l_0_6 = 5
l_0_2 = 2.1
l_0_3 = 2.1
l_0_4 = 2.1
l_0_5 = 2.1
l_0_6 = 2.1
l_0_0.g_CriticalScale, l_0_1 = l_0_1, {l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, 3, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1, 2.1}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_SelfCommonDamage, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_SelfCriticalStrikeDamage, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
l_0_3 = -2
l_0_4 = -4
l_0_5 = -6
l_0_6 = -8
l_0_3 = -67
l_0_4 = -68
l_0_5 = -69
l_0_6 = -70
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -10, -12, -14, -16, -18, -20, -22, -24, -26, -28, -30, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, -51, -52, -53, -54, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64, -65, -66, l_0_3, l_0_4, l_0_5, l_0_6, -71, -72, -73, -74, -75, -76, -77, -78, -79, -80}
l_0_0.g_OtherCriticalStrikeDamage, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_Therapy, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_OtherTherapy, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_SelfDodge, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_SelfBlock, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_SelfAbsorb, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_SelfShield, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_SelfParry, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_SelfInsight, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_SelfMiss, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherDodge, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherBlock, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherAbsorb, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherShield, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherParry, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = -1
l_0_4 = -2
l_0_5 = -3
l_0_6 = -4
l_0_3 = -51
l_0_4 = -52
l_0_5 = -53
l_0_6 = -54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33, -34, -35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, l_0_3, l_0_4, l_0_5, l_0_6, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherInsight, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_0.g_OtherMiss, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_BuffPrompt, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
l_0_0.g_BuffImmunity, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 4
l_0_3 = 51
l_0_4 = 52
l_0_5 = 53
l_0_6 = 54
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, l_0_3, l_0_4, l_0_5, l_0_6, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_3 = 0
l_0_4 = 0
l_0_5 = 0
l_0_6 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, l_0_3, l_0_4, l_0_5, l_0_6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
l_0_0.g_SkillCastName, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_BowledTip, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_0.g_BowledScale, l_0_1 = l_0_1, {}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_ExpLog, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_0.g_ExpLogScale, l_0_1 = l_0_1, {}
l_0_0.g_ExpAlpha, l_0_1 = l_0_1, {}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_Stylish, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_2 = 1
l_0_3 = 1
l_0_4 = 2
l_0_5 = 3
l_0_6 = 3
l_0_2 = 1
l_0_3 = 1
l_0_4 = 1
l_0_5 = 1
l_0_6 = 1
l_0_0.g_StylishScale, l_0_1 = l_0_1, {l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, 4, 4, 3, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, 1, 1, 1, 1, 1, 1, 1, 1, 1}
l_0_2 = {}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_color, l_0_1 = l_0_1, {r = l_0_2, g = l_0_2, b = l_0_2}
l_0_2 = {}
l_0_2 = {}
l_0_0.g_KillPrompt, l_0_1 = l_0_1, {X = l_0_2, Y = l_0_2}
l_0_0.g_KillScale, l_0_1 = l_0_1, {}
l_0_0.g_MaxTraceNumber = 32
l_0_0.g_CurrentIndex = 1
l_0_0.g_CurrentNumber = 5
l_0_2 = false
l_0_3 = false
l_0_4 = false
l_0_5 = false
l_0_6 = false
l_0_0.g_CurrentFlagTable, l_0_1 = l_0_1, {l_0_2, l_0_3, l_0_4, l_0_5, l_0_6}
l_0_0.bOn = false
l_0_0.bDeath = false
l_0_0.bEffective = false
l_0_0.bImmunity = true
l_0_3 = 255
l_0_4 = 128
l_0_5 = 128
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 255
l_0_5 = 255
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 255
l_0_5 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 12
l_0_4 = 242
l_0_5 = 239
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 128
l_0_4 = 255
l_0_5 = 128
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 128
l_0_5 = 128
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 255
l_0_5 = 255
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 0
l_0_5 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_3 = 255
l_0_4 = 0
l_0_5 = 0
l_0_2 = {l_0_3, l_0_4, l_0_5}
l_0_0.DamageColor, l_0_1 = l_0_1, {SOLAR_MAGIC_DAMAGE = l_0_2, PHYSICS_DAMAGE = l_0_2, NEUTRAL_MAGIC_DAMAGE = l_0_2, LUNAR_MAGIC_DAMAGE = l_0_2, POISON_DAMAGE = l_0_2, REFLECTIED_DAMAGE = l_0_2, OTHER_DAMAGE = l_0_2, OTHERTOME_DAMAGE = l_0_2, DEATHE = l_0_2}
CombatTextWndEx = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "CombatTextWndEx.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatTextWndEx.bDeath"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatTextWndEx.bEffective"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatTextWndEx.bImmunity"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "CombatTextWndEx.DamageColor"
l_0_0(l_0_1)
l_0_0 = function()
  local l_1_0 = Station.Lookup("Lowest/CombatTextWnd")
  if l_1_0 then
    l_1_0.OnEvent = nil
  end
end

l_0_1 = function()
  local l_2_0 = Station.Lookup("Lowest/CombatTextWnd")
  if l_2_0 then
    l_2_0.OnEvent = function()
  end
  end
end

l_0_2 = CombatTextWndEx
l_0_3 = function()
  this:RegisterEvent("FIGHT_HINT")
  this:RegisterEvent("COMMON_HEALTH_TEXT")
  this:RegisterEvent("SKILL_EFFECT_TEXT")
  this:RegisterEvent("SKILL_MISS")
  this:RegisterEvent("SKILL_DODGE")
  this:RegisterEvent("SKILL_EFFECT_TEXT")
  this:RegisterEvent("SKILL_BUFF")
  this:RegisterEvent("BUFF_IMMUNITY")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("PLAYER_LEAVE_SCENE")
  local l_3_0 = this:Lookup("", "")
  if l_3_0 then
    l_3_0:Clear()
  end
  l_3_0.nUseCount = 0
  CombatTextWndEx.handle = l_3_0
  CombatTextWndEx.hFrame = this
  for l_3_4 = 1, CombatTextWndEx.g_MaxTraceNumber do
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamage[1].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[1].Y[l_3_4] = -30 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamage[1].X[l_3_4] = 0
        CombatTextWndEx.g_OtherCommonDamage[1].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherCommonDamage[1].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[1].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamage[2].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[2].Y[l_3_4] = -15 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamage[2].X[l_3_4] = 0
        CombatTextWndEx.g_OtherCommonDamage[2].Y[l_3_4] = -15 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherCommonDamage[2].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[2].Y[l_3_4] = -15 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamage[3].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[3].Y[l_3_4] = 0 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamage[3].X[l_3_4] = 0
        CombatTextWndEx.g_OtherCommonDamage[3].Y[l_3_4] = 0 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherCommonDamage[3].X[l_3_4] = 0
      CombatTextWndEx.g_OtherCommonDamage[3].Y[l_3_4] = 0 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamage[4].X[l_3_4] = 25
      CombatTextWndEx.g_OtherCommonDamage[4].Y[l_3_4] = -30 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamage[4].X[l_3_4] = 25
        CombatTextWndEx.g_OtherCommonDamage[4].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherCommonDamage[4].X[l_3_4] = 25
      CombatTextWndEx.g_OtherCommonDamage[4].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamage[5].X[l_3_4] = -25
      CombatTextWndEx.g_OtherCommonDamage[5].Y[l_3_4] = -30 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamage[5].X[l_3_4] = -25
        CombatTextWndEx.g_OtherCommonDamage[5].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherCommonDamage[5].X[l_3_4] = -25
      CombatTextWndEx.g_OtherCommonDamage[5].Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherCommonDamageScale[l_3_4] = 1.5
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherCommonDamageScale[l_3_4] = 1.5
      end
    else
      CombatTextWndEx.g_OtherCommonDamageScale[l_3_4] = (1 - l_3_4 / CombatTextWndEx.g_MaxTraceNumber) * 1.5 * CombatTextWndEx.g_MaxTraceNumber / (CombatTextWndEx.g_MaxTraceNumber - l_3_4)
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.4 then
      CombatTextWndEx.g_SelfCommonDamage.X[l_3_4] = -2 * l_3_4 * l_3_4 * 0.15 - 32
      CombatTextWndEx.g_SelfCommonDamage.Y[l_3_4] = l_3_4 * l_3_4 * 0.15 + 32
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_SelfCommonDamage.X[l_3_4] = -2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 - 32
        CombatTextWndEx.g_SelfCommonDamage.Y[l_3_4] = CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 + 32
      end
    else
      CombatTextWndEx.g_SelfCommonDamage.X[l_3_4] = -0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) - 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 - 32
      CombatTextWndEx.g_SelfCommonDamage.Y[l_3_4] = 0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) + CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 + 32
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.4 then
      CombatTextWndEx.g_SelfCriticalStrikeDamage.X[l_3_4] = -2 * l_3_4 - 16
      CombatTextWndEx.g_SelfCriticalStrikeDamage.Y[l_3_4] = l_3_4 + 16
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_SelfCriticalStrikeDamage.X[l_3_4] = -2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 - 16
        CombatTextWndEx.g_SelfCriticalStrikeDamage.Y[l_3_4] = CombatTextWndEx.g_MaxTraceNumber * 0.4 + 16
      end
    else
      CombatTextWndEx.g_SelfCriticalStrikeDamage.X[l_3_4] = -0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) - 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 - 16
      CombatTextWndEx.g_SelfCriticalStrikeDamage.Y[l_3_4] = 0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) + CombatTextWndEx.g_MaxTraceNumber * 0.4 + 16
    end
    CombatTextWndEx.g_SelfMiss.X[l_3_4] = l_3_4 + 8
    CombatTextWndEx.g_SelfMiss.Y[l_3_4] = 0.05 * l_3_4 * l_3_4 + 16
    CombatTextWndEx.g_Stylish.X[l_3_4] = 0
    CombatTextWndEx.g_Stylish.Y[l_3_4] = 0
    CombatTextWndEx.g_color.r[l_3_4] = l_3_4 / 48 * 255
    CombatTextWndEx.g_color.g[l_3_4] = 255 * (1 - l_3_4 / 48)
    CombatTextWndEx.g_color.b[l_3_4] = 255
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.4 then
      CombatTextWndEx.g_Therapy.X[l_3_4] = 2 * l_3_4 + 32
      CombatTextWndEx.g_Therapy.Y[l_3_4] = l_3_4 + 32
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_Therapy.X[l_3_4] = 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 + 32
        CombatTextWndEx.g_Therapy.Y[l_3_4] = CombatTextWndEx.g_MaxTraceNumber * 0.4 + 32
      end
    else
      CombatTextWndEx.g_Therapy.X[l_3_4] = 0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) + 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 + 32
      CombatTextWndEx.g_Therapy.Y[l_3_4] = 0.2 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.75) + CombatTextWndEx.g_MaxTraceNumber * 0.4 + 32
    end
    if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_OtherTherapy.X[l_3_4] = 0
      CombatTextWndEx.g_OtherTherapy.Y[l_3_4] = -30 - 1 * l_3_4 - 0.25 * l_3_4 * l_3_4
    else
      if l_3_4 <= CombatTextWndEx.g_MaxTraceNumber * 0.8 then
        CombatTextWndEx.g_OtherTherapy.X[l_3_4] = 0
        CombatTextWndEx.g_OtherTherapy.Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 1 * (l_3_4 - 0.2 * CombatTextWndEx.g_MaxTraceNumber)
      end
    else
      CombatTextWndEx.g_OtherTherapy.X[l_3_4] = 0
      CombatTextWndEx.g_OtherTherapy.Y[l_3_4] = -30 - 0.2 * CombatTextWndEx.g_MaxTraceNumber - 0.01 * CombatTextWndEx.g_MaxTraceNumber * CombatTextWndEx.g_MaxTraceNumber - 0.6 * CombatTextWndEx.g_MaxTraceNumber - 4 * (l_3_4 - CombatTextWndEx.g_MaxTraceNumber * 0.8)
    end
  end
  for l_3_8 = 1, 64 do
    if l_3_8 <= CombatTextWndEx.g_MaxTraceNumber * 0.6 then
      CombatTextWndEx.g_ExpLog.X[l_3_8] = 0
      CombatTextWndEx.g_ExpLog.Y[l_3_8] = 0
    else
      if l_3_8 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_ExpLog.X[l_3_8] = 0
        CombatTextWndEx.g_ExpLog.Y[l_3_8] = 0
      end
    else
      CombatTextWndEx.g_ExpLog.X[l_3_8] = 0
      CombatTextWndEx.g_ExpLog.Y[l_3_8] = 0
    end
  end
  for l_3_12 = 1, 64 do
    if l_3_12 <= CombatTextWndEx.g_MaxTraceNumber * 3 / CombatTextWndEx.g_MaxTraceNumber then
      CombatTextWndEx.g_ExpLogScale[l_3_12] = l_3_12
    else
      if l_3_12 <= CombatTextWndEx.g_MaxTraceNumber * 5 / CombatTextWndEx.g_MaxTraceNumber then
        CombatTextWndEx.g_ExpLogScale[l_3_12] = 4.5
      end
    else
      if l_3_12 <= CombatTextWndEx.g_MaxTraceNumber * 6 / CombatTextWndEx.g_MaxTraceNumber then
        CombatTextWndEx.g_ExpLogScale[l_3_12] = 2.8
      end
    else
      CombatTextWndEx.g_ExpLogScale[l_3_12] = 1.5
    end
  end
  for l_3_16 = 1, 64 do
    if l_3_16 <= CombatTextWndEx.g_MaxTraceNumber * 0.4 then
      CombatTextWndEx.g_SelfDodge.X[l_3_16] = -2 * l_3_16 * l_3_16 * 0.15 - 32
      CombatTextWndEx.g_SelfDodge.Y[l_3_16] = 0
    else
      if l_3_16 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_SelfDodge.X[l_3_16] = -2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 - 32
        CombatTextWndEx.g_SelfDodge.Y[l_3_16] = 0
      end
    else
      CombatTextWndEx.g_SelfDodge.X[l_3_16] = -0.2 * (l_3_16 - CombatTextWndEx.g_MaxTraceNumber * 0.75) - 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 - 32
      CombatTextWndEx.g_SelfDodge.Y[l_3_16] = 0
    end
  end
  for l_3_20 = 1, 64 do
    if l_3_20 <= CombatTextWndEx.g_MaxTraceNumber * 0.4 then
      CombatTextWndEx.g_BuffPrompt.X[l_3_20] = 2 * l_3_20 * l_3_20 * 0.15 + 32
      CombatTextWndEx.g_BuffPrompt.Y[l_3_20] = 0
    else
      if l_3_20 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_BuffPrompt.X[l_3_20] = 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 + 32
        CombatTextWndEx.g_BuffPrompt.Y[l_3_20] = 0
      end
    else
      CombatTextWndEx.g_BuffPrompt.X[l_3_20] = 0.2 * (l_3_20 - CombatTextWndEx.g_MaxTraceNumber * 0.75) + 2 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * CombatTextWndEx.g_MaxTraceNumber * 0.4 * 0.15 + 32
      CombatTextWndEx.g_BuffPrompt.Y[l_3_20] = 0
    end
  end
  for l_3_24 = 1, CombatTextWndEx.g_MaxTraceNumber do
    CombatTextWndEx.g_KillPrompt.X[l_3_24] = 0
    CombatTextWndEx.g_KillPrompt.Y[l_3_24] = -50
  end
  for l_3_28 = 1, CombatTextWndEx.g_MaxTraceNumber do
    if l_3_28 <= CombatTextWndEx.g_MaxTraceNumber * 0.2 then
      CombatTextWndEx.g_KillScale[l_3_28] = 0
    else
      CombatTextWndEx.g_KillScale[l_3_28] = 2
    end
  end
  for l_3_32 = 1, 48 do
    if l_3_32 <= 8 then
      CombatTextWndEx.g_ExpAlpha[l_3_32] = l_3_32 / 8 * 255
    elseif l_3_32 <= 40 then
      CombatTextWndEx.g_ExpAlpha[l_3_32] = 255
    else
      CombatTextWndEx.g_ExpAlpha[l_3_32] = (1 - (l_3_32 - 40) / 8) * 255
    end
  end
  for l_3_36 = 1, 64 do
    if l_3_36 <= CombatTextWndEx.g_MaxTraceNumber * 0.6 then
      CombatTextWndEx.g_BowledTip.X[l_3_36] = 0
      CombatTextWndEx.g_BowledTip.Y[l_3_36] = -70
    else
      if l_3_36 <= CombatTextWndEx.g_MaxTraceNumber * 0.75 then
        CombatTextWndEx.g_BowledTip.X[l_3_36] = 0
        CombatTextWndEx.g_BowledTip.Y[l_3_36] = -70
      end
    else
      CombatTextWndEx.g_BowledTip.X[l_3_36] = 0
      CombatTextWndEx.g_BowledTip.Y[l_3_36] = -70
    end
  end
  for l_3_40 = 1, 64 do
    if l_3_40 <= CombatTextWndEx.g_MaxTraceNumber * 3 / CombatTextWndEx.g_MaxTraceNumber then
      CombatTextWndEx.g_BowledScale[l_3_40] = l_3_40
    else
      if l_3_40 <= CombatTextWndEx.g_MaxTraceNumber * 8 / CombatTextWndEx.g_MaxTraceNumber then
        CombatTextWndEx.g_BowledScale[l_3_40] = 2.8
      end
    else
      if l_3_40 <= CombatTextWndEx.g_MaxTraceNumber * 9 / CombatTextWndEx.g_MaxTraceNumber then
        CombatTextWndEx.g_BowledScale[l_3_40] = 2.6
      end
    else
      CombatTextWndEx.g_BowledScale[l_3_40] = 1.5
    end
  end
end

l_0_2.OnFrameCreate = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_4_0)
  if l_4_0 < 4 then
    if CombatTextWndEx.g_CurrentFlagTable[4] then
      CombatTextWndEx.OnDisplace(4, l_4_0)
    else
      if CombatTextWndEx.g_CurrentFlagTable[5] then
        CombatTextWndEx.OnDisplace(5, l_4_0)
      end
    else
      CombatTextWndEx.g_CurrentFlagTable[l_4_0] = false
    end
  else
    CombatTextWndEx.g_CurrentFlagTable[l_4_0] = false
  end
end

l_0_2.SelectTrack = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_5_0, l_5_1, l_5_2)
  if not l_5_0 or not l_5_0:IsValid() or not l_5_1 or not l_5_2 then
    l_5_0.bDelete = true
    return 
  end
  local l_5_3 = l_5_0.nFrameCount
  local l_5_4 = l_5_0.Track.X[l_5_3 % CombatTextWndEx.g_MaxTraceNumber + 1]
  local l_5_5 = l_5_0.Track.Y[l_5_3 % CombatTextWndEx.g_MaxTraceNumber + 1]
  if not l_5_4 or not l_5_5 then
    l_5_0.bDelete = true
    return 
  end
  local l_5_6, l_5_7 = Station.AdjustToOriginalPos(l_5_1, l_5_2)
  local l_5_8 = l_5_4 * 3
  local l_5_9 = l_5_5 * 3
  local l_5_10 = l_5_0.fScale
  if l_5_0.aScale and l_5_0.aScale[l_5_3] then
    l_5_10 = l_5_0.aScale[l_5_3]
  end
  l_5_0.nFrameCount = l_5_3 + 2
  l_5_3 = l_5_3 + 2
  if CombatTextWndEx.g_MaxTraceNumber <= l_5_3 and l_5_0:GetName() == "SkillOtherCommondDamage" then
    CombatTextWndEx.g_CurrentIndex = 1
    CombatTextWndEx.SelectTrack(l_5_0.nFlag)
  end
  if l_5_10 ~= l_5_0.fScale then
    l_5_0.fScale = l_5_10
    l_5_0:SetFontScale(l_5_10)
    l_5_0:AutoSize()
  end
  local l_5_11 = (l_5_3) % CombatTextWndEx.g_MaxTraceNumber + 1
  if l_5_0.bChangeColor then
    local l_5_12, l_5_13, l_5_14 = l_5_0:GetFontColor()
    local l_5_15 = CombatTextWndEx.g_color.r[l_5_11]
    local l_5_16 = CombatTextWndEx.g_color.g[l_5_11]
    do
      local l_5_17 = CombatTextWndEx.g_color.b[l_5_11]
    if l_5_15 == l_5_12 and l_5_16 == l_5_13 then
      end
    if l_5_15 == l_5_12 then
      end
    end
    l_5_0:SetFontColor(l_5_15, l_5_16, l_5_17)
  end
  local l_5_18, l_5_19 = l_5_0:GetSize()
  l_5_6 = l_5_6 - l_5_18 / 2
  l_5_7 = l_5_7 - l_5_19 / 2
  local l_5_20 = l_5_6 + l_5_8
  local l_5_21 = l_5_7 + l_5_9
  if l_5_0:GetName() ~= "TextShow" then
    l_5_0:SetAbsPos(l_5_20, l_5_21)
  end
  local l_5_22 = COMBAT_TEXT_FADE_IN_FRAME
  local l_5_23 = COMBAT_TEXT_HOLD_FRAME
  local l_5_24 = COMBAT_TEXT_FADE_OUT_FRAME
  if l_5_0.Alpha then
    local l_5_25 = l_5_0.Alpha[l_5_3]
    if l_5_25 then
      l_5_0:SetAlpha(l_5_25)
    else
      l_5_0.bDelete = true
    end
  elseif l_5_3 < l_5_22 then
    l_5_0:SetAlpha(255 * (l_5_3) / l_5_22)
  elseif l_5_3 < l_5_22 + l_5_23 then
    l_5_0:SetAlpha(255)
  else
    if l_5_3 < l_5_22 + l_5_23 + l_5_24 then
      l_5_0:SetAlpha(255 * (1 - (l_5_3 - l_5_22 - l_5_23) / l_5_24))
    end
  else
    l_5_0.bDelete = true
  end
end

l_0_2.UpdateTextTrack = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function()
  local l_6_0 = CombatTextWndEx.handle
  local l_6_1 = #CombatTextWndEx.m_tTextQueue
  for l_6_5 = l_6_1, 1, -1 do
    local l_6_6 = CombatTextWndEx.m_tTextQueue[l_6_5]
    if not l_6_6.bDelete then
      local l_6_7 = l_6_6.nFrameCount
      local l_6_8 = l_6_6.Track.X[l_6_7 % CombatTextWndEx.g_MaxTraceNumber + 1]
      local l_6_9 = l_6_6.Track.Y[l_6_7 % CombatTextWndEx.g_MaxTraceNumber + 1]
      if l_6_8 and l_6_9 then
        if l_6_6.dwOwner == UI_GetClientPlayerID() then
          CombatTextWndEx.UpdateTextTrack(l_6_6, l_6_6.xScreen, l_6_6.yScreen)
        end
      else
        PostThreadCall(CombatTextWndEx.UpdateTextTrack, l_6_6, "Scene_ScenePointToScreenPoint", l_6_6.x, l_6_6.y, l_6_6.z)
      end
    else
      l_6_6.bDelete = true
    end
    if l_6_6.bDelete then
      l_6_6.bDelete = nil
      l_6_6.bFree = true
      l_6_6:Hide()
      l_6_0.nUseCount = l_6_0.nUseCount - 1
      table.remove(CombatTextWndEx.m_tTextQueue, l_6_5)
    end
  end
end

l_0_2.OnFrameBreathe = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_7_0)
  if l_7_0 == "FIGHT_HINT" then
    CombatTextWndEx.OnFightHint(l_7_0)
    do break end
  end
  if l_7_0 == "COMMON_HEALTH_TEXT" then
    CombatTextWndEx.OnCommonHealth(l_7_0)
    do break end
  end
  if l_7_0 == "SKILL_MISS" then
    CombatTextWndEx.OnSkillMiss(l_7_0)
    do break end
  end
  if l_7_0 == "SKILL_DODGE" then
    CombatTextWndEx.OnSkillDodge(l_7_0)
    do break end
  end
  if l_7_0 == "SKILL_EFFECT_TEXT" then
    CombatTextWndEx.OnSkillEffect(l_7_0)
    do break end
  end
  if l_7_0 == "SKILL_BUFF" then
    CombatTextWndEx.OnSkillBuff(l_7_0)
    do break end
  end
  if l_7_0 == "BUFF_IMMUNITY" and not CombatTextWndEx.bImmunity then
    CombatTextWndEx.OnBuffImmunity(l_7_0)
  end
  do break end
  if l_7_0 == "SYS_MSG" then
    if arg0 == "UI_OME_EXP_LOG" then
      CombatTextWndEx.OnExpLog(arg1, arg2)
      do break end
    end
    if arg0 == "UI_OME_SKILL_EFFECT_LOG" then
      CombatTextWndEx.OnSkillEffectLog(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
      do break end
    end
    if arg0 == "UI_OME_DEATH_NOTIFY" then
      CombatTextWndEx.OnDeathe(arg1, arg3)
    end
    do break end
  end
  if l_7_0 == "PLAYER_LEAVE_SCENE" then
    local l_7_1 = GetClientPlayer()
  if l_7_1 then
    end
  if l_7_1 then
    end
  end
  local l_7_2 = CombatTextWndEx.handle
  if l_7_2 then
    local l_7_3 = #CombatTextWndEx.m_tTextQueue
    for l_7_7 = l_7_3, 1, -1 do
      local l_7_8 = CombatTextWndEx.m_tTextQueue[l_7_7]
      l_7_8.bFree = true
      l_7_8:Hide()
      l_7_2.nUseCount = l_7_2.nUseCount - 1
      table.remove(CombatTextWndEx.m_tTextQueue, l_7_7)
    end
  end
end

l_0_2.OnEvent = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_8_0)
  local l_8_1 = 0
  local l_8_2 = SKILL_RESULT_TYPE.PHYSICS_DAMAGE
  local l_8_3 = l_8_0[SKILL_RESULT_TYPE.PHYSICS_DAMAGE]
  if l_8_3 and l_8_3 > 0 then
    l_8_1 = l_8_1 + l_8_3
  end
  local l_8_4 = l_8_0[SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE]
  if l_8_4 and l_8_4 > 0 then
    l_8_2 = SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE
    l_8_1 = l_8_1 + l_8_4
  end
  local l_8_5 = l_8_0[SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE]
  if l_8_5 and l_8_5 > 0 then
    l_8_2 = SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE
    l_8_1 = l_8_1 + l_8_5
  end
  local l_8_6 = l_8_0[SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE]
  if l_8_6 and l_8_6 > 0 then
    l_8_2 = SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE
    l_8_1 = l_8_1 + l_8_6
  end
  local l_8_7 = l_8_0[SKILL_RESULT_TYPE.POISON_DAMAGE]
  if l_8_7 and l_8_7 > 0 then
    l_8_2 = SKILL_RESULT_TYPE.POISON_DAMAGE
    l_8_1 = l_8_1 + l_8_7
  end
  return l_8_2, l_8_1
end

l_0_2.GetTotalDamage = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5, l_9_6, l_9_7, l_9_8)
  local l_9_9 = GetClientPlayer()
  if l_9_7 <= 2 then
    return 
  end
  local l_9_10, l_9_11 = CombatTextWndEx.GetTotalDamage(l_9_8)
  local l_9_12 = l_9_11
  if CombatTextWndEx.bEffective then
    l_9_12 = l_9_8[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
  end
  if l_9_12 and l_9_12 ~= nil and l_9_12 > 0 then
    CombatTextWndEx.OnSkillEffectDamage(l_9_0, l_9_1, l_9_3, l_9_6, l_9_10, l_9_12, l_9_4, l_9_5)
  end
  local l_9_13 = l_9_8[SKILL_RESULT_TYPE.THERAPY]
  if CombatTextWndEx.bEffective and not l_9_8[SKILL_RESULT_TYPE.EFFECTIVE_THERAPY] then
    l_9_13 = not l_9_13 or l_9_13 <= 0 or 0
  end
  CombatTextWndEx.OnSkillEffectTherapy(l_9_0, l_9_1, l_9_3, l_9_6, nil, l_9_13, l_9_4, l_9_5)
  local l_9_14 = l_9_8[SKILL_RESULT_TYPE.REFLECTIED_DAMAGE]
  if l_9_14 and l_9_14 > 0 then
    CombatTextWndEx.OnSkillEffectDamage(l_9_1, l_9_0, l_9_3, l_9_6, SKILL_RESULT_TYPE.REFLECTIED_DAMAGE, l_9_14, l_9_4, l_9_5)
  end
  local l_9_15 = l_9_8[SKILL_RESULT_TYPE.STEAL_LIFE]
  if l_9_15 and l_9_15 > 0 and l_9_0 == l_9_9.dwID then
    local l_9_16 = CombatTextWndEx.NewText(l_9_9.dwID, "͵ȡ���� " .. l_9_15, COMBAT_TEXT_PARRY_SCALE, false, "SkillDamageParry")
    if not l_9_16 then
      return 
    end
    l_9_16:SetFontColor(0, 255, 0)
    l_9_16.Track = CombatTextWndEx.g_SelfDodge
  end
  local l_9_17 = nil
  if l_9_3 == SKILL_EFFECT_TYPE.SKILL then
    l_9_17 = Table_GetSkillName(l_9_4, l_9_5)
  else
    if l_9_3 == SKILL_EFFECT_TYPE.BUFF then
      l_9_17 = Table_GetBuffName(l_9_4, l_9_5)
    end
  end
  local l_9_18 = l_9_8[SKILL_RESULT_TYPE.ABSORB_DAMAGE]
  if l_9_18 and l_9_18 > 0 and l_9_1 == l_9_9.dwID then
    local l_9_19 = CombatTextWndEx.NewText(l_9_9.dwID, "���� " .. l_9_17 .. " " .. l_9_18, COMBAT_TEXT_ABSORB_SCALE, false, "SkillDamageAbsorb")
    if not l_9_19 then
      return 
    end
    l_9_19:SetFontColor(255, 255, 255)
    l_9_19:SetFontScale(1)
    l_9_19:AutoSize()
    l_9_19.Track = CombatTextWndEx.g_SelfDodge
  end
  local l_9_20 = l_9_8[SKILL_RESULT_TYPE.SHIELD_DAMAGE]
  if l_9_20 and l_9_20 > 0 and l_9_1 == l_9_9.dwID then
    local l_9_21 = CombatTextWndEx.NewText(l_9_9.dwID, "���� " .. l_9_17 .. " " .. l_9_20, COMBAT_TEXT_ABSORB_SCALE, false, "SkillDamageShield")
    if not l_9_21 then
      return 
    end
    l_9_21:SetFontColor(255, 255, 255)
    l_9_21.Track = CombatTextWndEx.g_SelfDodge
  end
  local l_9_22 = l_9_8[SKILL_RESULT_TYPE.PARRY_DAMAGE]
  if l_9_22 and l_9_22 > 0 and l_9_1 == l_9_9.dwID then
    local l_9_23 = CombatTextWndEx.NewText(l_9_9.dwID, "���� " .. l_9_17 .. " " .. l_9_22, COMBAT_TEXT_PARRY_SCALE, false, "SkillDamageParry")
    if not l_9_23 then
      return 
    end
    l_9_23:SetFontColor(210, 200, 58)
    l_9_23.Track = CombatTextWndEx.g_SelfDodge
  end
  local l_9_24 = l_9_8[SKILL_RESULT_TYPE.INSIGHT_DAMAGE]
  if l_9_24 and l_9_24 > 0 and l_9_1 == l_9_9.dwID then
    local l_9_25 = CombatTextWndEx.NewText(l_9_9.dwID, "ʶ�� " .. l_9_17 .. " " .. l_9_24, COMBAT_TEXT_INSIGHT_SCALE, false, "SkillDamageInsight")
    if not l_9_25 then
      return 
    end
    l_9_25:SetFontColor(255, 255, 255)
    l_9_25.Track = CombatTextWndEx.g_SelfInsight
  end
end

l_0_2.OnSkillEffectLog = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_10_0)
  local l_10_1 = CombatTextWndEx.DamageColor
  local l_10_2 = nil
  if l_10_0 == SKILL_RESULT_TYPE.PHYSICS_DAMAGE then
    l_10_2 = l_10_1.PHYSICS_DAMAGE
  else
    if l_10_0 == SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE then
      l_10_2 = l_10_1.SOLAR_MAGIC_DAMAGE
    end
  else
    if l_10_0 == SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE then
      l_10_2 = l_10_1.NEUTRAL_MAGIC_DAMAGE
    end
  else
    if l_10_0 == SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE then
      l_10_2 = l_10_1.LUNAR_MAGIC_DAMAGE
    end
  else
    if l_10_0 == SKILL_RESULT_TYPE.POISON_DAMAGE then
      l_10_2 = l_10_1.POISON_DAMAGE
    end
  else
    if l_10_0 == SKILL_RESULT_TYPE.REFLECTIED_DAMAGE then
      l_10_2 = l_10_1.REFLECTIED_DAMAGE
    end
  else
    l_10_2 = l_10_1.OTHER_DAMAGE
  end
  local l_10_3 = unpack
  local l_10_4 = l_10_2
  return l_10_3(l_10_4)
end

l_0_2.GetSkillKindColor = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4, l_11_5, l_11_6, l_11_7)
  local l_11_8 = GetClientPlayer()
  local l_11_9 = GetClientPlayer().dwID
  local l_11_15, l_11_16, l_11_17 = l_11_9 == l_11_0, l_11_9 == l_11_1, nil
  local l_11_18 = nil
  local l_11_19 = nil
  local l_11_20 = 1
  local l_11_21, l_11_22 = nil, (GetClientPlayer())
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_11_2 == SKILL_EFFECT_TYPE.SKILL then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_11_2 ~= SKILL_EFFECT_TYPE.BUFF or IsPlayer(l_11_0) then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_11_16 then
    local l_11_23 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if nil then
      l_11_21 = nil.szName .. " " .. l_11_23 .. " -" .. l_11_5
    else
      l_11_21 = l_11_23 .. " -" .. l_11_5
    end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    if l_11_23 then
      l_11_21 = l_11_23 .. " " .. tostring(l_11_5)
    end
  end
  if l_11_4 == SKILL_RESULT_TYPE.REFLECTIED_DAMAGE then
    l_11_21 = "���� " .. l_11_21
  end
  if l_11_3 then
    l_11_21 = "���� " .. l_11_21
    if l_11_16 then
      local l_11_24 = nil
      if not CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage") then
        return 
      end
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetFontColor(l_11_17, l_11_18, l_11_19)
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_CriticalScale
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").Track = CombatTextWndEx.g_SelfCommonDamage
    elseif l_11_15 then
      local l_11_25 = nil
      if not CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage") then
        return 
      end
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetFontColor(l_11_17, l_11_18, l_11_19)
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_CriticalScale
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetName("SkillOtherCommondDamage")
      local l_11_26 = nil
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").nFlag = CombatTextWndEx.OnSelectTrace()
      CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").Track = CombatTextWndEx.g_OtherCommonDamage[CombatTextWndEx.OnSelectTrace()]
      CombatTextWndEx.g_CurrentFlagTable[CombatTextWndEx.OnSelectTrace()] = true
    end
  elseif l_11_16 then
    local l_11_27 = nil
    if not CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage") then
      return 
    end
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetFontColor(l_11_17, l_11_18, l_11_19)
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_OtherCommonDamageScale
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").Track = CombatTextWndEx.g_SelfCommonDamage
  elseif l_11_15 then
    local l_11_28 = nil
    if not CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage") then
      return 
    end
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetFontColor(l_11_17, l_11_18, l_11_19)
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_OtherCommonDamageScale
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage"):SetName("SkillOtherCommondDamage")
    local l_11_29 = nil
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").nFlag = CombatTextWndEx.OnSelectTrace()
    CombatTextWndEx.NewText(l_11_1, l_11_21, 1, false, "SkillDamage").Track = CombatTextWndEx.g_OtherCommonDamage[CombatTextWndEx.OnSelectTrace()]
    CombatTextWndEx.g_CurrentFlagTable[CombatTextWndEx.OnSelectTrace()] = true
  end
end

l_0_2.OnSkillEffectDamage = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_12_0, l_12_1, l_12_2, l_12_3, l_12_4, l_12_5, l_12_6, l_12_7)
  local l_12_8 = GetClientPlayer()
  local l_12_9 = l_12_8.dwID
  local l_12_15 = l_12_9 == l_12_0
  local l_12_16 = l_12_9 == l_12_1
  local l_12_17 = ""
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_12_2 == SKILL_EFFECT_TYPE.SKILL then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_12_2 ~= SKILL_EFFECT_TYPE.BUFF or IsPlayer(l_12_0) then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_12_15 and l_12_16 and nil then
    l_12_17 = nil.szName .. " " .. "" .. " +" .. l_12_5
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_12_17 = "" .. " +" .. l_12_5
  end
  if l_12_2 == SKILL_EFFECT_TYPE.BUFF then
    l_12_17 = "���� " .. l_12_17
  end
  if l_12_3 and l_12_3 ~= 0 then
    l_12_17 = "���� " .. l_12_17
  end
  if l_12_16 then
    local l_12_18 = nil
    if not CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy") then
      return 
    end
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy").aScale = CombatTextWndEx.g_OtherCommonDamageScale
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy"):SetFontColor(0, 255, 0)
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy").Track = CombatTextWndEx.g_Therapy
  elseif l_12_15 then
    local l_12_19 = nil
    if not CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy") then
      return 
    end
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy"):SetFontColor(0, 255, 0)
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy").aScale = CombatTextWndEx.g_OtherCommonDamageScale
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy"):SetName("SkillOtherCommondDamage")
    local l_12_20 = nil
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy").nFlag = CombatTextWndEx.OnSelectTrace()
    CombatTextWndEx.NewText(l_12_1, l_12_17, 1, false, "SkillTherapy").Track = CombatTextWndEx.g_OtherCommonDamage[CombatTextWndEx.OnSelectTrace()]
    CombatTextWndEx.g_CurrentFlagTable[CombatTextWndEx.OnSelectTrace()] = true
  end
end

l_0_2.OnSkillEffectTherapy = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_13_0, l_13_1)
  if not CombatTextWndEx.bDeath then
    return 
  end
  local l_13_2 = GetClientPlayer()
  local l_13_3 = "��ɱ"
  local l_13_4 = nil
  if l_13_2.szName == l_13_1 then
    if IsPlayer(l_13_0) then
      l_13_4 = GetPlayer(l_13_0)
    else
      l_13_4 = GetNpc(l_13_0)
    end
  end
  if l_13_4 then
    l_13_3 = l_13_3 .. "[" .. l_13_4.szName .. "]"
    CombatTextWndEx.ShowSkillMsg(l_13_3)
  end
end

l_0_2.OnDeathe = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function()
  local l_14_0 = false
  local l_14_1 = 1
  for l_14_5 = 1, CombatTextWndEx.g_CurrentNumber do
    if not CombatTextWndEx.g_CurrentFlagTable[l_14_5] then
      l_14_0 = true
      l_14_1 = l_14_5
      do break end
    end
  end
  if not l_14_0 then
    l_14_1 = CombatTextWndEx.g_CurrentIndex
    if CombatTextWndEx.g_CurrentNumber <= CombatTextWndEx.g_CurrentIndex then
      CombatTextWndEx.g_CurrentIndex = 1
    end
  else
    CombatTextWndEx.g_CurrentIndex = CombatTextWndEx.g_CurrentIndex + 1
  end
  return l_14_1
end

l_0_2.OnSelectTrace = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_15_0, l_15_1)
  local l_15_2 = Station.Lookup("Lowest/CombatTextWndEx", "")
  local l_15_3 = l_15_2:GetItemCount() - 1
  for l_15_7 = 0, l_15_3 do
    local l_15_8 = l_15_2:Lookup(l_15_7)
    if l_15_8:GetName() == "SkillOtherCommondDamage" and l_15_8.nFlag == l_15_0 then
      l_15_8.nFlag = l_15_1
      l_15_8.Track = CombatTextWndEx.g_OtherCommonDamage[l_15_1]
      CombatTextWndEx.g_CurrentFlagTable[l_15_0] = false
    end
  end
end

l_0_2.OnDisplace = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_16_0)
  local l_16_1 = arg0
  if l_16_1 then
    MiddleMap.bInFight = true
    OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.STR_MSG_ENTER_FIGHT)
  else
    MiddleMap.bInFight = false
    OutputMessage("MSG_ANNOUNCE_YELLOW", g_tStrings.STR_MSG_LEAVE_FIGHT)
  end
end

l_0_2.OnFightHint = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_17_0)
  local l_17_1 = GetTickCount()
  local l_17_2 = (l_17_0:GetItemCount())
  local l_17_3 = nil
  if l_17_0.nUseCount < l_17_2 then
    local l_17_4 = l_17_2 - 1
    for l_17_8 = 0, l_17_4 do
      local l_17_9 = l_17_0:Lookup(l_17_8)
      if l_17_9 and (l_17_9.bFree or not l_17_9.stime or l_17_9.stime < BigIntSub(l_17_1, 60000)) then
        l_17_9.bFree = false
        l_17_0.nUseCount = l_17_0.nUseCount + 1
        l_17_9.stime = l_17_1
        return l_17_9
      end
    end
  elseif l_17_2 >= 25 then
    return 
  end
  l_17_0:AppendItemFromString("<text> w=550 h=100 halign=1 valign=1 multiline=1 </text>")
  local l_17_10 = l_17_0:Lookup(l_17_2)
  l_17_10.bFree = false
  l_17_10.stime = l_17_1
  l_17_0.nUseCount = l_17_0.nUseCount + 1
  return l_17_10
end

l_0_2.GetFreeText = l_0_3
l_0_2 = CombatTextWndEx
l_0_2.m_tTextQueue, l_0_3 = l_0_3, {}
l_0_2 = CombatTextWndEx
l_0_3 = function(l_18_0, l_18_1, l_18_2, l_18_3, l_18_4, l_18_5)
  if not l_18_0 or not l_18_0:IsValid() then
    return 
  end
  l_18_0.stime = nil
  if not l_18_1 then
    l_18_0.bDelete = nil
    l_18_0.bFree = true
    l_18_0:Hide()
    CombatTextWndEx.handle.nUseCount = CombatTextWndEx.handle.nUseCount - 1
    return 
  end
  l_18_0:Show()
  l_18_0.x = l_18_3
  l_18_0.y = l_18_4
  l_18_0.z = l_18_5
  if l_18_0:GetName() ~= "TextShow" then
    local l_18_6, l_18_7 = l_18_0:GetSize()
    l_18_0.xScreen = l_18_1
    l_18_0.yScreen = l_18_2
    l_18_0:SetAbsPos(l_18_1 - l_18_6 / 2, l_18_2 - l_18_7 / 2)
  end
  table.insert(CombatTextWndEx.m_tTextQueue, l_18_0)
end

l_0_2.OnUpdateTextPos = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_19_0, l_19_1, l_19_2, l_19_3, l_19_4)
  local l_19_5 = CombatTextWndEx.handle
  local l_19_6 = CombatTextWndEx.GetFreeText(l_19_5)
  if not l_19_6 then
    return 
  end
  l_19_6:Hide()
  l_19_6:SetText(l_19_1)
  l_19_6:SetName(l_19_4)
  l_19_6:SetFontScheme(19)
  l_19_6:SetFontScale(1)
  l_19_6:SetFontScale(l_19_2)
  l_19_6:AutoSize()
  l_19_6.aScale = nil
  l_19_6.Track = nil
  l_19_6.Alpha = nil
  l_19_6.nFlag = nil
  l_19_6:SetAlpha(0)
  l_19_6.x = nil
  l_19_6.y = nil
  l_19_6.z = nil
  l_19_6.xScreen = nil
  l_19_6.yScreen = nil
  l_19_6.fScale = l_19_2
  l_19_6.dwOwner = l_19_0
  l_19_6.nFrameCount = 1
  l_19_6.bChangeColor = l_19_3
  if l_19_4 == "TextShow" then
    xScreen = Station.GetClientSize()
    l_19_6.xScreen = xScreen
    l_19_6.yScreen = yScreen
    l_19_6:SetAbsPos(xScreen * 3 / 4, yScreen / 4)
  end
  PostThreadCall(CombatTextWndEx.OnUpdateTextPos, l_19_6, "Scene_GetCharacterTopScreenPos", l_19_0)
  return l_19_6
end

l_0_2.NewText = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_20_0)
  local l_20_1 = arg0
  local l_20_2 = arg1
  if l_20_1 ~= GetClientPlayer().dwID then
    return 
  end
  if l_20_2 < 0 then
    CombatTextWndEx.OnSkillDamage(0, l_20_1, false, SKILL_RESULT_TYPE.PHYSICS_DAMAGE, -l_20_2)
  elseif l_20_2 > 0 then
    CombatTextWndEx.OnSkillTherapy(0, l_20_1, l_20_2)
  end
end

l_0_2.OnCommonHealth = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_21_0)
  local l_21_1 = GetClientPlayer().dwID
  local l_21_4 = l_21_1 == l_21_0
  do
    if not IsPlayer(l_21_0) then
      local l_21_5 = false
    end
    l_21_5 = not GetNpc(l_21_0) or l_21_1 == GetNpc(l_21_0).dwEmployer
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_21_4 or l_21_5 then
    return true
  end
  return false
end

l_0_2.IsClientCaster = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_22_0)
  local l_22_1 = GetClientPlayer().dwID
  local l_22_4 = l_22_1 == l_22_0
  do
    if not IsPlayer(l_22_0) then
      local l_22_5 = false
    end
    l_22_5 = not GetNpc(l_22_0) or l_22_1 == GetNpc(l_22_0).dwEmployer
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_22_4 or l_22_5 then
    return true
  end
  return false
end

l_0_2.IsClientTarget = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_23_0, l_23_1, l_23_2, l_23_3, l_23_4, l_23_5, l_23_6)
  OnDamageEventEx(l_23_1, l_23_4, l_23_2)
  local l_23_7 = CombatTextWndEx.IsClientCaster(l_23_0)
  local l_23_8 = (CombatTextWndEx.IsClientTarget(l_23_1))
  local l_23_9, l_23_10, l_23_11 = nil, nil, nil
  local l_23_12 = 1
  local l_23_13 = nil
  if l_23_8 then
    l_23_9 = 225
    l_23_13 = "-" .. l_23_4
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_23_9 = CombatTextWndEx.GetSkillKindColor(l_23_3)
    l_23_13 = tostring(l_23_4)
  end
  if l_23_2 then
    if l_23_8 then
      l_23_13 = function(l_24_0)
    -- upvalues: l_23_5 , l_23_2
    do
      local l_24_1 = Table_GetSkillName(l_23_5, 1) or ""
    end
    local l_24_2 = nil
    if not l_23_2 or l_24_2 ~= "" then
      return l_24_2 .. g_tStrings.STR_COLON .. g_tStrings.STR_CS_NAME .. " " .. l_24_0
    end
  end(l_23_13)
      do
        local l_23_15 = nil
        if not CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage") then
          return 
        end
        CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetFontColor(l_23_9, l_23_10, l_23_11)
        CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_CriticalScale
        CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").Track = CombatTextWndEx.g_SelfCommonDamage
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    elseif l_23_7 then
      l_23_13 = l_23_15(l_23_13)
      local l_23_16 = nil
      if not CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage") then
        return 
      end
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetFontColor(l_23_9, l_23_10, l_23_11)
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_CriticalScale
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetName("SkillOtherCommondDamage")
      local l_23_17 = nil
      l_23_17.nFlag = CombatTextWndEx.OnSelectTrace()
      l_23_17.Track = CombatTextWndEx.g_OtherCommonDamage[CombatTextWndEx.OnSelectTrace()]
      CombatTextWndEx.g_CurrentFlagTable[CombatTextWndEx.OnSelectTrace()] = true
    end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_23_8 then
    l_23_13 = l_23_16(l_23_13)
    do
      local l_23_18 = nil
      if not CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage") then
        return 
      end
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetFontColor(l_23_9, l_23_10, l_23_11)
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_OtherCommonDamageScale
      CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").Track = CombatTextWndEx.g_SelfCommonDamage
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_23_7 then
    l_23_13 = l_23_18(l_23_13)
    local l_23_19 = nil
    if not CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage") then
      return 
    end
    CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetFontColor(l_23_9, l_23_10, l_23_11)
    CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage").aScale = CombatTextWndEx.g_OtherCommonDamageScale
    CombatTextWndEx.NewText(l_23_1, l_23_13, 1, false, "SkillDamage"):SetName("SkillOtherCommondDamage")
    do
      local l_23_20 = nil
      l_23_20.nFlag = CombatTextWndEx.OnSelectTrace()
      l_23_20.Track = CombatTextWndEx.g_OtherCommonDamage[CombatTextWndEx.OnSelectTrace()]
      CombatTextWndEx.g_CurrentFlagTable[CombatTextWndEx.OnSelectTrace()] = true
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_2.OnSkillDamage = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_24_0)
  local l_24_1 = arg0
  local l_24_2 = arg1
  local l_24_3 = arg2
  local l_24_4 = arg3
  local l_24_5 = arg4
  local l_24_6 = arg5
  local l_24_7 = arg6
  if l_24_4 == SKILL_RESULT_TYPE.PHYSICS_DAMAGE or l_24_4 == SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE or l_24_4 == SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE or l_24_4 == SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE or l_24_4 == SKILL_RESULT_TYPE.POISON_DAMAGE then
    OnDamageEventEx(l_24_2, l_24_5, l_24_3)
  else
    if l_24_4 == SKILL_RESULT_TYPE.REFLECTIED_DAMAGE then
      OnDamageEventEx(l_24_1, l_24_5, l_24_3)
    end
  end
end

l_0_2.OnSkillEffect = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_25_0, l_25_1, l_25_2)
  local l_25_3 = CombatTextWndEx.IsClientCaster(l_25_0)
  local l_25_4 = CombatTextWndEx.IsClientTarget(l_25_1)
  local l_25_5 = "+" .. l_25_2
  if l_25_4 then
    local l_25_6 = CombatTextWndEx.NewText(l_25_1, l_25_5, 1, false, "SkillTherapy")
    if not l_25_6 then
      return 
    end
    l_25_6.aScale = CombatTextWndEx.g_OtherCommonDamageScale
    l_25_6:SetFontColor(0, 255, 0)
    l_25_6.Track = CombatTextWndEx.g_Therapy
  elseif l_25_3 or l_25_0 == 0 then
    local l_25_7 = CombatTextWndEx.NewText(l_25_1, l_25_5, 1, false, "SkillTherapy")
    if not l_25_7 then
      return 
    end
    l_25_7:SetFontColor(0, 255, 0)
    l_25_7.aScale = CombatTextWndEx.g_OtherCommonDamageScale
    l_25_7:SetName("SkillOtherCommondDamage")
    local l_25_8 = CombatTextWndEx.OnSelectTrace()
    l_25_7.nFlag = l_25_8
    l_25_7.Track = CombatTextWndEx.g_OtherCommonDamage[l_25_8]
    CombatTextWndEx.g_CurrentFlagTable[l_25_8] = true
  end
end

l_0_2.OnSkillTherapy = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_26_0, l_26_1)
  local l_26_2 = arg0
  local l_26_3 = arg1
  local l_26_4 = CombatTextWndEx.IsClientCaster(l_26_2)
  local l_26_5 = CombatTextWndEx.IsClientTarget(l_26_3)
  if l_26_5 then
    local l_26_6 = CombatTextWndEx.NewText(l_26_3, g_tStrings.STR_MSG_MISS, 1, false, "SkillMiss")
    if not l_26_6 then
      return 
    end
    l_26_6.Track = CombatTextWndEx.g_SelfDodge
    l_26_6:SetFontColor(230, 230, 230)
  elseif l_26_4 then
    local l_26_7 = CombatTextWndEx.NewText(l_26_3, g_tStrings.STR_MSG_MISS, 1, false, "SkillMiss")
    if not l_26_7 then
      return 
    end
    l_26_7:SetName("SkillOtherCommondDamage")
    local l_26_8 = CombatTextWndEx.OnSelectTrace()
    l_26_7.nFlag = l_26_8
    l_26_7:SetFontColor(255, 255, 255)
    l_26_7.Track = CombatTextWndEx.g_OtherCommonDamage[l_26_8]
    CombatTextWndEx.g_CurrentFlagTable[l_26_8] = true
  end
end

l_0_2.OnSkillMiss = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_27_0, l_27_1)
  local l_27_2 = arg0
  local l_27_3 = arg1
  local l_27_4 = CombatTextWndEx.IsClientCaster(l_27_2)
  local l_27_5 = CombatTextWndEx.IsClientTarget(l_27_3)
  if l_27_5 then
    local l_27_6 = CombatTextWndEx.NewText(l_27_3, g_tStrings.STR_MSG_DODGE, 1, false, "SkillDodge")
    if not l_27_6 then
      return 
    end
    l_27_6.Track = CombatTextWndEx.g_SelfDodge
    l_27_6:SetFontColor(216, 54, 4)
  elseif l_27_4 then
    local l_27_7 = CombatTextWndEx.NewText(l_27_3, g_tStrings.STR_MSG_DODGE, 1, false, "SkillDodge")
    if not l_27_7 then
      return 
    end
    l_27_7:SetName("SkillOtherCommondDamage")
    local l_27_8 = CombatTextWndEx.OnSelectTrace()
    l_27_7.nFlag = l_27_8
    l_27_7:SetFontColor(255, 255, 255)
    l_27_7.Track = CombatTextWndEx.g_OtherCommonDamage[l_27_8]
    CombatTextWndEx.g_CurrentFlagTable[l_27_8] = true
  end
end

l_0_2.OnSkillDodge = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_28_0)
  local l_28_1 = arg0
  local l_28_2 = arg1
  local l_28_3 = arg2
  local l_28_4 = arg3
  if not Table_BuffIsVisible(l_28_3, l_28_4) then
    return 
  end
  local l_28_5 = Table_GetBuffName(l_28_3, l_28_4)
  local l_28_6 = CombatTextWndEx.NewText(l_28_1, l_28_5, 1, false, "SkillBuff")
  if not l_28_6 then
    return 
  end
  if l_28_2 then
    l_28_6:SetFontColor(255, 255, 0)
  else
    l_28_6:SetFontColor(255, 0, 0)
  end
  l_28_6.Track = CombatTextWndEx.g_BuffPrompt
  l_28_6:SetFontScale(1)
  l_28_6:AutoSize()
end

l_0_2.OnSkillBuff = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_29_0)
  local l_29_1 = arg0
  local l_29_2 = CombatTextWndEx.NewText(l_29_1, g_tStrings.STR_MSG_IMMUNITY, COMBAT_TEXT_IMMUNE_SCALE, false, "BuffImmunity")
  if not l_29_2 then
    return 
  end
  l_29_2:SetFontColor(255, 255, 255)
  l_29_2.Track = CombatTextWndEx.g_SelfDodge
end

l_0_2.OnBuffImmunity = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_30_0, l_30_1)
  local l_30_2 = arg0
  local l_30_3 = arg1
  local l_30_4 = arg2
  local l_30_5 = ""
  local l_30_6 = IsPlayer(l_30_2)
  local l_30_7 = CombatTextWndEx.IsClientTarget(l_30_2)
  if not l_30_7 and Table_IsSkillCombatShow(l_30_3, l_30_4) then
    l_30_5 = Table_GetSkillName(l_30_3, l_30_4)
    local l_30_8 = CombatTextWndEx.NewText(l_30_2, l_30_5, COMBAT_TEXT_IMMUNE_SCALE, false, "SkillCast")
    if not l_30_8 then
      return 
    end
    l_30_8:SetFontColor(0, 128, 255)
    l_30_8:SetFontScale(1)
    l_30_8.Track = CombatTextWndEx.g_SkillCastName
  end
end

l_0_2.OnSkillCast = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = function(l_31_0, l_31_1)
  local l_31_2 = CombatTextWndEx.NewText(l_31_0, g_tStrings.STR_COMBATMSG_EXP .. l_31_1, 1, false, "Exp")
  if not l_31_2 then
    return 
  end
  l_31_2:SetFontColor(211, 10, 199)
  l_31_2.aScale = CombatTextWndEx.g_ExpLogScale
  l_31_2.Track = CombatTextWndEx.g_ExpLog
  l_31_2.Alpha = CombatTextWndEx.g_ExpAlpha
end

l_0_2.OnExpLog = l_0_3
l_0_2 = CombatTextWndEx
l_0_3 = "ShowSkillMsg"
l_0_4 = function(l_32_0)
  local l_32_1 = CombatTextWndEx.NewText(GetClientPlayer().dwID, l_32_0, 1, false, "kill")
  if not l_32_1 then
    return 
  end
  local l_32_2 = CombatTextWndEx.DamageColor.DEATHE
  local l_32_3, l_32_4, l_32_5 = unpack(l_32_2)
  l_32_1:SetFontColor(l_32_3, l_32_4, l_32_5)
  l_32_1.aScale = CombatTextWndEx.g_KillScale
  l_32_1.Track = CombatTextWndEx.g_KillPrompt
end

l_0_2[l_0_3] = l_0_4
l_0_2 = function(l_33_0, l_33_1, l_33_2)
  local l_33_3 = l_33_0:Lookup("", "Image_Health")
  local l_33_4 = l_33_0:Lookup("", "Image_SubHealth")
  local l_33_5 = l_33_3:GetPercentage()
  local l_33_6 = GetClientPlayer()
  if not l_33_6 or l_33_6.nMaxLife == 0 then
    l_33_4:SetPercentage(l_33_5)
    return 
  end
  local l_33_8 = l_33_4:GetPercentage()
  if l_33_8 - l_33_1 / l_33_6.nMaxLife < l_33_5 then
    l_33_8 = l_33_5
    do
      local l_33_7 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_33_8 = l_33_8 - l_33_7
  end
  l_33_4:SetPercentage(l_33_8)
end

l_0_3 = function(l_34_0, l_34_1, l_34_2)
  local l_34_3 = 1
  if l_34_0.nIntensity == 2 or l_34_0.nIntensity == 3 then
    l_34_3 = 2
  elseif l_34_0.nIntensity == 4 then
    l_34_3 = 3
  end
  local l_34_4, l_34_5 = nil, nil
  local l_34_6 = l_34_0:Lookup("", "Image_Health03")
  local l_34_7 = l_34_0:Lookup("", "Image_Health02")
  local l_34_8 = l_34_0:Lookup("", "Image_Health")
  if l_34_6 and l_34_6:IsVisible() then
    l_34_4 = l_34_6
    l_34_5 = l_34_0:Lookup("", "Image_SubHealth03")
  elseif l_34_7 and l_34_7:IsVisible() then
    l_34_4 = l_34_7
    l_34_5 = l_34_0:Lookup("", "Image_SubHealth02")
  else
    l_34_4 = l_34_8
    l_34_5 = l_34_0:Lookup("", "Image_SubHealth")
  end
  local l_34_9 = nil
  if l_34_0.dwType == TARGET.PLAYER then
    l_34_9 = GetPlayer(l_34_0.dwID)
  else
    if l_34_0.dwType == TARGET.NPC then
      l_34_9 = GetNpc(l_34_0.dwID)
    end
  end
  local l_34_10 = l_34_4:GetPercentage()
  if not l_34_9 or l_34_9.nMaxLife == 0 then
    l_34_5:SetPercentage(l_34_10)
    return 
  end
  local l_34_12 = l_34_5:GetPercentage()
  if l_34_12 - l_34_1 / l_34_9.nMaxLife % (1 / l_34_3) < l_34_10 then
    l_34_12 = l_34_10
    do
      local l_34_11 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_34_12 = l_34_12 - l_34_11
  end
  l_34_5:SetPercentage(l_34_12)
end

l_0_4 = function(l_35_0, l_35_1, l_35_2)
  local l_35_3 = l_35_0:Lookup("", "Image_Health")
  local l_35_4 = l_35_0:Lookup("", "Image_SubHealth")
  local l_35_5 = (l_35_3:GetPercentage())
  local l_35_6 = nil
  if l_35_0.dwType == TARGET.PLAYER then
    l_35_6 = GetPlayer(l_35_0.dwID)
  else
    if l_35_0.dwType == TARGET.NPC then
      l_35_6 = GetNpc(l_35_0.dwID)
    end
  end
  local l_35_7 = l_35_3:GetPercentage()
  if not l_35_6 or l_35_6.nMaxLife == 0 then
    l_35_4:SetPercentage(l_35_7)
    return 
  end
  local l_35_9 = l_35_4:GetPercentage()
  if l_35_9 - l_35_1 / l_35_6.nMaxLife < l_35_7 then
    l_35_9 = l_35_7
    do
      local l_35_8 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_35_9 = l_35_9 - l_35_8
  end
  l_35_4:SetPercentage(l_35_9)
end

l_0_5 = function(l_36_0, l_36_1, l_36_2)
  -- upvalues: l_0_2 , l_0_3 , l_0_4
  local l_36_3 = GetClientPlayer()
  if l_36_3.dwID == l_36_0 then
    l_0_2(Station.Lookup("Normal/Player"), l_36_1, l_36_2)
  end
  local l_36_4 = Station.Lookup("Normal/Target")
  if l_36_4 and l_36_4:IsVisible() and l_36_4.dwID == l_36_0 then
    l_0_3(l_36_4, l_36_1, l_36_2)
  end
  local l_36_5 = Station.Lookup("Normal/TargetTarget")
  if l_36_5 and l_36_5:IsVisible() and l_36_5.dwID == l_36_0 then
    l_0_4(l_36_5, l_36_1, l_36_2)
  end
end

OnDamageEventEx = l_0_5
l_0_5 = CombatTextWndEx
l_0_6 = "Create"
l_0_5[l_0_6] = function(l_37_0)
  -- upvalues: l_0_1 , l_0_0
  local l_37_1 = l_37_0:Lookup("", "")
  BoxBoolCheckBox(l_37_0, "CheckBox_bEffective", "�����˺���ʽ", CombatTextWndEx, "bOn", function()
    -- upvalues: l_0_1
    l_0_1()
    Wnd.OpenWindow("interface/Moon_CombatTextWndEx/CombatTextWndEx.ini", "CombatTextWndEx")
  end, function()
    -- upvalues: l_0_0
    Wnd.CloseWindow("CombatTextWndEx")
    l_0_0()
  end)
  BoxBoolCheckBox(l_37_0, "CheckBox_bEffective", "��ʾ��Ч�˺�", CombatTextWndEx, "bEffective"):SetRelPos(150, 0)
  BoxBoolCheckBox(l_37_0, "CheckBox_bDeath", "��ʾ��ɱ��Ϣ", CombatTextWndEx, "bDeath"):SetRelPos(300, 0)
  BoxBoolCheckBox(l_37_0, "CheckBox_bImmunity", "����������Ϣ", CombatTextWndEx, "bImmunity"):SetRelPos(0, 30)
  local l_37_2 = BoxLabel
  local l_37_3 = l_37_1
  local l_37_4 = "label1"
  local l_37_5 = "�˺���ʽ��ɫ"
  local l_37_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_37_2(l_37_3, l_37_4, l_37_5, l_37_6, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_37_7 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_37_8 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_37_9 = {}
  do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_37_10 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    do
      local l_37_11 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_37_6,l_37_7 in l_37_3 do
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_37_12 = {}
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_37_8(l_37_9, l_37_10, l_37_11, l_37_12)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      do
        local l_37_13 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        for i_1,l_37_8 in pairs({
{l_37_5, l_37_6, 92}, 
{"SOLAR_MAGIC_DAMAGE", 200, l_37_8}, 
{"LUNAR_MAGIC_DAMAGE", l_37_8, l_37_9}, 
{l_37_8, l_37_9, l_37_10}, l_37_8, l_37_9, l_37_10, l_37_11, l_37_13}) do
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          local l_37_14 = "DEATHE"
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_37_15 = 330
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_37_16 = 152
          local l_37_17 = "Shadow_" .. i_1
          local l_37_19 = function(l_40_0)
        -- upvalues: l_37_9
        OpenColorTablePanel(function(l_41_0, l_41_1, l_41_2)
          -- upvalues: l_3_0 , l_37_9
          l_3_0:SetColorRGB(l_41_0, l_41_1, l_41_2)
          local l_41_3 = CombatTextWndEx.DamageColor
          local l_41_4 = l_37_9
          do
            local l_41_5 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end)
      end
          local l_37_20 = {l_37_8[2], l_37_8[3]}
          local l_37_21 = {18, 18}
          local l_37_22 = {}
          l_37_22.tRGB = {l_37_11, R23_PC202, l_37_14}
          l_37_22.szColor = "white"
          l_37_15(l_37_16, l_37_17, l_37_19, l_37_20, l_37_21, l_37_22)
        end
        BoxButton(l_37_0, "Btn_DefaultColor", {txt = "Ĭ����ɫ", x = 0, y = 185}):OnClick(function()
      -- upvalues: l_37_3 , l_37_1
      local l_41_0 = CombatTextWndEx
      local l_41_1 = {}
      local l_41_2 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_41_1.PHYSICS_DAMAGE, l_41_2 = l_41_2, {255, 128, 128}
      l_41_1.NEUTRAL_MAGIC_DAMAGE, l_41_2 = l_41_2, {255, 255, 0}
      l_41_1.LUNAR_MAGIC_DAMAGE, l_41_2 = l_41_2, {12, 242, 239}
      l_41_1.POISON_DAMAGE, l_41_2 = l_41_2, {128, 255, 128}
      l_41_1.REFLECTIED_DAMAGE, l_41_2 = l_41_2, {255, 128, 128}
      l_41_1.OTHER_DAMAGE, l_41_2 = l_41_2, {255, 255, 255}
      l_41_1.OTHERTOME_DAMAGE, l_41_2 = l_41_2, {255, 0, 0}
      l_41_1.DEATHE, l_41_2 = l_41_2, {255, 0, 0}
      l_41_0.DamageColor = l_41_1
      l_41_0 = pairs
      l_41_1 = l_37_3
      l_41_0 = l_41_0(l_41_1)
      for i_1,i_2 in l_41_0 do
        local l_41_5 = l_41_4[1]
        local l_41_6 = CombatTextWndEx.DamageColor[l_41_5]
        local l_41_7, l_41_8, l_41_9 = unpack(l_41_6)
        local l_41_10 = "Shadow_" .. l_41_3
        local l_41_11 = l_37_1:Lookup("Handle_" .. l_41_10)
        if l_41_11 then
          local l_41_12 = l_41_11:Lookup(l_41_10)
          local l_41_13, l_41_14, l_41_15 = unpack(l_41_6)
          l_41_12:SetColorRGB(l_41_13, l_41_14, l_41_15)
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end)
      end
      l_37_1:FormatAllItemPos()
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_5 = RegisterMoonButton
l_0_6 = "ComBatTextWndEx"
l_0_5(l_0_6, 639, "�˺���ʽ", "General", CombatTextWndEx.Create)
l_0_5 = RegisterEvent
l_0_6 = "AddonLoad"
l_0_5(l_0_6, function()
  -- upvalues: l_0_1
  if CombatTextWndEx.bOn then
    l_0_1()
    Wnd.OpenWindow("interface/Moon_CombatTextWndEx/CombatTextWndEx.ini", "CombatTextWndEx")
  end
end
)

