-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Durability.lua 

Moon_Durability = {}
CharacterPanel_GetPageBattle = function()
  local l_1_0 = Station.Lookup
  local l_1_1 = "Normal/CharacterPanel/Page_Main/Page_Battle"
  return l_1_0(l_1_1)
end

CharacterPanel_GetEquipBox = function(l_2_0, l_2_1)
  local l_2_6, l_2_7, l_2_12, l_2_13, l_2_18, l_2_19, l_2_24, l_2_25, l_2_30, l_2_31, l_2_36, l_2_37, l_2_42, l_2_43, l_2_48, l_2_49, l_2_54, l_2_55, l_2_60, l_2_61 = nil
  if l_2_1 == EQUIPMENT_INVENTORY.HELM then
    local l_2_2, l_2_3 = l_2_0:Lookup, l_2_0
    local l_2_4 = "Wnd_Equit"
    local l_2_5 = "Box_Helm"
    return l_2_2(l_2_3, l_2_4, l_2_5)
  else
    if l_2_1 == EQUIPMENT_INVENTORY.CHEST then
      local l_2_8, l_2_9 = l_2_0:Lookup, l_2_0
      local l_2_10 = "Wnd_Equit"
      local l_2_11 = "Box_Chest"
      return l_2_8(l_2_9, l_2_10, l_2_11)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.BANGLE then
      local l_2_14, l_2_15 = l_2_0:Lookup, l_2_0
      local l_2_16 = "Wnd_Equit"
      local l_2_17 = "Box_Bangle"
      return l_2_14(l_2_15, l_2_16, l_2_17)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.WAIST then
      local l_2_20, l_2_21 = l_2_0:Lookup, l_2_0
      local l_2_22 = "Wnd_Equit"
      local l_2_23 = "Box_Waist"
      return l_2_20(l_2_21, l_2_22, l_2_23)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.PANTS then
      local l_2_26, l_2_27 = l_2_0:Lookup, l_2_0
      local l_2_28 = "Wnd_Equit"
      local l_2_29 = "Box_Pants"
      return l_2_26(l_2_27, l_2_28, l_2_29)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.BOOTS then
      local l_2_32, l_2_33 = l_2_0:Lookup, l_2_0
      local l_2_34 = "Wnd_Equit"
      local l_2_35 = "Box_Boots"
      return l_2_32(l_2_33, l_2_34, l_2_35)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.AMULET then
      local l_2_38, l_2_39 = l_2_0:Lookup, l_2_0
      local l_2_40 = "Wnd_Equit"
      local l_2_41 = "Box_Amulet"
      return l_2_38(l_2_39, l_2_40, l_2_41)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.PENDANT then
      local l_2_44, l_2_45 = l_2_0:Lookup, l_2_0
      local l_2_46 = "Wnd_Equit"
      local l_2_47 = "Box_Pendant"
      return l_2_44(l_2_45, l_2_46, l_2_47)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.LEFT_RING then
      local l_2_50, l_2_51 = l_2_0:Lookup, l_2_0
      local l_2_52 = "Wnd_Equit"
      local l_2_53 = "Box_LeftRing"
      return l_2_50(l_2_51, l_2_52, l_2_53)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.RIGHT_RING then
      local l_2_56, l_2_57 = l_2_0:Lookup, l_2_0
      local l_2_58 = "Wnd_Equit"
      local l_2_59 = "Box_RightRing"
      return l_2_56(l_2_57, l_2_58, l_2_59)
    end
  end
  local l_2_62 = l_2_0:Lookup("Wnd_Weapon")
  local l_2_63 = l_2_0:Lookup("Wnd_CangJian")
  if l_2_62:IsVisible() then
    if l_2_1 == EQUIPMENT_INVENTORY.MELEE_WEAPON then
      local l_2_64, l_2_65 = l_2_62:Lookup, l_2_62
      local l_2_66 = ""
      local l_2_67 = "Box_MeleeWeapon"
      return l_2_64(l_2_65, l_2_66, l_2_67)
    else
      if l_2_1 == EQUIPMENT_INVENTORY.RANGE_WEAPON then
        local l_2_68, l_2_69 = l_2_62:Lookup, l_2_62
        local l_2_70 = ""
        local l_2_71 = "Box_RangeWeapon"
        return l_2_68(l_2_69, l_2_70, l_2_71)
      end
    else
      if l_2_1 == EQUIPMENT_INVENTORY.ARROW then
        local l_2_72, l_2_73 = l_2_62:Lookup, l_2_62
        local l_2_74 = ""
        local l_2_75 = "Box_AmmoPouch"
        return l_2_72(l_2_73, l_2_74, l_2_75)
      end
    end
  else
    if l_2_63:IsVisible() then
      if l_2_1 == EQUIPMENT_INVENTORY.MELEE_WEAPON then
        local l_2_76, l_2_77 = l_2_63:Lookup, l_2_63
        local l_2_78 = ""
        local l_2_79 = "Box_LightSword"
        return l_2_76(l_2_77, l_2_78, l_2_79)
      end
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.BIG_SWORD then
      local l_2_80, l_2_81 = l_2_63:Lookup, l_2_63
      local l_2_82 = ""
      local l_2_83 = "Box_HeavySword"
      return l_2_80(l_2_81, l_2_82, l_2_83)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.RANGE_WEAPON then
      local l_2_84, l_2_85 = l_2_63:Lookup, l_2_63
      local l_2_86 = ""
      local l_2_87 = "Box_RangeWeaponCJ"
      return l_2_84(l_2_85, l_2_86, l_2_87)
    end
  else
    if l_2_1 == EQUIPMENT_INVENTORY.ARROW then
      local l_2_88, l_2_89 = l_2_63:Lookup, l_2_63
      local l_2_90 = ""
      local l_2_91 = "Box_AmmoPouchCJ"
      return l_2_88(l_2_89, l_2_90, l_2_91)
    end
  end
end

Moon_Durability.UpdateEquipItem = function(l_3_0)
  local l_3_1 = GetClientPlayer()
  if not l_3_1 then
    return 
  end
  local l_3_2 = CharacterPanel_GetPageBattle()
  if not l_3_2 then
    return 
  end
  local l_3_3 = CharacterPanel_GetEquipBox(l_3_2, l_3_0)
  if not l_3_3 then
    return 
  end
  local l_3_4 = l_3_1.GetItem(INVENTORY_INDEX.EQUIP, l_3_0)
  if l_3_4 then
    local l_3_5 = l_3_4.nCurrentDurability / l_3_4.nMaxDurability
    local l_3_6 = 16
    if l_3_5 <= 0.2 then
      l_3_6 = 159
    elseif l_3_5 <= 0.7 then
      l_3_6 = 168
    end
    l_3_3:SetOverText(0, math.floor(l_3_5 * 100) .. "%")
    l_3_3:SetOverTextFontScheme(0, l_3_6)
  end
end

Moon_Durability.UpdateAllBox = function()
  do
    local l_4_0 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_4_4,l_4_5 in EQUIPMENT_INVENTORY.MELEE_WEAPON(EQUIPMENT_INVENTORY.RANGE_WEAPON) do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      EQUIPMENT_INVENTORY.PANTS.UpdateEquipItem(EQUIPMENT_INVENTORY.BOOTS)
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end

RegisterEvent("EQUIP_ITEM_UPDATE", function()
  if arg0 == INVENTORY_INDEX.EQUIP then
    Moon_Durability.UpdateAllBox()
  end
end
)
RegisterEvent("LOADING_END", Moon_Durability.UpdateAllBox)
RegisterEvent("SKILL_MOUNT_KUNG_FU", Moon_Durability.UpdateAllBox)
RegisterEvent("EQUIP_CHANGE", Moon_Durability.UpdateAllBox)
RegisterEvent("UNEQUIPALL", Moon_Durability.UpdateAllBox)
RegisterEvent("SYNC_EQUIPID_ARRAY", Moon_Durability.UpdateAllBox)
RegisterEvent("CURRENT_PLAYER_FORCE_CHANGED", Moon_Durability.UpdateAllBox)
local l_0_0 = RegisterFrameHook
local l_0_1 = "update_durability"
local l_0_2 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1, l_0_2, "Normal/CharacterPanel", Moon_Durability.UpdateAllBox)

