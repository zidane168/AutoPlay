-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: UpdateManager.lua 

local l_0_0 = 5
local l_0_1 = 5
local l_0_2 = 64
local l_0_3 = 45
local l_0_4 = 10
local l_0_5 = 8
local l_0_6 = 28
local l_0_7 = 24
local l_0_8 = "interface\\RaidGridEx\\RaidGridEx.ini"
RaidGridEx.AutoScalePanel = function()
  -- upvalues: l_0_5 , l_0_0 , l_0_1 , l_0_2 , l_0_4 , l_0_3 , l_0_7 , l_0_6
  local l_1_0 = GetClientTeam()
  local l_1_1 = l_1_0.nGroupNum
  local l_1_2 = RaidGridEx.IsInRaid()
  if not RaidGridEx.bAutoScalePanel or RaidGridEx.bDrag then
    local l_1_3 = l_0_5
    for l_1_7 = 0, l_0_0 - 1 do
      local l_1_8 = RaidGridEx.hRoles:Lookup("Text_Group_" .. l_1_7)
      if l_1_2 and RaidGridEx.bShowNumber then
        l_1_3 = l_0_5 + 12
        l_1_8:SetText(NumberToChinese(l_1_7 + 1))
        l_1_8:Show()
      else
        l_1_8:Hide()
      end
      for l_1_12 = 1, l_0_1 do
        local l_1_13 = RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_1_7 .. "_" .. l_1_12)
        if l_1_13 then
          if l_1_1 - 1 < l_1_7 then
            l_1_13:Hide()
          end
        else
          l_1_13:SetRelPos((l_1_7 * l_0_2 + l_0_4) * RaidGridEx.fScale, ((l_1_12 - 1) * l_0_3 + l_0_5) * RaidGridEx.fScale)
          l_1_13:Show()
        end
      end
      l_1_8:SetRelPos((l_1_7 * l_0_2 + l_0_4) * RaidGridEx.fScale, 5 * l_0_3 * RaidGridEx.fScale)
    end
    RaidGridEx.hBg:Lookup("Image_Title_BG"):SetSize((l_1_1 * l_0_2 + l_0_4) * RaidGridEx.fScale, l_0_7)
    RaidGridEx.hBg:Lookup("Image_BG"):SetSize((l_1_1 * l_0_2 + l_0_4) * RaidGridEx.fScale, (l_0_1 * l_0_3 + (l_1_3)) * RaidGridEx.fScale)
    RaidGridEx.frame:SetSize((l_1_1 * l_0_2 + l_0_4) * RaidGridEx.fScale, (l_0_1 * l_0_3 + l_0_6 + (l_1_3)) * RaidGridEx.fScale)
    RaidGridEx.frame:SetDragArea(0, 0, (l_1_1 * l_0_2 + l_0_4) * RaidGridEx.fScale, 25)
  else
    local l_1_14 = 0
    local l_1_15 = 0
    local l_1_16 = 0
    local l_1_17 = l_0_5
    for l_1_21 = 0, l_0_0 - 1 do
      local l_1_22 = true
      local l_1_23 = RaidGridEx.hRoles:Lookup("Text_Group_" .. l_1_21)
      l_1_23:SetText(NumberToChinese(l_1_21 + 1))
      l_1_23:Hide()
      l_1_23.bShow = false
      l_1_23.nX = 0
      for l_1_27 = 1, l_0_0 do
        local l_1_28 = RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_1_21 .. "_" .. l_1_27)
        l_1_28:SetRelPos(((l_1_21 + l_1_16) * l_0_2 + l_0_4) * RaidGridEx.fScale, ((l_1_27 - 1) * l_0_3 + l_0_5) * RaidGridEx.fScale)
        if l_1_28.dwMemberID then
          l_1_14 = math.max(l_1_14, l_1_27)
          l_1_22 = false
        else
          l_1_28:Hide()
        end
      end
      if l_1_22 then
        l_1_16 = l_1_16 - 1
      else
        l_1_23.bShow = true
        l_1_23.nX = ((l_1_21 + (l_1_16)) * l_0_2 + l_0_4) * RaidGridEx.fScale
        l_1_15 = l_1_15 + 1
      end
    end
    l_1_14 = math.max(l_1_14, 1)
    if l_1_1 > 1 then
      l_1_15 = math.max(l_1_15, 2)
      if RaidGridEx.bShowNumber then
        for l_1_32 = 0, 4 do
          local l_1_33 = RaidGridEx.hRoles:Lookup("Text_Group_" .. l_1_32)
          if l_1_33.bShow then
            l_1_17 = l_0_5 + 12
            l_1_33:SetRelPos(l_1_33.nX, l_1_14 * l_0_3 * RaidGridEx.fScale)
            l_1_33:Show()
          end
        end
      end
    else
      l_1_15 = math.max(l_1_15, 1)
    end
    RaidGridEx.hBg:Lookup("Image_Title_BG"):SetSize((l_1_15 * l_0_2 + l_0_4) * RaidGridEx.fScale, l_0_7)
    RaidGridEx.hBg:Lookup("Image_BG"):SetSize((l_1_15 * l_0_2 + l_0_4) * RaidGridEx.fScale, (l_1_14 * l_0_3 + (l_1_17)) * RaidGridEx.fScale)
    RaidGridEx.frame:SetSize((l_1_15 * l_0_2 + l_0_4) * RaidGridEx.fScale, (l_1_14 * l_0_3 + l_0_6 + (l_1_17)) * RaidGridEx.fScale)
    RaidGridEx.frame:SetDragArea(0, 0, (l_1_15 * l_0_2 + l_0_4) * RaidGridEx.fScale, 25)
  end
  RaidGridEx.hRoles:FormatAllItemPos()
end

RaidGridEx.CreateAllRoleHandle = function()
  -- upvalues: l_0_0 , l_0_1 , l_0_8 , l_0_2 , l_0_4 , l_0_3 , l_0_5
  RaidGridEx.hRoles:Clear()
  for l_2_3 = 0, l_0_0 - 1 do
    for l_2_7 = 1, l_0_1 do
      local l_2_8 = RaidGridEx.hRoles:AppendItemFromIni(l_0_8, "Handle_Role", "Handle_Role_" .. l_2_3 .. "_" .. l_2_7)
      l_2_8:SetRelPos((l_2_3 * l_0_2 + l_0_4) * RaidGridEx.fScale, ((l_2_7 - 1) * l_0_3 + l_0_5) * RaidGridEx.fScale)
      l_2_8.dwMemberID = nil
      RaidGridEx.HideRoleHandle(nil, nil, l_2_8)
      l_2_8:Scale(RaidGridEx.fScale, RaidGridEx.fScale)
    end
    local l_2_9 = RaidGridEx.hRoles:AppendItemFromIni(l_0_8, "Text_Group", "Text_Group_" .. l_2_3)
    l_2_9:Scale(RaidGridEx.fScale, RaidGridEx.fScale)
  end
  RaidGridEx.hRoles:FormatAllItemPos()
end

RaidGridEx.ShowRoleHandle = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = nil
  if not l_3_2 then
    l_3_3 = RaidGridEx
    l_3_3 = l_3_3.hRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_3_3 then
    return 
  end
  l_3_3:Show()
  l_3_3:SetAlpha(255)
  l_3_3:Lookup("Text_Name"):SetText("")
  l_3_3:Lookup("Image_LifeBG"):Show()
  l_3_3:Lookup("Image_LifeBG"):SetAlpha(48)
  l_3_3:Lookup("Image_BGBox_White"):Show()
  l_3_3:Lookup("Image_BGBox_White"):SetAlpha(16)
  RaidGridEx.HideAllLifeBar(l_3_3)
  l_3_3:Lookup("Text_LifeValue"):SetText("")
  l_3_3:Lookup("Image_ManaBG"):Show()
  l_3_3:Lookup("Image_ManaBG"):SetAlpha(64)
  l_3_3:Lookup("Image_Mana"):Show()
  l_3_3:Lookup("Image_Leader"):Hide()
  l_3_3:Lookup("Image_Looter"):Hide()
  l_3_3:Lookup("Image_Mark"):Hide()
  l_3_3:Lookup("Image_MarkImage"):Hide()
  l_3_3:Lookup("Image_Matrix"):Hide()
end

RaidGridEx.HideRoleHandle = function(l_4_0, l_4_1, l_4_2)
  local l_4_3 = nil
  if not l_4_2 then
    l_4_3 = RaidGridEx
    l_4_3 = l_4_3.hRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_4_3 then
    return 
  end
  l_4_3:Show()
  l_4_3:SetAlpha(32)
  l_4_3:Lookup("Text_Name"):SetText("")
  l_4_3:Lookup("Text_Kungfu"):SetText("")
  l_4_3:Lookup("Image_Kungfu"):Hide()
  l_4_3:Lookup("Image_LifeBG"):Hide()
  l_4_3:Lookup("Image_BGBox_White"):Show()
  l_4_3:Lookup("Image_BGBox_White"):SetAlpha(8)
  RaidGridEx.HideAllLifeBar(l_4_3)
  l_4_3:Lookup("Text_LifeValue"):SetText("")
  l_4_3:Lookup("Image_ManaBG"):Hide()
  l_4_3:Lookup("Image_Mana"):Hide()
  l_4_3:Lookup("Image_Leader"):Hide()
  l_4_3:Lookup("Image_Looter"):Hide()
  l_4_3:Lookup("Image_Mark"):Hide()
  l_4_3:Lookup("Image_MarkImage"):Hide()
  l_4_3:Lookup("Image_Matrix"):Hide()
  l_4_3:Lookup("Image_ReadyCheck"):Hide()
  l_4_3:Lookup("Image_ReadyCheck_No"):Hide()
end

RaidGridEx.EnterRoleHandle = function(l_5_0, l_5_1, l_5_2)
  if not l_5_2 then
    l_5_2 = RaidGridEx.handleRoles:Lookup("Handle_Role_" .. l_5_0 .. "_" .. l_5_1)
  end
  if not l_5_2 then
    return 
  end
  if l_5_2.dwMemberID then
    l_5_2:Lookup("Animate_SelectRole"):Show()
    local l_5_3 = RaidGridEx.GetTeamMemberInfo(l_5_2.dwMemberID)
    if not l_5_3 then
      return 
    end
    local l_5_5 = l_5_3.nCurrentLife
    if IsCtrlKeyDown() then
      local l_5_4 = l_5_3.nCurrentLife / l_5_3.nMaxLife
    end
    local l_5_6 = nil
    if l_5_2:Lookup("Text_LifeValue") and RaidGridEx.nLifeType == 0 and l_5_3.bIsOnLine and not l_5_3.bDeathFlag then
      l_5_2:Lookup("Text_LifeValue"):SetText(l_5_5)
      l_5_2:Lookup("Text_LifeValue"):SetFontScale(RaidGridEx.nLifeFontScale)
      if l_5_6 < 0.3 then
        l_5_2:Lookup("Text_LifeValue"):SetFontColor(255, 96, 96)
      elseif l_5_6 < 0.7 then
        l_5_2:Lookup("Text_LifeValue"):SetFontColor(255, 192, 64)
      else
        l_5_2:Lookup("Text_LifeValue"):SetFontColor(255, 128, 128)
      end
      l_5_2:Lookup("Text_LifeValue"):Show()
    end
    local l_5_7, l_5_8 = , RaidGridEx.frame:GetAbsPos()
    local l_5_9, l_5_10 = , RaidGridEx.frame:GetSize()
    local l_5_11 = nil
    local l_5_12 = OutputTeamMemberTip
    do
      local l_5_13 = l_5_2.dwMemberID
      l_5_12(l_5_13, {l_5_8, l_5_9, l_5_10, l_5_11})
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_5_2:SetAlpha(128)
  end
end

RaidGridEx.LeaveRoleHandle = function(l_6_0, l_6_1, l_6_2)
  local l_6_3 = nil
  if not l_6_2 then
    l_6_3 = RaidGridEx
    l_6_3 = l_6_3.handleRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_6_3 then
    return 
  end
  if l_6_3.dwMemberID then
    if RaidGridEx.handleLastSelect ~= l_6_3 then
      l_6_3:Lookup("Animate_SelectRole"):Hide()
      RaidGridEx.handleLastSelect = nil
    end
    local l_6_4 = l_6_3:Lookup("Text_LifeValue")
    if l_6_4 and RaidGridEx.nLifeType == 0 and l_6_4:GetText() ~= "����" and l_6_4:GetText() ~= "����" then
      l_6_4:SetText("")
      l_6_4:SetFontScale(RaidGridEx.nLifeFontScale)
      l_6_4:SetFontColor(255, 255, 255)
      l_6_4:Hide()
    end
    HideTip()
  else
    RaidGridEx.HideRoleHandle(l_6_0, l_6_1, l_6_3)
  end
end

RaidGridEx.UpdateByGroup = function(l_7_0)
  for l_7_4 = 1, 5 do
    local l_7_5 = RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_7_0 .. "_" .. l_7_4)
    l_7_5.dwMemberID = nil
    RaidGridEx.HideRoleHandle(nil, nil, l_7_5)
  end
  local l_7_6 = GetClientTeam()
  local l_7_7 = l_7_6.GetGroupInfo(l_7_0)
  if l_7_7.MemberList and #l_7_7.MemberList > 0 then
    RaidGridEx.tFormationLeader[l_7_0] = l_7_7.dwFormationLeader
    for l_7_11,l_7_12 in ipairs(l_7_7.MemberList) do
      local l_7_13 = RaidGridEx.GetHandleByPos(l_7_0, l_7_11)
      RaidGridEx.ShowRoleHandle(nil, nil, l_7_13)
      l_7_13.dwMemberID = l_7_12
      RaidGridEx.UpdateMemberLFData(l_7_13)
      RaidGridEx.UpdateMemberSpecialState(l_7_13)
      RaidGridEx.UpdateMemberHFData(l_7_13)
    end
  end
  RaidGridEx.UpdateMemberMark(l_7_0)
end

RaidGridEx.UpdateRaid = function()
  local l_8_0 = GetClientTeam()
  if not l_8_0 then
    return 
  end
  local l_8_1 = GetClientPlayer()
  if RaidGridEx.tLootModeImage[l_8_0.nLootMode] then
    RaidGridEx.tLootModeImage[l_8_0.nLootMode]:SetAlpha(255)
  end
  if RaidGridEx.tRollQualityImage[l_8_0.nRollQuality] then
    RaidGridEx.tRollQualityImage[l_8_0.nRollQuality]:SetAlpha(255)
  end
  if l_8_0.nGroupNum == 1 then
    RaidGridEx.hLootMode:Hide()
    RaidGridEx.hLootColor:Hide()
  end
  RaidGridEx.tFormationLeader = {}
  for l_8_5 = 0, math.min(4, l_8_0.nGroupNum - 1) do
    local l_8_6 = l_8_0.GetGroupInfo(l_8_5)
    if l_8_6 then
      RaidGridEx.tFormationLeader[l_8_5] = l_8_6.dwFormationLeader
      for l_8_10,l_8_11 in ipairs(l_8_6.MemberList) do
        local l_8_12 = RaidGridEx.GetHandleByPos(l_8_5, l_8_10)
        RaidGridEx.ShowRoleHandle(nil, nil, l_8_12)
        l_8_12.dwMemberID = l_8_11
        RaidGridEx.UpdateMemberLFData(l_8_12)
        RaidGridEx.UpdateMemberHFData(l_8_12)
        RaidGridEx.UpdateMemberSpecialState(l_8_12)
      end
    end
  end
  RaidGridEx.UpdateMemberMark()
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

RaidGridEx.UpdateMemberLFData = function(l_9_0)
  local l_9_1 = GetClientTeam()
  local l_9_2 = l_9_0.dwMemberID
  local l_9_3 = l_9_1.GetMemberInfo(l_9_2)
  local l_9_4 = l_9_0:Lookup("Image_Leader")
  if RaidGridEx.IsAuthority(l_9_2, "leader") then
    l_9_4:Show()
  else
    l_9_4:Hide()
  end
  local l_9_5 = l_9_0:Lookup("Image_Looter")
  if RaidGridEx.IsAuthority(l_9_2, "distribute") then
    l_9_5:Show()
  else
    l_9_5:Hide()
  end
  local l_9_6 = l_9_0:Lookup("Image_Mark")
  if RaidGridEx.IsAuthority(l_9_2, "mark") then
    l_9_6:Show()
  else
    l_9_6:Hide()
  end
  local l_9_7 = l_9_0:Lookup("Image_Matrix")
  local l_9_8 = l_9_1.GetMemberGroupIndex(l_9_2)
  local l_9_9 = l_9_1.GetGroupInfo(l_9_8)
  if l_9_9 and #l_9_9.MemberList > 0 and l_9_9.dwFormationLeader == l_9_2 then
    l_9_7:Show()
  else
    l_9_7:Hide()
  end
end

RaidGridEx.HideAllLifeBar = function(l_10_0)
  l_10_0:Lookup("Image_Life_White"):Hide()
  l_10_0:Lookup("Image_Life_Red"):Hide()
  l_10_0:Lookup("Image_Life_Orange"):Hide()
  l_10_0:Lookup("Image_Life_Blue"):Hide()
  l_10_0:Lookup("Image_Life_Green"):Hide()
end

RaidGridEx.UpdateAllLife = function()
  local l_11_0 = RaidGridEx.hRoles:GetItemCount()
  for l_11_4 = 0, l_11_0 - 1 do
    local l_11_5 = RaidGridEx.hRoles:Lookup(l_11_4)
    if l_11_5 and l_11_5.dwMemberID then
      local l_11_6 = l_11_5:Lookup("Text_LifeValue")
      l_11_6:SetText("")
      l_11_6:Hide()
      RaidGridEx.UpdateMemberHFData(l_11_5)
    end
  end
end

local l_0_9 = function(l_12_0)
  if l_12_0 >= 10000 and not RaidGridEx.bFullFile then
    return KeepOneByteFloat(l_12_0 / 10000) .. "w"
  end
  return l_12_0
end

RaidGridEx.UpdateMemberHFData = function(l_13_0)
  -- upvalues: l_0_9
  RaidGridEx.HideAllLifeBar(l_13_0)
  local l_13_1 = GetClientTeam()
  local l_13_2 = l_13_1.GetMemberInfo(l_13_0.dwMemberID)
  local l_13_3 = l_13_0:Lookup("Text_LifeValue")
  local l_13_4 = l_13_0:Lookup("Image_Mana")
  if l_13_2.bIsOnLine then
    local l_13_5 = l_13_2.nCurrentLife / l_13_2.nMaxLife
    if RaidGridEx.bAutoDistColor then
      if not l_13_0.imgLife then
        l_13_0.imgLife = l_13_0:Lookup("Image_Life_Green")
    else
      end
    end
    if l_13_5 <= 0.3 then
      l_13_0.imgLife = l_13_0:Lookup("Image_Life_Red")
    elseif l_13_5 <= 0.6 then
      l_13_0.imgLife = l_13_0:Lookup("Image_Life_Orange")
    else
      l_13_0.imgLife = l_13_0:Lookup("Image_Life_Green")
    end
    l_13_0.imgLife:Show()
    l_13_0.imgLife:SetPercentage(l_13_5)
    l_13_0.imgLife:SetAlpha(230)
    if l_13_2.bDeathFlag then
      l_13_3:SetText("����")
      l_13_3:SetFontScale(RaidGridEx.nLifeFontScale)
      l_13_3:SetFontColor(255, 0, 0)
      l_13_3:Show()
    elseif l_13_2.nMaxLife > 0 and RaidGridEx.nLifeType ~= 0 then
      local l_13_6 = l_13_2.nCurrentLife
      local l_13_7 = l_13_2.nMaxLife - l_13_2.nCurrentLife
      if RaidGridEx.nLifeType == 1 then
        l_13_3:SetText(l_0_9(l_13_6))
        l_13_3:SetFontScale(RaidGridEx.nLifeFontScale)
        l_13_3:SetFontColor(255, 255, 255)
        l_13_3:Show()
      else
        if RaidGridEx.nLifeType == 2 then
          if l_13_7 > 0 then
            l_13_3:SetText("-" .. l_0_9(l_13_7))
            l_13_3:SetFontScale(RaidGridEx.nLifeFontScale)
            if l_13_5 < 0.3 then
              l_13_3:SetFontColor(255, 96, 96)
            elseif l_13_5 < 0.7 then
              l_13_3:SetFontColor(255, 192, 64)
            else
              l_13_3:SetFontColor(255, 128, 128)
            end
            l_13_3:Show()
          end
        else
          l_13_3:Hide()
        end
      else
        if RaidGridEx.nLifeType == 3 then
          if l_13_7 > 0 then
            l_13_3:SetText("%d":format(100 * l_13_2.nCurrentLife / l_13_2.nMaxLife) .. "%")
            l_13_3:SetFontScale(RaidGridEx.nLifeFontScale)
            if l_13_5 < 0.3 then
              l_13_3:SetFontColor(255, 96, 96)
            elseif l_13_5 < 0.7 then
              l_13_3:SetFontColor(255, 192, 64)
            else
              l_13_3:SetFontColor(255, 128, 128)
            end
            l_13_3:Show()
          end
        end
      else
        l_13_3:Hide()
      end
    else
      if RaidGridEx.nLifeType == 0 and l_13_3:GetText() == "����" then
        l_13_3:Hide()
      end
    end
    if l_13_2.nMaxMana > 0 and l_13_2.nMaxMana ~= 1 then
      l_13_4:SetPercentage(l_13_2.nCurrentMana / l_13_2.nMaxMana)
      l_13_4:Show()
    end
  else
    l_13_3:SetText("����")
    l_13_3:SetFontScale(RaidGridEx.nLifeFontScale)
    l_13_3:SetFontColor(96, 96, 96)
    l_13_3:Show()
    l_13_4:Hide()
  end
end

RaidGridEx.UpdateMemberMark = function(l_14_0)
  local l_14_1 = GetClientTeam()
  local l_14_2 = l_14_1.GetTeamMark()
  if not l_14_2 then
    return 
  end
  if l_14_0 then
    for l_14_7 = 1, 5 do
      local l_14_4 = function(l_15_0)
    -- upvalues: l_14_2
    local l_15_1 = l_15_0:Lookup("Image_MarkImage")
    if l_15_0.dwMemberID then
      local l_15_2 = nil
      local l_15_3 = l_14_2[l_15_0.dwMemberID]
      if l_15_3 then
        local l_15_4 = assert
        l_15_4(l_15_3 > 0 and l_15_3 <= #PARTY_MARK_ICON_FRAME_LIST)
        l_15_4 = PARTY_MARK_ICON_FRAME_LIST
        l_15_2 = l_15_4[l_15_3]
      end
      if l_15_2 then
        l_15_1:FromUITex(PARTY_MARK_ICON_PATH, l_15_2)
        l_15_1:Show()
      else
        l_15_1:Hide()
      end
    else
      l_15_1:Hide()
    end
  end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_14_4(RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_14_0 .. "_" .. R7_PC21))
    end
    do break end
  end
  do
    local l_14_9 = nil
    for l_14_13 = 0, RaidGridEx.hRoles:GetItemCount() - 1 do
      local l_14_10 = nil
      if RaidGridEx.hRoles:Lookup(RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_14_0 .. "_" .. R7_PC21)) and RaidGridEx.hRoles:Lookup(RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_14_0 .. "_" .. R7_PC21)):GetType() == "Handle" then
        l_14_9(RaidGridEx.hRoles:Lookup(RaidGridEx.hRoles:Lookup("Handle_Role_" .. l_14_0 .. "_" .. R7_PC21)))
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

RaidGridEx.UpdateAllSpecialState = function()
  local l_15_0 = RaidGridEx.hRoles:GetItemCount()
  for l_15_4 = 0, l_15_0 - 1 do
    local l_15_5 = RaidGridEx.hRoles:Lookup(l_15_4)
    if l_15_5 and l_15_5.dwMemberID then
      RaidGridEx.UpdateMemberSpecialState(l_15_5)
    end
  end
end

RaidGridEx.UpdateMemberSpecialState = function(l_16_0)
  local l_16_1 = RaidGridEx.GetTeamMemberInfo(l_16_0.dwMemberID)
  if not l_16_1 then
    return 
  end
  local l_16_2 = l_16_0:Lookup("Text_Name")
  local l_16_3 = l_16_0:Lookup("Text_Kungfu")
  local l_16_4 = l_16_0:Lookup("Image_Kungfu")
  local l_16_5 = l_16_1.szName
  local l_16_6 = (RaidGridEx.fScale / 0.2 - 4) * 2 + 4
  l_16_2:SetFontScheme(RaidGridEx.nFontScheme)
  if l_16_6 > 12 then
    l_16_6 = 12
  end
  if RaidGridEx.nFontScheme == 23 then
    l_16_6 = l_16_6 - 2
  end
  local l_16_7 = RaidGridEx.GetKungfuByID(l_16_0.dwMemberID)
  local l_16_8, l_16_9, l_16_10 = RaidGridEx.GetCharacterColor(l_16_0.dwMemberID, l_16_1.dwForceID)
  local l_16_11, l_16_12, l_16_13 = nil, nil, nil
  if l_16_1.bDeathFlag then
    l_16_11 = 255
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  elseif not l_16_1.bIsOnLine then
    l_16_11 = 128
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    if RaidGridEx.nNameColor == 2 then
      if not l_16_1.nCamp or l_16_1.nCamp == 0 then
        l_16_11 = 255
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_16_1.nCamp == CAMP.GOOD or l_16_1.nCamp == 1 then
        l_16_11 = 0
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_16_1.nCamp == CAMP.EVIL or l_16_1.nCamp == 2 then
        l_16_11 = 250
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if RaidGridEx.nNameColor == 0 then
        l_16_11 = 255
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_16_11 = l_16_8
    end
    if #l_16_5 <= l_16_6 then
      l_16_2:SetFontSpacing(-1)
      l_16_2:SetText(l_16_1.szName)
    else
      l_16_2:SetFontSpacing(-3)
      local l_16_14 = l_16_1.szName:sub(1, l_16_6)
      if StringFindW(l_16_14, "@") then
        l_16_14 = l_16_1.szName:sub(1, l_16_6 - 1)
      end
      l_16_2:SetText(l_16_14 .. "��")
    end
    l_16_2:SetFontColor(l_16_11, l_16_12, l_16_13)
    if l_16_7 and RaidGridEx.nKungfuType ~= 0 then
      if RaidGridEx.nKungfuType == 1 then
        l_16_3:Hide()
        local l_16_15 = Table_GetSkillIconID(l_16_7[2], 0)
        if l_16_15 and l_16_7[2] ~= 10000 then
          l_16_4:FromIconID(l_16_15)
          l_16_4:Show()
        else
          l_16_4:Hide()
        end
      else
        l_16_4:Hide()
        l_16_3:SetText(l_16_7[1])
        l_16_3:SetFontColor(l_16_8, l_16_9, l_16_10)
        l_16_3:Show()
      end
    else
      l_16_4:Hide()
      l_16_3:Hide()
    end
    local l_16_16 = GetClientPlayer()
    if l_16_16.bFightState then
      l_16_4:SetAlpha(192)
      l_16_2:SetAlpha(192)
      l_16_3:SetAlpha(192)
    else
      l_16_4:SetAlpha(240)
      l_16_2:SetAlpha(240)
      l_16_3:SetAlpha(240)
    end
    local l_16_17 = GetPlayer(l_16_0.dwMemberID)
    if RaidGridEx.bAutoDistColor then
      if not l_16_1.bIsOnLine then
        l_16_0.imgLife = l_16_0:Lookup("Image_Life_White")
      end
    elseif l_16_17 then
      local l_16_18 = math.floor(l_16_17.nX - l_16_16.nX ^ 2 + l_16_17.nY - l_16_16.nY ^ 2 ^ 0.5)
      local l_16_19 = l_16_18 / 64
      if l_16_19 <= 8 then
        l_16_0.imgLife = l_16_0:Lookup("Image_Life_" .. RaidGridEx.szDistColor_8)
      elseif l_16_19 <= 20 then
        l_16_0.imgLife = l_16_0:Lookup("Image_Life_" .. RaidGridEx.szDistColor_20)
      elseif l_16_19 <= 24 then
        l_16_0.imgLife = l_16_0:Lookup("Image_Life_" .. RaidGridEx.szDistColor_24)
      else
        l_16_0.imgLife = l_16_0:Lookup("Image_Life_" .. RaidGridEx.szDistColor_999)
      end
      RaidGridEx.UpdateMemberHFData(l_16_0)
    else
      l_16_0.imgLife = l_16_0:Lookup("Image_Life_" .. RaidGridEx.szDistColor_0)
      RaidGridEx.UpdateMemberHFData(l_16_0)
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

RaidGridEx.UpdateAllMemberBuff = function()
  local l_17_0 = GetClientPlayer()
  local l_17_1 = GetClientTeam()
  local l_17_2 = l_17_1.nGroupNum - 1
  for l_17_6 = 0, l_17_2 do
    local l_17_7 = l_17_1.GetGroupInfo(l_17_6)
    if l_17_7 and #l_17_7.MemberList ~= 0 then
      for l_17_11,l_17_12 in pairs(l_17_7.MemberList) do
        RaidGridEx.UpdateMemberBuff(l_17_12)
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

RaidGridEx.UpdateMemberBuff = function(l_18_0)
  local l_18_1 = RaidGridEx.GetHandleByID(l_18_0)
  local l_18_2 = GetPlayer(l_18_0)
  if not l_18_2 or l_18_1:GetAlpha() == 32 then
    return 
  end
  if not l_18_1.tBoxes then
    local l_18_3 = l_18_1:Lookup("Handle_Debuffs")
    if not l_18_3 then
      return 
    end
    local l_18_4 = {}
    for l_18_8 = 1, 4 do
      local l_18_9 = l_18_3:Lookup("Box_" .. l_18_8)
      if l_18_9 then
        l_18_9:Hide()
        l_18_9:SetAlpha(RaidGridEx.nBuffFlashAlpha)
        l_18_9:SetObject(1, 0)
        l_18_9:ClearObjectIcon()
        l_18_9.szName = nil
        l_18_9.nIconID = -1
        l_18_9.bShow = false
        l_18_9.nEndFrame = 0
        l_18_9.nRate = 9999
        l_18_9.szColor = nil
        l_18_9.nAlpha = RaidGridEx.nBuffFlashAlpha
        l_18_9.nTrend = 1
        l_18_4[l_18_8] = l_18_9
      end
    end
    l_18_1.tBoxes = l_18_4
  end
  local l_18_10 = RaidGridEx.nBuffFlashAlpha
  local l_18_11 = false
  if not RaidGridEx.bAutoBUFFColor then
    l_18_10 = 0
  else
    if RaidGridEx.nBuffFlashTime == 0 then
      l_18_10 = RaidGridEx.nBuffFlashAlpha
    end
  else
    l_18_11 = true
  end
  for l_18_15 = 1, 4 do
    if l_18_1.tBoxes[l_18_15].bShow then
      if l_18_11 then
        l_18_10 = l_18_1.tBoxes[l_18_15].nAlpha
        local l_18_16 = l_18_1.tBoxes[l_18_15].nTrend
        if l_18_10 <= 70 then
          l_18_10 = l_18_10 + RaidGridEx.nBuffFlashTime * l_18_16 / 15
        else
          if l_18_10 <= 70 + (RaidGridEx.nBuffFlashAlpha - 70) / 2 then
            l_18_10 = l_18_10 + RaidGridEx.nBuffFlashTime * l_18_16 / 2
          end
        else
          if RaidGridEx.nBuffFlashAlpha - 10 <= l_18_10 then
            l_18_10 = l_18_10 + RaidGridEx.nBuffFlashTime * l_18_16 / 10
          end
        else
          l_18_10 = l_18_10 + RaidGridEx.nBuffFlashTime * l_18_16
        end
        if RaidGridEx.nBuffFlashAlpha <= l_18_10 then
          l_18_10 = RaidGridEx.nBuffFlashAlpha
          l_18_16 = l_18_16 * -1
        elseif l_18_10 <= 50 then
          l_18_10 = 50
          l_18_16 = l_18_16 * -1
        end
        l_18_1.tBoxes[l_18_15].nAlpha = l_18_10
        l_18_1.tBoxes[l_18_15].nTrend = l_18_16
      end
      l_18_1.tBoxes[l_18_15]:Show()
      l_18_1.tBoxes[l_18_15]:SetAlpha(l_18_10)
      if l_18_10 == RaidGridEx.nBuffFlashAlpha then
        l_18_1.tBoxes[l_18_15]:SetObjectStaring(true)
      end
      if l_18_1.tBoxes[l_18_15].nEndFrame then
        local l_18_17 = GetLogicFrameCount()
      end
      if l_18_1.tBoxes[l_18_15].nEndFrame or 0 < l_18_17 then
        l_18_1.tBoxes[l_18_15].szName = nil
        l_18_1.tBoxes[l_18_15].nIconID = -1
        l_18_1.tBoxes[l_18_15].bShow = false
        l_18_1.tBoxes[l_18_15].nEndFrame = 0
        l_18_1.tBoxes[l_18_15].nRate = 9999
        l_18_1.tBoxes[l_18_15].szColor = nil
        l_18_1.tBoxes[l_18_15].nAlpha = RaidGridEx.nBuffFlashAlpha
        l_18_1.tBoxes[l_18_15].nTrend = 1
        l_18_1.tBoxes[l_18_15]:ClearObjectIcon()
        l_18_1.tBoxes[l_18_15]:Hide()
      end
    else
      l_18_1.tBoxes[l_18_15]:Hide()
    end
  end
  local l_18_18 = l_18_1:Lookup("Shadow_Color")
  if l_18_18 then
    l_18_18:SetAlpha(RaidGridEx.nBuffCoverAlpha)
    do
      local l_18_19 = l_18_18.nEndFrame or 0
    end
    local l_18_20 = nil
  if l_18_20 >= GetLogicFrameCount() then
    end
  if l_18_20 >= GetLogicFrameCount() then
    end
  end
  l_18_18.nEndFrame = 0
  l_18_18.nRate = 9999
  l_18_18:Hide()
end

RaidGridEx.OnUpdateBuffData = function(l_19_0, l_19_1, l_19_2, l_19_3, l_19_4, l_19_5, l_19_6)
  if l_19_6 <= 0 then
    return 
  end
  local l_19_7 = GetPlayer(l_19_0)
  if not l_19_7 then
    return 
  end
  local l_19_8 = l_19_7.GetBuffList()
  if not l_19_8 then
    return 
  end
  local l_19_9 = Table_GetBuffName(l_19_3, l_19_6)
  if not l_19_9 or l_19_9 == "" then
    return 
  end
  local l_19_10 = RaidGridEx.GetHandleByID(l_19_0)
  local l_19_11 = l_19_10.tBoxes
  if not l_19_10.tBoxes then
    RaidGridEx.UpdateMemberBuff(l_19_0)
    l_19_11 = l_19_10.tBoxes
  end
  if l_19_1 then
    for l_19_15 = 1, 4 do
      local l_19_16 = l_19_11[l_19_15]
      if l_19_16.szName == l_19_9 then
        l_19_16.szName = nil
        l_19_16.nIconID = -1
        l_19_16.bShow = false
        l_19_16.nEndFrame = 0
        l_19_16.nRate = 9999
        l_19_16.szColor = nil
        l_19_16.nAlpha = RaidGridEx.nBuffFlashAlpha
        l_19_16.nTrend = 1
        l_19_16:ClearObjectIcon()
        local l_19_17 = l_19_10:Lookup("Shadow_Color")
        l_19_17:Hide()
        l_19_17.nEndFrame = 0
        l_19_17.nRate = 9999
      end
    end
    return 
  end
  local l_19_18 = DebuffSettingPanel.FormatDebuffNameList()
  if not l_19_18[l_19_9] then
    return 
  end
  local l_19_19 = l_19_18[l_19_9][1]
  do
    local l_19_20 = l_19_18[l_19_9][2] or ""
  end
  local l_19_21 = nil
  do
    local l_19_22 = {}
    for l_19_26 = 1, 4 do
      local l_19_23 = false
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if not l_19_11[R20_PC87].nRate then
        l_19_11[R20_PC87].nRate = not l_19_11[R20_PC87]:IsVisible() or 9999
         -- DECOMPILER ERROR: Confused about usage of registers!

      end
      if l_19_19 < l_19_11[R20_PC87].nRate and not l_19_23 then
        local l_19_28 = nil
      end
      if Table_GetBuffIconID(l_19_3, l_19_6) then
        l_19_23 = true
        local l_19_29 = nil
        local l_19_30 = table.insert
        local l_19_31 = l_19_22
        l_19_30(l_19_31, {szName = l_19_9, nIconID = l_19_29, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1})
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_19_9 ~= l_19_28.szName then
        local l_19_32 = nil
        local l_19_33 = table.insert
        local l_19_34 = l_19_22
        l_19_33(l_19_34, {szName = l_19_32.szName, nIconID = l_19_32.nIconID, bShow = l_19_32.bShow, nEndFrame = l_19_32.nEndFrame, nRate = l_19_32.nRate, szColor = l_19_32.szColor, nAlpha = l_19_32.nAlpha, nTrend = l_19_32.nTrend})
      end
    end
    if #l_19_22 == 0 then
      local l_19_35 = nil
    end
    if Table_GetBuffIconID(l_19_3, l_19_6) then
      local l_19_36 = nil
      local l_19_37 = table.insert
      local l_19_38 = l_19_22
      l_19_37(l_19_38, {szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1})
    end
    for l_19_42 = 1, 4 do
      local l_19_39 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}] then
        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].szName = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].szName
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nIconID = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nIconID
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].bShow = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].bShow
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nEndFrame = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nEndFrame
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nRate = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nRate
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].szColor = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].szColor
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nAlpha = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nAlpha
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nTrend = l_19_22[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nTrend
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}]:ClearObjectIcon()
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}]:SetObjectIcon(l_19_11[{szName = l_19_9, nIconID = l_19_36, bShow = true, nEndFrame = l_19_5, nRate = l_19_19, szColor = l_19_21, nAlpha = RaidGridEx.nBuffFlashAlpha, nTrend = 1}].nIconID)
        if l_19_10:Lookup("Shadow_Color") and (l_19_10:Lookup("Shadow_Color").nEndFrame == 0 or l_19_11[l_19_43].nRate < l_19_10:Lookup("Shadow_Color").nRate) then
          local l_19_44 = nil
          local l_19_45 = DebuffSettingPanel.tColorCover[l_19_11[l_19_43].szColor]
          local l_19_46 = 255
          local l_19_47 = 255
          local l_19_48 = 255
           -- DECOMPILER ERROR: Overwrote pending register.

          if l_19_45 then
            l_19_44:SetTriangleFan(true)
            l_19_44:ClearTriangleFanPoint()
            l_19_44:AppendTriangleFanPoint(0, 0, l_19_46, l_19_47, l_19_48, 0)
             -- DECOMPILER ERROR: Confused about usage of registers!

            l_19_44:AppendTriangleFanPoint(0, 34, l_19_46, l_19_47, l_19_48, 0)
             -- DECOMPILER ERROR: Confused about usage of registers!

            l_19_44:AppendTriangleFanPoint(56, 34, l_19_46, l_19_47, l_19_48, 0)
             -- DECOMPILER ERROR: Confused about usage of registers!

            l_19_44:AppendTriangleFanPoint(56, 0, l_19_46, l_19_47, l_19_48, 0)
            l_19_44:Scale(RaidGridEx.fScale, RaidGridEx.fScale)
            l_19_44:Show()
            l_19_44.nEndFrame = l_19_11[l_19_43].nEndFrame or 0
            l_19_44.nRate = l_19_11[l_19_43].nRate
          end
         -- DECOMPILER ERROR: Confused about usage of registers!

        else
          l_19_11[l_19_43].szName = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].nIconID = -1
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].bShow = false
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].nEndFrame = 0
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].nRate = 9999
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].szColor = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].nAlpha = RaidGridEx.nBuffFlashAlpha
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43].nTrend = 1
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_19_11[l_19_43]:ClearObjectIcon()
        end
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 253 
end

RaidGridEx.GetHandleByPos = function(l_20_0, l_20_1)
  local l_20_2, l_20_3 = RaidGridEx.hRoles:Lookup, RaidGridEx.hRoles
  local l_20_5 = "Handle_Role_"
  local l_20_6 = l_20_0
  local l_20_7 = "_"
  l_20_5 = l_20_5 .. l_20_6 .. l_20_7 .. l_20_1
  local l_20_4 = nil
  return l_20_2(l_20_3, l_20_5)
end

RaidGridEx.GetHandleByID = function(l_21_0)
  local l_21_1 = RaidGridEx.hRoles:GetItemCount()
  for l_21_5 = 0, l_21_1 - 1 do
    local l_21_6 = RaidGridEx.hRoles:Lookup(l_21_5)
    if l_21_6 and l_21_6.dwMemberID == l_21_0 then
      return l_21_6
    end
  end
end

RaidGridEx.GetAuthority = function(l_22_0)
  local l_22_1 = GetClientTeam()
  if not l_22_1 then
    return 
  end
  local l_22_2 = l_22_1.GetAuthorityInfo
  local l_22_5 = TEAM_AUTHORITY_TYPE
  local l_22_4 = string.upper(l_22_0)
  l_22_5 = l_22_5[l_22_4]
  local l_22_3 = nil
  return l_22_2(l_22_5)
end

RaidGridEx.IsAuthority = function(l_23_0, l_23_1)
  return l_23_0 == RaidGridEx.GetAuthority(l_23_1)
end

RaidGridEx.GetLootModenQuality = function()
  local l_24_0 = GetClientTeam()
  if not l_24_0 then
    return 
  end
  return l_24_0.nLootMode, l_24_0.nRollQuality
end

RaidGridEx.GetGroupIndex = function(l_25_0)
  local l_25_1 = GetClientTeam()
  local l_25_2 = l_25_1.GetMemberGroupIndex
  local l_25_3 = l_25_0
  return l_25_2(l_25_3)
end

RaidGridEx.GetTeamMemberInfo = function(l_26_0)
  local l_26_1 = GetClientTeam()
  if not l_26_1 then
    return 
  end
  local l_26_2 = l_26_1.GetMemberInfo(l_26_0)
  if not l_26_2 then
    return 
  end
  l_26_2.nX = l_26_2.nPosX
  l_26_2.nY = l_26_2.nPosY
  return l_26_2
end

RaidGridEx.GetCharacterColor = function(l_27_0, l_27_1)
  local l_27_2 = GetClientPlayer()
  if not l_27_2 then
    return 128, 128, 128
  end
  if not IsPlayer(l_27_0) then
    return 168, 168, 168
  end
  if not l_27_1 then
    local l_27_3 = GetPlayer(l_27_0)
    if not l_27_3 then
      return 128, 128, 128
    end
    l_27_1 = l_27_3.dwForceID
  end
  if not l_27_1 then
    return 168, 168, 168
  end
  if l_27_1 == 0 then
    return 255, 255, 255
  elseif l_27_1 == 1 then
    return 255, 178, 95
  elseif l_27_1 == 2 then
    return 196, 152, 255
  elseif l_27_1 == 3 then
    return 250, 111, 83
  elseif l_27_1 == 4 then
    return 89, 224, 232
  elseif l_27_1 == 5 then
    return 255, 129, 176
  elseif l_27_1 == 6 then
    return 55, 147, 255
  elseif l_27_1 == 8 then
    return 214, 249, 93
  elseif l_27_1 == 9 then
    return 205, 133, 63
  elseif l_27_1 == 7 then
    return 121, 183, 54
  elseif l_27_1 == 10 then
    return 240, 70, 96
  end
  return 168, 168, 168
end

local l_0_10 = {}
l_0_10[10080] = "��"
l_0_10[10081] = "��"
l_0_10[10021] = "��"
l_0_10[10028] = "��"
l_0_10[10026] = "��"
l_0_10[10062] = "��"
l_0_10[10002] = "ϴ"
l_0_10[10003] = "��"
l_0_10[10014] = "��"
l_0_10[10015] = "��"
l_0_10[10144] = "��"
l_0_10[10145] = "ɽ"
l_0_10[10175] = "��"
l_0_10[10176] = "��"
l_0_10[10224] = "��"
l_0_10[10225] = "��"
l_0_10[10242] = "��"
l_0_10[10243] = "��"
l_0_10[10268] = "ؤ"
RaidGridEx.GetKungfuByID = function(l_28_0)
  -- upvalues: l_0_10
  local l_28_1 = RaidGridEx.GetTeamMemberInfo(l_28_0)
  local l_28_2 = l_28_1.dwMountKungfuID
  if not l_28_2 or l_28_2 == 0 then
    local l_28_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_28_3
  else
    if l_0_10[l_28_2] then
      local l_28_4 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      return l_28_4
    end
  else
    local l_28_5 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_28_5
  end
   -- WARNING: undefined locals caused missing assignments!
end

RaidGridEx.SetTarget = function(l_29_0)
  local l_29_1 = TARGET.NPC
  if not l_29_0 or l_29_0 <= 0 then
    l_29_1 = TARGET.NO_TARGET
    l_29_0 = 0
  else
    if IsPlayer(l_29_0) then
      l_29_1 = TARGET.PLAYER
    end
  end
  SetTarget(l_29_1, l_29_0)
end

RaidGridEx.IsInRaid = function()
  local l_30_0 = GetClientTeam()
  if not l_30_0 or l_30_0.nGroupNum <= 1 then
    return false
  end
  return true
end


