-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: comment.lua 

local l_0_0 = 180000
local l_0_1 = 18
local l_0_2 = 3
local l_0_3 = 1000
local l_0_4 = 23
local l_0_5 = 47
local l_0_6 = 10
local l_0_7 = 2
local l_0_8 = 3
local l_0_9 = {}
BoxComment_Base = class()
BoxComment = {}
BoxComment_Base.OnFrameCreate = function()
  this:RegisterEvent("UI_SCALED")
end

BoxComment_Base.OnEvent = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    BoxComment.AdjustSize(this)
    this:CorrectPos()
  end
end

BoxComment_Base.OnFrameBreathe = function()
  if not this.bHasObject then
    return 
  end
  assert(this.hObject)
  if not BoxComment_IsElemVisible(this.hObject) or this.nHoldTime < GetTickCount() - this.dwStartTime then
    CloseBoxComment(this:GetName())
    return 
  end
  if this.hObject:IsValid() and this.hObject:GetType() == "Box" then
    local l_3_0 = this.hObject:GetObjectType()
    local l_3_1 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if this.hObject:GetObjectData()(.end.hObject.nOldType, this.hObject.tOldData, l_3_0, l_3_1) then
    CloseBoxComment(this:GetName())
    return 
  end
  BoxComment.AdjustPos(this, this.hObject)
  local l_3_2 = this.hObject:GetRoot()
  assert(l_3_2)
  this:ChangeRelation(l_3_2, true)
end

BoxComment.AdjustPos = function(l_4_0, l_4_1)
  assert(l_4_0)
  assert(l_4_1)
  local l_4_2, l_4_3 = l_4_1:GetAbsPos()
  local l_4_4, l_4_5 = l_4_1:GetSize()
  local l_4_6, l_4_7 = Station.GetClientSize()
  local l_4_8 = l_4_0:Lookup("", "")
  local l_4_9 = l_4_8:Lookup("Image_TopLeft")
  local l_4_10 = l_4_8:Lookup("Image_TopRight")
  local l_4_11 = l_4_8:Lookup("Image_BottomLeft")
  local l_4_12 = l_4_8:Lookup("Image_BottomRight")
  l_4_9:Hide()
  l_4_10:Hide()
  l_4_11:Hide()
  l_4_12:Hide()
  l_4_0:CorrectPos(l_4_2, l_4_3, l_4_4, l_4_5, ALW.CENTER)
  local l_4_13, l_4_14 = l_4_0:GetAbsPos()
  if l_4_13 < l_4_2 then
    if l_4_14 < l_4_3 then
      l_4_12:Show()
    else
      l_4_10:Show()
    end
  elseif l_4_14 < l_4_3 then
    l_4_11:Show()
  else
    l_4_9:Show()
  end
end

BoxComment.AdjustSize = function(l_5_0)
  -- upvalues: l_0_1 , l_0_2 , l_0_6
  assert(l_5_0)
  local l_5_1 = l_5_0:Lookup("", "")
  l_5_1:SetItemStartRelPos(0, 0)
  local l_5_2 = l_5_1:Lookup("Handle_Message")
  local l_5_3, l_5_4 = l_5_2:GetAllItemSize()
  l_5_2:SetSize(l_5_3, l_5_4)
  l_5_2:SetItemStartRelPos(0, 0)
  local l_5_5 = l_5_1:Lookup("Image_TopLeft")
  local l_5_6, l_5_7 = l_5_5:GetSize()
  l_5_5:SetRelPos(0, 0)
  local l_5_8 = l_5_1:Lookup("Animate_Mouse")
  local l_5_9, l_5_10 = l_5_8:GetSize()
  local l_5_11 = l_5_1:Lookup("Image_BG")
  if l_5_9 > 0 then
    fBGWidth = l_0_1 + l_5_9 + l_0_1 + l_5_3 + l_0_1
  else
    fBGWidth = l_0_1 + l_5_9 + l_5_3 + l_0_1
  end
  if l_5_10 < l_5_4 then
    fBGHeight = l_0_1 + l_5_4 + l_0_1
  else
    fBGHeight = l_0_1 + l_5_10 + l_0_1
  end
  l_5_11:SetSize(fBGWidth, fBGHeight)
  l_5_11:SetRelPos(0, l_5_7 - l_0_2)
  local l_5_12 = l_5_0:Lookup("Btn_Close")
  local l_5_13, l_5_14 = l_5_12:GetSize()
  l_5_12:SetRelPos(fBGWidth - l_5_13 - l_0_6, l_5_7 - l_0_2 + l_0_6)
  if l_5_9 > 0 then
    l_5_2:SetRelPos(l_0_1 + l_5_9 + l_0_1, l_5_7 + (fBGHeight - l_5_4) / 2)
  else
    l_5_2:SetRelPos(l_0_1 + l_5_9, l_5_7 + (fBGHeight - l_5_4) / 2)
  end
  l_5_8:SetRelPos(l_0_1, l_5_7 + (fBGHeight - l_5_10) / 2)
  local l_5_15 = l_5_1:Lookup("Image_TopRight")
  l_5_15:SetRelPos(fBGWidth - l_5_6, 0)
  local l_5_16 = l_5_1:Lookup("Image_BottomLeft")
  l_5_16:SetRelPos(0, l_5_7 + fBGHeight - l_0_2 * 2)
  local l_5_17 = l_5_1:Lookup("Image_BottomRight")
  l_5_17:SetRelPos(fBGWidth - l_5_6, l_5_7 + fBGHeight - l_0_2 * 2)
  l_5_1:SetSize(fBGWidth, l_5_7 - l_0_2 + fBGHeight + (l_5_7 - l_0_2))
  l_5_1:FormatAllItemPos()
  l_5_0:SetSize(fBGWidth, l_5_7 - l_0_2 + fBGHeight + (l_5_7 - l_0_2))
end

BoxComment.SetHoldTime = function(l_6_0, l_6_1)
  l_6_0.nHoldTime = l_6_1
end

BoxComment.SetObject = function(l_7_0, l_7_1)
  l_7_0.bHasObject = true
  l_7_0.hObject = l_7_1
  if l_7_0.hObject then
    l_7_0:Show()
    BoxComment.AdjustPos(l_7_0, l_7_1)
  end
  if l_7_0.hObject:GetType() == "Box" then
    l_7_0.hObject.nOldType = l_7_0.hObject:GetObjectType()
    local l_7_2 = l_7_0.hObject
    local l_7_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BoxComment.OutputComment = function(l_8_0, l_8_1)
  assert(l_8_0.hObject)
  local l_8_2 = l_8_0:Lookup("", "Handle_Message")
  l_8_2:Clear()
  l_8_2:AppendItemFromString(l_8_1)
  l_8_2:FormatAllItemPos()
  BoxComment.AdjustSize(l_8_0)
  l_8_0:BringToTop()
end

BoxComment_Base.OnLButtonClick = function()
  CloseBoxComment(this:GetRoot():GetName())
end

CreateBoxComment = function(l_10_0)
  -- upvalues: l_0_0
  local l_10_1 = Wnd.OpenWindow("interface\\Moon_Lib\\ini\\CommentPanel.ini", l_10_0)
  assert(l_10_1)
  l_10_1.nHoldTime = l_0_0
  l_10_1.dwStartTime = GetTickCount()
  l_10_1.szResponse = "None"
  l_10_1.bHasObject = false
  local l_10_2 = l_10_1:Lookup("", "Animate_Mouse")
  l_10_2:Hide()
  l_10_2:SetSize(0, 0)
  l_10_1:Hide()
  return l_10_1
end

BoxComment_IsElemVisible = function(l_11_0)
  if not l_11_0:IsValid() then
    return false
  end
  if l_11_0:GetType() == "WndButton" and not l_11_0:IsEnabled() then
    return false
  end
  if l_11_0 then
    if not l_11_0:IsVisible() then
      return false
    end
    l_11_0 = l_11_0:GetParent()
  end
end
return true
end

BoxComment_IsBoxChanged = function(l_12_0, l_12_1, l_12_2, l_12_3)
  if l_12_0 ~= l_12_2 then
    return true
  end
  if #l_12_1 ~= #l_12_3 then
    return true
  end
  for l_12_7 = 1, #l_12_1 do
    if l_12_1[l_12_7] ~= l_12_3[l_12_7] then
      return true
    end
  end
  return false
end

CloseBoxComment = function(l_13_0, l_13_1)
  Wnd.CloseWindow(l_13_0)
  if not l_13_1 then
    PlaySound(SOUND.UI_SOUND, g_sound.CloseFrame)
  end
end


