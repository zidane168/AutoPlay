-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Book.lua 

local l_0_0 = {}
l_0_0.num = 147
Book = l_0_0
local l_0_1 = {}
local l_0_2 = {}
l_0_2.f = "i"
l_0_2.t = "dwID"
local l_0_3 = {}
l_0_3.f = "i"
l_0_3.t = "SubID"
local l_0_4 = {}
l_0_4.f = "s"
l_0_4.t = "szName"
local l_0_5 = {}
l_0_5.f = "i"
l_0_5.t = "dwDoodadTemplateID"
local l_0_6 = {}
l_0_6.f = "i"
l_0_6.t = "dwCostStamina"
local l_0_7 = {}
l_0_7.f = "i"
l_0_7.t = "dwProfessionID"
local l_0_8 = {}
l_0_8.f = "i"
l_0_8.t = "dwRequireLevel"
local l_0_9 = {}
l_0_9.f = "i"
l_0_9.t = "dwToolItemType"
local l_0_10 = {}
l_0_10.f = "i"
l_0_10.t = "dwToolItemIndex"
local l_0_11 = {}
l_0_11.f = "i"
l_0_11.t = "dwEquipmentType"
local l_0_12 = {}
l_0_12.f = "i"
l_0_12.t = "dwPrepareFrame"
local l_0_13 = {}
l_0_13.f = "i"
l_0_13.t = "dwPlayerExp"
local l_0_14 = {}
l_0_14.f = "i"
l_0_14.t = "dwProfessionExp"
local l_0_15 = {}
l_0_15.f = "i"
l_0_15.t = "dwExtendProfessionID1"
local l_0_16 = {}
l_0_16.f = "i"
l_0_16.t = "dwExtendExp1"
local l_0_17 = {}
l_0_17.f = "i"
l_0_17.t = "dwExtendProfessionID2"
local l_0_18 = {}
l_0_18.f = "i"
l_0_18.t = "dwExtendExp2"
local l_0_19 = {}
l_0_19.f = "i"
l_0_19.t = "dwCreateItemTab"
local l_0_20 = {}
l_0_20.f = "i"
l_0_20.t = "dwCreateItemIndex"
local l_0_21 = {}
l_0_21.f = "i"
l_0_21.t = "dwCreateItemStackNum"
local l_0_22 = {}
l_0_22.f = "i"
l_0_22.t = "dwBuffID"
local l_0_23 = {}
l_0_23.f = "i"
l_0_23.t = "dwBuffLevel"
local l_0_24 = {}
l_0_24.f = "i"
l_0_24.t = "dwTrain"
local l_0_25 = {}
l_0_25.f = "s"
l_0_25.t = "szScriptName"
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_1 = KG_Table
l_0_1 = l_0_1.Load
l_0_2, l_0_0 = l_0_0.Path, {Path = "\\settings\\Craft\\Read\\Book.tab", Title = l_0_1}
l_0_3 = l_0_0.Title
l_0_4 = FILE_OPEN_MODE
l_0_4 = l_0_4.NORMAL
l_0_1 = l_0_1(l_0_2, l_0_3, l_0_4)
l_0_2 = Book
l_0_3 = function()
  local l_1_0 = 0
  local l_1_1 = g_tTable.BookSegment:GetRowCount()
  for l_1_5 = 1, l_1_1 do
    local l_1_6 = g_tTable.BookSegment:GetRow(l_1_5).dwBookID
    if l_1_0 < l_1_6 then
      l_1_0 = l_1_6
    end
  end
  Book.num = l_1_0
end

l_0_2.GetBookLastBookID = l_0_3
l_0_2 = Book
l_0_2 = l_0_2.GetBookLastBookID
l_0_2()
l_0_3 = CraftReadManagePanel
l_0_4 = function(l_2_0)
  -- upvalues: l_0_2
  local l_2_1 = GetClientPlayer()
  local l_2_2 = "UI/Config/Default/CraftReadManagePanel.ini"
  local l_2_3 = l_2_0:Lookup("", "Handle_Book")
  local l_2_4 = {}
  for l_2_8 = 1, Book.num do
    table.insert(l_2_4, l_2_8)
  end
  local l_2_9 = false
  local l_2_10 = false
  do
    local l_2_11, l_2_12, l_2_13, l_2_14, l_2_15 = CraftReadManagePanel.GetFilterValue(l_2_0)
    l_2_3:Clear()
    do break end
    do
      local l_2_16, l_2_17, l_2_18, l_2_19, l_2_20 = pairs(l_2_4)
      local l_2_21 = Table_GetBookSort(l_2_20, 1)
      local l_2_22 = Table_GetBookSubSort(l_2_20, 1)
      local l_2_23 = GLOBAL.CURRENT_ITEM_VERSION
      local l_2_24 = 5
      if (CraftReadManagePanel.bIsSearch or CraftReadManagePanel.nSortID == l_2_21) and (l_2_11 == -1 or l_2_11 == l_2_22) then
        local l_2_25 = l_2_1.GetBookSegmentList(l_2_20)
        local l_2_26 = Table_GetBookNumber(l_2_20, 1)
        local l_2_27 = true
        local l_2_28 = {}
        for l_2_32,l_2_33 in pairs(l_2_25) do
          l_2_28[l_2_33] = true
        end
        for l_2_37 = 1, l_2_26 do
          local l_2_38 = GetRecipe(12, l_2_20, l_2_37)
          if l_2_38 then
            local l_2_39 = l_2_38.dwRequireProfessionLevel
            local l_2_40 = GetItemInfo(l_2_38.dwCreateItemType, l_2_38.dwCreateItemIndex)
            local l_2_41 = false
            if (l_2_40.bCanTrade and l_2_15) or not l_2_40.bCanTrade and not l_2_15 then
              l_2_41 = true
            end
            if l_0_2[l_2_14] then
              CraftReadManagePanel.bIsSearch = true
            do
              else
                local l_2_42 = l_2_0:Lookup("Edit_Search"):GetText()
              if l_2_42 then
                end
              if l_2_42 then
                end
              end
              CraftReadManagePanel.bIsSearch = false
            end
            if (l_2_12 == -1 or l_2_12 > l_2_39 or l_2_39 <= l_2_13) and (l_2_14 == -1 or ((l_2_14 == l_2_40.nBindType and l_2_41) or l_0_2[l_2_14])) then
              if l_2_27 and not CraftReadManagePanel.bIsSearch then
                local l_2_43 = l_2_3:AppendItemFromIni(l_2_2, "TreeLeaf_Name")
                l_2_43.bTitle = true
                local l_2_44 = Table_GetBookName(l_2_20, 1)
                l_2_43.szName = l_2_44
                local l_2_45 = #l_2_25
                local l_2_46 = l_2_43:Lookup("Text_Name")
                l_2_46:SetText(l_2_44 .. "(" .. l_2_45 .. "/" .. l_2_26 .. ")")
                local l_2_47 = l_2_46:GetTextExtent()
                local l_2_48 = l_2_43:Lookup("Image_All_Copy")
                local l_2_49, l_2_50 = l_2_48:GetRelPos()
                l_2_48:SetRelPos(l_2_47, l_2_50)
                l_2_43:FormatAllItemPos()
                l_2_48.nBookID = l_2_20
                l_2_48.nBookNum = l_2_26
                local l_2_51, l_2_52 = CraftReadManagePanel.GetTip(l_2_48)
                l_2_48.bEnable = l_2_52
                l_2_48.szTip = l_2_51
                CraftReadManagePanel.UpdateCheckState(l_2_48)
                if CraftReadManagePanel.tExpand[l_2_44] then
                  l_2_43:Expand()
                end
                l_2_27 = false
              end
              local l_2_53 = Table_GetSegmentName(l_2_20, l_2_37)
              local l_2_54 = "TreeLeaf_Page"
              local l_2_55 = 1
              if CraftReadManagePanel.bIsSearch then
                l_2_54 = "TreeLeaf_Search"
                l_2_55 = StringFindW(l_2_53, CraftReadManagePanel.szSearchKey or "")
              end
              if l_2_55 then
                l_2_9 = true
              end
              if l_0_2[l_2_14] then
                local l_2_56 = GetRecipe(8, l_2_20, l_2_37)
                if l_2_14 == 5 then
                  if l_2_56.nPlayerExp <= 0 then
                    l_2_55 = not l_2_56
                else
                  end
                end
                if l_2_56.nTrain <= 0 then
                  l_2_55 = l_2_14 ~= 6
                  do return end
                end
                if l_2_56.dwBuffID <= 0 then
                  l_2_55 = l_2_14 ~= 7
                  do return end
                end
                if l_2_56.dwCreateItemTab <= 0 then
                  l_2_55 = l_2_14 ~= 8
                  do return end
                end
                if l_2_14 == 9 then
                  if l_2_56.dwCreateItemTab > 0 then
                    local l_2_57 = GetItemInfo(l_2_56.dwCreateItemTab, l_2_56.dwCreateItemIndex)
                  end
                  l_2_55 = not l_2_57 or (l_2_57.nGenre == ITEM_GENRE.MATERIAL and l_2_57.nSub == ITEM_SUBTYPE_RECIPE)
                else
                  l_2_55 = false
                end
              end
              if l_2_55 then
                l_2_9 = true
              end
            end
            if l_2_55 then
              local l_2_58 = l_2_3:AppendItemFromIni(l_2_2, l_2_54)
              l_2_58:ClearEvent()
              l_2_58:RegisterEvent(289)
              local l_2_59, l_2_60, l_2_61 = GetItemFontColorByQuality(l_2_40.nQuality, false)
              l_2_58.bItem = true
              l_2_58.bRead = l_2_28[l_2_37]
              if CraftReadManagePanel.bIsSearch then
                l_2_58:SetName("TreeLeaf_Page")
                l_2_58:Lookup("Text_PageS"):SetName("Text_Page")
                l_2_58:Lookup("Image_PageS"):SetName("Image_Page")
              end
              l_2_58.nBookID = l_2_20
              l_2_58.nSegmentID = l_2_37
              if not l_2_58.bRead then
                l_2_53 = l_2_53 .. "(δ�Ķ�)"
              end
              l_2_58:Lookup("Text_Page"):SetText(l_2_53)
              l_2_58:Lookup("Text_Page"):SetFontScheme(162)
              l_2_58:Lookup("Text_Page"):SetFontColor(l_2_59, l_2_60, l_2_61)
            end
            if l_2_20 == CraftReadManagePanel.nBookID and l_2_37 == CraftReadManagePanel.nSegmentID then
              CraftReadManagePanel.Selected(l_2_0, l_2_58)
              CraftReadManagePanel.UpdateCondition(l_2_0)
              l_2_10 = true
            end
          else
            Trace("KLUA[ERROR] ui/Config/Default/CraftReadManagePanel.lua  the reuturn value of GetRecipe(12, " .. l_2_20 .. ", " .. l_2_37 .. ") is nil!!\n")
          end
        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if not l_2_10 then
      CraftReadManagePanel.Selected(l_2_0, nil)
    end
    if CraftReadManagePanel.bIsSearch and not l_2_9 then
      l_2_3:AppendItemFromIni(l_2_2, "TreeLeaf_Search")
      local l_2_62 = l_2_3:Lookup(l_2_3:GetItemCount() - 1)
      l_2_62:Lookup("Text_PageS"):SetText(g_tStrings.STR_MSG_NOT_FIND_LIST)
      l_2_62:Lookup("Text_PageS"):SetFontScheme(162)
      l_2_62:Lookup("Image_PageS"):Hide()
    end
    l_2_3:Show()
    l_2_3:FormatAllItemPos()
    CraftReadManagePanel.OnUpdateScorllList(l_2_3)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_3.UpdateList = l_0_4
l_0_4 = Book
l_0_5 = function()
  -- upvalues: l_0_3
  local l_3_0 = GetClientPlayer()
  local l_3_1 = l_3_0.dwForceID
  if l_3_1 == 0 then
    return l_0_3[l_3_0.GetKungfuMount().dwMountType]
  else
    return l_3_1
  end
end

l_0_4.GetEffectForceID = l_0_5
l_0_4 = Book
l_0_5 = function(l_4_0, l_4_1)
  local l_4_2 = GetClientPlayer()
  local l_4_3 = GetQuestInfo(l_4_1)
  local l_4_4 = ""
  if l_4_3 and l_4_3.bRepeat then
    l_4_4 = GetFormatText("[�ظ�]\n", 105)
  else
    l_4_4 = l_4_4 .. GetFormatText("[��" .. l_4_0 .. "��]", 105)
    if l_4_2.GetQuestPhase(l_4_1) == 3 then
      l_4_4 = l_4_4 .. GetFormatText("(�����)\n", 105)
    end
  else
    l_4_4 = l_4_4 .. GetFormatText("(δ���)\n", 105)
  end
  local l_4_5 = l_4_3.GetHortation()
  if l_4_5.money then
    l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "��Ǯ��", 105) .. GetMoneyText(l_4_5.money) .. GetFormatText("\n")
  end
  if l_4_5.tongfund and l_4_5.tongfund ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "����ʽ�", 105) .. GetMoneyText(l_4_5.tongfund) .. GetFormatText("\n")
  end
  if l_4_5.presentexamprint and l_4_5.presentexamprint ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(FormatString(g_tStrings.STR_TWO_CHINESE_SPACE .. "�౾ӡ�ģ�<D0>\n", l_4_5.presentexamprint), 105)
  end
  if l_4_5.presentjustice and l_4_5.presentjustice ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(FormatString(g_tStrings.STR_TWO_CHINESE_SPACE .. "����ֵ��<D0>\n", l_4_5.presentjustice), 105)
  end
  if l_4_5.presenttrain and l_4_5.presenttrain ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(FormatString(g_tStrings.STR_TWO_CHINESE_SPACE .. "��Ϊ��<D0>\n", l_4_5.presenttrain), 105)
  end
  if l_4_5.contribution and l_4_5.contribution ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(FormatString(g_tStrings.STR_TWO_CHINESE_SPACE .. "�ﹱ��<D0>\n", l_4_5.contribution), 105)
  end
  if l_4_5.tongdevelopmentpoint and l_4_5.tongdevelopmentpoint ~= 0 then
    l_4_4 = l_4_4 .. GetFormatText(FormatString(g_tStrings.STR_TWO_CHINESE_SPACE .. "��ᷢչ�㣺<D0>\n", l_4_5.tongdevelopmentpoint), 105)
  end
  if l_4_5.skill then
    l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "���ܣ�" .. "[" .. Table_GetSkillName(l_4_5.skill) .. "]\n", 105)
  end
  if l_4_5.reputation then
    l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "������", 100)
    for l_4_9,l_4_10 in ipairs(l_4_5.reputation) do
      l_4_4 = l_4_4 .. GetFormatText(g_tReputation.tReputationTable[l_4_10.force].szName .. "(+" .. l_4_10.value .. ")", 105)
      if l_4_9 ~= #l_4_5.reputation then
        l_4_4 = l_4_4 .. "<Text>text=\"��\" r=192 b=192 g=192</Text>"
      else
        l_4_4 = l_4_4 .. "<Text>text=\"\n\"</Text>"
      end
    end
  end
  for l_4_14 = 1, 2 do
    local l_4_15 = l_4_5["itemgroup" .. l_4_14]
    if l_4_15 then
      local l_4_16 = ""
      for l_4_20,l_4_21 in ipairs(l_4_15) do
        if not l_4_15.accord2force or l_4_21.selectindex == QuestEx.GetEffectForceID() - 1 then
          local l_4_22 = GetItemInfo(l_4_21.type, l_4_21.index)
        end
        if l_4_22 then
          l_4_16 = l_4_16 .. "<Text>text=" .. EncodeComponentsString("[" .. l_4_22.szName .. "]") .. " font=105 </text>"
          if l_4_20 ~= #l_4_15 then
            l_4_16 = l_4_16 .. "<Text>text=\"��\" r=192 b=192 g=192</Text>"
          end
        else
          l_4_16 = l_4_16 .. "<Text>text=\"\n\"</Text>"
        end
      end
    end
    if l_4_16 ~= "" then
      if l_4_15.all then
        l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "��Ʒ(ȫ��)��", 100)
      else
        l_4_4 = l_4_4 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "��Ʒ(ѡ��)��", 100)
      end
      l_4_4 = l_4_4 .. l_4_16
    end
  end
  return l_4_4
end

l_0_4.GetQuestTip = l_0_5
l_0_4 = Book
l_0_5 = function(l_5_0, l_5_1, l_5_2, l_5_3)
  if bRemove then
    MiddleMap.dwMapMarkMapID = nil
    MiddleMap.dwMapMarkX = nil
    MiddleMap.dwMapMarkY = nil
    MiddleMap.dwMapMarkType = nil
    MiddleMap.szMapMarkName = nil
  else
    MiddleMap.dwMapMarkMapID = l_5_0
    local l_5_4 = MiddleMap
    local l_5_5 = nil
    if not l_5_1 then
      l_5_5 = 50000
    end
    l_5_4.dwMapMarkX = l_5_5
    l_5_4 = MiddleMap
    l_5_5 = l_5_2 or 50000
    l_5_4.dwMapMarkY = l_5_5
    l_5_4 = MiddleMap
    l_5_4.dwMapMarkType = 2
    l_5_4 = MiddleMap
    l_5_5 = l_5_3 or "����"
    l_5_4.szMapMarkName = l_5_5
  end
  OpenMiddleMap(l_5_0, 0)
  local l_5_6 = Station.Lookup("Topmost1/MiddleMap", "Handle_Map")
  if l_5_6 then
    MiddleMap.UpdateMapMark(l_5_6)
  end
end

l_0_4.OpenMiddleMapMark = l_0_5
l_0_4 = Book
l_0_5 = function(l_6_0, l_6_1)
  local l_6_2 = ""
  local l_6_3 = GetClientPlayer()
  local l_6_4 = BookID2GlobelRecipeID(l_6_0, l_6_1)
  local l_6_5 = Table_GetSegmentName(l_6_0, l_6_1)
  if ShopBook[l_6_4] then
    l_6_2 = GetFormatText("�̵꣺\n", 100)
    for l_6_9,l_6_10 in pairs(ShopBook[l_6_4]) do
      if l_6_10[4] ~= 0 and l_6_10[3] ~= "0" then
        l_6_2 = l_6_2 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "[" .. Table_GetMapName(l_6_10[4]) .. "]" .. l_6_10[3] .. "-" .. l_6_10[2] .. "\n", 106)
      elseif l_6_10[4] ~= 0 and l_6_10[3] == "0" then
        l_6_2 = l_6_2 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. "[" .. Table_GetMapName(l_6_10[4]) .. "]" .. l_6_10[2] .. "\n", 106)
      else
        l_6_2 = l_6_2 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. l_6_10[3] .. "-" .. l_6_10[2] .. "\n", 106)
      end
    end
    do break end
  end
  if QuestBook[l_6_4] then
    l_6_2 = GetFormatText("����\n", 100)
    for l_6_14,l_6_15 in pairs(QuestBook[l_6_4]) do
      local l_6_16 = Table_GetQuestStringInfo(l_6_15)
      if l_6_16 then
        l_6_2 = l_6_2 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_TWO_CHINESE_SPACE .. "[" .. l_6_16.szName .. "]\n") .. " font=67 </text>"
      end
    end
    do break end
  end
  if Stele["������" .. l_6_5] then
    l_6_2 = GetFormatText("������\n", 100)
    local l_6_17 = Stele["������" .. l_6_5]
    for l_6_21,l_6_22 in ipairs(Stele["������" .. l_6_5]) do
      l_6_2 = l_6_2 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_TWO_CHINESE_SPACE .. "[" .. Table_GetMapName(l_6_22[1]) .. "]\n") .. " font=162 </text>"
    end
  else
    l_6_2 = GetFormatText("���䣺\n", 100)
    local l_6_23 = GetRecipe(8, l_6_0, l_6_1)
    local l_6_24 = l_6_23.dwRequireProfessionLevel
    local l_6_25 = ""
    if l_6_24 > 8 then
      l_6_25 = l_6_24 .. "-" .. l_6_24 + 4 .. "����������"
    end
    l_6_2 = l_6_2 .. GetFormatText(g_tStrings.STR_TWO_CHINESE_SPACE .. l_6_25 .. "\n", 106)
  end
  return l_6_2
end

l_0_4.GetBookFrom = l_0_5
l_0_4 = Book
l_0_5 = function(l_7_0, l_7_1)
  local l_7_2 = GetRecipe(12, l_7_0, l_7_1)
  local l_7_3 = GetClientPlayer()
  local l_7_4 = ""
  local l_7_5 = ""
  local l_7_6 = ""
  do
    local l_7_7 = ""
    if not l_7_2 then
      l_7_5 = l_7_5 .. "<text>text=" .. EncodeComponentsString(g_tStrings.CRAFT_READING_CANNOT_COPY) .. " font=162 </text>"
    else
      l_7_5 = l_7_5 .. GetFormatText("��¼������<�������ӣ�" .. l_7_2.dwExp .. "��>\n", 163)
      local l_7_8 = 5
      local l_7_9 = Table_GetBookItemIndex(l_7_0, l_7_1)
      local l_7_10 = GetItemInfo(l_7_8, l_7_9)
      local l_7_11 = l_7_3.GetProfessionLevel(8)
      local l_7_12 = 162
      if l_7_11 < l_7_2.dwRequireProfessionLevel then
        l_7_12 = 102
      end
      l_7_5 = l_7_5 .. "<text>text=" .. EncodeComponentsString(FormatString(g_tStrings.CRAFT_READING_REQUIRE_LEVEL, l_7_2.dwRequireProfessionLevel)) .. " font=" .. l_7_12 .. " </text>"
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_7_2.dwProfessionIDExt ~= 0 and GetProfession(l_7_2.dwProfessionIDExt) then
        if l_7_3.GetProfessionLevel(l_7_2.dwProfessionIDExt) < l_7_2.dwRequireProfessionLevelExt then
          l_7_5 = l_7_5 .. "<text>text=" .. EncodeComponentsString(Table_GetProfessionName(l_7_2.dwProfessionIDExt) .. l_7_2.dwRequireProfessionLevelExt .. g_tStrings.LEVEL_BLANK) .. " font=" .. l_7_12 .. " </text>"
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_7_2.nRequirePlayerLevel and l_7_2.nRequirePlayerLevel ~= 0 then
          if l_7_3.nLevel < l_7_2.nRequirePlayerLevel then
            l_7_5 = l_7_5 .. "<text>text=" .. EncodeComponentsString(FormatString(g_tStrings.STR_CRAFT_READ_NEED_PLAYER_LEVEL, l_7_2.nRequirePlayerLevel)) .. " font=" .. l_7_12 .. " </text>"
          end
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_7_3.nCurrentThew < l_7_2.nThew then
            l_7_6 = l_7_6 .. "<text>text=" .. EncodeComponentsString(FormatString(g_tStrings.CRAFT_COST_THEW_BLANK, l_7_2.nThew)) .. " font=" .. l_7_12 .. " </text>"
            if l_7_2.dwCoolDownID > 0 then
              local l_7_13 = ""
              local l_7_14 = l_7_3.GetCDInterval(l_7_2.dwCoolDownID)
              local l_7_15 = l_7_3.GetCDLeft(l_7_2.dwCoolDownID)
              if l_7_15 <= 0 then
                local l_7_16 = ForamtCoolDownTime(l_7_14)
                l_7_13 = g_tStrings.TIME_CD .. l_7_16
              else
                local l_7_17 = ForamtCoolDownTime(l_7_15)
                if not l_7_17 or l_7_17 == "" then
                  l_7_15 = 0
                  local l_7_18 = ForamtCoolDownTime(l_7_14)
                  l_7_13 = g_tStrings.TIME_CD .. l_7_18
                end
              else
                l_7_13 = g_tStrings.TIME_CD1 .. l_7_17
              end
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              if l_7_15 ~= 0 then
                l_7_6 = l_7_6 .. "<text>text=" .. EncodeComponentsString(l_7_13) .. " font=" .. l_7_12 .. " </text>"
              end
              if l_7_2.dwToolItemType ~= 0 and l_7_2.dwToolItemIndex ~= 0 then
                local l_7_19 = GetItemInfo(l_7_2.dwToolItemType, l_7_2.dwToolItemIndex)
                do
                  local l_7_20 = GetItemNameByItemInfo(l_7_19)
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

              end
              if l_7_3.GetItemAmount(l_7_2.dwToolItemType, l_7_2.dwToolItemIndex) <= 0 then
                end
                 -- DECOMPILER ERROR: Overwrote pending register.

                for l_7_24 = 1, 4 do
                  local l_7_25 = l_7_2["dwRequireItemType" .. l_7_24]
                  local l_7_26 = l_7_2["dwRequireItemIndex" .. l_7_24]
                  local l_7_27 = l_7_2["dwRequireItemCount" .. l_7_24]
                  if l_7_27 > 0 then
                    local l_7_28 = GetItemInfo(l_7_25, l_7_26)
                    do
                      local l_7_29 = GetItemNameByItemInfo(l_7_28)
                       -- DECOMPILER ERROR: Overwrote pending register.

                       -- DECOMPILER ERROR: Overwrote pending register.

                       -- DECOMPILER ERROR: Overwrote pending register.

                  end
                  if l_7_3.GetItemAmount(l_7_25, l_7_26) < l_7_27 then
                    end
                  end
                  l_7_4 = l_7_4 .. l_7_5 .. "<text>text=\"\\\n\"</text>" .. l_7_6 .. "<text>text=\"\\\n\"</text>" .. l_7_7 .. "<text>text=\"\\\n\"</text>"
                end
                return l_7_4
              end
               -- WARNING: missing end command somewhere! Added here
            end
             -- WARNING: missing end command somewhere! Added here
          end
           -- WARNING: missing end command somewhere! Added here
        end
         -- WARNING: missing end command somewhere! Added here
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 78 105 124 181 219 271 
end

l_0_4.GetCopyTip = l_0_5
l_0_4 = Book
l_0_5 = function(l_8_0, l_8_1)
  -- upvalues: l_0_1
  local l_8_2 = GetClientPlayer()
  local l_8_3 = l_0_1:Search(l_8_0, l_8_1)
  local l_8_4 = ""
  l_8_4 = l_8_4 .. GetFormatText("�Ķ�������\n", 100)
  if l_8_3.dwCreateItemTab > 0 then
    local l_8_5 = GetItemInfo(l_8_3.dwCreateItemTab, l_8_3.dwCreateItemIndex)
  end
  if l_8_5 then
    local l_8_7, l_8_8 = "{" .. l_8_3.dwCreateItemTab .. "," .. l_8_3.dwCreateItemIndex .. "}"
    l_8_8 = l_8_4
    l_8_4 = l_8_8 .. GetFormatText("�����Ʒ��", 105)
    l_8_8 = l_8_4
    l_8_4 = l_8_8 .. "<text>text=" .. EncodeComponentsString("[" .. GetItemNameByItemInfo(l_8_5, l_8_3.nBookID) .. "]\n") .. "font=105 " .. GetItemFontColorByQuality(l_8_5.nQuality, true) .. " </text>"
  end
  if l_8_3.dwBuffID ~= 0 and l_8_3.dwBuffLevel ~= 0 then
    local l_8_6 = Table_GetBuff
    l_8_6 = l_8_6(l_8_3.dwBuffID, l_8_3.dwBuffLevel)
    l_8_4 = l_8_4 .. GetFormatText("������棺[" .. l_8_6.szName .. "]\n", 105)
    l_8_4 = l_8_4 .. GetFormatText("����Ч����" .. GetBuffDesc(l_8_3.dwBuffID, l_8_3.dwBuffLevel, "desc") .. "\n", 105)
  end
  if l_8_3.dwPlayerExp > 0 then
    l_8_4 = l_8_4 .. GetFormatText("���������" .. l_8_3.dwPlayerExp .. "\n", 105)
  end
  if l_8_3.dwTrain > 0 then
    l_8_4 = l_8_4 .. GetFormatText("�����Ϊ��" .. l_8_3.dwTrain .. "\n", 105)
  end
  if l_8_3.dwProfessionExp ~= 0 then
    l_8_4 = l_8_4 .. GetFormatText("�Ķ�������" .. l_8_3.dwProfessionExp .. "\n", 105)
  end
  if l_8_3.dwExtendProfessionID1 > 0 and l_8_3.dwExtendExp1 > 0 then
    l_8_4 = l_8_4 .. GetFormatText(GetProfession(l_8_3.dwExtendProfessionID1).szProfessionName .. "������" .. l_8_3.dwExtendExp1 .. "\n", 105)
  end
  local l_8_9 = BookID2GlobelRecipeID(l_8_0, 1)
  if BookExchange[l_8_9] then
    l_8_4 = l_8_4 .. GetFormatText("���齱����\n", 100)
    for l_8_13,l_8_14 in pairs(BookExchange[l_8_9]) do
      l_8_4 = l_8_4 .. Book.GetQuestTip(l_8_13, l_8_14)
    end
  end
  do
    local l_8_15 = Book.GetBookFrom(l_8_0, l_8_1)
    if l_8_15 then
      l_8_4 = l_8_4 .. l_8_15
    end
    l_8_4 = l_8_4 .. Book.GetCopyTip(l_8_0, l_8_1)
  end
  return l_8_4
end

l_0_4.GetBookTip = l_0_5
l_0_4 = function(l_9_0, l_9_1, l_9_2)
  local l_9_3 = GetRecipe(12, l_9_0, l_9_1)
  if l_9_3 then
    local l_9_4 = GetItemInfo(l_9_3.dwCreateItemType, l_9_3.dwCreateItemIndex)
    local l_9_5 = GetBookTipByItemInfo(l_9_4, l_9_0, l_9_1)
    l_9_5 = l_9_5 .. Book.GetBookTip(l_9_0, l_9_1)
    OutputTip(l_9_5, 400, l_9_2)
  end
end

OutputBookTipByIDEx = l_0_4
l_0_4 = CraftReadComparePanel
l_0_5 = function()
  if this.bItem then
    this.bOver = true
    CraftReadComparePanel.UpdateBgStatus(this)
    local l_10_0 = this:GetIndex()
    local l_10_1, l_10_2 = this:GetAbsPos()
    local l_10_3, l_10_4 = this:GetSize()
    local l_10_5 = OutputBookTipByIDEx
    local l_10_6 = this.nBookID
    local l_10_7 = this.nSegmentID
    local l_10_8 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_10_5(l_10_6, l_10_7, l_10_8)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_4.OnItemMouseEnter = l_0_5
l_0_4 = CraftReadManagePanel
l_0_5 = function()
  if this.bItem then
    local l_11_0, l_11_1 = this:GetAbsPos()
    do
      local l_11_2, l_11_3 = this:GetSize()
      local l_11_4 = {}
      local l_11_5 = this.nBookID
      local l_11_6 = this.nSegmentID
      local l_11_7 = BookID2GlobelRecipeID(l_11_5, l_11_6)
      local l_11_8 = Table_GetSegmentName(l_11_5, l_11_6)
      local l_11_9 = "������" .. l_11_8
      if QuestBook[l_11_7] then
        l_11_4.fnAction = function(l_12_0, l_12_1)
        -- upvalues: l_11_0 , l_11_1 , l_11_2 , l_11_3
        if not l_12_0 then
          return 
        end
        local l_12_2 = OutputQuestTip
        local l_12_3 = l_12_0
        do
          local l_12_4 = {}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_12_2(l_12_3, l_12_4, true)
        end
         -- WARNING: undefined locals caused missing assignments!
      end
        local l_11_10 = table.insert
        local l_11_11 = l_11_4
        local l_11_12 = {}
        l_11_12.szOption = "����(����)��"
        l_11_10(l_11_11, l_11_12)
        l_11_10 = table
        l_11_10 = l_11_10.insert
        l_11_11 = l_11_4
        l_11_10(l_11_11, l_11_12)
        l_11_12 = {bDevide = true}
        l_11_10 = pairs
        l_11_11 = QuestBook
        l_11_11 = l_11_11[l_11_7]
        l_11_10 = l_11_10(l_11_11)
        for i_1,i_2 in l_11_10 do
          local l_11_15 = Table_GetQuestStringInfo(l_11_14)
          if l_11_15 then
            local l_11_16 = table.insert
            local l_11_17 = l_11_4
            local l_11_18 = {}
            l_11_18.szOption = l_11_15.szName
            l_11_18.UserData = l_11_14
            l_11_16(l_11_17, l_11_18)
          end
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        do break end
      end
      if Stele[l_11_9] then
        l_11_4.fnAction = function(l_13_0, l_13_1)
        -- upvalues: l_11_9
        if not l_13_0 then
          return 
        end
        Book.OpenMiddleMapMark(l_13_0[1], l_13_0[2], l_13_0[3], l_11_9)
      end
        local l_11_19 = nil
        local l_11_20 = nil
        local l_11_21 = nil
        table.insert(l_11_4, l_11_19)
        l_11_19 = {szOption = "����(����)��"}
        table.insert(l_11_4, l_11_19)
        l_11_19 = {bDevide = true}
        for l_11_20,l_11_21 in ipairs(Stele[l_11_9]) do
          local l_11_22, l_11_23 = nil
          l_11_22 = table
          l_11_22 = l_11_22.insert
          local l_11_24 = nil
          l_11_23 = l_11_4
          local l_11_25 = nil
          local l_11_26 = nil
          l_11_25 = Table_GetMapName
          l_11_26 = l_11_21[1]
          l_11_25 = l_11_25(l_11_26)
          l_11_22(l_11_23, l_11_24)
          l_11_24 = {szOption = l_11_25, UserData = l_11_21}
        end
      end
      if #l_11_4 > 1 then
        PopupMenu(l_11_4)
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
end

l_0_4.OnItemRButtonClick = l_0_5
l_0_4 = CraftReadManagePanel
l_0_5 = function()
  if this.bItem then
    this.bOver = true
    CraftReadManagePanel.UpdateBgStatus(this)
    local l_12_0, l_12_1 = this:GetAbsPos()
    local l_12_2, l_12_3 = this:GetSize()
    local l_12_4 = OutputBookTipByIDEx
    local l_12_5 = this.nBookID
    local l_12_6 = this.nSegmentID
    local l_12_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_12_4(l_12_5, l_12_6, l_12_7)
  else
    if this:GetName() == "Image_All_Copy" then
      CraftReadManagePanel.UpdateCheckState(this)
      local l_12_8 = this.szTip
      local l_12_9, l_12_10 = this:GetAbsPos()
      local l_12_11, l_12_12 = this:GetSize()
      local l_12_13 = OutputTip
      local l_12_14 = l_12_8
      local l_12_15 = 400
      local l_12_16 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_12_13(l_12_14, l_12_15, l_12_16)
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_4.OnItemMouseEnter = l_0_5
l_0_6 = ITEM_BIND
l_0_6 = l_0_6.NEVER_BIND
l_0_5 = {nBindType = l_0_6, bCanTrade = true}
l_0_6 = ITEM_BIND
l_0_6 = l_0_6.BIND_ON_PICKED
l_0_5 = {nBindType = l_0_6, bCanTrade = true}
l_0_6 = ITEM_BIND
l_0_6 = l_0_6.BIND_ON_PICKED
l_0_5 = {nBindType = l_0_6, bCanTrade = false}
l_0_5 = {nBindType = 5, bCanTrade = true}
l_0_5 = {nBindType = 6, bCanTrade = true}
l_0_5 = CraftReadComparePanel
l_0_5 = l_0_5.OnLButtonClick
old_readcompareclick = l_0_5
l_0_5 = CraftReadComparePanel
l_0_6 = function()
  -- upvalues: l_0_4
  local l_13_0 = this:GetName()
  if l_13_0 == "Btn_Kind" then
    local l_13_1 = {}
    for l_13_5,l_13_6 in pairs(l_0_4) do
      table.insert(l_13_1, l_13_5)
    end
    table.sort(l_13_1, function(l_14_0, l_14_1)
      -- upvalues: l_0_4
      return l_0_4[l_14_0].nBindType <= l_0_4[l_14_1].nBindType
    end)
    table.insert(l_13_1, 1, g_tStrings.STR_BOOK_ALL_STATUS)
    do
      local l_13_7, l_13_8 = this:GetParent():Lookup("", "Text_Kind")
      l_13_8 = CraftReadComparePanel
      l_13_8 = l_13_8.PopupMenu
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_13_8(this, l_13_7, l_13_1)
  else
    old_readcompareclick()
  end
end

l_0_5.OnLButtonClick = l_0_6
l_0_5 = CraftReadComparePanel
l_0_6 = function(l_14_0)
  -- upvalues: l_0_4
  local l_14_1 = l_14_0:Lookup("", "")
  local l_14_2 = l_14_1:Lookup("Text_Type")
  local l_14_3 = l_14_1:Lookup("Text_Level")
  local l_14_4 = l_14_1:Lookup("Text_Kind")
  if l_14_2:GetText() == g_tStrings.STR_BOOK_ALL_TYPE then
    do return end
  end
  do
    local l_14_5 = g_tStrings.tBookType[-1]
  end
  local l_14_6 = nil
  local l_14_7 = -1
  local l_14_8 = -1
  if l_14_3:GetText() ~= g_tStrings.STR_BOOK_ALL_LEVEL then
    l_14_7 = g_tStrings.tBookLevel[l_14_3:GetText()][1]
    l_14_8 = g_tStrings.tBookLevel[l_14_3:GetText()][2]
  end
  local l_14_9 = nil
  local l_14_10 = l_14_4:GetText()
  local l_14_11 = -1
  if l_14_10 == g_tStrings.STR_BOOK_ALL_STATUS then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  CraftReadComparePanel.UpdateFilterValue(l_14_0, true)
  return l_14_6, l_14_7, l_14_8, l_14_11, true
end

l_0_5.GetFilterValue = l_0_6
l_0_5 = CraftReadComparePanel
l_0_6 = function(l_15_0)
  local l_15_1 = GetClientPlayer()
  local l_15_2 = GetPlayer(CraftReadComparePanel.nPlayerID)
  if not l_15_2 then
    return 
  end
  local l_15_3 = false
  local l_15_4 = false
  local l_15_5 = "UI/Config/Default/CraftReadComparePanel.ini"
  local l_15_6 = l_15_0:Lookup("", "Handle_Book")
  local l_15_7 = l_15_1.GetBookList()
  local l_15_8 = l_15_2.GetBookList()
  local l_15_9 = GLOBAL.CURRENT_ITEM_VERSION
  local l_15_10 = 5
  local l_15_11, l_15_12, l_15_13, l_15_14, l_15_15 = CraftReadComparePanel.GetFilterValue(l_15_0)
  local l_15_16 = {}
  do
    local l_15_17 = {}
    for l_15_21,l_15_22 in pairs(l_15_7) do
      if not l_15_17[l_15_22] then
        l_15_17[l_15_22] = true
        table.insert(l_15_16, l_15_22)
      end
    end
    for l_15_26,l_15_27 in pairs(l_15_8) do
      if not l_15_17[l_15_27] then
        l_15_17[l_15_27] = true
        table.insert(l_15_16, l_15_27)
      end
    end
    table.sort(l_15_16, function(l_16_0, l_16_1)
    return l_16_0 < l_16_1
  end)
    l_15_6:Clear()
    do break end
    do
      local l_15_28, l_15_29, l_15_30, l_15_31, l_15_32 = pairs(l_15_16)
      local l_15_33 = Table_GetBookSort(l_15_32, 1)
      local l_15_34 = Table_GetBookSubSort(l_15_32, 1)
      if CraftReadComparePanel.nSortID == l_15_33 and (l_15_11 == -1 or l_15_11 == l_15_34) then
        local l_15_35 = l_15_1.GetBookSegmentList(l_15_32)
        local l_15_36 = l_15_2.GetBookSegmentList(l_15_32)
        local l_15_37 = Table_GetBookNumber(l_15_32, 1)
        local l_15_38 = true
        local l_15_39 = {}
        local l_15_40 = {}
        for l_15_44,l_15_45 in pairs(l_15_35) do
          l_15_39[l_15_45] = true
        end
        for l_15_49,l_15_50 in pairs(l_15_36) do
          l_15_40[l_15_50] = true
        end
        local l_15_51 = true
        for l_15_55 = 1, l_15_37 do
          do
            local l_15_56, l_15_72 = GetRecipe(12, l_15_32, l_15_55)
            if l_15_56 then
              l_15_72 = l_15_56.dwRequireProfessionLevel
              local l_15_57 = nil
              l_15_57 = GetItemInfo
              l_15_57 = l_15_57(l_15_56.dwCreateItemType, l_15_56.dwCreateItemIndex)
              local l_15_58 = nil
              l_15_58 = false
              local l_15_59 = nil
              l_15_59 = l_15_57.bCanTrade
              if not l_15_59 or not l_15_15 then
                l_15_59 = l_15_57.bCanTrade
              if not l_15_59 and not l_15_15 then
                end
              end
              l_15_58 = true
              l_15_59 = true
              local l_15_60 = nil
              if l_15_14 == 5 then
                l_15_60 = l_15_40[l_15_55]
                if not l_15_60 then
                  l_15_60 = l_15_39[l_15_55]
                  if l_15_60 then
                    l_15_60 = l_15_57.nBindType
                  if l_15_60 == 3 then
                    end
                  end
                  l_15_59 = false
                elseif l_15_14 == 6 then
                  l_15_60 = l_15_39[l_15_55]
                  if not l_15_60 then
                    l_15_60 = l_15_40[l_15_55]
                  end
                  if l_15_60 then
                    l_15_60 = l_15_57.nBindType
                  if l_15_60 == 3 then
                    end
                  end
                  l_15_59 = false
                end
                if l_15_12 == -1 or l_15_12 <= l_15_72 and l_15_72 <= l_15_13 then
                  if l_15_14 ~= -1 then
                    l_15_60 = l_15_57.nBindType
                  if l_15_14 == l_15_60 then
                    end
                  if l_15_14 == l_15_60 then
                    end
                  end
                if l_15_14 ~= 5 then
                  end
                if l_15_14 ~= 5 then
                  end
                end
                if l_15_59 then
                  if l_15_51 then
                    l_15_60 = CraftReadComparePanel
                    l_15_60 = l_15_60.bIsSearch
                  end
                   -- DECOMPILER ERROR: Overwrote pending register.

                  if not l_15_60 then
                    local l_15_61 = nil
                    l_15_60.bTitle = true
                    l_15_61 = Table_GetBookName
                    l_15_61 = l_15_61(l_15_32, 1)
                    local l_15_62 = nil
                    l_15_60.szName = l_15_61
                    l_15_62 = #l_15_35
                    local l_15_63 = nil
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_15_63(l_15_63, l_15_61 .. "(" .. l_15_62 .. "/" .. l_15_37 .. ")")
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    if l_15_63 then
                      l_15_63(l_15_60)
                    end
                    l_15_51 = false
                  end
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  local l_15_64 = nil
                  l_15_64 = "TreeLeaf_Page"
                  local l_15_65 = nil
                  l_15_65 = 1
                  local l_15_66 = l_15_63
                  l_15_66 = CraftReadComparePanel
                  l_15_66 = l_15_66.bIsSearch
                  if l_15_66 then
                    l_15_64 = "TreeLeaf_Search"
                    l_15_66 = StringFindW
                    l_15_66 = l_15_66(l_15_60, CraftReadComparePanel.szSearchKey or "")
                    l_15_65 = l_15_66
                  end
                  if l_15_65 then
                    l_15_3 = true
                  end
                end
                 -- DECOMPILER ERROR: Overwrote pending register.

                if l_15_65 then
                  local l_15_67 = nil
                  l_15_67 = GetItemFontColorByQuality
                  l_15_67 = l_15_67(l_15_57.nQuality, false)
                  local l_15_68, l_15_69, l_15_70 = nil
                  l_15_66.bItem = true
                  l_15_70 = l_15_39[l_15_55]
                  l_15_66.bRead = l_15_70
                  l_15_70 = CraftReadComparePanel
                  l_15_70 = l_15_70.bIsSearch
                  if l_15_70 then
                    l_15_70(l_15_66, "TreeLeaf_Page")
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_15_70(l_15_70, "Text_Page")
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_15_70(l_15_70, "Image_Page")
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_15_70(l_15_70, "Image_Book1")
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_15_70(l_15_70, "Image_Book2")
                  end
                  l_15_66.nBookID = l_15_32
                  l_15_66.nSegmentID = l_15_55
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  l_15_70(l_15_70, l_15_60)
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  l_15_70(l_15_70, 162)
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  l_15_70(l_15_70, l_15_67, l_15_68, l_15_69)
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  if l_15_70 then
                    l_15_70(l_15_70)
                  end
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  if l_15_70 then
                    l_15_70(l_15_70)
                  end
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  local l_15_71 = nil
                  l_15_71 = l_15_70.nBookID
                end
                if l_15_32 == l_15_71 then
                  l_15_71 = l_15_70.nSegmentID
                end
                if l_15_55 == l_15_71 then
                  l_15_71 = CraftReadComparePanel
                  l_15_71 = l_15_71.Selected
                  l_15_71(l_15_0, l_15_66)
                  l_15_71 = CraftReadComparePanel
                  l_15_71 = l_15_71.UpdateCondition
                  l_15_71(l_15_0)
                  l_15_4 = true
                end
              else
                l_15_72 = Trace
                 -- DECOMPILER ERROR: Overwrote pending register.

              end
               -- DECOMPILER ERROR: Confused about usage of registers!

              l_15_72("KLUA[ERROR] ui/Config/Default/CraftReadComparePanel.lua  the reuturn value of GetRecipe(12, " .. l_15_32 .. ", " .. l_15_60 .. ") is nil!!\n")
            end
          end
        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if not l_15_4 then
      CraftReadComparePanel.Selected(l_15_0, nil)
    end
    if CraftReadComparePanel.bIsSearch and not l_15_3 then
      l_15_6:AppendItemFromIni(l_15_5, "TreeLeaf_Search")
      local l_15_73 = l_15_6:Lookup(l_15_6:GetItemCount() - 1)
      l_15_73:Lookup("Text_PageS"):SetText(g_tStrings.STR_MSG_NOT_FIND_LIST)
      l_15_73:Lookup("Text_PageS"):SetFontScheme(162)
      l_15_73:Lookup("Image_PageS"):Hide()
    end
    l_15_6:Show()
    CraftReadComparePanel.OnUpdateScorllList(l_15_6)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 157 
end

l_0_5.UpdateList = l_0_6
l_0_7 = ITEM_BIND
l_0_7 = l_0_7.NEVER_BIND
l_0_6 = {nBindType = l_0_7, bCanTrade = true}
l_0_7 = ITEM_BIND
l_0_7 = l_0_7.BIND_ON_PICKED
l_0_6 = {nBindType = l_0_7, bCanTrade = true}
l_0_7 = ITEM_BIND
l_0_7 = l_0_7.BIND_ON_PICKED
l_0_6 = {nBindType = l_0_7, bCanTrade = false}
l_0_6 = {nBindType = 5, bCanTrade = true}
l_0_6 = {nBindType = 6, bCanTrade = true}
l_0_6 = {nBindType = 7, bCanTrade = true}
l_0_6 = {nBindType = 8, bCanTrade = true}
l_0_6 = {nBindType = 9, bCanTrade = true}
l_0_6 = CraftReadManagePanel
l_0_6 = l_0_6.OnLButtonClick
old_readmanageclick = l_0_6
l_0_6 = CraftReadManagePanel
l_0_7 = function()
  -- upvalues: l_0_5
  local l_16_0 = this:GetName()
  if l_16_0 == "Btn_Kind" then
    local l_16_1 = {}
    for l_16_5,l_16_6 in pairs(l_0_5) do
      table.insert(l_16_1, l_16_5)
    end
    table.sort(l_16_1, function(l_17_0, l_17_1)
      -- upvalues: l_0_5
      return l_0_5[l_17_0].nBindType <= l_0_5[l_17_1].nBindType
    end)
    table.insert(l_16_1, 1, g_tStrings.STR_BOOK_ALL_STATUS)
    do
      local l_16_7, l_16_8 = this:GetParent():Lookup("", "Text_Kind")
      l_16_8 = CraftReadManagePanel
      l_16_8 = l_16_8.PopupMenu
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_8(this, l_16_7, l_16_1)
  else
    old_readmanageclick()
  end
end

l_0_6.OnLButtonClick = l_0_7
l_0_6 = CraftReadManagePanel
l_0_7 = function(l_17_0)
  -- upvalues: l_0_5
  local l_17_1 = l_17_0:Lookup("", "")
  local l_17_2 = l_17_1:Lookup("Text_Type")
  local l_17_3 = l_17_1:Lookup("Text_Level")
  local l_17_4 = l_17_1:Lookup("Text_Kind")
  if l_17_2:GetText() == g_tStrings.STR_BOOK_ALL_TYPE then
    do return end
  end
  do
    local l_17_5 = g_tStrings.tBookType[-1]
  end
  local l_17_6 = nil
  local l_17_7 = -1
  local l_17_8 = -1
  if l_17_3:GetText() ~= g_tStrings.STR_BOOK_ALL_LEVEL then
    l_17_7 = g_tStrings.tBookLevel[l_17_3:GetText()][1]
    l_17_8 = g_tStrings.tBookLevel[l_17_3:GetText()][2]
  end
  local l_17_9 = nil
  local l_17_10 = l_17_4:GetText()
  local l_17_11 = -1
  if l_17_10 == g_tStrings.STR_BOOK_ALL_STATUS then
    do return end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  CraftReadManagePanel.UpdateFilterValue(l_17_0, true)
  return l_17_6, l_17_7, l_17_8, l_17_11, true
end

l_0_6.GetFilterValue = l_0_7

