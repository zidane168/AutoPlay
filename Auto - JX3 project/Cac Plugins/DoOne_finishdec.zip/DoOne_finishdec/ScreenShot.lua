-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ScreenShot.lua 

local l_0_0 = {}
l_0_0.filetype = "bmp"
l_0_0.quality = 100
l_0_0.bui = true
SreenShotHelp = l_0_0
l_0_0 = RegisterCustomData
l_0_0("SreenShotHelp.filetype")
l_0_0 = RegisterCustomData
l_0_0("SreenShotHelp.quality")
l_0_0 = RegisterCustomData
l_0_0("SreenShotHelp.bui")
l_0_0 = SreenShotHelp
l_0_0.Create = function(l_1_0)
  local l_1_1 = l_1_0:Lookup("", "")
  BoxLabel(l_1_1, "label1", "ͼ���ʽ", nil, 27)
  for l_1_5,l_1_6 in pairs({"bmp", "tga", "jpg"}) do
    do
      local l_1_7 = BoxRadioBox
      local l_1_8 = l_1_0
      local l_1_9 = "CheckBox_" .. string.upper(l_1_6)
      local l_1_10 = {}
      l_1_10.txt = l_1_6
      l_1_10.x = (l_1_5 - 1) * 100
      l_1_10.y = 30
      l_1_10.group = "filetype"
      l_1_7 = l_1_7(l_1_8, l_1_9, l_1_10)
      l_1_7, l_1_8 = l_1_7:OnCheck, l_1_7
      l_1_9 = function()
        -- upvalues: l_1_6
        SreenShotHelp.filetype = l_1_6
      end
      l_1_7(l_1_8, l_1_9)
    end
  end
  l_1_0:Lookup("CheckBox_" .. string.upper(SreenShotHelp.filetype)):Check(true)
  local l_1_11 = BoxLabel
  local l_1_12 = l_1_1
  local l_1_13 = "label2"
  local l_1_14 = "��ͼUI��Ϣ"
  local l_1_15 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_11(l_1_12, l_1_13, l_1_14, l_1_15, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_1_14,l_1_15 in l_1_11 do
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_1_16, l_1_17 = unpack(60)
    local l_1_18 = BoxRadioBox
    local l_1_19 = l_1_0
    local l_1_20 = "CheckBox_" .. l_1_16
    local l_1_21 = {}
    l_1_21.txt = l_1_17
    l_1_21.x = (l_1_14 - 1) * 100
    l_1_21.y = 90
    l_1_21.group = "uiset"
    l_1_18 = l_1_18(l_1_19, l_1_20, l_1_21)
    if l_1_16 == "haveUI" then
      l_1_19, l_1_20 = l_1_18:OnCheck, l_1_18
      l_1_21 = function()
        SreenShotHelp.bui = true
      end
      l_1_19(l_1_20, l_1_21)
    else
      l_1_19, l_1_20 = l_1_18:OnCheck, l_1_18
      l_1_21 = function()
        SreenShotHelp.bui = false
      end
      l_1_19(l_1_20, l_1_21)
    end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_1_11.bui then
    l_1_0:Lookup(l_1_13):Check(true)
  else
    l_1_0:Lookup("CheckBox_noUI"):Check(true)
  end
  local l_1_22, l_1_28 = nil
  do
    local l_1_23, l_1_29 = nil
    local l_1_24 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_1_25 = nil
    local l_1_26 = nil
    BoxLabel(l_1_1, "label3", l_1_14, {l_1_22, l_1_28})
    if SreenShotHelp.quality < 50 then
      SreenShotHelp.quality = 50
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_1_27 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

    BoxCSlider(l_1_0, "Slider_Quality", {min = 50, max = 100, step = 10, val = SreenShotHelp.quality, x = 80, y = 132}):OnChanged(function(l_5_0)
    -- upvalues: l_1_3
    l_1_3:SetText(l_5_0)
    SreenShotHelp.quality = l_5_0
  end)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  l_1_1:FormatAllItemPos()
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- WARNING: undefined locals caused missing assignments!
end

l_0_0 = function(l_2_0)
  if not l_2_0 then
    Station.Hide()
  end
  DelayCall(0.1, function()
    local l_3_0 = ScreenShot(SreenShotHelp.filetype, SreenShotHelp.quality)
    if l_3_0 then
      OutputMessage("MSG_ANNOUNCE_YELLOW", g_tStrings.SCREENSHOT)
      Msg(g_tStrings.SCREENSHOT_MSG .. l_3_0)
    end
    if not Station.IsVisible() then
      Station.Show()
    end
  end)
end

RegisterMoonButton("SreenShot", 2001, "��ͼ����", "General", SreenShotHelp.Create)
Hotkey.AddBinding("ScreenShotHelper_Default", "Ĭ�Ͻ�ͼ", "��ͼ����", function()
  -- upvalues: l_0_0
  l_0_0(SreenShotHelp.bui)
end
, nil)
Hotkey.AddBinding("ScreenShotHelper_ShowUI", "����UI��ͼ", nil, function()
  -- upvalues: l_0_0
  l_0_0(true)
end
, nil)
Hotkey.AddBinding("ScreenShotHelper_HideUI", "��UI�Ľ�ͼ", nil, function()
  -- upvalues: l_0_0
  l_0_0(false)
end
, nil)
RegisterEvent("HOT_KEY_RELOADED", function()
  if Hotkey.Get("ScreenShotHelper_Default") == 0 then
    Hotkey.Set("ScreenShotHelper_Default", 1, GetKeyValue("PrintScreen"), false, false, false)
  end
end
)
RegisterBoxAddonVersion("Moon_SreenShot", 1)

