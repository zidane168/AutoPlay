-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: superBOSSspeak.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.x = 119
l_0_1.y = -17
l_0_1.s = "LEFTCENTER"
l_0_1.r = "LEFTCENTER"
l_0_0.Anchor = l_0_1
l_0_0.bOn = false
superBOSSspeak = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "superBOSSspeak.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "superBOSSspeak.bOn"
l_0_0(l_0_1)
l_0_0 = 0
l_0_1 = superBOSSspeak
l_0_1.OnFrameCreate = function()
  -- upvalues: l_0_0
  l_0_0 = GetCurrentTime()
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("FIGHT_HINT")
  superBOSSspeak.UpdateAnchor(this)
end

l_0_1 = superBOSSspeak
l_0_1.OnFrameDragEnd = function()
  this:CorrectPos()
  superBOSSspeak.Anchor = GetFrameAnchor(this)
end

l_0_1 = superBOSSspeak
l_0_1.UpdateAnchor = function(l_3_0)
  local l_3_1 = superBOSSspeak.Anchor
  l_3_0:SetPoint(l_3_1.s, 0, 0, l_3_1.r, l_3_1.x, l_3_1.y)
end

l_0_1 = superBOSSspeak
l_0_1.OnEvent = function(l_4_0)
  -- upvalues: l_0_0
  if l_4_0 == "FIGHT_HINT" then
    l_0_0 = GetCurrentTime()
  elseif l_4_0 == "UI_SCALED" then
    superBOSSspeak.UpdateAnchor(this)
  elseif l_4_0 == "CUSTOM_DATA_LOADED" then
    superBOSSspeak.UpdateAnchor(this)
  end
end

l_0_1 = superBOSSspeak
l_0_1.OnFrameBreathe = function()
  local l_5_0 = GetClientPlayer()
  if not l_5_0 then
    return 
  end
  local l_5_1 = this:Lookup("", "Text_Time")
  if l_5_1 then
    l_5_1:SetText(superBOSSspeak.getTimePassed())
  end
end

l_0_1 = superBOSSspeak
l_0_1.speak = function()
  local l_6_0 = GetClientPlayer()
  local l_6_1 = GetLocalTimeText()
  local l_6_2, l_6_3 = l_6_0.GetTarget()
  if not l_6_3 or l_6_3 == 0 then
    if not l_6_0.bFightState then
      OutputMessage("MSG_SYS", "��û��Ŀ�꣡Ҳû����ս��- -!\n")
    else
      local l_6_4 = superBOSSspeak.say
      local l_6_5 = {}
      l_6_5.type = "text"
      l_6_5.text = getTimePassed()
      l_6_4(l_6_5)
    end
    return 
  else
    local l_6_6 = GetTargetHandle(l_6_2, l_6_3)
    local l_6_7 = l_6_6.nCurrentLife
    local l_6_8 = l_6_6.nMaxLife
    local l_6_9 = ""
    if l_6_7 >= 10000 then
      l_6_9 = math.floor(l_6_7 / 10000) .. "�� " .. l_6_7 % 10000
    else
      l_6_9 = l_6_7 % 10000
    end
    local l_6_10 = "%.2f":format(100 * l_6_7 / l_6_8) .. "%"
    local l_6_11 = string.format("[%s]Ѫ����%s��%s��", l_6_6.szName, l_6_9, l_6_10)
    if l_6_0.bFightState then
      l_6_11 = superBOSSspeak.getTimePassed() .. "��" .. l_6_11
    end
    local l_6_12 = superBOSSspeak.say
    local l_6_13 = {}
    local l_6_14 = {}
    l_6_14.type = "text"
    l_6_14.text = l_6_11
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_6_12(l_6_13)
  end
end

l_0_1 = superBOSSspeak
l_0_1.say = function(l_7_0)
  if not R2_PC2 then
    local l_7_3, l_7_5 = EditBox_GetChannel(), R2_PC2
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_7_3 then
    local l_7_1, l_7_2, l_7_4 = PLAYER_TALK_CHANNEL.TEAM, l_7_5
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  GetClientPlayer().Talk(l_7_1, l_7_2, l_7_0)
end

l_0_1 = superBOSSspeak
l_0_1.getTimeInterval = function()
  -- upvalues: l_0_0
  local l_8_0 = TimeToDate(BigIntSub(GetCurrentTime(), l_0_0))
  local l_8_1 = string.format
  local l_8_2 = "%d:%d:%d"
  local l_8_3 = l_8_0.hour - 8
  local l_8_4 = l_8_0.minute
  local l_8_5 = l_8_0.second
  return l_8_1(l_8_2, l_8_3, l_8_4, l_8_5)
end

l_0_1 = superBOSSspeak
l_0_1.getTimePassed = function()
  local l_9_0 = GetClientPlayer()
  if not l_9_0 then
    return 
  end
  if l_9_0.bFightState then
    return "��ս��: " .. superBOSSspeak.getTimeInterval()
  else
    return "����ս����"
  end
end

l_0_1 = superBOSSspeak
l_0_1.OnRButtonDown = function()
  superBOSSspeak.speak()
end

l_0_1 = superBOSSspeak
l_0_1.OnMouseEnter = function()
  local l_11_0, l_11_1 = this:GetAbsPos()
  local l_11_2, l_11_3 = this:GetSize()
  local l_11_4 = OutputTip
  local l_11_5 = GetFormatText("�Ҽ�����ɷ���Ŀ����Ϣ")
  local l_11_6 = 400
  do
    local l_11_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_11_4(l_11_5, l_11_6, l_11_7)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1 = superBOSSspeak
l_0_1.OnMouseLeave = function()
  HideTip()
end

l_0_1 = superBOSSspeak
l_0_1.Toggle = function()
  if not Station.Lookup("Normal/superBOSSspeak") then
    local l_13_0, l_13_1, l_13_2, l_13_3 = Wnd.OpenWindow("interface\\Moon_superBOSSspeak\\superBOSSspeak.ini", "superBOSSspeak")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if superBOSSspeak.bOn then
    l_13_0:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_13_0:Hide()
  end
end

l_0_1 = superBOSSspeak
l_0_1.Create = function(l_14_0)
  local l_14_1 = BoxCheckBox
  local l_14_2 = l_14_0
  local l_14_3 = "CheckBox_FightTimePanel"
  local l_14_4 = {}
  l_14_4.txt = "ս����ʱ���"
  l_14_1 = l_14_1(l_14_2, l_14_3, l_14_4)
  l_14_2, l_14_3 = l_14_1:SetBoolValue, l_14_1
  l_14_4 = superBOSSspeak
  l_14_2(l_14_3, l_14_4, "bOn")
  l_14_2, l_14_3 = l_14_1:OnCheck, l_14_1
  l_14_4 = superBOSSspeak
  l_14_4 = l_14_4.Toggle
  l_14_2(l_14_3, l_14_4)
  l_14_2, l_14_3 = l_14_1:UnCheck, l_14_1
  l_14_4 = superBOSSspeak
  l_14_4 = l_14_4.Toggle
  l_14_2(l_14_3, l_14_4)
end

l_0_1 = RegisterMoonButton
l_0_1("superBOSSspeak", 2022, "ս����ʱ", "General", superBOSSspeak.Create)
l_0_1 = RegisterEvent
l_0_1("AddonLoad", superBOSSspeak.Toggle)

