-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: FightWnd.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetTargetHandle
local l_0_14 = GetForceFontColor
local l_0_15 = GetTargetUIName
local l_0_16 = GetForceTitle
local l_0_17 = GetForceImage
local l_0_18 = NPC_GetProtrait
local l_0_19 = NPC_GetHeadImageFile
local l_0_20 = IsFileExist
local l_0_21 = GetNpcHeadImage
local l_0_22 = GetCampImageFrame
local l_0_23 = SetImage
local l_0_24 = GetTargetLevelFont
local l_0_25 = Table_GetSkillName
local l_0_26 = GetSkill
FightWnd = {}
FightWnd.OnFrameCreate = function()
  this:RegisterEvent("SYS_MSG")
end

FightWnd.OnEvent = function(l_2_0)
  if PrettyShow.Options.ShowDamage_Target ~= true or PrettyShow.Options.TargetEnable ~= true then
    return 
  end
  if l_2_0 ~= "SYS_MSG" then
    return 
  end
  if arg0 == "UI_OME_SKILL_EFFECT_LOG" then
    FightWnd.OnSkillEffectLog(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
  end
end

local l_0_27 = 1
do
  Wnd.OpenWindow("Interface\\PrettyShow\\FightWnd.ini", "FightWnd")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

