-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: xHelp_AlarmScreen.lua 

xHelp_AlarmScreen = {current = "", 
color = {255, 0, 255}, alpha = 255, 
anchor = {s = "CENTER", r = "CENTER", x = -300, y = -80}, 
defanchor = {s = "CENTER", r = "CENTER", x = -300, y = -80}, FontSize = 2}
for k,_ in pairs(xHelp_AlarmScreen) do
  RegisterCustomData("xHelp_AlarmScreen." .. k)
end
xHelp_AlarmScreen.put = function(szText, szColor)
  xHelp_AlarmScreen.current = szText
  if szColor ~= nil then
    xHelp_AlarmScreen.color = szColor
  end
  xHelp_AlarmScreen.alpha = 255
end

xHelp_AlarmScreen.OnFrameBreathe = function()
  if xHelp_AlarmScreen.alpha > 0 then
    local handle = this:Lookup("", "Text_Total")
    handle:SetText(xHelp_AlarmScreen.current)
    handle:SetFontScheme(187)
    handle:SetFontColor(xHelp_AlarmScreen.color[1], xHelp_AlarmScreen.color[2], xHelp_AlarmScreen.color[3])
    handle:SetFontScale(xHelp_AlarmScreen.FontSize)
    handle:AutoSize()
    handle:SetAlpha(xHelp_AlarmScreen.alpha)
    if xHelp_AlarmScreen.alpha > 236 then
      xHelp_AlarmScreen.alpha = xHelp_AlarmScreen.alpha - 1
    end
  else
    if xHelp_AlarmScreen.alpha > 220 then
      xHelp_AlarmScreen.alpha = xHelp_AlarmScreen.alpha - 10
    end
  else
    if xHelp_AlarmScreen.alpha > 40 then
      xHelp_AlarmScreen.alpha = xHelp_AlarmScreen.alpha - 20
    end
  else
    xHelp_AlarmScreen.alpha = 0
    handle:SetText("")
  end
end

xHelp_AlarmScreen.OnFrameCreate = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
end

xHelp_AlarmScreen.OnEvent = function(event)
  if event == "UI_SCALED" or event == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    xHelp_AlarmScreen.UpdateAnchor(this)
  elseif event == "ON_ENTER_CUSTOM_UI_MODE" or event == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "������ĵ��", true)
  end
end

xHelp_AlarmScreen.OnFrameDragEnd = function()
  this:CorrectPos()
  xHelp_AlarmScreen.anchor = GetFrameAnchor(this)
end

xHelp_AlarmScreen.UpdateAnchor = function(frame)
  local anchor = xHelp_AlarmScreen.anchor
  frame:SetPoint(anchor.s, 0, 0, anchor.r, anchor.x, anchor.y)
  frame:CorrectPos()
end

RegisterEvent("CUSTOM_UI_MODE_SET_DEFAULT", xHelp_AlarmScreen_resetPos)
Wnd.OpenWindow("Interface\\xHelp\\xHelp_AlarmScreen.ini", "xHelp_AlarmScreen")

