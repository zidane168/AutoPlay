-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DoodadDisplay.lua 

local l_0_0 = {}
l_0_0.bRun = false
local l_0_1 = {}
l_0_1.r = 196
l_0_1.g = 64
l_0_1.b = 255
l_0_0.color = l_0_1
DoodadDisplay = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "DoodadDisplay.color"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "DoodadDisplay.bRun"
l_0_0(l_0_1)
l_0_0 = DoodadDisplay
l_0_0.Setting, l_0_1 = l_0_1, {A = true, B = true, C = true, D = false, E = false, F = false}
l_0_0 = RegisterCustomData
l_0_1 = "DoodadDisplay.Setting"
l_0_0(l_0_1)
l_0_0 = DoodadDisplay
l_0_0.nSteperCount = -1
l_0_0 = DoodadDisplay
l_0_0.SynAnyDoodadList, l_0_1 = l_0_1, {}
l_0_0 = DoodadDisplay
l_0_0.handleTotal = nil
l_0_0 = DoodadDisplay
l_0_0.szFiltrate = "���á�/���ָ�������"
l_0_0 = RegisterCustomData
l_0_1 = "DoodadDisplay.szFiltrate"
l_0_0(l_0_1)
l_0_0 = DoodadDisplay
l_0_0.QuestDoodadList, l_0_1 = l_0_1, {}
l_0_0 = function(l_1_0)
  local l_1_1 = string.match(this:GetName(), "CheckBox_Show(%a?)")
  if l_1_1 then
    DoodadDisplay.Setting[l_1_1] = l_1_0
    DoodadDisplay.UpdateQuestDoodadList()
    DoodadDisplay.UpdateAll()
  end
end

l_0_1 = DoodadDisplay
l_0_1.Create = function(l_2_0)
  -- upvalues: l_0_0
  local l_2_1 = l_2_0:Lookup("", "")
  local l_2_2 = BoxCheckBox
  local l_2_3 = l_2_0
  local l_2_4 = "CheckBox_Run"
  local l_2_5 = {}
  l_2_5.txt = "������Ʒ������ʾ"
  l_2_2 = l_2_2(l_2_3, l_2_4, l_2_5)
  l_2_3, l_2_4 = l_2_2:SetBoolValue, l_2_2
  l_2_5 = DoodadDisplay
  l_2_3(l_2_4, l_2_5, "bRun")
  l_2_3, l_2_4 = l_2_2:OnCheck, l_2_2
  l_2_5 = function()
    DoodadDisplay.UpdateQuestDoodadList()
    DoodadDisplay.UpdateAll()
  end
  l_2_3(l_2_4, l_2_5)
  l_2_3, l_2_4 = l_2_2:UnCheck, l_2_2
  l_2_5 = function()
    DoodadDisplay.handleTotal:Clear()
    DoodadDisplay.SynAnyDoodadList = {}
  end
  l_2_3(l_2_4, l_2_5)
  l_2_3 = DoodadDisplay
  l_2_3 = l_2_3.color
  l_2_3 = l_2_3.r
  l_2_4 = DoodadDisplay
  l_2_4 = l_2_4.color
  l_2_4 = l_2_4.g
  l_2_5 = DoodadDisplay
  l_2_5 = l_2_5.color
  l_2_5 = l_2_5.b
  local l_2_6 = BoxShadow
  local l_2_7 = l_2_1
  local l_2_8 = "Shadow_Color"
  local l_2_9 = function(l_5_0)
    OpenColorTablePanel(function(l_6_0, l_6_1, l_6_2)
      -- upvalues: l_3_0
      l_3_0:SetColorRGB(l_6_0, l_6_1, l_6_2)
      local l_6_3 = DoodadDisplay
      local l_6_4 = {}
      l_6_4.r = l_6_0
      l_6_4.g = l_6_1
      l_6_4.b = l_6_2
      l_6_3.color = l_6_4
    end)
  end
  local l_2_10 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_2_11 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_2_12 = {}
  local l_2_13 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_2_6(l_2_7, l_2_8, l_2_9, l_2_10, l_2_11, l_2_12)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_2_6(l_2_7, l_2_8, l_2_9, l_2_10, l_2_11)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  do
    local l_2_14 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_2_10,l_2_11 in l_2_7 do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_2_15 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

      l_2_15.x = l_2_5.x
      l_2_15.y = l_2_11[2].y
      l_2_15.txt = l_2_11[3]
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_2_15 = function()
      -- upvalues: l_0_0
      l_0_0(true)
    end
      l_2_13(l_2_14, l_2_15)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_2_15 = function()
      -- upvalues: l_0_0
      l_0_0(false)
    end
      l_2_13(l_2_14, l_2_15)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_2_7(l_2_8, l_2_9, l_2_10, {l_2_12, l_2_13}, l_2_12)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    BoxLabel(l_2_1, "label3", "���ư�����", {l_2_12, l_2_13})
    BoxEdit(l_2_0, "Edit_Filter", {txt = DoodadDisplay.szFiltrate, x = 80, y = 150, nlimit = 200}):SetValue(DoodadDisplay, "szFiltrate")
    l_2_1:FormatAllItemPos()
    DoodadDisplay.initSetting(l_2_0)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1 = DoodadDisplay
l_0_1.initSetting = function(l_3_0)
  for l_3_4,l_3_5 in pairs(DoodadDisplay.Setting) do
    if l_3_5 then
      l_3_0:Lookup("CheckBox_Show" .. l_3_4):Check(true)
    end
  end
end

l_0_1 = RegisterMoonButton
l_0_1("DoodadDisplay", 2025, "��Ʒ����", "General", DoodadDisplay.Create)
l_0_1 = DoodadDisplay
l_0_1.OnFrameCreate = function()
  DoodadDisplay.handleTotal = this:Lookup("", "")
  this:RegisterEvent("QUEST_ACCEPTED")
  this:RegisterEvent("QUEST_CANCELED")
  this:RegisterEvent("QUEST_FINISHED")
  this:RegisterEvent("QUEST_DATA_UPDATE")
  this:RegisterEvent("RENDER_FRAME_UPDATE")
  this:RegisterEvent("DOODAD_ENTER_SCENE")
  this:RegisterEvent("DOODAD_LEAVE_SCENE")
  this:RegisterEvent("SYNC_ROLE_DATA_END")
end

l_0_1 = DoodadDisplay
l_0_1.OnFrameBreathe = function()
  DoodadDisplay.Steper()
end

l_0_1 = DoodadDisplay
l_0_1.OnEvent = function(l_6_0)
  if l_6_0 == "QUEST_ACCEPTED" or l_6_0 == "QUEST_CANCELED" or l_6_0 == "QUEST_FINISHED" or l_6_0 == "SYNC_ROLE_DATA_END" then
    DoodadDisplay.UpdateQuestDoodadList()
    if not IsEmpty(DoodadDisplay.QuestDoodadList) then
      DoodadDisplay.UpdateAll()
    end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_6_0 == "QUEST_DATA_UPDATE" and arg0 >= 0 then
    DoodadDisplay.UpdateQuestDoodadList()
  end
  if not IsEmpty(DoodadDisplay.QuestDoodadList) then
    DoodadDisplay.UpdateAll()
  end
  do return end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_6_0 == "SYS_MSG" and arg0 == "UI_OME_LEARN_PROFESSION" then
    local l_6_1 = GetProfession(nProfessionID)
  end
  if l_6_1 and nProfessionID ~= 8 and nProfessionID ~= 9 and nProfessionID ~= 10 and nProfessionID ~= 11 then
    DoodadDisplay.UpdateAll()
  end
  do return end
  if l_6_0 == "RENDER_FRAME_UPDATE" and DoodadDisplay.bRun then
    DoodadDisplay.RefreshDisplay()
  end
  do return end
  if l_6_0 == "DOODAD_ENTER_SCENE" and DoodadDisplay.bRun then
    DoodadDisplay.AppendControl(arg0)
  end
  do return end
  if l_6_0 == "DOODAD_LEAVE_SCENE" and DoodadDisplay.bRun then
    DoodadDisplay.RemoveControl(arg0)
  end
end

l_0_1 = DoodadDisplay
l_0_1.UpdateAll = function()
  if not DoodadDisplay.bRun then
    return 
  end
  DoodadDisplay.handleTotal:Clear()
  DoodadDisplay.SynAnyDoodadList = {}
  if not GetNearbyDoodadList() then
    local l_7_0 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_7_4 = 1, #l_7_0 do
    local l_7_1 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    DoodadDisplay.AppendControl(l_7_1[R4_PC23])
  end
end

l_0_1 = DoodadDisplay
l_0_1.UpdateQuestDoodadList = function()
  DoodadDisplay.QuestDoodadList = {}
  local l_8_0 = GetClientPlayer()
  local l_8_1 = l_8_0.GetQuestTree()
  for l_8_5,l_8_6 in pairs(l_8_1) do
    do break end
    local l_8_7, l_8_8, l_8_9, l_8_10, l_8_11 = pairs(l_8_6)
    local l_8_12 = l_8_0.GetQuestID(l_8_11)
    if l_8_0.GetQuestPhase(l_8_12) ~= 2 then
      local l_8_13 = l_8_0.GetQuestTraceInfo(l_8_12)
      for l_8_17,l_8_18 in pairs(l_8_13.need_item) do
        local l_8_19 = GetItemInfo(l_8_18.type, l_8_18.index)
        l_8_18.have = math.min(l_8_18.have, l_8_18.need)
        if l_8_19 and l_8_18.have < l_8_18.need then
          local l_8_20 = GetItemNameByItemInfo(l_8_19, l_8_18.need)
          DoodadDisplay.QuestDoodadList[l_8_20] = true
        end
      end
      local l_8_21 = Table_GetQuestStringInfo(l_8_12)
      local l_8_22 = l_8_21.szDescription
      for l_8_26,l_8_27 in string.gfind(l_8_22, "<F17(%d)%s*(.-)>") do
        if tonumber(l_8_26) == 1 and not DoodadDisplay.QuestDoodadList[l_8_27] then
          DoodadDisplay.QuestDoodadList[l_8_27] = true
        end
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1 = DoodadDisplay
l_0_1.FilterOtherDoodad = function(l_9_0)
  local l_9_1 = true
  local l_9_2 = DoodadDisplay.szFiltrate
  if l_9_2 ~= "" and l_9_2 ~= "���á�/���ָ�������" then
    l_9_1 = false
    l_9_2 = l_9_2 .. "/"
    do
      local l_9_3 = 1
      for l_9_7 = 1, #l_9_2 do
        if l_9_2:sub(l_9_7, l_9_7) == "/" and l_9_3 <= l_9_7 then
          local l_9_8 = l_9_2:sub(l_9_3, l_9_7 - 1):gsub("%s", "")
          if l_9_8 and l_9_8 ~= "" and l_9_0 == l_9_8 then
            l_9_1 = true
          end
          do break end
        end
        l_9_3 = l_9_7 + 1
      end
    end
  end
  return l_9_1
end

l_0_1 = DoodadDisplay
l_0_1.CanOperate = function(l_10_0)
  local l_10_1 = l_10_0.nKind
  if l_10_1 == DOODAD_KIND.READ or l_10_1 == DOODAD_KIND.DIALOG or l_10_1 == DOODAD_KIND.TREASURE or l_10_1 == DOODAD_KIND.ACCEPT_QUEST or l_10_1 == DOODAD_KIND.DOOR then
    return true
  else
    if l_10_1 == DOODAD_KIND.QUEST and l_10_0.HaveQuest(GetClientPlayer().dwID) then
      return true
    end
  else
    if l_10_0.nKind == DOODAD_KIND.CHAIR and l_10_0.CanSit() then
      return true
    end
  end
  return false
end

l_0_1 = DoodadDisplay
l_0_1.FilterDoodad = function(l_11_0)
  if not l_11_0 then
    return false
  end
  local l_11_1 = GetDoodad(l_11_0)
  local l_11_2 = GetDoodadTemplate(l_11_1.dwTemplateID)
  if not l_11_1 or l_11_1.nKind == DOODAD_KIND.CORPSE then
    return false
  end
  local l_11_3 = GetClientPlayer()
  local l_11_4 = false
  if l_11_1.nKind == DOODAD_KIND.CRAFT_TARGET and l_11_2 and l_11_3.IsProfessionLearnedByCraftID(l_11_2.dwCraftID) then
    if DoodadDisplay.Setting.A and l_11_2.dwCraftID == 1 then
      l_11_4 = true
    end
  else
    if DoodadDisplay.Setting.B and l_11_2.dwCraftID == 2 then
      l_11_4 = true
    end
  else
    if DoodadDisplay.Setting.C and l_11_2.dwCraftID == 12 then
      l_11_4 = true
    end
  end
  do return end
  if DoodadDisplay.Setting.D and DoodadDisplay.FilterOtherDoodad(l_11_1.szName) then
    l_11_4 = true
  end
  do return end
  if DoodadDisplay.Setting.E and DoodadDisplay.CanOperate(l_11_1) then
    l_11_4 = true
  end
  do return end
  if DoodadDisplay.Setting.F and (DoodadDisplay.QuestDoodadList[l_11_1.szName] or l_11_1.nKind ~= DOODAD_KIND.QUEST or l_11_1.HaveQuest(GetClientPlayer().dwID)) then
    l_11_4 = true
  end
  return l_11_4, l_11_1.szName
end

l_0_1 = DoodadDisplay
l_0_1.AppendControl = function(l_12_0)
  local l_12_1, l_12_2 = DoodadDisplay.FilterDoodad(l_12_0)
  if not l_12_1 then
    return 
  end
  local l_12_3 = DoodadDisplay.handleTotal
  local l_12_4 = "Name_DOODAD_" .. l_12_0
  if not l_12_3:Lookup(l_12_4) then
    local l_12_5 = l_12_3:AppendItemFromIni("Interface/Moon_DoodadDisplay/DoodadTopHeadHandle.ini", "Handle_Label", l_12_4)
    l_12_5.dwDoodadID = l_12_0
    l_12_5.txt = l_12_5:Lookup("Text_Content")
    l_12_5.txt:SetFontScheme(40)
    l_12_5.txt:SetText(l_12_2)
    local l_12_6 = DoodadDisplay.SynAnyDoodadList
    local l_12_7 = {}
    l_12_7.name = l_12_2
    l_12_7.dwID = dwDoodadIDl
    l_12_6[l_12_0] = l_12_7
  end
end

l_0_1 = DoodadDisplay
l_0_1.RemoveControl = function(l_13_0)
  if not l_13_0 or not DoodadDisplay.SynAnyDoodadList[l_13_0] then
    return 
  end
  local l_13_1 = DoodadDisplay.handleTotal
  local l_13_2 = l_13_1:Lookup("Name_DOODAD_" .. l_13_0)
  if l_13_2 then
    l_13_1:RemoveItem(l_13_2:GetIndex())
  end
  DoodadDisplay.SynAnyDoodadList[l_13_0] = nil
end

l_0_1 = DoodadDisplay
l_0_1.Steper = function()
  DoodadDisplay.nSteperCount = DoodadDisplay.nSteperCount + 1
  if DoodadDisplay.nSteperCount >= 100000000 then
    DoodadDisplay.nSteperCount = -1
  end
end

l_0_1 = DoodadDisplay
l_0_1.AdjustPos = function(l_15_0, l_15_1, l_15_2)
  if not l_15_2 or not l_15_2:IsValid() then
    return 
  end
  if l_15_0 then
    local l_15_3, l_15_4 = l_15_2.txt:GetSize()
    local l_15_5 = math.ceil(l_15_0 - l_15_3 / 2)
    local l_15_6 = math.floor(l_15_1 - l_15_4 / 2) - 80
    l_15_2.txt:SetAbsPos(l_15_5, l_15_6)
    l_15_2:Show()
  else
    l_15_2.txt:SetAbsPos(-4096, -4096)
    l_15_2:Hide()
  end
end

l_0_1 = DoodadDisplay
l_0_1.GetDistance = function(l_16_0, l_16_1)
  local l_16_2 = GetDoodad(l_16_0)
  local l_16_3 = GetClientPlayer()
  local l_16_4 = math.floor(l_16_3.nX - l_16_2.nX ^ 2 + l_16_3.nY - l_16_2.nY ^ 2 + l_16_3.nZ / 8 - l_16_2.nZ / 8 ^ 2 ^ 0.5)
  if l_16_1 then
    return l_16_4
  end
  do return end
  return l_16_4 / 64
end

l_0_1 = DoodadDisplay
l_0_1.RefreshDisplay = function()
  local l_17_0 = GetClientPlayer()
  if not l_17_0 then
    return 
  end
  local l_17_1 = DoodadDisplay.handleTotal
  for l_17_5,l_17_6 in pairs(DoodadDisplay.SynAnyDoodadList) do
    local l_17_7 = GetDoodad(l_17_5)
    if not l_17_7 then
      DoodadDisplay.RemoveControl(l_17_5)
      return 
    end
    local l_17_8 = (l_17_1:Lookup("Name_DOODAD_" .. l_17_5))
    local l_17_9 = nil
    if l_17_8 then
      l_17_9 = l_17_8:Lookup("Text_Content")
      Moon_Lib.ApplyScreenPoint(DoodadDisplay.AdjustPos, l_17_8, l_17_7)
    end
    local l_17_10 = DoodadDisplay.GetDistance(l_17_5, true)
    local l_17_11 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_17_9 and 16.nSteperCount % 2 == 0 then
      if l_17_10 < 800 then
        l_17_9:SetFontScheme(40)
        l_17_9:SetFontScale(1)
      end
    elseif l_17_10 < 1600 then
      l_17_9:SetFontScheme(l_17_11[2])
      l_17_9:SetFontScale(1)
    elseif l_17_10 < 2400 then
      l_17_9:SetFontScheme(l_17_11[1])
      l_17_9:SetFontScale(1)
    else
      local l_17_12 = l_17_10 - 2400
      if 1 - l_17_12 / 4000 <= 0.7 then
        local l_17_13, l_17_14, l_17_15 = 0.7
      end
      l_17_9:SetFontScheme(l_17_11[1])
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_17_9:SetFontScale(l_17_13)
    end
    local l_17_16 = true
    if l_17_10 - 900 <= 0 then
      local l_17_19, l_17_21 = 210, 0
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_17_19 - math.floor(l_17_21 / 50) <= 0 then
      local l_17_17, l_17_18, l_17_20 = 0
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_17_9 then
      l_17_9:SetAlpha(l_17_17)
      l_17_9:SetFontColor(DoodadDisplay.color.r, DoodadDisplay.color.g, DoodadDisplay.color.b)
    end
  end
  if DoodadDisplay.nSteperCount % 16 == 0 then
    l_17_1:Sort()
  end
end

l_0_1 = Wnd
l_0_1 = l_0_1.OpenWindow
l_0_1("Interface\\Moon_DoodadDisplay\\DoodadTopHeadHandle.ini", "DoodadDisplay")
l_0_1 = RegisterBoxAddonVersion
l_0_1("Moon_DoodadDisplay", 1.9)

