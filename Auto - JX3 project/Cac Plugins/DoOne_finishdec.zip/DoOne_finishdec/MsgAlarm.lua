-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: MsgAlarm.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = 0
l_0_1.y = -250
l_0_0.Anchor = l_0_1
MsgAlarm = l_0_0
l_0_0 = MsgAlarm
l_0_1 = function()
  MsgAlarm.hmsg = this:Lookup("", "")
  this:RegisterEvent("UI_SCALED")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = MsgAlarm
l_0_1 = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    MsgAlarm.UpdateAnchor(this)
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = MsgAlarm
l_0_1 = function(l_3_0)
  l_3_0:SetPoint(MsgAlarm.Anchor.s, 0, 0, MsgAlarm.Anchor.r, MsgAlarm.Anchor.x, MsgAlarm.Anchor.y)
  l_3_0:CorrectPos()
end

l_0_0.UpdateAnchor = l_0_1
l_0_0 = MsgAlarm
l_0_1 = function(l_4_0)
  local l_4_1 = Station.Lookup("Topmost1/MsgAlarm")
  local l_4_2 = MsgAlarm.hmsg:Lookup("Text_Msg")
  l_4_2:SetText(l_4_0)
  local l_4_4 = l_4_2:GetTextExtent()
  if l_4_4 < 370 then
    l_4_4 = 370
    local l_4_3 = nil
  end
  l_4_2:SetSize(l_4_4 + 100, 25)
  MsgAlarm.hmsg:Lookup("Image_Bg"):SetSize(l_4_4 + 100, 50)
  MsgAlarm.hmsg:FormatAllItemPos()
  MsgAlarm.hmsg:SetSizeByAllItemSize()
  l_4_1:SetSize(l_4_4, R4_PC46)
  MsgAlarm.UpdateAnchor(l_4_1)
end

l_0_0.UpdateMsg = l_0_1
l_0_0 = MsgAlarm
l_0_1 = function(l_5_0)
  MsgAlarm.hmsg:SetAlpha(l_5_0)
end

l_0_0.UpdateAlpha = l_0_1
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "interface\\Moon_DBM\\MsgAlarm.ini"
l_0_0(l_0_1, "MsgAlarm")
l_0_0 = function(l_6_0, l_6_1, l_6_2)
  local l_6_3 = GetClientPlayer()
  local l_6_4 = l_6_3.Talk
  local l_6_5 = l_6_0
  local l_6_6 = l_6_1
  local l_6_7 = {}
  local l_6_8 = {}
  l_6_8.type = "text"
  l_6_8.text = "<������ʾ>" .. l_6_2
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_6_4(l_6_5, l_6_6, l_6_7)
end

DBMSay = l_0_0

