-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Recount.lua 

local l_0_0 = {}
l_0_0.HIT = 0
l_0_0.BLOCK = 1
l_0_0.SHIELD = 2
l_0_0.MISS = 3
l_0_0.DODGE = 4
l_0_0.CRITICAL = 5
l_0_0.ShIPO = 6
SKILL_RESULT = l_0_0
RECOUNT_FANGSHI, l_0_0 = l_0_0, {fangshi = "TotalDamage"}
RECOUNT_MODE, l_0_0 = l_0_0, {DAMAGE = "�˺�ͳ��", BEDAMAGE = "�ܵ��˺�ͳ��", HEAL = "����ͳ��", BEHEAL = "�ܵ�����ͳ��"}
Recount, l_0_0 = l_0_0, {bOn = false, nDataMode = 2, 
PlayerDataRecordList = {}, 
PlayerDataDisplayList = {}, startfighttime = 0, totalfighttime = 0, countboss = false, nCurrentMode = RECOUNT_MODE.DAMAGE}
l_0_0 = PLAYER_TALK_CHANNEL
l_0_0 = l_0_0.TEAM
zRecountspeak = l_0_0
zrecountanchor, l_0_0 = l_0_0, {s = "TOPLEFT", r = "TOPLEFT", x = 0, y = 0}
l_0_0 = RegisterCustomData
l_0_0("zrecountanchor")
l_0_0 = RegisterCustomData
l_0_0("Recount.nDataMode")
l_0_0 = RegisterCustomData
l_0_0("zRecountspeak")
l_0_0 = RegisterCustomData
l_0_0("Recount.nCurrentMode")
l_0_0 = RegisterCustomData
l_0_0("RECOUNT_FANGSHI")
l_0_0 = RegisterCustomData
l_0_0("Recount.countboss")
l_0_0 = RegisterCustomData
l_0_0("Recount.bOn")
l_0_0 = Recount
l_0_0.OnFrameCreate = function()
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("FIGHT_HINT")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("ON_BG_CHANNEL_MSG")
  Recount.hputwnd = this:Lookup("Wnd_Output"):Lookup("", "Handle_OutputText")
  Recount.hputwnd:Clear()
  Recount.UpdateScroll()
  Recount.UpdateBtnState()
  Recount.RefreshText()
  Recount.UpdateAnchor(this)
  local l_1_0 = GetClientPlayer()
  if not l_1_0 then
    return 
  end
  if l_1_0.bFightState and Recount.startfighttime == 0 then
    Recount.startfighttime = GetTime()
  end
end

l_0_0 = Recount
l_0_0.OnLButtonClick = function()
  local l_2_0 = this:GetName()
  if l_2_0 == "Btn_Config" then
    Recount.config()
  elseif l_2_0 == "Btn_Clear" then
    Recount.Clear()
  elseif l_2_0 == "Btn_Left" then
    Recount.ChangeMode("left")
  elseif l_2_0 == "Btn_Right" then
    Recount.ChangeMode("right")
  elseif l_2_0 == "Btn_Speak" then
    Recount.Speak()
  elseif l_2_0 == "Btn_Close" then
    Recount.bOn = false
    Recount.Clear()
    this:GetRoot():Hide()
  end
end

l_0_0 = Recount
l_0_0.Speak = function()
  local l_3_0 = GetClientPlayer()
  if Recount.PlayerDataRecordList == nil or IsEmpty(Recount.PlayerDataRecordList) then
    return 
  end
  local l_3_1 = Station.Lookup("Normal/Recount/Wnd_Title"):Lookup("", "Text_name")
  local l_3_2 = l_3_0.Talk
  local l_3_3 = zRecountspeak
  local l_3_4 = ""
  local l_3_5 = {}
  local l_3_6 = {}
  l_3_6.type = "text"
  l_3_6.text = l_3_1:GetText() .. "��"
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_3_2(l_3_3, l_3_4, l_3_5)
  l_3_2 = Recount
  l_3_2 = l_3_2.nCurrentMode
  l_3_3 = RECOUNT_MODE
  l_3_3 = l_3_3.DAMAGE
  if l_3_2 == l_3_3 then
    l_3_3 = 0
    l_3_4 = pairs
    l_3_5 = Recount
    l_3_5 = l_3_5.PlayerDataRecordList
    l_3_4 = l_3_4(l_3_5)
    for i_1,i_2 in l_3_4 do
      if not IsEmpty(l_3_8.DamageRecordList) and l_3_8.nTotalDamage ~= 0 then
        l_3_2[#l_3_2 + 1] = l_3_8
        l_3_3 = l_3_3 + l_3_8.nTotalDamage
      end
    end
    table.sort(l_3_2, function(l_4_0, l_4_1)
      return l_4_1.nTotalDamage < l_4_0.nTotalDamage
    end)
    for l_3_12,l_3_13 in ipairs(l_3_2) do
      local l_3_11, l_3_12, l_3_13 = nil
      l_3_11 = l_3_10.nTotalDamage
      l_3_11 = l_3_11 / (l_3_3)
      l_3_11 = l_3_11 * 100
      local l_3_14 = nil
      l_3_12 = l_3_10.nTotalDamage
      l_3_13 = "("
      l_3_14 = string
      l_3_14 = l_3_14.format
      l_3_14 = l_3_14("%.1f", l_3_11)
      l_3_12 = l_3_12 .. l_3_13 .. l_3_14 .. "%)"
      local l_3_15 = nil
      l_3_13 = math
      l_3_13 = l_3_13.floor
      l_3_14 = Recount
      l_3_14 = l_3_14.GetTime
      l_3_14 = l_3_14()
      l_3_14 = l_3_14 / 1000
      l_3_13 = (l_3_13(l_3_14))
      local l_3_16 = nil
      l_3_14 = nil
      local l_3_17 = nil
      if l_3_13 > 0 then
        l_3_15 = math
        l_3_15 = l_3_15.floor
        l_3_16 = l_3_10.nTotalDamage
        l_3_16 = l_3_16 / l_3_13
        l_3_15 = l_3_15(l_3_16)
        l_3_16 = "DPS"
        l_3_14 = l_3_15 .. l_3_16
      else
        l_3_15 = l_3_10.nTotalDamage
        l_3_16 = "DPS"
        l_3_14 = l_3_15 .. l_3_16
      end
      l_3_15 = l_3_9
      l_3_16 = "��"
      l_3_17 = l_3_10.szName
      l_3_15 = l_3_15 .. l_3_16 .. l_3_17 .. "��" .. l_3_12 .. "��" .. l_3_14
      talktext = l_3_15
      l_3_15 = l_3_0.Talk
      local l_3_18 = nil
      l_3_16 = zRecountspeak
      local l_3_19 = nil
      l_3_17 = ""
      local l_3_20 = nil
      local l_3_21 = nil
      local l_3_22 = nil
      l_3_20 = talktext
      l_3_19 = {type = "text", text = l_3_20}
      l_3_15(l_3_16, l_3_17, l_3_18)
      l_3_18 = {l_3_19}
    end
    do break end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_3 = l_3_2
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_3 = 1
  for i = l_3_3, l_3_2 do
    local l_3_23, l_3_24, l_3_25 = nil
    l_3_23 = Recount
    l_3_23 = l_3_23.hputwnd
    l_3_23, l_3_24 = l_3_23:Lookup, l_3_23
    l_3_25 = tostring
    R10_PC139, l_3_25 = .end, l_3_25(R10_PC139)
    l_3_23 = l_3_23(l_3_24, l_3_25, R10_PC139)
    local l_3_26 = nil
    if l_3_23 then
      l_3_24, l_3_25 = l_3_23:IsVisible, l_3_23
      l_3_24 = l_3_24(l_3_25)
    end
    if l_3_24 then
      l_3_24, l_3_25 = l_3_23:Lookup, l_3_23
      l_3_26 = "Text_Entry_L"
      l_3_24 = l_3_24(l_3_25, l_3_26)
      l_3_24, l_3_25 = l_3_24:GetText, l_3_24
      l_3_24 = l_3_24(l_3_25)
      local l_3_27 = nil
      l_3_25, l_3_26 = l_3_23:Lookup, l_3_23
      l_3_27 = "Text_Entry_R"
      l_3_25 = l_3_25(l_3_26, l_3_27)
      l_3_25, l_3_26 = l_3_25:GetText, l_3_25
      l_3_25 = l_3_25(l_3_26)
      local l_3_28 = nil
      l_3_26 = 
      l_3_27 = "��"
      l_3_28 = l_3_24
      l_3_26 = l_3_26 .. l_3_27 .. l_3_28 .. "��" .. l_3_25
      local l_3_29 = nil
      l_3_27 = l_3_0.Talk
      local l_3_30 = nil
      l_3_28 = zRecountspeak
      local l_3_31 = nil
      l_3_29 = ""
      local l_3_32 = nil
      local l_3_33 = nil
      local l_3_34 = nil
      l_3_31 = {type = "text", text = l_3_26}
      l_3_27(l_3_28, l_3_29, l_3_30)
      l_3_30 = {l_3_31}
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0 = Recount
l_0_0.ChangeMode = function(l_4_0)
  do
    local l_4_1 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_4_5,l_4_6 in "�˺�ͳ��"("�ܵ��˺�ͳ��") do
       -- DECOMPILER ERROR: unhandled construct in 'if'

       -- DECOMPILER ERROR: unhandled construct in 'if'

      if Recount.nCurrentMode == l_4_6 and l_4_0 == "left" and Recount.nCurrentMode ~= "�˺�ͳ��" then
        this:GetParent():Lookup("Btn_Right"):Enable(1)
        if Recount.nCurrentMode == "�˺�ͳ��" then
          this:Enable(0)
        end
        do break end
      end
      for l_4_5,l_4_6 in l_4_2 do
        if l_4_0 == "right" and Recount.nCurrentMode ~= "�ܵ�����ͳ��" then
          this:GetParent():Lookup("Btn_Left"):Enable(1)
          if Recount.nCurrentMode == "�ܵ�����ͳ��" then
            this:Enable(0)
          end
          do break end
        end
      end
      Recount.RefreshText()
    end
     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0 = Recount
l_0_0.OnItemMouseEnter = function()
  if this.bTip then
    local l_5_0 = Recount.PlayerDataRecordList[this.szName]
    if Recount.nCurrentMode == RECOUNT_MODE.DAMAGE then
      Recount.ShowTip(l_5_0.DamageRecordList, l_5_0.nTotalDamage)
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEDAMAGE then
      Recount.ShowTip(l_5_0.BeDamageRecordList, l_5_0.nTotalBeDamage)
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.HEAL then
      Recount.ShowTip(l_5_0.HealRecordList, l_5_0.nTotalHeal)
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEHEAL then
      Recount.ShowTip(l_5_0.BeHealRecordList, l_5_0.nTotalBeHeal)
    end
  end
end

l_0_0 = Recount
l_0_0.OnItemMouseLeave = function()
  HideTip()
end

l_0_0 = Recount
l_0_0.ShowTip = function(l_7_0, l_7_1)
  if not l_7_0 or IsEmpty(l_7_0) then
    return 
  end
  local l_7_2 = ""
  local l_7_3 = {}
  for l_7_7,l_7_8 in pairs(l_7_0) do
    l_7_3[#l_7_3 + 1] = l_7_8
  end
  table.sort(l_7_3, function(l_8_0, l_8_1)
    return l_8_1.Total < l_8_0.Total
  end)
  for l_7_12,l_7_13 in ipairs(l_7_3) do
    local l_7_14 = 0
    if l_7_1 ~= 0 then
      l_7_14 = l_7_13.Total / l_7_1 * 100
    end
    l_7_2 = l_7_2 .. "%d��%s:%d(%.1f%%)\n       ����:%d,����:%d,δ����:%d\n":format(l_7_12, l_7_13.Name, l_7_13.Total, l_7_14, l_7_13.nHit, l_7_13.nCritical, l_7_13.nMiss)
  end
  local l_7_15, l_7_16, l_7_19, l_7_20 = this:GetAbsPos()
  l_7_19 = this
  l_7_19, l_7_20 = l_7_19:GetSize, l_7_19
  l_7_19 = l_7_19(l_7_20)
  local l_7_17, l_7_18, l_7_21, l_7_22 = nil
  l_7_17 = OutputTip
  local l_7_23 = nil
  l_7_18 = GetFormatText
  l_7_21 = l_7_2
  l_7_18 = l_7_18(l_7_21)
  local l_7_24 = nil
  l_7_21 = 400
  local l_7_25 = nil
  do
    local l_7_26 = nil
    l_7_23 = l_7_15
    l_7_24 = l_7_16
    l_7_25 = l_7_19
    l_7_26 = 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_7_17(l_7_18, l_7_21, {l_7_23, l_7_24, l_7_25, l_7_26}, 0)
end

l_0_0 = Recount
l_0_0.OnItemLButtonDBClick = function()
  local l_8_0 = this:GetName()
  local l_8_1 = this:GetRoot()
  local l_8_2 = l_8_1:Lookup("Wnd_Output")
  if l_8_0 == "Handle_Title" then
    if l_8_2:IsVisible() then
      l_8_2:Hide()
      l_8_2:SetSize(0, 0)
    end
  else
    l_8_2:Show()
    l_8_2:SetSize(280, 210)
  end
end

l_0_0 = Recount
l_0_0.OnItemLButtonClick = function()
  local l_9_0 = this:GetName()
  local l_9_1 = Station.Lookup("Normal/Recount/Wnd_Output"):Lookup("", "Handle_OutputText")
  local l_9_2 = l_9_1:Lookup(tostring(l_9_0))
  if l_9_2 then
    ShowDetail.Show(l_9_2.szName)
  end
end

l_0_0 = Recount
l_0_0.CanRecord = function(l_10_0)
  local l_10_1 = GetClientPlayer()
  if not l_10_1 then
    return false
  end
  if not Recount.bOn then
    if not l_10_1.IsInParty() then
      return 
    end
    if IsInBattleField() then
      return 
    end
    if IsInArena() then
      return 
    end
    if IsPlayer(l_10_0) then
      return false
    end
  do
    else
      local l_10_2 = GetNpc(l_10_0)
      if not l_10_2 then
        return 
      end
    if l_10_2.dwEmployer ~= 0 then
      end
    if l_10_2.dwEmployer ~= 0 then
      end
    end
    return false
  end
  return true
end

Recount.OnEvent = function(l_11_0)
  -- upvalues: l_0_0
  if l_11_0 == "SYS_MSG" then
    if arg0 == "UI_OME_SKILL_EFFECT_LOG" then
      if arg8 <= 2 then
        return 
      end
      if not Recount.CanRecord(arg1) then
        return 
      end
      local l_11_1 = arg9
      local l_11_2 = 0
      local l_11_3 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_11_7,l_11_8 in SKILL_RESULT_TYPE.PHYSICS_DAMAGE(SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE) do
        do
          do
            local l_11_9 = l_11_1[l_11_8] or 0
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

      end
      if l_11_9 > 0 then
        end
        local l_11_10, l_11_19 = l_11_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if (l_11_19 ~= 1 or l_11_10) and l_11_10 > 0 then
          if l_11_19 and l_11_19 ~= 0 then
            l_11_19(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.CRITICAL, SKILL_RESULT_TYPE.PHYSICS_DAMAGE, l_11_10)
          end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        else
          l_11_19(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.HIT, SKILL_RESULT_TYPE.PHYSICS_DAMAGE, l_11_10)
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if not l_11_19 then
          local l_11_11 = nil
        end
         -- DECOMPILER ERROR: Overwrote pending register.

        if Recount.nDataMode == 1 and not l_11_1[SKILL_RESULT_TYPE.THERAPY] then
          local l_11_12, l_11_13, l_11_14, l_11_15, l_11_16, l_11_17, l_11_20 = nil
        end
        if l_11_19 and l_11_19 > 0 then
          if arg7 and arg7 ~= 0 then
            Recount.OnSkillEffect(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.CRITICAL, SKILL_RESULT_TYPE.THERAPY, l_11_19)
          end
        else
          Recount.OnSkillEffect(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.HIT, SKILL_RESULT_TYPE.THERAPY, l_11_19)
        end
        do
          local l_11_18, l_11_21 = l_11_1[SKILL_RESULT_TYPE.REFLECTIED_DAMAGE]
          if l_11_18 and l_11_18 > 0 then
            l_11_21 = Recount
            l_11_21 = l_11_21.OnSkillEffect
            l_11_21(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.HIT, SKILL_RESULT_TYPE.REFLECTIED_DAMAGE, l_11_18)
          end
          l_11_21 = SKILL_RESULT_TYPE
          l_11_21 = l_11_21.INSIGHT_DAMAGE
          l_11_18 = l_11_1[l_11_21]
          if l_11_18 and l_11_18 > 0 then
            l_11_21 = Recount
            l_11_21 = l_11_21.OnSkillEffect
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_11_21(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.ShIPO, SKILL_RESULT_TYPE.INSIGHT_DAMAGE, 0)
        end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        if l_0_0[l_11_2] then
          if not Recount.CanRecord(arg1) then
            return 
          end
          local l_11_22 = l_0_0[arg0]
          local l_11_23 = nil
          if arg0 == "UI_OME_SKILL_BLOCK_LOG" then
            l_11_23 = arg6
          end
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          Recount.OnSkillEffect(l_11_10, l_11_19, arg3, arg4, arg5, SKILL_RESULT[l_11_22], l_11_23, 0)
        end
      end
    elseif l_11_0 == "FIGHT_HINT" then
      if not Recount.bOn then
        return 
      end
      if arg0 then
        Recount.startfighttime = GetTime()
      else
        Recount.totalfighttime = Recount.totalfighttime + (GetTime() - Recount.startfighttime)
        Recount.Display()
      end
    elseif l_11_0 == "ON_BG_CHANNEL_MSG" then
      if not Recount.bOn then
        return 
      end
      if arg1 ~= PLAYER_TALK_CHANNEL.RAID then
        return 
      end
      local l_11_24 = GetClientPlayer()
      if not l_11_24 then
        return 
      end
      local l_11_25 = l_11_24.GetTalkData()
      if not l_11_25[2] then
        return 
      end
      do
        local l_11_26 = l_11_25[2].text or ""
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_11_26 == "recount_petskill" then
        local l_11_27 = nil
        if tonumber(l_11_25[3].text) == l_11_24.dwID then
          return 
        end
        Recount.RecivePetSKill(tonumber(l_11_25[3].text), l_11_25[4].text)
      end
     -- DECOMPILER ERROR: unhandled construct in 'if'

    elseif l_11_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
      Recount.RefreshText()
      Recount.UpdateBtnState()
      Recount.UpdateAnchor(this)
    end
    do return end
    if l_11_0 == "UI_SCALED" then
      Recount.UpdateAnchor(this)
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 42 
end

Recount.UpdateBtnState = function()
  local l_12_0 = Station.Lookup("Normal/Recount")
  local l_12_1 = l_12_0:Lookup("Wnd_Title")
  local l_12_2 = l_12_1:Lookup("Btn_Left")
  local l_12_3 = l_12_1:Lookup("Btn_Right")
  l_12_2:Enable(1)
  l_12_3:Enable(1)
  if Recount.nCurrentMode == RECOUNT_MODE.DAMAGE then
    l_12_2:Enable(0)
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEHEAL then
      l_12_3:Enable(0)
    end
  end
end

Recount.RefreshText = function()
  local l_13_0 = Station.Lookup("Normal/Recount")
  local l_13_1 = l_13_0:Lookup("Wnd_Title")
  local l_13_2 = l_13_1:Lookup("", "Text_name")
  if Recount.nCurrentMode == RECOUNT_MODE.DAMAGE then
    l_13_2:SetText("�˺�ͳ��")
  else
    if Recount.nCurrentMode == RECOUNT_MODE.HEAL then
      l_13_2:SetText("����ͳ��")
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEDAMAGE then
      l_13_2:SetText("����ͳ��")
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEHEAL then
      l_13_2:SetText("����ͳ��")
    end
  end
  Recount.Display()
end

Recount.Display = function()
  if Recount.nCurrentMode == RECOUNT_MODE.DAMAGE then
    Recount.DisplayByDamage()
  else
    if Recount.nCurrentMode == RECOUNT_MODE.HEAL then
      Recount.DisplayByHeal()
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEDAMAGE then
      Recount.DisplayByBeDamage()
    end
  else
    if Recount.nCurrentMode == RECOUNT_MODE.BEHEAL then
      Recount.DisplayByBeHeal()
    end
  end
  Recount.UpdateScroll()
end

Recount.UpdateScroll = function()
  local l_15_0 = Station.Lookup("Normal/Recount")
  local l_15_1 = l_15_0:Lookup("Wnd_Output")
  local l_15_2 = l_15_1:Lookup("", "Handle_OutputText")
  local l_15_3 = l_15_1:Lookup("Scroll_List")
  local l_15_4, l_15_5 = l_15_2:GetSize()
  local l_15_6, l_15_7 = l_15_2:GetAllItemSize()
  local l_15_8 = math.ceil((l_15_7 - l_15_5) / 10)
  l_15_3:SetStepCount(l_15_8)
  if l_15_8 > 0 then
    l_15_3:Show()
    l_15_1:Lookup("Btn_Up"):Show()
    l_15_3:GetParent():Lookup("Btn_Down"):Show()
  else
    l_15_3:Hide()
    l_15_1:Lookup("Btn_Up"):Hide()
    l_15_1:Lookup("Btn_Down"):Hide()
  end
end

Recount.OnScrollBarPosChanged = function()
  local l_16_0 = Station.Lookup("Normal/Recount")
  local l_16_1 = l_16_0:Lookup("Wnd_Output")
  local l_16_2 = l_16_1:Lookup("", "Handle_OutputText")
  local l_16_3 = l_16_1:Lookup("Scroll_List")
  local l_16_4 = this:GetScrollPos()
  if l_16_4 == 0 then
    l_16_1:Lookup("Btn_Up"):Enable(0)
  else
    l_16_1:Lookup("Btn_Up"):Enable(1)
  end
  if l_16_4 == this:GetStepCount() then
    l_16_1:Lookup("Btn_Down"):Enable(0)
  else
    l_16_1:Lookup("Btn_Down"):Enable(1)
  end
  l_16_2:SetItemStartRelPos(0, -l_16_4 * 10)
end

Recount.OnMouseWheel = function()
  local l_17_0 = Station.Lookup("Normal/Recount")
  local l_17_1 = l_17_0:Lookup("Wnd_Output"):Lookup("Scroll_List")
  local l_17_2 = this:GetName()
  if l_17_2 == "Scroll_List" then
    local l_17_3 = Station.GetMessageWheelDelta()
    l_17_1:ScrollNext(l_17_3)
    return 1
  end
end

Recount.OnItemMouseWheel = function()
  local l_18_0 = Station.Lookup("Normal/Recount")
  local l_18_1 = l_18_0:Lookup("Wnd_Output"):Lookup("Scroll_List")
  local l_18_2 = Station.GetMessageWheelDelta()
  l_18_1:ScrollNext(l_18_2)
  return 1
end

Recount.OnLButtonDown = function()
  local l_19_0 = this:GetName()
  local l_19_1 = Station.Lookup("Normal/Recount/Wnd_Output/Scroll_List")
  if l_19_0 == "Btn_Up" then
    l_19_1:ScrollPrev(1)
  elseif l_19_0 == "Btn_Down" then
    l_19_1:ScrollNext(1)
  end
end

Recount.OnLButtonHold = function()
  local l_20_0 = this:GetName()
  local l_20_1 = Station.Lookup("Normal/Recount/Wnd_Output/Scroll_List")
  if l_20_0 == "Btn_Up" then
    l_20_1:ScrollPrev(1)
  elseif l_20_0 == "Btn_Down" then
    l_20_1:ScrollNext(1)
  end
end

Recount.OnFrameDragEnd = function()
  this:CorrectPos()
  zrecountanchor = GetFrameAnchor(this)
end

Recount.UpdateAnchor = function(l_22_0)
  if zrecountanchor.x == 0 and zrecountanchor.y == 0 then
    l_22_0:SetPoint("TOPLEFT", 0, 0, "TOPLEFT", 367, 256)
  else
    l_22_0:SetPoint(zrecountanchor.s, 0, 0, zrecountanchor.r, zrecountanchor.x, zrecountanchor.y)
  end
  l_22_0:CorrectPos()
end

Recount.GetFromID = function(l_23_0)
  local l_23_1 = nil
  if IsPlayer(l_23_0) then
    l_23_1 = GetPlayer(l_23_0)
  else
    l_23_1 = GetNpc(l_23_0)
  end
  return l_23_1
end

Recount.GetColor = function(l_24_0)
  local l_24_1 = {}
  local l_24_2 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_24_1["���"], l_24_2 = l_24_2, {0, 128, 0, 255}
  l_24_1["��"], l_24_2 = l_24_2, {100, 0, 150, 96}
  l_24_1["����"], l_24_2 = l_24_2, {0, 175, 230, 112}
  l_24_1["����"], l_24_2 = l_24_2, {240, 80, 240, 96}
  l_24_1["����"], l_24_2 = l_24_2, {210, 180, 0, 144}
  l_24_1["�ؽ�"], l_24_2 = l_24_2, {215, 241, 74, 144}
  l_24_1["�嶾"], l_24_2 = l_24_2, {0, 128, 255, 144}
  l_24_1["����"], l_24_2 = l_24_2, {121, 183, 54, 144}
  l_24_1["����"], l_24_2 = l_24_2, {240, 70, 96, 180}
  l_24_1["ؤ��"], l_24_2 = l_24_2, {205, 133, 63, 180}
  l_24_2 = IsPlayer
  l_24_2 = l_24_2(l_24_0.dwID)
  if l_24_2 then
    l_24_2 = GetForceTitle
    l_24_2 = l_24_2(l_24_0.dwForceID)
  end
  if l_24_1[l_24_2] then
    return l_24_1[l_24_2]
  end
  return l_24_2
  l_24_2 = {0, 128, 0, 255}
end

Recount.Clear = function()
  Recount.PlayerDataRecordList = {}
  Recount.PlayerDataDisplayList = {}
  local l_25_0 = GetClientPlayer()
  if l_25_0.bFightState then
    Recount.startfighttime = GetTime()
  else
    Recount.startfighttime = 0
  end
  Recount.totalfighttime = 0
  Recount.Display()
end

Recount.config = function()
  local l_26_0 = {}
  local l_26_1 = {}
  l_26_1.szOption = "ͳ��Boss"
  l_26_1.bDisable = false
  l_26_1.bCheck = true
  l_26_1.bChecked = Recount.countboss
  l_26_1.fnAction = function()
    if Recount.countboss then
      Recount.countboss = false
    else
      Recount.countboss = true
    end
  end
  l_26_1.fnAutoClose = function()
    return true
  end
  local l_26_2 = {}
  l_26_2.szOption = "ͳ�Ʒ�ʽ"
  local l_26_3 = {}
  l_26_3.szOption = "��������"
  l_26_3.bMCheck = true
  l_26_3.bChecked = Recount.nDataMode == 1
  l_26_3.fnAction = function()
    Recount.nDataMode = 1
  end
  local l_26_6 = {}
  l_26_6.szOption = "��Ч����"
  l_26_6.bMCheck = true
  l_26_6.bChecked = Recount.nDataMode == 2
  l_26_6.fnAction = function()
    Recount.nDataMode = 2
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_26_6 = function()
    return true
  end
  local l_26_11 = {}
  l_26_11.szOption = "�Ŷ�"
  l_26_11.bDisable = false
  l_26_11.bMCheck = true
  l_26_11.bChecked = zRecountspeak == PLAYER_TALK_CHANNEL.RAID
  l_26_11.fnAction = function()
    zRecountspeak = PLAYER_TALK_CHANNEL.RAID
  end
  l_26_11.fnAutoClose = function()
    return true
  end
  local l_26_14 = {}
  l_26_14.szOption = "����"
  l_26_14.bDisable = false
  l_26_14.bMCheck = true
  l_26_14.bChecked = zRecountspeak == PLAYER_TALK_CHANNEL.NEARBY
  l_26_14.fnAction = function()
    zRecountspeak = PLAYER_TALK_CHANNEL.NEARBY
  end
  l_26_14.fnAutoClose = function()
    return true
  end
  local l_26_17 = {}
  l_26_17.szOption = "���"
  l_26_17.bDisable = false
  l_26_17.bMCheck = true
  l_26_17.bChecked = zRecountspeak == PLAYER_TALK_CHANNEL.TONG
  l_26_17.fnAction = function()
    zRecountspeak = PLAYER_TALK_CHANNEL.TONG
  end
  l_26_17.fnAutoClose = function()
    return true
  end
  l_26_6 = {szOption = "����", bDisable = false, bMCheck = true, bChecked = zRecountspeak == PLAYER_TALK_CHANNEL.TEAM, fnAction = function()
    zRecountspeak = PLAYER_TALK_CHANNEL.TEAM
  end, fnAutoClose = function()
    return true
  end}
  l_26_11 = function()
    return true
  end
  l_26_14 = RECOUNT_FANGSHI
  l_26_14 = l_26_14.fangshi
  l_26_14 = l_26_14 == "TotalDamage"
  l_26_14 = function()
    RECOUNT_FANGSHI.fangshi = "TotalDamage"
    Recount.Display()
  end
  l_26_14 = function()
    return true
  end
  l_26_17 = RECOUNT_FANGSHI
  l_26_17 = l_26_17.fangshi
  l_26_17 = l_26_17 == "DPS"
  l_26_17 = function()
    RECOUNT_FANGSHI.fangshi = "DPS"
    Recount.Display()
  end
  l_26_17 = function()
    return true
  end
  l_26_14, l_26_11 = {szOption = "ÿ���˺�������", bDisable = false, bMCheck = true, bChecked = l_26_17, fnAction = l_26_17, fnAutoClose = l_26_17}, {szOption = "���˺�������", bDisable = false, bMCheck = true, bChecked = l_26_14, fnAction = l_26_14, fnAutoClose = l_26_14}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_26_1 = PopupMenu
  l_26_2 = l_26_0
  l_26_1(l_26_2)
end

Recount.Toggle = function()
  local l_27_0 = Station.Lookup("Normal/Recount")
  Recount.Clear()
  if l_27_0:IsVisible() then
    l_27_0:Hide()
    Recount.bOn = false
  else
    l_27_0:Show()
    Recount.bOn = true
  end
end

Recount.Show = function()
  local l_28_0 = Station.Lookup("Normal/Recount")
  if not l_28_0:IsVisible() then
    Recount.Clear()
    l_28_0:Show()
  end
end

Recount.Hide = function()
  local l_29_0 = Station.Lookup("Normal/Recount")
  if l_29_0:IsVisible() then
    Recount.Clear()
    l_29_0:Hide()
  end
end

Recount.Create = function(l_30_0)
  local l_30_1 = BoxCheckBox
  local l_30_2 = l_30_0
  local l_30_3 = "CheckBox_Recount"
  local l_30_4 = {}
  l_30_4.txt = "�˺�������ͳ��"
  l_30_1 = l_30_1(l_30_2, l_30_3, l_30_4)
  l_30_2, l_30_3 = l_30_1:SetBoolValue, l_30_1
  l_30_4 = Recount
  l_30_2(l_30_3, l_30_4, "bOn")
  l_30_2, l_30_3 = l_30_1:OnCheck, l_30_1
  l_30_4 = Recount
  l_30_4 = l_30_4.Show
  l_30_2(l_30_3, l_30_4)
  l_30_2, l_30_3 = l_30_1:UnCheck, l_30_1
  l_30_4 = Recount
  l_30_4 = l_30_4.Hide
  l_30_2(l_30_3, l_30_4)
end

RegisterMoonButton("zRecount", 19, "�˺�ͳ��", "Team", Recount.Create)
RegisterEvent("AddonLoad", function()
  Wnd.OpenWindow("Interface\\Moon_zRecount\\Recount.ini", "Recount"):Show(Recount.bOn)
end
)
local l_0_1 = RegisterMoonMenu
local l_0_2 = "Recount"
local l_0_3 = {}
l_0_3.szName = "�˺�ͳ��"
l_0_3.szImage = "ui\\image\\targetpanel\\target.uitex"
l_0_3.nFrame = 57
l_0_3.fnAction = Recount.Toggle
l_0_1(l_0_2, l_0_3)

