-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SkillMonitor.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1["����ʽ"] = 30
l_0_1["Ħڭ����"] = 19
l_0_1["���̽Կ�"] = 14
l_0_1["׽Ӱʽ"] = 20
l_0_1["�͹Ǿ�"] = 45
l_0_1["�����"] = 54
l_0_0["����"] = l_0_1
l_0_0["��"], l_0_1 = l_0_1, {["ܽ�ز���"] = 20, ["̫��ָ"] = 25, ["����ָ"] = 10, ["��¥��Ӱ"] = 24, ["���໤��"] = 33, ["��������"] = 30, ["��������"] = 180}
l_0_0["����"], l_0_1 = l_0_1, {["��������"] = 120, ["���Ż���"] = 20, ["��ת��һ"] = 15, ["���Զ���"] = 25, ["�򽣹���"] = 13, ["�������"] = 20, ["���ɾ���"] = 20, ["�˽���һ"] = 15, ["תǬ��"] = 110, ["������"] = 10}
l_0_0["�ؽ�"], l_0_1 = l_0_1, {["����"] = 15, ["Х��"] = 10.5, ["����"] = 12, ["��Ȫ����"] = 28, ["�׹��ɽ"] = 20, ["�紵��"] = 45, ["ժ��"] = 20}
l_0_0["���"], l_0_1 = l_0_1, {["ͻ"] = 20, ["�����"] = 60, ["��"] = 25, ["��"] = 15, ["����"] = 20, ["��"] = 20, ["�ϻ��"] = 23, ["�γ۳�"] = 40}
l_0_0["����"], l_0_1 = l_0_1, {["��Ӱ����"] = 30, ["��������"] = 40, ["����ͨ��"] = 30, ["ȵ̤֦"] = 90, ["��Ū��"] = 75, ["������"] = 300, ["��ĸ����"] = 5, ["����Ͱ�"] = 45, ["��صͰ�"] = 83}
l_0_0["�嶾"], l_0_1 = l_0_1, {["�Ƴ��׼�"] = 30, ["Ů洲���"] = 49, ["�Ƴ��"] = 120, ["�ٻ�����"] = 30, ["����"] = 15, ["�Х"] = 12, ["ǧ˿"] = 8}
l_0_0["����"], l_0_1 = l_0_1, {["÷����"] = 15, ["����޼"] = 17, ["������"] = 30, ["����"] = 20, ["������צ"] = 24, ["��������"] = 90, ["������Ӱ"] = 90, ["���Ĵ̹�"] = 20, ["��������"] = 65, ["���Ƕ�Ӱ"] = 45}
l_0_0["����"], l_0_1 = l_0_1, {["�ùⲽ"] = 30, ["������ɢ"] = 45, ["�������"] = 120, ["���ⷨ"] = 60, ["̰ħ��"] = 40, ["������Ӱ"] = 20, ["��η����"] = 32, ["��������"] = 25, ["������"] = 45, ["ʥ����"] = 60}
l_0_0["ؤ��"], l_0_1 = l_0_1, {["��Ծ��Ԩ"] = 10, ["��ս��Ұ"] = 10, ["����ͷ"] = 20, ["��������"] = 25, ["��Х����"] = 36, ["������"] = 30, ["Ц����"] = 84}
local l_0_2 = {}
local l_0_3 = {}
l_0_3.s = "TOPCENTER"
l_0_3.r = "TOPCENTER"
l_0_3.x = 0
l_0_3.y = 190
l_0_2.Anchor = l_0_3
l_0_2.bOn = false
l_0_2.nFrame = 5
l_0_2.nVersion = 0
l_0_2.nCurrVersion = 4
l_0_2.Monitor, l_0_3 = l_0_3, {}
l_0_2.tShield, l_0_3 = l_0_3, {}
l_0_2.nShowStyle = 2
SkillMonitor = l_0_2
l_0_2 = SkillMonitor
l_0_3 = clone
l_0_3 = l_0_3(l_0_0)
l_0_2.Monitor = l_0_3
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.nShowStyle"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.nVersion"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.Monitor"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.tShield"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.Anchor"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.bOn"
l_0_2(l_0_3)
l_0_2 = RegisterCustomData
l_0_3 = "SkillMonitor.nFrame"
l_0_2(l_0_3)
l_0_2 = false
local l_0_4 = function()
  if Moon.CheckAddon("Moon_ShieldRender") and ShieldRender.bShield and ShieldRender.tSetting[19] then
    return true
  end
  return false
end

local l_0_5 = {}
local l_0_6 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_5["����ͻ"], l_0_6 = l_0_6, {"��صͰ�", "ȵ̤֦", "��Ū��", "������"}
l_0_5["������"], l_0_6 = l_0_6, {"��������"}
l_0_5["תǬ��"], l_0_6 = l_0_6, {"��̫��", "��̫��", "������", "������"}
l_0_5["�ϳ�"], l_0_6 = l_0_6, {"�Ʒ����"}
l_0_5["�������"], l_0_6 = l_0_6, {"������ɢ", "��η����", "��������", "������Ӱ", "ҵ���︿", "��ҹ�ϳ�", "̰ħ��"}
l_0_5["���໤��"], l_0_6 = l_0_6, {"̫��ָ"}
l_0_6 = function(l_2_0, l_2_1, l_2_2)
  -- upvalues: l_0_0 , l_0_1 , l_0_5 , l_0_3
  if not l_2_0 then
    return 
  end
  if l_2_2 == 0 then
    l_2_2 = 1
  end
  local l_2_3 = Table_GetSkillName(l_2_1, l_2_2)
  local l_2_4 = Table_GetSkillIconID(l_2_1, l_2_2)
  if not Table_IsSkillShow(l_2_1, l_2_2) or l_2_4 == -1 or l_2_4 == 13 then
    return 
  end
  local l_2_5 = GetPlayer(l_2_0)
  if not l_2_5 then
    return 
  end
  local l_2_6 = GetForceTitle(l_2_5.dwForceID)
  if not l_0_0[l_2_6] then
    return 
  end
  if l_0_1[l_2_3] then
    l_2_3 = l_0_1[l_2_3]
  end
  if l_0_5[l_2_3] then
    for l_2_10,l_2_11 in ipairs(l_0_5[l_2_3]) do
      if not l_0_3[l_2_0] then
        local l_2_12, l_2_13 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      for l_2_17,l_2_18 in pairs(l_2_12) do
        local l_2_14 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        if R17_PC63.szName == l_2_11 then
          table.remove(l_2_14, l_2_18)
      else
        end
      end
    end
  end
  local l_2_19, l_2_35 = SkillMonitor.Monitor[l_2_6][l_2_3]
  if l_2_19 then
    l_2_35 = l_0_3
    if not l_0_3[l_2_0] then
      l_2_35[l_2_0] = {}
    end
    l_2_35 = ipairs
    l_2_35 = l_2_35(l_0_3[l_2_0])
    for l_2_23,l_2_24 in l_2_35 do
      local l_2_24 = nil
      l_2_24 = l_2_23.szName
      if l_2_24 == l_2_3 then
        l_2_24 = table
        l_2_24 = l_2_24.remove
        l_2_24(l_0_3[l_2_0], l_2_22)
        do break end
      end
    end
    local l_2_25, l_2_30, l_2_36 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_2_26, l_2_31, l_2_37 = nil
    l_2_30 = table
    l_2_30 = l_2_30.insert
    local l_2_27, l_2_32, l_2_38 = nil
    l_2_36 = l_0_3
    l_2_36 = l_2_36[l_2_0]
    local l_2_28, l_2_33, l_2_39 = nil
    do
      local l_2_29, l_2_34, l_2_40 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_2_30(l_2_36, {szName = l_2_3, dwID = l_2_1, nLevel = l_2_2, nIcon = l_2_4, nTotalTime = l_2_19 * 16, nEndTime = l_2_25})
  end
end

local l_0_7 = function(l_3_0, l_3_1)
  local l_3_2 = GetClientPlayer()
  do
    local l_3_3, l_3_4 = l_3_2.GetTarget()
    if not IsPlayer(l_3_0) or ((l_3_3 == TARGET.PLAYER and l_3_4 == l_3_0) or l_3_1 == SKILL_EFFECT_TYPE.BUFF) then
      return false
    end
    if l_3_3 == TARGET.PLAYER then
      local l_3_5 = GetPlayer(l_3_0)
    end
    if l_3_5 and l_3_3 == TARGET.PLAYER and l_3_0 == R7_PC39 then
      return false
    end
    return true
  end
   -- WARNING: undefined locals caused missing assignments!
end

local l_0_8 = nil
local l_0_10 = function()
  -- upvalues: l_0_8 , l_0_3
  local l_4_0 = 160
  local l_4_1 = GetLogicFrameCount()
  if not l_0_8 then
    l_0_8 = l_4_1
  else
    if l_4_0 < l_4_1 - l_0_8 then
      l_0_8 = l_4_1
      for l_4_5,l_4_6 in pairs(l_0_3) do
        for l_4_10,l_4_11 in ipairs(l_4_6) do
          if l_4_11.nEndTime < l_4_1 then
            table.remove(l_4_6, l_4_10)
          end
        end
        if #l_4_6 == 0 then
          l_0_3[l_4_5] = nil
        end
      end
    end
  end
end

do
  for l_0_15,l_0_16 in pairs({"DO_SKILL_CAST", "PLAYER_LEAVE_SCENE", "SYS_MSG", "Breathe"}) do
    local l_0_12, l_0_13 = function()
  local l_5_0 = GetClientPlayer()
  if not l_5_0 then
    return 
  end
  local l_5_1 = l_5_0.GetMapID()
  if l_5_1 == 25 or l_5_1 == 27 then
    local l_5_2 = GetCurrentTime()
    do
      local l_5_3 = TimeToDate(l_5_2)
    if l_5_3.weekday ~= 6 then
      end
    if l_5_3.weekday ~= 6 then
      end
    end
    return true
  end
  return false
end
, function(l_6_0)
  -- upvalues: l_0_4 , l_0_2 , l_0_10 , l_0_11 , l_0_6 , l_0_3 , l_0_7 , l_0_9
  local l_6_6, l_6_7 = nil
  if l_6_0 == "DO_SKILL_CAST" then
    if not SkillMonitor.bOn or l_0_4() then
      return 
    end
    if l_0_2 and not l_0_10() then
      l_0_2 = false
      RegisterEvent("SYS_MSG", l_0_11)
    end
    if IsPlayer(arg0) and arg0 ~= GetClientPlayer().dwID then
      l_0_6(arg0, arg1, arg2)
    end
  elseif l_6_0 == "PLAYER_LEAVE_SCENE" then
    local l_6_1 = arg0
    do
      if l_0_3[l_6_1] then
        DelayCall(20, function()
        -- upvalues: l_0_3 , l_6_1
        l_0_3[l_6_1] = nil
      end)
      end
    end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_6_0 == "SYS_MSG" then
    if not SkillMonitor.bOn or l_0_4() then
      return 
    end
    if l_0_10() and not l_0_2 then
      l_0_2 = true
      local l_6_2 = nil
      local l_6_3 = UnRegisterEvent
      local l_6_4 = "SYS_MSG"
      return l_6_3(l_6_4, l_0_11)
    end
    if arg0 == "UI_OME_SKILL_MISS_LOG" or arg0 == "UI_OME_SKILL_HIT_LOG" then
      local l_6_8 = nil
      local l_6_9 = GetClientPlayer()
      if IsPlayer(arg1) and (l_6_9.IsPlayerInMyParty(arg1) or GetClientTeam().IsPlayerInTeam(arg1)) then
        return 
      end
      if l_0_7(arg1, arg3) then
        l_0_6(arg1, arg4, arg5)
      end
    elseif arg0 == "UI_OME_SKILL_EFFECT_LOG" then
      l_0_6(arg1, arg5, arg6)
    elseif arg0 == "UI_OME_SKILL_BLOCK_LOG" or arg0 == "UI_OME_SKILL_SHIELD" or arg0 == "UI_OME_SKILL_MISS_LOG" or arg0 == "UI_OME_SKILL_DODGE_LOG" then
      l_0_6(arg1, arg4, arg5)
    end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_6_8 == "Breathe" then
    l_0_9()
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

     -- DECOMPILER ERROR: Confused about usage of registers!

    RegisterEvent("SYS_MSG", l_0_13)
  end
  SkillMonitor.OnFrameCreate = function()
  local l_7_0 = Station.Lookup("Normal/SkillMonitor")
  local l_7_1 = l_7_0:Lookup("", "")
  l_7_1:Lookup("Text_TitleName"):SetText("Ŀ�꼼��")
  l_7_1:Lookup("Handle_List"):Clear()
  this:RegisterEvent("UI_SCALED")
  SkillMonitor.UpdateAnchor(this)
end

  SkillMonitor.OnEvent = function(l_8_0)
  if l_8_0 == "UI_SCALED" then
    SkillMonitor.UpdateAnchor(this)
  end
end

  SkillMonitor.UpdateAnchor = function(l_9_0)
  l_9_0:SetPoint(SkillMonitor.Anchor.s, 0, 0, SkillMonitor.Anchor.r, SkillMonitor.Anchor.x, SkillMonitor.Anchor.y)
  l_9_0:CorrectPos()
end

  SkillMonitor.OnFrameDragEnd = function()
  this:CorrectPos()
  SkillMonitor.Anchor = GetFrameAnchor(this)
end

  SkillMonitor.OnItemMouseEnter = function()
  this:SetObjectMouseOver(1)
  local l_11_0, l_11_1 = this:GetAbsPos()
  local l_11_2, l_11_3 = this:GetSize()
  local l_11_4, l_11_5 = this:GetObjectData()
  local l_11_6 = OutputSkillTip
  local l_11_7 = l_11_4
  local l_11_8 = l_11_5
  do
    local l_11_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_11_6(l_11_7, l_11_8, l_11_9, false)
  end
   -- WARNING: undefined locals caused missing assignments!
end

  SkillMonitor.OnItemMouseLeave = function()
  HideTip()
  this:SetObjectMouseOver(0)
end

  SkillMonitor.UpdateInfo = function(l_13_0, l_13_1)
  local l_13_2 = (l_13_0:GetItemCount())
  local l_13_3 = nil
  if l_13_0.nIndex < l_13_2 then
    l_13_3 = l_13_0.nIndex
  else
    l_13_0:AppendItemFromIni("interface/Moon_SkillMonitor/SkillMonitor.ini", "Handle_Skill")
    l_13_3 = l_13_2
  end
  l_13_0.nIndex = l_13_3 + 1
  local l_13_4 = l_13_0:Lookup(l_13_3)
  local l_13_5, l_13_6, l_13_7 = GetTimeToHourMinuteSecond(l_13_1.nEndTime - GetLogicFrameCount(), true)
  local l_13_8 = string.format("%02d:%02d", l_13_6, l_13_7)
  if l_13_5 > 0 then
    l_13_8 = l_13_5 .. "h"
  end
  l_13_4:Lookup("Text_SkillCD"):SetText(l_13_8)
  l_13_4:Lookup("Image_Per"):SetFrame(SkillMonitor.nFrame)
  l_13_4:Lookup("Image_Per"):SetPercentage(1 - (l_13_1.nEndTime - GetLogicFrameCount()) / l_13_1.nTotalTime)
  if not l_13_4.dwID or l_13_4.dwID ~= l_13_1.dwID then
    l_13_4:Lookup("Text_SkillName"):SetText(l_13_1.szName)
    l_13_4:Lookup("Box_Icon"):SetObject(UI_OBJECT_SKILL, l_13_1.dwID, l_13_1.nLevel)
    l_13_4:Lookup("Box_Icon"):SetObjectIcon(l_13_1.nIcon)
  end
  l_13_4:Show()
end

  SkillMonitor.OnFrameBreathe = function()
  -- upvalues: l_0_3
  local l_14_0 = Station.Lookup("Normal/SkillMonitor")
  local l_14_1 = l_14_0:Lookup("", "Handle_List")
  local l_14_2 = GetClientPlayer()
  if not l_14_2 then
    return 
  end
  local l_14_8, l_14_9, l_14_10, l_14_11, l_14_12, l_14_13, l_14_14, l_14_15 = GetTargetHandle, l_14_2.GetTarget(), .end
  l_14_8 = l_14_8(l_14_9, l_14_10, l_14_11, l_14_12, l_14_13, l_14_14, l_14_15)
  local l_14_3 = nil
  l_14_9, l_14_10 = l_14_0:Lookup, l_14_0
  l_14_11 = ""
  l_14_12 = "Text_TitleName"
  l_14_9 = l_14_9(l_14_10, l_14_11, l_14_12)
  local l_14_4 = nil
  if l_14_8 then
    l_14_10 = l_0_3
    l_14_11 = l_14_8.dwID
    l_14_10 = l_14_10[l_14_11]
  end
  if l_14_10 then
    l_14_10 = IsEmpty
    l_14_11 = l_0_3
    l_14_12 = l_14_8.dwID
    l_14_11 = l_14_11[l_14_12]
    l_14_10 = l_14_10(l_14_11)
  if l_14_10 then
    end
  end
  l_14_10, l_14_11 = l_14_9:SetText, l_14_9
  l_14_12 = "Ŀ�꼼��"
  l_14_10(l_14_11, l_14_12)
  l_14_10, l_14_11 = l_14_1:Hide, l_14_1
  l_14_10(l_14_11)
  l_14_10 = SkillMonitor
  l_14_10 = l_14_10.UpdateSize
  local l_14_5 = nil
  l_14_11 = l_14_1
  local l_14_6 = nil
  l_14_12 = 0
  do
    local l_14_7 = nil
    return l_14_10(l_14_11, l_14_12)
  end
  l_14_10, l_14_11 = l_14_9:SetText, l_14_9
  l_14_12 = l_14_8.szName
  l_14_10(l_14_11, l_14_12)
  l_14_10 = GetForceTitle
  l_14_11 = l_14_8.dwForceID
  l_14_10 = l_14_10(l_14_11)
  l_14_11 = l_14_8.dwID
  l_14_12 = GetLogicFrameCount
  l_14_12 = l_14_12()
  l_14_1.nIndex = 0
  l_14_13 = ipairs
  l_14_14 = l_0_3
  l_14_14 = l_14_14[l_14_11]
  l_14_13 = l_14_13(l_14_14)
  for l_14_3,l_14_4 in l_14_13 do
    if l_14_12 < l_14_4.nEndTime then
      SkillMonitor.UpdateInfo(l_14_1, l_14_4)
    end
  end
  for i = l_14_1:GetItemCount() - 1, l_14_1.nIndex, -1 do
    l_14_1:Lookup(i):Hide()
  end
  SkillMonitor.UpdateSize(l_14_1)
  l_14_1:Show()
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

  SkillMonitor.UpdateSize = function(l_15_0, l_15_1)
  if not l_15_1 then
    l_15_1 = l_15_0.nIndex
  end
  if l_15_0.nCount == l_15_1 then
    return 
  end
  local l_15_2, l_15_3 = l_15_0:GetSize()
  local l_15_4 = 25 * l_15_1
  l_15_0:SetSize(l_15_2, l_15_4)
  l_15_0:FormatAllItemPos()
  local l_15_5 = l_15_0:GetRoot()
  local l_15_6 = l_15_5:Lookup("", "")
  l_15_5:SetSize(l_15_2, l_15_4 + 25)
  l_15_5:SetDragArea(0, 0, l_15_2, l_15_4 + 25)
  l_15_6:SetSize(l_15_2, l_15_4)
  l_15_0.nCount = l_15_1
end

  local l_0_17, l_0_20 = nil
  local l_0_18, l_0_21 = {}, {}
  l_0_21.s = "CENTER"
  l_0_21.r = "CENTER"
  l_0_21.x = 200
  l_0_21.y = -122
  l_0_18.Anchor = l_0_21
  l_0_18.nMaxAlpha = 196
  l_0_18.nDirection = 1
  l_0_18.nBoxSize = 50
  l_0_18.nSpace = 10
  l_0_18.bEffect = false
  SkillAlert = l_0_18
  l_0_18 = RegisterCustomData
  l_0_21 = "SkillAlert.Anchor"
  l_0_18(l_0_21)
  l_0_18 = RegisterCustomData
  l_0_21 = "SkillAlert.nDirection"
  l_0_18(l_0_21)
  l_0_18 = RegisterCustomData
  l_0_21 = "SkillAlert.nBoxSize"
  l_0_18(l_0_21)
  l_0_18 = RegisterCustomData
  l_0_21 = "SkillAlert.nSpace"
  l_0_18(l_0_21)
  l_0_18 = RegisterCustomData
  l_0_21 = "SkillAlert.bEffect"
  l_0_18(l_0_21)
  l_0_18 = SkillAlert
  l_0_21 = function()
  this.handle = this:Lookup("", "")
  this.handle:Clear()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  SkillAlert.UpdateAnchor(this)
  SkillAlert.AdjustFrameSize()
end

  l_0_18.OnFrameCreate = l_0_21
  l_0_18 = SkillAlert
  l_0_21 = function(l_17_0)
  if l_17_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_17_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "Ŀ�꼼�ܼ��")
  elseif l_17_0 == "UI_SCALED" then
    SkillAlert.UpdateAnchor(this)
  end
end

  l_0_18.OnEvent = l_0_21
  l_0_18 = SkillAlert
  l_0_21 = function(l_18_0)
  local l_18_1 = SkillAlert.Anchor
  l_18_0:SetPoint(l_18_1.s, 0, 0, l_18_1.r, l_18_1.x, l_18_1.y)
  l_18_0:CorrectPos()
end

  l_0_18.UpdateAnchor = l_0_21
  l_0_18 = SkillAlert
  l_0_21 = function()
  this:CorrectPos()
  SkillAlert.Anchor = GetFrameAnchor(this)
end

  l_0_18.OnFrameDragEnd = l_0_21
  l_0_18 = SkillAlert
  l_0_21 = function()
  local l_20_0 = this.handle
  if not l_20_0:IsVisible() then
    return 
  end
  local l_20_1 = l_20_0:GetItemCount()
  if l_20_1 == 0 then
    return 
  end
  for l_20_5 = 0, l_20_1 - 1 do
    local l_20_6 = l_20_0:Lookup(l_20_5)
    if l_20_6 and l_20_6:IsVisible() and l_20_6.nEndTime then
      local l_20_7 = (l_20_6.nEndTime - GetTime()) / 1000
      if SkillAlert.bEffect and l_20_7 < 3 and l_20_7 > 0 then
        local l_20_8 = l_20_6:Lookup("Box_Alert")
        l_20_8:Show()
        local l_20_9 = l_20_7 % 1
        l_20_8:SetAlpha(SkillAlert.nMaxAlpha * l_20_9)
        local l_20_10 = 1.7 ^ (1 - l_20_9)
        l_20_8:SetSize(SkillAlert.nBoxSize * l_20_10, SkillAlert.nBoxSize * l_20_10)
        l_20_8:SetRelPos(-SkillAlert.nBoxSize * (l_20_10 - 1) / 2, -SkillAlert.nBoxSize * (l_20_10 - 1) / 2)
      else
        l_20_6:Lookup("Box_Alert"):Hide()
      end
      l_20_6:FormatAllItemPos()
    end
  end
end

  l_0_18.OnFrameRender = l_0_21
  l_0_18 = SkillAlert
  l_0_21 = function()
  -- upvalues: l_0_3
  local l_21_0 = GetLogicFrameCount()
  local l_21_1 = GetClientPlayer()
  if not l_21_1 or l_21_0 % 3 ~= 0 then
    return 
  end
  local l_21_2 = this.handle
  local l_21_8, l_21_9, l_21_10, l_21_11, l_21_12, l_21_13, l_21_14, l_21_15 = GetTargetHandle, l_21_1.GetTarget(), .end
  l_21_8 = l_21_8(l_21_9, l_21_10, l_21_11, l_21_12, l_21_13, l_21_14, l_21_15)
  local l_21_3 = nil
  l_21_9 = true
  local l_21_4 = nil
  if l_21_8 then
    l_21_10 = l_0_3
    l_21_11 = l_21_8.dwID
    l_21_10 = l_21_10[l_21_11]
  end
  if l_21_10 then
    l_21_10 = IsEmpty
    l_21_11 = l_0_3
    l_21_12 = l_21_8.dwID
    do
      local l_21_7 = nil
      l_21_11 = l_21_11[l_21_12]
      l_21_10 = l_21_10(l_21_11)
  end
  if l_21_10 then
    end
  end
  l_21_10, l_21_11 = l_21_2:Hide, l_21_2
  do
    local l_21_5, l_21_6 = nil
    return l_21_10(l_21_11)
  end
  l_21_10 = GetForceTitle
  l_21_11 = l_21_8.dwForceID
  l_21_10 = l_21_10(l_21_11)
  l_21_11 = l_21_8.dwID
  l_21_12 = GetLogicFrameCount
  l_21_12 = l_21_12()
  l_21_2.nIndex = 0
  l_21_13 = ipairs
  l_21_14 = l_0_3
  l_21_14 = l_21_14[l_21_11]
  l_21_13 = l_21_13(l_21_14)
  for l_21_3,l_21_4 in l_21_13 do
    if l_21_12 < l_21_4.nEndTime then
      SkillAlert.UpdateBox(l_21_2, l_21_4)
    end
  end
  for i = l_21_2:GetItemCount() - 1, l_21_2.nIndex, -1 do
    l_21_2:Lookup(i):Hide()
  end
  l_21_2:Show()
  l_21_2:FormatAllItemPos()
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

  l_0_18.OnFrameBreathe = l_0_21
  l_0_18 = function(l_22_0)
  local l_22_1 = (l_22_0 - GetLogicFrameCount()) / 16
  if l_22_1 < 100 then
    return string.format("%d\"", l_22_1), 204
  elseif l_22_1 < 3600 then
    return string.format("%d'", l_22_1 / 60), 203
  elseif l_22_1 < 36000 then
    return string.format("%d", l_22_1 / 3600), 203
  else
    return "", 203
  end
end

  l_0_21 = function(l_23_0)
  local l_23_1 = SkillAlert.nBoxSize + SkillAlert.nSpace
  local l_23_2 = string.len(l_23_0)
  local l_23_3 = l_23_0
  if l_23_1 < 45 then
    if l_23_2 > 6 then
      l_23_3 = StringSubW(l_23_0, 1, 2)
    elseif l_23_2 == 6 then
      l_23_3 = StringSubW(l_23_0, 2, 3)
    end
  elseif l_23_1 < 60 and l_23_2 > 6 then
    l_23_3 = StringSubW(l_23_0, 1, 2)
  end
  return l_23_3
end

  SkillAlert.UpdateBox = function(l_24_0, l_24_1)
  -- upvalues: l_0_13 , l_0_12
  local l_24_2 = "Interface/Moon_SkillMonitor/SkillAlert.ini"
  local l_24_3 = (l_24_0:GetItemCount())
  local l_24_4 = nil
  if l_24_0.nIndex < l_24_3 then
    l_24_4 = l_24_0.nIndex
  else
    l_24_4 = l_24_3
    l_24_0:AppendItemFromIni(l_24_2, "Handle_Skill")
  end
  l_24_0.nIndex = l_24_4 + 1
  local l_24_5 = l_24_0:Lookup(l_24_4)
  l_24_5:SetAlpha(SkillAlert.nMaxAlpha)
  local l_24_6 = l_24_5:Lookup("Box_Skill")
  local l_24_7 = l_24_5:Lookup("Box_Alert")
  l_24_6:SetSize(SkillAlert.nBoxSize, SkillAlert.nBoxSize)
  l_24_7:SetSize(SkillAlert.nBoxSize, SkillAlert.nBoxSize)
  if not l_24_5.dwID then
    l_24_6:SetOverTextFontScheme(0, 15)
    l_24_6:SetOverTextPosition(1, 3)
  end
  if l_24_5.dwID ~= l_24_1.dwID or l_24_5.nLevel ~= l_24_1.nLevel then
    l_24_5.dwID = l_24_1.dwID
    l_24_5.nLevel = l_24_1.nLevel
    l_24_6:SetObject(UI_OBJECT_SKILL, l_24_1.dwID, l_24_1.nLevel)
    l_24_6:SetObjectIcon(l_24_1.nIcon)
    l_24_7:SetObject(UI_OBJECT_SKILL, l_24_1.dwID, l_24_1.nLevel)
    l_24_7:SetObjectIcon(l_24_1.nIcon)
    l_24_6:SetObjectCoolDown(true)
    local l_24_8 = l_24_5:Lookup("Text_Name")
    l_24_8:SetSize(SkillAlert.nBoxSize, 25)
    l_24_8:SetRelPos(0, SkillAlert.nBoxSize)
    l_24_8:SetText(l_0_13(l_24_1.szName))
  end
  local l_24_9 = (l_24_1.nEndTime - GetLogicFrameCount()) * 1000 / 16
  l_24_5.nEndTime = GetTime() + l_24_9
  local l_24_10, l_24_11 = l_0_12(l_24_1.nEndTime)
  l_24_6:SetOverText(1, l_24_10)
  l_24_6:SetOverTextFontScheme(1, l_24_11)
  l_24_6:SetCoolDownPercentage(1 - (l_24_1.nEndTime - GetLogicFrameCount()) / l_24_1.nTotalTime)
  if SkillAlert.nDirection == 1 then
    l_24_5:SetRelPos(l_24_4 * (SkillAlert.nBoxSize + SkillAlert.nSpace), 0)
  else
    if SkillAlert.nDirection == 2 then
      l_24_5:SetRelPos(-l_24_4 * (SkillAlert.nBoxSize + SkillAlert.nSpace), 0)
    end
  else
    if SkillAlert.nDirection == 3 then
      l_24_5:SetRelPos(0, l_24_4 * (SkillAlert.nBoxSize + 25 + SkillAlert.nSpace))
    end
  else
    if SkillAlert.nDirection == 4 then
      l_24_5:SetRelPos(0, -l_24_4 * (SkillAlert.nBoxSize + 25 + SkillAlert.nSpace))
    end
  end
  l_24_5:Show()
  l_24_5:FormatAllItemPos()
end

  SkillAlert.ClearAllAlert = function()
  local l_25_0 = Station.Lookup("Normal/SkillAlert")
  if l_25_0 then
    l_25_0.handle:Clear()
  end
end

  SkillAlert.AdjustFrameSize = function(l_26_0)
  local l_26_1 = Station.Lookup("Normal/SkillAlert")
  if l_26_1 then
    l_26_1:SetSize(SkillAlert.nBoxSize * 3 + 2 * SkillAlert.nSpace, SkillAlert.nBoxSize + 25)
  end
  if l_26_0 then
    l_26_1:CorrectPos()
    SkillAlert.Anchor = GetFrameAnchor(l_26_1)
  end
end

  SkillAlert.ToggleFrame = function(l_27_0)
  -- upvalues: l_0_4
  if not Station.Lookup("Normal/SkillMonitor") then
    local l_27_1, l_27_2, l_27_10, l_27_11, l_27_13, l_27_15 = Wnd.OpenWindow("interface/Moon_SkillMonitor/SkillMonitor.ini", "SkillMonitor")
  end
  if not Station.Lookup("Normal/SkillAlert") then
    local l_27_3, l_27_12, l_27_14, l_27_16 = , Wnd.OpenWindow("interface/Moon_SkillMonitor/SkillAlert.ini", "SkillAlert")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  do
    if l_27_0 and not l_0_4() then
      local l_27_4, l_27_5 = nil
      l_27_3:Show(SkillMonitor.nShowStyle == 1)
      l_27_5:Show(SkillMonitor.nShowStyle == 2)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    l_27_4:Hide()
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_27_5:Hide()
  end
end

  OnCreate = function(l_28_0)
  -- upvalues: l_0_4
  local l_28_1 = BoxCheckBox
  local l_28_2 = l_28_0
  local l_28_3 = "CheckBox_SkillMonitor"
  local l_28_4 = {}
  l_28_4.txt = "����Ŀ�꼼�ܼ���"
  l_28_1 = l_28_1(l_28_2, l_28_3, l_28_4)
  l_28_2, l_28_3 = l_28_1:SetBoolValue, l_28_1
  l_28_4 = SkillMonitor
  l_28_2(l_28_3, l_28_4, "bOn")
  l_28_2, l_28_3 = l_28_1:OnCheck, l_28_1
  l_28_4 = function()
    SkillAlert.ToggleFrame(true)
  end
  l_28_2(l_28_3, l_28_4)
  l_28_2, l_28_3 = l_28_1:UnCheck, l_28_1
  l_28_4 = function()
    SkillAlert.ToggleFrame(false)
  end
  l_28_2(l_28_3, l_28_4)
  l_28_2 = BoxButton
  l_28_3 = l_28_0
  l_28_4 = "Btn_Manager"
  local l_28_5 = {}
  l_28_5.txt = "���ܹ���"
  l_28_5.x = 0
  l_28_5.y = 30
  l_28_2 = l_28_2(l_28_3, l_28_4, l_28_5)
  l_28_2, l_28_3 = l_28_2:OnClick, l_28_2
  l_28_4 = OpenSkillMonitorManager
  l_28_2(l_28_3, l_28_4)
  l_28_2, l_28_3 = l_28_0:Lookup, l_28_0
  l_28_4 = ""
  l_28_5 = ""
  l_28_2 = l_28_2(l_28_3, l_28_4, l_28_5)
  l_28_3 = BoxLabel
  l_28_4 = l_28_2
  l_28_5 = "label_tip"
  local l_28_6 = "ע���޷����������AOE���ܣ��磺���������϶���"
  local l_28_7 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_28_3(l_28_4, l_28_5, l_28_6, l_28_7)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_3(l_28_4, l_28_5, l_28_6, l_28_7, 27)
  l_28_7 = {0, 60}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_7 = SkillMonitor
  l_28_7 = l_28_7.nShowStyle
  l_28_7 = l_28_7 == 1
   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6 = {group = "style", txt = "�б����", x = 0, y = 120, bchecked = l_28_7}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6 = function()
    -- upvalues: l_0_4
    SkillMonitor.nShowStyle = 1
    if SkillMonitor.bOn and not l_0_4() then
      SkillAlert.ToggleFrame(true)
    end
  end
  l_28_4(l_28_5, l_28_6)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6 = "ComboBox_Texture"
   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_7 = {x = 30, y = 150, txt = "�޸Ĳ���", w = 150, h = 25}
   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6 = l_28_4
  l_28_7 = function(l_32_0)
    for l_32_4 = 0, 7 do
      do
        local l_32_5 = {}
        l_32_5.bMCheck = true
        l_32_5.bChecked = SkillMonitor.nFrame == l_32_4
        l_32_5.szIcon = "interface/Moon_Lib/img/progressbar.UiTex"
        l_32_5.nFrame = l_32_4
        l_32_5.fnAction = function()
          -- upvalues: l_4_4
          SkillMonitor.nFrame = l_4_4
        end
        table.insert(l_32_0, l_32_5)
      end
    end
  end
  l_28_5(l_28_6, l_28_7)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6 = l_28_0
  l_28_7 = "RadioBox_BoxView"
  local l_28_8 = {}
  l_28_8.group = "style"
  l_28_8.txt = "ͼ����"
  l_28_8.x = 0
  l_28_8.y = 180
  l_28_8.bchecked = SkillMonitor.nShowStyle == 2
   -- DECOMPILER ERROR: Overwrote pending register.

  l_28_6, l_28_7 = l_28_5:OnCheck, l_28_5
  l_28_8 = function()
    -- upvalues: l_0_4
    SkillMonitor.nShowStyle = 2
    if SkillMonitor.bOn and not l_0_4() then
      SkillAlert.ToggleFrame(true)
    end
  end
  l_28_6(l_28_7, l_28_8)
  l_28_6 = BoxBoolCheckBox
  l_28_7 = l_28_0
  l_28_8 = "CheckBox_bEffect"
  l_28_6 = l_28_6(l_28_7, l_28_8, "������˸��Ч", SkillAlert, "bEffect")
  l_28_6, l_28_7 = l_28_6:SetRelPos, l_28_6
  l_28_8 = 30
  l_28_6(l_28_7, l_28_8, 210)
  l_28_6 = BoxComboBox
  l_28_7 = l_28_0
  l_28_8 = "ComboBox_Layout"
  local l_28_11 = {}
  l_28_11.txt = "ͼ�겼������"
  l_28_11.x = 30
  l_28_11.y = 240
  l_28_6 = l_28_6(l_28_7, l_28_8, l_28_11)
  l_28_6, l_28_7 = l_28_6:SetMenu, l_28_6
  l_28_8 = function(l_34_0)
    local l_34_1 = {}
    l_34_1.szOption = "���з���"
    local l_34_2 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_34_6,l_34_7 in "������"("���ҵ���") do
      do
        local l_34_8 = table.insert
        do
          local l_34_9 = l_34_1
          local l_34_10 = {}
          l_34_8(l_34_9, l_34_10)
        end
      end
      table.insert(l_34_0, l_34_1)
      local l_34_13, l_34_33 = {}
      for l_34_17 = l_34_33, 30, 5 do
        local l_34_17 = nil
        l_34_17 = table
        l_34_17 = l_34_17.insert
        local l_34_18 = nil
        l_34_18 = l_34_13
        local l_34_19 = nil
        local l_34_20 = nil
        l_34_20 = tostring
        l_34_20 = l_34_20(l_34_16)
        l_34_20 = SkillAlert
        l_34_20 = l_34_20.nSpace
        l_34_20 = l_34_20 == l_34_16
        l_34_20 = function()
          -- upvalues: l_6_7
          SkillAlert.nSpace = l_6_7
          SkillAlert.ClearAllAlert()
          SkillAlert.AdjustFrameSize(true)
        end
        l_34_17(l_34_18, l_34_19)
        l_34_19 = {szOption = l_34_20, bMCheck = true, bChecked = l_34_20, fnAction = l_34_20}
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      l_34_33.insert(l_34_0, l_34_13)
      local l_34_23, l_34_34 = nil
      l_34_23 = 35
      l_34_34 = 80
      for l_34_27 = l_34_23, l_34_34, 5 do
        local l_34_26, l_34_27 = nil
        l_34_26 = table
        l_34_26 = l_34_26.insert
        local l_34_28 = nil
        l_34_27 = {szOption = "ͼ���С"}
        local l_34_29 = nil
        local l_34_30 = nil
        l_34_29 = tostring
        l_34_30 = l_34_25
        l_34_29 = l_34_29(l_34_30)
        l_34_29 = SkillAlert
        l_34_29 = l_34_29.nBoxSize
        l_34_29 = l_34_29 == l_34_25
        l_34_29 = function()
          -- upvalues: l_6_8
          SkillAlert.nBoxSize = l_6_8
          SkillAlert.ClearAllAlert()
          SkillAlert.AdjustFrameSize(true)
        end
        l_34_26(l_34_27, l_34_28)
        l_34_28 = {szOption = l_34_29, bMCheck = true, bChecked = l_34_29, fnAction = l_34_29}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      table.insert(l_34_0, {szOption = "ͼ���С"})
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
  end
  l_28_6(l_28_7, l_28_8)
  l_28_6, l_28_7 = l_28_2:FormatAllItemPos, l_28_2
  l_28_6(l_28_7)
end

  RegisterMoonButton("SkillMonitor", 12, "Ŀ�꼼��", "General", OnCreate)
  RegisterEvent("AddonLoad", function()
  -- upvalues: l_0_0
  if SkillMonitor.nVersion < SkillMonitor.nCurrVersion then
    SkillMonitor.Monitor = clone(l_0_0)
    SkillMonitor.nVersion = SkillMonitor.nCurrVersion
  end
  for l_29_3 in pairs(SkillMonitor.Monitor) do
    if not SkillMonitor.tShield[l_29_3] then
      SkillMonitor.tShield[l_29_3] = {}
    end
  end
  SkillAlert.ToggleFrame(true)
end
)
  do
    local l_0_19, l_0_22 = {}
    l_0_19.szForce = ""
    SkillMonitorManager = l_0_19
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  this:EnableDrag(false)
  InitFrameAutoPosInfo(this, 1, nil, nil, function()
    Wnd.CloseWindow("SkillMonitorManager")
  end)
end

    l_0_19.OnFrameCreate = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  if not this.bItem then
    return 
  end
  this.bIn = true
  if not this.bSel then
    this:Lookup("Image_Over"):Show()
  end
end

    l_0_19.OnItemMouseEnter = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  if not this.bItem then
    return 
  end
  this.bIn = false
  if not this.bSel then
    this:Lookup("Image_Over"):Hide()
  end
end

    l_0_19.OnItemMouseLeave = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  if not this.bItem then
    return 
  end
  this.bSel = true
  local l_33_0 = this:GetParent()
  local l_33_1 = l_33_0:GetItemCount() - 1
  for l_33_5 = 0, l_33_1 do
    local l_33_6 = l_33_0:Lookup(l_33_5)
    if l_33_6 then
      if l_33_6:GetName() == this:GetName() then
        this:Lookup("Image_Sel"):Show()
        this:Lookup("Image_Over"):Hide()
      end
    else
      l_33_6.bSel = false
      l_33_6:Lookup("Image_Sel"):Hide()
    end
  end
end

    l_0_19.OnItemLButtonUp = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  if not this.bItem then
    return 
  end
  local l_34_0 = SkillMonitorManager.szForce
  local l_34_1 = this.szName
  local l_34_2 = {}
  local l_34_3 = {}
  l_34_3.szOption = "�޸�"
  l_34_3.fnAction = function()
    -- upvalues: l_34_1 , l_34_0
    OpenAddSkillMonitor(l_34_1, l_34_0)
  end
  local l_34_4 = {}
  l_34_4.szOption = "ɾ��"
  l_34_4.fnAction = function()
    -- upvalues: l_34_0 , l_34_1
    SkillMonitor.Monitor[l_34_0][l_34_1] = nil
    SkillMonitorManager.UpdateList()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_34_3 = PopupMenu
  l_34_4 = l_34_2
  l_34_3(l_34_4)
end

    l_0_19.OnItemRButtonClick = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  if not this.bItem then
    return 
  end
  OpenAddSkillMonitor(this.szName, SkillMonitorManager.szForce)
end

    l_0_19.OnItemLButtonDBClick = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  local l_36_0 = this:GetName()
  if l_36_0 == "Image_CheckBox" then
    local l_36_1 = this:GetParent()
    local l_36_2 = SkillMonitorManager.szForce
    if this:GetFrame() == 6 then
      this:SetFrame(5)
      SkillMonitor.tShield[l_36_2][l_36_1.szName] = true
    end
  else
    this:SetFrame(6)
    SkillMonitor.tShield[l_36_2][l_36_1.szName] = nil
  end
end

    l_0_19.OnItemLButtonClick = l_0_22
    l_0_19 = SkillMonitorManager
    l_0_22 = function()
  local l_37_0 = SkillMonitorManager.sSkills.handle
  l_37_0:Clear()
  local l_37_1 = SkillMonitorManager.szForce
  if l_37_1 ~= "" then
    local l_37_2 = 0
    for l_37_6,l_37_7 in table.pairsByKeys(SkillMonitor.Monitor[l_37_1]) do
      local l_37_8 = BoxHandle
      local l_37_9 = l_37_0
      local l_37_10 = (tostring(l_37_2))
      local l_37_11 = nil
      local l_37_12 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_37_13 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_37_14 = 30
      local l_37_15 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      local l_37_16 = {}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if not l_37_10 then
        l_37_10(l_37_11, l_37_12)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_10(l_37_11, l_37_12, l_37_13, l_37_14, l_37_15, l_37_16)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_37_17 = {}
      l_37_17.nAlpha = 230
       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_16 = {30, 30}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_10(l_37_11)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_17 = 330
       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_17, l_37_16 = {nAlpha = 230}, {l_37_17, 30}
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_10(l_37_11)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_37_10(l_37_11)
      l_37_2 = l_37_2 + 1
    end
    l_37_0:FormatAllItemPos()
  end
  SkillMonitorManager.sSkills:Update()
end

    l_0_19.UpdateList = l_0_22
    l_0_19 = function()
  -- upvalues: l_0_0
  if Station.Lookup("Normal/SkillMonitorManager") then
    return 
  end
  local l_38_0 = BoxFrame
  local l_38_1 = "SkillMonitorManager"
  local l_38_2 = {}
  l_38_2.title = "���ܼ��ӹ���"
  l_38_2.bglobal = true
  l_38_0 = l_38_0(l_38_1, l_38_2)
  l_38_1, l_38_2 = l_38_0:ui, l_38_0
  l_38_1 = l_38_1(l_38_2)
   -- DECOMPILER ERROR: Overwrote pending register.

  SkillMonitorManager.szForce = ""
  local l_38_3 = BoxComboBox
  local l_38_4 = l_38_1
  local l_38_5 = "ComboBox_ForceList"
  local l_38_6 = {}
  l_38_6.x = 20
  l_38_6.y = 40
  l_38_6.w = 180
  l_38_6.h = 25
  l_38_6.txt = "ѡ��ְҵ"
  l_38_3 = l_38_3(l_38_4, l_38_5, l_38_6)
  l_38_4 = BoxButton
  l_38_5 = l_38_1
  l_38_6 = "Btn_Add"
  local l_38_7 = {}
  l_38_7.x = 205
  l_38_7.y = 42
  l_38_7.txt = "����"
  l_38_7.w = 80
  l_38_7.h = 25
  l_38_4 = l_38_4(l_38_5, l_38_6, l_38_7)
  l_38_5 = BoxButton
  l_38_6 = l_38_1
  l_38_7 = "Btn_Reset"
  local l_38_8 = {}
  l_38_8.x = 285
  l_38_8.y = 42
  l_38_8.txt = "����"
  l_38_8.w = 80
  l_38_8.h = 25
  l_38_5 = l_38_5(l_38_6, l_38_7, l_38_8)
  l_38_6 = BoxImage
  l_38_7 = l_38_2
  l_38_8 = "Image_Break1"
  local l_38_9 = "ui/Image/UICommon/CommonPanel.UITex"
  local l_38_10 = 42
  local l_38_11 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_38_12 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_38_13 = {}
  l_38_6(l_38_7, l_38_8, l_38_9, l_38_10, l_38_11, l_38_12, l_38_13)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7(l_38_8, l_38_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_38_14 = {}
  l_38_14.nAlpha = 255
  l_38_7(l_38_8, l_38_9, l_38_10, l_38_11, l_38_12, l_38_13, l_38_14)
  l_38_13, l_38_12 = {380, 7}, {l_38_13, 7}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_12 = 20
  l_38_13 = 467
  l_38_7(l_38_8, l_38_9, l_38_10, l_38_11)
  l_38_11 = {l_38_12, l_38_13}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7(l_38_8, l_38_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7(l_38_8, l_38_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7(l_38_8, l_38_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_38_7(l_38_8)
end

    OpenSkillMonitorManager = l_0_19
    l_0_19 = function(l_39_0, l_39_1)
  if Station.Lookup("Normal/AddSkillMonitor") then
    return 
  end
  local l_39_2 = BoxSetFrame
  local l_39_3 = "AddSkillMonitor"
  local l_39_4 = {}
  l_39_4.w = 350
  l_39_4.h = 380
  l_39_4.bdrag = true
  l_39_2 = l_39_2(l_39_3, l_39_4)
  l_39_3, l_39_4 = l_39_2:Center, l_39_2
  l_39_3(l_39_4)
  l_39_3 = l_39_2.frame
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_39_5 = "���Ӽ��ܼ���"
  if l_39_0 then
    l_39_5 = "�޸ļ��ܼ���"
  end
  local l_39_6 = BoxLabel
  local l_39_7 = l_39_4
  local l_39_8 = "Label_Titile"
  local l_39_9 = l_39_5
  local l_39_10 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_39_11 = 0
  local l_39_12 = {}
  l_39_12.nW = 380
  l_39_12.nH = 25
  l_39_12.nHAlign = 1
  l_39_6(l_39_7, l_39_8, l_39_9, l_39_10, l_39_11, l_39_12)
  l_39_6 = BoxLabel
  l_39_7 = l_39_4
  l_39_8 = "Label_Name"
  l_39_9 = "�������֣�"
  l_39_11 = 45
  l_39_12 = 40
  l_39_6(l_39_7, l_39_8, l_39_9, l_39_10)
  l_39_10 = {l_39_11, l_39_12}
  l_39_6 = BoxEdit
  l_39_7 = l_39_3
  l_39_8 = "Edit_Name"
  l_39_6, l_39_9 = l_39_6(l_39_7, l_39_8, l_39_9), {w = 250, h = 27, x = 45, y = 70}
  if l_39_0 then
    l_39_7, l_39_8 = l_39_6:SetText, l_39_6
    l_39_9 = l_39_0
    l_39_7(l_39_8, l_39_9)
    l_39_7, l_39_8 = l_39_6:Enable, l_39_6
    l_39_9 = false
    l_39_7(l_39_8, l_39_9)
  end
  l_39_7 = BoxLabel
  l_39_8 = l_39_4
  l_39_9 = "Label_CD"
  l_39_10 = "����CD����λ���룩��"
  l_39_12 = 45
  l_39_7(l_39_8, l_39_9, l_39_10, l_39_11)
  l_39_11 = {l_39_12, 105}
  l_39_7 = BoxEdit
  l_39_8 = l_39_3
  l_39_9 = "Edit_SkillCD"
  l_39_7, l_39_10 = l_39_7(l_39_8, l_39_9, l_39_10), {w = 250, h = 27, x = 45, y = 135}
  l_39_8, l_39_9 = l_39_7:SetType, l_39_7
  l_39_10 = 0
  l_39_8(l_39_9, l_39_10)
  if l_39_0 then
    l_39_8 = SkillMonitor
    l_39_8 = l_39_8.Monitor
    l_39_8 = l_39_8[l_39_1]
    l_39_8 = l_39_8[l_39_0]
    l_39_9, l_39_10 = l_39_7:SetText, l_39_7
    l_39_11 = tostring
    l_39_12 = l_39_8
    l_39_12, l_39_11 = .end, l_39_11(l_39_12)
    l_39_9(l_39_10, l_39_11, l_39_12)
  end
  l_39_8 = BoxImage
  l_39_9 = l_39_4
  l_39_10 = "Image_RadioBoxsBg"
  l_39_11 = "ui\\Image\\uicommon\\commonpanel.uitex"
  l_39_12 = 48
  local l_39_13 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  local l_39_14 = {}
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  do
    local l_39_15 = {}
    l_39_8(l_39_9, l_39_10, l_39_11, l_39_12, l_39_13, l_39_14, l_39_15)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_39_8 = {l_39_9, l_39_10, l_39_11, l_39_12, l_39_13, l_39_14, l_39_15, 150, "����", "ؤ��"}
     -- DECOMPILER ERROR: Overwrote pending register.

    for l_39_13,l_39_14 in l_39_10 do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_39_13 % 3 == 2 then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_39_13 % 3 == 0 then
        local l_39_16 = math.ceil(l_39_13 / 3)
        local l_39_17 = BoxRadioBox
        local l_39_18 = l_39_3
        local l_39_19 = "RadioBox_" .. l_39_13
        local l_39_20 = {}
        l_39_20.x = l_39_15
        l_39_20.y = 155 + l_39_16 * 35
        l_39_20.txt = l_39_14
        l_39_20.group = "school"
        l_39_17 = l_39_17(l_39_18, l_39_19, l_39_20)
        l_39_18, l_39_19 = l_39_17:OnCheck, l_39_17
        l_39_20 = function()
        -- upvalues: l_39_9
        l_39_9 = this.szSchool
      end
        l_39_18(l_39_19, l_39_20)
        l_39_18 = l_39_17.hwnd
        l_39_18.szSchool = l_39_14
        if l_39_1 then
          if l_39_1 == l_39_14 then
            l_39_18, l_39_19 = l_39_17:Check, l_39_17
            l_39_20 = true
            l_39_18(l_39_19, l_39_20)
          end
          l_39_18, l_39_19 = l_39_17:Enable, l_39_17
          l_39_20 = false
          l_39_18(l_39_19, l_39_20)
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_39_0 then
        l_39_11(l_39_12, l_39_13, {w = 100, h = 30, x = 55, y = 325, txt = l_39_10}):OnClick(function()
      -- upvalues: l_39_6 , l_39_7 , l_39_9 , l_39_0
      local l_41_0 = l_39_6:GetText()
      l_41_0 = StringReplaceW(l_41_0, " ", "")
      local l_41_1 = tonumber(l_39_7:GetText())
      if l_41_0 == "" then
        MsgBox("�������Ʋ���Ϊ�ա�")
        return 
      end
      if l_39_9 == "" then
        MsgBox("��ѡ��������ְҵ��")
        return 
      end
      if not l_41_1 then
        MsgBox("����CDʱ�䲻��Ϊ�ա�")
        return 
      end
      if l_41_1 <= 0 then
        MsgBox("����CDʱ��������0��")
        return 
      end
      if not l_39_0 then
        if SkillMonitor.Monitor[l_39_9][l_41_0] then
          MsgBox("�벻Ҫ�ظ����ӡ�")
        else
          SkillMonitor.Monitor[l_39_9][l_41_0] = l_41_1
        end
      else
        SkillMonitor.Monitor[l_39_9][l_41_0] = l_41_1
      end
      if Station.Lookup("Normal/SkillMonitorManager") then
        SkillMonitorManager.UpdateList()
      end
      Wnd.CloseWindow("AddSkillMonitor")
    end)
         -- DECOMPILER ERROR: Overwrote pending register.

        BoxButton(l_39_3, "Btn_Close", l_39_15):OnClick(l_39_15)
        l_39_4:FormatAllItemPos()
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 141 180 
end

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  OpenAddSkillMonitor = l_0_19
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.


