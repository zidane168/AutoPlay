-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ie.lua 

BoxIE_Base = classEx()
BoxIE = {}
BoxIE_Base.OnFrameCreate = function()
  this:RegisterEvent("UI_SCALED")
  this.nOpenTime = GetTickCount()
  BoxIE.EnableDrage(this, true)
end

BoxIE_Base.OnEvent = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    if this.bMaxSize then
      local l_2_1, l_2_2, l_2_3, l_2_4, l_2_5 = Station.GetClientSize()
    end
    this:CorrectPos()
  end
end

BoxIE_Base.OnLButtonClick = function(l_3_0)
  local l_3_1 = this:GetName()
  if l_3_1 == "Btn_Close" then
    CloseBoxIE(this:GetRoot().nIndex)
  elseif l_3_1 == "Btn_GoBack" then
    this:GetParent():Lookup("WebPage_Page"):GoBack()
  elseif l_3_1 == "Btn_GoForward" then
    this:GetParent():Lookup("WebPage_Page"):GoForward()
  elseif l_3_1 == "Btn_Refresh" then
    this:GetParent():Lookup("WebPage_Page"):Refresh()
  elseif l_3_1 == "Btn_GoTo" then
    local l_3_2 = this:GetParent():Lookup("Edit_Input"):GetText()
  end
  if l_3_2 ~= "" then
    this:GetParent():Lookup("WebPage_Page"):Navigate(l_3_2)
  end
end

BoxIE_Base.OnHistoryChanged = function()
  this:GetParent():Lookup("Btn_GoBack"):Enable(this:CanGoBack())
  this:GetParent():Lookup("Btn_GoForward"):Enable(this:CanGoForward())
end

BoxIE_Base.OnTitleChanged = function()
  szName = this:GetLocationName()
  this:GetRoot():Lookup("", "Text_Title"):SetText(szName)
  local l_5_0 = this:GetLocationURL()
  local l_5_1 = this:GetParent():Lookup("Edit_Input")
  if l_5_0 ~= l_5_1.szAddr then
    l_5_1:SetText(l_5_0)
    l_5_1.szAddr = l_5_0
  end
end

BoxIE_Base.OnCheckBoxCheck = function(l_6_0)
  local l_6_1 = this:GetName()
  if l_6_1 == "CheckBox_MaxSize" then
    local l_6_2, l_6_3 = Station.GetClientSize()
    local l_6_4 = this:GetRoot()
    local l_6_5 = l_6_4:GetSize()
    l_6_4.hOrg = l_6_4
    l_6_4.wOrg = l_6_5
     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_4.yOrg = l_6_4
    l_6_4.xOrg = l_6_5
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_5(l_6_4, l_6_2, l_6_3)
     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_5(l_6_4, 0, 0)
    l_6_4.bMaxSize = true
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_5(l_6_4:Lookup("WebPage_Page"))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_5(l_6_4, false)
  end
end

BoxIE.EnableDrage = function(l_7_0, l_7_1)
  if l_7_1 then
    l_7_0:Lookup("Btn_DL"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DTL"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DT"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DTR"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DR"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DRB"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DB"):RegisterLButtonDrag()
    l_7_0:Lookup("Btn_DLB"):RegisterLButtonDrag()
  else
    l_7_0:Lookup("Btn_DL"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DTL"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DT"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DTR"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DR"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DRB"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DB"):UnregisterLButtonDrag()
    l_7_0:Lookup("Btn_DLB"):UnregisterLButtonDrag()
  end
end

BoxIE_Base.OnCheckBoxUncheck = function(l_8_0)
  local l_8_1 = this:GetName()
  if l_8_1 == "CheckBox_MaxSize" then
    local l_8_2, l_8_3 = Station.GetClientSize()
    local l_8_4 = this:GetRoot()
    if not l_8_4.wOrg then
      return 
    end
    if l_8_2 < l_8_4.wOrg then
      l_8_4.wOrg = l_8_2
    end
    if l_8_3 < l_8_4.hOrg then
      l_8_4.hOrg = l_8_3
    end
    BoxIE.Resize(l_8_4, l_8_4.wOrg, l_8_4.hOrg)
    if l_8_2 < l_8_4.xOrg + l_8_4.wOrg then
      l_8_4.xOrg = l_8_2 - l_8_4.wOrg
    end
    if l_8_3 < l_8_4.yOrg + l_8_4.hOrg then
      l_8_4.yOrg = l_8_3 - l_8_4.hOrg
    end
    l_8_4:SetRelPos(l_8_4.xOrg, l_8_4.yOrg)
    l_8_4:CorrectPos()
    l_8_4.bMaxSize = false
    Station.SetFocusWindow(l_8_4:Lookup("WebPage_Page"))
    BoxIE.EnableDrage(l_8_4, true)
  end
end

BoxIE_Base.OnEditSpecialKeyDown = function(l_9_0)
  local l_9_1 = GetKeyName(Station.GetMessageKey())
  if l_9_1 == "Enter" then
    local l_9_2 = this:GetText()
    if l_9_2 ~= "" then
      this:GetParent():Lookup("WebPage_Page"):Navigate(l_9_2)
    end
    return 1
  end
end

BoxIE_Base.OnItemLButtonDBClick = function()
  local l_10_0 = this:GetName()
  if l_10_0 == "Text_Title" then
    local l_10_1 = this:GetRoot()
    if l_10_1.bMaxSize then
      l_10_1:Lookup("CheckBox_MaxSize"):Check(false)
    end
  else
    l_10_1:Lookup("CheckBox_MaxSize"):Check(true)
  end
end

BoxIE_Base.OnDragButtonBegin = function()
  local l_11_0 = this
  local l_11_1 = this
  local l_11_2 = Station.GetMessagePos()
  l_11_1.fDragY = R3_PC5
  l_11_0.fDragX = l_11_2
  l_11_0 = this
  l_11_0.bOnDraging = true
  l_11_0 = this
  l_11_0, l_11_1 = l_11_0:GetRoot, l_11_0
  l_11_0 = l_11_0(l_11_1)
  l_11_1 = this
  l_11_2 = this
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_11_3 = R3_PC5
  l_11_2.fDragH = l_11_0
  l_11_1.fDragW = l_11_3
  l_11_1 = this
  l_11_2 = this
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_11_2.fDragFrameY = l_11_0
  l_11_1.fDragFrameX = l_11_3
end

BoxIE_Base.OnDragButton = function()
  BoxIE.OnDragButton()
end

BoxIE.OnDragButton = function()
  local l_13_0, l_13_1 = Station.GetMessagePos()
  local l_13_2, l_13_3 = Station.GetClientSize()
  if l_13_0 < 0 or l_13_1 < 0 or l_13_2 < l_13_0 or l_13_3 < l_13_1 then
    return 
  end
  local l_13_4 = this:GetRoot()
  local l_13_5 = this:GetName()
  local l_13_6, l_13_7 = l_13_4:GetRelPos()
  local l_13_8, l_13_9 = nil, nil
  if l_13_5 == "Btn_DL" then
    l_13_8 = this.fDragX - l_13_0
    BoxIE.Resize(l_13_4, this.fDragW + (l_13_8), this.fDragH)
  elseif l_13_5 == "Btn_DTL" then
    l_13_8 = this.fDragX - l_13_0
    l_13_9 = this.fDragY - l_13_1
    BoxIE.Resize(l_13_4, this.fDragW + (l_13_8), this.fDragH + (l_13_9))
  elseif l_13_5 == "Btn_DT" then
    l_13_9 = this.fDragY - l_13_1
    BoxIE.Resize(l_13_4, this.fDragW, this.fDragH + (l_13_9))
  elseif l_13_5 == "Btn_DTR" then
    l_13_9 = this.fDragY - l_13_1
    BoxIE.Resize(l_13_4, this.fDragW - this.fDragX + l_13_0, this.fDragH + (l_13_9))
  elseif l_13_5 == "Btn_DR" then
    BoxIE.Resize(l_13_4, this.fDragW - this.fDragX + l_13_0, this.fDragH)
  elseif l_13_5 == "Btn_DRB" then
    BoxIE.Resize(l_13_4, this.fDragW - this.fDragX + l_13_0, this.fDragH + l_13_1 - this.fDragY)
  elseif l_13_5 == "Btn_DB" then
    BoxIE.Resize(l_13_4, this.fDragW, this.fDragH + l_13_1 - this.fDragY)
  elseif l_13_5 == "Btn_DLB" then
    l_13_8 = this.fDragX - l_13_0
    BoxIE.Resize(l_13_4, this.fDragW + (l_13_8), this.fDragH + l_13_1 - this.fDragY)
  end
  if l_13_8 or l_13_9 then
    if l_13_8 then
      l_13_6 = this.fDragFrameX - (l_13_8)
    end
    if l_13_9 then
      l_13_7 = this.fDragFrameY - (l_13_9)
    end
    l_13_4:SetAbsPos(l_13_6, l_13_7)
  end
end

BoxIE.Resize = function(l_14_0, l_14_1, l_14_2)
  if l_14_1 < 400 then
    l_14_1 = 400
  end
  if l_14_2 < 200 then
    l_14_2 = 200
  end
  local l_14_3 = l_14_0:Lookup("", "")
  l_14_3:SetSize(l_14_1, l_14_2)
  l_14_3:Lookup("Image_Bg"):SetSize(l_14_1, l_14_2)
  l_14_3:Lookup("Image_BgT"):SetSize(l_14_1 - 6, 64)
  l_14_3:Lookup("Image_Edit"):SetSize(l_14_1 - 300, 25)
  l_14_3:Lookup("Text_Title"):SetSize(l_14_1 - 168, 30)
  l_14_3:FormatAllItemPos()
  local l_14_4 = l_14_0:Lookup("WebPage_Page")
  l_14_4:SetSize(l_14_1 - 12, l_14_2 - 76)
  l_14_0:Lookup("Edit_Input"):SetSize(l_14_1 - 306, 20)
  l_14_0:Lookup("Btn_GoTo"):SetRelPos(l_14_1 - 110, 38)
  l_14_0:Lookup("Btn_Close"):SetRelPos(l_14_1 - 40, 10)
  l_14_0:Lookup("CheckBox_MaxSize"):SetRelPos(l_14_1 - 70, 10)
  l_14_0:Lookup("Btn_DL"):SetSize(10, l_14_2 - 20)
  l_14_0:Lookup("Btn_DT"):SetSize(l_14_1 - 20, 10)
  l_14_0:Lookup("Btn_DTR"):SetRelPos(l_14_1 - 10, 0)
  l_14_0:Lookup("Btn_DR"):SetRelPos(l_14_1 - 10, 10)
  l_14_0:Lookup("Btn_DR"):SetSize(10, l_14_2 - 20)
  l_14_0:Lookup("Btn_DRB"):SetRelPos(l_14_1 - 10, l_14_2 - 10)
  l_14_0:Lookup("Btn_DB"):SetRelPos(10, l_14_2 - 10)
  l_14_0:Lookup("Btn_DB"):SetSize(l_14_1 - 20, 10)
  l_14_0:Lookup("Btn_DLB"):SetRelPos(0, l_14_2 - 10)
  l_14_0:SetSize(l_14_1, l_14_2)
  l_14_0:SetDragArea(0, 0, l_14_1, 30)
end

BoxIE_Base.OnDragButtonEnd = function()
  local l_15_0, l_15_1 = Station.GetMessagePos()
  local l_15_2 = this:GetRoot()
  l_15_2.bOnDraging = false
  BoxIE.OnDragButton()
  this.bOnDraging = false
  if not this.bMouseOver then
    local l_15_3 = this:GetName()
  if l_15_3 == "Btn_DragTop" then
    end
    if l_15_3 == "Btn_DragTop" then
      Cursor.Switch(CURSOR.NORMAL)
    end
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_15_3 == "Btn_DragTopRight" and Cursor.GetCurrentIndex() == CURSOR.RIGHTTOP_LEFTBOTTOM then
    Cursor.Switch(CURSOR.NORMAL)
  end
  do return end
  if l_15_3 == "Btn_DragRight" and Cursor.GetCurrentIndex() == CURSOR.LEFT_RIGHT then
    Cursor.Switch(CURSOR.NORMAL)
  end
end

BoxIE_Base.OnFrameDragEnd = function()
  this:CorrectPos()
end

BoxIE_Base.OnMouseLeave = function()
  local l_17_0 = this:GetName()
  if (l_17_0 == "Btn_DT" or l_17_0 == "Btn_DB") and not this.bOnDraging and Cursor.GetCurrentIndex() == CURSOR.TOP_BOTTOM then
    Cursor.Switch(CURSOR.NORMAL)
  end
  do return end
  if (l_17_0 == "Btn_DTR" or l_17_0 == "Btn_DLB") and not this.bOnDraging and Cursor.GetCurrentIndex() == CURSOR.RIGHTTOP_LEFTBOTTOM then
    Cursor.Switch(CURSOR.NORMAL)
  end
  do return end
  if (l_17_0 == "Btn_DTL" or l_17_0 == "Btn_DRB") and not this.bOnDraging and Cursor.GetCurrentIndex() == CURSOR.LEFTTOP_RIGHTBOTTOM then
    Cursor.Switch(CURSOR.NORMAL)
  end
  do return end
  if (l_17_0 == "Btn_DL" or l_17_0 == "Btn_DR") and not this.bOnDraging and Cursor.GetCurrentIndex() == CURSOR.LEFT_RIGHT then
    Cursor.Switch(CURSOR.NORMAL)
  end
end

BoxIE_Base.OnMouseEnter = function()
  local l_18_0 = this:GetRoot()
  if l_18_0.bMaxSize then
    return 
  end
  local l_18_1 = this:GetName()
  if (l_18_1 == "Btn_DT" or l_18_1 == "Btn_DB") and (not IsCursorInExclusiveMode or not IsCursorInExclusiveMode()) then
    Cursor.Switch(CURSOR.TOP_BOTTOM)
  end
  do return end
  if (l_18_1 == "Btn_DTR" or l_18_1 == "Btn_DLB") and (not IsCursorInExclusiveMode or not IsCursorInExclusiveMode()) then
    Cursor.Switch(CURSOR.RIGHTTOP_LEFTBOTTOM)
  end
  do return end
  if (l_18_1 == "Btn_DTL" or l_18_1 == "Btn_DRB") and (not IsCursorInExclusiveMode or not IsCursorInExclusiveMode()) then
    Cursor.Switch(CURSOR.LEFTTOP_RIGHTBOTTOM)
  end
  do return end
  if (l_18_1 == "Btn_DL" or l_18_1 == "Btn_DR") and (not IsCursorInExclusiveMode or not IsCursorInExclusiveMode()) then
    Cursor.Switch(CURSOR.LEFT_RIGHT)
  end
end

BoxIE_Base.OnFrameHide = function()
end

BoxIE_GetNewIEFramePos = function()
  local l_20_0 = 0
  local l_20_1 = nil
  for l_20_5 = 1, 10 do
    local l_20_6 = Station.Lookup("Topmost/BoxIE" .. l_20_5)
    if l_20_6 and l_20_6:IsVisible() and l_20_0 < l_20_6.nOpenTime then
      l_20_0 = l_20_6.nOpenTime
      l_20_1 = l_20_5
    end
  end
  if l_20_1 then
    local l_20_7 = Station.Lookup("Topmost/BoxIE" .. l_20_1)
    x = l_20_7:GetAbsPos()
  end
  if x + 890 <= Station.GetClientSize() and y + 630 <= l_20_7 then
    return x + 30, y + 30
  end
  return 40, 40
end

OpenBoxIE = function(l_21_0, l_21_1)
  local l_21_2, l_21_3 = nil, nil
  for i = 1, 10 do
    if not IsBoxIEOpened(i) then
      l_21_2 = i
      do break end
    elseif not l_21_3 then
      l_21_3 = i
    end
  end
  if not l_21_2 then
    OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.MSG_OPEN_TOO_MANY)
    return nil
  end
  local l_21_6, l_21_7 = BoxIE_GetNewIEFramePos()
  local l_21_8 = Wnd.OpenWindow("Interface\\Moon_Lib\\ie.ini", "BoxIE" .. l_21_2)
  l_21_8.bBoxIE = true
  l_21_8.nIndex = l_21_2
  l_21_8:BringToTop()
  if l_21_3 then
    l_21_8:SetAbsPos(l_21_6, l_21_7)
    l_21_8:CorrectPos()
    l_21_8.x = l_21_6
    l_21_8.y = l_21_7
  else
    l_21_8:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
    local l_21_9 = l_21_8:GetAbsPos()
    l_21_8.y = l_21_8
    l_21_8.x = l_21_9
  end
  local l_21_10 = l_21_8:Lookup("WebPage_Page")
  if l_21_0 then
    l_21_10:Navigate(l_21_0)
  end
  Station.SetFocusWindow(l_21_10)
  if not l_21_1 then
    PlaySound(SOUND.UI_SOUND, g_sound.OpenFrame)
  end
  return l_21_10
end

CloseLastBoxIE = function()
  local l_22_0 = nil
  if Station.Lookup("Topmost"):GetFirstChild() then
    if Station.Lookup("Topmost"):GetFirstChild().bBoxIE then
      l_22_0 = Station.Lookup("Topmost"):GetFirstChild()
    end
  end
end
if l_22_0 then
  Wnd.CloseWindow(l_22_0:GetName())
  return true
end
return false
 -- WARNING: undefined locals caused missing assignments!
end

CloseBoxIE = function(l_23_0, l_23_1)
  if not IsBoxIEOpened(l_23_0) then
    return 
  end
  Wnd.CloseWindow("BoxIE" .. l_23_0)
  if not l_23_1 then
    PlaySound(SOUND.UI_SOUND, g_sound.CloseFrame)
  end
end

IsBoxIEOpened = function(l_24_0)
  local l_24_1 = Station.Lookup("Topmost/BoxIE" .. l_24_0)
  if l_24_1 and l_24_1:IsVisible() then
    return true
  end
  return false
end

GetBoxIEIndex = function(l_25_0)
  if not l_25_0 then
    return 
  end
  local l_25_1 = nil
  local l_25_2 = Station.Lookup("Topmost"):GetFirstChild()
  if l_25_2 then
    if l_25_2.bBoxIE then
      local l_25_3 = l_25_2:Lookup("WebPage_Page")
    end
    if l_25_0 == l_25_3:GetLocationURL() then
      l_25_1 = l_25_2.nIndex
    end
    do break end
  end
  l_25_2 = l_25_2:GetNext()
end
return l_25_1
end

GetBoxIEIndexFromTitle = function(l_26_0)
  if not l_26_0 or l_26_0 == "" then
    return 
  end
  local l_26_1 = nil
  local l_26_2 = Station.Lookup("Topmost"):GetFirstChild()
  if l_26_2 then
    if l_26_2.bBoxIE then
      local l_26_3 = l_26_2:Lookup("WebPage_Page")
      local l_26_4 = l_26_3:GetLocationName()
    end
    if string.find(l_26_4, l_26_0) then
      l_26_1 = l_26_2.nIndex
    end
    do break end
  end
  l_26_2 = l_26_2:GetNext()
end
return l_26_1
end


