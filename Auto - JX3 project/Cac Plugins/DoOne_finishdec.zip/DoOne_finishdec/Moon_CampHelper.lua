-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Moon_CampHelper.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = -344
l_0_1.y = -216
l_0_0.Anchor = l_0_1
l_0_0.bShowTrace = true
l_0_0.bOn = false
l_0_0.bLock = false
l_0_0.fBgAlpha = 185
local l_0_2 = {}
l_0_2.live = 0
l_0_2.dead = 0
l_0_2.cout = 0
l_0_2.title = "��"
local l_0_3 = {}
l_0_3.live = 0
l_0_3.dead = 0
l_0_3.cout = 0
l_0_3.title = "��"
l_0_0.tCamp, l_0_1 = l_0_1, {l_0_2, l_0_3}
l_0_0.bDeathMini = true
l_0_0.bRedName = false
l_0_0.bRedNameMini = false
l_0_0.bBattlefieldMark = true
l_0_0.bCalcArenaAward = true
l_0_0.bEntryArena = false
l_0_0.bEntryBattlefield = false
Moon_CampHelper = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bEntryArena"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bEntryBattlefield"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bCalcArenaAward"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bBattlefieldMark"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.Anchor"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bShowTrace"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bLock"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.fBgAlpha"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bDeathMini"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bRedName"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "Moon_CampHelper.bRedNameMini"
l_0_0(l_0_1)
l_0_0 = Moon_CampHelper
l_0_1 = function()
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  Moon_CampHelper.frame = this
  Moon_CampHelper.handleTotal = this:Lookup("", "")
  Moon_CampHelper.handleInfo = this:Lookup("", "Handle_Info")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = Moon_CampHelper
l_0_1 = function(l_2_0)
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if l_2_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    if Moon_CampHelper.bOn then
      this:Show()
    else
      this:Hide()
    end
    Moon_CampHelper.UpdateAnchor(this)
    this:EnableDrag(not Moon_CampHelper.bLock)
    this:Lookup("CheckBox_Minimize"):Check(Moon_CampHelper.bShowTrace)
    Moon_CampHelper.UpdateBgSize(Moon_CampHelper.bShowTrace)
    Moon_CampHelper.handleTotal:Lookup("Image_Bg"):SetAlpha(Moon_CampHelper.fBgAlpha)
    Moon_CampHelper.handleTotal:Lookup("Image_Title"):SetAlpha(Moon_CampHelper.fBgAlpha)
  end
  do return end
  if l_2_0 == "UI_SCALED" then
    Moon_CampHelper.UpdateAnchor(this)
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = Moon_CampHelper
l_0_1 = function()
  Moon_CampHelper.tCamp[1].live = 0
  Moon_CampHelper.tCamp[1].dead = 0
  Moon_CampHelper.tCamp[1].cout = 0
  Moon_CampHelper.tCamp[2].live = 0
  Moon_CampHelper.tCamp[2].dead = 0
  Moon_CampHelper.tCamp[2].cout = 0
  local l_3_0 = GetAllPlayer()
  for l_3_4,l_3_5 in pairs(l_3_0) do
    local l_3_6 = l_3_5.nCamp
    if l_3_6 ~= 0 then
      if l_3_5.nMoveState == MOVE_STATE.ON_DEATH then
        Moon_CampHelper.tCamp[l_3_6].dead = Moon_CampHelper.tCamp[l_3_6].dead + 1
      else
        Moon_CampHelper.tCamp[l_3_6].live = Moon_CampHelper.tCamp[l_3_6].live + 1
      end
      Moon_CampHelper.tCamp[l_3_6].cout = Moon_CampHelper.tCamp[l_3_6].cout + 1
    end
  end
end

l_0_0.GetAllCamp = l_0_1
l_0_0 = Moon_CampHelper
l_0_1 = function()
  local l_4_0 = GetClientPlayer()
  if not l_4_0 then
    return 
  end
  if not Moon_CampHelper.bShowTrace then
    return 
  end
  if GetLogicFrameCount() % 4 ~= 0 then
    return 
  end
  Moon_CampHelper.GetAllCamp()
  local l_4_1 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if 167 ~= 0 then
    for l_4_5 = 1, 167 do
      if l_4_0.nCamp ~= l_4_5 then
        l_4_1[l_4_5] = 159
      end
    end
  end
  local l_4_6 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_4_10 = Moon_CampHelper.handleInfo:Lookup("Text_CampGood"), Moon_CampHelper.handleInfo:Lookup("Text_CampBad"), .end do
    local l_4_11 = Moon_CampHelper.tCamp[l_4_10]
    local l_4_12 = string.format("%s����(%d)  ��(%d)  ��(%d)", l_4_11.title, l_4_11.live, l_4_11.dead, l_4_11.cout)
    l_4_6[l_4_10]:SetText(l_4_12)
    l_4_6[l_4_10]:SetFontScheme(l_4_1[l_4_10])
  end
end

l_0_0.OnFrameBreathe = l_0_1
l_0_1 = Moon_CampHelper
l_0_2 = function()
  -- upvalues: l_0_0
  local l_5_0, l_5_1 = GetClientPlayer()
  local l_5_2 = l_5_0.GetKungfuMount()
  local l_5_3 = false
  if l_5_2 then
    local l_5_4 = table.hasVal
    do
      local l_5_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

    end
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_5_4 then
    for l_5_9,l_5_10 in l_5_4(GetAllNpc()) do
      if l_0_0[l_5_10.szName] and l_0_0[l_5_1.szName] < 2 then
        do break end
      end
    end
    if l_5_1 then
      if l_5_3 and IsEnemy(l_5_0.dwID, l_5_1.dwID) then
        SetTarget(l_5_1.GetTarget())
        Msg("[��Ӫ����]ѡ�� BOSS [" .. l_5_1.szName .. "]��Ŀ�ꡣ")
      end
    else
      SetTarget(TARGET.NPC, l_5_1.dwID)
      Msg("[��Ӫ����]ѡ�� BOSS [" .. l_5_1.szName .. "]��")
    end
     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 20 
end

l_0_1.SelectBoss = l_0_2
l_0_1 = Moon_CampHelper
l_0_2 = function()
  local l_6_0 = PLAYER_TALK_CHANNEL.NEARBY
  local l_6_1 = GetClientPlayer()
  Moon_CampHelper.GetAllCamp()
  for l_6_5 = 1, 2 do
    local l_6_6 = Moon_CampHelper.tCamp[l_6_5]
    local l_6_7 = "����"
    if l_6_6.title == "��" then
      l_6_7 = "����"
    end
    local l_6_8 = l_6_1.Talk
    local l_6_9 = l_6_0
    local l_6_10 = ""
    local l_6_11 = {}
    local l_6_12 = {}
    l_6_12.type = "text"
    l_6_12.text = string.format("%s����(%d) ��(%d) ��(%d)", l_6_7, l_6_6.live, l_6_6.dead, l_6_6.cout)
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_6_8(l_6_9, l_6_10, l_6_11)
  end
end

l_0_1.Talk = l_0_2
l_0_1 = 0
l_0_2 = Moon_CampHelper
l_0_3 = function()
  -- upvalues: l_0_1
  local l_7_0 = this:GetName()
  if l_7_0 == "Btn_Setting" then
    local l_7_1 = Moon_CampHelper.handleTotal:Lookup("Image_Bg")
    do
      local l_7_2 = Moon_CampHelper.handleTotal:Lookup("Image_Title")
      local l_7_3 = {}
      local l_7_4 = {}
      l_7_4.szOption = "�������λ��"
      l_7_4.bCheck = true
      l_7_4.bChecked = Moon_CampHelper.bLock
      l_7_4.fnAction = function(l_8_0, l_8_1)
        Moon_CampHelper.bLock = l_8_1
        Moon_CampHelper.frame:EnableDrag(not l_8_1)
      end
      local l_7_5 = {}
      l_7_5.szOption = g_tStrings.QUEST_TRACE_BG_ALPHA_CHANGE
      l_7_5.UserData = l_7_1:GetAlpha()
      l_7_5.fnAction = function(l_9_0)
        -- upvalues: l_7_1 , l_7_2
        local l_9_1, l_9_2 = Cursor.GetPos()
        local l_9_3 = GetUserPercentage
        local l_9_5 = function(l_10_0)
          -- upvalues: l_7_1 , l_7_2
          Moon_CampHelper.fBgAlpha = (1 - l_10_0) * 255
          l_7_1:SetAlpha(Moon_CampHelper.fBgAlpha)
          l_7_2:SetAlpha(Moon_CampHelper.fBgAlpha)
        end
        local l_9_6 = nil
        local l_9_7 = 1 - l_9_0 / 255
        do
          local l_9_8 = g_tStrings.WINDOW_ADJUST_BG_ALPHA
          l_9_3(l_9_5, l_9_6, l_9_7, l_9_8, {l_9_1, l_9_2, l_9_1 + 1, l_9_2 + 1})
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_7_4 = PopupMenu
      l_7_5 = l_7_3
      l_7_4(l_7_5)
    end
  elseif l_7_0 == "Btn_Say" then
    local l_7_6 = GetTime()
    if l_7_6 - l_0_1 > 3000 then
      l_0_1 = l_7_6
      Moon_CampHelper.Talk()
    end
  elseif l_7_0 == "Btn_Boss" then
    Moon_CampHelper.SelectBoss()
  end
end

l_0_2.OnLButtonClick = l_0_3
l_0_2 = Moon_CampHelper
l_0_3 = function(l_8_0)
  if l_8_0 then
    Moon_CampHelper.handleInfo:Show()
    Moon_CampHelper.handleTotal:Lookup("Image_Bg"):SetSize(200, 100)
  else
    Moon_CampHelper.handleInfo:Hide()
    Moon_CampHelper.handleTotal:Lookup("Image_Bg"):SetSize(200, 32)
  end
end

l_0_2.UpdateBgSize = l_0_3
l_0_2 = Moon_CampHelper
l_0_3 = function()
  local l_9_0 = this:GetName()
  if l_9_0 == "CheckBox_Minimize" then
    Moon_CampHelper.bShowTrace = true
    Moon_CampHelper.UpdateBgSize(true)
  end
end

l_0_2.OnCheckBoxCheck = l_0_3
l_0_2 = Moon_CampHelper
l_0_3 = function()
  local l_10_0 = this:GetName()
  if l_10_0 == "CheckBox_Minimize" then
    Moon_CampHelper.bShowTrace = false
    Moon_CampHelper.UpdateBgSize(false)
  end
end

l_0_2.OnCheckBoxUncheck = l_0_3
l_0_2 = Moon_CampHelper
l_0_3 = function(l_11_0)
  l_11_0:SetPoint(Moon_CampHelper.Anchor.s, 0, 0, Moon_CampHelper.Anchor.r, Moon_CampHelper.Anchor.x, Moon_CampHelper.Anchor.y)
  l_11_0:CorrectPos()
end

l_0_2.UpdateAnchor = l_0_3
l_0_2 = Moon_CampHelper
l_0_3 = function()
  this:CorrectPos()
  Moon_CampHelper.Anchor = GetFrameAnchor(this)
end

l_0_2.OnFrameDragEnd = l_0_3
l_0_2 = Wnd
l_0_2 = l_0_2.OpenWindow
l_0_3 = "Interface\\Moon_CampHelper\\Moon_CampHelper.ini"
l_0_2(l_0_3, "Moon_CampHelper")
l_0_2 = function(l_13_0, l_13_1)
  for l_13_5,l_13_6 in ipairs(l_13_1) do
    local l_13_7 = BoxLabel
    local l_13_8 = l_13_0
    local l_13_9 = "Text_Mark" .. l_13_5
    local l_13_10 = l_13_6.szName
    local l_13_11 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    l_13_8(l_13_9, l_13_10)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_3 = function()
  -- upvalues: l_0_2
  local l_14_0 = Station.Lookup("Topmost1/MiddleMap")
  local l_14_1 = MiddleMap.dwMapID
  local l_14_2 = l_14_0:Lookup("", "Handle_Map")
  local l_14_3 = l_14_2:Lookup("Handle_DirectionMark")
  if not l_14_3 and Moon_CampHelper.bBattlefieldMark then
    local l_14_4 = table.hasVal
    local l_14_5 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_4 then
    local l_14_6 = BoxHandle
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_14_7 = 48
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_14_8 = 135
    local l_14_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_14_10 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_6(l_14_7)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_3 then
    l_14_4(l_14_5)
    if Moon_CampHelper.bBattlefieldMark then
      if l_14_1 == 48 then
        local l_14_11 = l_0_2
        local l_14_12 = l_14_3
        local l_14_13 = {}
        local l_14_14 = {}
        local l_14_15 = {}
        local l_14_16 = {}
        local l_14_17 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_14_11(l_14_12, l_14_13)
      end
    elseif l_14_1 == 50 then
      local l_14_18 = l_0_2
      local l_14_19 = l_14_3
      local l_14_20 = {}
      local l_14_21 = {}
      local l_14_22 = {}
      local l_14_23 = {}
      local l_14_24 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_14_18(l_14_19, l_14_20)
    elseif l_14_1 == 135 then
      local l_14_25 = l_0_2
      local l_14_26 = l_14_3
      local l_14_27 = {}
      local l_14_28 = {}
      local l_14_29 = {}
      local l_14_30 = {}
      local l_14_31 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_14_25(l_14_26, l_14_27)
    end
    l_14_3:FormatAllItemPos()
  end
   -- WARNING: undefined locals caused missing assignments!
end

BattleFieldDirection = l_0_3
l_0_3 = RegisterEvent
l_0_3("OnMiddleMapUpdateCurrentMap", function()
  BattleFieldDirection()
end
)
l_0_3 = RegisterEvent
l_0_3("OnMiddleMapShowMap", function()
  BattleFieldDirection()
end
)
l_0_3 = 0
local l_0_4 = 0
RegisterEvent("Breathe", function()
  -- upvalues: l_0_4 , l_0_3
  local l_17_0 = GetClientPlayer()
  if not l_17_0 then
    return 
  end
  if l_0_4 == 0 then
    local l_17_1 = 0
    if not GetAllPlayer() then
      local l_17_2, l_17_3 = {}
    end
    local l_17_4 = nil
    for l_17_8,l_17_9 in pairs(l_17_4) do
      local l_17_5 = Station.Lookup("Topmost/Minimap/Wnd_Minimap/Minimap_Map")
       -- DECOMPILER ERROR: Confused about usage of registers!

      if IsEnemy(l_17_0.dwID, R8_PC24.dwID) then
        l_17_1 = l_17_1 + 1
      end
      if (Moon_CampHelper.bDeathMini and R8_PC24.nMoveState ~= MOVE_STATE.ON_DEATH) or not Moon_CampHelper.bDeathMini then
        local l_17_11 = Scene_PlaneGameWorldPosToScene(R8_PC24.nX, R8_PC24.nY)
        l_17_5:UpdataArrowPoint(8, l_17_10.dwID, 199, 48, l_17_11, R18_PC58, 16)
      end
    end
    if Moon_CampHelper.bRedName then
      if l_0_3 == 0 and l_17_1 > 0 then
        OutputMessage("MSG_ANNOUNCE_RED", "** ���ֺ��� **")
      end
    end
    if l_0_3 > 0 and l_17_1 == 0 then
      OutputMessage("MSG_ANNOUNCE_YELLOW", "** �����뿪 **")
    end
    l_0_3 = l_17_1
    l_0_4 = 12
  end
  if l_0_4 > 0 then
    l_0_4 = l_0_4 - 1
  end
end
)
local l_0_5 = {}
local l_0_6 = {}
local l_0_7 = 0
local l_0_8 = ""
RegisterEvent("SYNC_CORPS_LIST", function()
  -- upvalues: l_0_9
  if Moon_CampHelper.bCalcArenaAward then
    l_0_9()
  end
end
)
RegisterEvent("SYNC_CORPS_BASE_DATA", function()
  -- upvalues: l_0_11
  if Moon_CampHelper.bCalcArenaAward then
    l_0_11()
  end
end
)
RegisterEvent("SYNC_CORPS_MEMBER_DATA", function()
  -- upvalues: l_0_11
  if Moon_CampHelper.bCalcArenaAward then
    l_0_11()
  end
end
)
RegisterEvent("Breathe", function()
  if GetLogicFrameCount() % 8 ~= 0 then
    return 
  end
  local l_26_0 = Station.Lookup("Normal/ArenaCorpsPanel")
  if not l_26_0 or l_26_0.bInit then
    return 
  end
  local l_26_1 = l_26_0:Lookup("", "")
  local l_26_2 = l_26_1:Lookup("Text_Title")
  if l_26_2:GetText() ~= "�������" then
    return 
  end
  local l_26_3 = l_26_0:Lookup("Wnd_Arena")
  local l_26_4 = l_26_3:Lookup("Btn_Add")
  l_26_4:SetSize(85, 30)
  l_26_4:Lookup("", ""):SetSize(85, 30)
  l_26_4:Lookup("", "Text_Add "):SetSize(85, 30)
  if l_26_3:Lookup("Btn_Calc") then
    return 
  end
  l_26_0.bInit = true
  local l_26_5 = BoxButton
  local l_26_6 = l_26_3
  local l_26_7 = "Btn_Calc"
  local l_26_8 = {}
  l_26_8.txt = "�����Ҽ�����"
  l_26_8.x = 85
  l_26_8.y = 312
  l_26_8.w = 110
  l_26_8.h = 30
  l_26_5 = l_26_5(l_26_6, l_26_7, l_26_8)
  l_26_5, l_26_6 = l_26_5:OnClick, l_26_5
  l_26_7 = OpenArenaAwardCalc
  l_26_5(l_26_6, l_26_7)
end
)
local l_0_12 = function()
  -- upvalues: l_0_5 , l_0_6 , l_0_7 , l_0_8
  local l_18_0 = arg0
  l_0_6 = {}
  l_0_5 = {}
  local l_18_1 = GetPlayer(l_18_0)
  if l_18_1 then
    for l_18_5 = 0, 2 do
      local l_18_6 = GetCorpsID(l_18_5, l_18_0)
      if l_18_6 ~= 0 then
        l_0_5[l_18_5] = l_18_6
      else
        local l_18_7 = l_0_6
        local l_18_8 = {}
        l_18_8.dwWeekTotalCount = 0
        l_18_8.nTeamCorpsLevel = 0
        l_18_8.dwPersonTotalCount = 0
        l_18_8.nPersonCorpsLevel = 0
        l_18_7[l_18_5] = l_18_8
      end
    end
    l_0_7 = l_18_0
    l_0_8 = string.gsub(l_18_1.szName, "@.*$", "")
  end
end

RegisterEvent("BATTLE_FIELD_NOTIFY", function()
  -- upvalues: l_0_13
  if Moon_CampHelper.bEntryBattlefield and arg0 == 2 then
    if DoAcceptJoinBattleField then
      DoAcceptJoinBattleField(arg5, arg3, arg4, arg6, arg7)
    end
  else
    l_0_13("BattleField_Enter_" .. arg3)
  end
end
)
RegisterEvent("ARENA_NOTIFY", function()
  -- upvalues: l_0_13
  if Moon_CampHelper.bEntryArena and arg0 == 2 then
    if DoAcceptJoinArena then
      DoAcceptJoinArena(arg1, arg7, arg5, arg6, arg8, arg9, arg2)
    end
  else
    l_0_13("Arena_Enter_" .. arg1)
  end
end
)
local l_0_14 = function()
  -- upvalues: l_0_6
  local l_19_0 = -1000
  local l_19_1 = false
  for l_19_5 = 0, 2 do
    local l_19_15, l_19_16 = nil
    l_19_15 = l_0_6
    l_19_15 = l_19_15[l_19_5]
    l_19_15 = l_19_15.dwWeekTotalCount
    local l_19_6, l_19_17 = nil
    l_19_16 = l_0_6
    l_19_16 = l_19_16[l_19_5]
    l_19_16 = l_19_16.dwPersonTotalCount
    local l_19_7, l_19_18 = nil
    l_19_6 = l_0_6
    l_19_6 = l_19_6[l_19_5]
    l_19_6 = l_19_6.nTeamCorpsLevel
    local l_19_8, l_19_19 = nil
    l_19_17 = l_0_6
    l_19_17 = l_19_17[l_19_5]
    l_19_17 = l_19_17.nPersonCorpsLevel
    local l_19_9, l_19_20 = nil
    if l_19_15 >= 10 then
      l_19_7 = l_19_16 / l_19_15
    end
    if l_19_7 >= 0.3 then
      l_19_7 = l_19_17
      local l_19_10, l_19_21 = nil
      l_19_18 = l_19_6 - l_19_17
      if l_19_18 <= 200 then
        l_19_7 = l_19_6
      end
      l_19_18 = 0
      local l_19_11, l_19_22 = nil
      if l_19_5 == 0 then
        l_19_18 = 0.8
      elseif l_19_5 == 1 then
        l_19_18 = 0.9
      else
        l_19_18 = 1
      end
      l_19_8 = 0
      local l_19_12, l_19_23 = nil
      if l_19_7 < 800 then
        l_19_19 = l_19_18 * 4
        l_19_9 = 650 * l_19_7
        l_19_9 = l_19_9 + 2337500
        l_19_19 = l_19_19 * (l_19_9)
        l_19_8 = l_19_19 / 10000
      elseif l_19_7 < 3100 then
        l_19_19 = l_19_18 * 4
        l_19_9 = l_19_7 - 1900
        l_19_9 = 1238400 * (l_19_9)
        l_19_20 = l_19_7 - 1900
        l_19_20 = l_19_20 ^ 2
        l_19_20 = l_19_20 + 1440000
        local l_19_26 = nil
        l_19_9 = l_19_9 / (l_19_20)
        l_19_9 = l_19_9 + 800
        l_19_8 = l_19_19 * (l_19_9)
      else
        l_19_19 = l_19_18 * 4
        l_19_9 = 195 * l_19_7
        l_19_9 = l_19_9 + 12555500
        local l_19_25 = nil
        l_19_19 = l_19_19 * (l_19_9)
        local l_19_24 = nil
        l_19_8 = l_19_19 / 10000
      end
      if l_19_0 < l_19_8 then
        l_19_0 = l_19_8
        l_19_1 = true
      end
    elseif not l_19_1 then
      l_19_0 = 0
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  local l_19_13 = math.floor
  local l_19_14 = l_19_0
  return l_19_13(l_19_14)
end

do
  RegisterEvent("Breathe", function()
  -- upvalues: l_0_15
  if GetLogicFrameCount() % 8 == 0 then
    l_0_15()
  end
end
)
  RegisterEvent("UPDATE_CAMP_INFO", function()
  -- upvalues: l_0_15
  l_0_15()
end
)
  RegisterMoonButton("CampHelper", 2131, "��Ӫ����", "General", Moon_CampHelper.Create)
  RegisterTraceButtonMenu("camppeople", function()
  local l_36_0 = {}
  l_36_0.szOption = "��Ӫ�������"
  l_36_0.bCheck = true
  l_36_0.bChecked = Moon_CampHelper.bOn
  l_36_0.fnAction = function()
    if Moon_CampHelper.bOn then
      Moon_CampHelper.bOn = false
      Moon_CampHelper.frame:Hide()
    else
      Moon_CampHelper.bOn = true
      Moon_CampHelper.frame:Show()
    end
  end
  do
    local l_36_1 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_36_1
  end
   -- WARNING: undefined locals caused missing assignments!
end
)
  Hotkey.AddBinding("Camp_Boss", "ѡ�й���Boss", "��Ӫ����", function()
  Moon_CampHelper.SelectBoss()
end
, nil)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

