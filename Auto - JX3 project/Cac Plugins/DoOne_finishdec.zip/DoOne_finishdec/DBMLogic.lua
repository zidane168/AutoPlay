-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DBMLogic.lua 

local l_0_0 = {}
l_0_0.currMap = ""
l_0_0.BuffTime = {}
l_0_0.WatchNpc = {}
DBMLogic = l_0_0
l_0_0 = DBMLogic
l_0_0.LoadEvent = function()
  RegisterEvent("SYS_MSG", DBMLogic.Event)
  RegisterEvent("NPC_ENTER_SCENE", DBMLogic.Event)
  RegisterEvent("NPC_LEAVE_SCENE", DBMLogic.Event)
  RegisterEvent("PLAYER_SAY", DBMLogic.Event)
  RegisterEvent("BUFF_UPDATE", DBMLogic.Event)
  RegisterEvent("DO_SKILL_CAST", DBMLogic.Event)
  RegisterEvent("RENDER_FRAME_UPDATE", DBMLogic.Event)
  RegisterEvent("SYNC_ROLE_DATA_END", DBMLogic.Event)
end

l_0_0 = DBMLogic
l_0_0.GetCurrMod = function()
  local l_2_0 = DBMLogic.currMap
  if not DBMPanel.ModData[l_2_0] then
    return false
  end
  return DBMPanel.ModData[l_2_0]
end

l_0_0 = DBMLogic
l_0_0.IsNpcExistByName = function(l_3_0)
  local l_3_1 = false
  local l_3_2 = GetNpcList()
  for l_3_6,l_3_7 in ipairs(l_3_2) do
    do
      local l_3_8 = GetNpc(l_3_7)
      if l_3_8 and l_3_8.szName == l_3_0 then
        l_3_1 = true
      end
      do break end
    end
  end
  return l_3_1
end

l_0_0 = DBMLogic
l_0_0.RollCall = function(l_4_0, l_4_1)
  if not DBMPanel_Set.bBossRollCall or not DBMPanel_Set.bOn then
    return 
  end
  local l_4_2 = GetClientPlayer()
  if not l_4_2.bFightState then
    return 
  end
  if IsPlayer(l_4_1) or not IsEnemy(l_4_1, l_4_2.dwID) then
    return 
  end
  local l_4_3, l_4_4 = GetMapParams(l_4_2.GetMapID())
  if l_4_4 ~= 1 then
    return 
  end
  if StringFindW(l_4_0, l_4_2.szName) then
    local l_4_5 = GetNpc(l_4_1)
    if not l_4_5 or GetNpcIntensity(l_4_5) ~= 4 then
      return 
    end
    CreateDBMAlarm(2, true, DBMPanel_Set.szRollCallColor)
  end
  if DBMPanel_Set.bMsgAlarm then
    OutputWarningMessage("MSG_NOTICE_YELLOW", "[" .. l_4_5.szName .. "]�������ˣ���", 3)
  end
end

l_0_0 = DBMLogic
l_0_0.OnSkillCast = function(l_5_0, l_5_1, l_5_2, l_5_3)
  if not DBMPanel_Set.bOn or IsPlayer(l_5_0) then
    return 
  end
  local l_5_4 = DBMLogic.GetCurrMod()
  if not l_5_4 or not l_5_4.bOn then
    return 
  end
  local l_5_5 = GetNpc(l_5_0)
  local l_5_6 = l_5_4.bossData[l_5_5.szName]
  if not l_5_5 or not l_5_6 or not l_5_6.bOn then
    return 
  end
  local l_5_7, l_5_8 = l_5_5.GetTarget()
  local l_5_9 = Table_GetSkillName(l_5_1, l_5_2)
  for l_5_13,l_5_14 in ipairs(l_5_6.Skill) do
    if ((l_5_3 and l_5_14.type == 2) or l_5_3 or l_5_14.type == 1) and ((l_5_14.nTarget == 1 and l_5_8 == GetClientPlayer().dwID) or l_5_14.nTarget == 2) then
      local l_5_15 = l_5_5.szName .. " �ͷ��� " .. l_5_9 .. "  " .. l_5_14.szDesc
      if l_5_3 then
        l_5_15 = l_5_5.szName .. " �����ͷ� " .. l_5_9 .. "  " .. l_5_14.szDesc
      end
      CreateDBMAlarm(2, l_5_14.bFlash, l_5_14.szrgb, l_5_14.bMsg, l_5_15)
    end
    if DBMPanel_Set.bSayAlarm and l_5_14.bSay then
      DBMSay(DBMPanel_Set.nSaySkill, "", l_5_15)
    end
  end
end

l_0_0 = DBMLogic
l_0_0.UpdateBuff = function(l_6_0)
  local l_6_1 = nil
  if IsPlayer(l_6_0) then
    l_6_1 = GetPlayer(l_6_0)
  else
    l_6_1 = GetNpc(l_6_0)
  end
  if not l_6_1 then
    return 
  end
  if not l_6_1.GetBuffList() then
    for l_6_5,l_6_6 in pairs({}) do
      local l_6_2 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if R7_PC26.bCanCanel then
        DBMLogic.OnBuffUpdate(l_6_0, true, R7_PC26.dwID, R7_PC26.nLevel, R7_PC26.nStackNum)
      else
        DBMLogic.OnBuffUpdate(l_6_0, false, R7_PC26.dwID, R7_PC26.nLevel, R7_PC26.nStackNum)
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 23 
end

l_0_0 = DBMLogic
l_0_0.CheckBuff = function(l_7_0, l_7_1, l_7_2)
  if (l_7_1 and l_7_0.nType == 2) or not l_7_1 and l_7_0.nType == 1 then
    return false
  end
  if l_7_2 < l_7_0.nCount then
    return false
  end
  return true
end

l_0_0 = DBMLogic
l_0_0.OnBuffUpdate = function(l_8_0, l_8_1, l_8_2, l_8_3, l_8_4)
  if not DBMPanel_Set.bOn then
    return 
  end
  local l_8_5 = DBMLogic.GetCurrMod()
  if not l_8_5 or not l_8_5.bOn then
    return 
  end
  local l_8_6 = (Table_GetBuffName(l_8_2, l_8_3))
  local l_8_7 = nil
  do break end
  do
    local l_8_8, l_8_9, l_8_10, l_8_11, l_8_12 = ipairs(l_8_5.bossMod)
    local l_8_13 = l_8_5.bossData[l_8_12]
    if DBMLogic.IsNpcExistByName(l_8_12) and l_8_13 and l_8_13.bOn then
      for l_8_17,l_8_18 in pairs(l_8_13.Buff) do
      if l_8_18.szName == l_8_6 then
        end
        if l_8_18.szName == l_8_6 then
          l_8_7 = l_8_18
        end
        do break end
      end
    end
  end
end
if l_8_7 then
  l_8_8 = l_8_7.bOn
if not l_8_8 then
  end
  return 
end
l_8_8 = nil
local l_8_19, l_8_27, l_8_31 = nil
l_8_19 = IsPlayer
 -- DECOMPILER ERROR: Confused about usage of registers!

l_8_27 = l_8_0
l_8_19 = l_8_19(l_8_27)
if l_8_19 then
  l_8_19 = GetPlayer
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_8_27 = l_8_0
  l_8_19 = l_8_19(l_8_27)
  l_8_8 = l_8_19
else
  l_8_19 = GetNpc
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_8_27 = l_8_0
  l_8_19 = l_8_19(l_8_27)
  l_8_8 = l_8_19
end
if not l_8_8 then
  return 
end
l_8_19 = DBMLogic
l_8_19 = l_8_19.BuffTime
l_8_19 = l_8_19[l_8_6]
if l_8_19 then
  l_8_19 = GetCurrentTime
  l_8_19 = l_8_19()
  local l_8_20 = nil
  l_8_27 = BigIntSub
  l_8_31 = l_8_19
  l_8_20 = DBMLogic
  l_8_20 = l_8_20.BuffTime
  l_8_20 = l_8_20[l_8_6]
  l_8_20 = l_8_20.nTime
  l_8_27 = l_8_27(l_8_31, l_8_20)
end
if l_8_27 > 1 then
  l_8_27 = DBMLogic
  l_8_27 = l_8_27.BuffTime
  l_8_27 = l_8_27[l_8_6]
  l_8_27.bState = true
  l_8_27 = DBMLogic
  l_8_27 = l_8_27.BuffTime
  l_8_27 = l_8_27[l_8_6]
  l_8_27.nTime = l_8_19
end
local l_8_21, l_8_28, l_8_32 = nil
l_8_27 = l_8_7.bFlash
if l_8_27 then
  l_8_27 = CreateDBMAlarm
  l_8_31 = 2
  l_8_21 = true
  l_8_28 = l_8_7.szrgb
  l_8_27(l_8_31, l_8_21, l_8_28)
end
l_8_27 = l_8_8.szName
l_8_31 = "�����["
l_8_21 = l_8_6
l_8_28 = "]  "
l_8_32 = l_8_7.szDesc
l_8_27 = l_8_27 .. l_8_31 .. l_8_21 .. l_8_28 .. l_8_32
local l_8_22, l_8_29, l_8_33 = nil
l_8_31 = GetClientPlayer
l_8_31 = l_8_31()
l_8_31 = l_8_31.dwID
 -- DECOMPILER ERROR: Confused about usage of registers!

if l_8_0 == l_8_31 then
  l_8_31 = "������["
  l_8_21 = l_8_6
  l_8_28 = "]  "
  l_8_32 = l_8_7.szDesc
  l_8_27 = l_8_31 .. l_8_21 .. l_8_28 .. l_8_32
end
l_8_31 = l_8_7.bMsg
if l_8_31 then
  l_8_31, l_8_19 = l_8_19[l_8_6], {["��������"] = true, ["����"] = true}
end
if not l_8_31 then
  l_8_31 = CreateDBMAlarm
  l_8_21 = 2
  l_8_28 = false
  l_8_32 = nil
  l_8_22 = true
  l_8_29 = l_8_27
  l_8_31(l_8_21, l_8_28, l_8_32, l_8_22, l_8_29)
end
l_8_31 = DBMPanel_Set
l_8_31 = l_8_31.bSayAlarm
if l_8_31 then
  l_8_31 = l_8_7.bSay
if not l_8_31 then
  end
  return 
end
l_8_31 = ""
local l_8_23, l_8_30, l_8_34 = nil
l_8_21 = ""
local l_8_24, l_8_35 = nil
l_8_28 = DBMPanel_Set
l_8_28 = l_8_28.nSayBuff
local l_8_25, l_8_36 = nil
l_8_32 = GetClientPlayer
l_8_32 = l_8_32()
do
  local l_8_26, l_8_37 = nil
  l_8_22 = l_8_7.nTarget
  if l_8_22 == 1 then
    l_8_22 = l_8_32.dwID
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_8_0 ~= l_8_22 then
      l_8_22 = IsPlayer
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_8_29 = l_8_0
      l_8_22 = l_8_22(l_8_29)
    end
    if l_8_22 then
      l_8_22 = DBMPanel_Set
      l_8_22 = l_8_22.nSayBuff
      l_8_29 = PLAYER_TALK_CHANNEL
      l_8_29 = l_8_29.WHISPER
      if l_8_22 == l_8_29 then
        l_8_22 = "������["
        l_8_29 = l_8_6
        l_8_33 = "]  "
        l_8_23 = l_8_7.szDesc
        l_8_31 = l_8_22 .. l_8_29 .. l_8_33 .. l_8_23
        l_8_21 = l_8_8.szName
      else
        l_8_22 = "["
        l_8_29 = l_8_8.szName
        l_8_33 = "]�����["
        l_8_23 = l_8_6
        l_8_30 = "]  "
        l_8_34 = l_8_7.szDesc
        l_8_31 = l_8_22 .. l_8_29 .. l_8_33 .. l_8_23 .. l_8_30 .. l_8_34
        l_8_21 = ""
      end
    else
      l_8_22 = DBMPanel_Set
      l_8_22 = l_8_22.nSayBuff
      l_8_29 = PLAYER_TALK_CHANNEL
      l_8_29 = l_8_29.WHISPER
      if l_8_22 == l_8_29 then
        l_8_28 = 7
      end
      l_8_22 = "["
      l_8_29 = l_8_8.szName
      l_8_33 = "]�����["
      l_8_23 = l_8_6
      l_8_30 = "]  "
      l_8_34 = l_8_7.szDesc
      l_8_31 = l_8_22 .. l_8_29 .. l_8_33 .. l_8_23 .. l_8_30 .. l_8_34
      l_8_21 = ""
    end
  else
    l_8_22 = l_8_7.nTarget
  end
  if l_8_22 == 2 then
    l_8_22 = IsPlayer
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_8_29 = l_8_0
    l_8_22 = l_8_22(l_8_29)
  end
  if l_8_22 then
    l_8_22 = DBMPanel_Set
    l_8_22 = l_8_22.nSayBuff
    l_8_29 = PLAYER_TALK_CHANNEL
    l_8_29 = l_8_29.WHISPER
    if l_8_22 == l_8_29 then
      l_8_28 = 7
    end
    l_8_22 = "��һ����["
    l_8_29 = l_8_6
    l_8_33 = "]  "
    l_8_23 = l_8_7.szDesc
    l_8_31 = l_8_22 .. l_8_29 .. l_8_33 .. l_8_23
    l_8_21 = ""
  end
  if l_8_31 == "" then
    return 
  end
  l_8_22 = l_8_19[l_8_6]
  if l_8_22 then
    l_8_22 = DBMLogic
    l_8_22 = l_8_22.BuffTime
    l_8_22 = l_8_22[l_8_6]
    l_8_22 = l_8_22.bState
    if l_8_22 then
      l_8_22 = DBMSay
      l_8_29 = l_8_28
      l_8_33 = l_8_21
      l_8_23 = l_8_31
      l_8_22(l_8_29, l_8_33, l_8_23)
      l_8_22 = DBMLogic
      l_8_22 = l_8_22.BuffTime
      l_8_22 = l_8_22[l_8_6]
      l_8_22.bState = false
    end
  else
    l_8_22 = DBMSay
    l_8_29 = l_8_28
    l_8_33 = l_8_21
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_8_22(l_8_29, l_8_33, l_8_31)
end
end

l_0_0 = DBMLogic
l_0_0.RefreshWatchNpc = function()
  local l_9_0 = GetNpcList()
  DBMLogic.WatchNpc = {}
  local l_9_1 = DBMLogic.GetCurrMod()
  if not l_9_1 or not l_9_1.bOn then
    return 
  end
  for l_9_5,l_9_6 in ipairs(l_9_0) do
    local l_9_7 = GetNpc(l_9_6)
    if l_9_7 and l_9_1.bossData[l_9_7.szName] then
      local l_9_8 = l_9_1.bossData[l_9_7.szName]
    end
    if l_9_8 and l_9_8.bOn then
      table.insert(DBMLogic.WatchNpc, l_9_6)
    end
  end
end

l_0_0 = DBMLogic
l_0_0.NpcEnter = function(l_10_0)
  if not DBMPanel_Set.bOn then
    return 
  end
  local l_10_1 = DBMLogic.GetCurrMod()
  if not l_10_1 or not l_10_1.bOn then
    return 
  end
  local l_10_2 = GetNpc(l_10_0)
  local l_10_3 = l_10_1.bossData[l_10_2.szName]
  if not l_10_3 or not l_10_3.bOn then
    return 
  end
  table.insert(DBMLogic.WatchNpc, l_10_0)
  print(l_10_2.szName)
  print(l_10_3.bEnter)
  if l_10_3.bEnter then
    CreateDBMAlarm(2, true, "red", true, l_10_2.szName .. " ���֣�ע�⣡��")
  end
end

l_0_0 = DBMLogic
l_0_0.NpvLeave = function(l_11_0)
  if IsEmpty(DBMLogic.WatchNpc) then
    return 
  end
  for l_11_4,l_11_5 in ipairs(DBMLogic.WatchNpc) do
    if l_11_5 == l_11_0 then
      table.remove(DBMLogic.WatchNpc, l_11_4)
    end
  end
end

l_0_0 = DBMLogic
l_0_0.OnLifeTip = function()
  local l_12_0 = GetClientPlayer()
  if not l_12_0 then
    return 
  end
  local l_12_1 = DBMLogic.GetCurrMod()
  if not l_12_1 or not l_12_1.bOn then
    return 
  end
  do break end
  local l_12_2, l_12_3, l_12_4, l_12_5, l_12_6 = ipairs(DBMLogic.WatchNpc)
  local l_12_7 = GetNpc(l_12_6)
  if l_12_7 and l_12_1.bossData[l_12_7.szName] then
    local l_12_8 = math.floor(100 * l_12_7.nCurrentLife / l_12_7.nMaxLife)
    local l_12_9 = l_12_1.bossData[l_12_7.szName]
  end
  if l_12_9 and l_12_9.bOn and l_12_9.bLife then
    for l_12_13,l_12_14 in ipairs(l_12_9.tLife) do
       -- DECOMPILER ERROR: unhandled construct in 'if'

      if l_12_0.bFightState and l_12_14.num == l_12_8 and l_12_14.bOn then
        l_12_9.tLife[l_12_13].bOn = false
        CreateDBMAlarm(2, true, "red", true, "[" .. l_12_7.szName .. "] Ѫ������ " .. l_12_8 .. "% " .. l_12_14.tip)
      end
      for l_12_13,l_12_14 in l_12_10 do
        l_12_9.tLife[l_12_13].bOn = true
      end
    end
  end
end

l_0_0 = DBMLogic
l_0_0.UpdateCurrentMap = function()
  local l_13_0 = GetClientPlayer()
  local l_13_1 = l_13_0.GetScene()
  DBMLogic.currMap = Table_GetMapName(l_13_1.dwMapID)
end

l_0_0 = DBMLogic
l_0_0.Event = function(l_14_0)
  if l_14_0 == "SYS_MSG" then
    if arg0 == "UI_OME_SKILL_CAST_LOG" then
      DBMLogic.OnSkillCast(arg1, arg2, arg3, true)
      do break end
    end
    if arg0 == "UI_OME_DEATH_NOTIFY" and not IsPlayer(arg1) and not IsEmpty(DBMLogic.WatchNpc) then
      for l_14_4,l_14_5 in ipairs(DBMLogic.WatchNpc) do
        if l_14_5 == arg1 then
          table.remove(DBMLogic.WatchNpc, l_14_4)
        end
      end
    end
  elseif l_14_0 == "DO_SKILL_CAST" then
    DBMLogic.OnSkillCast(arg0, arg1, arg2, false)
  elseif l_14_0 == "NPC_ENTER_SCENE" then
    DBMLogic.NpcEnter(arg0)
  elseif l_14_0 == "NPC_LEAVE_SCENE" then
    DBMLogic.NpvLeave(arg0)
  elseif l_14_0 == "PLAYER_SAY" then
    DBMLogic.RollCall(arg0, arg1)
  elseif l_14_0 == "BUFF_UPDATE" then
    if arg1 then
      return 
    end
    if arg7 then
      DBMLogic.UpdateBuff(arg0)
      return 
    end
    if arg5 > 0 then
      local l_14_6 = Table_GetBuffName(arg4, arg8)
      if not DBMLogic.BuffTime[l_14_6] and l_14_6 ~= "" then
        local l_14_7 = DBMLogic.BuffTime
        local l_14_8 = {}
        l_14_8.bState = true
        l_14_8.nTime = GetCurrentTime()
        l_14_7[l_14_6] = l_14_8
      end
      DBMLogic.OnBuffUpdate(arg0, arg3, arg4, arg8, arg5)
    end
  elseif l_14_0 == "SYNC_ROLE_DATA_END" then
    DBMLogic.UpdateCurrentMap()
  elseif l_14_0 == "RENDER_FRAME_UPDATE" then
    if GetLogicFrameCount() % 8 ~= 0 then
      return 
    end
    DBMLogic.OnLifeTip()
  end
end

l_0_0 = DBMLogic
l_0_0 = l_0_0.LoadEvent
l_0_0()

