-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ExaminationTip.lua 

local l_0_0 = {}
l_0_0.answer = ""
l_0_0.bauto = false
l_0_0.nCurrIndex = 0
l_0_0.webpath = nil
ExaminationTip = l_0_0
l_0_0 = RegisterCustomData
l_0_0("ExaminationTip.bauto")
l_0_0 = function(l_1_0, l_1_1)
  local l_1_2 = math.abs(l_1_0 - l_1_1)
  return l_1_2 >= 0 and l_1_2 <= 2
end

local l_0_2 = function()
  -- upvalues: l_0_0
  local l_2_0 = Station.Lookup("Normal/ExaminationPanel")
  if not l_2_0:Lookup("Btn_GetAnswer") then
    local l_2_1 = BoxButton
    local l_2_2 = l_2_0
    local l_2_3 = "Btn_GetAnswer"
    local l_2_4 = {}
    l_2_4.txt = "������"
    l_2_4.x = 580
    l_2_4.y = 438
    l_2_4.w = 100
    l_2_4.h = 35
    l_2_1 = l_2_1(l_2_2, l_2_3, l_2_4)
    l_2_2, l_2_3 = l_2_1:OnClick, l_2_1
    l_2_4 = ExaminationTip
    l_2_4 = l_2_4.ShowSearch
    l_2_2(l_2_3, l_2_4)
    l_2_2, l_2_3 = l_2_1:SetAnimateGroup, l_2_1
    l_2_4 = 56
    l_2_2(l_2_3, l_2_4, 57, 58, 55)
    l_2_2, l_2_3 = l_2_1:SetFontScheme, l_2_1
    l_2_4 = 106
    l_2_2(l_2_3, l_2_4)
    l_2_2 = l_2_1.txt
    l_2_2, l_2_3 = l_2_2:SetSize, l_2_2
    l_2_4 = 100
    l_2_2(l_2_3, l_2_4, 30)
    l_2_2 = BoxBoolCheckBox
    l_2_3 = l_2_0
    l_2_4 = "CheckBox_Search"
    l_2_2 = l_2_2(l_2_3, l_2_4, "�Զ�����", ExaminationTip, "bauto")
    l_2_3, l_2_4 = l_2_2:SetRelPos, l_2_2
    l_2_3(l_2_4, 582, 410)
    l_2_3, l_2_4 = l_2_2:SetFontScheme, l_2_2
    l_2_3(l_2_4, 4)
  end
  local l_2_5 = l_2_0:Lookup("", "Image_Arrow")
  local l_2_6 = l_2_0:Lookup("", "Handle_List")
  if not l_2_5:IsVisible() then
    return 
  end
  local l_2_7 = 0
  local l_2_9 = nil
  local l_2_8 = math.floor(l_2_5 - 55)
  for l_2_13 = 1, 20 do
    local l_2_14 = l_2_6:Lookup(string.format("Image_List%.2d", l_2_13))
    if l_2_14 and l_2_14:IsVisible() then
      local l_2_15, l_2_16 = l_2_14:GetRelPos()
      l_2_15 = math.floor(l_2_15)
    end
    if l_0_0(l_2_9, l_2_15) and l_0_0(l_2_16, l_2_8) then
      l_2_7 = l_2_13
    end
  end
  if l_2_7 == 0 or ExaminationTip.nCurrIndex == l_2_7 then
    return 
  end
  ExaminationTip.nCurrIndex = l_2_7
  ExaminationTip.GetAnswer()
end

local l_0_3 = RegisterFrameHook
local l_0_4 = "ExaminationPanel_Breathe"
l_0_3(l_0_4, {"Normal/ExaminationPanel"}, "OnFrameBreathe", l_0_2)
l_0_3 = function()
  local l_3_0 = Station.Lookup(ExaminationTip.webpath)
  if l_3_0 then
    l_3_0:Destroy()
    ExaminationTip.webpath = nil
  end
end

l_0_4 = RegisterFrameHook
do
  local l_0_5 = "ExaminationPanel_Hide"
  l_0_4(l_0_5, {"Normal/ExaminationPanel"}, "OnFrameHide", l_0_3)
  l_0_4 = ExaminationTip
  l_0_5 = function()
  local l_4_0 = FormatString("http://jx3.duowan.com/s/ex.html?q=<D0>", ExaminationTip.answer)
  local l_4_1 = Station.Lookup(ExaminationTip.webpath)
  if not l_4_1 then
    local l_4_2 = OpenBoxIE(l_4_0)
    local l_4_3 = l_4_2:GetRoot()
    ExaminationTip.webpath = l_4_3:GetTreePath()
    l_4_3:Lookup("Edit_Input"):SetLimit(500)
    IE_Resize(l_4_3, 805, 570)
    local l_4_4 = Station.Lookup("Normal/ExaminationPanel")
    local l_4_5, l_4_6 = l_4_4:GetAbsPos()
    local l_4_7, l_4_8 = l_4_4:GetSize()
    l_4_3:SetAbsPos(l_4_5 + l_4_7, l_4_6 - 35)
  else
    l_4_1:Lookup("WebPage_Page"):Navigate(l_4_0)
  end
end

  l_0_4.ShowSearch = l_0_5
  l_0_4 = ExaminationTip
  l_0_5 = function()
  local l_5_0 = Station.Lookup("Normal/ExaminationPanel")
  local l_5_1 = l_5_0:Lookup("", "Handle_ExamContents")
  local l_5_2 = l_5_1:GetItemCount() - 1
  for l_5_6 = 0, l_5_2 do
    local l_5_7 = l_5_1:Lookup(l_5_6)
    if l_5_7 and l_5_7:GetType() == "Text" then
      local l_5_8 = l_5_7:GetText()
      l_5_8 = l_5_8:gsub("��ѡ�⣺", "")
      l_5_8 = l_5_8:gsub("�ж��⣺", "")
      l_5_8 = l_5_8:gsub("��ѡ�⣺", "")
      l_5_8 = l_5_8:gsub("����⣺", "")
      local l_5_9 = l_5_7:GetTextLen() - 4
      if l_5_9 > 10 then
        ExaminationTip.answer = StringSubW(l_5_8, 1, 10)
      else
        ExaminationTip.answer = StringSubW(l_5_8, 1, l_5_9)
      end
    end
    if ExaminationTip.bauto then
      ExaminationTip.ShowSearch()
    end
  end
end

  l_0_4.GetAnswer = l_0_5
  l_0_4 = RegisterBoxAddonVersion
  l_0_5 = "Moon_ExaminationTip"
  l_0_4(l_0_5, 1.6)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.


