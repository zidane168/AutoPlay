-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: EasyLoot.lua 

local l_0_0 = {}
l_0_0.bOn = false
l_0_0.bFightLoot = false
l_0_0.bLootSpecified = false
l_0_0.tLootSpecified = {}
local l_0_1 = {}
l_0_1.bExcludeGray = true
l_0_1.bExcludeWhite = false
l_0_1.bExcludeGreen = false
l_0_1.bExcludeSpecified = false
l_0_1.tExcludeSpecified = {}
l_0_0.tExcludeSetting = l_0_1
EasyLoot = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "EasyLoot.bOn"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "EasyLoot.bFightLoot"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "EasyLoot.bLootSpecified"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "EasyLoot.tLootSpecified"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "EasyLoot.tExcludeSetting"
l_0_0(l_0_1)
l_0_0 = EasyLoot
l_0_0.OpenList, l_0_1 = l_0_1, {}
l_0_0 = EasyLoot
l_0_0.IsLootList, l_0_1 = l_0_1, {}
l_0_0 = function()
  local l_1_0 = Station.Lookup("Normal/LootListExSingle")
  if l_1_0 and l_1_0:IsVisible() then
    return true
  end
  return false
end

l_0_1 = function()
  local l_2_0 = Station.Lookup("Normal/LootList")
  if l_2_0 and l_2_0:IsVisible() then
    return true
  end
  return false
end

local l_0_2 = function()
  local l_3_0 = Station.Lookup("Normal/LootList")
  local l_3_1 = l_3_0:Lookup("", "Handle_LootList")
  l_3_1:Clear()
end

EasyLoot.ClearLootList = function()
  EasyLoot.OpenList = {}
  EasyLoot.IsLootList = {}
end

EasyLoot.CheckLoot = function(l_5_0)
  if EasyLoot.bLootSpecified then
    for l_5_4,l_5_5 in ipairs(EasyLoot.tLootSpecified) do
      if GetItemNameByItem(l_5_0) == l_5_5 then
        return true
      end
    end
    return false
  end
  local l_5_6 = EasyLoot.tExcludeSetting
  if l_5_6.bExcludeSpecified then
    for l_5_10,l_5_11 in ipairs(l_5_6.tExcludeSpecified) do
      if GetItemNameByItem(l_5_0) == l_5_11 then
        return false
      end
    end
  end
  if l_5_6.bExcludeGray and l_5_0.nQuality == 0 then
    return false
  end
  if l_5_6.bExcludeWhite and l_5_0.nGenre == ITEM_GENRE.EQUIPMENT and l_5_0.nQuality == 1 then
    return false
  end
  if l_5_6.bExcludeGreen and l_5_0.nGenre == ITEM_GENRE.EQUIPMENT and l_5_0.nQuality == 2 then
    return false
  end
  return true
end

EasyLoot.OpenDoodad = function(l_6_0)
  local l_6_1 = GetClientPlayer()
  if EasyLoot.doodadCanOpen(l_6_0) then
    InteractDoodad(l_6_0)
    lc_dwLootDoodadID = l_6_0
    local l_6_2 = EasyLoot.OpenList
    local l_6_3 = {}
    l_6_3.done = true
    l_6_3.time = GetTime()
    l_6_2[l_6_0] = l_6_3
    l_6_2 = true
    return l_6_2
  end
  return false
end

EasyLoot.doodadCanOpen = function(l_7_0)
  local l_7_1 = GetDoodad(l_7_0)
  local l_7_2 = GetClientPlayer()
  if not l_7_2 or not l_7_1 then
    return false
  end
  if math.floor(l_7_2.nX - l_7_1.nX ^ 2 + l_7_2.nY - l_7_1.nY ^ 2 ^ 0.5) > 249 then
    return false
  end
  return true
end

EasyLoot.RequestLootList = function()
  local l_8_0 = {}
  local l_8_1 = GetClientPlayer()
  local l_8_2 = GetNearbyDoodadList()
  if l_8_2 then
    for l_8_6 = 1, #l_8_2 do
      local l_8_7 = l_8_2[l_8_6]
      local l_8_8 = GetDoodad(l_8_2[l_8_6])
      if not EasyLoot.IsLootList[l_8_7] and l_8_8 and l_8_8.nKind == DOODAD_KIND.CORPSE and l_8_8.CanLoot(l_8_1.dwID) and EasyLoot.doodadCanOpen(l_8_7) then
        table.insert(l_8_0, l_8_7)
      end
    end
  end
  return l_8_0
end

EasyLoot.Tip = function()
  if IsBigBagFull() then
    OutputMessage("MSG_ANNOUNCE_YELLOW", "�����Ѿ�����")
  end
end

EasyLoot.LootItem = function(l_10_0)
  local l_10_1 = GetClientPlayer()
  local l_10_2 = l_10_0.GetLootMoney()
  if l_10_2 > 0 then
    LootMoney(l_10_0.dwID)
  end
  for l_10_6 = 0, 31 do
    local l_10_7, l_10_8, l_10_9 = l_10_0.GetLootItem(l_10_6, l_10_1)
    if l_10_7 and l_10_0.CanLoot(l_10_1.dwID) and not l_10_8 and not l_10_9 and EasyLoot.CheckLoot(l_10_7) then
      LootItem(l_10_0.dwID, l_10_7.dwID)
      EasyLoot.Tip()
    end
  end
  EasyLoot.IsLootList[l_10_0.dwID] = true
end

EasyLoot.OnLoot = function()
  -- upvalues: l_0_0
  if not EasyLoot.bOn or l_0_0() then
    return 
  end
  local l_11_0 = GetClientPlayer()
  if not l_11_0 or l_11_0.GetOTActionState() ~= 0 or l_11_0.nMoveState ~= MOVE_STATE.ON_STAND then
    return 
  end
  if not EasyLoot.bFightLoot and l_11_0.bFightState then
    return 
  end
  local l_11_1 = EasyLoot.RequestLootList()
  local l_11_2 = l_11_1[#l_11_1]
  local l_11_3 = false
  if l_11_2 and EasyLoot.OpenList[l_11_2] and EasyLoot.OpenList[l_11_2].done then
    l_11_3 = true
  end
  if l_11_2 and EasyLoot.doodadCanOpen(l_11_2) and not l_11_3 then
    EasyLoot.OpenDoodad(l_11_2)
  end
  for l_11_7,l_11_8 in pairs(EasyLoot.OpenList) do
    if GetTime() - l_11_8.time > 1000 then
      EasyLoot.OpenList[l_11_7] = nil
    end
  end
end

RegisterEvent("Breathe", EasyLoot.OnLoot)
EasyLoot.CanLootItem = function(l_12_0, l_12_1)
  -- upvalues: l_0_0 , l_0_1 , l_0_2
  if l_12_0 == 0 then
    return 
  end
  if EasyLoot.IsLootList[l_12_0] then
    return false
  end
  local l_12_2 = GetClientPlayer()
  local l_12_3 = GetDoodad(l_12_0)
  if not l_12_3 or not l_12_3.CanLoot(l_12_2.dwID) or l_12_3.nKind ~= DOODAD_KIND.CORPSE then
    return false
  end
  if l_0_0() then
    return false
  end
  if l_0_1() then
    l_0_2()
  end
  return true
end

EasyLoot.OnEvent = function(l_13_0)
  if not EasyLoot.bOn then
    return 
  end
  local l_13_1 = GetClientPlayer()
  if not l_13_1 then
    return 
  end
  if l_13_0 == "OPEN_DOODAD" then
    if not EasyLoot.CanLootItem(arg0) then
      return 
    end
    EasyLoot.LootItem(GetDoodad(arg0))
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_13_0 == "PLAYER_LEAVE_SCENE" and arg0 == l_13_1.dwID then
    EasyLoot.IsLootList = {}
  end
  do return end
  if l_13_0 == "DOODAD_LEAVE_SCENE" and EasyLoot.IsLootList[arg0] then
    EasyLoot.IsLootList[arg0] = nil
  end
  do return end
  if l_13_0 == "HELP_EVENT" then
    if arg0 ~= "OnOpenpanel" or arg1 ~= "LOOT" then
      return 
    end
    EasyLoot.CanLootItem(lc_dwLootDoodadID)
    lc_dwLootDoodadID = 0
  end
end

for l_0_6,l_0_7 in pairs({"HELP_EVENT", "OPEN_DOODAD", "PLAYER_LEAVE_SCENE", "DOODAD_LEAVE_SCENE"}) do
  RegisterEvent(l_0_7, EasyLoot.OnEvent)
end

