-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: FocusShow.lua 

local l_0_0 = Table_BuffIsVisible
local l_0_1 = GetClientPlayer
local l_0_2 = Table_BuffNeedSparking
local l_0_3 = Table_BuffNeedShowTime
local l_0_4 = Table_GetBuffIconID
local l_0_5 = GetBuffTime
local l_0_6 = GetLogicFrameCount
local l_0_7 = Table_GetBuffName
local l_0_8 = GetTickCount
local l_0_9 = GetTimeToHourMinuteSecond
local l_0_10 = GetClientTeam
local l_0_11 = GetPlayer
local l_0_12 = GetNpc
local l_0_13 = GetForceFontColor
local l_0_14 = GetTargetUIName
local l_0_15 = GetForceTitle
local l_0_16 = GetForceImage
local l_0_17 = NPC_GetProtrait
local l_0_18 = NPC_GetHeadImageFile
local l_0_19 = IsFileExist
local l_0_20 = GetNpcHeadImage
local l_0_21 = GetCampImageFrame
local l_0_22 = SetImage
local l_0_23 = GetTargetLevelFont
local l_0_24 = Table_GetSkillName
local l_0_25 = GetSkill
local l_0_26 = string.format
local l_0_27 = {}
local l_0_28 = {}
l_0_28.s = "TOPLEFT"
l_0_28.r = "TOPLEFT"
l_0_28.x = 700
l_0_28.y = 465
l_0_27.DefaultAnchor = l_0_28
l_0_27.Anchor, l_0_28 = l_0_28, {s = "TOPLEFT", r = "TOPLEFT", x = 700, y = 465}
FocusShow = l_0_27
l_0_27 = RegisterCustomData
l_0_28 = "FocusShow.Anchor"
l_0_27(l_0_28)
l_0_27 = 1
if l_0_27 == 1 and l_0_27 == 1 then
  l_0_27 = 0
  l_0_28 = function()
    -- upvalues: l_0_27
    return l_0_27 == 2 or l_0_27 == 3
  end
end
end
end
l_0_28 = function()
local l_2_0 = 1
if l_2_0 == 1 and l_2_0 == 1 then
l_2_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_2_2 = nil
if function()
  -- upvalues: l_2_0
  return l_2_0 == 2 or l_2_0 == 3
end
.modelView == nil then
FocusShow.modelView = PlayerModelView.new()
FocusShow.modelView:init()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
local l_0_29 = function()
local l_3_0 = 1
if l_3_0 == 1 and l_3_0 == 1 then
l_3_0 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

do
local l_3_2 = nil
if function()
  -- upvalues: l_3_0
  return l_3_0 == 2 or l_3_0 == 3
end
.modelView then
FocusShow.modelView:UnloadModel()
FocusShow.modelView:release()
FocusShow.modelView = nil
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end
local l_0_33 = function(l_4_0, l_4_1)
-- upvalues: l_0_11 , l_0_10 , l_0_12
local l_4_2 = nil
if l_4_0 == TARGET.PLAYER then
l_4_2 = l_0_11(l_4_1)
if not l_4_2 then
  l_4_2 = l_0_10().GetMemberInfo(l_4_1)
end
else
if l_4_0 == TARGET.NPC then
  l_4_2 = l_0_12(l_4_1)
end
end
return l_4_2
end
local l_0_34 = function(l_9_0, l_9_1, l_9_2, l_9_3, l_9_4, l_9_5, l_9_6, l_9_7, l_9_8)
-- upvalues: l_0_0 , l_0_1 , l_0_2 , l_0_3 , l_0_4 , l_0_6
if not l_0_0(l_9_4, l_9_7) then
return 
end
if PrettyShow.Options.nFilters[l_9_4] == true and PrettyShow.Options.FocusFilter == true then
return 
end
if l_9_1 then
l_9_0:RemoveItem("b" .. l_9_2)
l_9_0:FormatAllItemPos()
else
local l_9_9 = l_0_1()
local l_9_10 = l_9_0:Lookup("b" .. l_9_2)
if l_9_10 then
  l_9_10.nCount = l_9_5
  l_9_10.nEndFrame = l_9_6
  l_9_10.bCanCancel = l_9_3
  l_9_10.dwBuffID = l_9_4
  l_9_10.nLevel = l_9_7
  l_9_10.bSparking = l_0_2(l_9_4, l_9_7)
  l_9_10.bShowTime = l_0_3(l_9_4, l_9_7)
  l_9_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_9_4)
  l_9_10:SetObjectIcon(l_0_4(l_9_4, l_9_7))
  if l_9_8 and l_9_9.dwID == l_9_8 then
    l_9_10:SetIndex(0)
  end
end
if l_9_5 > 1 then
  l_9_10:SetOverText(0, l_9_5)
end
else
l_9_0:AppendItemFromIni("Interface\\PrettyShow\\FocusShow.ini", "Box", "b" .. l_9_2)
l_9_10 = l_9_0:Lookup(l_9_0:GetItemCount() - 1)
l_9_10:SetName("b" .. l_9_2)
l_9_10.nCount = l_9_5
l_9_10.nEndFrame = l_9_6
l_9_10.bCanCancel = l_9_3
l_9_10.dwBuffID = l_9_4
l_9_10.nLevel = l_9_7
l_9_10.nIndex = l_9_2
l_9_10.bSparking = l_0_2(l_9_4, l_9_7)
l_9_10.bShowTime = l_0_3(l_9_4, l_9_7)
l_9_10:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_9_4)
l_9_10:SetObjectIcon(l_0_4(l_9_4, l_9_7))
l_9_10:SetOverTextFontScheme(0, 15)
l_9_10:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP + 1)
l_9_10:SetOverTextFontScheme(1, 16)
if l_9_8 and l_9_9.dwID == l_9_8 then
  l_9_10:SetIndex(0)
end
if l_9_0:GetName() == "Handle_Debuff" then
  local l_9_11 = "\\ui\\Image\\Common\\Box.UITex"
  local l_9_12 = 1
  l_9_10:SetExtentImage(l_9_11, l_9_12)
else
  local l_9_13 = "\\ui\\Image\\Common\\Box.UITex"
  local l_9_14 = 13
  l_9_10:SetExtentImage(l_9_13, l_9_14)
end
if l_9_5 > 1 then
  l_9_10:SetOverText(0, l_9_5)
end
l_9_10.OnItemMouseEnter = function()
  -- upvalues: l_0_6
  local l_10_0 = this:GetRoot()
  this:SetObjectMouseOver(1)
  local l_10_1 = math.floor(this.nEndFrame - l_0_6()) / 16 + 1
  local l_10_2, l_10_3 = this:GetAbsPos()
  local l_10_4, l_10_5 = this:GetSize()
  local l_10_6 = OutputBuffTip
  local l_10_7 = l_10_0.dwID
  local l_10_8 = this.dwBuffID
  local l_10_9 = this.nLevel
  local l_10_10 = this.nCount
  local l_10_11 = this.bShowTime
  local l_10_12 = l_10_1
  do
    local l_10_13 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_10_6(l_10_7, l_10_8, l_10_9, l_10_10, l_10_11, l_10_12, l_10_13)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_9_10.OnItemMouseHover = l_9_10.OnItemMouseEnter
l_9_10.OnItemMouseLeave = function()
  HideTip()
  this:SetObjectMouseOver(0)
end

l_9_0:FormatAllItemPos()
end
local l_9_15 = l_9_0:GetItemCount()
local l_9_16, l_9_17 = l_9_0:GetAbsPos()
local l_9_18 = PrettyShow.Options.nScale_Focus
for l_9_22 = 0, l_9_15 - 1 do
local l_9_23 = l_9_0:Lookup(l_9_22)
local l_9_24 = math.floor(l_9_22 / 8)
local l_9_25 = l_9_22 % 8
local l_9_26 = l_9_16 + l_9_25 * 29 * l_9_18
local l_9_27 = l_9_17 + l_9_24 * 29 * l_9_18
l_9_23:SetSize(28 * l_9_18, 28 * l_9_18)
l_9_23:SetAbsPos(l_9_26, l_9_27)
end
if l_9_0:GetName() == "Handle_Buff" then
local l_9_28 = math.ceil(l_9_15 / 8)
local l_9_29 = l_9_16
local l_9_30 = l_9_17 + l_9_28 * 31 * l_9_18
l_9_0:GetRoot():Lookup("", "Handle_Debuff"):SetAbsPos(l_9_29, l_9_30)
end
end
local l_0_37 = function(l_15_0, l_15_1)
-- upvalues: l_0_26
local l_15_2 = l_0_26("%d", l_15_1)
local l_15_3 = l_0_26("%d", l_15_0)
local l_15_4 = l_0_26("%.1f%%", l_15_0 * 100 / l_15_1)
if PrettyShow.Options.nActHealth == 2 then
if l_15_1 > 100000 then
  l_15_2 = l_0_26("%.1f��", l_15_1 / 10000)
end
if l_15_0 > 100000 then
  l_15_3 = l_0_26("%.1f��", l_15_0 / 10000)
end
else
if PrettyShow.Options.nActHealth == 3 then
  if l_15_1 > 100000 then
    l_15_2 = l_0_26("%.1fW", l_15_1 / 10000)
  end
end
end
if l_15_0 > 100000 then
l_15_3 = l_0_26("%.1fW", l_15_0 / 10000)
end
if PrettyShow.Options.nHealthMode == 1 or PrettyShow.Options.nHealthMode == 2 or PrettyShow.Options.nHealthMode == 3 then
return l_15_3
end
if PrettyShow.Options.nHealthMode == 4 or PrettyShow.Options.nHealthMode == 5 or PrettyShow.Options.nHealthMode == 6 then
return l_15_3 .. "/" .. l_15_2
end
if PrettyShow.Options.nHealthMode == 7 then
if l_15_0 - l_15_1 < 0 then
  local l_15_5 = l_0_26
  local l_15_6 = "%d"
  local l_15_7 = l_15_0 - l_15_1
  return l_15_5(l_15_6, l_15_7)
end
else
return ""
end
end
local l_0_39 = function(l_16_0)
if l_16_0 <= 0 or l_16_0 >= 1 then
return 0.09, 0.7, 0.03
end
if l_16_0 >= 0.5 then
return (1 - l_16_0) * 2, 0.7, 0
else
return 1, l_16_0 * 2, 0
end
end
local l_0_40 = nil
local l_0_41 = function(l_31_0)
-- upvalues: l_0_11
local l_31_1 = 1
if l_31_1 == 1 and l_31_1 == 1 then
l_31_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_31_3 = nil
local l_31_4 = function()
  -- upvalues: l_31_1
  return l_31_1 == 2 or l_31_1 == 3
end
(l_31_0)
if not Station.Lookup("Normal/FocusShow") then
return 
end
if Station.Lookup("Normal/FocusShow").dwID ~= l_31_0 then
return 
end
local l_31_5 = nil
if not l_31_4 then
Station.Lookup("Normal/FocusShow"):Lookup("", "Image_Target"):SetAlpha(255)
FocusShow.modelView:UnloadModel()
return 
end
Station.Lookup("Normal/FocusShow"):Lookup("", "Image_Target"):SetAlpha(0)
local l_31_6 = nil
l_31_5:Lookup("Show_Role"):Show()
local l_31_7 = nil
FocusShow.modelView:SetCamera(SelfPortraitCameraInfo[l_31_4.nRoleType])
l_31_7:SetScene(FocusShow.modelView.m_scene)
FocusShow.modelView:UnloadModel()
local l_31_8 = nil
do
local l_31_9 = FocusShow.modelView
l_31_9.m_aRoleAnimation = {Idle = 41}
l_31_9 = FocusShow
l_31_9 = l_31_9.modelView
l_31_9(l_31_9, l_31_0, false)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_31_9(l_31_9)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_31_9(l_31_9, "Idle", "loop")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
RegisterEvent("BGFRAME_RESET", function()
local l_37_0 = Station.Lookup("Normal/FocusShow")
if l_37_0 then
local l_37_1 = l_37_0:Lookup("", "")
local l_37_2 = l_37_1:Lookup("Image_Frame")
if PrettyShow.Options.bShowFrame then
  l_37_2:Show()
end
else
l_37_2:Hide()
end
end)
RegisterEvent("FOCUS_ENABLE", function()
Wnd.CloseWindow("FocusShow")
end)
local l_0_44 = function(l_32_0)
-- upvalues: l_0_12
local l_32_1 = 1
if l_32_1 == 1 and l_32_1 == 1 then
l_32_1 = 0
end
end
end
 -- DECOMPILER ERROR: Overwrote pending register.

local l_32_3 = nil
local l_32_4 = function()
  -- upvalues: l_32_1
  return l_32_1 == 2 or l_32_1 == 3
end
(l_32_0)
if not Station.Lookup("Normal/FocusShow") then
return 
end
local l_32_5 = nil
do
local l_32_6 = Station.Lookup("Normal/FocusShow"):Lookup("", "Image_Target")
l_32_6:SetAlpha(255)
l_32_5:Lookup("Show_Role"):Hide()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
RegisterEvent("BUFF_RESET", function()
local l_41_0 = Station.Lookup("Normal/FocusShow")
if l_41_0 then
FocusShow.UpdateBuff(l_41_0)
end
end)
RegisterEvent("HEAD_ALPHA_RESET", function()
local l_35_0 = Station.Lookup("Normal/FocusShow")
if l_35_0 then
local l_35_1 = l_35_0:Lookup("", "")
local l_35_2 = l_35_1:Lookup("Image_BgMidC")
end
if l_35_2 then
l_35_2:SetAlpha(PrettyShow.Options.Bg)
end
end)
RegisterEvent("CASTER_STYLE_RESET", function()
local l_33_0 = Station.Lookup("Normal/FocusShow")
if l_33_0 then
local l_33_1 = l_33_0:Lookup("", "Image_Progress")
local l_33_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nCaster]
if l_33_1 and l_33_2 then
  l_33_1:FromUITex(l_33_2[1], l_33_2[2])
end
local l_33_3 = PrettyShow.Options.tCasterText[1]
local l_33_4 = PrettyShow.Options.tCasterText[2]
end
if l_33_3 and l_33_4 then
local l_33_5 = l_33_0:Lookup("", "Text_SkillName")
local l_33_6 = l_33_0:Lookup("", "Text_SkillTime")
l_33_5:SetFontScheme(l_33_3)
l_33_6:SetFontScheme(l_33_3)
l_33_5:SetFontColor(l_33_4[1], l_33_4[2], l_33_4[3])
l_33_6:SetFontColor(l_33_4[1], l_33_4[2], l_33_4[3])
end
end)
RegisterEvent("HEALTH_MODE_RESET", function()
-- upvalues: l_0_30
local l_34_0 = Station.Lookup("Normal/FocusShow")
if l_34_0 then
local l_34_1 = l_34_0:Lookup("", "")
if PrettyShow.Options.nMode == 1 then
  l_34_1:Lookup("Shadow_Health"):Hide()
  l_34_1:Lookup("Shadow_Mana"):Hide()
  l_34_1:Lookup("Image_Health"):Show()
  l_34_1:Lookup("Image_Mana"):Show()
  local l_34_2 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nHealthBar]
  if l_34_2 then
    l_34_1:Lookup("Image_Health"):FromUITex(l_34_2[1], l_34_2[2])
  end
  local l_34_3 = PrettyShow.Options.ImgSrc[PrettyShow.Options.nManaBar]
  if l_34_3 then
    l_34_1:Lookup("Image_Mana"):FromUITex(l_34_3[1], l_34_3[2])
  end
else
  if PrettyShow.Options.nMode == 2 then
    l_34_1:Lookup("Image_Health"):Hide()
    l_34_1:Lookup("Image_Mana"):Hide()
    local l_34_4 = PrettyShow.Options.tHealthColor[1]
    l_34_1:Lookup("Shadow_Health"):SetColorRGB(l_34_4[1], l_34_4[2], l_34_4[3])
    local l_34_5 = PrettyShow.Options.tHealthColor[2]
    l_34_1:Lookup("Shadow_Mana"):SetColorRGB(l_34_5[1], l_34_5[2], l_34_5[3])
    l_34_1:Lookup("Shadow_Health"):Show()
    l_34_1:Lookup("Shadow_Mana"):Show()
  end
else
  if PrettyShow.Options.nMode == 3 then
    l_34_1:Lookup("Shadow_Health"):Show()
    l_34_1:Lookup("Shadow_Mana"):Show()
    l_34_1:Lookup("Image_Health"):Hide()
    l_34_1:Lookup("Image_Mana"):Hide()
    local l_34_6 = l_0_30(l_34_0.dwType, l_34_0.dwID)
    if l_34_6 then
      local l_34_7 = l_34_6.dwForceID
      if l_34_0.dwType == TARGET.NPC then
        l_34_7 = 999
      end
    end
    if l_34_7 then
      if not PrettyShow.Options.tForceColor[l_34_7] then
        local l_34_8, l_34_9, l_34_10, l_34_11 = {}
        l_34_9 = 0
        l_34_10 = 255
        l_34_11 = 0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_34_1:Lookup("Shadow_Health"):SetColorRGB(l_34_8[1], l_34_8[2], l_34_8[3])
    end
    local l_34_12 = PrettyShow.Options.tHealthColor[2]
    l_34_1:Lookup("Shadow_Mana"):SetColorRGB(l_34_12[1], l_34_12[2], l_34_12[3])
  end
else
  l_34_1:Lookup("Shadow_Health"):Show()
  l_34_1:Lookup("Shadow_Mana"):Show()
  l_34_1:Lookup("Image_Health"):Hide()
  l_34_1:Lookup("Image_Mana"):Hide()
  local l_34_13 = PrettyShow.Options.tHealthColor[2]
  l_34_1:Lookup("Shadow_Mana"):SetColorRGB(l_34_13[1], l_34_13[2], l_34_13[3])
end
local l_34_14 = l_34_0:Lookup("", "")
local l_34_15 = l_34_14:Lookup("Text_Health")
local l_34_16 = l_34_14:Lookup("Text_Mana")
if PrettyShow.Options.nHealthMode == 7 then
  l_34_15:SetHAlign(2)
  l_34_16:SetHAlign(2)
else
  l_34_15:SetHAlign(1)
  l_34_16:SetHAlign(1)
end
local l_34_17 = PrettyShow.Options.tHealth[1]
local l_34_18 = PrettyShow.Options.tHealth[2]
l_34_15:SetFontScheme(l_34_17)
l_34_15:SetFontColor(l_34_18[1], l_34_18[2], l_34_18[2])
l_34_16:SetFontScheme(l_34_17)
l_34_16:SetFontColor(l_34_18[1], l_34_18[2], l_34_18[2])
FocusShow.UpdateLM(l_34_0)
end
end)
RegisterEvent("PLAYER_DISPLAY_DATA_UPDATE", function()
-- upvalues: l_0_35
if PrettyShow.Options.FocusEnable == true then
l_0_35(arg0)
end
end)
local l_0_46 = nil
RegisterEvent("FORCE_RESET", function()
if PrettyShow.Options.FocusEnable ~= true then
return 
end
local l_43_0 = Station.Lookup("Normal/FocusShow")
if l_43_0 then
TargetTargetShow.UpdateHead(l_43_0)
end
end)
RegisterEvent("FRAME_SIZE_RESET", function()
-- upvalues: l_0_42
if arg0 ~= "Focus" then
return 
end
local l_44_0 = Station.Lookup("Normal/FocusShow")
if l_44_0 then
local l_44_1 = l_44_0.dwType
local l_44_2 = l_44_0.dwID
Wnd.CloseWindow("FocusShow")
l_0_42(l_44_1, l_44_2)
end
end)
RegisterEvent("FOCUSICON_RESET", function()
local l_36_0 = Station.Lookup("Normal/FocusShow")
if l_36_0 then
if PrettyShow.Options.bFocusIcon then
  l_36_0:Lookup("", "Image_Focus"):Show()
end
else
l_36_0:Lookup("", "Image_Focus"):Hide()
end
end)
local l_0_49 = nil
Hotkey.AddBinding("SetFocus", "���ý���", "3D����Ŀ��", function()
-- upvalues: l_0_1 , l_0_11 , l_0_12 , l_0_43
local l_45_0 = (l_0_1())
local l_45_1, l_45_2 = nil, nil
if l_45_0 then
l_45_1 = l_45_0.GetTarget()
end
local l_45_3 = nil
if l_45_1 == TARGET.PLAYER then
l_45_3 = l_0_11(l_45_2)
else
if l_45_1 == TARGET.NPC then
  l_45_3 = l_0_12(l_45_2)
end
end
local l_45_4 = Station.Lookup("Normal/FocusShow")
if l_45_4 and l_45_1 == l_45_4.dwType and l_45_2 == l_45_4.dwID then
return 
end
if l_45_3 then
l_0_43()
end
end, nil)
Hotkey.AddBinding("ClearFocus", "ȡ������", nil, function()
Wnd.CloseWindow("FocusShow")
end, nil)
RegisterEvent("CUSTOM_DATA_LOADED", function()
-- upvalues: l_0_48 , l_0_49
if arg0 ~= "Role" then
return 
end
AppendCommand("focus", l_0_48)
AppendCommand("clearfocus", l_0_49)
if PrettyShow.Options.FocusFlash == true then
Wnd.OpenWindow("Interface\\PrettyShow\\FocusGui.ini", "FocusGui")
end
end)
local l_0_51 = nil
RegisterEvent("FOCUS_FLASH", function()
if PrettyShow.Options.FocusFlash == true then
Wnd.OpenWindow("Interface\\PrettyShow\\FocusGui.ini", "FocusGui")
else
Wnd.CloseWindow("FocusGui")
end
end)
local l_0_52 = nil
do
local l_0_53 = nil
RegisterCustomData("FocusGui.Anchor")
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

