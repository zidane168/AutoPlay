-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: radiobutton.lua 

BFRadioButton = classv2(BFWidget)
local l_0_0 = {}
BFRadioButton.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4, l_1_5)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  l_1_0:SetText(l_1_4)
  l_1_0:SetGroup(l_1_5)
end

BFRadioButton.Create = function(l_2_0, l_2_1, l_2_2)
  -- upvalues: l_0_0
  local l_2_3 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\radiobutton.ini", l_2_0:GetName())
  local l_2_4 = l_2_3:Lookup("Wnd_Main")
  assert(l_2_4, "Failed to create RadioButton widget.")
  l_2_0:SetContainer(l_2_4)
  local l_2_5 = l_2_4:Lookup("CheckBox_Main")
  local l_2_6 = l_2_5:Lookup("", "")
  local l_2_7 = l_2_6:Lookup("Text_Main")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button = l_2_5
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_6
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text = l_2_7
  l_2_0:SetSize(l_2_1, l_2_2)
  l_2_5.widget = l_2_0
  l_2_5.OnCheckBoxCheck = function()
    -- upvalues: l_0_0
    if this.widget.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9 then
      local l_3_0, l_3_1 = nil, nil
      for l_3_5,l_3_6 in pairs(l_0_0[this.widget.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9]) do
        if l_3_6 ~= this.widget then
          l_3_6:_SetChecked(false)
        end
      end
      this.widget:_FireEvent("OnSelect", this.widget)
    end
  end
end

BFRadioButton.Select = function(l_3_0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Check(true)
end

BFRadioButton.IsSelected = function(l_4_0)
  local l_4_1, l_4_2 = l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:IsCheckBoxChecked, l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button
  return l_4_1(l_4_2)
end

BFRadioButton._SetChecked = function(l_5_0, l_5_1)
  l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Check(l_5_1)
end

BFRadioButton.Enable = function(l_6_0)
  l_6_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(true)
end

BFRadioButton.Disable = function(l_7_0)
  l_7_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(false)
end

BFRadioButton.SetText = function(l_8_0, l_8_1)
  l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetText(l_8_1)
end

BFRadioButton.GetText = function(l_9_0)
  local l_9_1, l_9_2 = l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:GetText, l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text
  return l_9_1(l_9_2)
end

BFRadioButton.SetGroup = function(l_10_0, l_10_1)
  -- upvalues: l_0_0
  if l_10_0.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9 then
    local l_10_2, l_10_3 = nil, nil
    for l_10_7,l_10_8 in pairs(l_0_0[l_10_0.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9]) do
      if l_10_8 == l_10_0 then
        table.remove(l_0_0[l_10_0.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9], l_10_7)
      end
    end
  end
  if l_10_1 then
    l_10_2 = l_0_0
    l_10_2 = l_10_2[l_10_1]
    if not l_10_2 then
      l_10_2 = l_0_0
      l_10_2[l_10_1], l_10_3 = l_10_3, {}
    end
    l_10_2 = table
    l_10_2 = l_10_2.insert
    l_10_3 = l_0_0
    l_10_3 = l_10_3[l_10_1]
    l_10_2(l_10_3, l_10_0)
  end
  l_10_0.BigFoot_a3b4351f09fb1ad61e0a6f2f8323f6e9 = l_10_1
end

BFRadioButton.IsEnabled = function(l_11_0)
  local l_11_1, l_11_2 = l_11_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:IsEnabled, l_11_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button
  return l_11_1(l_11_2)
end

BFRadioButton._UpdateContent = function(l_12_0)
  local l_12_1 = l_12_0:GetWidth()
  local l_12_2 = l_12_0:GetHeight()
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetSize(25, 25)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetRelPos(0, (l_12_2 - 25) / 2)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetRelPos(0, 0)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSize(l_12_1, 25)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetRelPos(30, -1)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetSize(l_12_1 - 30, 25)
end


