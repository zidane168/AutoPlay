-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: test.lua 

if not BF_Loot then
  BF_Loot = {}
end
BF_Loot.LootList = {}
RegisterEvent("SYNC_LOOT_LIST", function()
  if arg0 then
    BF_Loot.LootItemsByQuality(arg0, true)
  end
end
)
RegisterEvent("OPEN_DOODAD", function()
  BF_Loot.LootItemsByQuality(arg0, false)
end
)
BF_Loot.LootItemsByQuality = function(l_3_0, l_3_1)
  if l_3_1 then
    InteractDoodad(l_3_0)
  end
  local l_3_2 = GetDoodad(l_3_0)
  if l_3_2.nKind ~= DOODAD_KIND.CORPSE then
    return 
  end
  local l_3_3 = Station.Lookup("Normal/LootList")
  if l_3_3 then
    l_3_3:Hide()
  else
    return 
  end
  local l_3_4 = l_3_3:Lookup("", "Handle_LootList")
  local l_3_5 = l_3_4:GetItemCount()
  for l_3_9 = 0, l_3_5 - 1 do
    local l_3_10 = l_3_4:Lookup(l_3_9)
    if l_3_10.bMoney then
      LootMoney(l_3_0)
    else
      local l_3_11 = GetItem(l_3_10.dwID)
    end
    if l_3_11 then
      local l_3_12 = l_3_11.nQuality
      LootItem(l_3_0, l_3_11.dwID)
    end
  end
end


