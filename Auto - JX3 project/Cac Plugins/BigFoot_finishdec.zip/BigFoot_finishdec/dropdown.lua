-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: dropdown.lua 

BFDropdown = classv2(BFWidget)
BFDropdown.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  local l_1_5 = BFImage.new(l_1_0, l_1_2, l_1_3, "ui\\Image\\UICommon\\CommonPanel.UITex", 48)
  local l_1_6 = BFImage.new(l_1_0, 20, 20, "ui\\Image\\UICommon\\CommonPanel.UITex", 73)
  local l_1_7 = BFButton.new(l_1_0, l_1_2 - 8, l_1_3)
  local l_1_8 = BFWindow.new(l_1_0, l_1_2, 0)
  l_1_5:SetImageType("NINE_PART")
  l_1_7:SetTextHAlign("LEFT")
  l_1_7:SetStyle("TRANSPARENT")
  l_1_7.widget = l_1_0
  l_1_8:SetBorder("THIN")
  l_1_8:Hide()
  l_1_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button = l_1_7
  l_1_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.background = l_1_5
  l_1_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.downimage = l_1_6
  l_1_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list = l_1_8
  l_1_0:SetSize(l_1_2, l_1_3)
  l_1_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7 = {}
  l_1_7.OnMouseEnter = function(l_2_0)
    -- upvalues: l_1_6
    l_1_6:SetImage("ui\\Image\\UICommon\\CommonPanel.UITex", 74)
  end
  l_1_7.OnMouseLeave = function(l_3_0)
    -- upvalues: l_1_6
    l_1_6:SetImage("ui\\Image\\UICommon\\CommonPanel.UITex", 73)
  end
  l_1_7.OnClick = function(l_4_0)
    -- upvalues: l_1_8
    if l_1_8:IsShown() then
      l_1_8:Hide()
    else
      l_1_8:Show()
      local l_4_1 = l_4_0.widget:GetHeight() + l_1_8:GetHeight()
      l_4_0.widget:SetSize(l_4_0.widget:GetWidth(), l_4_1)
      Station.SetFocusWindow(l_1_8:GetContainer())
    end
  end
  if l_1_4 then
    l_1_7.OnKillFocus = function()
    -- upvalues: l_1_7 , l_1_8
    local l_5_0, l_5_1 = Cursor.GetPos()
    local l_5_2, l_5_3 = l_1_7:GetAbsPos()
    local l_5_4, l_5_5 = l_1_7:GetSize()
    if l_1_8:IsShown() and (l_5_0 < l_5_2 or l_5_2 + l_5_4 < l_5_0 or l_5_1 < l_5_3 or l_5_3 + l_5_5 < l_5_1) then
      l_1_8:Hide()
    end
  end
  else
    l_1_8.OnKillFocus = function()
    -- upvalues: l_1_8 , l_1_7
    local l_6_0, l_6_1 = Cursor.GetPos()
    local l_6_2, l_6_3 = l_1_8:GetAbsPos()
    local l_6_4, l_6_5 = l_1_8:GetSize()
    local l_6_6, l_6_7 = l_1_7:GetAbsPos()
    local l_6_8, l_6_9 = l_1_7:GetSize()
    if ((l_6_0 >= l_6_6 and l_6_1 >= l_6_7 and l_6_2 + l_6_4 >= l_6_0 and l_6_3 + l_6_5 >= l_6_1) or (l_6_0 >= l_6_6 and l_6_6 + l_6_8 >= l_6_0 and l_6_1 >= l_6_7 and l_6_7 + l_6_9 >= l_6_1) or l_1_8:IsShown()) then
      l_1_8:Hide()
    end
  end
    l_1_8.OnMouseEnter = function()
      -- upvalues: l_1_8
      Station.SetFocusWindow(l_1_8:GetContainer())
    end
    l_1_8.OnMouseLeave = function()
      -- upvalues: l_1_8
      Station.SetFocusWindow(l_1_8:GetContainer())
    end
  end
end

BFDropdown.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\dropdown.ini", l_2_0:GetName())
  local l_2_4 = l_2_3:Lookup("Wnd_Main")
  local l_2_5 = l_2_4:Lookup("", "")
  local l_2_6 = l_2_5:Lookup("Handle_Highlight")
  local l_2_7 = l_2_6:Lookup("Image_Highlight")
  l_2_3.widget = l_2_0
  l_2_6:Hide()
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_5
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.highlight = l_2_7
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.highlighthandle = l_2_6
  l_2_0:SetContainer(l_2_4)
end

BFDropdown._UpdateContent = function(l_3_0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 15, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.downimage:SetPoint("TOPRIGHT", l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button, "TOPRIGHT", -15, l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:GetHeight() / 2 - 10)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.background:SetPoint("LEFT", l_3_0, "LEFT", 0, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.background:SetPoint("TOP", l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button, "TOP", 0, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.background:SetPoint("BOTTOMRIGHT", l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button, "BOTTOMRIGHT", 0, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list:SetPoint("TOP", l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button, "BOTTOM", 0, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list:SetPoint("LEFT", l_3_0, "LEFT", 0, 0)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list:SetPoint("RIGHT", l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button, "RIGHT", 0, 0)
end

BFDropdown.SetDefaultText = function(l_4_0, l_4_1)
  l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetText(l_4_1)
end

BFDropdown.AddItem = function(l_5_0, l_5_1)
  if l_5_1 then
    l_5_1:SetParent(l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list)
    l_5_1:Show()
    table.insert(l_5_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7, l_5_1)
    l_5_0:BigFoot_c43e821e5f67d6f795ba047656c5a81c(l_5_0)
  end
end

BFDropdown.RemoveItem = function(l_6_0, l_6_1)
  if l_6_1 then
    for l_6_5,l_6_6 in ipairs(l_6_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
      if l_6_6 == l_6_1 then
        table.remove(l_6_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7, l_6_5)
        l_6_6:Hide()
        do break end
      end
    end
    l_6_0:BigFoot_c43e821e5f67d6f795ba047656c5a81c(l_6_0)
  end
end

BFDropdown.BigFoot_c43e821e5f67d6f795ba047656c5a81c = function(l_7_0)
  local l_7_1 = l_7_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.list
  local l_7_2 = l_7_1:GetSize()
  local l_7_3 = 0
  for l_7_7,l_7_8 in ipairs(l_7_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
    l_7_8:SetPoint("TOPLEFT", l_7_1, "TOPLEFT", 5, l_7_3 + 10)
    l_7_3 = l_7_3 + l_7_8:GetHeight() + 5
  end
  l_7_1:SetSize(l_7_2, l_7_3 + 20)
end

BFDropdown.OnFrameBreathe = function(l_8_0)
  local l_8_1 = this.widget.BigFoot_3114845209994c70609a5b5a5c9a1c28.list
  if l_8_1:IsShown() then
    local l_8_2 = this.widget.BigFoot_3114845209994c70609a5b5a5c9a1c28.highlighthandle
    local l_8_3 = this.widget.BigFoot_3114845209994c70609a5b5a5c9a1c28.highlight
    local l_8_4, l_8_5 = Cursor.GetPos()
    local l_8_6, l_8_7 = l_8_1:GetAbsPos()
    local l_8_8, l_8_9 = l_8_1:GetSize()
    l_8_2:Hide()
  end
  if l_8_6 < l_8_4 and l_8_4 < l_8_6 + l_8_8 and l_8_7 < l_8_5 and l_8_5 < l_8_7 + l_8_9 then
    for l_8_13,l_8_14 in ipairs(this.widget.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
      local l_8_15, l_8_16 = l_8_14:GetAbsPos()
      local l_8_17, l_8_18 = l_8_14:GetSize()
      l_8_2:Show()
      if l_8_15 < l_8_4 and l_8_4 < l_8_15 + l_8_17 and l_8_16 < l_8_5 and l_8_5 < l_8_16 + l_8_18 then
        l_8_2:SetAbsPos(l_8_15, l_8_16)
        l_8_3:SetSize(l_8_17, l_8_18)
      end
      do break end
    end
  end
end

test_dropdown = function()
  local l_9_0 = BFFrame.new(200, 200, "NONE")
  dropdown = BFDropdown.new(l_9_0, 100, 25)
  l_9_0:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", 800, 500)
  dropdown:SetPoint("TOPLEFT", l_9_0, "TOPLEFT", 0, 0)
  dropdown:SetDefaultText("dddd")
  local l_9_1 = BFButton.new(l_9_0, 100, 25, "aaass")
  l_9_1.OnClick = function(l_10_0)
    Output("click")
  end
  dropdown:AddItem(l_9_1)
  local l_9_2 = BFCheckButton.new(l_9_0, 100, 25, "orange")
  dropdown:AddItem(l_9_2)
end


