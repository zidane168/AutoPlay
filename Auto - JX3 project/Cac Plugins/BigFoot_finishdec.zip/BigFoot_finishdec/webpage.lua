-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: webpage.lua 

BFWebPage = classv2(BFWidget)
BFWebPage.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  if l_1_4 then
    l_1_0:Navigate(l_1_4)
  end
end

BFWebPage.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = assert
  l_2_3(l_2_1 >= 0 and l_2_2 >= 0, "Invalid widget size.")
  l_2_3 = Wnd
  l_2_3 = l_2_3.OpenWindow
  l_2_3 = l_2_3("Interface\\BF_Base\\widget\\webpage.ini", l_2_0:GetName())
  local l_2_6 = l_2_3:Lookup("Wnd_Main")
  l_2_0:SetContainer(l_2_6)
  local l_2_7 = l_2_6:Lookup("WebPage_Main")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.webpage = l_2_7
  l_2_0:SetSize(l_2_1, l_2_2)
end

BFWebPage.Navigate = function(l_3_0, l_3_1)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.webpage:Navigate(l_3_1)
end

BFWebPage.GetURL = function(l_4_0)
  l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.webpage:GetLocationURL()
end

BFWebPage._UpdateContent = function(l_5_0)
  local l_5_1 = l_5_0:GetWidth()
  local l_5_2 = l_5_0:GetHeight()
  l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.webpage:SetSize(l_5_1, l_5_2)
end


