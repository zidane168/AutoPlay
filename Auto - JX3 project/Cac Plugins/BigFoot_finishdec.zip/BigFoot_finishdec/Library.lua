-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Library.lua 

BigFootLibrary = {}
BigFootLibrary.new = function(l_1_0)
  local l_1_1 = {}
  setmetatable(l_1_1, l_1_0)
  if l_1_0.index ~= l_1_0 then
    l_1_0.index = l_1_0
  end
  l_1_1:constructor()
  return l_1_1
end

BigFootLibrary.constructor = function(l_2_0)
  l_2_0.classes = {}
end

BigFootLibrary.Register = function(l_3_0, l_3_1, l_3_2, l_3_3, l_3_4)
  local l_3_5 = assert
  local l_3_6 = nil
  if l_3_1 then
    l_3_6 = type
    l_3_6 = l_3_6(l_3_1)
    l_3_6 = l_3_6 == "table"
  end
  l_3_5(l_3_6, "The class must be specified.")
  l_3_5 = assert
  l_3_6 = l_3_1.constructor
  l_3_5(l_3_6, "The method <constructor> must be defined.")
  l_3_5 = assert
  if l_3_2 then
    l_3_6 = type
    l_3_6 = l_3_6(l_3_2)
    l_3_6 = l_3_6 == "string"
  end
  l_3_5(l_3_6, "The type of parameter library must be string.")
  l_3_5 = l_3_0.classes
  l_3_5 = l_3_5[l_3_2]
  if l_3_5 then
    l_3_5 = error
    l_3_6 = string
    l_3_6 = l_3_6.format
    l_3_5(l_3_6)
    l_3_5 = false
    return l_3_5
  end
  l_3_5 = l_3_1.index
  if l_3_5 ~= l_3_1 then
    l_3_1.index = l_3_1
  end
  l_3_5 = l_3_0.classes
  l_3_5[l_3_2], l_3_6 = l_3_6, {}
  l_3_5 = l_3_0.classes
  l_3_5 = l_3_5[l_3_2]
  l_3_5.class = l_3_1
  l_3_5 = l_3_0.classes
  l_3_5 = l_3_5[l_3_2]
  l_3_5.major_version = l_3_3
  l_3_5 = l_3_0.classes
  l_3_5 = l_3_5[l_3_2]
  l_3_5.minor_version = l_3_4
  l_3_5 = true
  return l_3_5
end

local l_0_0 = function(l_4_0, l_4_1, ...)
  local l_4_3 = assert
  l_4_3(not l_4_1 or type(l_4_1) == "string", "The type of parameter library must be string.")
  l_4_3 = assert
  l_4_3(l_4_0.classes[l_4_1], string.format("The library <%s> does not exist.", l_4_1))
  l_4_3 = setmetatable
  l_4_3 = l_4_3({}, l_4_0.classes[l_4_1].class)
  l_4_3:constructor(...)
  return l_4_3
end

BigFootLibrary.CreateInstance = l_0_0
BigFootLibrary.GetClass = function(l_5_0, l_5_1)
  local l_5_2 = assert
  local l_5_3 = nil
  if l_5_1 then
    l_5_3 = type
    l_5_3 = l_5_3(l_5_1)
    l_5_3 = l_5_3 == "string"
  end
  l_5_2(l_5_3, "The type of parameter library must be string.")
  l_5_2 = l_5_0.classes
  l_5_2 = l_5_2[l_5_1]
  if l_5_2 then
    l_5_2 = l_5_0.classes
    l_5_2 = l_5_2[l_5_1]
    l_5_2 = l_5_2.class
  end
  if l_5_2 then
    l_5_2 = l_5_0.classes
    l_5_2 = l_5_2[l_5_1]
    l_5_2 = l_5_2.class
    return l_5_2
  else
    l_5_2 = false
    return l_5_2
  end
end

BLibrary = BigFootLibrary:new()
getmetatable(BLibrary).call = l_0_0

