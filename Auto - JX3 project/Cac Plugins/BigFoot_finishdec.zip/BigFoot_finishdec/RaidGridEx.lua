-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RaidGridEx.lua 

if not RaidGridEx then
  RaidGridEx = {}
end
RaidGridEx.nSteper = -1
RaidGridEx.frameSelf = nil
RaidGridEx.handleMain = nil
RaidGridEx.handleBG = nil
RaidGridEx.handleDummy = nil
RaidGridEx.handleRoles = nil
RaidGridEx.szTitleText = ""
RaidGridEx.nColLength = 64
RaidGridEx.nRowLength = 45
RaidGridEx.nLeftBound = 10
RaidGridEx.nBottomBound = 8
RaidGridEx.nTopBound = 28
RaidGridEx.nTitleHeight = 24
RaidGridEx.handleLastSelect = nil
RaidGridEx.bDrag = false
RaidGridEx.TeamGroupInfo = {}
local l_0_0 = RaidGridEx
local l_0_1 = {}
l_0_1.nX = 0
l_0_1.nY = 0
l_0_0.tLastLoc = l_0_1
l_0_0 = RegisterCustomData
l_0_1 = "RaidGridEx.tLastLoc"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "RaidGridEx.fScale"
l_0_0(l_0_1)
l_0_0 = "Interface/BF_RaidGridEx/RaidGridEx.ini"
l_0_1 = RaidGridEx
l_0_1.OnCustomDataLoaded = function()
  RaidGridEx.EnableRaidPanel(RaidGridEx.bShowSystemRaidPanel)
  if RaidGridEx.tLastLoc.nX == 0 and RaidGridEx.tLastLoc.nY == 0 then
    RaidGridEx.SetPanelPos()
  else
    if RaidGridEx.frameSelf then
      RaidGridEx.SetPanelPos(RaidGridEx.tLastLoc.nX, RaidGridEx.tLastLoc.nY)
    end
  end
  if not RaidGridEx.fScale then
    RaidGridEx.fScale = 1.1
  end
end

l_0_1 = RaidGridEx
l_0_1.OnFrameCreate = function()
  this:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
  this:RegisterEvent("PARTY_ADD_MEMBER")
  this:RegisterEvent("PARTY_DISBAND")
  this:RegisterEvent("PARTY_DELETE_MEMBER")
  this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
  this:RegisterEvent("PARTY_UPDATE_MEMBER_LMR")
  this:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
  this:RegisterEvent("PLAYER_STATE_UPDATE")
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
  this:RegisterEvent("RIAD_READY_CONFIRM_RECEIVE_ANSWER")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
  this:RegisterEvent("PARTY_SET_FORMATION_LEADER")
  this:RegisterEvent("TEAM_CHANGE_MEMBER_GROUP")
  this:RegisterEvent("PARTY_ROLL_QUALITY_CHANGED")
  if RaidGridEx.frameSelf then
    RaidGridEx.frameSelf:Hide()
  end
end

l_0_1 = RaidGridEx
l_0_1.OnEvent = function(l_3_0)
  if not BigFoot_b0690f1f0dd37df2f5f85ae100707f67 and RaidGridEx.frameSelf then
    RaidGridEx.frameSelf:Hide()
  end
  return 
  local l_3_1 = GetClientPlayer()
  local l_3_2 = Station.Lookup("Normal/RaidGridEx")
  if l_3_0 == "PARTY_SYNC_MEMBER_DATA" or l_3_0 == "PARTY_ADD_MEMBER" then
    RaidGridEx.OnMemberJoinTeam(arg1, arg2)
    RaidGridEx.ShowRoleHandle(nil, nil, RaidGridEx.GetRoleHandleByID(arg1))
    RaidGridEx.RedrawMemberHandleHPnMP(arg1)
    RaidGridEx.RedrawMemberHandleState(arg1)
    RaidGridEx.UpdateMemberSpecialState(arg1)
    RaidGridEx.AutoScalePanel()
  elseif l_3_0 == "PARTY_DELETE_MEMBER" then
    if GetClientPlayer().dwID == arg1 then
      if RaidGridEx.bShowInRaid then
        RaidGridEx.ClosePanel()
      else
        RaidGridEx.OnMemberChangeGroup()
        RaidGridEx.frameSelf:Show()
      end
    else
      RaidGridEx.OnMemberChangeGroup()
    end
  elseif l_3_0 == "PARTY_DISBAND" then
    if RaidGridEx.bShowInRaid then
      RaidGridEx.ClosePanel()
    else
      RaidGridEx.OnMemberChangeGroup()
      RaidGridEx.frameSelf:Show()
    end
  elseif l_3_0 == "PARTY_UPDATE_MEMBER_INFO" then
    RaidGridEx.RedrawMemberHandleState(arg1)
    RaidGridEx.UpdateMemberSpecialState(arg1)
  elseif l_3_0 == "UPDATE_PLAYER_SCHOOL_ID" and l_3_1.IsPlayerInMyParty(arg0) then
    RaidGridEx.RedrawMemberHandleState(arg0)
    RaidGridEx.UpdateMemberSpecialState(arg0)
  end
  do return end
  if l_3_0 == "PARTY_UPDATE_MEMBER_LMR" then
    RaidGridEx.RedrawMemberHandleHPnMP(arg1)
  elseif l_3_0 == "PLAYER_STATE_UPDATE" and l_3_1.IsPlayerInMyParty(arg0) then
    RaidGridEx.RedrawMemberHandleState(arg0)
  end
  do return end
  if l_3_0 == "PARTY_SET_MEMBER_ONLINE_FLAG" then
    RaidGridEx.RedrawMemberHandleHPnMP(arg1)
    RaidGridEx.RedrawMemberHandleState(arg1)
    RaidGridEx.UpdateMemberSpecialState(arg1)
  elseif l_3_0 == "BUFF_UPDATE" and l_3_1.IsPlayerInMyParty(arg0) then
    RaidGridEx.OnUpdateBuffData(arg0, arg1, arg2, arg4, arg5, arg6, arg8)
  end
  do return end
  if l_3_0 == "TEAM_AUTHORITY_CHANGED" then
    RaidGridEx.RedrawMemberHandleState(arg2)
    RaidGridEx.RedrawMemberHandleState(arg3)
  elseif l_3_0 == "PARTY_SET_FORMATION_LEADER" then
    RaidGridEx.OnMemberChangeGroup()
  elseif l_3_0 == "RIAD_READY_CONFIRM_RECEIVE_ANSWER" then
    RaidGridEx.ChangeReadyConfirm(arg0, arg1)
  elseif l_3_0 == "TEAM_CHANGE_MEMBER_GROUP" and not RaidGridEx.IsOpened() and RaidGridEx.bShowInRaid and BigFoot_b0690f1f0dd37df2f5f85ae100707f67 then
    l_3_2:Show()
  end
end

l_0_1 = RaidGridEx
l_0_1.OnLButtonClick = function()
  local l_4_0 = this:GetName()
  if l_4_0 == "Btn_Option" then
    RaidGridEx.PopOptions()
  end
end

l_0_1 = RaidGridEx
l_0_1.OnItemLButtonClick = function()
  local l_5_0 = this:GetName()
  local l_5_1 = GetClientPlayer()
  if not l_5_1 then
    return 
  end
  if l_5_0:match("Handle_Role_") and this:GetAlpha() == 255 then
    local l_5_2 = RaidGridEx.tGroupList[this.nGroupIndex][this.nSortIndex]
  end
  if l_5_2 and l_5_2 > 0 and IsPlayer(l_5_2) then
    local l_5_3 = GetPlayer(l_5_2)
  end
  if l_5_3 then
    if RaidGridEx.handleLastSelect then
      RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole"):Hide()
      RaidGridEx.handleLastSelect = nil
    end
    if IsCtrlKeyDown() then
      RaidGridEx.EditBox_AppendLinkPlayer(l_5_3.szName)
    end
  else
    RaidGridEx.SetTarget(l_5_2)
  end
end

l_0_1 = RaidGridEx
l_0_1.OnItemRButtonClick = function()
  local l_6_0 = this:GetName()
  local l_6_1 = GetClientTeam()
  if not l_6_1 then
    return 
  end
  if l_6_0:match("Handle_Role_") and this:GetAlpha() == 255 then
    local l_6_2 = {}
    local l_6_3 = GetClientPlayer()
    local l_6_4 = RaidGridEx.tGroupList[this.nGroupIndex][this.nSortIndex]
    if RaidGridEx.IsLeader(l_6_3.dwID) then
      InsertTeammateLeaderMenu(l_6_2, l_6_4)
    end
    if l_6_4 ~= l_6_3.dwID then
      InsertTeammateMenu(l_6_2, l_6_4)
    else
      InsertPlayerMenu(l_6_2)
    end
  end
  if l_6_2 and #l_6_2 > 0 then
    PopupMenu(l_6_2)
  end
end

local l_0_2 = nil
RaidGridEx.OnItemLButtonDrag = function()
  -- upvalues: l_0_1 , l_0_2
  local l_7_0 = this:GetName()
  if not RaidGridEx.IsLeader(GetClientPlayer().dwID) or not l_7_0:match("Handle_Role_") or RaidGridEx.IsInTeam() ~= 2 then
    return 
  end
  if IsShiftKeyDown() then
    RaidGridEx.bDrag = true
    RaidGridEx.AutoScalePanel()
    l_0_1 = this.nGroupIndex
    l_0_2 = RaidGridEx.tGroupList[this.nGroupIndex][this.nSortIndex]
    RaidGridEx.OpenRaidDragPanel(l_0_2)
  else
    OutputMessage("MSG_SYS", "�밴ס��סSHIFT���ж����Ա�϶�\n")
  end
end

RaidGridEx.OnItemLButtonDragEnd = function()
  -- upvalues: l_0_1 , l_0_2
  local l_8_0 = this:GetName()
  local l_8_1 = GetClientTeam()
  if not RaidGridEx.IsLeader(GetClientPlayer().dwID) or not l_8_0:match("Handle_Role_") or not l_8_1 then
    return 
  end
  RaidGridEx.bDrag = false
  RaidGridEx.AutoScalePanel()
  local l_8_2 = this.nGroupIndex
  do
    local l_8_3, l_8_4, l_8_5, l_8_6, l_8_7 = RaidGridEx.tGroupList[this.nGroupIndex][this.nSortIndex] or 0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_8_2 and l_8_2 >= 0 and l_8_2 < 5 and l_0_1 and l_0_2 and l_8_3 and l_8_2 ~= l_0_1 then
    l_8_1.ChangeMemberGroup(l_0_2, l_8_2, l_8_3)
  end
  RaidGridEx.handleBG:Lookup("Image_DragBox"):Hide()
  RaidGridEx.handleBG:Lookup("Image_DragBox_Disable"):Hide()
  l_0_1 = nil
  l_0_2 = nil
  RaidGridEx.CloseRaidDragPanel()
end

RaidGridEx.OnFrameBreathe = function()
  -- upvalues: l_0_1 , l_0_2
  RaidGridEx.nSteper = RaidGridEx.nSteper + 1
  local l_9_0 = GetClientPlayer()
  if l_9_0 then
    if RaidGridEx.handleLastSelect then
      local l_9_1 = RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole")
    end
    if l_9_1 then
      l_9_1:Hide()
      RaidGridEx.handleLastSelect = nil
    end
    local l_9_2, l_9_3 = l_9_0.GetTarget()
  end
  if l_9_3 and l_9_3 > 0 then
    local l_9_4 = nil
    if IsPlayer(l_9_3) and l_9_0.IsPlayerInMyParty(l_9_3) then
      l_9_4 = GetPlayer(l_9_3)
    else
      if IsPlayer(l_9_3) then
        l_9_4 = GetPlayer(l_9_3)
      else
        l_9_4 = GetNpc(l_9_3)
      end
    end
    if l_9_4 then
      local l_9_5, l_9_6 = l_9_4.GetTarget()
      if IsPlayer(l_9_6) and l_9_0.IsPlayerInMyParty(l_9_6) then
        l_9_4 = GetPlayer(l_9_6)
      end
    else
      l_9_4 = nil
    end
  end
  if l_9_4 then
    RaidGridEx.handleLastSelect = RaidGridEx.GetRoleHandleByID(l_9_4.dwID)
  end
  if RaidGridEx.handleLastSelect then
    RaidGridEx.handleLastSelect:Lookup("Animate_SelectRole"):Show()
  end
  if RaidGridEx.bDrag and not IsKeyDown("LButton") then
    RaidGridEx.bDrag = false
    RaidGridEx.AutoScalePanel()
    RaidGridEx.handleBG:Lookup("Image_DragBox"):Hide()
    RaidGridEx.handleBG:Lookup("Image_DragBox_Disable"):Hide()
    l_0_1 = nil
    l_0_2 = nil
    RaidGridEx.CloseRaidDragPanel()
  end
  if RaidGridEx.nSteper % (RaidGridEx.nDistColorInterval or 12) == 0 then
    for l_9_10,l_9_11 in pairs(RaidGridEx.tRoleIDList) do
      RaidGridEx.UpdateMemberSpecialState(l_9_10)
    end
  end
  if RaidGridEx.bAutoScalePanel then
    RaidGridEx.frameSelf:Lookup("", "Text_Title"):Hide()
  else
    RaidGridEx.frameSelf:Lookup("", "Text_Title"):Show()
  end
  if RaidGridEx.bAutoBUFFColor then
    for l_9_15,l_9_16 in pairs(RaidGridEx.tRoleIDList) do
      RaidGridEx.UpdateMemberBuff(l_9_15)
    end
  end
  if not RaidGridEx.bShowSystemRaidPanel then
    RaidGridEx.RaidPanel_Switch(false)
  end
  local l_9_17, l_9_20 = RaidGridEx.tLastLoc
  l_9_20 = RaidGridEx
  l_9_20 = l_9_20.tLastLoc
  local l_9_18, l_9_21 = nil
  l_9_18 = RaidGridEx
  l_9_18 = l_9_18.frameSelf
  l_9_18, l_9_21 = l_9_18:GetRelPos, l_9_18
  l_9_18 = l_9_18(l_9_21)
  do
    local l_9_19, l_9_22 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_9_20.nY = l_9_21
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_9_17.nX = l_9_18
end

RaidGridEx.OnItemMouseEnter = function()
  -- upvalues: l_0_1
  local l_10_0 = this:GetName()
  if l_10_0:match("Handle_Role_") then
    RaidGridEx.EnterRoleHandle(nil, nil, this)
  end
  if RaidGridEx.bDrag then
    local l_10_1 = this.nGroupIndex
    local l_10_2 = nil
    if l_10_1 == l_0_1 then
      l_10_2 = RaidGridEx.handleBG:Lookup("Image_DragBox_Disable")
      RaidGridEx.handleBG:Lookup("Image_DragBox"):Hide()
    else
      l_10_2 = RaidGridEx.handleBG:Lookup("Image_DragBox")
      RaidGridEx.handleBG:Lookup("Image_DragBox_Disable"):Hide()
    end
  end
  if l_10_2 then
    l_10_2:Show()
    l_10_2:SetRelPos((l_10_1 * RaidGridEx.nColLength + 5) * RaidGridEx.fScale, RaidGridEx.nTopBound)
    RaidGridEx.handleBG:FormatAllItemPos()
  end
end

RaidGridEx.OnItemMouseLeave = function()
  local l_11_0 = this:GetName()
  if l_11_0:match("Handle_Role_") then
    RaidGridEx.LeaveRoleHandle(nil, nil, this)
  end
end

RaidGridEx.IsInRaid = function()
  local l_12_0 = GetClientTeam()
  if not l_12_0 or l_12_0.nGroupNum <= 1 then
    return false
  end
  return true
end

RaidGridEx.SetTarget = function(l_13_0)
  SetTarget(TARGET.PLAYER, l_13_0)
end

RaidGridEx.OpenPanel = function()
  local l_14_0 = GetClientPlayer()
  if not l_14_0 then
    return 
  end
  if not Station.Lookup("Normal/RaidGridEx") then
    local l_14_1, l_14_2, l_14_3, l_14_4, l_14_5, l_14_6, l_14_7, l_14_8, l_14_9, l_14_10 = Wnd.OpenWindow("Interface\\BF_RaidGridEx\\RaidGridEx.ini", "RaidGridEx")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGridEx.frameSelf = l_14_1
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGridEx.handleMain = l_14_1:Lookup("", "")
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGridEx.handleBG = l_14_1:Lookup("", "Handle_BG")
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGridEx.handleDummy = l_14_1:Lookup("", "Handle_Dummy")
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGridEx.handleRoles = l_14_1:Lookup("", "Handle_Roles")
  local l_14_11 = nil
  if not GetClientTeam() or GetClientTeam().nGroupNum <= 0 then
    RaidGridEx.frameSelf:Hide()
  else
    RaidGridEx.frameSelf:Show()
  end
  RaidGridEx.frameSelf:Lookup("", "Handle_Dummy"):Hide()
  RaidGridEx.CreateAllRoleHandle()
  RaidGridEx.ReloadEntireTeamInfo(true)
  RaidGridEx.AutoScalePanel()
  RaidGridEx.SetPanelPos(RaidGridEx.tLastLoc.nX, RaidGridEx.tLastLoc.nY)
  RaidGridEx.handleBG:Lookup("Image_DragBox"):Scale(RaidGridEx.fScale, RaidGridEx.fScale)
  RaidGridEx.handleBG:Lookup("Image_DragBox_Disable"):Scale(RaidGridEx.fScale, RaidGridEx.fScale)
  RaidGridEx.handleMain:FormatAllItemPos()
  if RaidGridEx.bShowInRaid and RaidGridEx.IsInTeam() ~= 2 then
    RaidGridEx.ClosePanel()
  end
  if RaidGridEx.IsInTeam() and not BigFoot_d75a98f62a179a690fa01589fb5c5202 then
    RaidGridEx.TeammatePanel_Switch(false)
  end
end

RaidGridEx.ClosePanel = function()
  local l_15_0 = Station.Lookup("Normal/RaidGridEx")
  if l_15_0 then
    l_15_0:Hide()
  end
end

RaidGridEx.IsOpened = function()
  local l_16_0 = Station.Lookup("Normal/RaidGridEx")
  if l_16_0 then
    local l_16_1, l_16_2 = l_16_0:IsVisible, l_16_0
    return l_16_1(l_16_2)
  end
end

RaidGridEx.OpenDebuffSettingPanel = function()
  if DebuffSettingPanel then
    DebuffSettingPanel.OpenPanel()
  end
end

RegisterEvent("PARTY_LEVEL_UP_RAID", function()
  if not BigFoot_b0690f1f0dd37df2f5f85ae100707f67 then
    return 
  end
  RaidGridEx.OpenPanel()
  RaidGridEx.EnableRaidPanel(RaidGridEx.bShowSystemRaidPanel)
  RaidGridEx.AutoScalePanel()
end
)
RegisterEvent("CUSTOM_DATA_LOADED", RaidGridEx.OnCustomDataLoaded)
RegisterEvent("SYNC_ROLE_DATA_END", function()
  if not BigFoot_b0690f1f0dd37df2f5f85ae100707f67 then
    return 
  end
  RaidGridEx.OpenPanel()
  RaidGridEx.EnableRaidPanel(RaidGridEx.bShowSystemRaidPanel)
  RaidGridEx.AutoScalePanel()
end
)
RegisterEvent("PARTY_UPDATE_BASE_INFO", function()
  if not BigFoot_b0690f1f0dd37df2f5f85ae100707f67 then
    return 
  end
  RaidGridEx.OpenPanel()
  RaidGridEx.EnableRaidPanel(RaidGridEx.bShowSystemRaidPanel)
  RaidGridEx.AutoScalePanel()
end
)
RegisterEvent("TEAM_CHANGE_MEMBER_GROUP", function()
  if not BigFoot_b0690f1f0dd37df2f5f85ae100707f67 then
    return 
  end
  RaidGridEx.OnMemberChangeGroup(arg0, arg1, arg3, arg2)
end
)
Hotkey.AddBinding("RaidGridEx_Toggle", "��/�ر��Ŷ���ǿ����", "�Ŷ���ǿ", function()
  local l_22_0 = RaidGridEx.bShowInRaid
  RaidGridEx.bShowInRaid = false
  if RaidGridEx.IsOpened() then
    RaidGridEx.ClosePanel()
  else
    RaidGridEx.OpenPanel()
  end
  RaidGridEx.bShowInRaid = l_22_0
end
, nil)
BFConfigPanel.RegisterMod("RaidGrid", "�Ŷӹ���", "\\ui\\image\\icon\\skill_jianghu33_03.tga", "BigFoot_b6b85020006c3110eba073d7eb8da75f")
BFConfigPanel.RegisterCheckButton("RaidGrid", "ShowRaidGrid", "�����Ŷ����", true, function(l_23_0)
  BigFoot_b0690f1f0dd37df2f5f85ae100707f67 = l_23_0
  RaidGridEx.bShowSystemRaidPanel = not l_23_0
  RaidGridEx.EnableRaidPanel(not l_23_0)
  if l_23_0 and RaidGridEx.frameSelf then
    RaidGridEx.frameSelf:Show()
  end
  do return end
  if RaidGridEx.frameSelf then
    RaidGridEx.frameSelf:Hide()
  end
end
)
BFConfigPanel.RegisterCheckButton("RaidGrid", "Openteampanel", "����ϵͳС�����", false, function(l_24_0)
  BigFoot_d75a98f62a179a690fa01589fb5c5202 = l_24_0
  RaidGridEx.TeammatePanel_Switch(l_24_0)
end
)
BFConfigPanel.RegisterCheckButton("RaidGrid", "Openraidpanel", "����ϵͳ�Ŷ����", false, function(l_25_0)
  RaidGridEx.bShowSystemRaidPanel = l_25_0
  RaidGridEx.EnableRaidPanel(l_25_0)
end
)

