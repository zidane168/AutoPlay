-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_BuffMonitorEx.lua 

if not BF_BuffMonitorEx then
  BF_BuffMonitorEx = {}
end
local l_0_0 = BF_BuffMonitorEx
local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = {}
local l_0_4 = {}
l_0_4.szName = "����"
l_0_4.bOn = true
l_0_3[1] = l_0_4
l_0_3[2], l_0_4 = l_0_4, {szName = "���໤��", bOn = true}
l_0_3[3], l_0_4 = l_0_4, {szName = "��¥��Ӱ", bOn = true}
l_0_3[4], l_0_4 = l_0_4, {szName = "���", bOn = true}
l_0_3[5], l_0_4 = l_0_4, {szName = "��ˮ����", bOn = true}
l_0_3[6], l_0_4 = l_0_4, {szName = "ˮ���޼�", bOn = true}
l_0_3[7], l_0_4 = l_0_4, {szName = "����", bOn = true}
l_0_3[8], l_0_4 = l_0_4, {szName = "����", bOn = true}
l_0_2["��"] = l_0_3
l_0_4 = {szName = "��صͰ�", bOn = true}
l_0_4 = {szName = "ȵ̤֦", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "ѸӰ", bOn = true}
l_0_2["����"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4}
l_0_4 = {szName = "�����׼�", bOn = true}
l_0_4 = {szName = "�Ƴ��", bOn = true}
l_0_4 = {szName = "ʥ��֯��", bOn = true}
l_0_4 = {szName = "�̵��׼�", bOn = true}
l_0_4 = {szName = "����׼�", bOn = true}
l_0_4 = {szName = "Ů洲���", bOn = true}
l_0_4 = {szName = "��Ϸˮ", bOn = true}
l_0_4 = {szName = "�����׼�", bOn = true}
l_0_2["�嶾"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "תǬ��", bOn = true}
l_0_4 = {szName = "��ɽ��", bOn = true}
l_0_4 = {szName = "��̫��", bOn = true}
l_0_4 = {szName = "�꼯", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "躹�����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_2["����"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "�޺�����", bOn = true}
l_0_4 = {szName = "�����", bOn = true}
l_0_4 = {szName = "�۹�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��վ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_2["����"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "��Ȫ��Ծ", bOn = true}
l_0_4 = {szName = "Х��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "��Ȥ", bOn = true}
l_0_4 = {szName = "ҹ��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_2["�ؽ�"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "Х�绢", bOn = true}
l_0_4 = {szName = "����ɽ", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "�����", bOn = true}
l_0_2["���"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "������Ⱥ", bOn = true}
l_0_4 = {szName = "����֮��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������ɢ", bOn = true}
l_0_4 = {szName = "׷������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_2["����"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "�縮", bOn = true}
l_0_4 = {szName = "�ٻ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_2["����"], l_0_3 = l_0_3, {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4}
l_0_1.TargetBuff = l_0_2
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ع��", bOn = true}
l_0_4 = {szName = "ܽ�ز���", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "ͬ��", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ͨ��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "筴�����", bOn = true}
l_0_4 = {szName = "������ŭ", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��Ӱ", bOn = true}
l_0_4 = {szName = "�Х", bOn = true}
l_0_4 = {szName = "ǧ˿", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�Ի�", bOn = true}
l_0_4 = {szName = "Ы��", bOn = true}
l_0_4 = {szName = "ǧ˿����", bOn = true}
l_0_4 = {szName = "�Х����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ݲ�", bOn = true}
l_0_4 = {szName = "�Х����", bOn = true}
l_0_4 = {szName = "��Ӱ����", bOn = true}
l_0_4 = {szName = "Ӱ��", bOn = true}
l_0_4 = {szName = "�����׼�", bOn = true}
l_0_4 = {szName = "�ù�", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "���Ĺ�", bOn = true}
l_0_4 = {szName = "�ݲй�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "˿ǣ", bOn = true}
l_0_4 = {szName = "�߹�", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4, [10] = l_0_4, [11] = l_0_4, [12] = l_0_4, [13] = l_0_4, [14] = l_0_4, [15] = l_0_4, [16] = l_0_4, [17] = l_0_4, [18] = l_0_4, [19] = l_0_4, [20] = l_0_4, [21] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�򽣹���", bOn = true}
l_0_4 = {szName = "���Ż���", bOn = true}
l_0_4 = {szName = "��̫��", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "���ɾ���", bOn = true}
l_0_4 = {szName = "���Զ���", bOn = true}
l_0_4 = {szName = "���ǹ���", bOn = true}
l_0_4 = {szName = "�巽�о�", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4, [10] = l_0_4, [11] = l_0_4, [12] = l_0_4, [13] = l_0_4, [14] = l_0_4, [15] = l_0_4}
l_0_4 = {szName = "ѣ��", bOn = true}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "���̽Կ�", bOn = true}
l_0_4 = {szName = "��ӽ�ɳ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "��ɨ����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�׹��ɽ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "Σ¥", bOn = true}
l_0_4 = {szName = "����ƾ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "ͻ", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "�ϻ��", bOn = true}
l_0_4 = {szName = "��Ӱ", bOn = true}
l_0_4 = {szName = "�Ƽ���", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "��Ѫ��", bOn = true}
l_0_4 = {szName = "÷����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����޼", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��צ", bOn = true}
l_0_4 = {szName = "���Ĵ̹�", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��ע", bOn = true}
l_0_4 = {szName = "���", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��Ĭ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4}
l_0_1.TargetDebuff, l_0_2 = l_0_2, {["��"] = l_0_3, ["����"] = l_0_3, ["�嶾"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["�ؽ�"] = l_0_3, ["���"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "���໤��", bOn = true}
l_0_4 = {szName = "��¥��Ӱ", bOn = true}
l_0_4 = {szName = "���", bOn = true}
l_0_4 = {szName = "��ˮ����", bOn = true}
l_0_4 = {szName = "ˮ���޼�", bOn = true}
l_0_4 = {szName = "����Ѫ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��صͰ�", bOn = true}
l_0_4 = {szName = "ȵ̤֦", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "ѸӰ", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��Ԫ����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "�����׼�", bOn = true}
l_0_4 = {szName = "�Ƴ��", bOn = true}
l_0_4 = {szName = "���Ͼ�", bOn = true}
l_0_4 = {szName = "ʥ��֯��", bOn = true}
l_0_4 = {szName = "�̵��׼�", bOn = true}
l_0_4 = {szName = "����׼�", bOn = true}
l_0_4 = {szName = "Ů洲���", bOn = true}
l_0_4 = {szName = "��Ϸˮ", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "תǬ��", bOn = true}
l_0_4 = {szName = "��ɽ��", bOn = true}
l_0_4 = {szName = "��̫��", bOn = true}
l_0_4 = {szName = "�꼯", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "躹�����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "�޺�����", bOn = true}
l_0_4 = {szName = "�����", bOn = true}
l_0_4 = {szName = "�۹�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��վ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "���ŭĿ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��Ȫ��Ծ", bOn = true}
l_0_4 = {szName = "Х��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "��Ȥ", bOn = true}
l_0_4 = {szName = "ҹ��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "Х�绢", bOn = true}
l_0_4 = {szName = "����ɽ", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "�����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "������Ⱥ", bOn = true}
l_0_4 = {szName = "����֮��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������ɢ", bOn = true}
l_0_4 = {szName = "׷������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4}
l_0_4 = {szName = "�縮", bOn = true}
l_0_4 = {szName = "�ٻ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4}
l_0_1.PlayerBuff, l_0_2 = l_0_2, {["��"] = l_0_3, ["����"] = l_0_3, ["�嶾"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["�ؽ�"] = l_0_3, ["���"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3}
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ع��", bOn = true}
l_0_4 = {szName = "ܽ�ز���", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ָ", bOn = true}
l_0_4 = {szName = "ͬ��", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ͨ��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "筴�����", bOn = true}
l_0_4 = {szName = "������ŭ", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��Ӱ", bOn = true}
l_0_4 = {szName = "�Х", bOn = true}
l_0_4 = {szName = "ǧ˿", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�Ի�", bOn = true}
l_0_4 = {szName = "Ы��", bOn = true}
l_0_4 = {szName = "ǧ˿����", bOn = true}
l_0_4 = {szName = "�Х����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����ݲ�", bOn = true}
l_0_4 = {szName = "�Х����", bOn = true}
l_0_4 = {szName = "��Ӱ����", bOn = true}
l_0_4 = {szName = "Ӱ��", bOn = true}
l_0_4 = {szName = "�����׼�", bOn = true}
l_0_4 = {szName = "�ù�", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4, [10] = l_0_4, [11] = l_0_4, [12] = l_0_4, [13] = l_0_4, [14] = l_0_4, [15] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�򽣹���", bOn = true}
l_0_4 = {szName = "���Ż���", bOn = true}
l_0_4 = {szName = "��̫��", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "���ɾ���", bOn = true}
l_0_4 = {szName = "���Զ���", bOn = true}
l_0_4 = {szName = "���ǹ���", bOn = true}
l_0_4 = {szName = "�巽�о�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��һ", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4, [10] = l_0_4, [11] = l_0_4, [12] = l_0_4, [13] = l_0_4, [14] = l_0_4, [15] = l_0_4, [16] = l_0_4, [17] = l_0_4}
l_0_4 = {szName = "ѣ��", bOn = true}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "���̽Կ�", bOn = true}
l_0_4 = {szName = "��ӽ�ɳ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����ʽ", bOn = true}
l_0_4 = {szName = "��ɨ����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "�׹��ɽ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "Σ¥", bOn = true}
l_0_4 = {szName = "����ƾ�", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "ͻ", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "�ϻ��", bOn = true}
l_0_4 = {szName = "��Ӱ", bOn = true}
l_0_4 = {szName = "�Ƽ���", bOn = true}
l_0_4 = {szName = "��", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4}
l_0_4 = {szName = "��Ѫ��", bOn = true}
l_0_4 = {szName = "÷����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "������", bOn = true}
l_0_4 = {szName = "����޼", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��צ", bOn = true}
l_0_4 = {szName = "���Ĵ̹�", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4, [6] = l_0_4, [7] = l_0_4, [8] = l_0_4, [9] = l_0_4}
l_0_4 = {szName = "��ע", bOn = true}
l_0_4 = {szName = "���", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_4 = {szName = "��Ĭ", bOn = true}
l_0_4 = {szName = "����", bOn = true}
l_0_3 = {[1] = l_0_4, [2] = l_0_4, [3] = l_0_4, [4] = l_0_4, [5] = l_0_4}
l_0_1.PlayerDebuff, l_0_2 = l_0_2, {["��"] = l_0_3, ["����"] = l_0_3, ["�嶾"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["�ؽ�"] = l_0_3, ["���"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3}
l_0_0.tBuffData = l_0_1
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.tBuffData"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bTarget = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bTarget"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bPlayer = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bPlayer"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bTargetBuff = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bTargetBuff"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bPlayerBuff = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bPlayerBuff"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bTargetDebuff = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bTargetDebuff"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bPlayerDebuff = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bPlayerDebuff"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.nDistance = 10
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.nDistance"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.nScale = 0.9
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.nScale"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bSelfDebuff = false
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bSelfDebuff"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bAutoSwitch = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bAutoSwitch"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.nAlpha = 250
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.nAlpha"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bAnimate = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bAnimate"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_0.bEnable = true
l_0_0 = RegisterCustomData
l_0_1 = "BF_BuffMonitorEx.bEnable"
l_0_0(l_0_1)
l_0_0 = BF_BuffMonitorEx
l_0_1 = function()
  local l_1_0 = {}
  l_1_0.szOption = "��������"
  local l_1_1 = {}
  l_1_1.szOption = "Ŀ������"
  local l_1_2 = {}
  l_1_2.szOption = "BUFF�б�"
  for l_1_6,l_1_7 in pairs(BF_BuffMonitorEx.tBuffData.TargetBuff) do
    do
      local l_1_8 = {}
      do
        l_1_8.szOption = l_1_6
        for l_1_12 = 1, #BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6] do
          do
            local l_1_13 = {}
            l_1_13.szOption = BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].szName
            l_1_13.bCheck = true
            l_1_13.bChecked = BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].bOn
            l_1_13.fnAction = function()
              -- upvalues: l_1_6 , l_1_12
              BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].bOn = not BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].bOn
              Output(BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].bOn)
            end
            local l_1_14 = {}
            do
              l_1_14.szOption = "ɾ��"
              l_1_14.fnAction = function()
                -- upvalues: l_1_6 , l_1_12
                BigFoot_Print("��������", "[" .. BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6][l_1_12].szName .. "] �Ѵ��б�ɾ����")
                table.remove(BF_BuffMonitorEx.tBuffData.TargetBuff[l_1_6], l_1_12)
              end
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_1_14 = table
              l_1_14 = l_1_14.insert
              l_1_14(l_1_8, l_1_13)
            end
          end
          table.insert(l_1_2, l_1_8)
        end
      end
      local l_1_15 = {}
      l_1_15.szOption = "����"
      l_1_15.fnAction = function()
        GetUserInput("����-BUFF��", function(l_5_0)
          BF_BuffMonitorEx.AddBuffToList("TargetBuff", l_5_0)
        end, nil, nil, nil, nil, nil)
      end
      local l_1_16 = table.insert
      local l_1_17 = l_1_2
      local l_1_18 = {}
      do
        l_1_18.bDevide = true
        l_1_16(l_1_17, l_1_18)
        l_1_16 = table
        l_1_16 = l_1_16.insert
        l_1_17 = l_1_2
        l_1_18 = l_1_15
        l_1_16(l_1_17, l_1_18)
        l_1_16 = table
        l_1_16 = l_1_16.insert
        l_1_17 = l_1_1
        l_1_18 = l_1_2
        l_1_16(l_1_17, l_1_18)
        l_1_17 = pairs
        l_1_18 = BF_BuffMonitorEx
        l_1_18 = l_1_18.tBuffData
        l_1_18 = l_1_18.TargetDebuff
        l_1_17 = l_1_17(l_1_18)
        for i_1,i_2 in l_1_17 do
          do
            local l_1_22 = {}
            l_1_22.szOption = l_1_20
            for l_1_26 = 1, #BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_20] do
              local l_1_27 = {}
              l_1_27.szOption = BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_20][l_1_26].szName
              l_1_27.bCheck = true
              l_1_27.bChecked = BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_20][l_1_26].bOn
              l_1_27.fnAction = function()
                -- upvalues: l_1_8 , l_1_14
                BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_8][l_1_14].bOn = not BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_8][l_1_14].bOn
              end
              local l_1_28 = {}
              l_1_28.szOption = "ɾ��"
              l_1_28.fnAction = function()
                -- upvalues: l_1_8 , l_1_14
                BigFoot_Print("��������", "[" .. BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_8][l_1_14].szName .. "] �Ѵ��б�ɾ����")
                table.remove(BF_BuffMonitorEx.tBuffData.TargetDebuff[l_1_8], l_1_14)
              end
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_1_28 = table
              l_1_28 = l_1_28.insert
              l_1_28(l_1_22, l_1_27)
            end
            table.insert(l_1_16, l_1_22)
          end
        end
        local l_1_29, l_1_98 = nil
        local l_1_30, l_1_99 = nil
        local l_1_31, l_1_100 = nil
        local l_1_32, l_1_101 = nil
        table.insert(l_1_29, l_1_98)
        l_1_98 = {bDevide = true}
         -- DECOMPILER ERROR: Overwrote pending register.

        table.insert(l_1_29, l_1_98)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        table.insert(l_1_29, l_1_98)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_1_30 = BuffMonitorExTarget
        l_1_30 = l_1_30.nDirection
        l_1_30 = l_1_30 == 2
        l_1_30 = function()
          BuffMonitorExTarget.nDirection = 2
        end
        local l_1_35 = nil
        l_1_99 = BuffMonitorExTarget
        l_1_99 = l_1_99.nDirection
        l_1_99 = l_1_99 == 3
        l_1_99 = function()
          BuffMonitorExTarget.nDirection = 3
        end
        local l_1_38 = nil
        l_1_31 = BuffMonitorExTarget
        l_1_31 = l_1_31.nDirection
        l_1_31 = l_1_31 == 4
        l_1_31 = function()
          BuffMonitorExTarget.nDirection = 4
        end
        l_1_99, l_1_30, l_1_98, l_1_29 = {szOption = "��������", bMCheck = true, bChecked = l_1_31, fnAction = l_1_31}, {szOption = "��������", bMCheck = true, bChecked = l_1_99, fnAction = l_1_99}, {szOption = "��������", bMCheck = true, bChecked = l_1_30, fnAction = l_1_30}, {szOption = "��������", bMCheck = true, bChecked = l_1_98, fnAction = l_1_98}
        l_1_29 = table
        l_1_29 = l_1_29.insert
        l_1_98 = l_1_1
        l_1_30 = {l_1_29, l_1_98, l_1_30, l_1_99; szOption = "���з���"}
        l_1_29(l_1_98, l_1_30)
        l_1_29 = table
        l_1_29 = l_1_29.insert
        l_1_98 = l_1_0
        l_1_30 = l_1_1
        l_1_29(l_1_98, l_1_30)
        l_1_30 = pairs
        l_1_99 = BF_BuffMonitorEx
        l_1_99 = l_1_99.tBuffData
        l_1_99 = l_1_99.PlayerBuff
        l_1_30 = l_1_30(l_1_99)
        for l_1_100,l_1_32 in l_1_30 do
          local l_1_41, l_1_42, l_1_43 = nil
          do
            local l_1_44 = nil
            l_1_35 = 1
            l_1_38 = BF_BuffMonitorEx
            l_1_38 = l_1_38.tBuffData
            l_1_38 = l_1_38.PlayerBuff
            l_1_38 = l_1_38[l_1_100]
            l_1_38 = #l_1_38
            l_1_41 = 1
            for l_1_42 = l_1_35, l_1_38, l_1_41 do
              do
                local l_1_45, l_1_46, l_1_47, l_1_48 = nil
                local l_1_49 = nil
                l_1_44 = BF_BuffMonitorEx
                l_1_44 = l_1_44.tBuffData
                l_1_44 = l_1_44.PlayerBuff
                l_1_44 = l_1_44[l_1_100]
                l_1_44 = l_1_44[l_1_42]
                l_1_44 = l_1_44.szName
                l_1_44 = BF_BuffMonitorEx
                l_1_44 = l_1_44.tBuffData
                l_1_44 = l_1_44.PlayerBuff
                l_1_44 = l_1_44[l_1_100]
                l_1_44 = l_1_44[l_1_42]
                l_1_44 = l_1_44.bOn
                l_1_44 = function()
              -- upvalues: l_1_12 , l_1_18
              BF_BuffMonitorEx.tBuffData.PlayerBuff[l_1_12][l_1_18].bOn = not BF_BuffMonitorEx.tBuffData.PlayerBuff[l_1_12][l_1_18].bOn
            end
                local l_1_50 = nil
                l_1_45 = function()
              -- upvalues: l_1_12 , l_1_18
              BigFoot_Print("��������", "[" .. BF_BuffMonitorEx.tBuffData.PlayerBuff[l_1_12][l_1_18].szName .. "] �Ѵ��б�ɾ����")
              table.remove(BF_BuffMonitorEx.tBuffData.PlayerBuff[l_1_12], l_1_18)
            end
                l_1_44 = {szOption = "ɾ��", fnAction = l_1_45}
                l_1_44 = table
                l_1_44 = l_1_44.insert
                l_1_45, l_1_101 = l_1_101, {szOption = l_1_100}
                l_1_46, l_1_43 = l_1_43, {l_1_44; szOption = l_1_44, bCheck = true, bChecked = l_1_44, fnAction = l_1_44}
                l_1_44(l_1_45, l_1_46)
              end
            end
            table.insert(l_1_98, l_1_101)
          end
           -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        local l_1_51, l_1_93, l_1_102 = nil
        local l_1_52, l_1_94, l_1_103 = nil
        local l_1_53 = nil
        local l_1_54 = nil
        table.insert(l_1_98, {bDevide = true})
        table.insert(l_1_98, {szOption = "����", fnAction = function()
          GetUserInput("����-BUFF��", function(l_15_0)
            BF_BuffMonitorEx.AddBuffToList("PlayerBuff", l_15_0)
          end, nil, nil, nil, nil, nil)
        end})
        table.insert(l_1_29, l_1_98)
        for l_1_101,i_2 in pairs(BF_BuffMonitorEx.tBuffData.PlayerDebuff) do
          local l_1_55, l_1_56, l_1_57 = nil
          local l_1_58 = nil
          l_1_51 = 1
          l_1_93 = BF_BuffMonitorEx
          l_1_93 = l_1_93.tBuffData
          l_1_93 = l_1_93.PlayerDebuff
          l_1_93 = l_1_93[l_1_101]
          l_1_93 = #l_1_93
          l_1_102 = 1
          for l_1_52 = l_1_51, l_1_93, l_1_102 do
            do
              local l_1_59, l_1_60, l_1_61, l_1_62 = nil
              local l_1_63 = nil
              l_1_103 = BF_BuffMonitorEx
              l_1_103 = l_1_103.tBuffData
              l_1_103 = l_1_103.PlayerDebuff
              l_1_103 = l_1_103[l_1_101]
              l_1_103 = l_1_103[l_1_52]
              l_1_103 = l_1_103.szName
              l_1_103 = BF_BuffMonitorEx
              l_1_103 = l_1_103.tBuffData
              l_1_103 = l_1_103.PlayerDebuff
              l_1_103 = l_1_103[l_1_101]
              l_1_103 = l_1_103[l_1_52]
              l_1_103 = l_1_103.bOn
              l_1_103 = function()
              -- upvalues: l_1_14 , l_1_20
              BF_BuffMonitorEx.tBuffData.PlayerDebuff[l_1_14][l_1_20].bOn = not BF_BuffMonitorEx.tBuffData.PlayerDebuff[l_1_14][l_1_20].bOn
            end
              local l_1_64 = nil
              l_1_53 = function()
              -- upvalues: l_1_14 , l_1_20
              BigFoot_Print("��������", "[" .. BF_BuffMonitorEx.tBuffData.PlayerDebuff[l_1_14][l_1_20].szName .. "] �Ѵ��б�ɾ����")
              table.remove(BF_BuffMonitorEx.tBuffData.PlayerDebuff[l_1_14], l_1_20)
            end
              l_1_103 = {szOption = "ɾ��", fnAction = l_1_53}
              l_1_103 = table
              l_1_103 = l_1_103.insert
              l_1_53 = {szOption = l_1_101}
              l_1_54, l_1_94 = l_1_94, {l_1_103; szOption = l_1_103, bCheck = true, bChecked = l_1_103, fnAction = l_1_103}
              l_1_103(l_1_53, l_1_54)
            end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          table.insert({szOption = "DEBUFF�б�"}, {szOption = l_1_101})
        end
        local l_1_65, l_1_95, l_1_104 = nil
        local l_1_66, l_1_96, l_1_105 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        local l_1_67, l_1_97, l_1_106 = nil
        local l_1_68, l_1_107 = nil
        table.insert({szOption = "DEBUFF�б�"}, {bDevide = true})
         -- DECOMPILER ERROR: Confused about usage of registers!

        table.insert({szOption = "DEBUFF�б�"}, {szOption = "����", fnAction = function()
          GetUserInput("����-DEBUFF��", function(l_18_0)
            BF_BuffMonitorEx.AddBuffToList("PlayerDebuff", l_18_0)
          end, nil, nil, nil, nil, nil)
        end})
         -- DECOMPILER ERROR: Confused about usage of registers!

        table.insert(l_1_29, {szOption = "DEBUFF�б�"})
        local l_1_71, l_1_108 = nil
        local l_1_74, l_1_109 = nil
        table.insert(l_1_29, {
{szOption = "��������", bMCheck = true, bChecked = BuffMonitorExPlayer.nDirection == 1, fnAction = function()
          BuffMonitorExPlayer.nDirection = 1
        end}, 
{szOption = "��������", bMCheck = true, bChecked = BuffMonitorExPlayer.nDirection == 2, fnAction = function()
          BuffMonitorExPlayer.nDirection = 2
        end}, 
{szOption = "��������", bMCheck = true, bChecked = BuffMonitorExPlayer.nDirection == 3, fnAction = function()
          BuffMonitorExPlayer.nDirection = 3
        end}, 
{szOption = "��������", bMCheck = true, bChecked = BuffMonitorExPlayer.nDirection == 4, fnAction = function()
          BuffMonitorExPlayer.nDirection = 4
        end}; szOption = "���з���"})
        table.insert(l_1_0, l_1_29)
        do
          local l_1_79, l_1_110 = nil
          local l_1_82 = nil
          local l_1_85 = nil
          table.insert({szOption = "��������"}, {
{szOption = "Lv 1", bMCheck = true, bChecked = BF_BuffMonitorEx.nScale == 0.9, fnAction = function()
          BF_BuffMonitorEx.nScale = 0.9
        end}, 
{szOption = "Lv 2", bMCheck = true, bChecked = BF_BuffMonitorEx.nScale == 1, fnAction = function()
          BF_BuffMonitorEx.nScale = 1
        end}, 
{szOption = "Lv 3", bMCheck = true, bChecked = BF_BuffMonitorEx.nScale == 1.1, fnAction = function()
          BF_BuffMonitorEx.nScale = 1.1
        end}, 
{szOption = "Lv 4", bMCheck = true, bChecked = BF_BuffMonitorEx.nScale == 1.2, fnAction = function()
          BF_BuffMonitorEx.nScale = 1.2
        end}, 
{szOption = "Lv 5", bMCheck = true, bChecked = BF_BuffMonitorEx.nScale == 1.3, fnAction = function()
          BF_BuffMonitorEx.nScale = 1.3
        end}; szOption = "ͼ���С"})
          local l_1_90 = nil
          l_1_94 = BF_BuffMonitorEx
          l_1_94 = l_1_94.nDistance
          l_1_94 = l_1_94 == 30
          l_1_94 = function()
          BF_BuffMonitorEx.nDistance = 50
        end
           -- DECOMPILER ERROR: Confused about usage of registers!

          table.insert({szOption = "��������"}, {
{szOption = "Lv 1", bMCheck = true, bChecked = BF_BuffMonitorEx.nDistance == 10, fnAction = function()
          BF_BuffMonitorEx.nDistance = 10
        end}, 
{szOption = "Lv 2", bMCheck = true, bChecked = BF_BuffMonitorEx.nDistance == 15, fnAction = function()
          BF_BuffMonitorEx.nDistance = 20
        end}, 
{szOption = "Lv 3", bMCheck = true, bChecked = BF_BuffMonitorEx.nDistance == 20, fnAction = function()
          BF_BuffMonitorEx.nDistance = 30
        end}, 
{szOption = "Lv 4", bMCheck = true, bChecked = BF_BuffMonitorEx.nDistance == 25, fnAction = function()
          BF_BuffMonitorEx.nDistance = 40
        end}, 
{szOption = "Lv 5", bMCheck = true, bChecked = l_1_94, fnAction = l_1_94}; szOption = "ͼ����"})
           -- DECOMPILER ERROR: Confused about usage of registers!

          table.insert({szOption = "��������"}, {
{szOption = BF_BuffMonitorEx.nAlpha, fnAction = function()
          local l_32_0, l_32_1 = this:GetAbsPos()
          local l_32_2, l_32_3 = this:GetSize()
          local l_32_4 = GetUserInputNumber
          local l_32_5 = BF_BuffMonitorEx.nAlpha
          local l_32_6 = 255
          do
            local l_32_7 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_32_4(l_32_5, l_32_6, l_32_7, l_32_0, l_32_1, l_32_0 + l_32_2)
          end
           -- WARNING: undefined locals caused missing assignments!
        end}; szOption = "ͼ��͸����"})
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        table.insert(l_1_0, {szOption = "��������"})
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
      return l_1_0
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0.GetMenu = l_0_1
l_0_0 = BF_BuffMonitorEx
l_0_1 = function()
  this:RegisterEvent("BUFF_UPDATE")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = BF_BuffMonitorEx
l_0_1 = function()
  if not BF_BuffMonitorEx.bEnable then
    return 
  end
  if GetLogicFrameCount() % 8 == 0 then
    local l_3_0 = GetClientPlayer()
    if not l_3_0 then
      return 
    end
    local l_3_1 = GetTargetHandle(l_3_0.GetTarget())
  if l_3_1 then
    end
  if l_3_1 then
    end
  end
  BuffMonitorExTarget.ClearTimerHandle()
end

l_0_0.OnFrameBreathe = l_0_1
l_0_0 = BF_BuffMonitorEx
l_0_1 = function(l_4_0)
  if not BF_BuffMonitorEx.bEnable then
    return 
  end
  if l_4_0 == "BUFF_UPDATE" then
    if arg0 == GetClientPlayer().dwID then
      BF_BuffMonitorEx.UpdatePlayerBuff()
    end
  elseif arg7 then
    BF_BuffMonitorEx.UpdateTargetBuff()
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = BF_BuffMonitorEx
l_0_1 = function()
  if not BF_BuffMonitorEx.bTarget then
    return 
  end
  local l_5_0 = GetClientPlayer()
  if not l_5_0 then
    return 
  end
  local l_5_1 = GetTargetHandle(l_5_0.GetTarget())
  if not l_5_1 then
    return 
  end
  BuffMonitorExTarget.ClearTimerHandle()
  if not l_5_1.GetBuffList() then
    local l_5_2, l_5_3 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_5_2 then
    for l_5_7,l_5_8 in pairs(l_5_2) do
      local l_5_4 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_5_9.bCanCancel and Table_BuffIsVisible(l_5_9.dwID, l_5_9.nLevel) and BF_BuffMonitorEx.BuffIsInMonitor("TargetBuff", Table_GetBuffName(R7_PC32.dwID, R7_PC32.nLevel)) and BF_BuffMonitorEx.bTargetBuff then
        local l_5_10 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        if IsEnemy(l_5_0.dwID, l_5_1.dwID) then
          BuffMonitorExTarget.CreateTimerHandle(l_5_9.dwID, l_5_9.nLevel, l_5_9.nStackNum, l_5_9.nEndFrame, l_5_9.bCanCancel, nil)
        end
        for l_5_8,l_5_9 in l_5_5 do
           -- DECOMPILER ERROR: Confused about usage of registers!

          if (BF_BuffMonitorEx.bSelfDebuff or not BF_BuffMonitorEx.bAutoSwitch or not IsPlayer(l_5_1.dwID)) and Table_BuffIsVisible(l_5_9.dwID, l_5_9.nLevel) and BF_BuffMonitorEx.BuffIsInMonitor("TargetDebuff", l_5_10) and l_5_9.dwSkillSrcID == l_5_0.dwID and BF_BuffMonitorEx.bTargetDebuff then
            BuffMonitorExTarget.CreateTimerHandle(l_5_9.dwID, l_5_9.nLevel, l_5_9.nStackNum, l_5_9.nEndFrame, l_5_9.bCanCancel, false)
          end
          for l_5_8,l_5_9 in l_5_5 do
             -- DECOMPILER ERROR: Confused about usage of registers!

            if Table_BuffIsVisible(l_5_9.dwID, l_5_9.nLevel) and BF_BuffMonitorEx.BuffIsInMonitor("TargetDebuff", l_5_10) and BF_BuffMonitorEx.bTargetDebuff then
              local l_5_11 = nil
               -- DECOMPILER ERROR: Overwrote pending register.

              if not IsEnemy(l_5_0.dwID, l_5_1.dwID) then
                BuffMonitorExTarget.CreateTimerHandle(l_5_9.dwID, l_5_9.nLevel, l_5_9.nStackNum, l_5_9.nEndFrame, l_5_9.bCanCancel, nil)
              end
            end
          end
           -- WARNING: missing end command somewhere! Added here
        end
         -- WARNING: missing end command somewhere! Added here
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 68 151 
end

l_0_0.UpdateTargetBuff = l_0_1
l_0_0 = BF_BuffMonitorEx
l_0_1 = function()
  if not BF_BuffMonitorEx.bPlayer then
    return 
  end
  local l_6_0 = GetClientPlayer()
  if not l_6_0 then
    return 
  end
  BuffMonitorExPlayer.ClearTimerHandle()
  if not l_6_0.GetBuffList() then
    local l_6_1, l_6_2 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_6_1 then
    for l_6_6,l_6_7 in pairs(l_6_1) do
      local l_6_3 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_6_8.bCanCancel and Table_BuffIsVisible(l_6_8.dwID, l_6_8.nLevel) and BF_BuffMonitorEx.BuffIsInMonitor("PlayerBuff", Table_GetBuffName(R6_PC25.dwID, R6_PC25.nLevel)) and BF_BuffMonitorEx.bPlayerBuff then
        BuffMonitorExPlayer.CreateTimerHandle(l_6_8.dwID, l_6_8.nLevel, l_6_8.nStackNum, l_6_8.nEndFrame, l_6_8.bCanCancel, false)
      end
      for l_6_7,l_6_8 in l_6_4 do
        if Table_BuffIsVisible(l_6_8.dwID, l_6_8.nLevel) and BF_BuffMonitorEx.BuffIsInMonitor("PlayerDebuff", Table_GetBuffName(R6_PC25.dwID, R6_PC25.nLevel)) and BF_BuffMonitorEx.bPlayerDebuff then
          local l_6_9 = nil
          BuffMonitorExPlayer.CreateTimerHandle(l_6_8.dwID, l_6_8.nLevel, l_6_8.nStackNum, l_6_8.nEndFrame, l_6_8.bCanCancel, IsBuffDispel(l_6_8.dwID, l_6_8.nLevel))
        end
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0.UpdatePlayerBuff = l_0_1
l_0_0 = function(l_7_0, l_7_1)
  local l_7_2 = 1
  local l_7_3 = 1
  local l_7_4 = {}
  while 1 do
    local l_7_5 = string.find(l_7_0, l_7_1, l_7_2)
    if not l_7_5 then
      l_7_4[l_7_3] = string.sub(l_7_0, l_7_2, string.len(l_7_0))
      do break end
    end
    l_7_4[l_7_3] = string.sub(l_7_0, l_7_2, l_7_5 - 1)
    l_7_2 = l_7_5 + 1
    l_7_3 = l_7_3 + 1
  end
  return l_7_4
end

l_0_1 = BF_BuffMonitorEx
l_0_2 = function(l_8_0, l_8_1)
  local l_8_2 = BF_BuffMonitorEx.tBuffData[l_8_0]
  local l_8_3 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  do
    local l_8_4 = false
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for l_8_8 = "����", "�嶾", "����" do
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_8_9 = "�ؽ�"
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_8_13 = "���", #"����", "����" do
        if l_8_1 == l_8_2[l_8_9][l_8_13].szName and l_8_2[l_8_9][l_8_13].bOn then
          do break end
        end
      end
    end
    return l_8_4
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1.BuffIsInMonitor = l_0_2
l_0_1 = BF_BuffMonitorEx
l_0_2 = function(l_9_0, l_9_1)
  -- upvalues: l_0_0
  local l_9_2 = l_0_0(l_9_1, "-")
  local l_9_3 = l_9_2[1]
  do
    local l_9_4 = l_0_0(string.match(l_9_2[2], "[^(].*[^)]"), ",")
    table.delete = function(l_10_0, l_10_1)
    for l_10_5 = 1, #l_10_0 do
      if l_10_0[l_10_5] == l_10_1 then
        table.remove(l_10_0, l_10_5)
        l_10_5 = l_10_5 - 1
      end
    end
    return l_10_1
  end
    do break end
    do
      local l_9_5, l_9_6, l_9_7, l_9_8, l_9_9 = pairs(l_9_4)
      for l_9_13 = 1, #BF_BuffMonitorEx.tBuffData[l_9_0][l_9_3] do
        if l_9_9 == BF_BuffMonitorEx.tBuffData[l_9_0][l_9_3][l_9_13].szName then
          table.delete(l_9_4, l_9_9)
        end
      end
    end
  end
  for l_9_17,l_9_18 in pairs(l_9_4) do
    local l_9_19 = table.insert
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_9_20 = BF_BuffMonitorEx.tBuffData[l_9_0][l_9_3]
    local l_9_21 = {}
    l_9_21.szName = l_9_18
    l_9_21.bOn = true
    l_9_19(l_9_20, l_9_21)
    l_9_19 = BigFoot_Print
    l_9_20 = "��������"
    l_9_21 = "["
    l_9_21 = l_9_21 .. l_9_18 .. "] �����ӵ��б��У�"
    l_9_19(l_9_20, l_9_21)
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1.AddBuffToList = l_0_2
l_0_1 = Wnd
l_0_1 = l_0_1.OpenWindow
l_0_2 = "Interface\\BF_BuffMonitorEx\\BF_BuffMonitorEx.ini"
l_0_3 = "BF_BuffMonitorEx"
l_0_1(l_0_2, l_0_3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_2 = "BuffMonitorEx"
l_0_3 = "��������"
l_0_4 = "\\ui\\image\\icon\\book01.tga"
l_0_1(l_0_2, l_0_3, l_0_4, "BigFoot_24b10f70baf6f2b2677ce68025899b86")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bEnable"
l_0_4 = "���÷�����������"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_10_0)
  BF_BuffMonitorEx.bEnable = l_10_0
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bTarget"
l_0_4 = "����Ŀ�귨����������"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_11_0)
  BF_BuffMonitorEx.bTarget = l_11_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bTargetBuff"
l_0_4 = "BUFF���"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_12_0)
  BF_BuffMonitorEx.bTargetBuff = l_12_0
end
, 3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bTargetDebuff"
l_0_4 = "DEBUFF���"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_13_0)
  BF_BuffMonitorEx.bTargetDebuff = l_13_0
end
, 3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bPlayer"
l_0_4 = "��������������������"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_14_0)
  BF_BuffMonitorEx.bPlayer = l_14_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bPlayerBuff"
l_0_4 = "BUFF���"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_15_0)
  BF_BuffMonitorEx.bPlayerBuff = l_15_0
end
, 3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bPlayerDebuff"
l_0_4 = "DEBUFF���"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_16_0)
  BF_BuffMonitorEx.bPlayerDebuff = l_16_0
end
, 3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bAutoSwitch"
l_0_4 = "Ŀ����NPCʱ�Զ���������ʩ�ŵ�DEBUFF"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_17_0)
  BF_BuffMonitorEx.bAutoSwitch = l_17_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "BuffMonitorEx"
l_0_3 = "bAnimate"
l_0_4 = "����ʱ��Ч"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_18_0)
  BF_BuffMonitorEx.bAnimate = l_18_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.Registerbutton
l_0_2 = "BuffMonitorEx"
l_0_3 = "btnSetting"
l_0_4 = "�������"
l_0_1(l_0_2, l_0_3, l_0_4, true, function(l_19_0)
  local l_19_1 = BF_BuffMonitorEx.GetMenu()
  PopupMenu(l_19_1)
end
, 2)

