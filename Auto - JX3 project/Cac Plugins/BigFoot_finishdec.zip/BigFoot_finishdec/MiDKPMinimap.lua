-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: MiDKPMinimap.lua 

if BigFoot then
  
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
-- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 5 

