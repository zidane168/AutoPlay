-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: classv2.lua 

local l_0_0 = {}
classv2 = function(l_1_0)
  -- upvalues: l_0_0
  local l_1_1 = {}
  l_1_1.ctor = false
  l_1_1.super = l_1_0
  l_1_1.new = function(...)
    -- upvalues: l_0_0 , l_1_1
    local l_2_1 = {}
    local l_2_2 = setmetatable
    do
      local l_2_3 = l_2_1
      l_2_2(l_2_3, {__index = l_0_0[l_1_1]})
      l_2_2 = nil
      l_2_2 = function(l_3_0, ...)
        -- upvalues: l_1_2 , l_1_1
        if l_3_0.super then
          l_1_2(l_3_0.super, ...)
        end
        if l_3_0.ctor then
          l_3_0.ctor(l_1_1, ...)
        end
      end
      l_2_3 = l_2_2
      l_2_3(l_1_1, ...)
      return l_2_1
    end
  end
  local l_1_2 = {}
  l_0_0[l_1_1] = l_1_2
  local l_1_3 = setmetatable
  local l_1_4 = l_1_1
  local l_1_5 = {}
  l_1_5.__newindex = function(l_3_0, l_3_1, l_3_2)
    -- upvalues: l_1_2
    l_1_2[l_3_1] = l_3_2
  end
  l_1_3(l_1_4, l_1_5)
  if l_1_0 then
    l_1_3 = setmetatable
    l_1_4 = l_1_2
    l_1_3(l_1_4, l_1_5)
    l_1_5 = {__index = function(l_4_0, l_4_1)
      -- upvalues: l_0_0 , l_1_0 , l_1_2
      local l_4_2 = l_0_0[l_1_0][l_4_1]
      l_1_2[l_4_1] = l_4_2
      return l_4_2
    end}
  end
  return l_1_1
end


