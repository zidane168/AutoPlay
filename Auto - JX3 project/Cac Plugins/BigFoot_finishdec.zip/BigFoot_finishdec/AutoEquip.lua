-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: AutoEquip.lua 

local l_0_0 = {}
l_0_0.BigFoot_ebdf3aa511b1fbc7a3fdf87388ebff9f = 12
l_0_0.BigFoot_5a851dad59b84174dd073ff3b0455150 = 4
l_0_0.Currentnumber = 4
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.BigFoot_2ae0db4fe0823fc414427c3e09c6e708, l_0_1 = l_0_1, {EQUIPMENT_INVENTORY.HELM, EQUIPMENT_INVENTORY.CHEST, EQUIPMENT_INVENTORY.BANGLE, EQUIPMENT_INVENTORY.WAIST, EQUIPMENT_INVENTORY.PANTS, EQUIPMENT_INVENTORY.BOOTS, EQUIPMENT_INVENTORY.AMULET, EQUIPMENT_INVENTORY.PENDANT, EQUIPMENT_INVENTORY.LEFT_RING, "10".RIGHT_RING, "11".MELEE_WEAPON, "12".RANGE_WEAPON, EQUIPMENT_INVENTORY.ARROW, EQUIPMENT_INVENTORY.BIG_SWORD}
l_0_0.BigFoot_3e1e002600c5ca2db4a511fd094485f5, l_0_1 = l_0_1, {INVENTORY_INDEX.PACKAGE, INVENTORY_INDEX.PACKAGE1, INVENTORY_INDEX.PACKAGE2, INVENTORY_INDEX.PACKAGE3, INVENTORY_INDEX.PACKAGE4}
l_0_0.EquipmentPosTab, l_0_1 = l_0_1, {[""] = EQUIPMENT_INVENTORY.MELEE_WEAPON, RangeWeaponCJ = EQUIPMENT_INVENTORY.RANGE_WEAPON, AmmoPouchCJ = EQUIPMENT_INVENTORY.ARROW, Chest = EQUIPMENT_INVENTORY.CHEST, Helm = EQUIPMENT_INVENTORY.HELM, Amulet = EQUIPMENT_INVENTORY.AMULET, LeftRing = EQUIPMENT_INVENTORY.LEFT_RING, RightRing = EQUIPMENT_INVENTORY.RIGHT_RING, Waist = EQUIPMENT_INVENTORY.WAIST, Pendant = EQUIPMENT_INVENTORY.PENDANT, Pants = EQUIPMENT_INVENTORY.PANTS, Boots = EQUIPMENT_INVENTORY.BOOTS, Bangle = EQUIPMENT_INVENTORY.BANGLE, LightSword = EQUIPMENT_INVENTORY.MELEE_WEAPON, HeavySword = EQUIPMENT_INVENTORY.BIG_SWORD, MeleeWeapon = EQUIPMENT_INVENTORY.MELEE_WEAPON, RangeWeapon = EQUIPMENT_INVENTORY.RANGE_WEAPON, AmmoPouch = EQUIPMENT_INVENTORY.ARROW}
l_0_0.CHANGEEQUIPMENT, l_0_1 = l_0_1, {[""] = EQUIPMENT_SUB.MELEE_WEAPON, RangeWeaponCJ = EQUIPMENT_SUB.RANGE_WEAPON, AmmoPouchCJ = EQUIPMENT_SUB.ARROW, Chest = EQUIPMENT_SUB.CHEST, Helm = EQUIPMENT_SUB.HELM, Amulet = EQUIPMENT_SUB.AMULET, LeftRing = EQUIPMENT_SUB.RING, RightRing = EQUIPMENT_SUB.RING, Waist = EQUIPMENT_SUB.WAIST, Pendant = EQUIPMENT_SUB.PENDANT, Pants = EQUIPMENT_SUB.PANTS, Boots = EQUIPMENT_SUB.BOOTS, Bangle = EQUIPMENT_SUB.BANGLE, [""] = EQUIPMENT_SUB.HORSE, MeleeWeapon = EQUIPMENT_SUB.MELEE_WEAPON, RangeWeapon = EQUIPMENT_SUB.RANGE_WEAPON, AmmoPouch = EQUIPMENT_SUB.ARROW}
l_0_0.EnableAltChangeEquip = true
l_0_0.Enableclosetturn = true
l_0_0.CHANGEEQUIPMENTTAB, l_0_1 = l_0_1, {}
l_0_0.Config, l_0_1 = l_0_1, {}
BF_AutoEquip = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "BF_AutoEquip.Config"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_AutoEquip.nameList"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_AutoEquip.Currentnumber"
l_0_0(l_0_1)
l_0_0 = BF_AutoEquip
l_0_1 = function()
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(200, 40, "NONE")
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1165, 75)
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa = BFWindow.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a, 200, 40)
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetBorder("THIN")
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a, "TOPLEFT", 0, 0)
  local l_1_0 = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 10, 10)
  l_1_0:SetStyle("TRANSPARENT", true)
  l_1_0:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", 0, 0)
  l_1_0:SetPoint("BOTTOMRIGHT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "BOTTOMRIGHT", 0, 0)
  l_1_0.OnMouseEnter = function()
    OutputTip("<Text>text=\"�����˿��϶���\"</Text>", 200)
  end
  l_1_0.OnMouseLeave = function()
    HideTip()
  end
  l_1_0.OnMouseDown = function()
    BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:StartMoving()
  end
  l_1_0.OnMouseUp = function()
    BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:EndMoving()
  end
  BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30, "��")
  BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35 = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30, "��")
  BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11 = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30)
  BF_AutoEquip.BigFoot_dc6b698f4c9e65db9ebdf089fafa7c09 = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30, "��")
  BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a.OnClick = function(l_6_0, l_6_1, l_6_2)
    if BF_AutoEquip.enabled then
      BF_AutoEquip.Currentnumber = BF_AutoEquip.Currentnumber + 1
      BF_AutoEquip.updateCurrentnumber()
    end
  end
  BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9 = BFFrame.new(88, 32, "NONE")
  BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:SetAbsPos(270, 20)
  BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa = BFWindow.new(BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9, 88, 32)
  BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetBorder("THIN")
  BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9, "TOPLEFT", 0, 0)
  local l_1_1 = BFButton.new(BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 10, 10)
  l_1_1:SetStyle("TRANSPARENT", true)
  l_1_1:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", 0, 0)
  l_1_1:SetPoint("BOTTOMRIGHT", BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "BOTTOMRIGHT", 0, 0)
  l_1_1.OnMouseEnter = function()
    OutputTip("<Text>text=\"�¹��л���ť�������˿��϶���\"</Text>", 200)
  end
  l_1_1.OnMouseLeave = function()
    HideTip()
  end
  l_1_1.OnMouseDown = function()
    BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:StartMoving()
  end
  l_1_1.OnMouseUp = function()
    BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:EndMoving()
  end
  for l_1_5 = 1, 3 do
    do
      BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[l_1_5] = BFButton.new(BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 25, 25, l_1_5)
      BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[l_1_5]:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (l_1_5 - 1) * 24 + 8, 4)
      BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[l_1_5]:SetStyle("TOGGLE")
      BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[l_1_5].index = l_1_5
      BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[l_1_5].OnClick = function(l_11_0, l_11_1, l_11_2)
        -- upvalues: l_1_5
        if l_11_2 == "LeftButton" then
          for l_11_6,l_11_7 in ipairs(BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f) do
            if l_11_7 ~= l_11_0 then
              l_11_7:SetToggle(false)
            end
          end
          l_11_0:SetToggle(true)
          BF_AutoEquip.Config.CurrentCloset = l_1_5
          PlayerChangeSuit(l_1_5)
        end
      end
    end
  end
  if not BF_AutoEquip.Enableclosetturn then
    BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:Hide()
  end
  BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35.OnClick = function(l_12_0, l_12_1, l_12_2)
    if BF_AutoEquip.enabled then
      BF_AutoEquip.Currentnumber = BF_AutoEquip.Currentnumber - 1
      BF_AutoEquip.updateCurrentnumber()
    end
  end
  BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11.OnClick = function(l_13_0, l_13_1, l_13_2)
    if BF_AutoEquip.enabled then
      if BF_AutoEquip.Config.DressDown then
        BF_AutoEquip.DressUp()
        l_13_0:SetText("��")
      end
    else
      BF_AutoEquip.DressDown()
      l_13_0:SetText("��")
    end
  end
  BF_AutoEquip.BigFoot_dc6b698f4c9e65db9ebdf089fafa7c09.OnClick = function()
    if BF_AutoEquip.enabled then
      BF_AutoEquip.SaveSuit()
    end
  end
  BF_AutoEquip.updateCurrentnumber()
end

l_0_0.CreateFrame = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function()
  if BF_AutoEquip.BigFoot_ebdf3aa511b1fbc7a3fdf87388ebff9f <= BF_AutoEquip.Currentnumber then
    BF_AutoEquip.Currentnumber = BF_AutoEquip.BigFoot_ebdf3aa511b1fbc7a3fdf87388ebff9f
    BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a:Disable()
    BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35:Enable()
  else
    if BF_AutoEquip.Currentnumber <= BF_AutoEquip.BigFoot_5a851dad59b84174dd073ff3b0455150 then
      BF_AutoEquip.Currentnumber = BF_AutoEquip.BigFoot_5a851dad59b84174dd073ff3b0455150
      BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a:Enable()
      BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35:Disable()
    end
  else
    BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a:Enable()
    BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35:Enable()
  end
  if BF_AutoEquip.Currentnumber < #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c then
    for l_2_3 = 1, BF_AutoEquip.Currentnumber do
      BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_3]:Show()
    end
    for l_2_7 = BF_AutoEquip.Currentnumber + 1, #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c do
      BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_7]:Hide()
    end
  else
    if #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c < BF_AutoEquip.Currentnumber then
      for l_2_11 = 1, #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c do
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_11]:Show()
      end
      for l_2_15 = #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c + 1, BF_AutoEquip.Currentnumber do
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15] = BFButton.new(BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30)
        if BF_AutoEquip.nameList[l_2_15] then
          BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15]:SetText(BF_AutoEquip.nameList[l_2_15])
        end
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15]:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (l_2_15 - 1) * 30 + 8, 5)
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15]:SetStyle("TOGGLE")
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15].index = l_2_15
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15].OnClick = function(l_3_0, l_3_1, l_3_2)
          if BF_AutoEquip.enabled then
            if l_3_2 == "LeftButton" then
              for l_3_6,l_3_7 in ipairs(BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c) do
                if l_3_7 ~= l_3_0 then
                  l_3_7:SetToggle(false)
                end
              end
              l_3_0:SetToggle(true)
            end
            if not IsShiftKeyDown() then
              BF_AutoEquip.DressUp(l_3_0.index)
            end
          elseif l_3_2 == "RightButton" then
            GetUserInput("��������װ��������һ���֣�", function(l_4_0)
            -- upvalues: l_1_0
            local l_4_1 = string.len(l_4_0)
            if l_4_1 <= 2 then
              l_1_0:SetText(l_4_0)
              BF_AutoEquip.nameList[l_1_0.index] = l_4_0
            else
              BigFoot_Print("һ����װ", "���������̫��������������")
            end
          end, false, false, false, l_3_0:GetText())
          end
        end
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15].OnMouseEnter = function(...)
          OutputTip("<Text>text=\"��ס��Shift�����ֻ�л���ť����װ����\"</Text>", 200)
        end
        BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_15].OnMouseLeave = function(...)
          HideTip()
        end
      end
    end
    do break end
  end
  if #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c == BF_AutoEquip.Currentnumber then
    for l_2_19 = 1, #BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c do
      BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_19]:Show()
    end
  end
  for l_2_23 = 1, BF_AutoEquip.Currentnumber do
    if BF_AutoEquip.nameList[l_2_23] then
      BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_23]:SetText(BF_AutoEquip.nameList[l_2_23])
    end
    BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_2_23]:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (l_2_23 - 1) * 30 + 8, 5)
  end
  BF_AutoEquip.BigFoot_a888d1e0285a96606266c9dac67c232a:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (BF_AutoEquip.Currentnumber + 0) * 30 + 8, 5)
  BF_AutoEquip.BigFoot_e7091253ddf59f0cf5ed2277cadb8b35:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (BF_AutoEquip.Currentnumber + 1) * 30 + 8, 5)
  BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (BF_AutoEquip.Currentnumber + 2) * 30 + 8, 5)
  BF_AutoEquip.BigFoot_dc6b698f4c9e65db9ebdf089fafa7c09:SetPoint("TOPLEFT", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, "TOPLEFT", (BF_AutoEquip.Currentnumber + 3) * 30 + 8, 5)
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetSize((BF_AutoEquip.Currentnumber + 4) * 30 + 16, BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:GetHeight())
  BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetSize((BF_AutoEquip.Currentnumber + 4) * 30 + 16, BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:GetHeight())
end

l_0_0.updateCurrentnumber = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function(l_3_0)
  local l_3_1 = GetClientPlayer()
  if not l_3_1 and not BF_AutoEquip.Config.DressDown then
    return 
  end
  local l_3_2, l_3_3 = nil, nil
  if l_3_0 then
    l_3_2 = BF_AutoEquip.Config.Suits[l_3_0]
    BF_AutoEquip.Config.CurrentSuit = l_3_0
    l_3_3 = BF_AutoEquip.BigFoot_2ae0db4fe0823fc414427c3e09c6e708
  else
    l_3_2 = BF_AutoEquip.Config.DressDown
    l_3_3 = BF_AutoEquip.BigFoot_df3f18044617a1cc18d02415e7152d2f
  end
  if l_3_2 then
    local l_3_4 = {}
    for l_3_8,l_3_9 in ipairs(l_3_3) do
      if l_3_2[l_3_9] then
        do break end
        do
          local l_3_10, l_3_11, l_3_12, l_3_13, l_3_14 = ipairs(BF_AutoEquip.BigFoot_3e1e002600c5ca2db4a511fd094485f5)
          do
            local l_3_15, l_3_16, l_3_17 = l_3_1.GetBoxSize(l_3_14) or 0
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_3_15 and l_3_15 > 0 then
            for l_3_21 = 0, l_3_15 - 1 do
              local l_3_18 = nil
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: unhandled construct in 'if'

               -- DECOMPILER ERROR: unhandled construct in 'if'

              if ((l_3_1.GetItem(l_3_14, R19_PC59).nBindType ~= ITEM_BIND.BIND_ON_EQUIPPED and l_3_1.GetItem(l_3_14, R19_PC59).nBindType ~= ITEM_BIND.BIND_ON_PICKED) or l_3_1.GetItem(l_3_14, R19_PC59).bBind) and type(l_3_2[l_3_9]) == "table" and l_3_2[l_3_9][1] == l_3_1.GetItem(l_3_14, R19_PC59).dwTabType and l_3_2[l_3_9][2] == l_3_1.GetItem(l_3_14, R19_PC59).dwIndex then
                OnExchangeItem(l_3_14, l_3_22, INVENTORY_INDEX.EQUIP, l_3_9)
              end
              do return end
              if l_3_2[l_3_9] == l_3_1.GetItem(l_3_14, R19_PC59).szName then
                OnExchangeItem(l_3_14, l_3_22, INVENTORY_INDEX.EQUIP, l_3_9)
              end
            end
          end
        end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    else
      table.insert(l_3_4, l_3_9)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
  end
  local l_3_23, l_3_31 = nil
  do
    local l_3_24, l_3_32 = nil
    for l_3_31,l_3_24 in pairs(l_3_4) do
      do
        local l_3_25, l_3_26, l_3_27, l_3_28, l_3_29 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        if 1 <= l_3_32 then
          l_3_25 = INVENTORY_INDEX
          l_3_25 = l_3_25.EQUIP
          l_3_26 = l_3_24
           -- DECOMPILER ERROR: Overwrote pending register.

          local l_3_30 = nil
        end
        if l_3_32 then
          l_3_25 = OnExchangeItem
          l_3_26 = INVENTORY_INDEX
          l_3_26 = l_3_26.EQUIP
          l_3_27 = l_3_24
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_3_28 = BF_AutoEquip.GetEmptyBagPos(#l_3_4)[1]
          l_3_28 = l_3_28.BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_3_29 = BF_AutoEquip.GetEmptyBagPos(#l_3_4)[1]
          l_3_29 = l_3_29.BigFoot_a52531bbac1607c38b2f3adb878fd871
          l_3_25(l_3_26, l_3_27, l_3_28, l_3_29)
           -- DECOMPILER ERROR: Confused about usage of registers!

        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_3_0 then
      BigFoot_Print("һ����װ", "�л�����װ<" .. BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[BF_AutoEquip.Config.CurrentSuit]:GetText() .. ">��")
    else
      BigFoot_Print("һ����װ", string.format("װ���Ѵ��ϡ�"))
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11:SetText("��")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- DECOMPILER ERROR: Overwrote pending register.

else
  l_3_4("һ����װ", 1 + 1)
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end

l_0_0.DressUp = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function()
  local l_4_0 = GetClientPlayer()
  if not l_4_0 then
    return 
  end
  local l_4_1 = BF_AutoEquip.GetEmptyBagPos(#BF_AutoEquip.BigFoot_df3f18044617a1cc18d02415e7152d2f)
  local l_4_2 = 1
  BF_AutoEquip.Config.DressDown = {}
  for l_4_6,l_4_7 in ipairs(BF_AutoEquip.BigFoot_df3f18044617a1cc18d02415e7152d2f) do
    local l_4_8 = l_4_0.GetItem(INVENTORY_INDEX.EQUIP, l_4_7)
    if l_4_8 and l_4_2 <= #l_4_1 then
      local l_4_9 = BF_AutoEquip.Config.DressDown
      local l_4_10 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_4_9(l_4_10, l_4_8.dwTabType, l_4_8.dwIndex.BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3, l_4_1[l_4_2].BigFoot_a52531bbac1607c38b2f3adb878fd871)
      l_4_2 = l_4_2 + 1
    end
  end
  BigFoot_Print("һ����װ", "װ����ж�¡�")
end

l_0_0.DressDown = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function()
  local l_5_0 = GetClientPlayer()
  if not l_5_0 or not BF_AutoEquip.Config.CurrentSuit then
    return 
  end
  if not BF_AutoEquip.Config.Suits then
    BF_AutoEquip.Config.Suits = {}
  end
  local l_5_1 = BF_AutoEquip.Config.Suits
  local l_5_2 = BF_AutoEquip.Config.CurrentSuit
  l_5_1[l_5_2] = {}
  l_5_1 = BF_AutoEquip
  l_5_1 = l_5_1.Config
  l_5_1 = l_5_1.Suits
  l_5_2 = BF_AutoEquip
  l_5_2 = l_5_2.Config
  l_5_2 = l_5_2.CurrentSuit
  l_5_1 = l_5_1[l_5_2]
  l_5_2 = ipairs
  l_5_2 = l_5_2(BF_AutoEquip.BigFoot_2ae0db4fe0823fc414427c3e09c6e708)
  for l_5_6,i_2 in l_5_2 do
    local l_5_7 = l_5_0.GetItem(INVENTORY_INDEX.EQUIP, l_5_6)
    if l_5_7 then
      local l_5_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
  end
  BigFoot_Print("һ����װ", "��װ<" .. BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[BF_AutoEquip.Config.CurrentSuit]:GetText() .. ">����ɹ���")
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.SaveSuit = l_0_1
l_0_0 = function(l_6_0)
  return 0
end

GetBagContainType = l_0_0
l_0_0 = BF_AutoEquip
l_0_1 = function(l_7_0)
  local l_7_1 = GetClientPlayer()
  if not l_7_1 then
    return 
  end
  local l_7_2 = {}
  local l_7_3 = 1
  for l_7_7,l_7_8 in ipairs(BF_AutoEquip.BigFoot_3e1e002600c5ca2db4a511fd094485f5) do
    if not l_7_1.GetBoxSize(l_7_8) then
      local l_7_9, l_7_10 = GetBagContainType(l_7_8) ~= 0 or 0
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_7_9 > 0 then
      local l_7_11 = nil
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if 0 < l_7_11 then
      local l_7_12 = nil
      do
        if not l_7_1.GetItem(l_7_8, 0) then
          local l_7_13 = nil
          l_7_2[l_7_3] = {BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3 = l_7_8, BigFoot_a52531bbac1607c38b2f3adb878fd871 = l_7_12}
          l_7_3 = l_7_3 + 1
        end
        if l_7_0 < l_7_3 then
          return l_7_2
        end
      end
      l_7_12 = l_7_12 + 1
    end
  end
  l_7_8 = l_7_8 + 1
end
return l_7_2
end

l_0_0.GetEmptyBagPos = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function()
  BF_AutoEquip.CreateFrame()
  BigFoot.RegisterFrame("position", "AutoEquip", BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a)
  BigFoot.RegisterFrame("position", "AutoEquip2", BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9)
end

l_0_0.Init = l_0_1
l_0_0 = BF_AutoEquip
l_0_0 = l_0_0.Init
l_0_0()
l_0_0 = BF_AutoEquip
l_0_1 = function()
  BF_AutoEquip.BigFoot_f238af950add5b1c1ff900645f3ca5fb()
  if IsAltKeyDown() and this:GetType() == "Box" and BF_AutoEquip.EnableAltChangeEquip then
    local l_9_0 = this:GetName()
    local l_9_1 = string.sub(l_9_0, 5, -1)
    if not BF_AutoEquip.EquipmentPosTab[l_9_1] then
      return 
    end
    BF_AutoEquip.GetChangleEquipment(l_9_1)
    local l_9_2, l_9_3 = this:GetAbsPos()
    local l_9_4, l_9_5 = this:GetSize()
    BF_AutoEquip.OpenChangeUI(l_9_2, l_9_3, l_9_4, l_9_5, l_9_1)
  end
end

l_0_0.CharacterPanelOnItemMouseEnter = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function(l_10_0)
  local l_10_1 = nil
  do
    local l_10_2 = GetClientPlayer()
    if not CharacterPanel_GetItemBox(INVENTORY_INDEX.EQUIP, BF_AutoEquip.EquipmentPosTab[l_10_0]) then
      return 
    end
    if CharacterPanel_GetItemBox(INVENTORY_INDEX.EQUIP, BF_AutoEquip.EquipmentPosTab[l_10_0]):IsEmpty() then
      l_10_1 = true
    end
    do break end
    do
      local l_10_3, l_10_4, l_10_5, l_10_6, l_10_7 = , ipairs(BF_AutoEquip.BigFoot_3e1e002600c5ca2db4a511fd094485f5)
       -- DECOMPILER ERROR: Confused about usage of registers!

      do
        local l_10_8, l_10_9, l_10_10 = , l_10_2.GetBoxSize(R8_PC26) or 0
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_10_9 and l_10_9 > 0 then
        for l_10_14 = 0, l_10_9 - 1 do
          local l_10_11, l_10_12 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_10_2.GetItem(l_10_11, R13_PC41) and l_10_2.GetItem(l_10_11, R13_PC41).nGenre == ITEM_GENRE.EQUIPMENT then
             -- DECOMPILER ERROR: unhandled construct in 'if'

            if l_10_0 == "LightSword" and GetWeapenType(l_10_2.GetItem(l_10_11, R13_PC41).nDetail) == "�̱���" then
              local l_10_17 = nil
              local l_10_18 = l_10_2.GetItem(l_10_11, R13_PC41).nSub
              local l_10_19 = table.insert
              l_10_19(BF_AutoEquip.CHANGEEQUIPMENTTAB, {l_10_11, l_10_16})
            end
            do return end
             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_10_0 == "HeavySword" and GetWeapenType(l_10_17.nDetail) == "�ر���" then
              local l_10_20 = nil
              local l_10_21 = nil
              local l_10_22 = table.insert
              l_10_22(BF_AutoEquip.CHANGEEQUIPMENTTAB, {l_10_11, l_10_16})
            end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          if BF_AutoEquip.CHANGEEQUIPMENT[l_10_0] and l_10_21 == BF_AutoEquip.CHANGEEQUIPMENT[l_10_0] then
            local l_10_23 = nil
            local l_10_24 = nil
            local l_10_25 = table.insert
            l_10_25(BF_AutoEquip.CHANGEEQUIPMENTTAB, {l_10_11, l_10_16})
          end
        end
      end
    end
  end
  if not l_10_1 then
    local l_10_26 = nil
    local l_10_27 = table.insert
    do
      local l_10_28 = BF_AutoEquip.CHANGEEQUIPMENTTAB
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_10_27(l_10_28, {-1, -1})
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end

l_0_0.GetChangleEquipment = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4)
  BF_AutoEquip.CreatChangeUIFarm(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4)
  if not BF_AutoEquip.ChangeUIFarmHandle then
    return 
  end
  BF_AutoEquip.UpdateItemPos(BF_AutoEquip.BigFoot_43366e390d55f02d877888a67dc492ca, BF_AutoEquip.BigFoot_f79e7c7afc8ed54f61e8744e8f92185b, BF_AutoEquip.BigFoot_9a786eb83ace45dfbf1d5bd10a5ad201)
  local l_11_5, l_11_6 = BF_AutoEquip.ChangeUIFarmHandle:GetSize()
  BF_AutoEquip.ChangeUIFarm:SetSize(l_11_5, l_11_6)
  BF_AutoEquip.ChangeUIFarm:BringToTop()
end

l_0_0.OpenChangeUI = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function(l_12_0, l_12_1, l_12_2)
  BF_AutoEquip.ChangeUIFarmHandle:Clear()
  local l_12_3 = GetClientPlayer()
  if #BF_AutoEquip.CHANGEEQUIPMENTTAB == 0 then
    BF_AutoEquip.ChangeUIFarmHandle:SetSize(0, 0)
    return 
  end
  for l_12_7,l_12_8 in pairs(BF_AutoEquip.CHANGEEQUIPMENTTAB) do
    local l_12_9 = l_12_3.GetItem(l_12_8[1], l_12_8[2])
    do
      if l_12_9 then
        BF_AutoEquip.ChangeUIFarmHandle:AppendItemFromString("<box>w=" .. l_12_0 .. " h=" .. l_12_1 .. " eventid=272 postype=0</box>")
        local l_12_10 = BF_AutoEquip.ChangeUIFarmHandle:Lookup(BF_AutoEquip.ChangeUIFarmHandle:GetItemCount() - 1)
        do
          l_12_10.index = BF_AutoEquip.ChangeUIFarmHandle:GetItemCount()
          l_12_10.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_12_9
          l_12_10.BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3 = l_12_8[1]
          l_12_10.BigFoot_a52531bbac1607c38b2f3adb878fd871 = l_12_8[2]
          l_12_10:SetRelPos((l_12_10.index - 1) * l_12_0, 0)
          l_12_10:SetObject(UI_OBJECT_ITEM, l_12_9.nUiId, l_12_8[1], l_12_8[2], l_12_9.nVersion, l_12_9.dwTabType, l_12_9.dwIndex)
          l_12_10:SetObjectIcon(Table_GetItemIconID(l_12_9.nUiId))
          l_12_10.OnItemMouseEnter = function()
            -- upvalues: l_12_9
            this:SetObjectMouseOver(1)
            local l_13_0, l_13_1 = this:GetAbsPos()
            local l_13_2, l_13_3 = this:GetSize()
            local l_13_4 = "<Text>text=\"���ֱ��װ����װ��\n\" r=0 g=255 b=0</Text>"
            local l_13_5 = GetItemTip(l_12_9)
            l_13_4 = l_13_4 .. l_13_5
            local l_13_6 = OutputTip
            local l_13_7 = l_13_4
            local l_13_8 = 300
            do
              local l_13_9 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_13_6(l_13_7, l_13_8, l_13_9)
            end
             -- WARNING: undefined locals caused missing assignments!
          end
          l_12_10.OnItemMouseLeave = function()
            HideTip()
            this:SetObjectMouseOver(0)
          end
          l_12_10.OnItemLButtonClick = function()
            -- upvalues: l_12_10 , l_12_2
            OnExchangeItem(l_12_10.BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3, l_12_10.BigFoot_a52531bbac1607c38b2f3adb878fd871, INVENTORY_INDEX.EQUIP, BF_AutoEquip.EquipmentPosTab[l_12_2])
          end
          BF_AutoEquip.ChangeUIFarmHandle:FormatAllItemPos()
        end
      else
        BF_AutoEquip.ChangeUIFarmHandle:AppendItemFromString("<box>w=" .. l_12_0 .. " h=" .. l_12_1 .. " eventid=272 postype=0</box>")
        local l_12_11 = BF_AutoEquip.ChangeUIFarmHandle:Lookup(BF_AutoEquip.ChangeUIFarmHandle:GetItemCount() - 1)
        l_12_11.index = BF_AutoEquip.ChangeUIFarmHandle:GetItemCount()
        l_12_11:SetRelPos((l_12_11.index - 1) * l_12_0, 0)
        l_12_11:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_12_11.index)
        l_12_11:SetObjectIcon(374)
        l_12_11.OnItemMouseEnter = function()
          this:SetObjectMouseOver(1)
          local l_16_0, l_16_1 = this:GetAbsPos()
          local l_16_2, l_16_3 = this:GetSize()
          local l_16_4 = "<Text>text=\"���ֱ�����¸�װ��\n\" r=0 g=255 b=0</Text>"
          local l_16_5 = OutputTip
          local l_16_6 = l_16_4
          local l_16_7 = 300
          do
            local l_16_8 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_16_5(l_16_6, l_16_7, l_16_8)
          end
           -- WARNING: undefined locals caused missing assignments!
        end
        l_12_11.OnItemMouseLeave = function()
          HideTip()
          this:SetObjectMouseOver(0)
        end
        l_12_11.OnItemLButtonClick = function()
          -- upvalues: l_12_2
          local l_18_0 = BF_AutoEquip.GetEmptyBagPos(1)
          OnExchangeItem(INVENTORY_INDEX.EQUIP, BF_AutoEquip.EquipmentPosTab[l_12_2], l_18_0[1].BigFoot_8ac8e3aaa0a034b14dfe57ad7bdaa2d3, l_18_0[1].BigFoot_a52531bbac1607c38b2f3adb878fd871)
        end
      end
    end
  end
  BF_AutoEquip.ChangeUIFarmHandle:FormatAllItemPos()
  BF_AutoEquip.ChangeUIFarmHandle:SetSizeByAllItemSize()
end

l_0_0.UpdateItemPos = l_0_1
l_0_0 = BF_AutoEquip
l_0_1 = function(l_13_0, l_13_1, l_13_2, l_13_3, l_13_4)
  if not BF_AutoEquip.ChangeUIFarm then
    BF_AutoEquip.ChangeUIFarm = Wnd.OpenWindow("interface\\BF_AutoEquip\\AutoEquip.ini", "CreatChangeUIFarm")
    BF_AutoEquip.ChangeUIFarm:RegisterEvent("EQUIP_ITEM_UPDATE")
    BF_AutoEquip.ChangeUIFarm.OnEvent = function(l_14_0)
      if l_14_0 == "EQUIP_ITEM_UPDATE" and BF_AutoEquip.ChangeUIFarm.bShow then
        BF_AutoEquip.GetChangleEquipment(BF_AutoEquip.BigFoot_9a786eb83ace45dfbf1d5bd10a5ad201)
        BF_AutoEquip.UpdateItemPos(BF_AutoEquip.BigFoot_43366e390d55f02d877888a67dc492ca, BF_AutoEquip.BigFoot_f79e7c7afc8ed54f61e8744e8f92185b, BF_AutoEquip.BigFoot_9a786eb83ace45dfbf1d5bd10a5ad201)
      end
    end
    BF_AutoEquip.ChangeUIFarm.OnKillFocus = function()
      BF_AutoEquip.ChangeUIFarm:Hide()
    end
    BF_AutoEquip.ChangeUIFarm.OnFrameBreathe = function()
      if not IsAltKeyDown() then
        BF_AutoEquip.ChangeUIFarm:Hide()
        BF_AutoEquip.ChangeUIFarm.bShow = false
      end
    end
  end
  BF_AutoEquip.ChangeUIFarm:Show()
  BF_AutoEquip.ChangeUIFarm.bShow = true
  BF_AutoEquip.ChangeUIFarm:SetAbsPos(l_13_0 + l_13_2 + 5, l_13_1)
  BF_AutoEquip.BigFoot_9a786eb83ace45dfbf1d5bd10a5ad201 = l_13_4
  BF_AutoEquip.BigFoot_b254e387cf58e982ba24fcb3e8a63995 = l_13_0
  BF_AutoEquip.BigFoot_a0f453fd098c0b0fda780f69cda6ffbf = l_13_1
  BF_AutoEquip.BigFoot_43366e390d55f02d877888a67dc492ca = l_13_2
  BF_AutoEquip.BigFoot_f79e7c7afc8ed54f61e8744e8f92185b = l_13_3
  BF_AutoEquip.ChangeUIFarmHandle = BF_AutoEquip.ChangeUIFarm:Lookup("", "")
end

l_0_0.CreatChangeUIFarm = l_0_1
l_0_0 = RegisterEvent
l_0_1 = "CUSTOM_DATA_LOADED"
l_0_0(l_0_1, function()
  if arg0 ~= "Role" then
    return 
  end
  if BF_AutoEquip.Config.DressDown then
    BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11:SetText("��")
  else
    BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11:SetText("��")
  end
  if not BF_AutoEquip.Config.Suits then
    BF_AutoEquip.Config.Suits = {}
  end
  if BF_AutoEquip.Config.CurrentSuit then
    BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[BF_AutoEquip.Config.CurrentSuit]:SetToggle(true)
  else
    BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[1]:SetToggle(true)
    BF_AutoEquip.Config.CurrentSuit = 1
  end
  if BF_AutoEquip.Config.CurrentCloset then
    BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[BF_AutoEquip.Config.CurrentCloset]:SetToggle(true)
  else
    BF_AutoEquip.BigFoot_9b4adaa19278b1604d50265a01424d2f[1]:SetToggle(true)
    BF_AutoEquip.Config.CurrentCloset = 1
  end
  BF_AutoEquip.updateCurrentnumber()
end
)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterMod
l_0_1 = "AutoEquip"
l_0_0(l_0_1, "һ����װ", "\\ui\\image\\icon\\def_coat08.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "AutoEquip"
l_0_0(l_0_1, "EnableAutoEquip", "����һ����װ", false, function(l_15_0, l_15_1)
  if l_15_0 then
    BF_AutoEquip.enabled = true
    BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
    for l_15_5 = 1, BF_AutoEquip.BigFoot_ebdf3aa511b1fbc7a3fdf87388ebff9f do
      do
        if l_15_5 == 1 then
          Hotkey.AddBinding("BF_AUTOEQUIP_" .. l_15_5, "��װ" .. l_15_5, "һ����װ", function()
          -- upvalues: l_15_5
          BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_15_5].OnClick(BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_15_5], __, "LeftButton")
        end, nil)
        else
          Hotkey.AddBinding("BF_AUTOEQUIP_" .. l_15_5, "��װ" .. l_15_5, nil, function()
          -- upvalues: l_15_5
          BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_15_5].OnClick(BF_AutoEquip.BigFoot_1211d8bc63d5b7c47d22260e48f7d89c[l_15_5], __, "LeftButton")
        end, nil)
        end
      end
    end
    Hotkey.AddBinding("BF_AUTOEQUIP_DRESSDOWN", "ж��װ��", nil, function()
      BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11.OnClick(BF_AutoEquip.BigFoot_afdd355977d42801d054a8cef1c2ba11)
    end, nil)
    Hotkey.AddBinding("BF_AUTOEQUIP_SAVE", "����", nil, function()
      BF_AutoEquip.BigFoot_dc6b698f4c9e65db9ebdf089fafa7c09.OnClick(BF_AutoEquip.BigFoot_dc6b698f4c9e65db9ebdf089fafa7c09)
    end, nil)
    BF_AutoEquip.updateCurrentnumber()
  else
    BF_AutoEquip.enabled = nil
    BF_AutoEquip.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "AutoEquip"
l_0_0(l_0_1, "Enablecloset", "��������¹�", true, function(l_16_0, l_16_1)
  if l_16_0 then
    if BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9 then
      BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:Show()
    end
    BF_AutoEquip.Enableclosetturn = l_16_0
  else
    BF_AutoEquip.BigFoot_849671197fbb43fe43949938fc8a72e9:Hide()
    BF_AutoEquip.Enableclosetturn = l_16_0
  end
end
)
l_0_0 = BigFoot
l_0_0 = l_0_0.RegisterMinimapButton
l_0_1 = "Interface\\BF_AutoEquip\\autoequip.tga"
l_0_0(l_0_1, "<Text>text=\"��/�ر�һ����װ����\"</Text>", "AutoEquip", "EnableAutoEquip")

