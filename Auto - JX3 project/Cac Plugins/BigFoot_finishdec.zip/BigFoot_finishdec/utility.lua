-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: utility.lua 

BF_UTILITY_FRAME = BFFrame.new(0, 0, "NONE")
local l_0_0 = {}
local l_0_1 = {}
local l_0_2 = "����"
local l_0_3 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {35, 89, 255}
l_0_0[3], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {158, 6, 106}
l_0_0[2], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {0, 255, 255}
l_0_0[4], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {255, 128, 204}
l_0_0[5], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {255, 128, 0}
l_0_0[1], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {34, 86, 171}
l_0_0[6], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {255, 252, 0}
l_0_0[8], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {171, 212, 100}
l_0_0[7], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {}
l_0_0[9], l_0_1 = l_0_1, {l_0_2, l_0_3}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_3 = {}
l_0_0[10], l_0_1 = l_0_1, {l_0_2, l_0_3}
BF_ClassColor = l_0_0
l_0_0 = function(l_1_0)
  for l_1_4,l_1_5 in pairs(BF_ClassColor) do
    if l_1_4 == l_1_0 then
      local l_1_6 = unpack
      local l_1_7 = l_1_5[2]
      return l_1_6(l_1_7)
    end
  end
end

BF_GetClassColor = l_0_0
l_0_0 = KG_Table
l_0_0 = l_0_0.Load
l_0_1 = "\\settings\\Craft\\Read\\book.tab"
local l_0_4 = {}
l_0_4.f = "i"
l_0_4.t = "SubID"
local l_0_5 = {}
l_0_5.f = "s"
l_0_5.t = "Name"
local l_0_6 = {}
l_0_6.f = "i"
l_0_6.t = "CostStamina"
local l_0_7 = {}
l_0_7.f = "i"
l_0_7.t = "ProfessionID"
local l_0_8 = {}
l_0_8.f = "i"
l_0_8.t = "RequireLevel"
local l_0_9 = {}
l_0_9.f = "i"
l_0_9.t = "ToolItemType"
local l_0_10 = {}
l_0_10.f = "i"
l_0_10.t = "ToolItemIndex"
local l_0_11 = {}
l_0_11.f = "i"
l_0_11.t = "EquipmentType"
local l_0_12 = {}
l_0_12.f = "i"
l_0_12.t = "PrepareFrame"
local l_0_13 = {}
l_0_13.f = "i"
l_0_13.t = "PlayerExp"
local l_0_14 = {}
l_0_14.f = "i"
l_0_14.t = "ProfessionExp"
local l_0_15 = {}
l_0_15.f = "i"
l_0_15.t = "ExtendProfessionID1"
local l_0_16 = {}
l_0_16.f = "i"
l_0_16.t = "ExtendExp1"
local l_0_17 = {}
l_0_17.f = "i"
l_0_17.t = "ExtendProfessionID2"
local l_0_18 = {}
l_0_18.f = "i"
l_0_18.t = "ExtendExp2"
local l_0_19 = {}
l_0_19.f = "i"
l_0_19.t = "CreateItemTab"
local l_0_20 = {}
l_0_20.f = "i"
l_0_20.t = "CreateItemIndex"
local l_0_21 = {}
l_0_21.f = "i"
l_0_21.t = "CreateItemStackNum"
local l_0_22 = {}
l_0_22.f = "i"
l_0_22.t = "BuffID"
local l_0_23 = {}
l_0_23.f = "i"
l_0_23.t = "BuffLevel"
local l_0_24 = {}
l_0_24.f = "i"
l_0_24.t = "Train"
local l_0_25 = {}
l_0_25.f = "s"
l_0_25.t = "ScriptName"
l_0_3 = {f = "i", t = "ID"}
l_0_3 = FILE_OPEN_MODE
l_0_3 = l_0_3.NORMAL
l_0_0, l_0_2 = l_0_0(l_0_1, l_0_2, l_0_3), {l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25}
local l_0_26 = {}
l_0_26.f = "i"
l_0_26.t = "RequireItemIndex4"
local l_0_27 = {}
l_0_27.f = "i"
l_0_27.t = "RequireItemCount4"
local l_0_28 = {}
l_0_28.f = "i"
l_0_28.t = "RequireItemType5"
local l_0_29 = {}
l_0_29.f = "i"
l_0_29.t = "RequireItemIndex5"
local l_0_30 = {}
l_0_30.f = "i"
l_0_30.t = "RequireItemCount5"
local l_0_31 = {}
l_0_31.f = "i"
l_0_31.t = "RequireItemType6"
local l_0_32 = {}
l_0_32.f = "i"
l_0_32.t = "RequireItemIndex6"
local l_0_33 = {}
l_0_33.f = "i"
l_0_33.t = "RequireItemCount6"
local l_0_34 = {}
l_0_34.f = "i"
l_0_34.t = "RequireItemType7"
local l_0_35 = {}
l_0_35.f = "i"
l_0_35.t = "RequireItemIndex7"
local l_0_36 = {}
l_0_36.f = "i"
l_0_36.t = "RequireItemCount7"
local l_0_37 = {}
l_0_37.f = "i"
l_0_37.t = "RequireItemType8"
local l_0_38 = {}
l_0_38.f = "i"
l_0_38.t = "RequireItemIndex8"
local l_0_39 = {}
l_0_39.f = "i"
l_0_39.t = "RequireItemCount8"
local l_0_40 = {}
l_0_40.f = "i"
l_0_40.t = "CreateItemType1"
local l_0_41 = {}
l_0_41.f = "i"
l_0_41.t = "CreateItemIndex1"
local l_0_42 = {}
l_0_42.f = "i"
l_0_42.t = "CreateItemMin1"
local l_0_43 = {}
l_0_43.f = "i"
l_0_43.t = "CreateItemMax1"
local l_0_44 = {}
l_0_44.f = "i"
l_0_44.t = "CreateItemProbability1"
local l_0_45 = {}
l_0_45.f = "i"
l_0_45.t = "CreateItemType2"
local l_0_46 = {}
l_0_46.f = "i"
l_0_46.t = "CreateItemIndex2"
local l_0_47 = {}
l_0_47.f = "i"
l_0_47.t = "CreateItemMin2"
local l_0_48 = {}
l_0_48.f = "i"
l_0_48.t = "CreateItemMax2"
local l_0_49 = {}
l_0_49.f = "i"
l_0_49.t = "CreateItemProbability2"
local l_0_50 = {}
l_0_50.f = "i"
l_0_50.t = "CreateItemType3"
local l_0_51 = {}
l_0_51.f = "i"
l_0_51.t = "CreateItemIndex3"
l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6, l_0_5, l_0_4, l_0_3, l_0_2 = {f = "i", t = "RequireItemType4"}, {f = "i", t = "RequireItemCount3"}, {f = "i", t = "RequireItemIndex3"}, {f = "i", t = "RequireItemType3"}, {f = "i", t = "RequireItemCount2"}, {f = "i", t = "RequireItemIndex2"}, {f = "i", t = "RequireItemType2"}, {f = "i", t = "RequireItemCount1"}, {f = "i", t = "RequireItemIndex1"}, {f = "i", t = "RequireItemType1"}, {f = "i", t = "EnchantID"}, {f = "s", t = "szBelong"}, {f = "i", t = "PrepareFrame"}, {f = "i", t = "Exp"}, {f = "i", t = "EquipmentType"}, {f = "i", t = "ToolItemIndex"}, {f = "i", t = "ToolItemType"}, {f = "i", t = "RequireDoodad"}, {f = "i", t = "RequireBranchID"}, {f = "i", t = "RequireLevel"}, {f = "i", t = "ProfessionID"}, {f = "i", t = "CostStamina"}, {f = "s", t = "szName"}, {f = "i", t = "ID"}
l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6, l_0_5, l_0_4, l_0_3, l_0_2 = {f = "i", t = "CoolDownID"}, {f = "s", t = "ScriptName"}, {f = "i", t = "_Quality"}, {f = "i", t = "CreateItemProbability8"}, {f = "i", t = "CreateItemMax8"}, {f = "i", t = "CreateItemMin8"}, {f = "i", t = "CreateItemIndex8"}, {f = "i", t = "CreateItemType8"}, {f = "i", t = "CreateItemProbability7"}, {f = "i", t = "CreateItemMax7"}, {f = "i", t = "CreateItemMin7"}, {f = "i", t = "CreateItemIndex7"}, {f = "i", t = "CreateItemType7"}, {f = "i", t = "CreateItemProbability6"}, {f = "i", t = "CreateItemMax6"}, {f = "i", t = "CreateItemMin6"}, {f = "i", t = "CreateItemIndex6"}, {f = "i", t = "CreateItemType6"}, {f = "i", t = "CreateItemProbability5"}, {f = "i", t = "CreateItemMax5"}, {f = "i", t = "CreateItemMin5"}, {f = "i", t = "CreateItemIndex5"}, {f = "i", t = "CreateItemType5"}, {f = "i", t = "CreateItemProbability4"}, {f = "i", t = "CreateItemMax4"}, {f = "i", t = "CreateItemMin4"}, {f = "i", t = "CreateItemIndex4"}, {f = "i", t = "CreateItemType4"}, {f = "i", t = "CreateItemProbability3"}, {f = "i", t = "CreateItemMax3"}, {f = "i", t = "CreateItemMin3"}
l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6, l_0_5, l_0_4, l_0_3 = {f = "s", t = "szScriptName"}, {f = "i", t = "dw_Quality"}, {f = "i", t = "dwRequireItemCount8"}, {f = "i", t = "dwRequireItemIndex8"}, {f = "i", t = "dwRequireItemType8"}, {f = "i", t = "dwRequireItemCount7"}, {f = "i", t = "dwRequireItemIndex7"}, {f = "i", t = "dwRequireItemType7"}, {f = "i", t = "dwRequireItemCount6"}, {f = "i", t = "dwRequireItemIndex6"}, {f = "i", t = "dwRequireItemType6"}, {f = "i", t = "dwRequireItemCount5"}, {f = "i", t = "dwRequireItemIndex5"}, {f = "i", t = "dwRequireItemType5"}, {f = "i", t = "dwRequireItemCount4"}, {f = "i", t = "dwRequireItemIndex4"}, {f = "i", t = "dwRequireItemType4"}, {f = "i", t = "dwRequireItemCount3"}, {f = "i", t = "dwRequireItemIndex3"}, {f = "i", t = "dwRequireItemType3"}, {f = "i", t = "dwRequireItemCount2"}, {f = "i", t = "dwRequireItemIndex2"}, {f = "i", t = "dwRequireItemType2"}, {f = "i", t = "dwRequireItemCount1"}, {f = "i", t = "dwRequireItemIndex1"}, {f = "i", t = "dwRequireItemType1"}, {f = "i", t = "dwEnchantID"}, {f = "s", t = "szBelong"}, {f = "i", t = "dwPrepareFrame"}, {f = "i", t = "dwExp"}, {f = "i", t = "dwEquipmentType"}, {f = "i", t = "dwToolItemIndex"}, {f = "i", t = "dwToolItemType"}, {f = "i", t = "dwRequireDoodad"}, {f = "i", t = "dwRequireBranchID"}, {f = "i", t = "dwRequireLevel"}, {f = "i", t = "dwProfessionID"}, {f = "i", t = "dwCostStamina"}, {f = "s", t = "szName"}, {f = "i", t = "dwID"}
l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6, l_0_5, l_0_4 = {f = "s", t = "ScriptFile"}, {f = "i", t = "DamageAddPercent"}, {f = "i", t = "CostTrainAdd"}, {f = "i", t = "CostStaminaAdd"}, {f = "i", t = "CostEnergyAdd"}, {f = "i", t = "CostRageAdd"}, {f = "i", t = "CostManaAddPercent"}, {f = "i", t = "CostLifeAddPercent"}, {f = "i", t = "MaxRadiusAdd"}, {f = "i", t = "MinRadiusAdd"}, {f = "i", t = "CoolDownAdd3"}, {f = "i", t = "CoolDownAdd2"}, {f = "i", t = "CoolDownAdd1"}, {f = "i", t = "PrepareFramesPercent"}, {f = "i", t = "PrepareFramesAdd"}, {f = "i", t = "SkillLevel"}, {f = "i", t = "SkillID"}, {f = "i", t = "SkillType"}, {f = "i", t = "SkillRecipeType"}, {f = "i", t = "IsEquipmentRecipe"}, {f = "i", t = "IsSystemRecipe"}, {f = "i", t = "Type"}, {f = "i", t = "RecipeLevel"}, {f = "i", t = "RecipeID"}, {f = "s", t = "RecipeExplain"}, {f = "i", t = "DesignLevel"}, {f = "s", t = "BelongSchool"}, {f = "s", t = "RecipeName"}
l_0_5 = KG_Table
l_0_5 = l_0_5.Load
l_0_6 = "\\settings\\Craft\\Recipe\\cooking.tab"
l_0_7, l_0_1 = l_0_1, {l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32}
l_0_8 = FILE_OPEN_MODE
l_0_8 = l_0_8.NORMAL
l_0_5 = l_0_5(l_0_6, l_0_7, l_0_8)
l_0_5 = KG_Table
l_0_5 = l_0_5.Load
l_0_6 = "\\settings\\Craft\\Recipe\\tailoring.tab"
l_0_7 = l_0_1
l_0_8 = FILE_OPEN_MODE
l_0_8 = l_0_8.NORMAL
l_0_5 = l_0_5(l_0_6, l_0_7, l_0_8)
l_0_5 = KG_Table
l_0_5 = l_0_5.Load
l_0_6 = "\\settings\\Craft\\Recipe\\founding.tab"
l_0_7 = l_0_1
l_0_8 = FILE_OPEN_MODE
l_0_8 = l_0_8.NORMAL
l_0_5 = l_0_5(l_0_6, l_0_7, l_0_8)
l_0_5 = KG_Table
l_0_5 = l_0_5.Load
l_0_6 = "\\settings\\Craft\\Recipe\\medicine.tab"
l_0_7 = l_0_1
l_0_8 = FILE_OPEN_MODE
l_0_8 = l_0_8.NORMAL
l_0_5 = l_0_5(l_0_6, l_0_7, l_0_8)
l_0_5 = KG_Table
l_0_5 = l_0_5.Load
l_0_6 = "\\settings\\Craft\\Enchant\\EnchantRecipe.tab"
l_0_7, l_0_2 = l_0_2, {l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42}
l_0_8 = FILE_OPEN_MODE
l_0_8 = l_0_8.NORMAL
l_0_5 = l_0_5(l_0_6, l_0_7, l_0_8)
l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6 = {f = "i", t = "TabId"}, {f = "i", t = "TabIndex"}, {f = "i", t = "ColorQuality"}, {f = "i", t = "BossIndex"}, {f = "s", t = "ItemDrop"}, {f = "i", t = "Level"}, {f = "s", t = "Name"}, {f = "i", t = "Index"}
l_0_43 = "Base6Type"
l_0_44 = "Base6Min"
l_0_45 = "Base6Max"
l_0_46 = "Require1Type"
l_0_47 = "Require1Value"
l_0_48 = "Require2Type"
l_0_49 = "Require2Value"
l_0_50 = "Require3Type"
l_0_51 = "Require3Value"
local l_0_52 = {}
l_0_52.f = "i"
l_0_52.t = "Require4Value"
local l_0_53 = {}
l_0_53.f = "i"
l_0_53.t = "Require5Type"
local l_0_54 = {}
l_0_54.f = "i"
l_0_54.t = "Require5Value"
local l_0_55 = {}
l_0_55.f = "i"
l_0_55.t = "Require6Type"
local l_0_56 = {}
l_0_56.f = "i"
l_0_56.t = "Require6Value"
l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7 = {f = "i", t = "Require4Type"}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "i", t = l_0_45}, {f = "i", t = l_0_44}, {f = "s", t = l_0_43}, {f = "i", t = "Base5Max"}, {f = "i", t = "Base5Min"}, {f = "s", t = "Base5Type"}, {f = "i", t = "Base4Max"}, {f = "i", t = "Base4Min"}, {f = "s", t = "Base4Type"}, {f = "i", t = "Base3Max"}, {f = "i", t = "Base3Min"}, {f = "s", t = "Base3Type"}, {f = "i", t = "Base2Max"}, {f = "i", t = "Base2Min"}, {f = "s", t = "Base2Type"}, {f = "i", t = "Base1Max"}, {f = "i", t = "Base1Min"}, {f = "s", t = "Base1Type"}, {f = "i", t = "Quality"}, {f = "i", t = "ScriptName"}, {f = "i", t = "SetID"}, {f = "i", t = "CanDestroy"}, {f = "i", t = "CanTrade"}, {f = "i", t = "MaxExistAmount"}, {f = "i", t = "MaxExistTime"}, {f = "i", t = "AbradeRate"}, {f = "i", t = "MaxDurability"}, {f = "i", t = "BindType"}, {f = "i", t = "Level"}, {f = "i", t = "Price"}, {f = "i", t = "DetailType"}, {f = "i", t = "SubType"}, {f = "i", t = "Genre"}, {f = "i", t = "ColorID"}, {f = "i", t = "RepresentID"}, {f = "i", t = "UiID"}, {f = "s", t = "Name"}, {f = "i", t = "ID"}
l_0_8 = "Magic1Type"
l_0_9 = "Magic2Type"
l_0_10 = "Magic3Type"
l_0_11 = "Magic4Type"
l_0_12 = "Magic5Type"
l_0_13 = "Magic6Type"
l_0_14 = "Magic7Type"
l_0_15 = "Magic8Type"
l_0_16 = "Magic9Type"
l_0_17 = "Magic10Type"
l_0_18 = "Magic11Type"
l_0_19 = "Magic12Type"
l_0_23 = "MagicKind"
l_0_24 = "MagicType"
l_0_25 = "GetType"
l_0_26 = "BelongMap"
l_0_27 = "_CATEGORY"
l_0_29 = "IconTag1"
l_0_30 = "IconTag2"
l_0_31 = "IsSpecialIcon"
l_0_32 = "IsSpecialRepresent"
l_0_33 = "IconID"
l_0_34 = "CanSetColor"
l_0_35 = "AucGenre"
l_0_36 = "AucSubType"
l_0_37 = "RequireCamp"
l_0_38 = "RequireProfessionID"
l_0_39 = "RequireProfessionLevel"
l_0_40 = "RequireProfessionBranch"
l_0_41 = "PackageGenerType"
l_0_42 = "PackageSubType"
l_0_43 = "TargetType"
l_0_44 = "EnchantRepresentID1"
l_0_45 = "EnchantRepresentID2"
l_0_46 = "EnchantRepresentID3"
l_0_47 = "EnchantRepresentID4"
l_0_48 = "ExistType"
l_0_49 = "DiamondTypeMask1"
l_0_50 = "DiamondAttributeID1"
l_0_51 = "DiamondTypeMask2"
l_0_52 = "DiamondAttributeID2"
l_0_53 = "DiamondTypeMask3"
l_0_54 = "DiamondAttributeID3"
l_0_55 = "EquipCoolDownID"
l_0_56 = "RecommendID"
l_0_56, l_0_55, l_0_54, l_0_53, l_0_52, l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7 = {f = "i", t = "MaxStrengthLevel"}, {f = "i", t = l_0_56}, {f = "i", t = l_0_55}, {f = "i", t = l_0_54}, {f = "i", t = l_0_53}, {f = "i", t = l_0_52}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "i", t = l_0_45}, {f = "i", t = l_0_44}, {f = "i", t = l_0_43}, {f = "i", t = l_0_42}, {f = "i", t = l_0_41}, {f = "i", t = l_0_40}, {f = "i", t = l_0_39}, {f = "i", t = l_0_38}, {f = "i", t = l_0_37}, {f = "i", t = l_0_36}, {f = "i", t = l_0_35}, {f = "i", t = l_0_34}, {f = "i", t = l_0_33}, {f = "i", t = l_0_32}, {f = "i", t = l_0_31}, {f = "s", t = l_0_30}, {f = "s", t = l_0_29}, {f = "i", t = "CoolDownID"}, {f = "s", t = l_0_27}, {f = "s", t = l_0_26}, {f = "s", t = l_0_25}, {f = "s", t = l_0_24}, {f = "s", t = l_0_23}, {f = "s", t = "BelongSchool"}, {f = "i", t = "SkillLevel"}, {f = "i", t = "SkillID"}, {f = "i", t = l_0_19}, {f = "i", t = l_0_18}, {f = "i", t = l_0_17}, {f = "i", t = l_0_16}, {f = "i", t = l_0_15}, {f = "i", t = l_0_14}, {f = "i", t = l_0_13}, {f = "i", t = l_0_12}, {f = "i", t = l_0_11}, {f = "i", t = l_0_10}, {f = "i", t = l_0_9}, {f = "i", t = l_0_8}
l_0_8 = "CanApart"
l_0_9 = "IgnoreBindMask"
l_0_10 = "CanExterior"
l_0_11 = "BelongForceMask"
l_0_10, l_0_9, l_0_8, l_0_7 = {f = "s", t = l_0_11}, {f = "i", t = l_0_10}, {f = "i", t = l_0_9}, {f = "i", t = l_0_8}
l_0_12 = "RepresentDec"
l_0_45 = "Base6Type"
l_0_46 = "Base6Min"
l_0_47 = "Base6Max"
l_0_48 = "Require1Type"
l_0_49 = "Require1Value"
l_0_50 = "Require2Type"
l_0_51 = "Require2Value"
l_0_52 = "Require3Type"
l_0_53 = "Require3Value"
l_0_54 = "Require4Type"
l_0_55 = "Require4Value"
l_0_56 = "Require5Type"
local l_0_57 = {}
l_0_57.f = "i"
l_0_57.t = "Require6Type"
l_0_56, l_0_55, l_0_54, l_0_53, l_0_52, l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8 = {f = "i", t = "Require5Value"}, {f = "i", t = l_0_56}, {f = "i", t = l_0_55}, {f = "i", t = l_0_54}, {f = "i", t = l_0_53}, {f = "i", t = l_0_52}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "s", t = l_0_45}, {f = "i", t = "Base5Max"}, {f = "i", t = "Base5Min"}, {f = "s", t = "Base5Type"}, {f = "i", t = "Base4Max"}, {f = "i", t = "Base4Min"}, {f = "s", t = "Base4Type"}, {f = "i", t = "Base3Max"}, {f = "i", t = "Base3Min"}, {f = "s", t = "Base3Type"}, {f = "i", t = "Base2Max"}, {f = "i", t = "Base2Min"}, {f = "s", t = "Base2Type"}, {f = "i", t = "Base1Max"}, {f = "i", t = "Base1Min"}, {f = "s", t = "Base1Type"}, {f = "i", t = "Quality"}, {f = "i", t = "ScriptName"}, {f = "i", t = "SetID"}, {f = "i", t = "CanDestroy"}, {f = "i", t = "CanTrade"}, {f = "i", t = "MaxExistAmount"}, {f = "i", t = "MaxExistTime"}, {f = "i", t = "AbradeRate"}, {f = "i", t = "MaxDurability"}, {f = "i", t = "BindType"}, {f = "i", t = "Level"}, {f = "i", t = "Price"}, {f = "i", t = "DetailType"}, {f = "i", t = "SubType"}, {f = "i", t = "Genre"}, {f = "i", t = "ColorID"}, {f = "i", t = "RepresentID"}, {f = "i", t = l_0_12}, {f = "i", t = "UiID"}, {f = "s", t = "Name"}, {f = "i", t = "ID"}
l_0_9 = "Require6Value"
l_0_10 = "Magic1Type"
l_0_11 = "Magic2Type"
l_0_12 = "Magic3Type"
l_0_13 = "Magic4Type"
l_0_14 = "Magic5Type"
l_0_15 = "Magic6Type"
l_0_16 = "Magic7Type"
l_0_17 = "Magic8Type"
l_0_18 = "Magic9Type"
l_0_19 = "Magic10Type"
l_0_20 = "Magic11Type"
l_0_21 = "Magic12Type"
l_0_25 = "MagicKind"
l_0_26 = "MagicType"
l_0_27 = "GetType"
l_0_28 = "BelongMap"
l_0_29 = "_CATEGORY"
l_0_31 = "IconTag1"
l_0_32 = "IconTag2"
l_0_33 = "IsSpecialIcon"
l_0_34 = "IsSpecialRepresent"
l_0_35 = "CanSetColor"
l_0_36 = "AucGenre"
l_0_37 = "AucSubType"
l_0_38 = "RequireCamp"
l_0_39 = "RequireProfessionID"
l_0_40 = "RequireProfessionLevel"
l_0_41 = "RequireProfessionBranch"
l_0_42 = "PackageGenerType"
l_0_43 = "PackageSubType"
l_0_44 = "TargetType"
l_0_45 = "EnchantRepresentID1"
l_0_46 = "EnchantRepresentID2"
l_0_47 = "EnchantRepresentID3"
l_0_48 = "EnchantRepresentID4"
l_0_49 = "ExistType"
l_0_50 = "DiamondTypeMask1"
l_0_51 = "DiamondAttributeID1"
l_0_52 = "DiamondTypeMask2"
l_0_53 = "DiamondAttributeID2"
l_0_54 = "DiamondTypeMask3"
l_0_55 = "DiamondAttributeID3"
l_0_56 = "EquipCoolDownID"
l_0_57 = "RecommendID"
l_0_57, l_0_56, l_0_55, l_0_54, l_0_53, l_0_52, l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9, l_0_8 = {f = "i", t = "MaxStrengthLevel"}, {f = "i", t = l_0_57}, {f = "i", t = l_0_56}, {f = "i", t = l_0_55}, {f = "i", t = l_0_54}, {f = "i", t = l_0_53}, {f = "i", t = l_0_52}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "i", t = l_0_45}, {f = "i", t = l_0_44}, {f = "i", t = l_0_43}, {f = "i", t = l_0_42}, {f = "i", t = l_0_41}, {f = "i", t = l_0_40}, {f = "i", t = l_0_39}, {f = "i", t = l_0_38}, {f = "i", t = l_0_37}, {f = "i", t = l_0_36}, {f = "i", t = l_0_35}, {f = "i", t = l_0_34}, {f = "i", t = l_0_33}, {f = "s", t = l_0_32}, {f = "s", t = l_0_31}, {f = "i", t = "CoolDownID"}, {f = "i", t = l_0_29}, {f = "s", t = l_0_28}, {f = "s", t = l_0_27}, {f = "s", t = l_0_26}, {f = "s", t = l_0_25}, {f = "s", t = "BelongSchool"}, {f = "i", t = "SkillLevel"}, {f = "i", t = "SkillID"}, {f = "i", t = l_0_21}, {f = "i", t = l_0_20}, {f = "i", t = l_0_19}, {f = "i", t = l_0_18}, {f = "i", t = l_0_17}, {f = "i", t = l_0_16}, {f = "i", t = l_0_15}, {f = "i", t = l_0_14}, {f = "i", t = l_0_13}, {f = "i", t = l_0_12}, {f = "i", t = l_0_11}, {f = "i", t = l_0_10}, {f = "i", t = l_0_9}
l_0_9 = "CanApart"
l_0_10 = "IgnoreBindMask"
l_0_11 = "CanExterior"
l_0_12 = "BelongForceMask"
l_0_11, l_0_10, l_0_9, l_0_8 = {f = "s", t = l_0_12}, {f = "i", t = l_0_11}, {f = "i", t = l_0_10}, {f = "i", t = l_0_9}
l_0_45 = "Base6Type"
l_0_46 = "Base6Min"
l_0_47 = "Base6Max"
l_0_48 = "Require1Type"
l_0_49 = "Require1Value"
l_0_50 = "Require2Type"
l_0_51 = "Require2Value"
l_0_52 = "Require3Type"
l_0_53 = "Require3Value"
l_0_54 = "Require4Type"
l_0_55 = "Require4Value"
l_0_56 = "Require5Type"
l_0_57 = "Require5Value"
local l_0_58 = {}
l_0_58.f = "i"
l_0_58.t = "Require6Value"
l_0_57, l_0_56, l_0_55, l_0_54, l_0_53, l_0_52, l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9 = {f = "i", t = "Require6Type"}, {f = "i", t = l_0_57}, {f = "i", t = l_0_56}, {f = "i", t = l_0_55}, {f = "i", t = l_0_54}, {f = "i", t = l_0_53}, {f = "i", t = l_0_52}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "s", t = l_0_45}, {f = "i", t = "Base5Max"}, {f = "i", t = "Base5Min"}, {f = "s", t = "Base5Type"}, {f = "i", t = "Base4Max"}, {f = "i", t = "Base4Min"}, {f = "s", t = "Base4Type"}, {f = "i", t = "Base3Max"}, {f = "i", t = "Base3Min"}, {f = "s", t = "Base3Type"}, {f = "i", t = "Base2Max"}, {f = "i", t = "Base2Min"}, {f = "s", t = "Base2Type"}, {f = "i", t = "Base1Max"}, {f = "i", t = "Base1Min"}, {f = "s", t = "Base1Type"}, {f = "i", t = "Quality"}, {f = "i", t = "ScriptName"}, {f = "i", t = "SetID"}, {f = "i", t = "CanDestroy"}, {f = "i", t = "CanTrade"}, {f = "i", t = "MaxExistAmount"}, {f = "i", t = "MaxExistTime"}, {f = "i", t = "AbradeRate"}, {f = "i", t = "MaxDurability"}, {f = "i", t = "BindType"}, {f = "i", t = "Level"}, {f = "i", t = "Price"}, {f = "i", t = "DetailType"}, {f = "i", t = "SubType"}, {f = "i", t = "Genre"}, {f = "i", t = "ColorID"}, {f = "i", t = "RepresentID"}, {f = "i", t = "UiID"}, {f = "s", t = "Name"}, {f = "i", t = "ID"}
l_0_10 = "Magic1Type"
l_0_11 = "Magic2Type"
l_0_12 = "Magic3Type"
l_0_13 = "Magic4Type"
l_0_14 = "Magic5Type"
l_0_15 = "Magic6Type"
l_0_16 = "Magic7Type"
l_0_17 = "Magic8Type"
l_0_18 = "Magic9Type"
l_0_19 = "Magic10Type"
l_0_20 = "Magic11Type"
l_0_21 = "Magic12Type"
l_0_25 = "MagicKind"
l_0_26 = "MagicType"
l_0_27 = "GetType"
l_0_28 = "BelongMap"
l_0_29 = "_CATEGORY"
l_0_31 = "IconTag1"
l_0_32 = "IconTag2"
l_0_33 = "IsSpecialIcon"
l_0_34 = "IsSpecialRepresent"
l_0_35 = "IconID"
l_0_36 = "CanSetColor"
l_0_37 = "AucGenre"
l_0_38 = "AucSubType"
l_0_39 = "RequireCamp"
l_0_40 = "RequireProfessionID"
l_0_41 = "RequireProfessionLevel"
l_0_42 = "RequireProfessionBranch"
l_0_43 = "PackageGenerType"
l_0_44 = "PackageSubType"
l_0_45 = "TargetType"
l_0_46 = "EnchantRepresentID1"
l_0_47 = "EnchantRepresentID2"
l_0_48 = "EnchantRepresentID3"
l_0_49 = "EnchantRepresentID4"
l_0_50 = "ExistType"
l_0_51 = "EquipCoolDownID"
l_0_52 = "RecommendID"
l_0_53 = "DiamondTypeMask1"
l_0_54 = "DiamondAttributeID1"
l_0_55 = "DiamondTypeMask2"
l_0_56 = "DiamondAttributeID2"
l_0_57 = "DiamondTypeMask3"
l_0_58 = "DiamondAttributeID3"
l_0_58, l_0_57, l_0_56, l_0_55, l_0_54, l_0_53, l_0_52, l_0_51, l_0_50, l_0_49, l_0_48, l_0_47, l_0_46, l_0_45, l_0_44, l_0_43, l_0_42, l_0_41, l_0_40, l_0_39, l_0_38, l_0_37, l_0_36, l_0_35, l_0_34, l_0_33, l_0_32, l_0_31, l_0_30, l_0_29, l_0_28, l_0_27, l_0_26, l_0_25, l_0_24, l_0_23, l_0_22, l_0_21, l_0_20, l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13, l_0_12, l_0_11, l_0_10, l_0_9 = {f = "i", t = "MaxStrengthLevel"}, {f = "i", t = l_0_58}, {f = "i", t = l_0_57}, {f = "i", t = l_0_56}, {f = "i", t = l_0_55}, {f = "i", t = l_0_54}, {f = "i", t = l_0_53}, {f = "i", t = l_0_52}, {f = "i", t = l_0_51}, {f = "i", t = l_0_50}, {f = "i", t = l_0_49}, {f = "i", t = l_0_48}, {f = "i", t = l_0_47}, {f = "i", t = l_0_46}, {f = "i", t = l_0_45}, {f = "i", t = l_0_44}, {f = "i", t = l_0_43}, {f = "i", t = l_0_42}, {f = "i", t = l_0_41}, {f = "i", t = l_0_40}, {f = "i", t = l_0_39}, {f = "i", t = l_0_38}, {f = "i", t = l_0_37}, {f = "i", t = l_0_36}, {f = "i", t = l_0_35}, {f = "i", t = l_0_34}, {f = "i", t = l_0_33}, {f = "s", t = l_0_32}, {f = "s", t = l_0_31}, {f = "i", t = "CoolDownID"}, {f = "s", t = l_0_29}, {f = "s", t = l_0_28}, {f = "s", t = l_0_27}, {f = "s", t = l_0_26}, {f = "s", t = l_0_25}, {f = "s", t = "BelongSchool"}, {f = "i", t = "SkillLevel"}, {f = "i", t = "SkillID"}, {f = "i", t = l_0_21}, {f = "i", t = l_0_20}, {f = "i", t = l_0_19}, {f = "i", t = l_0_18}, {f = "i", t = l_0_17}, {f = "i", t = l_0_16}, {f = "i", t = l_0_15}, {f = "i", t = l_0_14}, {f = "i", t = l_0_13}, {f = "i", t = l_0_12}, {f = "i", t = l_0_11}, {f = "i", t = l_0_10}
l_0_10 = "CanApart"
l_0_11 = "IgnoreBindMask"
l_0_12 = "CanExterior"
l_0_13 = "BelongForceMask"
l_0_12, l_0_11, l_0_10, l_0_9 = {f = "s", t = l_0_13}, {f = "i", t = l_0_12}, {f = "i", t = l_0_11}, {f = "i", t = l_0_10}
l_0_9 = KG_Table
l_0_9 = l_0_9.Load
l_0_10 = "\\settings\\item\\Custom_Armor.tab"
l_0_11, l_0_6 = l_0_6, {l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_7, l_0_8, l_0_9, l_0_10}
l_0_12 = FILE_OPEN_MODE
l_0_12 = l_0_12.NORMAL
l_0_9 = l_0_9(l_0_10, l_0_11, l_0_12)
l_0_6 = l_0_9
l_0_9 = KG_Table
l_0_9 = l_0_9.Load
l_0_10 = "\\settings\\item\\Custom_Weapon.tab"
l_0_11, l_0_7 = l_0_7, {l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_57, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_57, l_0_8, l_0_9, l_0_10, l_0_11}
l_0_12 = FILE_OPEN_MODE
l_0_12 = l_0_12.NORMAL
l_0_9 = l_0_9(l_0_10, l_0_11, l_0_12)
l_0_7 = l_0_9
l_0_9 = KG_Table
l_0_9 = l_0_9.Load
l_0_10 = "\\settings\\item\\Custom_Trinket.tab"
l_0_11, l_0_8 = l_0_8, {l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_57, l_0_58, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31, l_0_32, l_0_33, l_0_34, l_0_35, l_0_36, l_0_37, l_0_38, l_0_39, l_0_40, l_0_41, l_0_42, l_0_43, l_0_44, l_0_45, l_0_46, l_0_47, l_0_48, l_0_49, l_0_50, l_0_51, l_0_52, l_0_53, l_0_54, l_0_55, l_0_56, l_0_57, l_0_58, l_0_9, l_0_10, l_0_11, l_0_12}
l_0_12 = FILE_OPEN_MODE
l_0_12 = l_0_12.NORMAL
l_0_9 = l_0_9(l_0_10, l_0_11, l_0_12)
l_0_8 = l_0_9
l_0_9 = KG_Table
l_0_9 = l_0_9.Load
l_0_10 = "\\settings\\skill\\recipeSkill.tab"
l_0_11, l_0_3 = l_0_3, {l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19, l_0_20, l_0_21, l_0_22, l_0_23, l_0_24, l_0_25, l_0_26, l_0_27, l_0_28, l_0_29, l_0_30, l_0_31}
l_0_12 = FILE_OPEN_MODE
l_0_12 = l_0_12.NORMAL
l_0_9 = l_0_9(l_0_10, l_0_11, l_0_12)
l_0_10 = function(l_2_0)
  local l_2_1 = ""
  if BF_ChangeString[l_2_0] then
    l_2_1 = BF_ChangeString[l_2_0]
  else
    l_2_1 = l_2_0
  end
  return l_2_1
end

BF_GetChangeString = l_0_10
l_0_10 = BF_UTILITY_FRAME
l_0_11 = "OnRender"
l_0_12 = function(l_3_0)
  local l_3_1, l_3_2 = nil, nil
  if l_3_0.callroutines then
    for l_3_6,i_2 in pairs(l_3_0.callroutines) do
      local l_3_3 = GetTime()
       -- DECOMPILER ERROR: Overwrote pending register.

      if i_2.end_time <= l_3_3 then
        if type(i_2.func) == "string" then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if (type(i_2.func) ~= "function" or nil) and type(nil) == "function" and i_2.arg and table.maxn(i_2.arg) > 0 then
          nil(unpack(i_2.arg))
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        elseif nil and type(nil) == "function" then
          nil()
        end
        table.remove(l_3_0.callroutines, l_3_7)
      end
    end
  end
end

l_0_10[l_0_11] = l_0_12
l_0_10 = function(l_4_0, l_4_1, ...)
  if not BF_UTILITY_FRAME.callroutines then
    BF_UTILITY_FRAME.callroutines = {}
  end
  local l_4_3 = {}
  l_4_3.func = l_4_0
  l_4_3.delay = l_4_1
  l_4_3.end_time = GetTime() + l_4_1
  l_4_3.arg = {...}
  table.insert(BF_UTILITY_FRAME.callroutines, l_4_3)
end

BigFoot_DelayCall = l_0_10
l_0_10 = function(l_5_0, l_5_1, l_5_2)
  local l_5_3 = Station.Lookup("Topmost/Minimap/Wnd_Minimap/Minimap_Map")
  local l_5_4, l_5_5 = l_5_3:GetAbsPos()
  local l_5_6 = l_5_3:GetScale()
  local l_5_7 = GetClientPlayer()
  if not l_5_7 then
    return 
  end
  return l_5_4 + 99 + (l_5_0 - l_5_7.nX) / l_5_6 * 0.03, l_5_5 + 98 - (l_5_1 - l_5_7.nY) / l_5_6 * 0.03
end

BigFoot_MinimapPosToScreenPos = l_0_10
l_0_10 = function(l_6_0)
  -- upvalues: l_0_10
  if l_6_0.start then
    if l_6_0.func and l_6_0.args and table.maxn(l_6_0.args) > 0 then
      l_6_0.func(unpack(l_6_0.args))
    elseif l_6_0.func then
      l_6_0.func()
    end
    BigFoot_DelayCall(l_0_10, l_6_0.interval, l_6_0)
  end
end

l_0_11 = function(l_7_0)
  -- upvalues: l_0_10
  l_7_0.start = true
  BigFoot_DelayCall(l_0_10, l_7_0.interval, l_7_0)
end

l_0_12 = function(l_8_0)
  l_8_0.start = nil
end

l_0_13 = function(l_9_0, l_9_1, ...)
  -- upvalues: l_0_11 , l_0_12
  local l_9_3 = {interval = l_9_0, func = l_9_1}
  l_9_3.args = {...}
  l_9_3.Start = l_0_11
  l_9_3.Stop = l_0_12
  return l_9_3
end

BigFoot_CreateTimer = l_0_13
l_0_13 = function(l_10_0)
  -- upvalues: l_0_4
  return l_0_4[l_10_0]
end

BigFoot_GetCraftTable = l_0_13
l_0_13 = function()
  -- upvalues: l_0_4
  return l_0_4
end

BigFoot_GetAllCraftTables = l_0_13
BF_EquipList, l_0_13 = l_0_13, {}
l_0_13 = function()
  -- upvalues: l_0_6
  for l_12_3 = 1, l_0_6:GetRowCount() do
    local l_12_4 = l_0_6:GetRow(l_12_3)
    local l_12_5 = {}
    l_12_5.ID = l_12_4.ID
    l_12_5.Name = l_12_4.Name
    l_12_5.UiID = l_12_4.UiID
    l_12_5.RepresentID = l_12_4.RepresentID
    l_12_5.ColorID = l_12_4.ColorID
    l_12_5.Genre = l_12_4.Genre
    l_12_5.SubType = l_12_4.SubType
    l_12_5.DetailType = l_12_4.DetailType
    l_12_5.Price = l_12_4.Price
    l_12_5.Level = l_12_4.Level
    l_12_5.Quality = l_12_4.Quality
    l_12_5.BelongSchool = l_12_4.BelongSchool
    l_12_5.Require1Value = l_12_4.Require1Value
    l_12_5.GetType = l_12_4.GetType
    l_12_5.BelongMap = l_12_4.BelongMap
    l_12_5.MagicKind = l_12_4.MagicKind
    l_12_5.MagicType = l_12_4.MagicType
    BF_EquipList[l_12_4.UiID] = l_12_5
  end
end

BigFoot_GetCustomArmorTab = l_0_13
BF_WeaponList, l_0_13 = l_0_13, {}
l_0_13 = function()
  -- upvalues: l_0_7
  for l_13_3 = 1, l_0_7:GetRowCount() do
    local l_13_4 = l_0_7:GetRow(l_13_3)
    local l_13_5 = {}
    l_13_5.ID = l_13_4.ID
    l_13_5.Name = l_13_4.Name
    l_13_5.UiID = l_13_4.UiID
    l_13_5.RepresentID = l_13_4.RepresentID
    l_13_5.ColorID = l_13_4.ColorID
    l_13_5.Genre = l_13_4.Genre
    l_13_5.SubType = l_13_4.SubType
    l_13_5.DetailType = l_13_4.DetailType
    l_13_5.Price = l_13_4.Price
    l_13_5.Level = l_13_4.Level
    l_13_5.Quality = l_13_4.Quality
    l_13_5.BelongSchool = l_13_4.BelongSchool
    l_13_5.Require1Value = l_13_4.Require1Value
    l_13_5.GetType = l_13_4.GetType
    l_13_5.BelongMap = l_13_4.BelongMap
    l_13_5.MagicKind = l_13_4.MagicKind
    l_13_5.MagicType = l_13_4.MagicType
    BF_WeaponList[l_13_4.UiID] = l_13_5
  end
end

BigFoot_GetWeaponTab = l_0_13
BF_TrinketList, l_0_13 = l_0_13, {}
l_0_13 = function()
  -- upvalues: l_0_8
  for l_14_3 = 1, l_0_8:GetRowCount() do
    local l_14_4 = l_0_8:GetRow(l_14_3)
    local l_14_5 = {}
    l_14_5.ID = l_14_4.ID
    l_14_5.Name = l_14_4.Name
    l_14_5.UiID = l_14_4.UiID
    l_14_5.RepresentID = l_14_4.RepresentID
    l_14_5.ColorID = l_14_4.ColorID
    l_14_5.Genre = l_14_4.Genre
    l_14_5.SubType = l_14_4.SubType
    l_14_5.DetailType = l_14_4.DetailType
    l_14_5.Price = l_14_4.Price
    l_14_5.Level = l_14_4.Level
    l_14_5.Quality = l_14_4.Quality
    l_14_5.BelongSchool = l_14_4.BelongSchool
    l_14_5.Require1Value = l_14_4.Require1Value
    l_14_5.GetType = l_14_4.GetType
    l_14_5.BelongMap = l_14_4.BelongMap
    l_14_5.MagicKind = l_14_4.MagicKind
    l_14_5.MagicType = l_14_4.MagicType
    BF_TrinketList[l_14_4.UiID] = l_14_5
  end
end

BigFoot_GetTrinkeTab = l_0_13
l_0_13 = function()
  -- upvalues: l_0_0
  return l_0_0
end

BigFoot_GetBookTable = l_0_13
l_0_13 = function()
  -- upvalues: l_0_9
  return l_0_9
end

BigFoot_GetSkillRecipeTable = l_0_13
l_0_14 = BigFoot_CreateTimer
l_0_15 = 500
l_0_16 = function()
  -- upvalues: l_0_13
  if #l_0_13 > 0 then
    GetClientPlayer().Talk(unpack(l_0_13[1]))
    table.remove(l_0_13, 1)
    BigFoot_037968c72d27c97158f4a48c4a6ae9d8 = nil
  else
    BigFoot_037968c72d27c97158f4a48c4a6ae9d8 = true
  end
end

l_0_14 = l_0_14(l_0_15, l_0_16)
l_0_15 = function(l_18_0, l_18_1, l_18_2, l_18_3)
  -- upvalues: l_0_13
  local l_18_4 = table.insert
  local l_18_5 = l_18_3
  local l_18_6 = 1
  local l_18_7 = {}
  l_18_7.type = "text"
  l_18_7.text = "BG_CHANNEL_MSG"
  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_4 = table
  l_18_4 = l_18_4.insert
  l_18_5 = l_18_3
  l_18_6 = 2
  l_18_4(l_18_5, l_18_6, l_18_7)
  l_18_7 = {type = "text", text = l_18_0}
  l_18_4 = l_0_13
  l_18_4 = #l_18_4
  if l_18_4 >= 100 then
    l_18_4 = table
    l_18_4 = l_18_4.remove
    l_18_5 = l_0_13
    l_18_6 = 1
    l_18_4(l_18_5, l_18_6)
  end
  l_18_4 = table
  l_18_4 = l_18_4.insert
  l_18_5 = l_0_13
  l_18_7 = l_18_1
  l_18_4(l_18_5, l_18_6)
  l_18_6 = {l_18_7, l_18_2, l_18_3}
end

BigFoot_SendBackgroundMessage = l_0_15
l_0_16 = RegisterEvent
l_0_17 = "ON_BG_CHANNEL_MSG"
l_0_18 = function()
  -- upvalues: l_0_15
  local l_19_0 = GetClientPlayer()
  local l_19_1 = l_19_0.GetTalkData()
  if l_19_1 and l_19_1[2].type == "text" then
    local l_19_2 = l_19_1[2].text
  if l_0_15[l_19_2] then
    if l_19_0.dwID == arg0 then
      end
    if l_19_0.dwID == arg0 then
      end
    end
    local l_19_3 = {}
    for l_19_7 = 3, #l_19_1 do
      table.insert(l_19_3, l_19_1[l_19_7])
    end
    l_0_15[l_19_2][1](l_19_3, arg0, arg1)
  else
    if l_19_1[2].text == "PING" and not arg2 then
      local l_19_8 = GetClientPlayer().Talk
      local l_19_9 = PLAYER_TALK_CHANNEL.WHISPER
      local l_19_10 = arg3
      local l_19_11 = {}
      local l_19_12 = {}
      l_19_12.type = "text"
      l_19_12.text = "BG_CHANNEL_MSG"
      local l_19_13 = {}
      l_19_13.type = "text"
      l_19_13.text = "PING_RESPONSE"
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_19_8(l_19_9, l_19_10, l_19_11)
    end
  end
end

l_0_16(l_0_17, l_0_18)
l_0_16 = function(l_20_0, l_20_1, l_20_2)
  -- upvalues: l_0_15
  local l_20_3 = l_0_15
  do
    local l_20_4 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BigFoot_RegisterBackgroundMessage = l_0_16
l_0_16 = function(l_21_0, l_21_1, l_21_2)
  local l_21_3 = Table_GetQuestPoint(l_21_0, l_21_1, l_21_2)
  if l_21_3 then
    for l_21_7,l_21_8 in pairs(l_21_3) do
      if #l_21_8 > 0 then
        return l_21_7, l_21_8[1][1], l_21_8[1][2]
      end
    end
  end
end

Table_GetQuestTipInfo = l_0_16
l_0_16 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@$"
l_0_17 = function(l_22_0)
  -- upvalues: l_0_16
  local l_22_1 = l_22_0:gsub(".", function(l_23_0)
    local l_23_1 = ""
    local l_23_2 = l_23_0:byte()
    for l_23_6 = 8, 1, -1 do
      l_23_1 = l_23_1 .. (l_23_2 % 2 ^ l_23_6 - l_23_2 % 2 ^ (l_23_6 - 1) > 0 and "1" or "0")
    end
    return l_23_1
  end) .. "0000":gsub("%d%d%d?%d?%d?%d?", function(l_24_0)
    -- upvalues: l_0_16
    if #l_24_0 < 6 then
      return ""
    end
    local l_24_1 = 0
    for l_24_5 = 1, 6 do
      local l_24_11 = l_24_0:sub
      local l_24_12 = l_24_0
      local l_24_13 = l_24_5
      l_24_11 = l_24_11(l_24_12, l_24_13, l_24_5)
      if l_24_11 == "1" then
        l_24_11 = 6 - l_24_5
        l_24_11 = 2 ^ (l_24_11)
      if not l_24_11 then
        end
      end
      l_24_11 = 0
      do
        local l_24_10 = nil
      end
      l_24_1 = l_24_1 + l_24_11
    end
    local l_24_6, l_24_7 = l_0_16:sub, l_0_16
    local l_24_8 = l_24_1 + 1
    local l_24_9 = l_24_1 + 1
    return l_24_6(l_24_7, l_24_8, l_24_9)
  end)
  local l_22_2 = ({"", "==", "="})[#l_22_0 % 3 + 1]
  l_22_1 = l_22_1 .. l_22_2
  return l_22_1
end

base64 = l_0_17
l_0_17 = function(l_23_0)
  -- upvalues: l_0_16
  local l_23_1 = l_23_0:gsub(".", function(l_24_0)
    local l_24_1 = ""
    local l_24_2 = l_24_0:byte()
    for l_24_6 = 8, 1, -1 do
      l_24_1 = l_24_1 .. (l_24_2 % 2 ^ l_24_6 - l_24_2 % 2 ^ (l_24_6 - 1) > 0 and "1" or "0")
    end
    return l_24_1
  end) .. "0000":gsub("%d%d%d?%d?%d?%d?", function(l_25_0)
    -- upvalues: l_0_16
    if #l_25_0 < 6 then
      return ""
    end
    local l_25_1 = 0
    for l_25_5 = 1, 6 do
      local l_25_11 = l_25_0:sub
      local l_25_12 = l_25_0
      local l_25_13 = l_25_5
      l_25_11 = l_25_11(l_25_12, l_25_13, l_25_5)
      if l_25_11 == "1" then
        l_25_11 = 6 - l_25_5
        l_25_11 = 2 ^ (l_25_11)
      if not l_25_11 then
        end
      end
      l_25_11 = 0
      do
        local l_25_10 = nil
      end
      l_25_1 = l_25_1 + l_25_11
    end
    local l_25_6, l_25_7 = l_0_16:sub, l_0_16
    local l_25_8 = l_25_1 + 1
    local l_25_9 = l_25_1 + 1
    return l_25_6(l_25_7, l_25_8, l_25_9)
  end)
  local l_23_2 = ({"", "==", "="})[#l_23_0 % 3 + 1]
  l_23_1 = l_23_1 .. l_23_2
  return l_23_1
end

enc = l_0_17
l_0_17 = function(l_24_0)
  -- upvalues: l_0_16
  l_24_0 = string.gsub(l_24_0, "[^" .. l_0_16 .. "=]", "")
  return l_24_0:gsub(".", function(l_25_0)
    -- upvalues: l_0_16
    if l_25_0 == "=" then
      return ""
    end
    local l_25_1 = ""
    local l_25_2 = l_0_16:find(l_25_0) - 1
    for l_25_6 = 6, 1, -1 do
      l_25_1 = l_25_1 .. (l_25_2 % 2 ^ l_25_6 - l_25_2 % 2 ^ (l_25_6 - 1) > 0 and "1" or "0")
    end
    return l_25_1
  end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(l_26_0)
    if #l_26_0 ~= 8 then
      return ""
    end
    local l_26_1 = 0
    for l_26_5 = 1, 8 do
      local l_26_8, l_26_9 = nil
      l_26_8, l_26_9 = l_26_0:sub, l_26_0
      local l_26_11 = nil
      l_26_11 = l_26_5
      local l_26_12 = nil
      l_26_12 = l_26_5
      local l_26_13 = nil
      l_26_8 = l_26_8(l_26_9, l_26_11, l_26_12)
      if l_26_8 == "1" then
        l_26_8 = 8 - l_26_5
        l_26_8 = 2 ^ (l_26_8)
      if not l_26_8 then
        end
      end
      l_26_8 = 0
      do
        local l_26_10 = nil
      end
      l_26_1 = l_26_1 + l_26_8
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    local l_26_6 = string.char
    local l_26_7 = l_26_1
    return l_26_6(l_26_7)
  end)
end

dec = l_0_17
l_0_17 = function(l_25_0, l_25_1)
  local l_25_2 = GetMsgFontString("MSG_SYS")
  OutputMessage("MSG_SYS", FormatString("<text>text=\"<" .. l_25_0 .. "> \" font=0 r=0 g=196 b=196</text><text>text=\"<D0> \"font=0 r=255 g=255 b=255</text><D1><text>text=\"\n\" font=<D1></text>", l_25_1, l_25_2), true)
end

BigFoot_Print = l_0_17
l_0_17 = function(l_26_0)
  local l_26_1 = {}
  table.insert(l_26_1, l_26_0)
  if l_26_1 and #l_26_1 > 0 then
    Player_AppendAddonMenu(l_26_1)
  end
end

BigFoot_PlayerAppendAddonMenu = l_0_17
l_0_17 = function(l_27_0)
  local l_27_1 = {}
  table.insert(l_27_1, l_27_0)
  if l_27_1 and #l_27_1 > 0 then
    Target_AppendAddonMenu(l_27_1)
  end
end

BigFoot_TargetAppendAddonMenu = l_0_17
l_0_17 = false
Debug_MOD = l_0_17
l_0_17 = RegisterEvent
l_0_18 = "CALL_LUA_ERROR"
l_0_19 = function()
  if Debug_MOD then
    OutputMessage("MSG_SYS", arg0)
  end
end

l_0_17(l_0_18, l_0_19)

