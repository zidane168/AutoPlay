-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_BuffMonitorExPlayer.lua 

local l_0_0 = {}
l_0_0.nDirection = 2
l_0_0.nWidth = 60
l_0_0.nHeight = 120
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = -100
l_0_1.y = 50
l_0_0.Anchor = l_0_1
BuffMonitorExPlayer = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "BuffMonitorExPlayer.nDirection"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BuffMonitorExPlayer.Anchor"
l_0_0(l_0_1)
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:Lookup("", ""):Clear()
  BuffMonitorExPlayer.UpdateAnchor(this)
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function(l_2_0)
  if l_2_0 == "UI_SCALED" or l_2_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    BuffMonitorExPlayer.UpdateAnchor(this)
  elseif l_2_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_2_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "����")
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
  this:CorrectPos()
  BuffMonitorExPlayer.Anchor = GetFrameAnchor(this)
end

l_0_0.OnFrameDragEnd = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function(l_4_0)
  local l_4_1 = BuffMonitorExPlayer.Anchor
  l_4_0:SetPoint(l_4_1.s, 0, 0, l_4_1.r, l_4_1.x, l_4_1.y)
  l_4_0:CorrectPos()
end

l_0_0.UpdateAnchor = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
  local l_5_0 = this:Lookup("", "")
  local l_5_1 = 0
  if l_5_1 < l_5_0:GetItemCount() then
    local l_5_2 = l_5_0:Lookup(l_5_1)
    local l_5_3 = (l_5_2.nEndTime - GetTime()) / 1000
    local l_5_4 = ""
    if l_5_3 > 3600 then
      l_5_4 = math.ceil(l_5_3 / 3600) .. "h"
    elseif l_5_3 > 60 then
      l_5_4 = math.ceil(l_5_3 / 60) .. "m"
    elseif l_5_3 < 3 then
      l_5_4 = "%.1f":format(l_5_3)
    else
      l_5_4 = math.floor(l_5_3)
    end
    if l_5_3 < 0 then
      l_5_0:RemoveItem(l_5_1)
    else
      local l_5_5 = l_5_2:Lookup("TimeLeft")
      if l_5_3 < 3 and BF_BuffMonitorEx.bAnimate then
        local l_5_6 = l_5_2:Lookup("Box_F")
        l_5_6:Show()
        l_5_6:SetAlpha(BF_BuffMonitorEx.nAlpha * (l_5_3 % 1) / 1)
        scale = 1.7 ^ (1 - l_5_3 % 1 / 1)
        l_5_6:SetSize(l_5_6.org_w * scale, l_5_6.org_h * scale)
        l_5_6:SetRelPos(l_5_6.org_x - l_5_6.org_w * (scale - 1) / 2, l_5_6.org_y - l_5_6.org_h * (scale - 1) / 2)
        if l_5_3 - math.floor(l_5_3) > 0.5 then
          l_5_5:SetFontColor(255, 0, 0)
        else
          l_5_5:SetFontColor(255, 255, 255)
        end
      else
        l_5_2:Lookup("Box_F"):Hide()
      end
      l_5_5:SetText(l_5_4)
      if BuffMonitorExPlayer.nDirection == 1 then
        l_5_2:SetRelPos(l_5_1 * (BuffMonitorExPlayer.nWidth * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance), 0)
      else
        if BuffMonitorExPlayer.nDirection == 2 then
          l_5_2:SetRelPos(0 - l_5_1 * (BuffMonitorExPlayer.nWidth * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance), 0)
        end
      else
        if BuffMonitorExPlayer.nDirection == 3 then
          l_5_2:SetRelPos(0, l_5_1 * (BuffMonitorExPlayer.nHeight * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance))
        end
      else
        if BuffMonitorExPlayer.nDirection == 4 then
          l_5_2:SetRelPos(0, 0 - l_5_1 * (BuffMonitorExPlayer.nHeight * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance))
        end
        l_5_1 = l_5_1 + 1
      end
      l_5_2:FormatAllItemPos()
    end
  end
  l_5_0:FormatAllItemPos()
end

l_0_0.OnFrameRender = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function(l_6_0, l_6_1)
  local l_6_2 = l_6_0:GetItemCount() - 1
  for l_6_6 = 0, l_6_2 do
    local l_6_7 = l_6_0:Lookup(l_6_6)
    if l_6_7.dwBuffID == l_6_1 then
      return l_6_7
    end
  end
  return nil
end

l_0_0.GetTimerHandleByBuffID = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function(l_7_0, l_7_1, l_7_2, l_7_3)
  local l_7_4 = Station.Lookup("Topmost/BuffMonitorExPlayer"):Lookup("", "")
  local l_7_5 = BuffMonitorExPlayer.GetTimerHandleByBuffID(l_7_4, l_7_0)
  if l_7_5 then
    l_7_5:GetParent():RemoveItem(l_7_5)
  end
end

l_0_0.RemoveTimerHandle = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
  local l_8_0 = Station.Lookup("Topmost/BuffMonitorExPlayer"):Lookup("", "")
  l_8_0:Clear()
end

l_0_0.ClearTimerHandle = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.HideTimerHandle = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function()
   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.ShowTimerHandle = l_0_1
l_0_0 = BuffMonitorExPlayer
l_0_1 = function(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4, l_11_5)
  local l_11_6 = Station.Lookup("Topmost/BuffMonitorExPlayer"):Lookup("", "")
  local l_11_7 = BuffMonitorExPlayer.GetTimerHandleByBuffID(l_11_6, l_11_0)
  if not l_11_7 then
    local l_11_8 = "interface\\BF_BuffMonitorEx\\BF_BuffMonitorExPlayer.ini"
    l_11_6:AppendItemFromIni(l_11_8, "Hanele_Timer")
    l_11_7 = l_11_6:Lookup(l_11_6:GetItemCount() - 1)
    l_11_7:Scale(BF_BuffMonitorEx.nScale, BF_BuffMonitorEx.nScale)
    l_11_7:SetRelPos((l_11_6:GetItemCount() - 1) * BF_BuffMonitorEx.nDistance, 0)
    l_11_7:SetAlpha(BF_BuffMonitorEx.nAlpha)
    local l_11_9 = l_11_7:Lookup("Box_F")
    local l_11_10 = l_11_9:GetRelPos()
    l_11_9.org_y = l_11_9
    l_11_9.org_x = l_11_10
     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_9.org_h = l_11_9
    l_11_9.org_w = l_11_10
     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_10(l_11_6)
  end
  l_11_7.dwBuffID = l_11_0
  l_11_7.dwBuffLevel = l_11_1
  l_11_7.nEndTime = GetTime() + (l_11_3 - GetLogicFrameCount()) * 1000 / 16
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_11_11 = l_11_7:Lookup(l_11_10)
  l_11_11:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_11_0)
  l_11_11:SetObjectIcon(Table_GetBuffIconID(l_11_0, l_11_1))
  l_11_11:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
  l_11_11:SetOverTextFontScheme(0, 15)
  if l_11_2 > 1 then
    l_11_11:SetOverText(0, l_11_2)
  else
    l_11_11:SetOverText(0, "")
  end
  l_11_11 = l_11_7:Lookup("Box_F")
  l_11_11:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_11_0)
  l_11_11:SetObjectIcon(Table_GetBuffIconID(l_11_0, l_11_1))
  l_11_11:Hide()
  if l_11_4 then
    if l_11_5 then
      l_11_7:Lookup("BuffName"):SetFontColor(255, 255, 0)
    else
      l_11_7:Lookup("BuffName"):SetFontColor(0, 255, 0)
    end
  elseif l_11_5 then
    l_11_7:Lookup("BuffName"):SetFontColor(255, 255, 0)
  else
    l_11_7:Lookup("BuffName"):SetFontColor(255, 0, 0)
  end
  l_11_7:Lookup("BuffName"):SetText(Table_GetBuffName(l_11_0, l_11_1))
end

l_0_0.CreateTimerHandle = l_0_1
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "interface\\BF_BuffMonitorEx\\BF_BuffMonitorExPlayer.ini"
l_0_0(l_0_1, "BuffMonitorExPlayer")

