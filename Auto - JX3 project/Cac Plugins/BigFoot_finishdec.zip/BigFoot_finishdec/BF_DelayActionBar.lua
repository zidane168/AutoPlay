-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_DelayActionBar.lua 

local l_0_0 = {}
l_0_0.Enable = true
BF_DelayActionBar = l_0_0
l_0_0 = BF_DelayActionBar
l_0_0.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(0, 0, "NONE")
l_0_0 = BF_DelayActionBar
l_0_0 = l_0_0.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a
l_0_0(l_0_0, "DO_PICK_PREPARE_PROGRESS")
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_0, "DO_SKILL_PREPARE_PROGRESS")
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_0, "DO_SKILL_CHANNEL_PROGRESS")
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_0, "DO_CUSTOM_OTACTION_PROGRESS")
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_0, "DO_RECIPE_PREPARE_PROGRESS")
 -- DECOMPILER ERROR: Overwrote pending register.

BF_DelayActionBar.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnUpdate = function(l_1_0)
  -- upvalues: l_0_0
  if BF_DelayActionBar.Enable then
    local l_1_1 = Station.Lookup("Topmost/OTActionBar")
    if l_1_1.bShow then
      if not l_0_0 then
        BF_DelayActionBar.Ping = math.floor(GetPingValue() / 2)
        local l_1_2 = l_1_1:Lookup("", "")
        local l_1_3 = l_1_2:Lookup("Text_Name")
        local l_1_4 = l_1_3:GetText()
        l_1_3:SetText(l_1_4 .. " (" .. BF_DelayActionBar.Ping .. "ms)")
        l_0_0 = true
      end
      local l_1_5 = BF_DelayActionBar.EndTime - BF_DelayActionBar.StartTime
      local l_1_6 = BF_DelayActionBar.Ping / l_1_5
      BF_DelayActionBar.ShowDelay(l_1_6)
      local l_1_7 = GetTickCount()
      local l_1_8 = l_1_7 - BF_DelayActionBar.StartTime
      if l_1_5 - l_1_8 < 0 then
        local l_1_9 = 0
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if BF_DelayActionBar.Text_Done then
      BF_DelayActionBar.Text_Done:SetText(string.format("%.1f/%.1f", l_1_9 / 1000, l_1_5 / 1000) .. "S")
    end
  else
    BF_DelayActionBar.Ping = nil
    l_0_0 = false
  end
end

BF_DelayActionBar.UpdateTime = function()
  BF_DelayActionBar.StartTime = GetTickCount()
  BF_DelayActionBar.EndTime = BF_DelayActionBar.StartTime + (BF_DelayActionBar.EndFrame - BF_DelayActionBar.StartFrame) * 1000 / GLOBAL.GAME_FPS
end

BF_DelayActionBar.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnEvent = function(l_3_0, l_3_1, l_3_2, ...)
  -- upvalues: l_0_0
  if l_3_2 == "DO_PICK_PREPARE_PROGRESS" or l_3_2 == "DO_SKILL_CHANNEL_PROGRESS" then
    l_0_0 = false
    BF_DelayActionBar.StartFrame = GetLogicFrameCount()
    BF_DelayActionBar.EndFrame = GetLogicFrameCount() + arg0
    BF_DelayActionBar.UpdateTime()
  elseif l_3_2 == "DO_SKILL_PREPARE_PROGRESS" or l_3_2 == "DO_RECIPE_PREPARE_PROGRESS" or l_3_2 == "DO_CUSTOM_OTACTION_PROGRESS" then
    l_0_0 = false
    BF_DelayActionBar.StartFrame = GetLogicFrameCount()
    BF_DelayActionBar.EndFrame = GetLogicFrameCount() + arg0
    BF_DelayActionBar.UpdateTime()
  end
end

BF_DelayActionBar.ShowDelay = function(l_4_0)
  if not BF_DelayActionBar.Image_Delay then
    return 
  end
  BF_DelayActionBar.Image_Delay:SetImageType(2)
  BF_DelayActionBar.Image_Delay:SetPercentage(l_4_0)
  BF_DelayActionBar.Image_Delay:Show()
end

BF_DelayActionBar.ActionBarOnFrameRender = function()
  BF_DelayActionBar.BigFoot_fd6e3ca5ea59ab9b5aa5fed97c2abbeb()
  local l_5_0 = OTActionBar.g_nEndTime - OTActionBar.g_nStartTime
  local l_5_1 = BF_DelayActionBar.Ping / l_5_0
  BF_DelayActionBar.ShowDelay(l_5_1)
  local l_5_2 = GetTickCount()
  local l_5_3 = l_5_2 - OTActionBar.g_nStartTime
  local l_5_4 = OTActionBar.g_nEndTime - OTActionBar.g_nStartTime
  if l_5_4 - l_5_3 < 0 then
    local l_5_5 = 0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  BF_DelayActionBar.Text_Done:SetText(string.format("%.1f/%.1f", l_5_5 / 1000, l_5_4 / 1000) .. "S")
end

BFConfigPanel.RegisterMod("DelayActionBar", "�ӳ���ʾ", "\\ui\\image\\icon\\tome02.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
BFConfigPanel.RegisterCheckButton("DelayActionBar", "EnableDelayActionBar", "���������ӳ���ʾ", false, function(l_6_0)
  BF_DelayActionBar.Enable = l_6_0
  if l_6_0 then
    local l_6_1 = Station.Lookup("Topmost/OTActionBar")
    if l_6_1 then
      local l_6_2 = l_6_1:Lookup("", "")
    end
    if l_6_2 then
      l_6_2:AppendItemFromString("<text>name=\"Text_Done\" font=162 Width=240 Height=20 x=280 y=14</text>")
      BF_DelayActionBar.Text_Done = l_6_2:Lookup("Text_Done")
      BF_DelayActionBar.Image_Delay = l_6_2:Lookup("Image_FlashF")
    end
  else
    if BF_DelayActionBar.BigFoot_1d10ffc99e6f0c5b8f70c21b0b307a4a then
      OTActionBar.OnEvent = BF_DelayActionBar.BigFoot_1d10ffc99e6f0c5b8f70c21b0b307a4a
    end
    if BF_DelayActionBar.BigFoot_37548b0f0836a185781b205faa7c59a0 then
      OTActionBar.PrepaireProgressBar = BF_DelayActionBar.BigFoot_37548b0f0836a185781b205faa7c59a0
    end
    if BF_DelayActionBar.BigFoot_fd6e3ca5ea59ab9b5aa5fed97c2abbeb then
      OTActionBar.OnFrameRender = BF_DelayActionBar.BigFoot_fd6e3ca5ea59ab9b5aa5fed97c2abbeb
    end
  end
  if BF_DelayActionBar.Image_Delay then
    BF_DelayActionBar.Image_Delay:Hide()
  end
end
)

