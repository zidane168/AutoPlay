-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Drag.lua 

local l_0_0 = {}
l_0_0.enabled = false
l_0_0.x = 700
l_0_0.y = 490
local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_4 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_5 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_6 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_7 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_8 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_9 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_10 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_11 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

local l_0_12 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_12, l_0_11, l_0_10, l_0_9, l_0_8, l_0_7, l_0_6, l_0_5, l_0_4, l_0_3, l_0_2 = {"10", "20", "30", "40", "51"}, {l_0_12, "20", "30", "40", "51"}, {l_0_11, l_0_12, "30", "40", "50", "50"}, {l_0_10, l_0_11, l_0_12, "41", "50", "51"}, {l_0_9, l_0_10, l_0_11, l_0_12, "41", "50", "41"}, {l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, "50", "51"}, {l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, "50", "41"}, {l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, "51"}, {l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12, "40"}, {l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12}, {l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12}
l_0_0.aAccumulateHide, l_0_1 = l_0_1, {l_0_2, l_0_3, l_0_4, l_0_5, l_0_6, l_0_7, l_0_8, l_0_9, l_0_10, l_0_11, l_0_12}
BF_Drag = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "BF_Drag.x"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_Drag.y"
l_0_0(l_0_1)
l_0_0 = BF_Drag
l_0_1 = function()
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("SYNC_ROLE_DATA_END")
  this:RegisterEvent("SKILL_MOUNT_KUNG_FU")
  this:RegisterEvent("SKILL_UNMOUNT_KUNG_FU")
  this:RegisterEvent("SET_SHOW_VALUE_BY_PERCENTAGE")
  this:RegisterEvent("SET_SHOW_VALUE_TWO_FORMAT")
  this:RegisterEvent("SET_SHOW_PLAYER_STATE_VALUE")
  this:RegisterEvent("CURRENT_PLAYER_FORCE_CHANGED")
  this:RegisterEvent("UI_UPDATE_ACCUMULATE")
  UpdateCustomModeWindow(this, "ְҵ����λ��")
  BF_Drag.Farm = Station.Lookup("Topmost/BF_Drag")
  BF_Drag.Handle = BF_Drag.Farm:Lookup("", "")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = 0
l_0_1 = BF_Drag
l_0_2 = function()
  -- upvalues: l_0_0
  if GetTime() - l_0_0 > 500 then
    l_0_0 = GetTime()
    BF_Drag.UpdateCangjian()
    BF_Drag.OnUpdateTangmenEnergy()
  end
end

l_0_1.OnFrameBreathe = l_0_2
l_0_1 = BF_Drag
l_0_2 = function()
  local l_3_0 = this:GetRoot()
  local l_3_1, l_3_2 = l_3_0:GetAbsPos()
  local l_3_3 = BF_Drag
  local l_3_4 = BF_Drag
  l_3_3.x = l_3_1
  l_3_3 = BF_Drag
  l_3_3 = l_3_3.SetBF_DragPos
  l_3_3()
end

l_0_1.OnFrameDragEnd = l_0_2
l_0_1 = BF_Drag
l_0_2 = function()
  if not BF_Drag.enabled then
    return 
  end
  BF_Drag.Handle:Clear()
  BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb = nil
  BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe = nil
  local l_4_0 = GetClientPlayer()
  local l_4_1 = Player_GetFrame()
  if l_4_0 then
    local l_4_2 = l_4_1:Lookup("", "")
    local l_4_3 = (l_4_2:Lookup("Handle_CangJian"))
    local l_4_4 = nil
    local l_4_5 = l_4_0.GetKungfuMount()
  end
  if l_4_5 then
    local l_4_6 = Table_GetSkillName(l_4_5.dwSkillID, l_4_5.dwSkillnLevel)
    if l_4_5.dwSkillID == 10144 or l_4_5.dwSkillID == 10145 then
      l_4_3:Show()
      l_4_4 = "Handle_CangJian"
      BF_Drag.Class = "CangJian"
    elseif l_4_5.dwMountType == 3 or l_4_5.dwMountType == 5 or l_4_5.dwMountType == 10 then
      if not l_4_1.szShow or l_4_1.szShow == "" then
        return 
      end
      local l_4_7 = l_4_1:Lookup("", l_4_1.szShow)
      l_4_4 = l_4_1.szShow
      BF_Drag.Class = "NotCangJian"
    end
  end
  if l_4_4 then
    BF_Drag.Handle:Clear()
    BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe = l_4_4
    BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb = BF_Drag.Handle:AppendItemFromIni("UI\\Config\\Default\\Player.ini", l_4_4)
    BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb:Show()
    BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb:SetRelPos(0, 0)
    BF_Drag.Handle:FormatAllItemPos()
    local l_4_8, l_4_9 = BF_Drag.Handle:GetAllItemSize()
    BF_Drag.Farm:SetSize(l_4_8, l_4_9)
  end
  if BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe and BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe == "Handle_CangJian" then
    BF_Drag.UpdateCangjian(BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb)
  else
    if BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe and BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe == "Handle_TangMen" then
      BF_Drag.OnUpdateTangmenEnergy(l_4_1)
    end
  else
    if BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe then
      BF_Drag.BigFoot_36932f2ed3e3598142f9e52334977f32(BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb)
    end
  end
end

l_0_1.SetBF_DragPos = l_0_2
l_0_1 = BF_Drag
l_0_2 = function()
  if not BF_Drag.enabled then
    return 
  end
  if not BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb then
    return 
  end
  if BF_Drag.Class ~= "CangJian" then
    return 
  end
  local l_5_0 = GetClientPlayer()
  if l_5_0 then
    local l_5_1 = BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb
    if not l_5_1 then
      return 
    end
    local l_5_2 = GetClientPlayer()
    local l_5_3 = l_5_1:Lookup("Image_Short")
    local l_5_4 = l_5_1:Lookup("Text_Short")
    local l_5_5 = l_5_1:Lookup("Animate_Short")
    local l_5_6 = l_5_1:Lookup("Image_Long")
    local l_5_7 = l_5_1:Lookup("Text_Long")
    local l_5_8 = (l_5_1:Lookup("Animate_Long"))
    local l_5_9 = nil
    if l_5_2.nMaxRage > 100 then
      l_5_3:Hide()
      l_5_4:Hide()
      l_5_5:Hide()
      l_5_6:Show()
      l_5_7:Show()
      l_5_8:Show()
      l_5_9 = "Long"
    else
      l_5_3:Show()
      l_5_4:Show()
      l_5_5:Show()
      l_5_6:Hide()
      l_5_7:Hide()
      l_5_8:Hide()
      l_5_9 = "Short"
    end
    if l_5_2.nMaxRage > 0 then
      local l_5_10 = l_5_2.nCurrentRage / l_5_2.nMaxRage
      l_5_1:Lookup("Image_" .. l_5_9):SetPercentage(l_5_10)
      l_5_1:Lookup("Text_" .. l_5_9):SetText(l_5_2.nCurrentRage .. "/" .. l_5_2.nMaxRage)
    end
  else
    l_5_1:Lookup("Image_" .. l_5_9):SetPercentage(0)
    l_5_1:Lookup("Text_" .. l_5_9):SetText("")
  end
end

l_0_1.UpdateCangjian = l_0_2
l_0_1 = BF_Drag
l_0_2 = function()
  if not BF_Drag.enabled then
    return 
  end
  if BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb and BF_Drag.Class == "NotCangJian" then
    BF_Drag.BigFoot_36932f2ed3e3598142f9e52334977f32(BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb)
  end
end

l_0_1.OnUpdateAccumulateValue = l_0_2
l_0_1 = BF_Drag
l_0_2 = function()
  if not BF_Drag.enabled then
    return 
  end
  if BF_Drag.BigFoot_6a062fe096460c055cdeb5d058e3d6fe ~= "Handle_TangMen" then
    return 
  end
  local l_7_0 = BF_Drag.BigFoot_f1447e688195f0e731e0cc761f52cceb
  local l_7_1 = l_7_0:Lookup("Text_Energy")
  local l_7_2 = l_7_0:Lookup("Image_Strip")
  local l_7_3 = l_7_0:Lookup("Image_Frame")
  local l_7_4 = GetClientPlayer()
  if l_7_4.nMaxEnergy > 0 then
    local l_7_5 = l_7_4.nCurrentEnergy / l_7_4.nMaxEnergy
    l_7_2:SetPercentage(l_7_5)
    l_7_1:SetText(l_7_4.nCurrentEnergy .. "/" .. l_7_4.nMaxEnergy)
  else
    l_7_2:SetPercentage(0)
    l_7_1:SetText("")
  end
end

l_0_1.OnUpdateTangmenEnergy = l_0_2
l_0_1 = BF_Drag
l_0_2 = function(l_8_0)
  local l_8_1 = l_8_0
  local l_8_2 = Station.Lookup("Normal/Player")
  if GetClientPlayer().nAccumulateValue >= 0 or l_8_2.szShow == "Handle_ShaoLin" then
    if not l_8_1 or not l_8_2.szShow or 0 > 3 then
      local l_8_3, l_8_4, l_8_14 = 3
    end
    do
      local l_8_5 = nil
      for l_8_9 = 1, l_8_5 do
        local l_8_6 = l_8_2.szShowSub
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_8_1:Lookup(l_8_6 .. R8_PC29):Show()
      end
      for l_8_13 = l_8_5 + 1, 3 do
        local l_8_10 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_8_1:Lookup(l_8_10 .. R8_PC29):Hide()
      end
    end
    do break end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_8_5 > 10 then
    local l_8_15 = 10 + 1
  end
  local l_8_16 = l_8_2.szShowSub
  local l_8_17 = BF_Drag.aAccumulateShow[l_8_15]
  local l_8_18 = BF_Drag.aAccumulateHide[l_8_15]
  for l_8_22,l_8_23 in pairs(l_8_17) do
    l_8_1:Lookup(l_8_16 .. l_8_23):Show()
  end
  for l_8_27,l_8_28 in pairs(l_8_18) do
    l_8_1:Lookup(l_8_16 .. l_8_28):Hide()
  end
end

l_0_1.BigFoot_36932f2ed3e3598142f9e52334977f32 = l_0_2
l_0_1 = BF_Drag
l_0_2 = function(l_9_0)
  if l_9_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_9_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    local l_9_1 = this:GetRoot()
    l_9_1:SetAbsPos(BF_Drag.x, BF_Drag.y)
    UpdateCustomModeWindow(this)
  elseif l_9_0 == "CUSTOM_DATA_LOADED" then
    local l_9_2 = this:GetRoot()
    l_9_2:SetAbsPos(BF_Drag.x, BF_Drag.y)
  elseif l_9_0 == "SKILL_MOUNT_KUNG_FU" or not "SKILL_UNMOUNT_KUNG_FU" then
    BF_Drag.SetBF_DragPos()
    local l_9_3 = GetClientPlayer()
    local l_9_4 = l_9_3.GetKungfuMount()
    if l_9_4 then
      if l_9_4.dwMountType == 3 then
        BF_Drag.OnUpdateAccumulateValue()
      end
    elseif l_9_4.dwMountType == 5 then
      BF_Drag.OnUpdateAccumulateValue()
    elseif l_9_4.dwMountType == 10 then
      BF_Drag.OnUpdateTangmenEnergy()
    end
    do return end
    if l_9_0 == "PLAYER_STATE_UPDATE" then
      l_9_3 = arg0
      l_9_4 = GetClientPlayer
      l_9_4 = l_9_4()
      l_9_4 = l_9_4.dwID
      if l_9_3 == l_9_4 then
        l_9_3 = BF_Drag
        l_9_3 = l_9_3.UpdateCangjian
        l_9_3()
        l_9_3 = BF_Drag
        l_9_3 = l_9_3.OnUpdateTangmenEnergy
        l_9_3()
      end
    elseif l_9_0 == "SET_SHOW_VALUE_BY_PERCENTAGE" or l_9_0 == "SET_SHOW_VALUE_TWO_FORMAT" then
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.UpdateCangjian
      l_9_3()
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.OnUpdateTangmenEnergy
      l_9_3()
    elseif l_9_0 == "SET_SHOW_PLAYER_STATE_VALUE" then
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.UpdateCangjian
      l_9_3()
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.OnUpdateTangmenEnergy
      l_9_3()
    elseif l_9_0 == "CURRENT_PLAYER_FORCE_CHANGED" then
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.UpdateCangjian
      l_9_3()
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.OnUpdateTangmenEnergy
      l_9_3()
    elseif l_9_0 == "UI_UPDATE_ACCUMULATE" then
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.OnUpdateAccumulateValue
      l_9_3()
      l_9_3 = BF_Drag
      l_9_3 = l_9_3.OnUpdateTangmenEnergy
      l_9_3()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 35 
end

l_0_1.OnEvent = l_0_2
l_0_1 = Wnd
l_0_1 = l_0_1.OpenWindow
l_0_2 = "Interface\\BF_Drag\\BF_Drag.ini"
l_0_3 = "BF_Drag"
l_0_1(l_0_2, l_0_3)
l_0_1 = BFMods
l_0_1 = l_0_1.ClassHelper
if not l_0_1 then
  l_0_1 = BFConfigPanel
  l_0_1 = l_0_1.RegisterMod
  l_0_2 = "ClassHelper"
  l_0_3 = "ְҵ����"
  l_0_4 = "\\ui\\image\\icon\\medic31.tga"
  l_0_5 = "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d"
  l_0_1(l_0_2, l_0_3, l_0_4, l_0_5)
end
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "ClassHelper"
l_0_3 = "EnableDrag"
l_0_4 = "����,�ؽ�,��������,��������϶�"
l_0_5 = false
l_0_6 = function(l_10_0)
  if l_10_0 then
    BF_Drag.enabled = true
    BF_Drag.Farm:Show()
    BF_Drag.SetBF_DragPos()
  else
    BF_Drag.enabled = false
    BF_Drag.Farm:Hide()
  end
end

l_0_1(l_0_2, l_0_3, l_0_4, l_0_5, l_0_6)

