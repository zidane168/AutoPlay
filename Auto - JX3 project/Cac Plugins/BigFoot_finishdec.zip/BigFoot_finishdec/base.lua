-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: base.lua 

BFWidget = classv2()
BigFoot_3f883375f87b090ef572a06a3eaea9e0 = 1
BFWidget.ctor = function(l_1_0, l_1_1)
  l_1_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = "BFWidget" .. BigFoot_3f883375f87b090ef572a06a3eaea9e0
  _G[l_1_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584] = l_1_0
  BigFoot_3f883375f87b090ef572a06a3eaea9e0 = BigFoot_3f883375f87b090ef572a06a3eaea9e0 + 1
  l_1_0.BigFoot_92fc56267c7e14d288fbcf74f912203d = 0
  l_1_0.BigFoot_eada6c7b715e634a0f10a59caa7a63a2 = 0
  l_1_0.BigFoot_0694c14294eb642e50750f9964155ae0 = 0
  l_1_0.BigFoot_2f3acdeb071461a90aa82978f92256fc = 0
  l_1_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9 = 0
  l_1_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656 = 0
  l_1_0.BigFoot_fe68d264456494dec7daae6a568ef044 = {}
  l_1_0.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe = {}
  l_1_0.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 = true
  do
    local l_1_2 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BFWidget.GetName = function(l_2_0)
  return l_2_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
end

BFWidget.SetContainer = function(l_3_0, l_3_1)
  l_3_0.BigFoot_ac0723394133c458cf0a253e512eae56 = l_3_1
end

BFWidget.GetContainer = function(l_4_0)
  return l_4_0.BigFoot_ac0723394133c458cf0a253e512eae56
end

BFWidget.SetSize = function(l_5_0, l_5_1, l_5_2, l_5_3)
  local l_5_4 = assert
  local l_5_5 = nil
  if l_5_1 then
    l_5_5 = l_5_2
  end
  l_5_4(l_5_5, "Invalid size.")
  l_5_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9 = l_5_1
  l_5_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656 = l_5_2
  if not l_5_3 then
    l_5_4, l_5_5 = l_5_0:Update, l_5_0
    l_5_4(l_5_5)
  end
end

BFWidget.SetPoint = function(l_6_0, l_6_1, l_6_2, l_6_3, l_6_4, l_6_5, l_6_6)
  local l_6_7 = assert
  l_6_7(l_6_0 ~= l_6_2, "Anchor widget cannot be itself.")
  l_6_0.BigFoot_be4832c818b2e3a2514eb10ff20e906a = nil
  local l_6_10, l_6_11 = nil, nil
  for l_6_15,l_6_16 in pairs(l_6_0.BigFoot_0001857ddc87bc382cff1ce608260a07) do
    if l_6_16[1] == l_6_1 then
      local l_6_17, l_6_18 = nil, nil
      for l_6_22,l_6_23 in pairs(l_6_16[2].BigFoot_fe68d264456494dec7daae6a568ef044) do
        if l_6_23.widget == l_6_0 then
          l_6_23.count = l_6_23.count - 1
        end
        if l_6_23.count <= 0 then
          table.remove(l_6_16[2].BigFoot_fe68d264456494dec7daae6a568ef044, l_6_22)
      else
        end
      end
      table.remove(l_6_0.BigFoot_0001857ddc87bc382cff1ce608260a07, l_6_15)
  else
    end
  end
  local l_6_24 = table.insert
  local l_6_25 = l_6_0.BigFoot_0001857ddc87bc382cff1ce608260a07
  local l_6_26 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_6_24(l_6_25, l_6_26)
   -- DECOMPILER ERROR: Overwrote pending register.

  for i_1,i_2 in l_6_24 do
    do
       -- DECOMPILER ERROR: Overwrote pending register.

  end
  if l_6_3 == l_6_0 then
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_6_11 then
      local l_6_29 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_6_30 = nil
      local l_6_31 = nil
      l_6_24.insert(l_6_25, {widget = l_6_0, count = 1})
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    if not l_6_6 then
      l_6_0:Update()
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 71 
end

BFWidget.ClearAllPoints = function(l_7_0)
  local l_7_1, l_7_2, l_7_3, l_7_13 = nil, nil, nil
  do break end
  local l_7_4, l_7_5 = pairs(l_7_0.BigFoot_0001857ddc87bc382cff1ce608260a07)
  local l_7_6, l_7_7 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_7_11,l_7_12 in pairs(R8_PC6[2].BigFoot_fe68d264456494dec7daae6a568ef044) do
    local l_7_8, l_7_9, l_7_10 = , nil, nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if R15_PC10.widget == l_7_0 then
      R15_PC10.count = R15_PC10.count - 1
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if R15_PC10.count <= 0 then
      table.remove(l_7_8[2].BigFoot_fe68d264456494dec7daae6a568ef044, R14_PC23)
    end
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers!

l_7_0.BigFoot_0001857ddc87bc382cff1ce608260a07, l_7_4 = l_7_4, {}
end

BFWidget.GetParent = function(l_8_0)
  return l_8_0._parent
end

BFWidget.SetParent = function(l_9_0, l_9_1)
  if not l_9_1 then
    l_9_1 = BFScreen
  end
  if l_9_1.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 then
    l_9_0.BigFoot_ac0723394133c458cf0a253e512eae56:ChangeRelation(l_9_1.BigFoot_ac0723394133c458cf0a253e512eae56, nil, true)
  else
    l_9_0.BigFoot_ac0723394133c458cf0a253e512eae56:ChangeRelation(l_9_1, nil, true)
  end
  local l_9_2, l_9_3 = nil, nil
  local l_9_4 = l_9_0:GetParent()
  if l_9_4 and l_9_4.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 then
    for l_9_8,l_9_9 in pairs(l_9_4.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe) do
      if l_9_9 == l_9_0 then
        table.remove(l_9_4.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe, l_9_8)
      end
  else
    end
  end
  l_9_0._parent = l_9_1
  if l_9_1.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 then
    for l_9_13,l_9_14 in pairs(l_9_1.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe) do
      if l_9_14 == l_9_0 then
        return 
      end
    end
    table.insert(l_9_1.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe, l_9_0)
  end
end

BFWidget.Show = function(l_10_0)
  l_10_0.BigFoot_ac0723394133c458cf0a253e512eae56:Show()
  l_10_0.BigFoot_7ea16d69ee68978a562320944cf1ea36 = true
  l_10_0:Update()
end

BFWidget.Hide = function(l_11_0)
  l_11_0.BigFoot_7ea16d69ee68978a562320944cf1ea36 = nil
  l_11_0.BigFoot_ac0723394133c458cf0a253e512eae56:Hide()
end

BFWidget.IsShown = function(l_12_0)
  return l_12_0.BigFoot_7ea16d69ee68978a562320944cf1ea36
end

BFWidget.IsWidget = function(l_13_0)
  return true
end

BFWidget.GetTop = function(l_14_0)
  return l_14_0.BigFoot_0694c14294eb642e50750f9964155ae0
end

BFWidget.GetLeft = function(l_15_0)
  return l_15_0.BigFoot_92fc56267c7e14d288fbcf74f912203d
end

BFWidget.GetRight = function(l_16_0)
  return l_16_0.BigFoot_eada6c7b715e634a0f10a59caa7a63a2
end

BFWidget.GetBottom = function(l_17_0)
  return l_17_0.BigFoot_2f3acdeb071461a90aa82978f92256fc
end

BFWidget.GetWidth = function(l_18_0)
  if l_18_0.BigFoot_eada6c7b715e634a0f10a59caa7a63a2 and l_18_0.BigFoot_92fc56267c7e14d288fbcf74f912203d and l_18_0.BigFoot_eada6c7b715e634a0f10a59caa7a63a2 ~= 0 and l_18_0.BigFoot_92fc56267c7e14d288fbcf74f912203d ~= 0 then
    return l_18_0.BigFoot_eada6c7b715e634a0f10a59caa7a63a2 - l_18_0.BigFoot_92fc56267c7e14d288fbcf74f912203d
  else
    return l_18_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9
  end
end

BFWidget.GetSize = function(l_19_0)
  return l_19_0:GetWidth(), l_19_0:GetHeight()
end

BFWidget.GetAbsPos = function(l_20_0)
  local l_20_1 = l_20_0:GetContainer()
  local l_20_2, l_20_3 = l_20_1:GetAbsPos, l_20_1
  return l_20_2(l_20_3)
end

BFWidget.SetAbsPos = function(l_21_0, ...)
  l_21_0.BigFoot_be4832c818b2e3a2514eb10ff20e906a = true
  l_21_0:GetContainer():SetAbsPos(...)
  local l_21_2 = nil
  l_21_0.BigFoot_92fc56267c7e14d288fbcf74f912203d = l_21_0:GetAbsPos()
end

BFWidget.BringToTop = function(l_22_0)
  local l_22_1 = l_22_0:GetContainer()
  l_22_1:BringToTop()
end

BFWidget.SetRelPos = function(l_23_0, ...)
  l_23_0.BigFoot_be4832c818b2e3a2514eb10ff20e906a = true
  l_23_0:GetContainer():SetRelPos(...)
end

BFWidget.GetHeight = function(l_24_0)
  if l_24_0.BigFoot_2f3acdeb071461a90aa82978f92256fc and l_24_0.BigFoot_0694c14294eb642e50750f9964155ae0 and l_24_0.BigFoot_2f3acdeb071461a90aa82978f92256fc ~= 0 and l_24_0.BigFoot_0694c14294eb642e50750f9964155ae0 ~= 0 then
    return l_24_0.BigFoot_2f3acdeb071461a90aa82978f92256fc - l_24_0.BigFoot_0694c14294eb642e50750f9964155ae0
  else
    return l_24_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656
  end
end

BFWidget.SetMousePenetrable = function(l_25_0, l_25_1)
  l_25_0:GetContainer():SetMousePenetrable(l_25_1)
end

BFWidget.SetAutoRePos = function(l_26_0, l_26_1)
  if not l_26_0.BigFoot_9dfb1939b1d4a2866bff81e8a8731203 then
    l_26_0.BigFoot_9dfb1939b1d4a2866bff81e8a8731203 = function()
    -- upvalues: l_26_0
    l_26_0:Update()
  end
  end
  if l_26_1 then
    RegisterEvent("RENDER_FRAME_UPDATE", l_26_0.BigFoot_9dfb1939b1d4a2866bff81e8a8731203)
  end
end

BigFoot_3374e5b93507b9453c76f21887136e97 = function(l_27_0, l_27_1)
  if l_27_1 == "TOPLEFT" then
    return l_27_0:GetLeft(), l_27_0:GetTop()
  elseif l_27_1 == "TOP" then
    return (l_27_0:GetLeft() + l_27_0:GetRight()) / 2, l_27_0:GetTop()
  elseif l_27_1 == "TOPRIGHT" then
    return l_27_0:GetRight(), l_27_0:GetTop()
  elseif l_27_1 == "LEFT" then
    return l_27_0:GetLeft(), (l_27_0:GetTop() + l_27_0:GetBottom()) / 2
  elseif l_27_1 == "CENTER" then
    return (l_27_0:GetLeft() + l_27_0:GetRight()) / 2, (l_27_0:GetTop() + l_27_0:GetBottom()) / 2
  elseif l_27_1 == "RIGHT" then
    return l_27_0:GetRight(), (l_27_0:GetTop() + l_27_0:GetBottom()) / 2
  elseif l_27_1 == "BOTTOMLEFT" then
    return l_27_0:GetLeft(), l_27_0:GetBottom()
  elseif l_27_1 == "BOTTOM" then
    return (l_27_0:GetLeft() + l_27_0:GetRight()) / 2, l_27_0:GetBottom()
  elseif l_27_1 == "BOTTOMRIGHT" then
    return l_27_0:GetRight(), l_27_0:GetBottom()
  else
    Output("anchor error")
  end
end

BFWidget.AddListener = function(l_28_0, l_28_1)
  local l_28_2, l_28_3 = nil, nil
  for i_1,i_2 in pairs(l_28_0.BigFoot_805a9734c44d6b2d0e1f802812148fb6) do
    if i_2 == l_28_1 then
      return 
    end
  end
  table.insert(l_28_0.BigFoot_805a9734c44d6b2d0e1f802812148fb6, l_28_1)
end

BFWidget.RemoveListener = function(l_29_0, l_29_1)
  local l_29_2, l_29_3 = nil, nil
  for i_1,i_2 in pairs(l_29_0.BigFoot_805a9734c44d6b2d0e1f802812148fb6) do
    if i_2 == l_29_1 then
      table.remove(l_29_0.BigFoot_805a9734c44d6b2d0e1f802812148fb6, i_1)
    end
  end
end

BFWidget._FireEvent = function(l_30_0, l_30_1, ...)
  local l_30_3 = nil
  for l_30_7,i_2 in pairs(l_30_0.BigFoot_805a9734c44d6b2d0e1f802812148fb6) do
    local l_30_4 = nil
    if i_2[l_30_1] then
      i_2[l_30_1](i_2, l_30_0, ...)
    end
  end
end

BFWidget.Update = function(l_31_0)
  local l_31_1, l_31_2, l_31_7, l_31_8 = nil, nil
  l_31_0:_UpdatePosition()
  l_31_0:_UpdateContent()
  for l_31_6,i_2 in pairs(l_31_0.BigFoot_fe68d264456494dec7daae6a568ef044) do
    local l_31_3 = {}
    l_31_3[i_2.widget] = true
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_31_12,l_31_13 in pairs(l_31_3) do
    local l_31_9 = nil
    if l_31_13.BigFoot_7ea16d69ee68978a562320944cf1ea36 then
      l_31_13:Update()
    end
  end
end

BFWidget._UpdateContent = function(l_32_0)
end

BFWidget._UpdatePosition = function(l_33_0)
  local l_33_1, l_33_2, l_33_3, l_33_4, l_33_5, l_33_6, l_33_7, l_33_8 = nil, nil, nil, nil, nil, nil, nil, nil
  if l_33_0.BigFoot_be4832c818b2e3a2514eb10ff20e906a then
    return 
  end
  if l_33_0.BigFoot_c5722e9259468ca80bc96627e0483d1f then
    l_33_4 = Station.GetClientSize(true)
    l_33_1 = 0
    l_33_3 = 
  else
    for i_1,i_2 in pairs(l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07) do
      l_33_7 = BigFoot_3374e5b93507b9453c76f21887136e97(i_2[2], i_2[3])
      l_33_7 = l_33_7 + i_2[4]
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if i_2[1] == "TOPLEFT" then
        l_33_1 = l_33_8
      elseif i_2[1] == "TOP" then
        l_33_1 = l_33_8
      elseif i_2[1] == "TOPRIGHT" then
        l_33_4 = l_33_7
        l_33_1 = l_33_8
       -- DECOMPILER ERROR: Overwrote pending register.

      elseif i_2[1] == "LEFT" then
        for i_1,i_2 in pairs(l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07) do
        end
        if i_2[1] == "CENTER" then
          for i_1,i_2 in pairs(l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07) do
          end
          if i_2[1] == "RIGHT" then
            l_33_4 = l_33_7
           -- DECOMPILER ERROR: Overwrote pending register.

          elseif i_2[1] == "BOTTOMLEFT" then
            l_33_3 = l_33_8
          elseif i_2[1] == "BOTTOM" then
            l_33_3 = l_33_8
          elseif i_2[1] == "BOTTOMRIGHT" then
            l_33_4 = l_33_7
            l_33_3 = l_33_8
          end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

        if (l_33_2 or not l_33_4 or not l_33_1) and l_33_3 then
          l_33_1 = l_33_3 - l_33_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656
        end
        if not l_33_4 and l_33_2 then
          l_33_4 = l_33_2 + l_33_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9
        end
        if not l_33_3 and l_33_1 then
          l_33_3 = l_33_1 + l_33_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656
        end
      if l_33_2 and l_33_4 and l_33_1 then
        end
      if l_33_2 then
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07[1] then
        l_33_7 = BigFoot_3374e5b93507b9453c76f21887136e97(l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07[1][2], l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07[1][3])
        w = l_33_0.BigFoot_0001857ddc87bc382cff1ce608260a07[1][2]:GetSize()
         -- DECOMPILER ERROR: Overwrote pending register.

        if l_33_2 or not l_33_4 then
          l_33_4 = l_33_7 + l_33_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9 / 2
        end
        if not l_33_1 then
          l_33_1 = l_33_8 - l_33_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656 / 2
        end
      end
      if not l_33_3 then
        l_33_3 = l_33_8 + l_33_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656 / 2
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_33_2 and l_33_4 then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_33_1 and l_33_3 then
        do return end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if ((((l_33_2 and not l_33_1) or l_33_4) and not l_33_3) or l_33_2) and l_33_1 then
        l_33_0.BigFoot_ac0723394133c458cf0a253e512eae56:SetAbsPos(l_33_2, l_33_1)
      end
      l_33_0.BigFoot_ac0723394133c458cf0a253e512eae56:SetSize(nil, nil)
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

BFScreen = BFWidget.new()
BFScreen.OnFrameCreate = function()
  BFScreen:SetContainer(this)
  BFScreen:Update()
  this:RegisterEvent("UI_SCALED")
end

BFScreen.OnEvent = function(l_35_0)
  if l_35_0 == "UI_SCALED" then
    BFScreen:Update()
  end
end

BFScreen.BigFoot_c5722e9259468ca80bc96627e0483d1f = true
 -- WARNING: undefined locals caused missing assignments!

