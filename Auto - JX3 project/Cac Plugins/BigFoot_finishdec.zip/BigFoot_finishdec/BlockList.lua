-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BlockList.lua 

local l_0_0 = BF_Block
do
  local l_0_1 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

end
 -- WARNING: undefined locals caused missing assignments!

