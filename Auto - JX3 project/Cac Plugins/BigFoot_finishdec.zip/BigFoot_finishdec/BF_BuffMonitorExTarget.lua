-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_BuffMonitorExTarget.lua 

local l_0_0 = {}
l_0_0.nDirection = 1
l_0_0.nWidth = 60
l_0_0.nHeight = 120
local l_0_1 = {}
l_0_1.s = "CENTER"
l_0_1.r = "CENTER"
l_0_1.x = 100
l_0_1.y = 50
l_0_0.Anchor = l_0_1
BuffMonitorExTarget = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "BuffMonitorExTarget.nDirection"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BuffMonitorExTarget.Anchor"
l_0_0(l_0_1)
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:Lookup("", ""):Clear()
  BuffMonitorExTarget.UpdateAnchor(this)
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function(l_2_0)
  if l_2_0 == "UI_SCALED" or l_2_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    BuffMonitorExTarget.UpdateAnchor(this)
  elseif l_2_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_2_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "Ŀ��")
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  this:CorrectPos()
  BuffMonitorExTarget.Anchor = GetFrameAnchor(this)
end

l_0_0.OnFrameDragEnd = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function(l_4_0)
  local l_4_1 = BuffMonitorExTarget.Anchor
  l_4_0:SetPoint(l_4_1.s, 0, 0, l_4_1.r, l_4_1.x, l_4_1.y)
  l_4_0:CorrectPos()
end

l_0_0.UpdateAnchor = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  local l_5_0 = this:Lookup("", "")
  local l_5_1 = 0
  if l_5_1 < l_5_0:GetItemCount() then
    local l_5_2 = l_5_0:Lookup(l_5_1)
    local l_5_3 = (l_5_2.nEndTime - GetTime()) / 1000
    local l_5_4 = ""
    if l_5_3 > 3600 then
      l_5_4 = math.ceil(l_5_3 / 3600) .. "h"
    elseif l_5_3 > 60 then
      l_5_4 = math.ceil(l_5_3 / 60) .. "m"
    elseif l_5_3 < 3 then
      l_5_4 = "%.1f":format(l_5_3)
    else
      l_5_4 = math.floor(l_5_3)
    end
    if l_5_3 < 0 then
      l_5_0:RemoveItem(l_5_1)
    else
      local l_5_5 = l_5_2:Lookup("TimeLeft")
      if l_5_3 < 3 and BF_BuffMonitorEx.bAnimate then
        local l_5_6 = l_5_2:Lookup("Box_F")
        l_5_6:Show()
        l_5_6:SetAlpha(BF_BuffMonitorEx.nAlpha * (l_5_3 % 1) / 1)
        scale = 1.7 ^ (1 - l_5_3 % 1 / 1)
        l_5_6:SetSize(l_5_6.org_w * scale, l_5_6.org_h * scale)
        l_5_6:SetRelPos(l_5_6.org_x - l_5_6.org_w * (scale - 1) / 2, l_5_6.org_y - l_5_6.org_h * (scale - 1) / 2)
        if l_5_3 - math.floor(l_5_3) > 0.5 then
          l_5_5:SetFontColor(255, 0, 0)
        else
          l_5_5:SetFontColor(255, 255, 255)
        end
      else
        l_5_2:Lookup("Box_F"):Hide()
      end
      l_5_5:SetText(l_5_4)
      if BuffMonitorExTarget.nDirection == 1 then
        l_5_2:SetRelPos(l_5_1 * (BuffMonitorExTarget.nWidth * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance), 0)
      else
        if BuffMonitorExTarget.nDirection == 2 then
          l_5_2:SetRelPos(0 - l_5_1 * (BuffMonitorExTarget.nWidth * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance), 0)
        end
      else
        if BuffMonitorExTarget.nDirection == 3 then
          l_5_2:SetRelPos(0, l_5_1 * (BuffMonitorExTarget.nHeight * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance))
        end
      else
        if BuffMonitorExTarget.nDirection == 4 then
          l_5_2:SetRelPos(0, 0 - l_5_1 * (BuffMonitorExTarget.nHeight * BF_BuffMonitorEx.nScale + BF_BuffMonitorEx.nDistance))
        end
        l_5_1 = l_5_1 + 1
      end
      l_5_2:FormatAllItemPos()
    end
  end
  l_5_0:FormatAllItemPos()
end

l_0_0.OnFrameRender = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function(l_6_0, l_6_1)
  local l_6_2 = l_6_0:GetItemCount() - 1
  for l_6_6 = 0, l_6_2 do
    local l_6_7 = l_6_0:Lookup(l_6_6)
    if l_6_7.dwBuffID == l_6_1 then
      return l_6_7
    end
  end
  return nil
end

l_0_0.GetTimerHandleByBuffID = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function(l_7_0, l_7_1, l_7_2, l_7_3)
  local l_7_4 = Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
  local l_7_5 = BuffMonitorExTarget.GetTimerHandleByBuffID(l_7_4, l_7_0)
  if l_7_5 then
    l_7_5:GetParent():RemoveItem(l_7_5)
  end
end

l_0_0.RemoveTimerHandle = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  return Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
end

l_0_0.GetAllTimeHandle = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  local l_9_0 = Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
  l_9_0:Clear()
end

l_0_0.ClearTimerHandle = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  local l_10_0 = Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
  l_10_0:Hide()
end

l_0_0.HideTimerHandle = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function()
  local l_11_0 = Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
  l_11_0:Show()
end

l_0_0.ShowTimerHandle = l_0_1
l_0_0 = BuffMonitorExTarget
l_0_1 = function(l_12_0, l_12_1, l_12_2, l_12_3, l_12_4, l_12_5)
  local l_12_6 = Station.Lookup("Topmost/BuffMonitorExTarget"):Lookup("", "")
  local l_12_7 = BuffMonitorExTarget.GetTimerHandleByBuffID(l_12_6, l_12_0)
  if not l_12_7 then
    local l_12_8 = "interface\\BF_BuffMonitorEx\\BF_BuffMonitorExTarget.ini"
    l_12_6:AppendItemFromIni(l_12_8, "Hanele_Timer")
    l_12_7 = l_12_6:Lookup(l_12_6:GetItemCount() - 1)
    l_12_7:Scale(BF_BuffMonitorEx.nScale, BF_BuffMonitorEx.nScale)
    l_12_7:SetRelPos((l_12_6:GetItemCount() - 1) * BF_BuffMonitorEx.nDistance, 0)
    l_12_7:SetAlpha(BF_BuffMonitorEx.nAlpha)
    local l_12_9 = l_12_7:Lookup("Box_F")
    local l_12_10 = l_12_9:GetRelPos()
    l_12_9.org_y = l_12_9
    l_12_9.org_x = l_12_10
     -- DECOMPILER ERROR: Overwrote pending register.

    l_12_9.org_h = l_12_9
    l_12_9.org_w = l_12_10
     -- DECOMPILER ERROR: Overwrote pending register.

    l_12_10(l_12_6)
  end
  l_12_7.dwBuffID = l_12_0
  l_12_7.dwBuffLevel = l_12_1
  l_12_7.nEndTime = GetTime() + (l_12_3 - GetLogicFrameCount()) * 1000 / 16
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_12_11 = l_12_7:Lookup(l_12_10)
  l_12_11:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_12_0)
  l_12_11:SetObjectIcon(Table_GetBuffIconID(l_12_0, l_12_1))
  l_12_11:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
  l_12_11:SetOverTextFontScheme(0, 15)
  if l_12_2 > 1 then
    l_12_11:SetOverText(0, l_12_2)
  else
    l_12_11:SetOverText(0, "")
  end
  l_12_11 = l_12_7:Lookup("Box_F")
  l_12_11:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_12_0)
  l_12_11:SetObjectIcon(Table_GetBuffIconID(l_12_0, l_12_1))
  l_12_11:Hide()
  if l_12_4 then
    if l_12_5 then
      l_12_7:Lookup("BuffName"):SetFontColor(255, 255, 0)
    else
      l_12_7:Lookup("BuffName"):SetFontColor(0, 255, 0)
    end
  elseif l_12_5 then
    l_12_7:Lookup("BuffName"):SetFontColor(255, 255, 0)
  else
    l_12_7:Lookup("BuffName"):SetFontColor(255, 0, 0)
  end
  l_12_7:Lookup("BuffName"):SetText(Table_GetBuffName(l_12_0, l_12_1))
end

l_0_0.CreateTimerHandle = l_0_1
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "interface\\BF_BuffMonitorEx\\BF_BuffMonitorExTarget.ini"
l_0_0(l_0_1, "BuffMonitorExTarget")

