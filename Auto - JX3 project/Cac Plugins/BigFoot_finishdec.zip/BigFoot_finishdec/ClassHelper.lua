-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ClassHelper.lua 

local l_0_0 = {}
l_0_0.TCCount = 5
BF_ClassHelper = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BF_ClassHelper.TCCount")
l_0_0 = BF_ClassHelper
l_0_0.TCChangeActionBar = function()
  if BF_ClassHelper.enabled then
    local l_1_0 = GetClientPlayer()
  end
  if l_1_0 and l_1_0.dwForceID == 3 then
    local l_1_1 = arg0
    local l_1_2 = arg1
    local l_1_3 = arg4
  end
  if l_1_2 then
    if not BF_ClassHelper.BigFoot_4f256c721a0f14c5bd7b75b6b8c8f395 then
      SelectMainActionBarPage(l_1_1 ~= l_1_0.dwID or l_1_3 ~= 244 or 1)
  else
    end
  end
  BF_ClassHelper.BigFoot_4f256c721a0f14c5bd7b75b6b8c8f395 = nil
  SelectMainActionBarPage(3)
  if BF_ClassHelper.TCCount > 0 then
    local l_1_4 = GetMsgFontString("MSG_SYS")
    BigFoot_Print("ְҵ����", "��������Զ��л��������������������ҳ��������ڡ�������á�-��ְҵ���֡��йرմ˹��ܡ�")
    BF_ClassHelper.TCCount = BF_ClassHelper.TCCount - 1
  end
end

l_0_0 = BF_ClassHelper
l_0_0.BinFB = function()
  local l_2_0 = GetClientPlayer()
  if l_2_0 and l_2_0.dwForceID == 3 then
    if l_2_0.bOnHorse then
      BigFoot_DelayCall(SelectMainActionBarPage, 100, 3)
    end
  else
    SelectMainActionBarPage(BF_ClassHelper.BigFoot_4f256c721a0f14c5bd7b75b6b8c8f395 or 1)
  end
end

l_0_0 = RegisterEvent
l_0_0("SYNC_ROLE_DATA_END", function()
  BigFoot_DelayCall(BF_ClassHelper.BinFB, 1000)
end
)
l_0_0 = RegisterEvent
l_0_0("BUFF_UPDATE", BF_ClassHelper.TCChangeActionBar)
l_0_0 = BFMods
l_0_0 = l_0_0.ClassHelper
if not l_0_0 then
  l_0_0 = BFConfigPanel
  l_0_0 = l_0_0.RegisterMod
  l_0_0("ClassHelper", "ְҵ����", "\\ui\\image\\icon\\medic31.tga", "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
end
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_0("ClassHelper", "EnableTCAutoChangeActionBar", "��������Զ��л�������", false, function(l_4_0)
  if l_4_0 then
    BF_ClassHelper.enabled = true
  else
    BF_ClassHelper.enabled = nil
  end
end
)

