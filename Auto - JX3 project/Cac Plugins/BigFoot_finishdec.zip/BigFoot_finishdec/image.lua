-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: image.lua 

BFImage = classv2(BFWidget)
BFImage.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4, l_1_5)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  l_1_0:SetImage(l_1_4, l_1_5)
  l_1_0:SetImageType("NORMAL")
end

BFImage.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = assert
  l_2_3(l_2_1 >= 0 and l_2_1 >= 0, "Invalid widget size.")
  l_2_3 = Wnd
  l_2_3 = l_2_3.OpenWindow
  l_2_3 = l_2_3("Interface\\BF_Base\\widget\\Image.ini", l_2_0:GetName())
  local l_2_6 = l_2_3:Lookup("Wnd_Main")
  l_2_0:SetContainer(l_2_6)
  l_2_0:SetSize(l_2_1, l_2_2)
end

BFImage.SetImage = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = l_3_0:GetContainer()
  local l_3_4 = l_3_3:Lookup("", "")
  local l_3_5 = l_3_4:Lookup("Image_Main")
  if type(l_3_1) == "string" then
    if l_3_2 then
      l_3_5:FromUITex(l_3_1, l_3_2)
    else
      l_3_5:FromTextureFile(l_3_1)
    end
  else
    if type(l_3_1) == "number" then
      l_3_5:FromIconID(l_3_1)
    end
  end
end

BFImage.SetFrame = function(l_4_0, l_4_1)
  local l_4_2 = l_4_0:GetContainer()
  local l_4_3 = l_4_2:Lookup("", "")
  local l_4_4 = l_4_3:Lookup("Image_Main")
  l_4_4:SetFrame(l_4_1)
end

BFImage.GetFrame = function(l_5_0)
  local l_5_1 = l_5_0:GetContainer()
  local l_5_2 = l_5_1:Lookup("", "")
  local l_5_3 = l_5_2:Lookup("Image_Main")
  local l_5_4, l_5_5 = l_5_3:GetFrame, l_5_3
  return l_5_4(l_5_5)
end

BFImage.SetAlpha = function(l_6_0, l_6_1)
  local l_6_2 = l_6_0:GetContainer()
  local l_6_3 = l_6_2:Lookup("", "")
  local l_6_4 = l_6_3:Lookup("Image_Main")
  l_6_4:SetAlpha(l_6_1)
end

BFImage.SetPercentage = function(l_7_0, l_7_1)
  local l_7_2 = l_7_0:GetContainer()
  local l_7_3 = l_7_2:Lookup("", "")
  local l_7_4 = l_7_3:Lookup("Image_Main")
  l_7_4:SetPercentage(l_7_1)
end

BFImage.GetPercentage = function(l_8_0)
  local l_8_1 = l_8_0:GetContainer()
  local l_8_2 = l_8_1:Lookup("", "")
  local l_8_3 = l_8_2:Lookup("Image_Main")
  local l_8_4, l_8_5 = l_8_3:GetPercentage, l_8_3
  return l_8_4(l_8_5)
end

BFImage.SetRotate = function(l_9_0, l_9_1)
  local l_9_2 = l_9_0:GetContainer()
  local l_9_3 = l_9_2:Lookup("", "")
  local l_9_4 = l_9_3:Lookup("Image_Main")
  l_9_4:SetRotate(l_9_1)
end

BFImage.GetRotate = function(l_10_0)
  local l_10_1 = l_10_0:GetContainer()
  local l_10_2 = l_10_1:Lookup("", "")
  local l_10_3 = l_10_2:Lookup("Image_Main")
  local l_10_4, l_10_5 = l_10_3:GetRotate, l_10_3
  return l_10_4(l_10_5)
end

BFImage.SetImageType = function(l_11_0, l_11_1)
  local l_11_2 = l_11_0:GetContainer()
  local l_11_3 = l_11_2:Lookup("", "")
  local l_11_4 = (l_11_3:Lookup("Image_Main"))
  local l_11_5 = nil
  if l_11_1 == "NORMAL" then
    l_11_5 = IMAGE.NORMAL
  elseif l_11_1 == "LEFT_RIGHT" then
    l_11_5 = IMAGE.LEFT_RIGHT
  elseif l_11_1 == "RIGHT_LEFT" then
    l_11_5 = IMAGE.RIGHT_LEFT
  elseif l_11_1 == "TOP_BOTTOM" then
    l_11_5 = IMAGE.TOP_BOTTOM
  elseif l_11_1 == "BOTTOM_TOP" then
    l_11_5 = IMAGE.BOTTOM_TOP
  elseif l_11_1 == "TIMER" then
    l_11_5 = IMAGE.TIMER
  elseif l_11_1 == "ROTATE" then
    l_11_5 = IMAGE.ROTATE
  elseif l_11_1 == "FLIP_HORIZONTAL" then
    l_11_5 = IMAGE.FLIP_HORIZONTAL
  elseif l_11_1 == "FLIP_VERTICAL" then
    l_11_5 = IMAGE.FLIP_VERTICAL
  elseif l_11_1 == "FLIP_CENTRAL" then
    l_11_5 = IMAGE.FLIP_CENTRAL
  elseif l_11_1 == "NINE_PART" then
    l_11_5 = IMAGE.NINE_PART
  elseif l_11_1 == "LEFT_CENTER_RIGHT" then
    l_11_5 = IMAGE.LEFT_CENTER_RIGHT
  elseif l_11_1 == "TOP_CENTER_BOTTOM" then
    l_11_5 = IMAGE.TOP_CENTER_BOTTOM
  else
    assert(false, "Unknown image type.")
  end
  l_11_4:SetImageType(l_11_5)
end

BFImage._UpdateContent = function(l_12_0)
  local l_12_1 = l_12_0:GetContainer()
  local l_12_2 = l_12_1:Lookup("", "")
  local l_12_3 = l_12_2:Lookup("Image_Main")
  l_12_3:SetSize(l_12_0:GetWidth(), l_12_0:GetHeight())
end


