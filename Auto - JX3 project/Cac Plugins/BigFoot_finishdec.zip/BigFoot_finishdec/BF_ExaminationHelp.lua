-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_ExaminationHelp.lua 

local l_0_0 = {}
l_0_0.Enabled = true
l_0_0.AnswerString = "SD(JS),2:D,B,C,D,A,A,C,D,A,B,D,C,A,A,ABC,BCD,Daefa,���Դ�,���������,���������,"
l_0_0.AnswerTable = nil
BF_ExaminationHelp = l_0_0
BF_ExaminationHelp.UpdateExamContent = function(l_1_0)
  -- upvalues: l_0_0
  BF_ExaminationHelp.BigFoot_94034bd11d2c022b388f568b5b4bf2b3(l_1_0)
  if not BF_ExaminationHelp.Enabled then
    return 
  end
  local l_1_1 = l_1_0.nType
  local l_1_2 = ExaminationPanel.tExamContentList[l_1_0.nOrderIndex]
  if not l_1_2 then
    return 
  end
  do
    if l_1_1 == l_0_0.SIMPLE_SELECTION then
      function()
    -- upvalues: l_1_2 , l_1_1
    if not l_1_2 or not l_1_2.tSelections then
      return 
    end
    if BF_ExaminationHelp.AnswerTable then
      local l_2_0 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_2_4,l_2_5 in false(false) do
        local l_2_6 = ExaminationPanel.wndExamPage[l_1_1]:Lookup("CheckBox_T%dNo%d":format(l_1_1, l_2_4))
        local l_2_7 = l_2_6:Lookup("", "Text_T%dNo%d":format(l_1_1, l_2_4))
        if l_2_7 then
          local l_2_8 = l_2_7:GetText()
          if not string.find(l_2_8, "��ȷ��") and l_2_8 == BF_ExaminationHelp.AnswerTable then
            l_2_7:SetText(l_2_8 .. " (��ȷ��)")
            l_2_7:SetFontColor(255, 0, 0)
          end
        else
          l_2_7:SetFontColor(0, 0, 0)
        end
      end
    end
     -- WARNING: undefined locals caused missing assignments!
  end()
      do break end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_1_1 == l_0_0.MULTIPLE_SELECTION then
      function()
    -- upvalues: l_1_2 , l_1_1
    if not l_1_2 or not l_1_2.tSelections then
      return 
    end
    if BF_ExaminationHelp.AnswerTable then
      local l_2_0 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_2_4,l_2_5 in false(false) do
        local l_2_6 = ExaminationPanel.wndExamPage[l_1_1]:Lookup("CheckBox_T%dNo%d":format(l_1_1, l_2_4))
        local l_2_7 = l_2_6:Lookup("", "Text_T%dNo%d":format(l_1_1, l_2_4))
        if l_2_7 then
          local l_2_8 = l_2_7:GetText()
          if not string.find(l_2_8, "��ȷ��") and l_2_8 == BF_ExaminationHelp.AnswerTable then
            l_2_7:SetText(l_2_8 .. " (��ȷ��)")
            l_2_7:SetFontColor(255, 0, 0)
          end
        else
          l_2_7:SetFontColor(0, 0, 0)
        end
      end
    end
     -- WARNING: undefined locals caused missing assignments!
  end()
      do break end
    end
    if l_1_1 == l_0_0.GAP_FILLING then
      local l_1_4 = nil
      if BF_ExaminationHelp.AnswerTable then
        ExaminationPanel.wndExamPage[l_1_1]:Lookup("Edit_Anwer"):SetText(BF_ExaminationHelp.AnswerTable)
      end
      do break end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_1_1 == l_0_0.IMAGE_SELECTION then
      l_1_4()
      local l_1_5 = nil
      local l_1_6 = ExaminationPanel.wndExamPage[l_1_1]:Lookup("", "Image_Type4")
      l_1_6:FromIconID(tonumber(Table_GetBookContent(Table_GetBookPageID(l_1_2.nBookID, l_1_2.nSegmentID, 0))))
      local l_1_7 = nil
      for l_1_11 = 1, 9 do
        local l_1_8 = ExaminationPanel.wndExamPage[l_1_1]:Lookup("", "Handle_Type4Cover")
         -- DECOMPILER ERROR: Confused about usage of registers!

        temptest123 = l_1_8:Lookup("Image_C%d":format(0))
        if l_1_2.tImageMask[l_1_12] then
          l_1_8:Lookup("Image_C%d":format(0)):Show()
        else
          l_1_8:Lookup("Image_C%d":format(0)):Hide()
        end
      end
    else
      ExaminationPanel.wndExamPage[l_1_1]:Hide()
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

BF_ExaminationHelp.UpdateTitle = function(l_2_0)
  BF_ExaminationHelp.BigFoot_effdcd01003fcadf26f49d220e123fb5(l_2_0)
  BF_ExaminationHelp:SetCurrentQuestionAnswer(l_2_0)
  if not BF_ExaminationHelp.Enabled then
    return 
  end
  if ExaminationPanel.nLastQuestionIndex and ExaminationPanel.tExamContentList then
    local l_2_1 = ExaminationPanel.tExamContentList[ExaminationPanel.nLastQuestionIndex]
  end
  if l_2_1 and l_2_1.szContent then
    local l_2_2 = ""
    if l_2_1.tSelections and type(l_2_1.tSelections) == "table" then
      for l_2_6,l_2_7 in pairs(l_2_1.tSelections) do
        l_2_2 = l_2_2 .. tostring(l_2_7) .. "|"
      end
    end
    Interaction_Request("BF_ExaminationHelp", "http://bfservice.178.com", "/app/jx3/exam/index.php?question=" .. string.format("%s", base64(l_2_1.szContent)) .. "&options=" .. string.format("%s", base64(l_2_2)), "", 80)
  end
end

BF_ExaminationHelp.UnpackAnswerString = function(l_3_0)
  local l_3_1 = {}
  local l_3_2 = 0
  local l_3_3 = nil
  local l_3_4 = "JS"
  local l_3_5, l_3_6, l_3_7, l_3_8 = GetVersion()
  if l_3_8 == "snda" then
    l_3_4 = "SD"
  end
  local l_3_9 = string.sub(l_3_0, 1, 2)
  if l_3_4 ~= l_3_9 then
    return l_3_1
  end
  l_3_0 = string.sub(l_3_0, 4, -1)
  for l_3_13 = 1, string.len(l_3_0) do
    if l_3_2 + 1 <= string.len(l_3_0) then
      local l_3_14 = string.find(l_3_0, ",", l_3_2 + 1)
      if l_3_2 == 0 then
        local l_3_15 = string.find(l_3_0, ":")
        l_3_3 = string.sub(l_3_0, 0, l_3_15 - 1)
        l_3_3 = tonumber(l_3_3)
        l_3_1[l_3_3] = {}
        local l_3_16 = string.sub(l_3_0, l_3_15 + 1, l_3_14 - 1)
        table.insert(l_3_1[l_3_3], l_3_16)
        l_3_2 = l_3_14
      end
    else
      local l_3_17 = string.sub(l_3_0, l_3_2 + 1, l_3_14 - 1)
      if l_3_1[l_3_3] then
        table.insert(l_3_1[l_3_3], l_3_17)
      end
      l_3_2 = l_3_14
    end
  end
  return l_3_1
end

BF_ExaminationHelp.SetCurrentQuestionAnswer = function(l_4_0, l_4_1)
  local l_4_2 = ""
  if l_4_1 then
    l_4_2 = g_tStrings.EXAM_TITLES.REQUEST_NOTE
  end
  local l_4_3 = g_tStrings.EXAM_TITLES.NAME:format(ExaminationPanel.ConversionNumber(ExaminationPanel.nPromoteTime), g_tStrings.EXAM_TITLES.TYPE[ExaminationPanel.nTestType], ExaminationPanel.ConversionNumber(ExaminationPanel.nLastQuestionIndex), l_4_2)
  if l_4_0.Enabled and not l_4_1 then
    if BF_ExaminationHelp.AnswerTable then
      l_4_3 = l_4_3 .. " (�ƾ������ѿ���)"
    end
  else
    l_4_3 = l_4_3 .. " (���ݻ�ȡʧ�ܡ��ƾ����ֹر�)"
  end
  Station.Lookup("Normal/ExaminationPanel"):Lookup("", "Text_Title"):SetText(l_4_3)
  local l_4_4 = ExaminationPanel.handleIconList:Lookup("Image_List%02d":format(ExaminationPanel.nCurrentQuestionIndex))
  if not l_4_4 then
    return 
  end
  local l_4_5 = l_4_4.nType
  for l_4_9 = 1, 4 do
    local l_4_10 = ExaminationPanel.wndExamPage[l_4_5]:Lookup("CheckBox_T%dNo%d":format(l_4_5, l_4_9))
    if not l_4_10 then
      return 
    end
    local l_4_11 = l_4_10:Lookup("", "Text_T%dNo%d":format(l_4_5, l_4_9))
    if l_4_11 and not BF_ExaminationHelp.Enabled then
      l_4_11:SetFontColor(0, 0, 0)
    end
  end
end

BF_ExaminationHelp = {}
BF_ExaminationHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(0, 0, "NONE")
local l_0_1 = 0
BF_ExaminationHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnUpdate = function(l_5_0)
  -- upvalues: l_0_1 , l_0_0
  local l_5_1 = Station.Lookup("Normal/ExaminationPanel")
  if GetTime() - l_0_1 > 1000 then
    l_0_1 = GetTime()
  end
  if l_5_1 and l_5_1:IsVisible() then
    local l_5_2 = l_5_1:Lookup("", "Handle_ExamContents")
    local l_5_3 = l_5_2:Lookup(0):GetText()
    BF_ExaminationHelp.AnswerTable = BF_examinationData[l_5_3]
    local l_5_4 = {}
    local l_5_5 = l_0_0.SIMPLE_SELECTION
    l_5_4[l_5_5] = l_5_1:Lookup("Wnd_Type1")
    l_5_5 = l_0_0
    l_5_5 = l_5_5.MULTIPLE_SELECTION
    l_5_4[l_5_5] = l_5_1:Lookup("Wnd_Type2")
    l_5_5 = l_0_0
    l_5_5 = l_5_5.GAP_FILLING
    l_5_4[l_5_5] = l_5_1:Lookup("Wnd_Type3")
    l_5_5 = l_0_0
    l_5_5 = l_5_5.IMAGE_SELECTION
    l_5_4[l_5_5] = l_5_1:Lookup("Wnd_Type4")
    l_5_5 = nil
    local l_5_6 = {}
    local l_5_7 = false
    do break end
    do
      local l_5_8, l_5_9, l_5_10, l_5_11, l_5_12 = pairs(l_5_4)
      l_5_5 = l_5_12
      if l_5_5 and l_5_5:IsVisible() then
        if l_5_11 == l_0_0.SIMPLE_SELECTION or l_5_11 == l_0_0.MULTIPLE_SELECTION then
          for l_5_16 = 1, 4 do
            local l_5_17 = l_5_5:Lookup("CheckBox_T%dNo%d":format(l_5_11, l_5_16))
            local l_5_18 = l_5_17:Lookup("", "Text_T%dNo%d":format(l_5_11, l_5_16))
            if l_5_17 and l_5_17:IsVisible() then
              table.insert(l_5_6, l_5_18:GetText())
              if BF_ExaminationHelp.AnswerTable and l_5_18:GetText() == BF_ExaminationHelp.AnswerTable then
                if BF_ExaminationHelp.Enabled then
                  l_5_7 = true
                  l_5_18:SetText(BF_ExaminationHelp.AnswerTable .. " (��ȷ��)")
                  l_5_18:SetFontColor(255, 0, 0)
                  BF_ExaminationHelp.AnswerTable = nil
                end
              else
                l_5_18:SetFontColor(0, 0, 0)
              end
            else
              if l_5_18:GetText():find("(��ȷ��)") then
                l_5_7 = true
              end
            else
              l_5_18:SetFontColor(0, 0, 0)
            end
          end
        end
      else
        if l_5_11 == l_0_0.GAP_FILLING then
          local l_5_19 = l_5_5:Lookup("Edit_Anwer")
        end
        if BF_ExaminationHelp.AnswerTable then
          l_5_7 = true
          l_5_19:SetText(BF_ExaminationHelp.AnswerTable)
          BF_ExaminationHelp.AnswerTable = nil
        end
    else
      if l_5_11 == l_0_0.IMAGE_SELECTION then
        end
      end
    end
    local l_5_20, l_5_30 = ""
    l_5_30 = pairs
    l_5_30 = l_5_30(l_5_6)
    for l_5_24,l_5_25 in l_5_30 do
      local l_5_25 = nil
      l_5_25 = l_5_20
      l_5_20 = l_5_25 .. tostring(l_5_24) .. "|"
    end
  end
  if not l_5_7 then
    local l_5_26, l_5_28, l_5_31 = nil
    l_5_26, l_5_28 = l_5_1:Lookup("", "Text_Title"):GetText, l_5_1:Lookup("", "Text_Title")
    l_5_26 = l_5_26(l_5_28)
    l_5_26, l_5_28 = l_5_26:find, l_5_26
    l_5_31 = "(�ƾ������ѿ���)"
    l_5_26 = l_5_26(l_5_28, l_5_31)
  end
  if not l_5_26 then
    l_5_26, l_5_28 = l_5_1:Lookup("", "Text_Title"):GetText, l_5_1:Lookup("", "Text_Title")
    l_5_26 = l_5_26(l_5_28)
    do
      local l_5_27, l_5_29, l_5_32 = nil
      l_5_28 = l_5_26
      l_5_31 = " (�ƾ������ѿ���)"
      l_5_26 = l_5_28 .. l_5_31
      l_5_28, l_5_31 = l_5_1:Lookup("", "Text_Title"):SetText, l_5_1:Lookup("", "Text_Title")
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_5_28(l_5_31, l_5_26)
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 185 
end

RegisterEvent("INTERACTION_REQUEST_RESULT", function()
  if arg0 == "BF_ExaminationHelp" and arg1 and arg3 > 0 then
    local l_6_0 = arg2
    BF_ExaminationHelp.AnswerTable = l_6_0
  end
end
)
BF_ExaminationHelpUpdateTitle = function(l_7_0)
end

BFConfigPanel.RegisterMod("ExaminationHelp", "��������", "\\ui\\image\\icon\\book02.tga", "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
BFConfigPanel.RegisterCheckButton("ExaminationHelp", "ShowExaminationHelp", "��ʾ�ƾٿ�����ʾ(���ܻή����Ϸ��Ȥ�����ʹ��)", true, function(l_8_0, l_8_1)
  if l_8_0 then
    BF_ExaminationHelp.Enabled = true
  else
    BF_ExaminationHelp.Enabled = false
  end
end
)

