-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SkillTimer.lua 

SkillTimer = {}
SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e = {}
SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27 = {}
SkillTimer.BigFoot_8cad082e1332b16fb3f0a7cce759e0a8 = {}
SkillTimer.BigFoot_77b236c3eeb76bc3f6078586f18490fc = 0
local l_0_0 = SkillTimer
local l_0_1 = {}
l_0_1[180] = false
l_0_1[189] = false
l_0_1[190] = false
l_0_0.BigFoot_3f9a559e8d84ade456cc899c3bc79dba = l_0_1
SkillTimer_hottiming, l_0_0 = l_0_0, {}
l_0_0 = SkillTimer
l_0_0.definitionbuffs, l_0_1 = l_0_1, {}
l_0_0 = SkillTimer
local l_0_2 = {}
local l_0_3 = {}
l_0_3.type = "buff"
l_0_2["��Ѩ"] = l_0_3
l_0_2["���"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["ѣ��"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["����"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["��Ĭ"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["��ע"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["ä��"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["̽÷"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["��"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["��ҡֱ��"], l_0_3 = l_0_3, {type = "buff"}
l_0_2["ͬ��"], l_0_3 = l_0_3, {type = "debuff"}
l_0_2["�ͻ���ɽ"], l_0_3 = l_0_3, {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_2 = {["��Ѫ"] = l_0_3, ["��"] = l_0_3, ["����ͻ"] = l_0_3, ["������"] = l_0_3, ["Х�绢"] = l_0_3, ["ͻ"] = l_0_3, ["����ɽ"] = l_0_3, ["�γ۳�"] = l_0_3, ["�Ѳ��"] = l_0_3, ["����"] = l_0_3, ["�����"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["��"] = l_0_3, ["��ˮ"] = l_0_3, ["����"] = l_0_3, ["�²�"] = l_0_3, ["�˵�"] = l_0_3, ["�Ʒ�"] = l_0_3}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "debuff"}
l_0_2 = {["����"] = l_0_3, ["����ع��"] = l_0_3, ["����"] = l_0_3, ["��¥��Ӱ"] = l_0_3, ["����"] = l_0_3, ["̫��ָ"] = l_0_3, ["ˮ���޼�"] = l_0_3, ["����ָ"] = l_0_3, ["��������"] = l_0_3, ["����ָ"] = l_0_3, ["��������"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["��������"] = l_0_3, ["ܽ�ز���"] = l_0_3, ["���໤��"] = l_0_3, ["��ˮ����"] = l_0_3, ["��������"] = l_0_3, ["�ɹ�"] = l_0_3, ["����ָ"] = l_0_3, ["���"] = l_0_3}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "static"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "static"}
l_0_3 = {type = "static"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_2 = {["׽Ӱ"] = l_0_3, ["תǬ��"] = l_0_3, ["��ɽ��"] = l_0_3, ["��"] = l_0_3, ["�꼯"] = l_0_3, ["������"] = l_0_3, ["������"] = l_0_3, ["躹�����"] = l_0_3, ["���ǳ�"] = l_0_3, ["��һ����"] = l_0_3, ["��������"] = l_0_3, ["�����ֻ�"] = l_0_3, ["��̫��"] = l_0_3, ["���Ż���"] = l_0_3, ["���ǹ���"] = l_0_3, ["�Ʋ��"] = l_0_3, ["ƾ������"] = l_0_3, ["��̫��"] = l_0_3, ["���ɾ���"] = l_0_3, ["������"] = l_0_3, ["������"] = l_0_3, ["���Զ���"] = l_0_3, ["�������"] = l_0_3, ["������"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_2 = {["Ӱ��"] = l_0_3, ["�������"] = l_0_3, ["��صͰ�"] = l_0_3, ["��Ԫ����"] = l_0_3, ["ȵ̤֦"] = l_0_3, ["������ŭ"] = l_0_3, ["����ͨ��"] = l_0_3, ["��������"] = l_0_3, ["��������"] = l_0_3, ["����"] = l_0_3, ["��������"] = l_0_3, ["����"] = l_0_3, ["�벽��"] = l_0_3, ["ѸӰ"] = l_0_3}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_2 = {["�������"] = l_0_3, ["����Ǭ��"] = l_0_3, ["���̽Կ�"] = l_0_3, ["�����"] = l_0_3, ["ǧ��׹"] = l_0_3, ["Ħڭ����"] = l_0_3, ["�޺�����"] = l_0_3, ["��ɽʩ��"] = l_0_3, ["���سɷ�"] = l_0_3, ["���ŭĿ"] = l_0_3, ["��ӽ�ɳ"] = l_0_3, ["��������"] = l_0_3, ["����ʽ"] = l_0_3, ["����ʽ"] = l_0_3, ["�۹�"] = l_0_3, ["����ʽ"] = l_0_3, ["��ɨ����"] = l_0_3, ["�����"] = l_0_3, ["������"] = l_0_3, ["����"] = l_0_3, ["����ʽ"] = l_0_3}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "hot"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_2 = {["ʥ��֯��"] = l_0_3, ["Ů洲���"] = l_0_3, ["���ԡ��"] = l_0_3, ["�ƻ�����"] = l_0_3, ["����"] = l_0_3, ["��������"] = l_0_3, ["����ݲ�"] = l_0_3, ["�Х"] = l_0_3, ["�Х����"] = l_0_3, ["ǧ˿"] = l_0_3, ["ǧ˿����"] = l_0_3, ["��Ӱ"] = l_0_3, ["��Ӱ����"] = l_0_3, ["��Ӱ����"] = l_0_3, ["��Ӱ�ݲ�"] = l_0_3, ["Ы������"] = l_0_3, ["Ы�Ŀݲ�"] = l_0_3, ["�߹�"] = l_0_3, ["�ù�"] = l_0_3, ["�Ի�"] = l_0_3, ["�Ƴ��"] = l_0_3, ["��Ϸˮ"] = l_0_3, ["���Ͼ�"] = l_0_3}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_2 = {["Ѱ÷"] = l_0_3, ["����"] = l_0_3, ["�෵"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["Х��"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["ݺ��"] = l_0_3, ["������"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["����"] = l_0_3, ["��Ȫ��Ծ"] = l_0_3, ["����"] = l_0_3, ["��ѩ"] = l_0_3, ["����"] = l_0_3, ["�紵��"] = l_0_3, ["�׹��ɽ"] = l_0_3}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "buff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_3 = {type = "debuff"}
l_0_2 = {["����"] = l_0_3, ["��������"] = l_0_3, ["����"] = l_0_3, ["�һ����"] = l_0_3, ["ѸӰ"] = l_0_3, ["������Ⱥ"] = l_0_3, ["��Ӱ"] = l_0_3, ["������ɢ"] = l_0_3, ["������"] = l_0_3, ["��������"] = l_0_3, ["������Ӱ"] = l_0_3, ["����"] = l_0_3, ["��Ѫ��"] = l_0_3, ["����"] = l_0_3, ["������"] = l_0_3, ["����"] = l_0_3, ["����޼"] = l_0_3, ["÷����"] = l_0_3, ["�ϻ�ɰ"] = l_0_3, ["������"] = l_0_3, ["��צ"] = l_0_3, ["���켬��"] = l_0_3, ["����"] = l_0_3}
l_0_2 = {}
l_0_2 = {}
l_0_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a, l_0_1 = l_0_1, {[0] = l_0_2, [3] = l_0_2, [2] = l_0_2, [4] = l_0_2, [5] = l_0_2, [1] = l_0_2, [6] = l_0_2, [8] = l_0_2, [7] = l_0_2, [9] = l_0_2, [10] = l_0_2}
l_0_0 = RegisterCustomData
l_0_1 = "SkillTimer.definitionbuffs"
l_0_0(l_0_1)
l_0_0 = SkillTimer
l_0_1 = function()
  SkillTimer.InitAvailableSkills()
end

l_0_0.OnCustomDataLoad = l_0_1
l_0_0 = RegisterEvent
l_0_1 = "CUSTOM_DATA_LOADED"
l_0_2 = function()
  BigFoot_DelayCall(SkillTimer.OnCustomDataLoad, 2000)
end

l_0_0(l_0_1, l_0_2)
l_0_0 = SkillTimer
l_0_1 = function(l_3_0)
  local l_3_1 = GetClientPlayer()
  if not l_3_1 then
    return 
  end
  local l_3_2, l_3_3, l_3_4 = nil, nil, nil
  local l_3_5, l_3_6 = l_3_1.GetTarget()
  if l_3_1.dwID == l_3_0 then
    l_3_3 = l_3_1.szName
    l_3_2 = l_3_1.GetBuffList()
  else
    l_3_4 = GetTargetHandle(l_3_5, l_3_6)
  end
  if l_3_4 and l_3_0 == l_3_4.dwID then
    l_3_3 = l_3_4.szName
    l_3_2 = l_3_4.GetBuffList()
  end
  local l_3_7 = (GetLogicFrameCount())
  local l_3_8, l_3_9, l_3_10, l_3_11 = nil, nil, nil, nil
  local l_3_12 = {}
  for l_3_16,l_3_17 in ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e) do
    if l_3_17.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_3_0 and l_3_17:IsShown() then
      for l_3_21,l_3_22 in ipairs(l_3_17.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
        local l_3_23 = l_3_17.BigFoot_8d0febf2348ea712b2b375ae95601d5f .. ":" .. l_3_22.BigFoot_8d0febf2348ea712b2b375ae95601d5f
        local l_3_24 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      end
    end
  end
  if l_3_2 then
    for l_3_28,l_3_29 in pairs(l_3_2) do
      local l_3_30 = Table_GetBuffName(l_3_29.dwID, l_3_29.nLevel)
      if not SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd then
        SkillTimer.InitAvailableSkills()
      end
      local l_3_31 = SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_3_30]
      if l_3_31 then
        local l_3_32 = SkillTimer.GetdebuffTime(l_3_29.nEndFrame - GetLogicFrameCount()) + 1
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_3_31.type == "buff" and l_3_1 and (l_3_1.dwID == l_3_0 or not SkillTimer.showHot or l_3_6 ~= l_3_0 or IsAlly(l_3_1.dwID, l_3_0)) then
          SkillTimer.SetTimer(l_3_0, l_3_3, l_3_29.dwID, l_3_17.BigFoot_8d0febf2348ea712b2b375ae95601d5f, l_3_22.BigFoot_8d0febf2348ea712b2b375ae95601d5f(l_3_29.dwID, l_3_29.nLevel), l_3_29.nStackNum, Table_GetBuffName(l_3_29.dwID, l_3_29.nLevel), l_3_29.nEndFrame)
        elseif l_3_31.type == "debuff" and l_3_4 and l_3_4.dwID == l_3_0 and not l_3_29.bCanCancel then
          SkillTimer.SetTimer(l_3_0, l_3_3, l_3_29.dwID, l_3_29.nLevel, Table_GetBuffIconID(l_3_29.dwID, l_3_29.nLevel), l_3_29.nStackNum, Table_GetBuffName(l_3_29.dwID, l_3_29.nLevel), l_3_29.nEndFrame)
        else
          if l_3_29.dwSkillSrcID == l_3_1.dwID and l_3_31.type == "hot" and l_3_4 and l_3_4.dwID == l_3_0 and not l_3_29.bCanCancel then
            SkillTimer.SetTimer(l_3_0, l_3_3, l_3_29.dwID, l_3_29.nLevel, Table_GetBuffIconID(l_3_29.dwID, l_3_29.nLevel), l_3_29.nStackNum, Table_GetBuffName(l_3_29.dwID, l_3_29.nLevel), l_3_29.nEndFrame)
            l_3_31.isCast = false
            SkillTimer_hottiming[l_3_29.nIndex] = true
          end
        end
        if l_3_31.type == "debuff" or l_3_31.type == "buff" then
          l_3_12[l_3_0 .. ":" .. l_3_29.dwID] = nil
        end
      elseif l_3_31.type == "hot" then
        for l_3_36,l_3_37 in pairs(SkillTimer_hottiming) do
          if l_3_36 == l_3_29.nIndex then
            l_3_12[l_3_0 .. ":" .. l_3_29.dwID] = nil
          end
        end
      end
    end
  end
  for l_3_41,l_3_42 in pairs(l_3_12) do
    local l_3_40, l_3_41, l_3_42 = nil
    l_3_40 = SkillTimer
    l_3_40 = l_3_40.UnsetTimer
    l_3_41 = l_3_39[1]
    l_3_42 = l_3_39[2]
    l_3_40(l_3_41, l_3_42)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.Update = l_0_1
l_0_0 = SkillTimer
l_0_1 = function()
  local l_4_0 = GetClientPlayer()
  if l_4_0 then
    SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd = {}
    if l_4_0.dwForceID ~= 0 then
      for l_4_4,l_4_5 in pairs(SkillTimer.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a[0]) do
        SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_4_4] = l_4_5
      end
    end
    for l_4_9,l_4_10 in pairs(SkillTimer.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a[l_4_0.dwForceID]) do
      SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_4_9] = l_4_10
    end
  end
  if SkillTimer.definitionbuffs[l_4_0.dwForceID] and type(SkillTimer.definitionbuffs[l_4_0.dwForceID]) == "table" then
    for l_4_14,l_4_15 in pairs(SkillTimer.definitionbuffs[l_4_0.dwForceID]) do
      SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_4_14] = l_4_15
    end
  end
end

l_0_0.InitAvailableSkills = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_5_0, l_5_1, l_5_2, l_5_3, l_5_4, l_5_5, l_5_6, l_5_7)
  local l_5_8, l_5_9, l_5_10, l_5_16, l_5_17, l_5_18, l_5_19, l_5_20, l_5_22, l_5_23 = nil
  if not l_5_2 or not l_5_6 or l_5_6 == "" then
    return 
  end
  for l_5_14,l_5_15 in ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e) do
    local l_5_11, l_5_12, l_5_13 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_5_20:IsShown() and l_5_20.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_5_0 then
      l_5_13 = l_5_20
      do break end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_5_13 then
    if not l_5_1 then
      return 
    end
    local l_5_21, l_5_24 = nil
  end
  SkillTimer.AddBuffWidget(SkillTimer.GetPanelWidget(l_5_0, l_5_1), l_5_2, l_5_3, l_5_4, l_5_5, l_5_6, l_5_7)
end

l_0_0.SetTimer = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_6_0, l_6_1)
  local l_6_2, l_6_3, l_6_4, l_6_7, l_6_8, l_6_9 = nil, nil, nil
  for i_1,i_2 in ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e) do
    if i_2:IsShown() and i_2.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_6_0 then
      l_6_4 = i_2
  else
    end
  end
  if not l_6_4 then
    return 
  end
  for l_6_13,l_6_14 in ipairs(l_6_4.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
    if l_6_14:IsShown() and l_6_14.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_6_1 then
      SkillTimer.ReleaseBuffWidget(l_6_14)
      do break end
    end
  end
end

l_0_0.UnsetTimer = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_7_0)
  if l_7_0 then
    SkillTimer.enabled = true
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("BUFF_UPDATE")
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("SYS_MSG")
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("DO_SKILL_CAST")
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("DO_SKILL_PREPARE_PROGRESS")
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
  else
    SkillTimer.enabled = false
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end

l_0_0.Enable = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(...)
  if not SkillTimer.BigFoot_1bba2b04222223956ea408c2a789defa then
    SkillTimer.SetTimer(...)
    SkillTimer.BigFoot_1bba2b04222223956ea408c2a789defa = nil
  end
end

l_0_0.DelayCall = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_9_0, l_9_1)
  local l_9_2 = (Table_GetSkillDesc(l_9_0, l_9_1))
  local l_9_3 = nil
  string.gsub(l_9_2, "<BUFF (%d+) (%d+) time>", function(l_10_0, l_10_1)
    -- upvalues: l_9_3
    if not l_10_1 or l_10_1 == "0" then
      l_10_1 = 1
    end
    l_9_3 = math.floor(GetBuffTime(l_10_0, l_10_1) / 16)
  end)
  return l_9_3
end

l_0_0.GetSkillDuration = l_0_1
l_0_0 = SkillTimer
l_0_1 = function()
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(250, 25, "NONE")
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  BigFoot.RegisterFrame("position", "SkillTimer_Frame", SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a)
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnEvent = function(l_11_0, l_11_1, l_11_2, ...)
    if not SkillTimer.enabled then
      return 
    end
    if GetClientPlayer() then
      local l_11_4, l_11_5, l_11_6, l_11_7, l_11_8, l_11_9, l_11_10 = , GetClientPlayer().GetTarget()
    end
    if l_11_2 == "BUFF_UPDATE" then
      local l_11_11 = nil
      local l_11_12 = arg0
      local l_11_13 = arg1
      local l_11_14 = arg2
      local l_11_15 = arg3
      local l_11_16 = arg4
      local l_11_17 = arg5
      local l_11_18 = arg6
      local l_11_19 = arg7
      if not GetClientPlayer() then
        return 
      end
      if l_11_12 and l_11_19 then
        SkillTimer.Update(l_11_12)
        return 
      end
      local l_11_20 = arg8
      do
        if l_11_13 then
          local l_11_21 = arg9
          SkillTimer.UnsetTimer(l_11_12, l_11_16)
        end
        do break end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_11_22 = nil
      if not SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd then
        SkillTimer.InitAvailableSkills()
      end
      local l_11_23 = nil
      if SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[Table_GetBuffName(l_11_16, l_11_20)(l_11_16, l_11_20)] then
        local l_11_24 = SkillTimer.GetdebuffTime(l_11_18 - GetLogicFrameCount())
         -- DECOMPILER ERROR: Confused about usage of registers!

        if SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[Table_GetBuffName(l_11_16, l_11_20)(l_11_16, l_11_20)].type == "buff" and l_11_23 and (l_11_23.dwID == l_11_12 or not SkillTimer.showHot or dwTargetID ~= l_11_12 or IsAlly(l_11_23.dwID, l_11_12)) then
          if l_11_23.dwID ~= l_11_12 or not l_11_23.szName then
            local l_11_25, l_11_26 = nil
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          SkillTimer.SetTimer(l_11_12, GetPlayer(l_11_12).szName, l_11_16, l_11_20, Table_GetBuffIconID(l_11_16, l_11_20), l_11_17, l_11_25, l_11_18)
        end
        do break end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_11_26.type == "debuff" and not l_11_15 then
        SkillTimer.SetTimer(l_11_12, nil, l_11_16, l_11_20, Table_GetBuffIconID(l_11_16, l_11_20), l_11_17, Table_GetBuffName(l_11_16, l_11_20), l_11_18)
        do break end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_11_26.type == "hot" and l_11_22 == l_11_11.dwID and not l_11_15 then
        SkillTimer.SetTimer(l_11_12, nil, l_11_16, l_11_20, Table_GetBuffIconID(l_11_16, l_11_20), l_11_17, Table_GetBuffName(l_11_16, l_11_20), l_11_18)
         -- DECOMPILER ERROR: Confused about usage of registers!

      end
      do break end
    end
     -- DECOMPILER ERROR: unhandled construct in 'if'

    if l_11_2 == "SYS_MSG" and arg0 == "UI_OME_DEATH_NOTIFY" then
      local l_11_27 = nil
      local l_11_28 = arg1
      local l_11_29, l_11_30, l_11_31, l_11_32 = arg3, nil, nil, nil
      for l_11_36,l_11_37 in ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e) do
        local l_11_33 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_11_23:IsShown() and l_11_23.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_11_28 then
          SkillTimer.ReleasePanelWidget(l_11_23)
          SkillTimer.RefreshPanelPosition()
        end
      end
    end
    do return end
    if l_11_2 == "DO_SKILL_PREPARE_PROGRESS" then
      local l_11_38 = nil
      local l_11_39 = Table_GetSkill(arg1, arg2)
      if not SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd then
        SkillTimer.InitAvailableSkills()
      end
      local l_11_40 = GetClientPlayer()
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    if SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_11_39.szName] and SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_11_39.szName].type == "static" then
      if type(SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_11_39.szName].value) == "number" or l_11_39.szName == "���ǹ���" then
        BigFoot_DelayCall(SkillTimer.DelayCall, math.floor(arg0 / 16 * 1000), l_11_40.dwID, l_11_40.szName, l_11_39.dwSkillID, l_11_39.dwLevel, Table_GetSkillIconID(arg1, arg2), 1, l_11_39.szName, GetLogicFrameCount() + (SkillTimer.GetdebuffTime(l_11_18 - GetLogicFrameCount()) + 1) + SkillTimer.BigFoot_bb64f353ce955d86f462ce9c3c4e7edd[l_11_39.szName].value * 16)
      end
       -- WARNING: missing end command somewhere! Added here
    end
    -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 250 
  end
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnRender = function(l_12_0)
    if SkillTimer.enabled then
      SkillTimer.RefreshBuffs()
    end
  end
end

l_0_0.Init = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_11_0, l_11_1)
  local l_11_2, l_11_3, l_11_4 = nil, nil, nil
  for i_1,i_2 in ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e) do
    local l_11_5 = l_11_0
    if not i_2:IsShown() then
      l_11_4 = i_2
      l_11_4:Show()
      table.insert(SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27, i_2)
      do break end
    end
  end
  if not l_11_4 then
    l_11_4 = BFWindow.new(SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a, 250, 120)
    l_11_4:SetBorder("THIN")
    local l_11_8 = nil
    BFLabel.new(l_11_4, 250, 24):SetPoint("TOP", l_11_4, "TOP", 0, 3)
    l_11_4.BigFoot_12e49080c26b8b9fdea4fa8965254f05 = BFLabel.new(l_11_4, 250, 24)
    local l_11_9 = nil
    BFButton.new(l_11_4, 250, 120):SetStyle("TRANSPARENT")
    BFButton.new(l_11_4, 250, 120):SetPoint("TOPLEFT", l_11_4, "TOPLEFT", 0, 0)
    BFButton.new(l_11_4, 250, 120).OnMouseDown = function(l_12_0, l_12_1)
      if IsShiftKeyDown() then
        SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:StartMoving()
      end
    end
    BFButton.new(l_11_4, 250, 120).OnMouseUp = function(l_13_0, l_13_1)
      SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:EndMoving()
    end
    BFButton.new(l_11_4, 250, 120).OnMouseEnter = function(l_14_0, l_14_1)
      local l_14_2, l_14_3 = Cursor.GetPos()
      local l_14_4 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_14_2(l_14_3, 20, 20)
    end
    BFButton.new(l_11_4, 250, 120).OnClick = function(l_15_0, l_15_1, l_15_2)
      if l_15_2 == "LeftButton" then
         -- WARNING: missing end command somewhere! Added here
      end
      -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 3 
    end
    BFButton.new(l_11_4, 250, 120).OnMouseLeave = function(l_16_0, l_16_1)
      HideTip()
    end
    l_11_4.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 = BFButton.new(l_11_4, 250, 120)
    table.insert(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e, l_11_4)
    table.insert(SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27, l_11_4)
  end
  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  l_11_4.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetText(l_11_1)
  l_11_4.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetTextColor(224, 224, 0)
  l_11_4.BigFoot_8d0febf2348ea712b2b375ae95601d5f = l_11_0
  l_11_4.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a = {}
  l_11_4.BigFoot_d8227b82dd4719c707b81f83d6b4a825 = 0
  l_11_4.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5.OnClick = function(l_17_0, l_17_1, l_17_2)
    if l_17_2 == "LeftButton" then
       -- WARNING: missing end command somewhere! Added here
    end
    -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 3 
  end
  return l_11_4
end

l_0_0.GetPanelWidget = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_12_0)
  local l_12_1, l_12_2 = nil, nil
  if l_12_0.BigFoot_d8227b82dd4719c707b81f83d6b4a825 > 0 then
    for i_1,i_2 in ipairs(l_12_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
      i_2:Hide()
      i_2.BigFoot_8d0febf2348ea712b2b375ae95601d5f = nil
    end
  end
  l_12_0:Hide()
  l_12_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a = {}
  l_12_0.BigFoot_d8227b82dd4719c707b81f83d6b4a825 = 0
  for l_12_9,l_12_10 in ipairs(SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27) do
    if l_12_10 == l_12_0 then
      table.remove(SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27, l_12_9)
  else
    end
  end
  local l_12_11, l_12_17 = nil
  l_12_17 = ipairs
  l_12_17 = l_12_17(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e)
  for l_12_15,l_12_16 in l_12_17 do
    local l_12_16 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_12_16 then
      l_12_11 = true
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  if not l_12_11 then
    SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end

l_0_0.ReleasePanelWidget = l_0_1
l_0_0 = SkillTimer
l_0_1 = function()
  local l_13_0, l_13_1, l_13_2, l_13_5, l_13_12 = nil, nil, nil
  for i_1,i_2 in ipairs(SkillTimer.BigFoot_2a0e004eaadf5f575b34f8d7a30f1b27) do
    if not l_13_2 then
      i_2:ClearAllPoints()
      i_2:SetPoint("TOPLEFT", SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a, "TOPLEFT", 0, 0)
    else
      i_2:ClearAllPoints()
      i_2:SetPoint("TOPLEFT", l_13_2, "BOTTOMLEFT", 0, 10)
    end
    l_13_2 = i_2
  end
  local l_13_6, l_13_13 = 0
  l_13_13 = ipairs
  l_13_13 = l_13_13(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e)
  for l_13_10,l_13_11 in l_13_13 do
    local l_13_11 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

    l_13_6 = l_13_6 + l_13_11
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetSize(SkillTimer.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:GetWidth(), l_13_6)
end

l_0_0.RefreshPanelPosition = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_14_0)
  local l_14_1 = math.floor(l_14_0 / 16)
  local l_14_2 = math.floor(l_14_1 / 60)
  local l_14_3 = l_14_1 - l_14_2 * 60
  local l_14_4 = string.format
  local l_14_5 = "%02d:%02d"
  local l_14_6 = l_14_2
  local l_14_7 = l_14_3
  return l_14_4(l_14_5, l_14_6, l_14_7)
end

l_0_0.GetTimeString = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_15_0, l_15_1, l_15_2, l_15_3, l_15_4, l_15_5, l_15_6)
  local l_15_7, l_15_8, l_15_9, l_15_10, l_15_11 = nil, nil, nil, nil, nil
  for i_1,i_2 in ipairs(l_15_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
    local l_15_12 = GetLogicFrameCount()
    if i_2.BigFoot_8d0febf2348ea712b2b375ae95601d5f == l_15_1 then
      if i_2.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f ~= l_15_6 or i_2.BigFoot_3f50417fb16be9b1078eb68d24fa9c26 ~= l_15_4 then
        l_15_9 = i_2
        l_15_10 = true
    else
      l_15_9 = i_2
      l_15_11 = true
    end
else
  end
end
if l_15_11 then
  return 
end
if not l_15_9 then
  for l_15_16,l_15_17 in ipairs(SkillTimer.BigFoot_8cad082e1332b16fb3f0a7cce759e0a8) do
    local l_15_13 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if not i_2:IsShown() then
      l_15_9 = i_2
      l_15_9:Show()
    end
    do break end
  end
end
if not l_15_9 then
  l_15_9 = BFWindow.new(BFScreen, 250, 30)
  l_15_9.BigFoot_51bbc6646cac6748cc62569220600b52 = BFImage.new(l_15_9, 32, 32)
  l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52 = BFLabel.new(l_15_9, 32, 32)
  l_15_9.BigFoot_12e49080c26b8b9fdea4fa8965254f05 = BFLabel.new(l_15_9, 180, 20)
  l_15_9.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83 = BFProgressBar.new(l_15_9, 180, 10)
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 = BFButton.new(l_15_9, 32, 32)
  l_15_9.BigFoot_51bbc6646cac6748cc62569220600b52:SetPoint("LEFT", l_15_9, "LEFT", 4, 0)
  l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetPoint("TOPLEFT", l_15_9.BigFoot_51bbc6646cac6748cc62569220600b52, "TOPLEFT", 0, 0)
  l_15_9.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetPoint("TOPLEFT", l_15_9, "TOPLEFT", 40, 0)
  l_15_9.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83:SetPoint("BOTTOMLEFT", l_15_9, "BOTTOMLEFT", 40, -1)
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetPoint("LEFT", l_15_9, "LEFT", 4, 0)
  l_15_9.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetHAlign("LEFT")
  l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetHAlign("RIGHT")
  l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetVAlign("BOTTOM")
  l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetFontBorder(1, 0, 0, 0)
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetStyle("TRANSPARENT")
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 = l_15_9
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5.OnMouseEnter = function(l_16_0)
    -- upvalues: l_15_0
    local l_16_1, l_16_2 = l_16_0:GetAbsPos()
    SkillTimer.OutputBuffTip(l_15_0.BigFoot_8d0febf2348ea712b2b375ae95601d5f, l_16_0.BigFoot_4350eb5c77e4c9db3dc7371eeb400075.BigFoot_8d0febf2348ea712b2b375ae95601d5f, l_16_0.BigFoot_4350eb5c77e4c9db3dc7371eeb400075.BigFoot_0db5ab7591386d733b59a51d951e85d0, l_16_0.BigFoot_4350eb5c77e4c9db3dc7371eeb400075.BigFoot_3f50417fb16be9b1078eb68d24fa9c26, math.floor(l_16_0.BigFoot_4350eb5c77e4c9db3dc7371eeb400075.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f - GetLogicFrameCount()) / 16 + 1, l_16_1, l_16_2)
  end
  l_15_9.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5.OnMouseLeave = function()
    HideTip()
  end
  table.insert(SkillTimer.BigFoot_8cad082e1332b16fb3f0a7cce759e0a8, l_15_9)
end
if not l_15_10 then
  l_15_9.BigFoot_8d0febf2348ea712b2b375ae95601d5f = l_15_1
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_15_9.BigFoot_32eda4167021f5c8cf362f6c01966444 = l_15_13
  l_15_9.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f = l_15_6
  l_15_9.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_15_5
  l_15_9.BigFoot_3f50417fb16be9b1078eb68d24fa9c26 = l_15_4
  l_15_9.BigFoot_0db5ab7591386d733b59a51d951e85d0 = l_15_2
end
 -- DECOMPILER ERROR: Confused about usage of registers!

if l_15_9.BigFoot_3f50417fb16be9b1078eb68d24fa9c26 and l_15_4 and (l_15_9.BigFoot_3f50417fb16be9b1078eb68d24fa9c26 ~= l_15_4 or l_15_10) then
  l_15_9.BigFoot_32eda4167021f5c8cf362f6c01966444 = l_15_13
  l_15_9.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f = l_15_6
  l_15_9.BigFoot_3f50417fb16be9b1078eb68d24fa9c26 = l_15_4
end
if l_15_3 then
  l_15_9.BigFoot_51bbc6646cac6748cc62569220600b52:SetImage(l_15_3)
end
 -- DECOMPILER ERROR: Confused about usage of registers!

do
  local l_15_18, l_15_19 = , l_15_5 .. " - " .. SkillTimer.GetTimeString(l_15_6 - l_15_13)
  l_15_9.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetText(l_15_19)
  l_15_9.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83:SetRange(l_15_9.BigFoot_32eda4167021f5c8cf362f6c01966444, l_15_6)
  l_15_9.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83:SetPos(l_15_18)
  if l_15_4 > 1 then
    l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetText(l_15_4)
  else
    l_15_9.BigFoot_3a4cb6562488bf1f47a14a64fdfaee52:SetText("")
  end
  if not l_15_10 then
    table.insert(l_15_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a, l_15_9)
    l_15_0.BigFoot_d8227b82dd4719c707b81f83d6b4a825 = l_15_0.BigFoot_d8227b82dd4719c707b81f83d6b4a825 + 1
    l_15_9:SetParent(l_15_0)
    l_15_9.BigFoot_3baab10062be4ffabf749670e717c17a = l_15_0
  end
  SkillTimer.RefreshPanelBuffsPosition(l_15_0)
end
SkillTimer.RefreshPanelPosition()
end

l_0_0.AddBuffWidget = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_16_0)
  local l_16_1, l_16_2, l_16_7, l_16_8, l_16_9, l_16_10, l_16_11, l_16_12 = nil, nil
  l_16_0:Hide()
  l_16_0.BigFoot_8d0febf2348ea712b2b375ae95601d5f = nil
  for l_16_6,i_2 in ipairs(l_16_0.BigFoot_3baab10062be4ffabf749670e717c17a.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
    local l_16_3 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if i_2 == l_16_0 then
      table.remove(l_16_3.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a, l_16_11)
      l_16_3.BigFoot_d8227b82dd4719c707b81f83d6b4a825 = l_16_3.BigFoot_d8227b82dd4719c707b81f83d6b4a825 - 1
      do break end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_16_3.BigFoot_d8227b82dd4719c707b81f83d6b4a825 <= 0 then
    SkillTimer.ReleasePanelWidget(l_16_3)
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    SkillTimer.RefreshPanelBuffsPosition(l_16_3)
  end
  SkillTimer.RefreshPanelPosition()
end

l_0_0.ReleaseBuffWidget = l_0_1
l_0_0 = SkillTimer
l_0_1 = function()
  local l_17_0, l_17_1 = nil, nil
  do break end
  do
    local l_17_2, l_17_3, l_17_4, l_17_5 = GetLogicFrameCount(), ipairs(SkillTimer.BigFoot_f85253a6ae706f04d73b1af0bae6d12e)
     -- DECOMPILER ERROR: Confused about usage of registers!

    if R7_PC7:IsShown() then
      local l_17_6, l_17_7 = nil
    end
    if l_17_7.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a then
      for l_17_11,l_17_12 in ipairs(l_17_7.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
        local l_17_8, l_17_9 = nil, nil
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        do
          if R14_PC19.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f - l_17_2 >= 0 then
            l_17_14.BigFoot_12e49080c26b8b9fdea4fa8965254f05:SetText(R14_PC19.BigFoot_8983c60d66c8593ec7165ea9dbedb584 .. " - " .. SkillTimer.GetTimeString(R14_PC19.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f - l_17_2))
            l_17_14.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83:SetPos(l_17_2)
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        elseif R14_PC19.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f - l_17_2 < 0 then
          local l_17_15 = nil
          l_17_15.BigFoot_91bc0ccc542eadf44709b0dd32bbbd83:SetPos(l_17_15.BigFoot_8b2bc06c6e5a3a52ca1bef5b0372eb3f)
          SkillTimer.ReleaseBuffWidget(l_17_15)
        end
      end
    end
  end
end
 -- WARNING: undefined locals caused missing assignments!
end

l_0_0.RefreshBuffs = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_18_0)
  local l_18_1, l_18_2 = nil, nil
  if l_18_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a then
    for l_18_6,l_18_7 in ipairs(l_18_0.BigFoot_7a5e4c98e2ca051cb101e11cd9333b8a) do
      local l_18_3, l_18_4 = 0, nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if not l_18_4 then
        R9_PC11:ClearAllPoints()
        R9_PC11:SetPoint("TOPLEFT", l_18_0, "TOPLEFT", 4, 24)
      else
        R9_PC11:ClearAllPoints()
        R9_PC11:SetPoint("TOPLEFT", l_18_4, "BOTTOMLEFT", 0, 3)
      end
      l_18_4 = R9_PC11
      l_18_3 = l_18_3 + 1
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_18_0:SetSize(250, 36 + 32 * l_18_3)
end

l_0_0.RefreshPanelBuffsPosition = l_0_1
l_0_0 = function(l_19_0, l_19_1, l_19_2)
  local l_19_3 = l_19_0:Lookup("", "")
  local l_19_4 = l_19_3:Lookup("Handle_Message")
  local l_19_5, l_19_6 = l_19_4:GetAllItemSize()
  l_19_4:SetSize(l_19_5, l_19_6)
  l_19_4:SetItemStartRelPos(0, 0)
  if l_19_1 then
    l_19_5 = l_19_5 + 19 + l_19_2
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_19_5 = l_19_5 + 19
  end
  local l_19_7 = l_19_3:Lookup("Image_Bg")
  l_19_7:SetSize(l_19_5, l_19_6)
  l_19_3:SetSize(10000, 10000)
  l_19_3:FormatAllItemPos()
   -- DECOMPILER ERROR: Overwrote pending register.

  l_19_5 = l_19_3:GetAllItemSize()
  l_19_3:SetSize(l_19_5, l_19_6)
  l_19_0:SetSize(l_19_5, l_19_6)
  if l_19_1 then
    l_19_0:SetMousePenetrable(0)
    local l_19_8 = l_19_0:Lookup("Btn_Close")
    l_19_8.OnLButtonClick = function()
      -- upvalues: l_19_0
      if l_19_0.szSubName then
        Wnd.CloseWindow(l_19_0.szSubName)
      end
      Wnd.CloseWindow(this:GetRoot():GetName())
    end
    w1 = l_19_8:GetSize()
    local l_19_9, l_19_10 = l_19_8:GetRelPos()
    l_19_8:SetRelPos(l_19_5 - w1 - 4, l_19_10)
    l_19_0:EnableDrag(1)
    l_19_0:SetDragArea(0, 0, l_19_5, l_19_6)
  else
    l_19_0:Lookup("Btn_Close"):Hide()
  end
end

AdjustTipPanelSize = l_0_0
l_0_0 = SkillTimer
l_0_1 = function(l_20_0, l_20_1, l_20_2, l_20_3, l_20_4, l_20_5, l_20_6)
  local l_20_7 = "<Text>text=" .. EncodeComponentsString(Table_GetBuffName(l_20_1, l_20_2) .. "\t") .. " font=65 </text>"
  local l_20_8 = {}
  local l_20_9 = GetBuffInfo(l_20_1, l_20_2, l_20_8)
  local l_20_10 = ""
  if l_20_9 and g_tStrings.tBuffDetachType[l_20_9.nDetachType] then
    l_20_10 = g_tStrings.tBuffDetachType[l_20_9.nDetachType]
  end
  l_20_7 = l_20_7 .. "<Text>text=" .. EncodeComponentsString(l_20_10 .. "\n") .. " font=106 </text>"
  local l_20_11 = GetBuffDesc(l_20_1, l_20_2, "desc")
  if l_20_11 then
    l_20_11 = l_20_11 .. g_tStrings.STR_FULL_STOP
  end
  l_20_7 = l_20_7 .. "<Text>text=" .. EncodeComponentsString(l_20_11) .. " font=106 </text>"
  local l_20_12 = nil
  l_20_12 = Station.Lookup("Topmost1/TipPanel_Normal")
  if not l_20_12 then
    l_20_12 = Wnd.OpenWindow("TipPanel", "TipPanel_Normal")
  end
  l_20_12.bTipLink = nil
  local l_20_13 = l_20_12:Lookup("", "Handle_Message")
  l_20_12.OnFrameBreathe = nil
  l_20_12.bFadeOut = false
  l_20_12:SetAlpha(255)
  l_20_13:SetSize(300, 10000)
  l_20_13:Clear()
  l_20_13:AppendItemFromString(l_20_7)
  l_20_13:FormatAllItemPos()
  AdjustTipPanelSize(l_20_12)
  local l_20_14, l_20_15 = l_20_12:GetSize()
  l_20_12:SetAbsPos(l_20_5 - l_20_14 - 5, l_20_6 - 2)
  l_20_12:Show()
  l_20_12:BringToTop()
end

l_0_0.OutputBuffTip = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_21_0)
  local l_21_1 = GetClientPlayer()
  local l_21_2 = FormatSkillTip(l_21_0, l_21_1.GetSkillLevel(l_21_0))
  local l_21_3 = 0
  for l_21_7 in l_21_2:gmatch("����ʱ������(%d)��") do
    l_21_3 = l_21_3 + tonumber(l_21_7) or 0
  end
  return l_21_3
end

l_0_0.GetSkillEffectTime = l_0_1
l_0_0 = SkillTimer
l_0_1 = function(l_22_0)
  local l_22_1 = math.floor(l_22_0 / 16)
  return l_22_1 - math.floor(l_22_1 / 60) * 60
end

l_0_0.GetdebuffTime = l_0_1
l_0_0 = function(l_23_0)
  local l_23_1 = GetMsgFontString("MSG_SYS")
  OutputMessage("MSG_SYS", FormatString("<text>text=\"<������ʱ��> \" font=15 r=0 g=196 b=196</text><text>text=\"<D0> \"font=15 r=255 g=128 b=0</text><D1><text>text=\"\n\" font=<D1></text>", l_23_0, l_23_1), true)
end

l_0_1 = SkillTimer
l_0_2 = function(l_24_0)
  -- upvalues: l_0_0
  if l_24_0 == 182 then
    OutputMessage("MSG_ANNOUNCE_YELLOW", "***** ��������ʯ��١�Ч�� *****")
    l_0_0("*** ��������ʯ��١�Ч�� ***")
  end
end

l_0_1.OnAllDotcast = l_0_2
l_0_1 = SkillTimer
l_0_2 = function(l_25_0, l_25_1)
  -- upvalues: l_0_0
  if l_25_1 == 1696 and GetClientPlayer() and GetClientPlayer().dwID == l_25_0 then
    OutputMessage("MSG_ANNOUNCE_YELLOW", "***** �������̺���Ч�� *****")
    l_0_0("*** �������̺���Ч�� ***")
  end
end

l_0_1.OnEatAllDot = l_0_2
l_0_1 = SkillTimer
l_0_2 = function(l_26_0, l_26_1)
  -- upvalues: l_0_0
  local l_26_2 = {}
  l_26_2.szName = "ɾ�����ܼ�ʱ"
  l_26_2.szMessage = "��ȷ��Ҫɾ�����ܼ�ʱ��"
  local l_26_3 = {}
  l_26_3.szOption = "ȷ��"
  l_26_3.fnAction = function()
    -- upvalues: l_0_0 , l_26_1 , l_26_0
    l_0_0("�Ѿ�ɾ��" .. l_26_1 .. "�ļ�ʱ��")
    l_26_0[l_26_1] = nil
    SkillTimer.OnCustomDataLoad()
  end
  local l_26_4 = {}
  l_26_4.szOption = "ȡ��"
  l_26_4.fnAction = function()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  Msg = l_26_2
  l_26_2 = MessageBox
  l_26_3 = Msg
  l_26_2(l_26_3)
end

l_0_1.DelSkillList = l_0_2
l_0_1 = SkillTimer
l_0_2 = function(l_27_0, l_27_1)
  -- upvalues: l_0_0
  local l_27_2 = {}
  l_27_2.type = "buff"
  l_27_0[l_27_1] = l_27_2
  l_27_2 = l_0_0
  l_27_2("������BUFF��" .. l_27_1 .. "�ļ�ʱ")
  l_27_2 = SkillTimer
  l_27_2 = l_27_2.OnCustomDataLoad
  l_27_2()
end

l_0_1.AddkillList = l_0_2
l_0_1 = SkillTimer
l_0_2 = function()
  if not GetClientPlayer() then
    return {}
  end
  local l_28_0 = {}
  l_28_0.szOption = "���ܼ�ʱ��"
  local l_28_1 = {}
  l_28_1.szOption = "���ɼ�������"
  local l_28_2 = GetClientPlayer().dwForceID
  local l_28_3 = table.insert
  local l_28_4 = l_28_1
  local l_28_5 = {}
  l_28_5.szOption = "��" .. GetForceTitle(l_28_2) .. "��"
  l_28_3(l_28_4, l_28_5)
  l_28_3 = table
  l_28_3 = l_28_3.insert
  l_28_4 = l_28_1
  l_28_3(l_28_4, l_28_5)
  l_28_5 = {bDevide = true}
  l_28_3 = nil
  l_28_4 = pairs
  l_28_5 = SkillTimer
  l_28_5 = l_28_5.definitionbuffs
  l_28_4 = l_28_4(l_28_5)
  for i_1,i_2 in l_28_4 do
    do
      local l_28_9 = 0
      if l_28_2 then
        l_28_9 = l_28_2
      end
      if l_28_7 == l_28_9 then
        l_28_3 = l_28_8
        for l_28_13,l_28_14 in pairs(l_28_8) do
          do
            local l_28_15 = table.insert
            local l_28_16 = l_28_1
            local l_28_17 = {}
            l_28_17.szOption = l_28_13
            local l_28_18 = {}
            l_28_18.szOption = "ɾ��"
            l_28_18.fnAction = function()
              -- upvalues: l_28_8 , l_28_13
              SkillTimer.DelSkillList(l_28_8, l_28_13)
            end
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_28_15(l_28_16, l_28_17)
          end
        end
      end
    end
  end
  if not l_28_3 then
    SkillTimer.definitionbuffs[l_28_2] = {}
    l_28_3 = SkillTimer.definitionbuffs[l_28_2]
  end
  local l_28_19 = nil
  local l_28_20 = nil
  do
    local l_28_21 = nil
    table.insert(l_28_1, l_28_19)
    l_28_19 = {bDevide = true}
    table.insert(l_28_1, l_28_19)
    l_28_19 = {szOption = "�Զ���Buff", fnAction = l_28_20}
    table.insert(l_28_0, l_28_19)
  end
  return l_28_0
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1.GetMenu = l_0_2
l_0_1 = SkillTimer
l_0_1 = l_0_1.Init
l_0_1()
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_2 = "SkillTimer"
l_0_3 = "���ܼ�ʱ��"
l_0_1(l_0_2, l_0_3, "\\ui\\image\\icon\\skill_wanhua_neigongyinchang.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "SkillTimer"
l_0_3 = "EnableSkillTimer"
l_0_1(l_0_2, l_0_3, "�������ܼ�ʱ��", false, function(l_29_0)
  if l_29_0 then
    SkillTimer.Enable(true)
  else
    SkillTimer.Enable(false)
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "SkillTimer"
l_0_3 = "ShowHot"
l_0_1(l_0_2, l_0_3, "��ʾ�ѷ�Ŀ������", false, function(l_30_0)
  SkillTimer.showHot = l_30_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.Registerbutton
l_0_2 = "SkillTimer"
l_0_3 = "btnSetting"
l_0_1(l_0_2, l_0_3, "��ʱ����", true, function(l_31_0)
  local l_31_1 = SkillTimer.GetMenu()
  PopupMenu(l_31_1)
end
, 2)

