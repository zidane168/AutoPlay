-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: testcase.lua 

frame_test = function()
  local l_1_0 = BFFrame.new(200, 200)
  l_1_0:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
end

label_test = function()
  local l_2_0 = BFLabel.new(BFScreen, 200, 200, "it's a test")
  l_2_0:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
end

image_test = function()
  local l_3_0 = BFImage.new(BFScreen, 200, 200, "Interface\\BF_Base\\widget\\bigfoot.tga")
  l_3_0:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
end

total_test = function()
  local l_4_0 = BFFrame.new(400, 400)
  l_4_0:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
  local l_4_1 = BFLabel.new(l_4_0, 200, 32, "it's a test")
  l_4_1:SetPoint("TOP", l_4_0, "TOP", 0, 0)
  local l_4_2 = BFImage.new(l_4_0, 24, 24, "Interface\\BF_Base\\widget\\bigfoot.tga")
  l_4_2:SetPoint("TOPLEFT", l_4_0, "TOPLEFT", 4, 4)
  local l_4_3 = BFButton.new(l_4_0, 100, 28, "�ر�")
  l_4_3:SetPoint("BOTTOMRIGHT", l_4_0, "BOTTOMRIGHT", -10, -10)
  local l_4_4 = {}
  l_4_4.OnClick = function(l_5_0, l_5_1, l_5_2)
    Output(l_5_2 .. " click!")
  end
  l_4_4.OnCheck = function(l_6_0, l_6_1, l_6_2)
    if l_6_2 then
      Output("check!")
    else
      Output("uncheck!")
    end
  end
  l_4_4.OnSelect = function(l_7_0, l_7_1)
    Output(l_7_1:GetText())
  end
  l_4_3:AddListener(l_4_4)
  local l_4_5 = BFProgressBar.new(l_4_0, 150, 24, 0, 100)
  l_4_5:SetPoint("BOTTOM", l_4_0, "BOTTOM", 0, -20)
  l_4_5:SetPos(50)
  local l_4_6 = BFCheckButton.new(l_4_0, 150, 100, "�������ѡ��")
  l_4_6:SetPoint("TOPLEFT", l_4_0, "TOPLEFT", 50, 50)
  l_4_6:AddListener(l_4_4)
  local l_4_7 = BFRadioButton.new(l_4_0, 200, 28, "ѡ��1", "test")
  l_4_7:SetPoint("TOPLEFT", l_4_0, "TOPLEFT", 50, 150)
  l_4_7:AddListener(l_4_4)
  local l_4_8 = BFRadioButton.new(l_4_0, 200, 28, "ѡ��2", "test")
  l_4_8:SetPoint("LFFT", l_4_7, "RIGHT", 0, 0)
  l_4_8:AddListener(l_4_4)
  local l_4_9 = BFRadioButton.new(l_4_0, 200, 28, "ѡ��3", "test")
  l_4_9:SetPoint("LFFT", l_4_8, "RIGHT", 0, 0)
  l_4_9:AddListener(l_4_4)
  l_4_7:Select()
  local l_4_10 = BFEditBox.new(l_4_0, 200, 50)
  l_4_10:SetPoint("TOPLEFT", l_4_0, "TOPLEFT", 100, 200)
end


