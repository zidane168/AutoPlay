-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Loot.lua 

if not BF_Loot then
  BF_Loot = {}
end
BF_Loot.LootList = {}
BF_Loot.LootedList = {}
BF_Loot.bLootEnable = true
BF_Loot.bGrayFilter = true
BF_Loot.bRoolGreenItems = true
BF_Loot.nQuality = 0
BF_Loot.szModle = "Q0"
BF_Loot.OnFrameCreate = function()
  this:RegisterEvent("DOODAD_LEAVE_SCENE")
  this:RegisterEvent("SYNC_LOOT_LIST")
  this:RegisterEvent("OPEN_DOODAD")
  this:RegisterEvent("BEGIN_ROLL_ITEM")
  this:RegisterEvent("ON_SWITCH_MAP")
end

BF_Loot.OnEvent = function(l_2_0)
  if l_2_0 == "SYNC_LOOT_LIST" then
    BF_Loot.AppendDoodad(arg0)
  elseif l_2_0 == "DOODAD_LEAVE_SCENE" then
    BF_Loot.RemoveDoodad(arg0)
  elseif l_2_0 == "OPEN_DOODAD" then
    BF_Loot.LootAllItems(arg0)
  elseif l_2_0 == "BEGIN_ROLL_ITEM" then
    BF_Loot.RoolGreenItems(arg0, arg1)
  elseif l_2_0 == "ON_SWITCH_MAP" then
    BF_Loot.LootList = {}
    BF_Loot.LootedList = {}
  end
end

BF_Loot.OnFrameBreathe = function()
  if not BF_Loot.bLootEnable then
    return 
  end
  local l_3_0 = GetClientPlayer()
  if not l_3_0 then
    return 
  end
  if GetLogicFrameCount() % 16 ~= 0 then
    return 
  end
  for l_3_4,l_3_5 in pairs(BF_Loot.LootList) do
    local l_3_6 = GetDoodad(l_3_4)
    local l_3_7 = math.floor(l_3_0.nX - l_3_6.nX ^ 2 + l_3_0.nY - l_3_6.nY ^ 2 + l_3_0.nZ / 8 - l_3_6.nZ / 8 ^ 2 ^ 0.5) / 64
    if l_3_7 < 4 then
      if BF_Loot.LootedList[l_3_4] then
        return 
      end
      InteractDoodad(l_3_4)
      BF_Loot.LootAllItems(l_3_4)
    end
  end
end

BF_Loot.AppendDoodad = function(l_4_0)
  if not BF_Loot.bLootEnable then
    return 
  end
  if not l_4_0 then
    return 
  end
  local l_4_1 = GetDoodad(l_4_0)
  if BF_Loot.LootList[l_4_0] and not l_4_1 then
    BF_Loot.RemoveDoodad(l_4_0)
  end
  return 
  if l_4_1 and l_4_1.nKind == DOODAD_KIND.CORPSE and l_4_1.CanLoot(GetClientPlayer().dwID) then
    BF_Loot.LootList[l_4_0] = l_4_0
  end
end

BF_Loot.RemoveDoodad = function(l_5_0)
  if BF_Loot.LootList[l_5_0] then
    BF_Loot.LootList[l_5_0] = nil
  end
end

BF_Loot.LootAllItems = function(l_6_0)
  if not BF_Loot.bLootEnable then
    return 
  end
  local l_6_1 = GetDoodad(l_6_0)
  local l_6_2 = Station.Lookup("Normal/LootList")
  if l_6_2 then
    l_6_2:Hide()
  else
    return 
  end
  local l_6_3 = l_6_2:Lookup("", "Handle_LootList")
  local l_6_4 = l_6_3:GetItemCount()
  for l_6_8 = 0, l_6_4 - 1 do
    local l_6_9 = l_6_3:Lookup(l_6_8)
    if l_6_9.bMoney then
      LootMoney(l_6_0)
    else
      local l_6_10 = GetItem(l_6_9.dwID)
    end
    if l_6_10 then
      local l_6_11 = l_6_10.nQuality
    if BF_Loot.bGrayFilter then
      end
      if BF_Loot.bGrayFilter then
        LootItem(l_6_0, l_6_10.dwID)
      end
    else
      LootItem(l_6_0, l_6_10.dwID)
    end
  end
  if BF_Loot.LootedList[l_6_0] then
    return 
  end
  BF_Loot.LootedList[l_6_0] = l_6_0
end

BF_Loot.RoolGreenItems = function(l_7_0, l_7_1)
  if not BF_Loot.bRoolGreenItems then
    return 
  end
  local l_7_2 = GetItem(l_7_1)
  if not l_7_2 then
    return 
  end
  local l_7_3 = l_7_2.nQuality
  local l_7_4 = 2
  if l_7_3 == l_7_4 and (l_7_2.nBindType ~= ITEM_BIND.BIND_ON_PICKED or l_7_2.nBindType ~= ITEM_BIND.BIND_ON_PICKED or tWitheList[l_7_2.szName]) then
    RollItem(l_7_0, l_7_1, 2)
    for l_7_8 = 1, 4 do
      do
        local l_7_9 = Station.Lookup("Normal/LootRoll" .. l_7_8)
        if l_7_9 and l_7_9.dwDoodadID == arg0 and l_7_9.dwItemID == arg1 then
          Wnd.CloseWindow(l_7_9:GetName())
        end
        do break end
      end
    end
    local l_7_10 = MakeItemLink("[" .. l_7_2.szName .. "]", " font=10 r=0 g=255 b=32 ", l_7_2.dwID)
    BigFoot_Print("ʰȡ����", "�Զ�ROLL��ɫ����" .. l_7_10)
  end
end

BF_Loot.SetConfigModle = function(l_8_0)
  if l_8_0 == "Q0" then
    BFSetModValue("Loot", "EnableQ0", true)
    BFSetModValue("Loot", "EnableQ1", false)
    BFSetModValue("Loot", "EnableQ2", false)
    BFSetModValue("Loot", "EnableQ3", false)
  elseif l_8_0 == "Q1" then
    BFSetModValue("Loot", "EnableQ0", false)
    BFSetModValue("Loot", "EnableQ1", true)
    BFSetModValue("Loot", "EnableQ2", false)
    BFSetModValue("Loot", "EnableQ3", false)
  elseif l_8_0 == "Q2" then
    BFSetModValue("Loot", "EnableQ0", false)
    BFSetModValue("Loot", "EnableQ1", false)
    BFSetModValue("Loot", "EnableQ2", true)
    BFSetModValue("Loot", "EnableQ3", false)
  elseif l_8_0 == "Q3" then
    BFSetModValue("Loot", "EnableQ0", false)
    BFSetModValue("Loot", "EnableQ1", false)
    BFSetModValue("Loot", "EnableQ2", false)
    BFSetModValue("Loot", "EnableQ3", true)
  end
  BFConfigPanel.ShowModPage("Loot")
end

Wnd.OpenWindow("Interface\\BF_Loot\\BF_Loot.ini", "BF_Loot")
BFConfigPanel.RegisterMod("Loot", "ʰȡ����", "\\ui\\image\\icon\\coin05.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("Loot", "bLootEnable", "�����Զ�ʰȡ", true, function(l_9_0, l_9_1)
  BF_Loot.bLootEnable = l_9_0
end
)
BFConfigPanel.RegisterCheckButton("Loot", "bGrayFilter", "������Ʒ", true, function(l_10_0, l_10_1)
  BF_Loot.bGrayFilter = l_10_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Loot", "EnableQ0", "��ɫƷ��", true, function(l_11_0, l_11_1)
  if l_11_1 and not l_11_0 then
    return 
  end
  BF_Loot.szModle = "Q0"
  BF_Loot.nQuality = 0
  if not l_11_1 then
    BF_Loot.SetConfigModle(BF_Loot.szModle)
  end
end
, 3)
BFConfigPanel.RegisterCheckButton("Loot", "EnableQ1", "��ɫƷ��", false, function(l_12_0, l_12_1)
  if l_12_1 and not l_12_0 then
    return 
  end
  BF_Loot.szModle = "Q1"
  BF_Loot.nQuality = 1
  if not l_12_1 then
    BF_Loot.SetConfigModle(BF_Loot.szModle)
  end
end
, 3)
BFConfigPanel.RegisterCheckButton("Loot", "EnableQ2", "��ɫƷ��", false, function(l_13_0, l_13_1)
  if l_13_1 and not l_13_0 then
    return 
  end
  BF_Loot.szModle = "Q2"
  BF_Loot.nQuality = 2
  if not l_13_1 then
    BF_Loot.SetConfigModle(BF_Loot.szModle)
  end
end
, 3)
BFConfigPanel.RegisterCheckButton("Loot", "EnableQ3", "��ɫƷ��", false, function(l_14_0, l_14_1)
  if l_14_1 and not l_14_0 then
    return 
  end
  BF_Loot.szModle = "Q3"
  BF_Loot.nQuality = 3
  if not l_14_1 then
    BF_Loot.SetConfigModle(BF_Loot.szModle)
  end
end
, 3)
BFConfigPanel.RegisterCheckButton("Loot", "bRoolGreenItems", "�����Զ�ROOL��ɫ��Ʒ", true, function(l_15_0)
  BF_Loot.bRoolGreenItems = l_15_0
end
)

