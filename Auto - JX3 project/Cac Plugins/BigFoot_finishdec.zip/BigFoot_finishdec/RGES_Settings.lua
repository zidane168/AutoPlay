-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RGES_Settings.lua 

local l_0_0 = {}
local l_0_1 = {}
local l_0_2 = {}
l_0_2.fKeepTime = 29.9375
l_0_2.szMapName = "Ӣ�۳ֹ�������"
l_0_2.fEventTimeStart = 221007.6875
l_0_2.dwID = 1878
l_0_2.nIconID = 2140
l_0_2.fEventTimeEnd = 221036.375
l_0_2.bIsVisible = true
l_0_2.szType = "Debuff"
l_0_2.tRGCenterAlarm = true
l_0_2.nLevel = 3
l_0_2.nAutoEventTimeMode = 2
l_0_2.bChatAlertW = true
local l_0_3 = {}
l_0_3.bCanCancel = false
l_0_3.nIndex = 677
l_0_3.nEndFrame = 3438303
l_0_3.dwID = 1878
l_0_3.nStackNum = 1
l_0_3.dwSkillSrcID = 0
l_0_3.nLevel = 3
l_0_2.buff = l_0_3
l_0_2.szName = "�����ɢ�����ڶ�"
l_0_2.tAlarmAddInfo = "ȥ������λ�õ�ˮ�����buff��"
l_0_2.bIsDebuff = true
l_0_2.nEventAlertTime = 29.8125
l_0_1[27] = l_0_2
l_0_3 = {bCanCancel = false, nIndex = 268, nLevel = 4, nEndFrame = 2011014, nStackNum = 1, dwSkillSrcID = 1076668622, dwID = 2179}
l_0_1[2], l_0_2 = l_0_2, {fKeepTime = 17.9375, buff = l_0_3, bIsVisible = true, szType = "Debuff", szMapName = "25��Ӣ��ݶ��ʥ��", nLevel = 4, nAutoEventTimeMode = 2, szCasterName = "ĵ��", szName = "ʹѪָ", dwID = 2179, nIconID = 343, bIsDebuff = true, nEventAlertTime = 17}
l_0_3 = {bCanCancel = false, nIndex = 566, nEndFrame = 514432, dwID = 3617, nStackNum = 1, dwSkillSrcID = 0, nLevel = 1}
l_0_1[38], l_0_2 = l_0_2, {fKeepTime = 1799.875, fEventTimeEnd = 129398.875, szMapName = "������", bIsVisible = true, szType = "Debuff", buff = l_0_3, nLevel = 1, fEventTimeStart = 129398.3125, bIsDebuff = true, szName = "������繦", dwID = 3617, nAutoEventTimeMode = 2, nIconID = 2027, nEventAlertTime = 1799.875}
l_0_3 = {bCanCancel = false, nIndex = 217, dwID = 2676, nEndFrame = 3570581, nStackNum = 1, dwSkillSrcID = 1081143867, nLevel = 4}
l_0_1[3], l_0_2 = l_0_2, {fKeepTime = 9.625, fEventTimeEnd = 226407.6875, buff = l_0_3, bIsVisible = true, szType = "Debuff", fEventTimeStart = 226403.3125, nLevel = 4, nAutoEventTimeMode = 2, bIsDebuff = true, dwID = 2676, szName = "�ػ�", nEventAlertStackNum = 4, nIconID = 19, nEventAlertTime = 9.6875}
l_0_3 = {bCanCancel = false, nIndex = 2890, nEndFrame = 3636028, dwID = 2580, nStackNum = 1, dwSkillSrcID = 1074612848, nLevel = 1}
l_0_1[54], l_0_2 = l_0_2, {fKeepTime = 10, fEventTimeEnd = 227058.75, buff = l_0_3, bIsVisible = true, szType = "Debuff", nLevel = 1, nAutoEventTimeMode = 2, fEventTimeStart = 227057, bIsDebuff = true, dwID = 2580, szName = "ԭ�︿Ѩ��", nIconID = 334, nEventAlertTime = 10}
l_0_3 = {bCanCancel = false, nIndex = 394, nEndFrame = 1091594, dwID = 3248, nStackNum = 1, dwSkillSrcID = 1074626981, nLevel = 2}
l_0_1[4], l_0_2 = l_0_2, {fKeepTime = 3, fEventTimeEnd = 123655.875, buff = l_0_3, bIsVisible = true, szType = "Debuff", szMapName = "��������", tRGCenterAlarm = true, nLevel = 2, nAutoEventTimeMode = 2, nIconID = 770, dwID = 3248, szName = "��׼", szCasterName = "����", bIsDebuff = true, nEventAlertTime = 3}
l_0_3 = {bCanCancel = false, nIndex = 492, dwID = 3971, nEndFrame = 1290302, nStackNum = 1, dwSkillSrcID = 0, nLevel = 1}
l_0_1[5], l_0_2 = l_0_2, {fKeepTime = 7.75, szMapName = "������", bChatAlertT = true, bScreenHead = true, fEventTimeStart = 85594.125, dwID = 3971, nIconID = 2759, fEventTimeEnd = 85602.1875, bChatAlertW = true, szType = "Debuff", tRGCenterAlarm = true, nLevel = 1, tAlarmAddInfo = "��Զ����Ⱥ", bIsVisible = true, nAutoEventTimeMode = 2, szName = "������", buff = l_0_3, bIsDebuff = true, nEventAlertTime = 7.75}
l_0_3 = {bCanCancel = false, nIndex = 960, nLevel = 1, dwID = 4001, nStackNum = 1, dwSkillSrcID = 0, nEndFrame = 1300051}
l_0_1[6], l_0_2 = l_0_2, {fKeepTime = 4.5625, buff = l_0_3, bChatAlertT = true, bScreenHead = true, fEventTimeStart = 85756.875, dwID = 4001, nIconID = 1435, fEventTimeEnd = 85761.625, bIsVisible = false, szType = "Debuff", tRGCenterAlarm = true, nLevel = 1, nAutoEventTimeMode = 2, szName = "�����ж�", szMapName = "������", bIsDebuff = true, nEventAlertTime = 4.5625}
l_0_3 = {bCanCancel = false, nIndex = 961, dwID = 3976, nEndFrame = 1300099, nStackNum = 1, dwSkillSrcID = 1073759929, nLevel = 1}
l_0_1[7], l_0_2 = l_0_2, {fKeepTime = 7.5625, szMapName = "������", bChatAlertT = true, bScreenHead = true, fEventTimeStart = 85756.875, dwID = 3976, nIconID = 3443, fEventTimeEnd = 85764.625, bIsVisible = true, szType = "Debuff", tRGAutoSelect = false, tRGCenterAlarm = true, nLevel = 1, nAutoEventTimeMode = 2, tAlarmAddInfo = "���DEBUFF!", buff = l_0_3, szName = "���깦", szCasterName = "���ɹ�", bIsDebuff = true, nEventAlertTime = 7.5625}
l_0_3 = {bCanCancel = false, nIndex = 3265, dwID = 3984, nEndFrame = 1332162, nStackNum = 1, dwSkillSrcID = 0, nLevel = 1}
l_0_1[8], l_0_2 = l_0_2, {fKeepTime = 5.625, szMapName = "������", bChatAlertT = true, bScreenHead = true, fEventTimeStart = 85856.1875, dwID = 3984, nIconID = 2714, fEventTimeEnd = 85862.4375, bIsVisible = true, szType = "Debuff", tRGCenterAlarm = true, nLevel = 1, nAutoEventTimeMode = 2, tAlarmAddInfo = "�߿�������ɫ��Ȧ��", szName = "���ɹ�", buff = l_0_3, bIsDebuff = true, nEventAlertTime = 5.875}
l_0_3 = {bCanCancel = false, nIndex = 3256, nLevel = 1, dwID = 4066, nStackNum = 1, dwSkillSrcID = 0, nEndFrame = 1332063}
l_0_1[10], l_0_2 = l_0_2, {fKeepTime = 2.6875, buff = l_0_3, bChatAlertT = true, bScreenHead = true, fEventTimeStart = 85853.0625, dwID = 4066, nIconID = 2751, fEventTimeEnd = 85856.0625, bIsVisible = true, szType = "Debuff", nLevel = 1, nAutoEventTimeMode = 2, szMapName = "������", szName = "����", tAlarmAddInfo = "Ч������ʱ��á����ɹǡ�", bIsDebuff = true, nEventAlertTime = 2.875}
l_0_3 = {bCanCancel = false, nIndex = 837, nLevel = 1, nEndFrame = 256697, nStackNum = 1, dwSkillSrcID = 1073774793, dwID = 3808}
l_0_1[12], l_0_2 = l_0_2, {fKeepTime = 5.625, szMapName = "��ս����", bChatAlertT = true, bScreenHead = true, fEventTimeStart = 16178.0625, dwID = 3808, nIconID = 2021, fEventTimeEnd = 16179.5625, bIsVisible = true, szType = "Debuff", tAlarmAddInfo = "Զ��", nLevel = 1, nAutoEventTimeMode = 2, bChatAlertW = true, buff = l_0_3, szName = "��ɷ", szCasterName = "��ç", bIsDebuff = true, nEventAlertTime = 5.625}
l_0_3 = {bCanCancel = false, nIndex = 1341, nLevel = 1, nEndFrame = 251977, nStackNum = 1, dwSkillSrcID = 1073774793, dwID = 3781}
l_0_1[14], l_0_2 = l_0_2, {fKeepTime = 9.75, fEventTimeEnd = 15993.875, szMapName = "��ս����", bIsVisible = true, szType = "Debuff", buff = l_0_3, nIconID = 2028, nLevel = 1, nAutoEventTimeMode = 2, fEventTimeStart = 15984, dwID = 3781, szName = "�׶��ķ�", szCasterName = "��ç", bIsDebuff = true, nEventAlertTime = 9.5625}
l_0_3 = {bCanCancel = false, nIndex = 794, nLevel = 1, nEndFrame = 245035, nStackNum = 1, dwSkillSrcID = 1073786335, dwID = 3962}
l_0_1[16], l_0_2 = l_0_2, {fEventTimeStart = 271010.25, fKeepTime = 9.875, fEventTimeEnd = 271042.75, szMapName = "��ս����", bIsVisible = true, szType = "Debuff", szCasterName = "��������", tRGCenterAlarm = true, nLevel = 1, nAutoEventTimeMode = 2, buff = l_0_3, dwID = 3962, szName = "�Ƕ�", nIconID = 3423, bIsDebuff = true, nEventAlertTime = 9.875}
l_0_3 = {bCanCancel = false, nIndex = 1164, dwID = 3505, nEndFrame = 324919, nStackNum = 1, dwSkillSrcID = 1073807737, nLevel = 1}
l_0_1[20], l_0_2 = l_0_2, {fKeepTime = 19.5625, szMapName = "�ֹ�����¼", bChatAlertT = true, dwID = 3505, nIconID = 330, fEventTimeEnd = 20357.1875, bChatAlertW = true, szType = "Debuff", nAutoEventTimeMode = 2, nLevel = 1, tAlarmAddInfo = "Զ����Ⱥ", buff = l_0_3, szCasterName = "������", szName = "��Х", bIsVisible = true, bIsDebuff = true, nEventAlertTime = 19}
l_0_3 = {bCanCancel = false, nIndex = 551, nEndFrame = 3439583, dwID = 1877, nStackNum = 1, dwSkillSrcID = 0, nLevel = 3}
l_0_1[24], l_0_2 = l_0_2, {fKeepTime = 29.875, szMapName = "Ӣ�۳ֹ�������", fEventTimeStart = 221047.6875, dwID = 1877, nIconID = 329, fEventTimeEnd = 221056.1875, bIsVisible = true, szType = "Debuff", tRGCenterAlarm = true, nLevel = 3, nAutoEventTimeMode = 2, bChatAlertW = true, buff = l_0_3, szName = "�����ɢ��������", tAlarmAddInfo = "ȥ�׺�λ�õ�ˮ�����buff��", bIsDebuff = true, nEventAlertTime = 29.8125}
l_0_3 = {bCanCancel = false, nIndex = 1931, nEndFrame = 3467129, dwID = 1882, nStackNum = 1, dwSkillSrcID = 0, nLevel = 3}
l_0_1[28], l_0_2 = l_0_2, {fKeepTime = 59.9375, buff = l_0_3, bChatAlertT = true, bScreenHead = true, fEventTimeStart = 219444.625, dwID = 1882, nIconID = 332, fEventTimeEnd = 219504.6875, bIsVisible = true, szType = "Debuff", tRGCenterAlarm = true, nLevel = 3, tAlarmAddInfo = "ȥ�ĵ�λ�ý�buff��", szMapName = "Ӣ�۳ֹ�������", bIsDebuff = true, szName = "�����������ƾ�����", nAutoEventTimeMode = 2, bManyMembers = true, nEventAlertTime = 59.75}
l_0_3 = {[1] = 255, [2] = 255, [4] = 5, [3] = 0}
l_0_3 = {bCanCancel = false, nIndex = 6954, nLevel = 4, nEndFrame = 625400, nStackNum = 1, dwSkillSrcID = 1073808006, dwID = 3877}
l_0_3 = {[1] = 255, [2] = 255, [3] = 0}
l_0_1[32], l_0_2 = l_0_2, {fKeepTime = 5.875, szMapName = "25��Ӣ��ݶ��ʥ��", bChatAlertT = true, bScreenHead = true, fEventTimeStart = 44120.875, dwID = 3877, szSoundFile = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\haha.wav", nIconID = 1435, tRGAlertColor = l_0_3, buff = l_0_3, tAutoTeamMark = 4, fEventTimeEnd = 44126.5625, bChatAlertW = true, bIsVisible = false, szType = "Debuff", nAutoEventTimeMode = 2, tRGCenterAlarm = true, nLevel = 4, tAlarmAddInfo = "��Զ����Ⱥ��", tRGAutoSelect = false, tRGBuffColor = l_0_3, szName = "ԭ�︿Ѩ������", szCasterName = "������", bIsDebuff = true, nEventAlertTime = 5.625}
l_0_3 = {bCanCancel = false, nIndex = 1338, nEndFrame = 516466, dwID = 3658, nStackNum = 1, dwSkillSrcID = 0, nLevel = 1}
l_0_3 = {[1] = 255, [2] = 0, [4] = 2, [3] = 255}
l_0_3 = {[1] = 255, [2] = 0, [3] = 255}
l_0_1[40], l_0_2 = l_0_2, {fKeepTime = 7.875, buff = l_0_3, bChatAlertT = true, bScreenHead = true, fEventTimeStart = 131758.9375, dwID = 3658, nIconID = 2123, tAutoTeamMark = 4, fEventTimeEnd = 131763.8125, bIsVisible = false, szType = "Debuff", tRGAlertColor = l_0_3, tRGCenterAlarm = true, nLevel = 1, nAutoEventTimeMode = 2, bChatAlertW = true, tRGBuffColor = l_0_3, szName = "ѣ��", szMapName = "������", bIsDebuff = true, nEventAlertTime = 7.8125}
l_0_3 = {bCanCancel = false, nIndex = 720, dwID = 2678, nEndFrame = 827926, nStackNum = 1, dwSkillSrcID = 0, nLevel = 2}
l_0_1[48], l_0_2 = l_0_2, {fKeepTime = 60, fEventTimeEnd = 142679.9375, buff = l_0_3, bIsVisible = true, szType = "Debuff", bChatAlertT = true, bManyMembers = true, nLevel = 2, fEventTimeStart = 142674.5, bIsDebuff = true, dwID = 2678, szName = "����", nAutoEventTimeMode = 2, nIconID = 42, nEventAlertTime = 60}
l_0_3 = {bCanCancel = false, nIndex = 720, dwID = 2665, nEndFrame = 3546798, nStackNum = 1, dwSkillSrcID = 1074613182, nLevel = 1}
l_0_3 = true
l_0_3 = 120430.25
l_0_3 = 1
l_0_3 = 2
l_0_3 = true
local l_0_4 = 1
l_0_4 = 2
l_0_4 = 3
l_0_3 = {[l_0_4] = 255, [l_0_4] = 0, [l_0_4] = 255}
l_0_3 = "����"
l_0_3 = 2665
l_0_3 = 2029
l_0_3 = 7.75
l_0_1[56], l_0_2 = l_0_2, {fKeepTime = 7.9375, fEventTimeEnd = 120433, buff = l_0_3, bIsVisible = l_0_3, szType = "Debuff", fEventTimeStart = l_0_3, nLevel = l_0_3, nAutoEventTimeMode = l_0_3, bIsDebuff = l_0_3, tRGBuffColor = l_0_3, szName = l_0_3, dwID = l_0_3, nIconID = l_0_3, nEventAlertTime = l_0_3}
l_0_2 = 47
l_0_4 = 10
l_0_4 = {bCanCancel = false, nIndex = 1702, dwID = 2670, nEndFrame = 3506835, nStackNum = 1, dwSkillSrcID = 1077579469, nLevel = 4}
l_0_4 = true
l_0_4 = true
local l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 3, [l_0_5] = 0}
l_0_4 = 2670
l_0_4 = 330
l_0_4 = 225721.6875
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 0}
l_0_4 = "�ױ�"
l_0_4 = 225711.6875
l_0_4 = true
l_0_4 = 10
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = "Hash"
l_0_4 = 2665
l_0_5 = true
l_0_4 = 3807
l_0_5 = true
l_0_4 = 3248
l_0_5 = true
l_0_4 = 2256
l_0_5 = true
l_0_4 = 3658
l_0_5 = true
l_0_4 = 2666
l_0_5 = true
l_0_4 = 3808
l_0_5 = true
l_0_4 = 3564
l_0_5 = true
l_0_4 = 3454
l_0_5 = true
l_0_4 = 2580
l_0_5 = true
l_0_4 = 1877
l_0_5 = true
l_0_4 = 1881
l_0_5 = true
l_0_4 = 3416
l_0_5 = true
l_0_4 = 3753
l_0_5 = true
l_0_4 = 2179
l_0_5 = true
l_0_4 = 2628
l_0_5 = true
l_0_4 = 2636
l_0_5 = true
l_0_4 = 3657
l_0_5 = true
l_0_4 = 3623
l_0_5 = true
l_0_4 = 3668
l_0_5 = true
l_0_4 = 4003
l_0_5 = true
l_0_4 = 2676
l_0_5 = true
l_0_4 = 2243
l_0_5 = true
l_0_4 = 3617
l_0_5 = true
l_0_4 = 3877
l_0_5 = true
l_0_4 = 2204
l_0_5 = true
l_0_4 = 3976
l_0_5 = true
l_0_4 = 3984
l_0_5 = true
l_0_4 = 3799
l_0_5 = true
l_0_4 = 3629
l_0_5 = true
l_0_4 = 3756
l_0_5 = true
l_0_4 = 2678
l_0_5 = true
l_0_4 = 3782
l_0_5 = true
l_0_4 = 2181
l_0_5 = true
l_0_4 = 1876
l_0_5 = true
l_0_4 = 3560
l_0_5 = true
l_0_4 = 2670
l_0_5 = true
l_0_4 = 2174
l_0_5 = true
l_0_4 = 3505
l_0_5 = true
l_0_4 = 2631
l_0_5 = true
l_0_4 = 3962
l_0_5 = true
l_0_4 = 3781
l_0_5 = true
l_0_4 = 3978
l_0_5 = true
l_0_4 = 1883
l_0_5 = true
l_0_4 = 1878
l_0_5 = true
l_0_4 = 3527
l_0_5 = true
l_0_4 = 3789
l_0_5 = true
l_0_4 = 1875
l_0_5 = true
l_0_4 = 3773
l_0_5 = true
l_0_4 = 3971
l_0_5 = true
l_0_4 = 2215
l_0_5 = true
l_0_4 = 3999
l_0_5 = true
l_0_4 = 2231
l_0_5 = true
l_0_4 = 4066
l_0_5 = true
l_0_4 = 1884
l_0_5 = true
l_0_4 = 3893
l_0_5 = true
l_0_4 = 1882
l_0_5 = true
l_0_4 = 3531
l_0_5 = true
l_0_4 = 2172
l_0_5 = true
l_0_4 = 4001
l_0_5 = true
l_0_1[l_0_2], l_0_3 = l_0_3, {[l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5}
l_0_2 = 33
l_0_4 = 3.625
l_0_4 = 129306.1875
l_0_5 = false
l_0_5 = 50
l_0_5 = 4078521
l_0_5 = 3564
l_0_5 = 1
l_0_5 = 1074085353
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 338
l_0_4 = 1
l_0_4 = 2
l_0_4 = "����"
l_0_4 = 3564
l_0_4 = "��ػ�"
l_0_4 = 129301.3125
l_0_4 = true
l_0_4 = 4.625
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", nIconID = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = l_0_4, dwID = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 41
l_0_4 = 5.875
l_0_4 = true
l_0_4 = true
l_0_4 = 132025.875
l_0_4 = 3773
l_0_4 = "��̳�й�"
l_0_4 = 132031.8125
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 2, [l_0_5] = 255}
l_0_4 = true
l_0_5 = false
l_0_5 = 3259
l_0_5 = 548299
l_0_5 = 3773
l_0_5 = 1
l_0_5 = 1073869393
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 255}
l_0_4 = "������"
l_0_4 = 371
l_0_4 = true
l_0_4 = 5.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "������", bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, szCasterName = l_0_4, fEventTimeEnd = l_0_4, tRGAlertColor = l_0_4, bIsVisible = l_0_4, szType = "Debuff", buff = l_0_4, tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bChatAlertW = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, nIconID = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 49
l_0_4 = 29.9375
l_0_4 = 139823.125
l_0_5 = false
l_0_5 = 80
l_0_5 = 2636
l_0_5 = 3472790
l_0_5 = 1
l_0_5 = 1077579472
l_0_5 = 4
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = 139821.5
l_0_4 = true
l_0_4 = 2636
l_0_4 = "���"
l_0_4 = 7
l_0_4 = 30
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, dwID = l_0_4, szName = l_0_4, nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 57
l_0_4 = 10
l_0_5 = false
l_0_5 = 1968
l_0_5 = 4
l_0_5 = 2204
l_0_5 = 1
l_0_5 = 1074991810
l_0_5 = 2125576
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 5, [l_0_5] = 0}
l_0_4 = 2204
l_0_4 = 338
l_0_4 = 117051.5
l_0_4 = true
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = "ʨ����צ"
l_0_4 = 117050.5
l_0_4 = true
l_0_4 = 9.875
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", bIsVisible = l_0_4, tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bManyMembers = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 17
l_0_4 = 19.75
l_0_4 = 15421.75
l_0_4 = true
l_0_5 = false
l_0_5 = 506
l_0_5 = 1
l_0_5 = 246555
l_0_5 = 1
l_0_5 = 1073786311
l_0_5 = 3789
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = 14
l_0_4 = 1
l_0_4 = 2
l_0_4 = 15418.0625
l_0_4 = 3789
l_0_4 = "��������"
l_0_4 = "�����ٷ�"
l_0_4 = true
l_0_4 = 19.625
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, szMapName = "��ս����", bIsVisible = l_0_4, szType = "Debuff", buff = l_0_4, nIconID = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, szName = l_0_4, szCasterName = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 21
l_0_4 = "���ϣ���Ѫ���debuff��ʧ����С�Ṧ��������ؼǵö��� "
l_0_4 = 5.75
l_0_4 = 75284.875
l_0_4 = true
l_0_4 = 339
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = 3527
l_0_5 = false
l_0_5 = 1539
l_0_5 = 3527
l_0_5 = 332589
l_0_5 = 1
l_0_5 = 0
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = "��Ѫ���"
l_0_4 = 75278.75
l_0_4 = true
l_0_4 = 5.875
l_0_1[l_0_2], l_0_3 = l_0_3, {tAlarmAddInfo = l_0_4, fKeepTime = l_0_4, fEventTimeEnd = l_0_4, szMapName = "�ֹ�����¼", bIsVisible = l_0_4, szType = "Debuff", nIconID = l_0_4, bChatAlertW = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, dwID = l_0_4, buff = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 25
l_0_4 = 29.9375
l_0_4 = 221047.5
l_0_4 = 1875
l_0_4 = 408
l_0_4 = 221063.125
l_0_4 = true
l_0_4 = true
l_0_4 = 3
l_0_4 = 2
l_0_4 = true
l_0_5 = false
l_0_5 = 590
l_0_5 = 3439583
l_0_5 = 1875
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = "�����ɢ������¶"
l_0_4 = "ȥƿ��λ�õ�ˮ�����buff��"
l_0_4 = true
l_0_4 = 30
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "Ӣ�۳ֹ�������", fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bChatAlertW = l_0_4, buff = l_0_4, szName = l_0_4, tAlarmAddInfo = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 29
l_0_4 = 59.875
l_0_5 = false
l_0_5 = 1949
l_0_5 = 3469065
l_0_5 = 1884
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 221331.25
l_0_4 = 1884
l_0_4 = 2020
l_0_4 = 221391.25
l_0_4 = true
l_0_4 = true
l_0_4 = 3
l_0_4 = "ȥͭ���λ�ý�buff��"
l_0_4 = 2
l_0_4 = true
l_0_4 = "������������곤��"
l_0_4 = true
l_0_4 = 59.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, tAlarmAddInfo = l_0_4, nAutoEventTimeMode = l_0_4, bIsDebuff = l_0_4, szName = l_0_4, szMapName = "Ӣ�۳ֹ�������", bManyMembers = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 34
l_0_4 = 7.6875
l_0_5 = false
l_0_5 = 458
l_0_5 = 4102901
l_0_5 = 3623
l_0_5 = 1
l_0_5 = 0
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 132192.4375
l_0_4 = 3623
l_0_4 = 2133
l_0_4 = 132199.25
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 5, [l_0_5] = 0}
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = "������"
l_0_4 = true
l_0_4 = 7.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGAlertColor = l_0_4, tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, szMapName = "������", bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 42
l_0_4 = 4.875
l_0_4 = 224433.9375
l_0_5 = false
l_0_5 = 1114
l_0_5 = 362651
l_0_5 = 3756
l_0_5 = 1
l_0_5 = 1073789283
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 2038
l_0_4 = 1
l_0_4 = 2
l_0_4 = "ǧ����"
l_0_4 = 3756
l_0_4 = "��������"
l_0_4 = 224433.25
l_0_4 = true
l_0_4 = 5.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", nIconID = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = l_0_4, dwID = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 50
l_0_4 = 15
l_0_5 = false
l_0_5 = 4761
l_0_5 = 2231
l_0_5 = 4982319
l_0_5 = 1
l_0_5 = 0
l_0_5 = 4
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 5, [l_0_5] = 0}
l_0_4 = 2231
l_0_4 = 2021
l_0_4 = 46497.9375
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = "ѪͿʥӡ"
l_0_4 = 46482.9375
l_0_4 = true
l_0_4 = 15
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 58
l_0_4 = 12
l_0_5 = false
l_0_5 = 1123
l_0_5 = 4
l_0_5 = 2666
l_0_5 = 1
l_0_5 = 0
l_0_5 = 2111880
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 2, [l_0_5] = 255}
l_0_4 = 2666
l_0_4 = 2022
l_0_4 = 121482.25
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 255}
l_0_4 = "ע��"
l_0_4 = 121470.25
l_0_4 = true
l_0_4 = 11.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 51
l_0_4 = 20
l_0_5 = false
l_0_5 = 3916
l_0_5 = 4
l_0_5 = 2628
l_0_5 = 1
l_0_5 = 1077093717
l_0_5 = 4955248
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 2, [l_0_5] = 255}
l_0_4 = 2628
l_0_4 = 325
l_0_4 = 45066.125
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 0, [l_0_5] = 255}
l_0_4 = "������"
l_0_4 = 45046.125
l_0_4 = true
l_0_4 = 20
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 59
l_0_4 = 21
l_0_5 = false
l_0_5 = 486
l_0_5 = 4
l_0_5 = 4468412
l_0_5 = 1
l_0_5 = 1077771519
l_0_5 = 2181
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 5, [l_0_5] = 0}
l_0_4 = 2181
l_0_4 = 2124
l_0_4 = 114258.9375
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = 114256.125
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = "��ʬ��"
l_0_4 = true
l_0_4 = true
l_0_4 = 20.6875
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, fEventTimeStart = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, bManyMembers = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 55
l_0_4 = 5
l_0_4 = 120437.4375
l_0_5 = false
l_0_5 = 6852
l_0_5 = 2215
l_0_5 = 789252
l_0_5 = 1
l_0_5 = 1073924792
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 2
l_0_4 = 1
l_0_4 = 120433.6875
l_0_4 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = "�ٲ���˿��"
l_0_4 = 2215
l_0_4 = 345
l_0_4 = 4.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nAutoEventTimeMode = l_0_4, nLevel = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, dwID = l_0_4, nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 35
l_0_4 = 50
l_0_4 = 134134.5625
l_0_5 = false
l_0_5 = 1862
l_0_5 = 4119067
l_0_5 = 3629
l_0_5 = 1
l_0_5 = 1074085235
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 2019
l_0_4 = 1
l_0_4 = 2
l_0_4 = "���Ѷ�"
l_0_4 = 3629
l_0_4 = "ѱ����"
l_0_4 = 134089.8125
l_0_4 = true
l_0_4 = 44.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", nIconID = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = l_0_4, dwID = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 9
l_0_4 = 22.75
l_0_4 = 85917.5
l_0_5 = false
l_0_5 = 3147
l_0_5 = 3978
l_0_5 = 1332393
l_0_5 = 1
l_0_5 = 1073759929
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 85813.8125
l_0_4 = 2
l_0_4 = "�㶾"
l_0_4 = 3978
l_0_4 = 2744
l_0_4 = 22.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", bIsDebuff = l_0_4, nLevel = l_0_4, fEventTimeStart = l_0_4, nAutoEventTimeMode = l_0_4, szName = l_0_4, dwID = l_0_4, szCasterName = "���ɹ�", nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 11
l_0_4 = 134134488
l_0_5 = false
l_0_5 = 2117
l_0_5 = 1
l_0_5 = 4003
l_0_5 = 1
l_0_5 = 1073765031
l_0_5 = 2147483647
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = 85857.5625
l_0_4 = 4003
l_0_4 = 3401
l_0_4 = 85862.5625
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = "����ͼ��"
l_0_4 = "�ж�"
l_0_4 = 2
l_0_4 = true
l_0_4 = 134131872
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szMapName = "������", szCasterName = l_0_4, szName = l_0_4, nEventAlertStackNum = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 13
l_0_4 = 9.75
l_0_4 = true
l_0_4 = true
l_0_4 = 16180
l_0_4 = 3807
l_0_4 = 2020
l_0_4 = 16189.9375
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = "��ս"
l_0_4 = 2
l_0_5 = false
l_0_5 = 2609
l_0_5 = 1
l_0_5 = 256729
l_0_5 = 1
l_0_5 = 1073774793
l_0_5 = 3807
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = "��Х"
l_0_4 = true
l_0_4 = 9.5625
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "��ս����", bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", bChatAlertW = l_0_4, nLevel = l_0_4, tAlarmAddInfo = l_0_4, nAutoEventTimeMode = l_0_4, buff = l_0_4, szName = l_0_4, szCasterName = "��ç", bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 15
l_0_4 = 9.75
l_0_4 = true
l_0_4 = 271002.375
l_0_4 = 3782
l_0_4 = 2028
l_0_4 = 271012.25
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = "�����ƶ���ͣ��"
l_0_4 = 2
l_0_5 = false
l_0_5 = 1342
l_0_5 = 1
l_0_5 = 3782
l_0_5 = 1
l_0_5 = 1073774793
l_0_5 = 251977
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = 9.5625
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "��ս����", bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, tAlarmAddInfo = l_0_4, nAutoEventTimeMode = l_0_4, buff = l_0_4, szName = "�׶��ķ�", szCasterName = "��ç", bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 18
l_0_4 = 266494.875
l_0_4 = 2.6875
l_0_4 = 266498
l_0_5 = false
l_0_5 = 591
l_0_5 = 1
l_0_5 = 228578
l_0_5 = 1
l_0_5 = 1073782110
l_0_5 = 3999
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = 2027
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = 3999
l_0_4 = "����"
l_0_4 = "����������"
l_0_4 = true
l_0_4 = 2.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fEventTimeStart = l_0_4, fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nIconID = l_0_4, bScreenHead = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szMapName = "��ս����", dwID = l_0_4, szName = l_0_4, szCasterName = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 22
l_0_4 = 9.9375
l_0_4 = 78158.3125
l_0_5 = false
l_0_5 = 1078
l_0_5 = 1
l_0_5 = 376149
l_0_5 = 1
l_0_5 = 1073806371
l_0_5 = 3531
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = 78148.3125
l_0_4 = "����������"
l_0_4 = 3531
l_0_4 = 21
l_0_4 = "��ɳ"
l_0_4 = 9.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "�ֹ�����¼", bIsDebuff = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, fEventTimeStart = l_0_4, szName = l_0_4, dwID = l_0_4, nIconID = l_0_4, szCasterName = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 26
l_0_4 = 29.75
l_0_4 = 221007.6875
l_0_4 = 1876
l_0_4 = 2036
l_0_4 = 221037.625
l_0_4 = true
l_0_4 = true
l_0_4 = 3
l_0_4 = 2
l_0_4 = true
l_0_5 = false
l_0_5 = 962
l_0_5 = 3438303
l_0_5 = 1876
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = "�����ɢ�����̺�"
l_0_4 = "ȥС��λ�õ�ˮ�����buff��"
l_0_4 = true
l_0_4 = 29.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "Ӣ�۳ֹ�������", fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bChatAlertW = l_0_4, buff = l_0_4, szName = l_0_4, tAlarmAddInfo = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 30
l_0_4 = 59.875
l_0_5 = false
l_0_5 = 1915
l_0_5 = 3466161
l_0_5 = 1881
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 1881
l_0_4 = 338
l_0_4 = true
l_0_4 = true
l_0_4 = 3
l_0_4 = "ȥ���ٵ�λ�ý�buff��"
l_0_4 = true
l_0_4 = "�����������նɰ���"
l_0_4 = 2
l_0_4 = true
l_0_4 = 59
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, dwID = l_0_4, nIconID = l_0_4, bIsVisible = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, tAlarmAddInfo = l_0_4, szMapName = "Ӣ�۳ֹ�������", bIsDebuff = l_0_4, szName = l_0_4, nAutoEventTimeMode = l_0_4, bManyMembers = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 36
l_0_4 = 6
l_0_4 = 47931.9375
l_0_5 = false
l_0_5 = 3740
l_0_5 = 4148924
l_0_5 = 3668
l_0_5 = 1
l_0_5 = 1074085290
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 47927.8125
l_0_4 = 770
l_0_4 = 3668
l_0_4 = "����"
l_0_4 = 2
l_0_4 = "��֮����"
l_0_4 = 5.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", bIsDebuff = l_0_4, nLevel = l_0_4, fEventTimeStart = l_0_4, nIconID = l_0_4, dwID = l_0_4, szName = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 44
l_0_4 = 7.875
l_0_4 = 47796.75
l_0_5 = false
l_0_5 = 42
l_0_5 = 1
l_0_5 = 854955
l_0_5 = 1
l_0_5 = 1074108517
l_0_5 = 3893
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = "Ӣ��������"
l_0_4 = true
l_0_4 = 1
l_0_4 = 47788.875
l_0_4 = 3191
l_0_4 = 3893
l_0_4 = "ȼ��"
l_0_4 = 2
l_0_4 = "�ڵ�"
l_0_4 = 7.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = l_0_4, bIsDebuff = l_0_4, nLevel = l_0_4, fEventTimeStart = l_0_4, nIconID = l_0_4, dwID = l_0_4, szName = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 52
l_0_4 = 2
l_0_4 = 29.875
l_0_4 = 44964.75
l_0_5 = false
l_0_5 = 2263
l_0_5 = 4
l_0_5 = 2631
l_0_5 = 1
l_0_5 = 1077147514
l_0_5 = 4953977
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_5 = 1
l_0_5 = 2
l_0_5 = 4
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 5, [l_0_5] = 0}
l_0_4 = 44949.9375
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3
l_0_4 = {[l_0_5] = 255, [l_0_5] = 255, [l_0_5] = 0}
l_0_4 = 2631
l_0_4 = "��������"
l_0_4 = 336
l_0_4 = 30
l_0_1[l_0_2], l_0_3 = l_0_3, {nAutoEventTimeMode = l_0_4, fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", bIsDebuff = l_0_4, tRGCenterAlarm = l_0_4, nLevel = l_0_4, tRGAlertColor = l_0_4, fEventTimeStart = l_0_4, tRGBuffColor = l_0_4, dwID = l_0_4, szName = l_0_4, nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 60
l_0_4 = 5
l_0_5 = false
l_0_5 = 248
l_0_5 = 2090472
l_0_5 = 2172
l_0_5 = 1
l_0_5 = 1075819446
l_0_5 = 4
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = true
l_0_4 = "����"
l_0_4 = 2172
l_0_4 = 30
l_0_4 = 2031
l_0_4 = 5
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", bIsDebuff = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bManyMembers = l_0_4, szName = l_0_4, dwID = l_0_4, nEventAlertStackNum = l_0_4, nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = "Hash2"
l_0_4 = 2665
local l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3807
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3248
l_0_6 = 2
l_0_5 = {[l_0_6] = true}
l_0_4 = 2256
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3658
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2666
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3808
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3564
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3454
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2580
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 1877
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 1881
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3416
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3753
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2179
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 2628
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 2636
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3657
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3623
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3668
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 4003
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2676
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 2243
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3617
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3877
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 2204
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3976
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3984
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3799
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3629
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3756
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2678
l_0_6 = 2
l_0_5 = {[l_0_6] = true}
l_0_4 = 3782
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2181
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 1876
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3560
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2670
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 2174
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3505
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2631
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 3962
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3781
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3978
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 1883
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 1878
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3527
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3789
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 1875
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3773
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3971
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2215
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 3999
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2231
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 4066
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 1884
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3893
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 1882
l_0_6 = 3
l_0_5 = {[l_0_6] = true}
l_0_4 = 3531
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_4 = 2172
l_0_6 = 4
l_0_5 = {[l_0_6] = true}
l_0_4 = 4001
l_0_6 = 1
l_0_5 = {[l_0_6] = true}
l_0_1[l_0_2], l_0_3 = l_0_3, {[l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5, [l_0_4] = l_0_5}
l_0_2 = 46
l_0_4 = 2
l_0_4 = 10
l_0_4 = 190877.4375
l_0_5 = false
l_0_5 = 133
l_0_5 = 3454
l_0_5 = 305259
l_0_5 = 1
l_0_5 = 1073858087
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 190876.4375
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 255
l_0_5 = 4
l_0_6 = 5
l_0_5 = 3
l_0_6 = 0
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 255
l_0_5 = 3
l_0_6 = 0
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_4 = 3454
l_0_4 = "ʯ��"
l_0_4 = 936
l_0_4 = 9.9375
l_0_1[l_0_2], l_0_3 = l_0_3, {nAutoEventTimeMode = l_0_4, fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", bIsDebuff = l_0_4, bScreenHead = l_0_4, nLevel = l_0_4, fEventTimeStart = l_0_4, tRGAlertColor = l_0_4, tRGBuffColor = l_0_4, dwID = l_0_4, szName = l_0_4, nIconID = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 39
l_0_4 = 9.8125
l_0_5 = false
l_0_5 = 557
l_0_5 = 485683
l_0_5 = 2256
l_0_5 = 1
l_0_5 = 0
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_4 = 129396.5625
l_0_4 = 2256
l_0_4 = 2
l_0_4 = 129398.6875
l_0_4 = false
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 255
l_0_5 = 4
l_0_6 = 5
l_0_5 = 3
l_0_6 = 0
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 255
l_0_5 = 3
l_0_6 = 0
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_4 = "��Ѫ"
l_0_4 = true
l_0_4 = 9.8125
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", bChatAlertW = l_0_4, tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, tRGAlertColor = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, szMapName = "������", bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 43
l_0_4 = 9.8125
l_0_5 = false
l_0_5 = 2107
l_0_5 = 1
l_0_5 = 366237
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3657
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = 131752.8125
l_0_4 = 3657
l_0_4 = 6
l_0_4 = 131762.8125
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = "Ӣ��������"
l_0_4 = "nMinChatAlertCD"
l_0_5 = 2
l_0_4 = "����"
l_0_4 = true
l_0_4 = true
l_0_4 = 9.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szMapName = l_0_4, [l_0_4] = l_0_5, szName = l_0_4, bIsDebuff = l_0_4, bManyMembers = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 37
l_0_4 = 599.75
l_0_4 = 224440.9375
l_0_5 = false
l_0_5 = 789
l_0_5 = 4272953
l_0_5 = 3753
l_0_5 = 1
l_0_5 = 1074085217
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nEndFrame = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = "ǧ����"
l_0_4 = 1
l_0_4 = 2
l_0_4 = 2135
l_0_4 = 3753
l_0_4 = "����"
l_0_4 = 224439.8125
l_0_4 = true
l_0_4 = 599.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", szMapName = "������", szCasterName = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, nIconID = l_0_4, dwID = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 45
l_0_4 = 5
l_0_5 = false
l_0_5 = 132
l_0_5 = 3416
l_0_5 = 305096
l_0_5 = 1
l_0_5 = 1073858087
l_0_5 = 1
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = true
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 0
l_0_5 = 4
l_0_6 = 2
l_0_5 = 3
l_0_6 = 255
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_4 = 3416
l_0_4 = 279
l_0_4 = 190876.4375
l_0_4 = true
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = true
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 0
l_0_5 = 3
l_0_6 = 255
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_4 = "����"
l_0_4 = 190870.4375
l_0_4 = true
l_0_4 = 5.875
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, buff = l_0_4, bChatAlertT = l_0_4, bScreenHead = l_0_4, tRGAlertColor = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", tRGCenterAlarm = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, bIsVisible = l_0_4, tRGBuffColor = l_0_4, szName = l_0_4, fEventTimeStart = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 53
l_0_4 = 30
l_0_4 = 226881.625
l_0_5 = false
l_0_5 = 127
l_0_5 = 4
l_0_5 = 2243
l_0_5 = 1
l_0_5 = 0
l_0_5 = 2207764
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, dwID = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nEndFrame = l_0_5}
l_0_4 = true
l_0_4 = 226863.5
l_0_4 = 4
l_0_4 = 2
l_0_4 = 342
l_0_5 = 1
l_0_6 = 255
l_0_5 = 2
l_0_6 = 0
l_0_5 = 3
l_0_6 = 255
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_4 = 2243
l_0_4 = "����׼�"
l_0_4 = true
l_0_4 = 30
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", fEventTimeStart = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, nIconID = l_0_4, tRGBuffColor = l_0_4, dwID = l_0_4, szName = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 1
l_0_4 = 29.9375
l_0_4 = true
l_0_5 = false
l_0_5 = 196
l_0_5 = 4
l_0_5 = 2010494
l_0_5 = 1
l_0_5 = 1076668622
l_0_5 = 2174
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = 4
l_0_4 = 2
l_0_4 = "����ָ"
l_0_4 = 2174
l_0_4 = 331
l_0_4 = true
l_0_4 = 29
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "25��Ӣ��ݶ��ʥ��", bIsVisible = l_0_4, szType = "Debuff", buff = l_0_4, bManyMembers = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szCasterName = "ĵ��", szName = l_0_4, dwID = l_0_4, nIconID = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 19
l_0_4 = 271039.75
l_0_4 = 2.625
l_0_4 = 271042.6875
l_0_5 = false
l_0_5 = 328
l_0_5 = 1
l_0_5 = 228522
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3799
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = true
l_0_4 = 769
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = 3799
l_0_4 = "�����뿪ԭ��"
l_0_4 = true
l_0_4 = 5.875
l_0_1[l_0_2], l_0_3 = l_0_3, {fEventTimeStart = l_0_4, fKeepTime = l_0_4, fEventTimeEnd = l_0_4, buff = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nIconID = l_0_4, bScreenHead = l_0_4, nLevel = l_0_4, nAutoEventTimeMode = l_0_4, szMapName = "��ս����", dwID = l_0_4, szName = "��׼", tAlarmAddInfo = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 23
l_0_4 = 1.875
l_0_4 = true
l_0_4 = 78145
l_0_4 = 3560
l_0_4 = 397
l_0_4 = 78146.5625
l_0_4 = true
l_0_4 = 1
l_0_4 = 2
l_0_4 = "��ҡ�㿪��boss���ʱ�����ڿ���"
l_0_5 = false
l_0_5 = 69
l_0_5 = 1
l_0_5 = 403325
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3560
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, nLevel = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, dwID = l_0_5}
l_0_4 = "����"
l_0_4 = true
l_0_4 = true
l_0_4 = 1.5625
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "�ֹ�����¼", bChatAlertT = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bChatAlertW = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, tAlarmAddInfo = l_0_4, buff = l_0_4, szName = l_0_4, bIsVisible = l_0_4, bIsDebuff = l_0_4, nEventAlertTime = l_0_4}
l_0_2 = 31
l_0_4 = 60
l_0_4 = true
l_0_4 = true
l_0_4 = 221270.75
l_0_4 = 1883
l_0_4 = 331
l_0_4 = 221330.6875
l_0_4 = true
l_0_4 = 3
l_0_4 = 2
l_0_4 = "ȥ���ӵ�λ�ý�buff��"
l_0_4 = true
l_0_4 = "�������������µ���"
l_0_5 = false
l_0_5 = 642
l_0_5 = 1883
l_0_5 = 3509166
l_0_5 = 1
l_0_5 = 0
l_0_5 = 3
l_0_4 = {bCanCancel = l_0_5, nIndex = l_0_5, dwID = l_0_5, nEndFrame = l_0_5, nStackNum = l_0_5, dwSkillSrcID = l_0_5, nLevel = l_0_5}
l_0_4 = true
l_0_4 = 59.75
l_0_1[l_0_2], l_0_3 = l_0_3, {fKeepTime = l_0_4, szMapName = "Ӣ�۳ֹ�������", bChatAlertT = l_0_4, bScreenHead = l_0_4, fEventTimeStart = l_0_4, dwID = l_0_4, nIconID = l_0_4, fEventTimeEnd = l_0_4, bIsVisible = l_0_4, szType = "Debuff", nLevel = l_0_4, nAutoEventTimeMode = l_0_4, tAlarmAddInfo = l_0_4, bIsDebuff = l_0_4, szName = l_0_4, buff = l_0_4, bManyMembers = l_0_4, nEventAlertTime = l_0_4}
l_0_0.Debuff = l_0_1
l_0_1 = "Scrutiny"
l_0_3 = "Hash"
l_0_4 = {}
l_0_3 = "Hash2"
l_0_4 = {}
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = l_0_4, [l_0_3] = l_0_4}
l_0_1 = "Buff"
l_0_3 = 1
l_0_5 = 8.9375
l_0_5 = 205890.1875
l_0_6 = true
l_0_6 = 2987
l_0_6 = 3
l_0_6 = 4101
l_0_6 = 1
l_0_6 = 828181
l_0_6 = 3260641
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nEndFrame = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = "bNotAddToCTM"
l_0_6 = true
l_0_5 = 3
l_0_5 = 2
l_0_5 = 2994
l_0_5 = 205881.25
l_0_5 = "��Ǽ��"
l_0_5 = 4101
l_0_5 = false
l_0_5 = 8.5625
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, fEventTimeStart = l_0_5, szName = l_0_5, dwID = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 2
l_0_5 = 133949416
l_0_5 = 134217728
l_0_6 = true
l_0_6 = 294
l_0_6 = 2147483647
l_0_6 = 3917
l_0_6 = 3
l_0_6 = 0
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nEndFrame = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 1
l_0_5 = 2
l_0_5 = false
l_0_5 = 271042.375
l_0_5 = "��ˮ"
l_0_5 = 3917
l_0_5 = 3446
l_0_5 = 133946688
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, szMapName = "��ս����", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsDebuff = l_0_5, fEventTimeStart = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 4
l_0_5 = 7.875
l_0_5 = true
l_0_5 = 77432.9375
l_0_5 = 3989
l_0_5 = 3433
l_0_5 = 77440.5625
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 1
l_0_5 = "�⹦ͣ��"
l_0_5 = true
l_0_5 = 2
l_0_5 = "�쳾��Ӣ"
l_0_6 = true
l_0_6 = 90
l_0_6 = 1
l_0_6 = 413837
l_0_6 = 1
l_0_6 = 0
l_0_6 = 3989
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, dwID = l_0_6}
l_0_5 = false
l_0_5 = 7.625
l_0_4 = {fKeepTime = l_0_5, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, fEventTimeStart = l_0_5, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nLevel = l_0_5, tAlarmAddInfo = l_0_5, bChatAlertW = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, buff = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 8
l_0_5 = 1799.875
l_0_5 = 129399.1875
l_0_5 = true
l_0_5 = "Buff"
l_0_6 = true
l_0_6 = 124
l_0_6 = 4108656
l_0_6 = 3616
l_0_6 = 1
l_0_6 = 0
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nEndFrame = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = 1
l_0_5 = 2
l_0_5 = false
l_0_5 = 3616
l_0_5 = 129398.5
l_0_5 = 2030
l_0_5 = 1799.6875
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, buff = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsDebuff = l_0_5, szName = "������繦", dwID = l_0_5, fEventTimeStart = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 9
l_0_5 = 240
l_0_5 = 131753.8125
l_0_5 = true
l_0_5 = "Buff"
l_0_6 = true
l_0_6 = 2792
l_0_6 = 4136726
l_0_6 = 3722
l_0_6 = 1
l_0_6 = 0
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nEndFrame = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = 1
l_0_5 = 2
l_0_5 = false
l_0_5 = "��������"
l_0_5 = 3722
l_0_5 = 131513.875
l_0_5 = 21
l_0_5 = 239.6875
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, buff = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsDebuff = l_0_5, szName = l_0_5, dwID = l_0_5, fEventTimeStart = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 5
l_0_5 = 7.875
l_0_5 = true
l_0_5 = 77974
l_0_5 = 3990
l_0_5 = 3432
l_0_5 = 77981.5625
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_6 = true
l_0_6 = 68
l_0_6 = 1
l_0_6 = 403389
l_0_6 = 1
l_0_6 = 0
l_0_6 = 3990
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, dwID = l_0_6}
l_0_5 = "�쳾��Ӣ"
l_0_5 = "�ڹ�ͣ�֣��ڹ�ͣ��"
l_0_5 = false
l_0_5 = 7.5625
l_0_4 = {fKeepTime = l_0_5, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, fEventTimeStart = l_0_5, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertW = l_0_5, buff = l_0_5, szName = l_0_5, tAlarmAddInfo = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 10
l_0_5 = 59.6875
l_0_5 = 139740.6875
l_0_6 = true
l_0_6 = 110
l_0_6 = 4
l_0_6 = 2664
l_0_6 = 1
l_0_6 = 0
l_0_6 = 3499973
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nEndFrame = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = true
l_0_5 = 4
l_0_5 = 139684.6875
l_0_5 = 2
l_0_5 = 11
l_0_5 = 2664
l_0_5 = "ͬ����֦"
l_0_5 = false
l_0_5 = 56
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, dwID = l_0_5, szName = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 11
l_0_5 = 134083368
l_0_5 = 134217728
l_0_6 = true
l_0_6 = 84
l_0_6 = 4
l_0_6 = 2190
l_0_6 = 1
l_0_6 = 1074991663
l_0_6 = 2147483647
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nEndFrame = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = true
l_0_5 = 4
l_0_5 = 120437.6875
l_0_5 = 2
l_0_5 = 6
l_0_5 = "�ƽ��˵�"
l_0_5 = 2190
l_0_5 = false
l_0_5 = 134097288
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, szName = l_0_5, dwID = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = "Hash"
l_0_5 = 3616
l_0_6 = true
l_0_5 = 2664
l_0_6 = true
l_0_5 = 3722
l_0_6 = true
l_0_5 = 2192
l_0_6 = true
l_0_5 = 4101
l_0_6 = true
l_0_5 = 920
l_0_6 = true
l_0_5 = 3537
l_0_6 = true
l_0_5 = 3515
l_0_6 = true
l_0_5 = 2979
l_0_6 = true
l_0_5 = 943
l_0_6 = true
l_0_5 = 3989
l_0_6 = true
l_0_5 = 917
l_0_6 = true
l_0_5 = 3990
l_0_6 = true
l_0_5 = 2190
l_0_6 = true
l_0_5 = 3917
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 3
l_0_5 = 29.1875
l_0_6 = true
l_0_6 = 0
l_0_6 = 1
l_0_6 = 413021
l_0_6 = 3
l_0_6 = 0
l_0_6 = 3537
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nLevel = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, dwID = l_0_6}
l_0_5 = true
l_0_5 = 78100
l_0_5 = 3537
l_0_5 = 3447
l_0_5 = 78129
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = true
l_0_5 = 1
l_0_5 = "��ʮ���أ���ս�ٶ�Զ��"
l_0_5 = 2
l_0_5 = "����"
l_0_5 = 25
l_0_5 = false
l_0_5 = 29
l_0_4 = {fKeepTime = l_0_5, buff = l_0_5, bChatAlertT = l_0_5, fEventTimeStart = l_0_5, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, bChatAlertW = l_0_5, szType = l_0_5, bIsVisible = l_0_5, nLevel = l_0_5, tAlarmAddInfo = l_0_5, nAutoEventTimeMode = l_0_5, szMapName = "�ֹ�����¼", szName = l_0_5, nEventAlertStackNum = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 6
l_0_5 = 9.6875
l_0_5 = true
l_0_5 = 75266
l_0_5 = 2979
l_0_5 = 2434
l_0_5 = 75267.0625
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_6 = true
l_0_6 = 405
l_0_6 = 1152699
l_0_6 = 2979
l_0_6 = 1
l_0_6 = 0
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nEndFrame = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = "�������ıӻ�"
l_0_5 = "��ʧ���Ƿ磬���Ƕ���"
l_0_5 = false
l_0_5 = 1.0625
l_0_4 = {fKeepTime = l_0_5, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, fEventTimeStart = l_0_5, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertW = l_0_5, buff = l_0_5, szName = l_0_5, tAlarmAddInfo = l_0_5, bIsDebuff = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 12
l_0_5 = 134169888
l_0_5 = 134217728
l_0_6 = true
l_0_6 = 558
l_0_6 = 2192
l_0_6 = 2147483647
l_0_6 = 1
l_0_6 = 1074210288
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, dwID = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = true
l_0_5 = 1
l_0_5 = 120447.6875
l_0_5 = 2
l_0_5 = false
l_0_5 = 2192
l_0_5 = "��Ȼ��ʽ"
l_0_5 = 334
l_0_5 = 134097280
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, nAutoEventTimeMode = l_0_5, bIsDebuff = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = "Hash2"
l_0_5 = 3616
local l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2664
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3722
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2192
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 4101
l_0_7 = 3
l_0_6 = {[l_0_7] = true}
l_0_5 = 920
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3537
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3515
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2979
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 943
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3989
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 917
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3990
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2190
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3917
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 13
l_0_5 = 10
l_0_5 = 121479.25
l_0_6 = true
l_0_6 = 135
l_0_6 = 943
l_0_6 = 704680
l_0_6 = 1
l_0_6 = 359714
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, dwID = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 9.6875
l_0_5 = 1
l_0_5 = 121469.1875
l_0_5 = false
l_0_5 = "�Ź���������"
l_0_5 = 943
l_0_5 = 2
l_0_5 = 1649
l_0_5 = "bNotAddToCTM"
l_0_6 = true
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nEventAlertTime = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, bIsDebuff = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 7
l_0_5 = 59.125
l_0_5 = 77813
l_0_5 = 3515
l_0_5 = 938
l_0_5 = 77845.3125
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 2
l_0_5 = false
l_0_5 = 1
l_0_5 = "ѣ�μ��ܣ�Զ������"
l_0_5 = true
l_0_5 = "nMinChatAlertCD"
l_0_6 = 30
l_0_5 = "��ëǧ��"
l_0_6 = true
l_0_6 = 520
l_0_6 = 1184657
l_0_6 = 3515
l_0_6 = 1
l_0_6 = 0
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, nEndFrame = l_0_6, dwID = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = 32.3125
l_0_4 = {fKeepTime = l_0_5, szMapName = "�ֹ�����¼", fEventTimeStart = l_0_5, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, bChatAlertW = l_0_5, szType = l_0_5, nAutoEventTimeMode = l_0_5, bIsDebuff = l_0_5, nLevel = l_0_5, tAlarmAddInfo = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, buff = l_0_5, bManyMembers = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 14
l_0_5 = 9.9375
l_0_5 = 49314.1875
l_0_6 = true
l_0_6 = 68
l_0_6 = 920
l_0_6 = 2083393
l_0_6 = 1
l_0_6 = 772943
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, dwID = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 9.75
l_0_5 = 1
l_0_5 = 49304.125
l_0_5 = false
l_0_5 = 920
l_0_5 = "�����������"
l_0_5 = 2
l_0_5 = 1680
l_0_5 = "bNotAddToCTM"
l_0_6 = true
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nEventAlertTime = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, bIsDebuff = l_0_5, dwID = l_0_5, szName = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 15
l_0_5 = 10
l_0_5 = 138599.1875
l_0_6 = true
l_0_6 = 337
l_0_6 = 917
l_0_6 = 854211
l_0_6 = 1
l_0_6 = 782154
l_0_6 = 1
l_0_5 = {bCanCancel = l_0_6, nIndex = l_0_6, dwID = l_0_6, nEndFrame = l_0_6, nStackNum = l_0_6, dwSkillSrcID = l_0_6, nLevel = l_0_6}
l_0_5 = true
l_0_5 = "Buff"
l_0_5 = 9.75
l_0_5 = 1
l_0_5 = 138589.1875
l_0_5 = false
l_0_5 = "��շ�ħ����"
l_0_5 = 917
l_0_5 = 2
l_0_5 = 1661
l_0_5 = "bNotAddToCTM"
l_0_6 = true
l_0_4 = {fKeepTime = l_0_5, fEventTimeEnd = l_0_5, buff = l_0_5, bIsVisible = l_0_5, szType = l_0_5, nEventAlertTime = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, bIsDebuff = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6}
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4}
l_0_1 = "Casting"
l_0_3 = 31
l_0_5 = "fMinTime"
l_0_6 = 7.75
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 8.0625, [l_0_7] = 7.875, [l_0_7] = 7.875}
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "�������һ�(����)"
l_0_5 = 3898
l_0_5 = "��ɳ"
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 20, [l_0_7] = 17, [l_0_7] = 16.9375, [l_0_7] = 16.875}
l_0_5 = true
l_0_5 = 2
l_0_5 = 3
l_0_5 = 13
l_0_5 = "fMinTime"
l_0_6 = 16.875
l_0_5 = "������"
l_0_5 = 3254
l_0_5 = 16
l_0_4 = {[l_0_5] = l_0_6, szMapName = "��������", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, szCasterName = "����", nEventAlertTime = l_0_5}
l_0_3 = 8
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 52.3125
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 52.3125, [l_0_7] = 54.5625, [l_0_7] = 52.3125, [l_0_7] = 52.375, [l_0_7] = 58.5, [l_0_7] = 53, [l_0_7] = 52.3125, [l_0_7] = 265.5625, [l_0_7] = 53.875, [l_0_7] = 52.9375}
l_0_5 = "����̶����"
l_0_5 = 1
l_0_5 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 3921
l_0_5 = "��ײ����͸��"
l_0_5 = true
l_0_5 = 13
l_0_5 = 52
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szMapName = "������", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, bIsVisible = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 32
l_0_5 = "fMinTime"
l_0_6 = 7.8125
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 11.875, [l_0_7] = 14.9375, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875}
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��ɳ"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "�����ƻ�(��͸)"
l_0_5 = 3514
l_0_5 = 13
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 33
l_0_5 = "fMinTime"
l_0_6 = 7.125
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.8125, [l_0_7] = 7.9375, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 7.875, [l_0_7] = 13.4375, [l_0_7] = 7.9375, [l_0_7] = 7.875}
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�������"
l_0_5 = true
l_0_5 = "�������"
l_0_5 = 3901
l_0_5 = 13
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 34
l_0_5 = "fMinTime"
l_0_6 = 7.875
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 8.0625, [l_0_7] = 7.9375, [l_0_7] = 8, [l_0_7] = 7.9375, [l_0_7] = 8.0625, [l_0_7] = 8, [l_0_7] = 8, [l_0_7] = 7.875, [l_0_7] = 8.0625, [l_0_7] = 7.9375}
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = true
l_0_5 = "���ƹ�"
l_0_5 = 3502
l_0_5 = "�ݵ���"
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 35
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7, [l_0_7] = 7.125, [l_0_7] = 7, [l_0_7] = 7.375, [l_0_7] = 7.0625, [l_0_7] = 7, [l_0_7] = 7.0625, [l_0_7] = 7.375, [l_0_7] = 7.0625, [l_0_7] = 7}
l_0_5 = 13
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3512
l_0_5 = "��ѹ"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "˺�Ѷ���"
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nIconID = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 9
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 2
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_6 = {[l_0_7] = 58.5, [l_0_7] = 53, [l_0_7] = 23.0625, [l_0_7] = 265.5625, [l_0_7] = 271.875}
l_0_5 = 3920
l_0_5 = 13
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 23.0625
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = "����"
l_0_5 = "����̶����"
l_0_5 = true
l_0_5 = 38
l_0_4 = {szMapName = "������", bChatAlertT = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertW = l_0_5, szName = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 36
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = 75364.9375
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = 74164.9375
l_0_5 = 1
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = "�޴������"
l_0_5 = 2
l_0_5 = "����������(��͸)"
l_0_5 = 3522
l_0_5 = 13
l_0_5 = 1200
l_0_4 = {[l_0_5] = l_0_6, fEventTimeEnd = l_0_5, szMapName = "�ֹ�����¼", bIsVisible = l_0_5, szType = l_0_5, fEventTimeStart = l_0_5, nLevel = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 37
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 856.5, [l_0_7] = 60.5, [l_0_7] = 302.5625, [l_0_7] = 60.375}
l_0_5 = "fMinTime"
l_0_6 = 60.375
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��ɳ"
l_0_5 = true
l_0_5 = 3523
l_0_5 = "����������"
l_0_5 = 13
l_0_5 = 60
l_0_4 = {szMapName = "�ֹ�����¼", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 38
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 60.375
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 60.5, [l_0_7] = 60.625, [l_0_7] = 60.5, [l_0_7] = 60.5, [l_0_7] = 60.375, [l_0_7] = 60.625, [l_0_7] = 60.4375, [l_0_7] = 60.5, [l_0_7] = 60.5625, [l_0_7] = 60.5625}
l_0_5 = "��ɳ"
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��ҡ�㿪��׼����"
l_0_5 = 3515
l_0_5 = "����������(��͸)"
l_0_5 = true
l_0_5 = 13
l_0_5 = 60
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, tAlarmAddInfo = l_0_5, dwID = l_0_5, szName = l_0_5, bIsVisible = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 39
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_7 = 2
l_0_7 = 8
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_7 = 7
l_0_6 = {[l_0_7] = 87.3125, [l_0_7] = 999.875, [l_0_7] = 95.625, [l_0_7] = 99.3125, [l_0_7] = 99, [l_0_7] = 95.5625, [l_0_7] = 101.6875, [l_0_7] = 93.875}
l_0_5 = "fMinTime"
l_0_6 = 87.3125
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�޴������"
l_0_5 = true
l_0_5 = "����������(��͸)"
l_0_5 = 3520
l_0_5 = 13
l_0_5 = 94
l_0_4 = {szMapName = "�ֹ�����¼", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 10
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = true
l_0_5 = 3947
l_0_5 = "�򶾱���"
l_0_5 = "�򶾱���"
l_0_5 = 15
l_0_4 = {szMapName = "������", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 40
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_7 = 2
l_0_7 = 8
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_7 = 7
l_0_6 = {[l_0_7] = 87.3125, [l_0_7] = 999.875, [l_0_7] = 95.625, [l_0_7] = 99.3125, [l_0_7] = 99, [l_0_7] = 95.5625, [l_0_7] = 101.6875, [l_0_7] = 93.875}
l_0_5 = "fMinTime"
l_0_6 = 87.3125
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�޴������"
l_0_5 = true
l_0_5 = "����������(��͸)"
l_0_5 = 3521
l_0_5 = 13
l_0_5 = 94
l_0_4 = {szMapName = "�ֹ�����¼", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 41
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 25.25, [l_0_7] = 14.875, [l_0_7] = 16.5, [l_0_7] = 34.3125, [l_0_7] = 30.3125, [l_0_7] = 24.5, [l_0_7] = 26.0625, [l_0_7] = 30.5, [l_0_7] = 22.0625, [l_0_7] = 30.9375}
l_0_5 = "fMinTime"
l_0_6 = 14.875
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��"
l_0_5 = true
l_0_5 = 3899
l_0_5 = "�������һ�(����)"
l_0_5 = 13
l_0_5 = 22
l_0_4 = {szMapName = "�ֹ�����¼", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 42
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 13.25, [l_0_7] = 10.25, [l_0_7] = 13.1875, [l_0_7] = 13.1875, [l_0_7] = 10.1875, [l_0_7] = 13.1875, [l_0_7] = 13.1875, [l_0_7] = 13.1875, [l_0_7] = 10.1875, [l_0_7] = 10.1875}
l_0_5 = 1821
l_0_5 = 13
l_0_5 = "nLastSecond"
l_0_6 = 7
l_0_5 = "fMinTime"
l_0_6 = 10.125
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 15
l_0_5 = 2
l_0_5 = "��������"
l_0_5 = "����������������"
l_0_5 = "�����߸"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 11
l_0_4 = {szMapName = "Ӣ�۳ֹ�������", bChatAlertT = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, tAlarmAddInfo = l_0_5, szName = l_0_5, szCasterName = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 43
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = "fMinTime"
l_0_6 = 7.125
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7.5, [l_0_7] = 17.6875, [l_0_7] = 7.4375, [l_0_7] = 7.125, [l_0_7] = 14.9375, [l_0_7] = 20.75, [l_0_7] = 16.5625, [l_0_7] = 19.5625, [l_0_7] = 13.5, [l_0_7] = 9.1875}
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = "����"
l_0_5 = 3703
l_0_5 = "���ڵ�Ѳ��"
l_0_5 = 10
l_0_4 = {szSoundFile = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "������", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 11
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = true
l_0_5 = 3938
l_0_5 = "����"
l_0_5 = "����"
l_0_5 = 16
l_0_4 = {szMapName = "������", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 44
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 3
l_0_6 = {[l_0_7] = 25.0625, [l_0_7] = 5, [l_0_7] = 5}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = 3590
l_0_5 = "��Ѫ�󷨣����̣�"
l_0_5 = "������"
l_0_5 = 11
l_0_4 = {szMapName = "������", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 45
l_0_5 = "fMinTime"
l_0_6 = 13.9375
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 255, [l_0_7] = 0, [l_0_7] = 3, [l_0_7] = 0}
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 20.0625, [l_0_7] = 19.9375, [l_0_7] = 20.0625, [l_0_7] = 16.0625, [l_0_7] = 16.125, [l_0_7] = 16.125, [l_0_7] = 20, [l_0_7] = 19.125, [l_0_7] = 20, [l_0_7] = 19.9375}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "��ػ𣨴��̣�"
l_0_5 = 3564
l_0_5 = 13
l_0_5 = "����"
l_0_5 = 18
l_0_4 = {[l_0_5] = l_0_6, szSoundFile = l_0_5, [l_0_5] = l_0_6, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 46
l_0_5 = true
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = "nEventCountdownTime"
l_0_6 = 10
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 2
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_6 = {[l_0_7] = 35, [l_0_7] = 35, [l_0_7] = 35.0625, [l_0_7] = 5, [l_0_7] = 5}
l_0_5 = "½Ѱ"
l_0_5 = 1
l_0_5 = 1
l_0_5 = true
l_0_5 = 3628
l_0_5 = "����̤��ʽ�����̣�"
l_0_5 = 13
l_0_5 = 35
l_0_4 = {bIsVisible = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertT = l_0_5, dwID = l_0_5, szName = l_0_5, szMapName = "������", nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 3
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_6 = {[l_0_7] = 7.0625, [l_0_7] = 7}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��ˮ"
l_0_5 = 3948
l_0_5 = "ʴ�Ƕ�Һ"
l_0_5 = 13
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, szMapName = "������", dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 12
l_0_5 = 17381.5625
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 16181.5625
l_0_5 = 2
l_0_5 = 3724
l_0_5 = "̰��Хɷն"
l_0_5 = 13
l_0_5 = 1200
l_0_4 = {fEventTimeEnd = l_0_5, szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, bIsVisible = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, szCasterName = "��ç", nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 48
l_0_5 = "fMinTime"
l_0_6 = 21.9375
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 134105.625
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 25, [l_0_7] = 25, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 25, [l_0_7] = 25.0625, [l_0_7] = 30, [l_0_7] = 25, [l_0_7] = 30}
l_0_5 = true
l_0_5 = 1
l_0_5 = 134079.625
l_0_5 = "���Ѷ�"
l_0_5 = "�����ط�"
l_0_5 = 3613
l_0_5 = 2
l_0_5 = 13
l_0_5 = 26
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, fEventTimeEnd = l_0_5, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, szCasterName = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 49
l_0_5 = true
l_0_5 = "fMinTime"
l_0_6 = 27
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30.0625, [l_0_7] = 30, [l_0_7] = 30}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "���л��������̣�"
l_0_5 = 3616
l_0_5 = "���Ѷ�"
l_0_5 = 30
l_0_4 = {bIsVisible = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, szMapName = "������", szName = l_0_5, dwID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 50
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = "fMinTime"
l_0_6 = 13
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 18, [l_0_7] = 13, [l_0_7] = 15, [l_0_7] = 14.9375, [l_0_7] = 18, [l_0_7] = 528.1875, [l_0_7] = 18.0625, [l_0_7] = 17, [l_0_7] = 18, [l_0_7] = 15}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "��â���������̣�"
l_0_5 = 3682
l_0_5 = "ǧ����"
l_0_5 = 15
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, szMapName = "������", szName = l_0_5, dwID = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 51
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 2
l_0_5 = 13
l_0_5 = 3598
l_0_5 = "��ȡ����"
l_0_5 = "���밵ɱ��"
l_0_5 = 1200
l_0_4 = {szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, dwID = l_0_5, szName = l_0_5, szCasterName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 13
l_0_5 = 17379.5625
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 16179.5625
l_0_5 = 2
l_0_5 = 3723
l_0_5 = "̰��Хɷն"
l_0_5 = 13
l_0_5 = 1200
l_0_4 = {fEventTimeEnd = l_0_5, szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, bIsVisible = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, szCasterName = "��ç", nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 52
l_0_5 = "fMinTime"
l_0_6 = 28.75
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33, [l_0_7] = 33}
l_0_5 = 2
l_0_5 = 2
l_0_5 = "����"
l_0_5 = 2808
l_0_5 = 13
l_0_5 = 33
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 53
l_0_5 = "fMinTime"
l_0_6 = 3
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 22, [l_0_7] = 3, [l_0_7] = 3, [l_0_7] = 22, [l_0_7] = 22, [l_0_7] = 22, [l_0_7] = 22, [l_0_7] = 22, [l_0_7] = 22, [l_0_7] = 22}
l_0_5 = 2
l_0_5 = 2
l_0_5 = 2807
l_0_5 = "���֮ŭ"
l_0_5 = 13
l_0_5 = 22
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 54
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = true
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 255, [l_0_7] = 0, [l_0_7] = 2, [l_0_7] = 255}
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 2198
l_0_5 = 13
l_0_5 = 133533.5
l_0_5 = "fMinTime"
l_0_6 = 32.875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 132989.5
l_0_5 = true
l_0_5 = "��ɽ��"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_6 = {[l_0_7] = 1055.25, [l_0_7] = 32.875}
l_0_5 = "bAddToSkillTimer"
l_0_6 = false
l_0_5 = 544
l_0_4 = {szSoundFile = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, nIconID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, fEventTimeStart = l_0_5, bChatAlertW = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 55
l_0_5 = "fMinTime"
l_0_6 = 20
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 20.5, [l_0_7] = 20.5, [l_0_7] = 20.5, [l_0_7] = 20.5, [l_0_7] = 20.5, [l_0_7] = 21.5, [l_0_7] = 20.5, [l_0_7] = 20.5, [l_0_7] = 21.25, [l_0_7] = 21}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "����˪����"
l_0_5 = 3080
l_0_5 = 13
l_0_5 = 20
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 14
l_0_5 = 13
l_0_5 = "fMinTime"
l_0_6 = 25
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 3
l_0_6 = {[l_0_7] = 25, [l_0_7] = 25, [l_0_7] = 47}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "����׹��"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 3719
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 255, [l_0_7] = 0, [l_0_7] = 3, [l_0_7] = 0}
l_0_5 = 32
l_0_4 = {szMapName = "��ս����", nIconID = l_0_5, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, [l_0_5] = l_0_6, szCasterName = "��ç", nEventAlertTime = l_0_5}
l_0_3 = 56
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = true
l_0_5 = "fMinTime"
l_0_6 = 12
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 16, [l_0_7] = 16.375, [l_0_7] = 12.25, [l_0_7] = 17.75, [l_0_7] = 17.25, [l_0_7] = 12.3125, [l_0_7] = 14.125, [l_0_7] = 15.25, [l_0_7] = 19.375, [l_0_7] = 17.1875}
l_0_5 = true
l_0_5 = 4
l_0_5 = 2
l_0_5 = true
l_0_5 = "��������"
l_0_5 = 2777
l_0_5 = true
l_0_5 = 13
l_0_5 = 12
l_0_4 = {szSoundFile = l_0_5, bChatAlertW = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertT = l_0_5, szName = l_0_5, dwID = l_0_5, bIsVisible = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 57
l_0_5 = "fMinTime"
l_0_6 = 21.4375
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 21.875, [l_0_7] = 21.6875, [l_0_7] = 21.6875, [l_0_7] = 21.6875, [l_0_7] = 21.6875, [l_0_7] = 21.875, [l_0_7] = 21.6875, [l_0_7] = 21.75, [l_0_7] = 21.6875, [l_0_7] = 21.6875}
l_0_5 = 4
l_0_5 = 2
l_0_5 = "ǧ�밵��"
l_0_5 = 3068
l_0_5 = 13
l_0_5 = 21
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 58
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 23
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 24.6875, [l_0_7] = 24, [l_0_7] = 24.1875, [l_0_7] = 23.1875, [l_0_7] = 23.25, [l_0_7] = 24.25, [l_0_7] = 24.4375, [l_0_7] = 24.0625, [l_0_7] = 23.5625, [l_0_7] = 23.3125}
l_0_5 = 4
l_0_5 = 2
l_0_5 = "����ﵻ��"
l_0_5 = 2124
l_0_5 = 13
l_0_5 = 23
l_0_4 = {tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 59
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = "fMinTime"
l_0_6 = 35.1875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 37.25, [l_0_7] = 35.375, [l_0_7] = 36, [l_0_7] = 39, [l_0_7] = 36, [l_0_7] = 35.75, [l_0_7] = 35.5, [l_0_7] = 36, [l_0_7] = 36.5, [l_0_7] = 35.5}
l_0_5 = true
l_0_5 = 4
l_0_5 = 2
l_0_5 = true
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 0, [l_0_7] = 255, [l_0_7] = 1, [l_0_7] = 0}
l_0_5 = "���ƻ�ת��"
l_0_5 = 2535
l_0_5 = 13
l_0_5 = 35
l_0_4 = {szSoundFile = l_0_5, [l_0_5] = l_0_6, bChatAlertW = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 15
l_0_5 = 17046.5625
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = true
l_0_5 = 1
l_0_5 = 15846.5625
l_0_5 = "�����ٷ�"
l_0_5 = 2
l_0_5 = 3760
l_0_5 = "����"
l_0_5 = 13
l_0_5 = 1200
l_0_4 = {fEventTimeEnd = l_0_5, szMapName = "��ս����", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, szCasterName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 60
l_0_5 = "fMinTime"
l_0_6 = 13.5
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 24.4375, [l_0_7] = 17, [l_0_7] = 20, [l_0_7] = 15, [l_0_7] = 17.5, [l_0_7] = 15, [l_0_7] = 15, [l_0_7] = 16.9375, [l_0_7] = 14.5, [l_0_7] = 17.5}
l_0_5 = true
l_0_5 = 4
l_0_5 = 2
l_0_5 = 2118
l_0_5 = "�ƽ��˵�"
l_0_5 = 13
l_0_5 = 15
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 61
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = "fMinTime"
l_0_6 = 34.1875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 34.8125, [l_0_7] = 35.1875, [l_0_7] = 35.5625, [l_0_7] = 41.375, [l_0_7] = 40.75, [l_0_7] = 35.5, [l_0_7] = 34.1875, [l_0_7] = 42.5, [l_0_7] = 36.9375, [l_0_7] = 36}
l_0_5 = true
l_0_5 = 4
l_0_5 = 2
l_0_5 = true
l_0_6 = 1
l_0_7 = 0
l_0_6 = 2
l_0_7 = 255
l_0_6 = 4
l_0_7 = 1
l_0_6 = 3
l_0_7 = 0
l_0_5 = {[l_0_6] = l_0_7, [l_0_6] = l_0_7, [l_0_6] = l_0_7, [l_0_6] = l_0_7}
l_0_5 = 2809
l_0_5 = "��ز�����"
l_0_5 = 13
l_0_5 = 34
l_0_4 = {szSoundFile = l_0_5, [l_0_5] = l_0_6, bChatAlertW = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, tRGAlertColor = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 62
l_0_5 = "fMinTime"
l_0_6 = 20.5
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 20.5625, [l_0_7] = 20.625, [l_0_7] = 20.625, [l_0_7] = 20.625, [l_0_7] = 20.75, [l_0_7] = 20.5625, [l_0_7] = 20.625, [l_0_7] = 20.75, [l_0_7] = 20.5, [l_0_7] = 20.6875}
l_0_5 = 4
l_0_5 = 2
l_0_5 = "����̰�ǵ�"
l_0_5 = 2824
l_0_5 = 13
l_0_5 = 20
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 1
l_0_5 = "ݶ������"
l_0_5 = "����֮ŭ"
l_0_5 = true
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = "nEventCountdownTime"
l_0_6 = 3
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 14, [l_0_7] = 13.0625, [l_0_7] = 13.125, [l_0_7] = 7, [l_0_7] = 13.5, [l_0_7] = 13.9375, [l_0_7] = 14.0625, [l_0_7] = 13.5, [l_0_7] = 14.375, [l_0_7] = 13.5}
l_0_5 = true
l_0_5 = 1
l_0_5 = 1
l_0_5 = "nRemoveDelayTime"
l_0_6 = 3
l_0_5 = 3049
l_0_5 = "����(����)"
l_0_5 = true
l_0_5 = 13
l_0_5 = 7
l_0_4 = {szMapName = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, bChatAlertT = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 4
l_0_5 = true
l_0_5 = "fMinTime"
l_0_6 = 30
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30, [l_0_7] = 30}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 3912
l_0_5 = "ʬ��-���깦����͸��"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 13
l_0_5 = 30
l_0_4 = {bChatAlertT = l_0_5, szCasterName = "���ɹ�", [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szMapName = "������", dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 16
l_0_5 = 17053.4375
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 15853.4375
l_0_5 = 2
l_0_5 = 3758
l_0_5 = "�ٻ�"
l_0_5 = 13
l_0_5 = 1200
l_0_4 = {fEventTimeEnd = l_0_5, szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, bIsVisible = l_0_5, nLevel = l_0_5, fEventTimeStart = l_0_5, szCasterName = "��������", nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 64
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = "nEventCountdownTime"
l_0_6 = 8
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 22, [l_0_7] = 32, [l_0_7] = 22, [l_0_7] = 24, [l_0_7] = 21, [l_0_7] = 27, [l_0_7] = 27, [l_0_7] = 27, [l_0_7] = 20, [l_0_7] = 23}
l_0_5 = 4
l_0_5 = 2
l_0_5 = "bAddToSkillTimer"
l_0_6 = false
l_0_5 = true
l_0_5 = "�����ѿ�ǹ"
l_0_5 = 2793
l_0_5 = 13
l_0_5 = 22
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 17
l_0_5 = "bAddToSkillTimer"
l_0_6 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 17.0625, [l_0_7] = 17.0625, [l_0_7] = 16.875, [l_0_7] = 17.0625, [l_0_7] = 17.9375, [l_0_7] = 15, [l_0_7] = 16.9375, [l_0_7] = 14.0625, [l_0_7] = 16.0625, [l_0_7] = 17}
l_0_5 = 3720
l_0_5 = "fMinTime"
l_0_6 = 13.9375
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 13
l_0_5 = "����ҷ��"
l_0_5 = true
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 255, [l_0_7] = 0, [l_0_7] = 3, [l_0_7] = 0}
l_0_5 = 16
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, szCasterName = "��ç", [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertT = l_0_5, nIconID = l_0_5, szName = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 18
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 3
l_0_6 = {[l_0_7] = 43, [l_0_7] = 42.9375, [l_0_7] = 44}
l_0_5 = "fMinTime"
l_0_6 = 42.9375
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3754
l_0_5 = "���ƹ���"
l_0_5 = 13
l_0_5 = 43
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = "��ç", bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 19
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 44, [l_0_7] = 43.9375, [l_0_7] = 281, [l_0_7] = 177.1875}
l_0_5 = 3718
l_0_5 = "fMinTime"
l_0_6 = 43.9375
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "bAddToSkillTimer"
l_0_6 = true
l_0_5 = "Ѹ���ƶ������米��"
l_0_5 = "���ƹ��ף���͸��"
l_0_5 = true
l_0_5 = 13
l_0_5 = 43
l_0_4 = {szMapName = "��ս����", bChatAlertT = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szCasterName = "��ç", [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, tAlarmAddInfo = l_0_5, szName = l_0_5, bIsVisible = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 5
l_0_5 = true
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_7 = 2
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_6 = {[l_0_7] = 10.0625, [l_0_7] = 9.9375, [l_0_7] = 10, [l_0_7] = 10.0625, [l_0_7] = 9.9375, [l_0_7] = 20}
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = 13
l_0_5 = "fMinTime"
l_0_6 = 9.9375
l_0_5 = "�㶾ն"
l_0_5 = 3913
l_0_5 = 9
l_0_4 = {bIsVisible = l_0_5, szMapName = "������", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, szCasterName = "���ɹ�", nEventAlertTime = l_0_5}
l_0_3 = 20
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_6 = {[l_0_7] = 21.5625, [l_0_7] = 24.5625}
l_0_5 = "fMinTime"
l_0_6 = 21.5625
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�������"
l_0_5 = true
l_0_5 = 3741
l_0_5 = "������ͷ��"
l_0_5 = 13
l_0_5 = 23
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 21
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 27, [l_0_7] = 26, [l_0_7] = 51, [l_0_7] = 25}
l_0_5 = "fMinTime"
l_0_6 = 25
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3722
l_0_5 = 13
l_0_5 = 25
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = "��ç", bIsVisible = l_0_5, dwID = l_0_5, szName = "�׶��ķ�", nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 22
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_7 = 2
l_0_6 = {[l_0_7] = 7.9375, [l_0_7] = 8}
l_0_5 = "fMinTime"
l_0_6 = 7.9375
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�����ٷ�"
l_0_5 = true
l_0_5 = 3733
l_0_5 = "��������"
l_0_5 = 13
l_0_5 = 7
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 23
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_6 = {[l_0_7] = 10.0625}
l_0_5 = "fMinTime"
l_0_6 = 10.0625
l_0_5 = 1
l_0_5 = 2
l_0_5 = "���������"
l_0_5 = true
l_0_5 = 3864
l_0_5 = "��̤"
l_0_5 = 13
l_0_5 = 10
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 6
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 12, [l_0_7] = 13.0625, [l_0_7] = 7, [l_0_7] = 7, [l_0_7] = 7, [l_0_7] = 7, [l_0_7] = 12.9375, [l_0_7] = 12.875, [l_0_7] = 13.0625, [l_0_7] = 7.0625}
l_0_5 = ""
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3934
l_0_5 = 13
l_0_5 = 8
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = "���ɹ�", szMapName = "������", nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 24
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 21, [l_0_7] = 16.875, [l_0_7] = 22.5625, [l_0_7] = 15.875, [l_0_7] = 12.875, [l_0_7] = 19.4375, [l_0_7] = 13.25, [l_0_7] = 17.875, [l_0_7] = 13.5, [l_0_7] = 16}
l_0_5 = 3756
l_0_5 = "�����ٷ�"
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 12.875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 2
l_0_5 = "ע����"
l_0_5 = "��ɲ�ɻ�"
l_0_5 = 13
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 15
l_0_4 = {szMapName = "��ս����", bChatAlertT = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szCasterName = l_0_5, tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, tAlarmAddInfo = l_0_5, szName = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 25
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_6 = {[l_0_7] = 7.9375}
l_0_5 = "fMinTime"
l_0_6 = 7.9375
l_0_5 = 1
l_0_5 = 2
l_0_5 = "�����ٷ�"
l_0_5 = true
l_0_5 = 3734
l_0_5 = "��״��Ļ�"
l_0_5 = 13
l_0_5 = 258
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 26
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 12, [l_0_7] = 12, [l_0_7] = 11.9375, [l_0_7] = 12, [l_0_7] = 11.9375, [l_0_7] = 12, [l_0_7] = 11.9375, [l_0_7] = 12.0625, [l_0_7] = 12.0625, [l_0_7] = 12.0625}
l_0_5 = "fMinTime"
l_0_6 = 7.25
l_0_5 = 1
l_0_5 = 2
l_0_5 = "����������"
l_0_5 = true
l_0_5 = 3867
l_0_5 = "����"
l_0_5 = 13
l_0_5 = 11
l_0_4 = {szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = "Hash"
l_0_5 = 1821
l_0_6 = true
l_0_5 = 3521
l_0_6 = true
l_0_5 = 2807
l_0_6 = true
l_0_5 = 3760
l_0_6 = true
l_0_5 = 3899
l_0_6 = true
l_0_5 = 2838
l_0_6 = true
l_0_5 = 3901
l_0_6 = true
l_0_5 = 3723
l_0_6 = true
l_0_5 = 3724
l_0_6 = true
l_0_5 = 3934
l_0_6 = true
l_0_5 = 2808
l_0_6 = true
l_0_5 = 3068
l_0_6 = true
l_0_5 = 2824
l_0_6 = true
l_0_5 = 2809
l_0_6 = true
l_0_5 = 3722
l_0_6 = true
l_0_5 = 3947
l_0_6 = true
l_0_5 = 2793
l_0_6 = true
l_0_5 = 3564
l_0_6 = true
l_0_5 = 3502
l_0_6 = true
l_0_5 = 2124
l_0_6 = true
l_0_5 = 3518
l_0_6 = true
l_0_5 = 3080
l_0_6 = true
l_0_5 = 3912
l_0_6 = true
l_0_5 = 3920
l_0_6 = true
l_0_5 = 3613
l_0_6 = true
l_0_5 = 3754
l_0_6 = true
l_0_5 = 3522
l_0_6 = true
l_0_5 = 3703
l_0_6 = true
l_0_5 = 3569
l_0_6 = true
l_0_5 = 3590
l_0_6 = true
l_0_5 = 3913
l_0_6 = true
l_0_5 = 3921
l_0_6 = true
l_0_5 = 3509
l_0_6 = true
l_0_5 = 3616
l_0_6 = true
l_0_5 = 2118
l_0_6 = true
l_0_5 = 3512
l_0_6 = true
l_0_5 = 3520
l_0_6 = true
l_0_5 = 3623
l_0_6 = true
l_0_5 = 3914
l_0_6 = true
l_0_5 = 3733
l_0_6 = true
l_0_5 = 3741
l_0_6 = true
l_0_5 = 3938
l_0_6 = true
l_0_5 = 3898
l_0_6 = true
l_0_5 = 3756
l_0_6 = true
l_0_5 = 2198
l_0_6 = true
l_0_5 = 3718
l_0_6 = true
l_0_5 = 3864
l_0_6 = true
l_0_5 = 3734
l_0_6 = true
l_0_5 = 3049
l_0_6 = true
l_0_5 = 3867
l_0_6 = true
l_0_5 = 3254
l_0_6 = true
l_0_5 = 3514
l_0_6 = true
l_0_5 = 3900
l_0_6 = true
l_0_5 = 3719
l_0_6 = true
l_0_5 = 2535
l_0_6 = true
l_0_5 = 3598
l_0_6 = true
l_0_5 = 3628
l_0_6 = true
l_0_5 = 3758
l_0_6 = true
l_0_5 = 3948
l_0_6 = true
l_0_5 = 3515
l_0_6 = true
l_0_5 = 3523
l_0_6 = true
l_0_5 = 3720
l_0_6 = true
l_0_5 = 2777
l_0_6 = true
l_0_5 = 3682
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 27
l_0_5 = "fMinTime"
l_0_6 = 8.875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 15, [l_0_7] = 9, [l_0_7] = 9, [l_0_7] = 9, [l_0_7] = 9, [l_0_7] = 9, [l_0_7] = 12, [l_0_7] = 9, [l_0_7] = 9, [l_0_7] = 9}
l_0_5 = "����"
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3569
l_0_5 = "�����"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 13
l_0_5 = 9
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 7
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 25.0625
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 34.9375, [l_0_7] = 34.9375, [l_0_7] = 35, [l_0_7] = 35.0625, [l_0_7] = 34.9375, [l_0_7] = 34.9375, [l_0_7] = 34.9375, [l_0_7] = 34.9375, [l_0_7] = 35.0625, [l_0_7] = 25.0625}
l_0_5 = "����"
l_0_5 = 1
l_0_5 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 3914
l_0_5 = "�չ�����"
l_0_5 = true
l_0_5 = 13
l_0_5 = 33
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, bChatAlertT = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 28
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 7, [l_0_7] = 7.0625, [l_0_7] = 7, [l_0_7] = 7.0625, [l_0_7] = 11.4375, [l_0_7] = 7.0625, [l_0_7] = 7, [l_0_7] = 7, [l_0_7] = 7.3125, [l_0_7] = 7.0625}
l_0_5 = "�����ڷ�"
l_0_5 = 1
l_0_5 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "��Ѫ���"
l_0_5 = 3509
l_0_5 = true
l_0_5 = 13
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, bIsVisible = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 29
l_0_5 = "fMinTime"
l_0_6 = 7.875
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 8, [l_0_7] = 8.125, [l_0_7] = 8, [l_0_7] = 15.75, [l_0_7] = 7.9375, [l_0_7] = 8.0625, [l_0_7] = 8.125, [l_0_7] = 8, [l_0_7] = 7.9375, [l_0_7] = 15.875}
l_0_5 = 1
l_0_5 = 2
l_0_5 = "��ɳ"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "���Ѫצ"
l_0_5 = 3518
l_0_5 = 13
l_0_5 = 8
l_0_4 = {[l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", nLevel = l_0_5, nAutoEventTimeMode = l_0_5, szCasterName = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = "Hash2"
l_0_5 = 1821
l_0_7 = 15
l_0_6 = {[l_0_7] = true}
l_0_5 = 3521
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2807
l_0_7 = 2
l_0_6 = {[l_0_7] = true}
l_0_5 = 3760
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3899
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2838
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3901
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3723
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3724
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3934
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2808
l_0_7 = 2
l_0_6 = {[l_0_7] = true}
l_0_5 = 3068
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 2824
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 2809
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3722
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3947
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2793
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3564
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3502
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2124
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3518
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3080
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3912
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3920
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3613
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3754
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3522
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3703
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3569
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3590
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3913
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3921
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3509
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3616
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2118
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3512
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3520
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3623
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3914
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3733
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3741
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3938
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3898
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3756
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2198
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3718
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3864
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3734
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3049
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3867
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3254
l_0_7 = 2
l_0_6 = {[l_0_7] = true}
l_0_5 = 3514
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3900
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3719
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2535
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3598
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3628
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3758
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3948
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3515
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3523
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 3720
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_5 = 2777
l_0_7 = 4
l_0_6 = {[l_0_7] = true}
l_0_5 = 3682
l_0_7 = 1
l_0_6 = {[l_0_7] = true}
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 30
l_0_5 = "fMinTime"
l_0_6 = 10.125
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_7 = 2
l_0_7 = 3
l_0_7 = 1
l_0_7 = 4
l_0_7 = 5
l_0_7 = 7
l_0_6 = {[l_0_7] = 21, [l_0_7] = 12.625, [l_0_7] = 10.125, [l_0_7] = 13.5, [l_0_7] = 12.25, [l_0_7] = 20.25, [l_0_7] = 40}
l_0_5 = "��ɳ"
l_0_5 = 1
l_0_5 = 2
l_0_5 = true
l_0_5 = 3900
l_0_5 = "�쳾��Ӣ��"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 13
l_0_5 = 12
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, szCasterName = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 63
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = "tRGRedAlarm"
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 3
l_0_6 = {[l_0_7] = 255, [l_0_7] = 0, [l_0_7] = 2, [l_0_7] = 255}
l_0_5 = true
l_0_5 = 4
l_0_5 = 2
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 33.75, [l_0_7] = 34, [l_0_7] = 35.75, [l_0_7] = 15.5, [l_0_7] = 37.75, [l_0_7] = 20.5, [l_0_7] = 16.75, [l_0_7] = 10.5, [l_0_7] = 42.25, [l_0_7] = 38.25}
l_0_5 = 2838
l_0_5 = "����ȼҶ��"
l_0_5 = 13
l_0_5 = 34
l_0_4 = {szSoundFile = l_0_5, [l_0_5] = l_0_6, bChatAlertW = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, nIconID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 47
l_0_5 = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_7 = 1
l_0_7 = 2
l_0_7 = 4
l_0_7 = 8
l_0_7 = 9
l_0_7 = 5
l_0_7 = 10
l_0_7 = 3
l_0_7 = 6
l_0_6 = {[l_0_7] = 66.4375, [l_0_7] = 66.625, [l_0_7] = 66.75, [l_0_7] = 66.625, [l_0_7] = 62.3125, [l_0_7] = 62.4375, [l_0_7] = 66.5, [l_0_7] = 62.375, [l_0_7] = 66.625, [l_0_7] = 66.6875}
l_0_6 = 1
l_0_7 = 255
l_0_6 = 2
l_0_7 = 0
l_0_6 = 4
l_0_7 = 2
l_0_6 = 3
l_0_7 = 255
l_0_5 = {[l_0_6] = l_0_7, [l_0_6] = l_0_7, [l_0_6] = l_0_7, [l_0_6] = l_0_7}
l_0_5 = "nRemoveDelayTime"
l_0_6 = 25
l_0_5 = 3623
l_0_5 = 13
l_0_5 = "fMinTime"
l_0_6 = 57.375
l_0_5 = true
l_0_5 = "Casting"
l_0_5 = true
l_0_5 = 1
l_0_5 = 1
l_0_5 = true
l_0_5 = "��ӿ�����̣�"
l_0_5 = "��֮����"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 66
l_0_4 = {szSoundFile = l_0_5, szMapName = "������", bChatAlertT = l_0_5, [l_0_5] = l_0_6, tRGAlertColor = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, nIconID = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nLevel = l_0_5, nAutoEventTimeMode = l_0_5, bChatAlertW = l_0_5, szName = l_0_5, szCasterName = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4}
l_0_1 = "Npc"
l_0_3 = 27
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = "dwLinkNpcTID"
l_0_6 = 17406
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = 17406
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = 134490.25
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ�������Ѷ�"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = "tTimerSet"
l_0_7 = 1
local l_0_8 = {}
local l_0_9 = "szTimerName"
l_0_8[l_0_9] = "�����ط�"
l_0_9 = "nTime"
l_0_8[l_0_9] = 20
l_0_7 = 2
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 35}
l_0_7 = 4
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 65}
l_0_7 = 8
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 150}
l_0_7 = 16
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 295}
l_0_7 = 17
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 305}
l_0_7 = 9
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 165}
l_0_7 = 18
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 315}
l_0_7 = 5
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 75}
l_0_7 = 10
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 180}
l_0_7 = 20
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 380}
l_0_7 = 21
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 395}
l_0_7 = 11
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 190}
l_0_7 = 22
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 410}
l_0_7 = 3
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 50}
l_0_7 = 6
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 85}
l_0_7 = 12
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 200}
l_0_7 = 24
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 430}
l_0_7 = 13
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 250}
l_0_7 = 7
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 135}
l_0_7 = 14
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 265}
l_0_7 = 15
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 280}
l_0_7 = 19
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 365}
l_0_7 = 23
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 420}
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "szTimerSet"
l_0_6 = "20,�����ط�;35,���л���;50,�����ط�;65,���л���;75,�����ط�;85,��ɨ�˻�;135,�����ط�;150,���л���;165,�����ط�;180,���л���;190,�����ط�;200,��ɨ�˻�;250,�����ط�;265,���л���;280,�����ط�;295,���л���;305,�����ط�;315,��ɨ�˻�;365,�����ط�;380,���л���;395,�����ط�;410,���л���;420,�����ط�;430,��ɨ�˻�"
l_0_5 = 1
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = 133890.25
l_0_5 = "���Ѷ�"
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = 600
l_0_5 = "bEnemy"
l_0_6 = false
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, [l_0_5] = l_0_6, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, fEventTimeStart = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 2
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "ݶ������"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 14.9375
l_0_7 = 1
l_0_8 = 18.1875
l_0_7 = 2
l_0_8 = 15.5
l_0_7 = 4
l_0_8 = 15.5
l_0_7 = 8
l_0_8 = 18.1875
l_0_7 = 9
l_0_8 = 15.5625
l_0_7 = 5
l_0_8 = 18.375
l_0_7 = 10
l_0_8 = 18.375
l_0_7 = 3
l_0_8 = 17.6875
l_0_7 = 6
l_0_8 = 15.375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 2
l_0_5 = "�綾����"
l_0_5 = 15658
l_0_5 = "fMinTime"
l_0_6 = 14.9375
l_0_5 = 16
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 38
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 17.1875
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 27.75
l_0_7 = 1
l_0_8 = 29.9375
l_0_7 = 2
l_0_8 = 30.25
l_0_7 = 4
l_0_8 = 22.375
l_0_7 = 8
l_0_8 = 22.8125
l_0_7 = 9
l_0_8 = 26.9375
l_0_7 = 5
l_0_8 = 22.125
l_0_7 = 10
l_0_8 = 26
l_0_7 = 3
l_0_8 = 19.125
l_0_7 = 6
l_0_8 = 25.75
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = 21
l_0_5 = "����Ȧ"
l_0_5 = 10465
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 3
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = "����"
l_0_5 = 2
l_0_5 = 17741
l_0_5 = 1200
l_0_4 = {[l_0_5] = l_0_6, szMapName = "������", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 54
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 59.75
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 60
l_0_7 = 1
l_0_8 = 60
l_0_7 = 2
l_0_8 = 59.9375
l_0_7 = 4
l_0_8 = 60
l_0_7 = 8
l_0_8 = 59.8125
l_0_7 = 9
l_0_8 = 60.25
l_0_7 = 5
l_0_8 = 60
l_0_7 = 10
l_0_8 = 60
l_0_7 = 3
l_0_8 = 60.0625
l_0_7 = 6
l_0_8 = 59.9375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = 60
l_0_5 = true
l_0_5 = 13514
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, bChatAlertT = l_0_5, dwID = l_0_5, szName = "ĵ��", [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 4
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_8 = 20.5625
l_0_7 = 2
l_0_8 = 20.5
l_0_7 = 8
l_0_8 = 20.5625
l_0_7 = 3
l_0_8 = 25.5
l_0_7 = 1
l_0_8 = 25.5
l_0_7 = 4
l_0_8 = 20.4375
l_0_7 = 5
l_0_8 = 25.5
l_0_7 = 7
l_0_8 = 20.5
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "fMinTime"
l_0_6 = 20.4375
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = 17731
l_0_5 = 2
l_0_5 = "����̶����"
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = 20
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szMapName = "������", bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 5
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 24.9375
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 35.0625
l_0_7 = 1
l_0_8 = 25.0625
l_0_7 = 2
l_0_8 = 34.9375
l_0_7 = 4
l_0_8 = 35
l_0_7 = 8
l_0_8 = 34.9375
l_0_7 = 9
l_0_8 = 25.0625
l_0_7 = 5
l_0_8 = 35.0625
l_0_7 = 10
l_0_8 = 34.9375
l_0_7 = 3
l_0_8 = 25
l_0_7 = 6
l_0_8 = 24.9375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "nIconFrame"
l_0_6 = 50
l_0_5 = true
l_0_5 = "������"
l_0_5 = 17704
l_0_5 = 2
l_0_5 = 29
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, szMapName = "������", nEventAlertTime = l_0_5}
l_0_3 = 6
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "dwLinkNpcTID"
l_0_6 = 17572
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = 17572
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = 1
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 1200
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ�����ɹ�"
l_0_4 = {[l_0_5] = l_0_6, szMapName = "������", [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, szName = "���ɹ�", [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 7
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 8.8125
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_8 = 554.4375
l_0_7 = 2
l_0_8 = 11.875
l_0_7 = 3
l_0_8 = 17.25
l_0_7 = 1
l_0_8 = 8.8125
l_0_7 = 4
l_0_8 = 11.8125
l_0_7 = 5
l_0_8 = 47.125
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 10
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 2
l_0_5 = 16684
l_0_5 = "bEnemy"
l_0_6 = false
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = "��������", szMapName = "��ս����", [l_0_5] = l_0_6}
l_0_3 = 8
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "Npc"
l_0_5 = 1200
l_0_5 = 2
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = true
l_0_5 = 17110
l_0_5 = "����������"
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = "��ս����", [l_0_5] = l_0_6, szType = l_0_5, nEventAlertTime = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 10
l_0_5 = 86
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 87.1875
l_0_7 = 1
l_0_8 = 93.5
l_0_7 = 2
l_0_8 = 76.4375
l_0_7 = 4
l_0_8 = 100.875
l_0_7 = 8
l_0_8 = 93.9375
l_0_7 = 9
l_0_8 = 95.625
l_0_7 = 5
l_0_8 = 96.375
l_0_7 = 10
l_0_8 = 85.1875
l_0_7 = 3
l_0_8 = 76.3125
l_0_7 = 6
l_0_8 = 95.75
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "fMinTime"
l_0_6 = 76.3125
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "ע��Զ��"
l_0_5 = "�޴������"
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = 16351
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {nEventAlertTime = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, tAlarmAddInfo = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, bChatAlertT = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 12
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 52.3125
l_0_7 = 1
l_0_8 = 10.3125
l_0_7 = 2
l_0_8 = 7.3125
l_0_7 = 4
l_0_8 = 22.5625
l_0_7 = 8
l_0_8 = 46.75
l_0_7 = 9
l_0_8 = 42
l_0_7 = 5
l_0_8 = 54.1875
l_0_7 = 10
l_0_8 = 89.875
l_0_7 = 3
l_0_8 = 21.5625
l_0_7 = 6
l_0_8 = 29.25
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 25
l_0_5 = true
l_0_5 = "nIconFrame"
l_0_6 = 50
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "����"
l_0_5 = 16429
l_0_5 = 2
l_0_5 = "fMinTime"
l_0_6 = 7.3125
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 14
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 5.25
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 7.9375
l_0_7 = 1
l_0_8 = 8.125
l_0_7 = 2
l_0_8 = 7.875
l_0_7 = 4
l_0_8 = 7.9375
l_0_7 = 8
l_0_8 = 8.1875
l_0_7 = 9
l_0_8 = 7.75
l_0_7 = 5
l_0_8 = 6.1875
l_0_7 = 10
l_0_8 = 6.125
l_0_7 = 3
l_0_8 = 6.0625
l_0_7 = 6
l_0_8 = 8.125
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = 2
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "������"
l_0_5 = 7518
l_0_5 = 7
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, szMapName = "Ӣ�۳ֹ�������", nEventAlertTime = l_0_5}
l_0_3 = 16
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "dwLinkNpcTID"
l_0_6 = 15503
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = "tTimerSet"
l_0_7 = 1
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 25}
l_0_7 = 2
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 40}
l_0_7 = 4
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 81}
l_0_7 = 8
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 180}
l_0_7 = 16
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 350}
l_0_7 = 17
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 371}
l_0_7 = 9
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 195}
l_0_7 = 18
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 391}
l_0_7 = 5
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 102}
l_0_7 = 10
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 216}
l_0_7 = 20
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 424}
l_0_7 = 21
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 433}
l_0_7 = 11
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 236}
l_0_7 = 3
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 61}
l_0_7 = 6
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 114}
l_0_7 = 12
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 257}
l_0_7 = 13
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 269}
l_0_7 = 7
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 123}
l_0_7 = 14
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 278}
l_0_7 = 15
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 335}
l_0_7 = 19
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 412}
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = 2
l_0_5 = "szTimerSet"
l_0_6 = "25,��ӿ;40,ɨ��;61,ɨ�����;81,ɨ��;102,ɨ�����;114,��ӿ;123,���ص���;180,��ӿ;195,ɨ��;216,ɨ�����;236,ɨ��;257,ɨ�����;269,��ӿ;278,���ص���;335,��ӿ;350,ɨ��;371,ɨ�����;391,ɨ��;412,ɨ�����;424,��ӿ;433,���ص���"
l_0_5 = true
l_0_5 = 15503
l_0_5 = "��֮����(��ͨ)"
l_0_5 = 1200
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ������֮����"
l_0_4 = {[l_0_5] = l_0_6, szMapName = "������", [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bChatAlertT = l_0_5, dwID = l_0_5, szName = l_0_5, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 20
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 15.4375
l_0_7 = 1
l_0_8 = 12.9375
l_0_7 = 2
l_0_8 = 12.0625
l_0_7 = 4
l_0_8 = 14.9375
l_0_7 = 8
l_0_8 = 13.9375
l_0_7 = 9
l_0_8 = 16.75
l_0_7 = 5
l_0_8 = 12
l_0_7 = 10
l_0_8 = 13
l_0_7 = 3
l_0_8 = 13.125
l_0_7 = 6
l_0_8 = 13.375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = 17342
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 12
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = 12
l_0_5 = "���ص���"
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 24
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 8.375
l_0_7 = 1
l_0_8 = 34.0625
l_0_7 = 2
l_0_8 = 13
l_0_7 = 4
l_0_8 = 49.5
l_0_7 = 8
l_0_8 = 43.5625
l_0_7 = 9
l_0_8 = 12
l_0_7 = 5
l_0_8 = 249
l_0_7 = 10
l_0_8 = 25.0625
l_0_7 = 3
l_0_8 = 99.9375
l_0_7 = 6
l_0_8 = 46
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 17369
l_0_5 = 219753.875
l_0_5 = "fMinTime"
l_0_6 = 6
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = "���밵ɱ��"
l_0_5 = 219727.875
l_0_5 = true
l_0_5 = 26
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, fEventTimeStart = l_0_5, bIsVisible = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 28
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 17.0625
l_0_7 = 1
l_0_8 = 15.9375
l_0_7 = 2
l_0_8 = 7
l_0_7 = 4
l_0_8 = 16
l_0_7 = 8
l_0_8 = 16
l_0_7 = 9
l_0_8 = 9.9375
l_0_7 = 5
l_0_8 = 15
l_0_7 = 10
l_0_8 = 17
l_0_7 = 3
l_0_8 = 9.9375
l_0_7 = 6
l_0_8 = 10.0625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nMarkCount"
l_0_6 = 5
l_0_5 = 17417
l_0_5 = "fMinTime"
l_0_6 = 7
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "fLastMarkCountTime"
l_0_6 = 222616.3125
l_0_5 = 11
l_0_5 = "���ױ���"
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 32
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 47.0625
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 52.5
l_0_7 = 1
l_0_8 = 52.5625
l_0_7 = 2
l_0_8 = 52.5
l_0_7 = 4
l_0_8 = 52.5
l_0_7 = 8
l_0_8 = 52.5
l_0_7 = 9
l_0_8 = 52.5
l_0_7 = 5
l_0_8 = 52.5625
l_0_7 = 10
l_0_8 = 52.5
l_0_7 = 3
l_0_8 = 52.4375
l_0_7 = 6
l_0_8 = 52.4375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = "nRemoveDelayTime"
l_0_6 = 20
l_0_5 = 52
l_0_5 = 14966
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = "ѪͿ�籩"
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 40
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 14.3125
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 20.0625
l_0_7 = 1
l_0_8 = 19.8125
l_0_7 = 2
l_0_8 = 20
l_0_7 = 4
l_0_8 = 18.9375
l_0_7 = 8
l_0_8 = 19.9375
l_0_7 = 9
l_0_8 = 18.4375
l_0_7 = 5
l_0_8 = 26.0625
l_0_7 = 10
l_0_8 = 20.25
l_0_7 = 3
l_0_8 = 20
l_0_7 = 6
l_0_8 = 20
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = 2
l_0_5 = 20
l_0_5 = 14901
l_0_5 = "Ѫ��"
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 48
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 59.875
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 59.9375
l_0_7 = 1
l_0_8 = 60.125
l_0_7 = 2
l_0_8 = 59.9375
l_0_7 = 4
l_0_8 = 59.875
l_0_7 = 8
l_0_8 = 60
l_0_7 = 9
l_0_8 = 60.0625
l_0_7 = 5
l_0_8 = 59.9375
l_0_7 = 10
l_0_8 = 60
l_0_7 = 3
l_0_8 = 59.9375
l_0_7 = 6
l_0_8 = 60
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = true
l_0_5 = 14584
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = 60
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bChatAlertT = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, szName = "ĵ��", nEventAlertTime = l_0_5}
l_0_3 = 33
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 6
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 13
l_0_7 = 1
l_0_8 = 13
l_0_7 = 2
l_0_8 = 13.25
l_0_7 = 4
l_0_8 = 12.5
l_0_7 = 8
l_0_8 = 12.8125
l_0_7 = 9
l_0_8 = 11.4375
l_0_7 = 5
l_0_8 = 12.8125
l_0_7 = 10
l_0_8 = 11.5
l_0_7 = 3
l_0_8 = 13.5
l_0_7 = 6
l_0_8 = 18.25
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "�綾����"
l_0_5 = 2
l_0_5 = 16150
l_0_5 = 13
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 41
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 48.875
l_0_7 = 1
l_0_8 = 48.875
l_0_7 = 2
l_0_8 = 47.5625
l_0_7 = 4
l_0_8 = 47.5
l_0_7 = 8
l_0_8 = 47.5
l_0_7 = 9
l_0_8 = 48.8125
l_0_7 = 5
l_0_8 = 48.875
l_0_7 = 10
l_0_8 = 42.375
l_0_7 = 3
l_0_8 = 47.5
l_0_7 = 6
l_0_8 = 48.9375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bNotAddToScrutiny"
l_0_6 = false
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "��������"
l_0_5 = 2
l_0_5 = 14899
l_0_5 = 47
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 49
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 59.8125
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 60
l_0_7 = 1
l_0_8 = 60
l_0_7 = 2
l_0_8 = 60
l_0_7 = 4
l_0_8 = 60
l_0_7 = 8
l_0_8 = 60
l_0_7 = 9
l_0_8 = 60
l_0_7 = 5
l_0_8 = 60
l_0_7 = 10
l_0_8 = 60
l_0_7 = 3
l_0_8 = 60
l_0_7 = 6
l_0_8 = 60
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = true
l_0_5 = 2
l_0_5 = 14936
l_0_5 = 60
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szName = "ĵ��", nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 17
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "dwLinkNpcTID"
l_0_6 = 16417
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = "tTimerSet"
l_0_7 = 1
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 20}
l_0_7 = 2
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 35}
l_0_7 = 4
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 65}
l_0_7 = 8
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 150}
l_0_7 = 16
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 295}
l_0_7 = 17
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 305}
l_0_7 = 9
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 165}
l_0_7 = 18
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 315}
l_0_7 = 5
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 75}
l_0_7 = 10
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 180}
l_0_7 = 20
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 380}
l_0_7 = 21
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 395}
l_0_7 = 11
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 190}
l_0_7 = 22
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 410}
l_0_7 = 3
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 50}
l_0_7 = 6
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 85}
l_0_7 = 12
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 200}
l_0_7 = 24
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ɨ�˻�", [l_0_9] = 430}
l_0_7 = 13
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 250}
l_0_7 = 7
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 135}
l_0_7 = 14
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���л���", [l_0_9] = 265}
l_0_7 = 15
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 280}
l_0_7 = 19
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 365}
l_0_7 = 23
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "�����ط�", [l_0_9] = 420}
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = 2
l_0_5 = "szTimerSet"
l_0_6 = "20,�����ط�;35,���л���;50,�����ط�;65,���л���;75,�����ط�;85,��ɨ�˻�;135,�����ط�;150,���л���;165,�����ط�;180,���л���;190,�����ط�;200,��ɨ�˻�;250,�����ط�;265,���л���;280,�����ط�;295,���л���;305,�����ط�;315,��ɨ�˻�;365,�����ط�;380,���л���;395,�����ط�;410,���л���;420,�����ط�;430,��ɨ�˻�"
l_0_5 = true
l_0_5 = 16417
l_0_5 = "���Ѷ�(��ͨ)"
l_0_5 = 1200
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ�������Ѷ�"
l_0_4 = {[l_0_5] = l_0_6, szMapName = "������", [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bChatAlertT = l_0_5, dwID = l_0_5, szName = l_0_5, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 21
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 5.5
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 9.875
l_0_7 = 1
l_0_8 = 14.25
l_0_7 = 2
l_0_8 = 13.375
l_0_7 = 4
l_0_8 = 9.9375
l_0_7 = 8
l_0_8 = 16.3125
l_0_7 = 9
l_0_8 = 9.9375
l_0_7 = 5
l_0_8 = 14.125
l_0_7 = 10
l_0_8 = 6.375
l_0_7 = 3
l_0_8 = 9.875
l_0_7 = 6
l_0_8 = 12.3125
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = 10
l_0_5 = 2
l_0_5 = true
l_0_5 = "Ӣ��������"
l_0_5 = "�ڵ�"
l_0_5 = 17353
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nEventAlertTime = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, szMapName = l_0_5, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 25
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 25.0625
l_0_7 = 1
l_0_8 = 8
l_0_7 = 2
l_0_8 = 26
l_0_7 = 4
l_0_8 = 26.5625
l_0_7 = 8
l_0_8 = 256.5
l_0_7 = 9
l_0_8 = 13
l_0_7 = 5
l_0_8 = 61.9375
l_0_7 = 10
l_0_8 = 11
l_0_7 = 3
l_0_8 = 59.4375
l_0_7 = 6
l_0_8 = 19.5
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 17377
l_0_5 = 219762.8125
l_0_5 = "fMinTime"
l_0_6 = 5.4375
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = "������ʿ"
l_0_5 = 219744.8125
l_0_5 = true
l_0_5 = 18
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, fEventTimeStart = l_0_5, bIsVisible = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 29
l_0_5 = 16
l_0_5 = true
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 6
l_0_8 = 16.25
l_0_7 = 2
l_0_8 = 16.25
l_0_7 = 8
l_0_8 = 17
l_0_7 = 3
l_0_8 = 18
l_0_7 = 1
l_0_8 = 18
l_0_7 = 4
l_0_8 = 16.1875
l_0_7 = 5
l_0_8 = 18
l_0_7 = 7
l_0_8 = 18.25
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = false
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "����"
l_0_5 = 2
l_0_5 = 17419
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 16.1875
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {nEventAlertTime = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 34
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 13.6875
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 15.3125
l_0_7 = 1
l_0_8 = 15.25
l_0_7 = 2
l_0_8 = 15.4375
l_0_7 = 4
l_0_8 = 15.25
l_0_7 = 8
l_0_8 = 15.25
l_0_7 = 9
l_0_8 = 15.4375
l_0_7 = 5
l_0_8 = 15.4375
l_0_7 = 10
l_0_8 = 15.5
l_0_7 = 3
l_0_8 = 15.5
l_0_7 = 6
l_0_8 = 15.3125
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "�������"
l_0_5 = 2
l_0_5 = 16154
l_0_5 = 15
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 42
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 26.75
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 30
l_0_7 = 1
l_0_8 = 30
l_0_7 = 2
l_0_8 = 30
l_0_7 = 4
l_0_8 = 31.3125
l_0_7 = 8
l_0_8 = 30
l_0_7 = 9
l_0_8 = 28.25
l_0_7 = 5
l_0_8 = 30
l_0_7 = 10
l_0_8 = 31.75
l_0_7 = 3
l_0_8 = 28.6875
l_0_7 = 6
l_0_8 = 30
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "nIconFrame"
l_0_6 = 50
l_0_5 = 30
l_0_5 = "������"
l_0_5 = 15196
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 50
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 15.5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 23.9375
l_0_7 = 1
l_0_8 = 20
l_0_7 = 2
l_0_8 = 24.875
l_0_7 = 4
l_0_8 = 20.0625
l_0_7 = 8
l_0_8 = 20.0625
l_0_7 = 9
l_0_8 = 20.0625
l_0_7 = 5
l_0_8 = 20
l_0_7 = 10
l_0_8 = 20
l_0_7 = 3
l_0_8 = 20
l_0_7 = 6
l_0_8 = 20
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = 13479
l_0_5 = "Ѫ��"
l_0_5 = 2
l_0_5 = 20
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = "Hash"
l_0_5 = 14941
l_0_6 = true
l_0_5 = 17342
l_0_6 = true
l_0_5 = 17406
l_0_6 = true
l_0_5 = 15196
l_0_6 = true
l_0_5 = 13968
l_0_6 = true
l_0_5 = 16533
l_0_6 = true
l_0_5 = 10411
l_0_6 = true
l_0_5 = 17417
l_0_6 = true
l_0_5 = 17419
l_0_6 = true
l_0_5 = 7507
l_0_6 = true
l_0_5 = 16854
l_0_6 = true
l_0_5 = 16154
l_0_6 = true
l_0_5 = 17704
l_0_6 = true
l_0_5 = 16417
l_0_6 = true
l_0_5 = 17741
l_0_6 = true
l_0_5 = 15188
l_0_6 = true
l_0_5 = 16150
l_0_6 = true
l_0_5 = 17377
l_0_6 = true
l_0_5 = 16151
l_0_6 = true
l_0_5 = 16434
l_0_6 = true
l_0_5 = 17369
l_0_6 = true
l_0_5 = 13475
l_0_6 = true
l_0_5 = 17371
l_0_6 = true
l_0_5 = 14969
l_0_6 = true
l_0_5 = 14894
l_0_6 = true
l_0_5 = 13477
l_0_6 = true
l_0_5 = 17375
l_0_6 = true
l_0_5 = 17328
l_0_6 = true
l_0_5 = 16684
l_0_6 = true
l_0_5 = 13479
l_0_6 = true
l_0_5 = 14897
l_0_6 = true
l_0_5 = 14899
l_0_6 = true
l_0_5 = 14936
l_0_6 = true
l_0_5 = 13546
l_0_6 = true
l_0_5 = 17572
l_0_6 = true
l_0_5 = 7624
l_0_6 = true
l_0_5 = 13514
l_0_6 = true
l_0_5 = 16381
l_0_6 = true
l_0_5 = 14901
l_0_6 = true
l_0_5 = 17353
l_0_6 = true
l_0_5 = 15658
l_0_6 = true
l_0_5 = 13548
l_0_6 = true
l_0_5 = 14966
l_0_6 = true
l_0_5 = 16351
l_0_6 = true
l_0_5 = 16429
l_0_6 = true
l_0_5 = 15503
l_0_6 = true
l_0_5 = 14968
l_0_6 = true
l_0_5 = 14584
l_0_6 = true
l_0_5 = 15662
l_0_6 = true
l_0_5 = 10465
l_0_6 = true
l_0_5 = 14970
l_0_6 = true
l_0_5 = 17110
l_0_6 = true
l_0_5 = 7518
l_0_6 = true
l_0_5 = 17731
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 9
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 8.375
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 2
l_0_8 = 9
l_0_7 = 3
l_0_8 = 8.625
l_0_7 = 1
l_0_8 = 15.875
l_0_7 = 4
l_0_8 = 9.9375
l_0_7 = 5
l_0_8 = 8.375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 8
l_0_5 = true
l_0_5 = 2
l_0_5 = true
l_0_5 = "��ɫ����"
l_0_5 = 16434
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, bChatAlertT = l_0_5, nAutoEventTimeMode = l_0_5, bIsVisible = l_0_5, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, szMapName = "�ֹ�����¼", [l_0_5] = l_0_6}
l_0_3 = 13
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 28.125
l_0_7 = 1
l_0_8 = 29.75
l_0_7 = 2
l_0_8 = 29.75
l_0_7 = 4
l_0_8 = 32
l_0_7 = 8
l_0_8 = 28.6875
l_0_7 = 9
l_0_8 = 28.625
l_0_7 = 5
l_0_8 = 29.875
l_0_7 = 10
l_0_8 = 29.625
l_0_7 = 3
l_0_8 = 29.75
l_0_7 = 6
l_0_8 = 29
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = 7507
l_0_5 = "nLastSecond"
l_0_6 = 0
l_0_5 = "fMinTime"
l_0_6 = 28.125
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "ľ��"
l_0_5 = true
l_0_5 = "�ٶ���⣡"
l_0_5 = 29
l_0_4 = {[l_0_5] = l_0_6, szMapName = "Ӣ�۳ֹ�������", bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, bIsVisible = l_0_5, tAlarmAddInfo = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 35
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "dwLinkNpcTID"
l_0_6 = 14970
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = 2
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = 14970
l_0_5 = "׿����"
l_0_5 = 1200
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ����׿����"
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, bIsVisible = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 11
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 7.8125
l_0_7 = 1
l_0_8 = 7.9375
l_0_7 = 2
l_0_8 = 7.6875
l_0_7 = 4
l_0_8 = 7.6875
l_0_7 = 8
l_0_8 = 7.6875
l_0_7 = 9
l_0_8 = 7.6875
l_0_7 = 5
l_0_8 = 7.6875
l_0_7 = 10
l_0_8 = 7.8125
l_0_7 = 3
l_0_8 = 7.6875
l_0_7 = 6
l_0_8 = 7.5625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 7
l_0_5 = true
l_0_5 = "nIconFrame"
l_0_6 = 50
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "��Ѫ����"
l_0_5 = 16381
l_0_5 = 2
l_0_5 = "fMinTime"
l_0_6 = 7.4375
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = "�ֹ�����¼", bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 51
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 52.5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 1
l_0_8 = 52.5
l_0_7 = 2
l_0_8 = 52.5
l_0_7 = 4
l_0_8 = 52.5
l_0_7 = 3
l_0_8 = 52.5
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "����Ѫ��"
l_0_5 = 13546
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = 52
l_0_4 = {tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 15
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "nLastSecond"
l_0_6 = 4
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "25����ͨ�ֹ�������"
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 2
l_0_8 = 29.5
l_0_7 = 3
l_0_8 = 29.75
l_0_7 = 1
l_0_8 = 29.8125
l_0_7 = 4
l_0_8 = 28.875
l_0_7 = 5
l_0_8 = 28.5625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "�ٶ���⣡"
l_0_5 = 2
l_0_5 = 7624
l_0_5 = "fMinTime"
l_0_6 = 28.5625
l_0_5 = "ľ��"
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = 28
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, tAlarmAddInfo = l_0_5, nAutoEventTimeMode = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 18
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 6.375
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 7.5
l_0_7 = 1
l_0_8 = 8.5
l_0_7 = 2
l_0_8 = 11.625
l_0_7 = 4
l_0_8 = 16.5
l_0_7 = 8
l_0_8 = 10.5
l_0_7 = 9
l_0_8 = 12.4375
l_0_7 = 5
l_0_8 = 7.375
l_0_7 = 10
l_0_8 = 15.5
l_0_7 = 3
l_0_8 = 13.5
l_0_7 = 6
l_0_8 = 7.5
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "���ױ���(��ͨ)"
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 2
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = 16854
l_0_5 = true
l_0_5 = 9
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, bIsVisible = l_0_5, szMapName = "������", nEventAlertTime = l_0_5}
l_0_3 = 22
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = "dwLinkNpcTID"
l_0_6 = 17328
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = "bBossIntensity"
l_0_6 = true
l_0_5 = "tTimerSet"
l_0_7 = 1
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 25}
l_0_7 = 2
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 40}
l_0_7 = 4
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 81}
l_0_7 = 8
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 180}
l_0_7 = 16
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 350}
l_0_7 = 17
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 371}
l_0_7 = 9
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 195}
l_0_7 = 18
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 391}
l_0_7 = 5
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 102}
l_0_7 = 10
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 216}
l_0_7 = 20
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 424}
l_0_7 = 21
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 433}
l_0_7 = 11
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ��", [l_0_9] = 236}
l_0_7 = 3
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 61}
l_0_7 = 6
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 114}
l_0_7 = 12
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 257}
l_0_7 = 13
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 269}
l_0_7 = 7
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 123}
l_0_7 = 14
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "���ص���", [l_0_9] = 278}
l_0_7 = 19
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "ɨ�����", [l_0_9] = 412}
l_0_7 = 15
l_0_9 = "szTimerName"
l_0_9 = "nTime"
l_0_8 = {[l_0_9] = "��ӿ", [l_0_9] = 335}
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ������֮����"
l_0_5 = true
l_0_5 = "szTimerSet"
l_0_6 = "25,��ӿ;40,ɨ��;61,ɨ�����;81,ɨ��;102,ɨ�����;114,��ӿ;123,���ص���;180,��ӿ;195,ɨ��;216,ɨ�����;236,ɨ��;257,ɨ�����;269,��ӿ;278,���ص���;335,��ӿ;350,ɨ��;371,ɨ�����;391,ɨ��;412,ɨ�����;424,��ӿ;433,���ص���"
l_0_5 = 1
l_0_5 = 17328
l_0_5 = "��֮����"
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = 600
l_0_5 = "bEnemy"
l_0_6 = false
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, bChatAlertT = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 26
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 333
l_0_7 = 1
l_0_8 = 18
l_0_7 = 2
l_0_8 = 9
l_0_7 = 4
l_0_8 = 56.5
l_0_7 = 8
l_0_8 = 21.5
l_0_7 = 9
l_0_8 = 27.375
l_0_7 = 5
l_0_8 = 21.9375
l_0_7 = 10
l_0_8 = 14.125
l_0_7 = 3
l_0_8 = 7.5
l_0_7 = 6
l_0_8 = 38.0625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 17375
l_0_5 = 219713.8125
l_0_5 = "fMinTime"
l_0_6 = 5.4375
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = "�����ʬ"
l_0_5 = 219696.8125
l_0_5 = true
l_0_5 = 17
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, fEventTimeStart = l_0_5, bIsVisible = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 30
l_0_5 = "bNpcLeaveScrutiny"
l_0_6 = true
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "bNpcAllLeave"
l_0_6 = true
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 14894
l_0_5 = 120468
l_0_5 = "fMinTime"
l_0_6 = 36.9375
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 38.8125
l_0_7 = 1
l_0_8 = 36.9375
l_0_7 = 2
l_0_8 = 37.5
l_0_7 = 4
l_0_8 = 40.5
l_0_7 = 8
l_0_8 = 37.5625
l_0_7 = 9
l_0_8 = 310.75
l_0_7 = 5
l_0_8 = 37.0625
l_0_7 = 10
l_0_8 = 37.375
l_0_7 = 3
l_0_8 = 38.125
l_0_7 = 6
l_0_8 = 37.0625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "���ƻ�ת��"
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = 120431
l_0_5 = 37
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, [l_0_5] = l_0_6, fEventTimeStart = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 36
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 49.625
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 52.4375
l_0_7 = 1
l_0_8 = 57.375
l_0_7 = 2
l_0_8 = 52.4375
l_0_7 = 4
l_0_8 = 52.4375
l_0_7 = 8
l_0_8 = 52.5
l_0_7 = 9
l_0_8 = 52.5
l_0_7 = 5
l_0_8 = 49.625
l_0_7 = 10
l_0_8 = 52.5
l_0_7 = 3
l_0_8 = 52.5
l_0_7 = 6
l_0_8 = 52.5
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = 52
l_0_5 = false
l_0_5 = 14968
l_0_5 = 2
l_0_5 = "����Ѫ��"
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, tRGAutoSelect = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 44
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 5.875
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 11.125
l_0_7 = 1
l_0_8 = 16.6875
l_0_7 = 2
l_0_8 = 15.625
l_0_7 = 4
l_0_8 = 18.25
l_0_7 = 8
l_0_8 = 15.5
l_0_7 = 9
l_0_8 = 20
l_0_7 = 5
l_0_8 = 15.5625
l_0_7 = 10
l_0_8 = 20.0625
l_0_7 = 3
l_0_8 = 6
l_0_7 = 6
l_0_8 = 13
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = 2
l_0_5 = "ά��ʹ����췣��"
l_0_5 = 14897
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = 15
l_0_4 = {tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 52
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 6.25
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 47.125
l_0_7 = 1
l_0_8 = 47.5
l_0_7 = 2
l_0_8 = 48.9375
l_0_7 = 4
l_0_8 = 47.5
l_0_7 = 8
l_0_8 = 47.5625
l_0_7 = 9
l_0_8 = 14.8125
l_0_7 = 5
l_0_8 = 47.25
l_0_7 = 10
l_0_8 = 8.9375
l_0_7 = 3
l_0_8 = 49.0625
l_0_7 = 6
l_0_8 = 47.6875
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bAddToSkillTimer"
l_0_6 = false
l_0_5 = 13477
l_0_5 = "pt25��������"
l_0_5 = 2
l_0_5 = "bNotAddToScrutiny"
l_0_6 = false
l_0_5 = 47
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, szName = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 46
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 6.5
l_0_5 = "dwLinkNpcTID"
l_0_6 = 14889
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 60
l_0_7 = 1
l_0_8 = 13.3125
l_0_7 = 2
l_0_8 = 60.0625
l_0_7 = 4
l_0_8 = 60.1875
l_0_7 = 8
l_0_8 = 60.1875
l_0_7 = 9
l_0_8 = 61.0625
l_0_7 = 5
l_0_8 = 60.0625
l_0_7 = 10
l_0_8 = 60.0625
l_0_7 = 3
l_0_8 = 59.9375
l_0_7 = 6
l_0_8 = 60
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = 2
l_0_5 = "nIconFrame"
l_0_6 = 54
l_0_5 = true
l_0_5 = 14969
l_0_5 = "ʬ��"
l_0_5 = 60
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "�ﰢ����"
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, dwID = l_0_5, szName = l_0_5, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = "Hash2"
l_0_4 = {}
l_0_3 = 39
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 14.9375
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 15.25
l_0_7 = 1
l_0_8 = 16.5625
l_0_7 = 2
l_0_8 = 15.1875
l_0_7 = 4
l_0_8 = 17.0625
l_0_7 = 8
l_0_8 = 16.5625
l_0_7 = 9
l_0_8 = 16.6875
l_0_7 = 5
l_0_8 = 16.5
l_0_7 = 10
l_0_8 = 16.6875
l_0_7 = 3
l_0_8 = 19.9375
l_0_7 = 6
l_0_8 = 16.5625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = 16
l_0_5 = 13968
l_0_5 = "������"
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 43
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 35.5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 36
l_0_7 = 1
l_0_8 = 36
l_0_7 = 2
l_0_8 = 35.9375
l_0_7 = 4
l_0_8 = 36
l_0_7 = 8
l_0_8 = 36
l_0_7 = 9
l_0_8 = 35.5
l_0_7 = 5
l_0_8 = 35.75
l_0_7 = 10
l_0_8 = 35.9375
l_0_7 = 3
l_0_8 = 36
l_0_7 = 6
l_0_8 = 36.0625
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = 14941
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "��Ȧ"
l_0_5 = 36
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 31
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 28
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 28.8125
l_0_7 = 1
l_0_8 = 28.75
l_0_7 = 2
l_0_8 = 28.9375
l_0_7 = 4
l_0_8 = 28.75
l_0_7 = 8
l_0_8 = 28.8125
l_0_7 = 9
l_0_8 = 28.6875
l_0_7 = 5
l_0_8 = 28.75
l_0_7 = 10
l_0_8 = 28.9375
l_0_7 = 3
l_0_8 = 28.8125
l_0_7 = 6
l_0_8 = 28.9375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 28
l_0_5 = "nIconFrame"
l_0_6 = 54
l_0_5 = true
l_0_5 = 2
l_0_5 = "���������"
l_0_5 = 16151
l_0_5 = false
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, dwID = l_0_5, tRGAutoSelect = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 37
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = 1200
l_0_5 = "bNormalCountdownType"
l_0_6 = true
l_0_5 = 13548
l_0_5 = 2
l_0_5 = "׿����"
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = "bNotAppearScrutiny"
l_0_6 = true
l_0_5 = "dwLinkNpcTID"
l_0_6 = 13548
l_0_5 = "bLinkNpcFightState"
l_0_6 = true
l_0_5 = "szLinkNpcName"
l_0_6 = "����ʱ����׿����"
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, nEventAlertTime = l_0_5, [l_0_5] = l_0_6, dwID = l_0_5, nAutoEventTimeMode = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_3 = 45
l_0_5 = 226903.9375
l_0_5 = "fMinTime"
l_0_6 = 54.875
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 55
l_0_7 = 1
l_0_8 = 55
l_0_7 = 2
l_0_8 = 55
l_0_7 = 4
l_0_8 = 55
l_0_7 = 8
l_0_8 = 55
l_0_7 = 9
l_0_8 = 55
l_0_7 = 5
l_0_8 = 557.5625
l_0_7 = 10
l_0_8 = 55
l_0_7 = 3
l_0_8 = 642.625
l_0_7 = 6
l_0_8 = 55
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = 226848.9375
l_0_5 = "����˾"
l_0_5 = 15188
l_0_5 = 2
l_0_5 = 55
l_0_4 = {fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, fEventTimeStart = l_0_5, szName = l_0_5, dwID = l_0_5, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 53
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 59.9375
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 60
l_0_7 = 1
l_0_8 = 60
l_0_7 = 2
l_0_8 = 59.9375
l_0_7 = 4
l_0_8 = 60.0625
l_0_7 = 8
l_0_8 = 60
l_0_7 = 9
l_0_8 = 59.9375
l_0_7 = 5
l_0_8 = 60
l_0_7 = 10
l_0_8 = 60
l_0_7 = 3
l_0_8 = 60.0625
l_0_7 = 6
l_0_8 = 60
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = true
l_0_5 = 2
l_0_5 = 10411
l_0_5 = 60
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, bChatAlertT = l_0_5, szName = "ĵ��", nAutoEventTimeMode = l_0_5, dwID = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 1
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "ݶ������"
l_0_5 = "bAddToSkillTimer"
l_0_6 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 30.625
l_0_7 = 1
l_0_8 = 30.75
l_0_7 = 2
l_0_8 = 30.75
l_0_7 = 4
l_0_8 = 30.75
l_0_7 = 8
l_0_8 = 30.875
l_0_7 = 9
l_0_8 = 30.75
l_0_7 = 5
l_0_8 = 27.25
l_0_7 = 10
l_0_8 = 30.6875
l_0_7 = 3
l_0_8 = 30.75
l_0_7 = 6
l_0_8 = 31
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 67
l_0_5 = 15662
l_0_5 = 114040.125
l_0_5 = "fMinTime"
l_0_6 = 20.5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = "bEnemy"
l_0_6 = true
l_0_5 = "�������"
l_0_5 = "nEventCountdownTime"
l_0_6 = 5
l_0_5 = 114010.125
l_0_5 = 30
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, szName = l_0_5, [l_0_5] = l_0_6, fEventTimeStart = l_0_5, nEventAlertTime = l_0_5}
l_0_3 = 19
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 11.25
l_0_7 = 1
l_0_8 = 13
l_0_7 = 2
l_0_8 = 11.125
l_0_7 = 4
l_0_8 = 13.25
l_0_7 = 8
l_0_8 = 15.1875
l_0_7 = 9
l_0_8 = 11.25
l_0_7 = 5
l_0_8 = 15.3125
l_0_7 = 10
l_0_8 = 15.3125
l_0_7 = 3
l_0_8 = 12.25
l_0_7 = 6
l_0_8 = 12.1875
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "nIconFrame"
l_0_6 = 57
l_0_5 = 16533
l_0_5 = false
l_0_5 = "fMinTime"
l_0_6 = 11.125
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "Npc"
l_0_5 = true
l_0_5 = 2
l_0_5 = 12
l_0_5 = "���ص���(��ͨ)"
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = true
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, szMapName = "������", bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, dwID = l_0_5, tRGAutoSelect = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szType = l_0_5, tRGCenterAlarm = l_0_5, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, [l_0_5] = l_0_6}
l_0_3 = 23
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "Ӣ��������"
l_0_5 = true
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 272
l_0_7 = 1
l_0_8 = 10
l_0_7 = 2
l_0_8 = 14.4375
l_0_7 = 4
l_0_8 = 9.5625
l_0_7 = 8
l_0_8 = 60.5625
l_0_7 = 9
l_0_8 = 41.0625
l_0_7 = 5
l_0_8 = 20
l_0_7 = 10
l_0_8 = 27
l_0_7 = 3
l_0_8 = 45.5625
l_0_7 = 6
l_0_8 = 73.9375
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = "bAutoTeamMarkAll"
l_0_6 = true
l_0_5 = 219715.8125
l_0_5 = 17371
l_0_5 = 1
l_0_5 = 219738.8125
l_0_5 = "fMinTime"
l_0_6 = 5
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "bEnemy"
l_0_6 = false
l_0_5 = true
l_0_5 = "bNotAddToScrutiny"
l_0_6 = true
l_0_5 = 2
l_0_5 = "fLastMarkCountTime"
l_0_6 = 219691.375
l_0_5 = "nMarkCount"
l_0_6 = 3
l_0_5 = "���붾ʦ"
l_0_5 = "nEventCountdownTime"
l_0_6 = 0
l_0_5 = "nIconFrame"
l_0_6 = 47
l_0_5 = 23
l_0_4 = {[l_0_5] = l_0_6, szMapName = l_0_5, bChatAlertT = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, fEventTimeStart = l_0_5, dwID = l_0_5, tAutoTeamMark = l_0_5, fEventTimeEnd = l_0_5, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, tRGCenterAlarm = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6, nEventAlertTime = l_0_5}
l_0_3 = 47
l_0_5 = "szIconPath"
l_0_6 = "ui/Image/TargetPanel/Target.UITex"
l_0_5 = "fMinTime"
l_0_6 = 11.0625
l_0_5 = true
l_0_5 = "Npc"
l_0_5 = "tEventTimeCache"
l_0_7 = 7
l_0_8 = 15.6875
l_0_7 = 1
l_0_8 = 15.5625
l_0_7 = 2
l_0_8 = 11.1875
l_0_7 = 4
l_0_8 = 15.6875
l_0_7 = 8
l_0_8 = 13
l_0_7 = 9
l_0_8 = 11.1875
l_0_7 = 5
l_0_8 = 20
l_0_7 = 10
l_0_8 = 15.625
l_0_7 = 3
l_0_8 = 11.0625
l_0_7 = 6
l_0_8 = 18.125
l_0_6 = {[l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8, [l_0_7] = l_0_8}
l_0_5 = 2
l_0_5 = 15
l_0_5 = 13475
l_0_5 = "ά��ʹ����췣��"
l_0_5 = "nIconFrame"
l_0_6 = 52
l_0_5 = "bEnemy"
l_0_6 = true
l_0_4 = {[l_0_5] = l_0_6, [l_0_5] = l_0_6, bIsVisible = l_0_5, szType = l_0_5, [l_0_5] = l_0_6, nAutoEventTimeMode = l_0_5, nEventAlertTime = l_0_5, dwID = l_0_5, szName = l_0_5, [l_0_5] = l_0_6, [l_0_5] = l_0_6}
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4, [l_0_3] = l_0_4}
RGES_Settings = l_0_0

