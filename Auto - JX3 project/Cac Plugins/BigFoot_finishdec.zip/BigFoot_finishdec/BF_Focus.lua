-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Focus.lua 

if not BF_Focus then
  BF_Focus = {}
end
local l_0_0 = BF_Focus
local l_0_1 = {}
l_0_1.s = "LEFT"
l_0_1.r = "LEFT"
l_0_1.x = 1240
l_0_1.y = 200
l_0_0.Anchor = l_0_1
l_0_0 = BF_Focus
l_0_0.tFocusID, l_0_1 = l_0_1, {}
l_0_0 = BF_Focus
l_0_0.tDelete, l_0_1 = l_0_1, {}
l_0_0 = BF_Focus
l_0_0.bArena = false
l_0_0 = BF_Focus
l_0_0.nMaxCount = 0
l_0_1 = "��ɽ�����"
l_0_1 = RegisterCustomData
l_0_1("BF_Focus.Anchor")
l_0_1 = BF_Focus
l_0_1.OnFrameCreate = function()
  local l_1_0 = this:Lookup("", "")
  l_1_0:Lookup("Handle_List"):Clear()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
end

l_0_1 = BF_Focus
l_0_1.OnEvent = function(l_2_0)
  if l_2_0 == "UI_SCALED" or l_2_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    BF_Focus.UpdateAnchor(this)
  elseif l_2_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_2_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "��Ŷཹ��Ŀ���б�")
  end
end

l_0_1 = BF_Focus
l_0_1.OnFrameDragEnd = function()
  this:CorrectPos()
  BF_Focus.Anchor = GetFrameAnchor(this)
end

l_0_1 = BF_Focus
l_0_1.UpdateAnchor = function(l_4_0)
  local l_4_1 = BF_Focus.Anchor
  l_4_0:SetPoint(l_4_1.s, 0, 0, l_4_1.r, l_4_1.x, l_4_1.y)
  l_4_0:CorrectPos()
end

l_0_1 = BF_Focus
l_0_1.OnFrameBreathe = function()
  if not BF_Focus.bEnable then
    return 
  end
  local l_5_0 = Station.Lookup("Normal/BF_Focus")
  local l_5_1 = l_5_0:Lookup("", "Handle_List")
  local l_5_2 = GetClientPlayer()
  if not l_5_2 then
    return 
  end
  if not IsTableEmpty(BF_Focus.tDelete) then
    for l_5_6,l_5_7 in pairs(BF_Focus.tDelete) do
      local l_5_8 = l_5_1:Lookup(tostring(l_5_6))
      if l_5_8 then
        l_5_1:RemoveItem(tostring(l_5_6))
      end
    end
  end
  for l_5_12,l_5_13 in pairs(BF_Focus.tFocusID) do
    local l_5_14 = BF_Focus.GetTargetHandle(l_5_12)
    if l_5_14 then
      local l_5_15 = l_5_14.nCurrentLife / l_5_14.nMaxLife
      local l_5_16 = l_5_14.nCurrentMana / l_5_14.nMaxMana
      local l_5_17 = l_5_14.szName
      if math.ceil(GetCharacterDistance(l_5_2.dwID, l_5_14.dwID) / 64) > 50 then
        local l_5_18, l_5_19, l_5_22, l_5_24, l_5_28, l_5_33, l_5_35 = "??"
      end
      if not l_5_1:Lookup(tostring(l_5_14.dwID)) then
        local l_5_20, l_5_23, l_5_25, l_5_29, l_5_34, l_5_36 = , l_5_1:AppendItemFromIni("Interface/BF_Focus/BF_Focus.ini", "Handle_Item", l_5_14.dwID)
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_5_23.dwID = l_5_14.dwID
      if IsPlayer(l_5_12) then
        if not l_5_14.GetKungfuMount() then
          local l_5_21, l_5_26 = nil
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        if {} then
          local l_5_27 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_5_26:Lookup("Image_School"):FromIconID(Table_GetSkillIconID(({}).dwSkillID, 0))
        end
      else
        local l_5_30 = nil
        local l_5_31 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        local l_5_32 = nil
        if NPC_GetProtrait(GetNpc(l_5_12).dwModelID) and IsFileExist(NPC_GetProtrait(GetNpc(l_5_12).dwModelID)) then
          do return end
        end
        szPath = NPC_GetHeadImageFile(GetNpc(l_5_12).dwModelID)
        if IsFileExist(szPath) then
          l_5_31:Lookup("Image_School"):FromTextureFile(szPath)
        end
      else
        szPath = GetNpcHeadImage(l_5_12)
        l_5_31:Lookup("Image_School"):FromUITex(szPath, nFrame)
      end
      local l_5_37, l_5_38 = nil
      if NPC_GetProtrait(GetNpc(l_5_12).dwModelID) == l_5_14.dwID then
        l_5_38:Lookup("Animate_Effect"):Show()
      else
        l_5_38:Lookup("Animate_Effect"):Hide()
      end
      l_5_38:Lookup("Image_Life"):SetPercentage(l_5_15)
      l_5_38:Lookup("Image_Mana"):SetPercentage(l_5_16)
      local l_5_39 = l_5_2.GetTarget()
      l_5_38:Lookup("Text_Name"):SetText(l_5_17 .. "(" .. l_5_37 .. ")")
      local l_5_40 = nil
      l_5_38:Lookup("Text_Life"):SetText(math.ceil(l_5_15 * 100) .. "%")
      local l_5_41 = nil
      l_5_0:SetSize(250, 50 * l_5_1:GetItemCount())
      l_5_38:FormatAllItemPos()
    end
  end
  l_5_1:FormatAllItemPos()
end

l_0_1 = BF_Focus
l_0_1.OnItemLButtonClick = function()
  local l_6_0 = this:GetName()
  local l_6_1 = tonumber(l_6_0)
  if l_6_1 ~= 0 then
    if IsPlayer(l_6_1) then
      SetTarget(TARGET.PLAYER, l_6_1)
    end
  else
    SetTarget(TARGET.NPC, l_6_1)
  end
end

l_0_1 = BF_Focus
l_0_1.OnItemRButtonClick = function()
  local l_7_0 = this:GetName()
  local l_7_1 = tonumber(l_7_0)
  if l_7_1 ~= 0 then
    local l_7_2 = {}
    local l_7_3 = {}
    l_7_3.szOption = "�������"
    l_7_3.fnAction = function()
      -- upvalues: l_7_1
      BF_Focus.RemoveFocus(l_7_1)
    end
    local l_7_4 = {}
    l_7_4.szOption = "�鿴װ��"
    l_7_4.fnAction = function()
      -- upvalues: l_7_1
      ViewInviteToPlayer(l_7_1)
    end
    local l_7_5 = {}
    l_7_5.szOption = "�鿴����"
    l_7_5.fnAction = function()
      -- upvalues: l_7_1
      ViewOtherPlayerChannels(l_7_1)
    end
    local l_7_6 = {}
    l_7_6.szOption = "�鿴����"
    l_7_6.fnAction = function()
      -- upvalues: l_7_1
      ViewOtherZhenPaiSkill(l_7_1)
    end
    local l_7_7 = {}
    l_7_7.szOption = "�鿴������"
    l_7_7.fnAction = function()
      -- upvalues: l_7_1
      OpenArenaCorpsPanel(false, l_7_1)
    end
    table.insert(l_7_2, l_7_3)
  end
  if l_7_2 and #l_7_2 > 0 then
    PopupMenu(l_7_2)
  end
end

l_0_1 = BF_Focus
l_0_1.GetTargetHandle = function(l_8_0)
  local l_8_1 = nil
  if IsPlayer(l_8_0) then
    l_8_1 = GetPlayer(l_8_0)
  else
    l_8_1 = GetNpc(l_8_0)
  end
  return l_8_1
end

l_0_1 = BF_Focus
l_0_1.SetFocus = function()
  local l_9_0 = GetClientPlayer()
  if not l_9_0 then
    return 
  end
  local l_9_1, l_9_2 = l_9_0.GetTarget()
  local l_9_3 = BF_Focus.GetTargetHandle(l_9_2)
  if not l_9_3 then
    return 
  end
  BF_Focus.AppendFocus(l_9_2)
  BigFoot_Print("����Ŀ��", "�ѽ� [" .. l_9_3.szName .. "] ��Ϊ����")
end

l_0_1 = BF_Focus
l_0_1.AppendFocus = function(l_10_0)
  BF_Focus.nMaxCount = 0
  for l_10_4,l_10_5 in pairs(BF_Focus.tFocusID) do
    BF_Focus.nMaxCount = BF_Focus.nMaxCount + 1
  end
  if BF_Focus.nMaxCount > 4 then
    return 
  end
  if not BF_Focus.tFocusID[l_10_0] then
    if BF_Focus.tDelete[l_10_0] then
      BF_Focus.tDelete[l_10_0] = nil
    end
    BF_Focus.tFocusID[l_10_0] = l_10_0
  end
end

l_0_1 = BF_Focus
l_0_1.RemoveFocus = function(l_11_0)
  if BF_Focus.tFocusID[l_11_0] then
    BF_Focus.tFocusID[l_11_0] = nil
    BF_Focus.tDelete[l_11_0] = l_11_0
    local l_11_1 = BF_Focus.GetTargetHandle(l_11_0)
  end
  if l_11_1 then
    BigFoot_Print("����Ŀ��", "�ѽ������ [" .. l_11_1.szName .. "]")
  end
end

l_0_1 = 1
BF_Focus.SwitchFocus = function()
  -- upvalues: l_0_1
  local l_12_0 = Station.Lookup("Normal/BF_Focus")
  local l_12_1 = l_12_0:Lookup("", "Handle_List")
  local l_12_2 = l_12_1:GetItemCount()
  if l_12_2 < l_0_1 then
    l_0_1 = 1
  end
  local l_12_3 = l_12_1:Lookup(l_0_1 - 1)
  local l_12_4 = BF_Focus.GetTargetHandle(l_12_3.dwID)
  if l_12_4 then
    if IsPlayer(l_12_3.dwID) then
      SetTarget(TARGET.PLAYER, l_12_3.dwID)
    end
  else
    SetTarget(TARGET.NPC, l_12_3.dwID)
  end
  l_0_1 = l_0_1 + 1
end

BF_Focus.SwitchPanel = function(l_13_0)
  local l_13_1 = Station.Lookup("Normal/BF_Focus")
  if l_13_1 then
    if l_13_0 then
      l_13_1:Show()
    end
  else
    l_13_1:Hide()
  end
end

local l_0_2 = {}
l_0_2.szOption = "���ý���"
l_0_2.fnAction = function()
  BF_Focus.SetFocus()
end

BigFoot_TargetAppendAddonMenu(l_0_2)
Wnd.OpenWindow("Interface\\BF_Focus\\BF_Focus.ini", "BF_Focus")
Hotkey.AddBinding("BF_Focus.SetFocus", "���ý���", "����Ŀ��", BF_Focus.SetFocus, nil)
Hotkey.AddBinding("BF_Focus.SwitchFocus", "�����л�����", "", BF_Focus.SwitchFocus, nil)
BFConfigPanel.RegisterMod("Focus", "����Ŀ��", "\\ui\\image\\icon\\ty_wudu_07.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
BFConfigPanel.RegisterCheckButton("Focus", "bEnable", "���ý���Ŀ�꣨�������԰棩", false, function(l_15_0)
  BF_Focus.bEnable = l_15_0
  BF_Focus.SwitchPanel(l_15_0)
end
)

