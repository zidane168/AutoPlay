-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: button.lua 

BFButton = classv2(BFWidget)
BFButton.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  l_1_0:SetText(l_1_4)
end

BFButton.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = assert
  l_2_3(l_2_1 >= 0 and l_2_2 >= 0, "Invalid widget size.")
  l_2_3 = Wnd
  l_2_3 = l_2_3.OpenWindow
  l_2_3 = l_2_3("Interface\\BF_Base\\widget\\button.ini", l_2_0:GetName())
  local l_2_6 = l_2_3:Lookup("Wnd_Main")
  l_2_0:SetContainer(l_2_6)
  local l_2_7 = l_2_6:Lookup("Btn_Main")
  local l_2_8 = l_2_7:Lookup("", "")
  local l_2_9 = l_2_8:Lookup("Text_Btn_Text")
  local l_2_10 = l_2_8:Lookup("Image_Btn_Image")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.container = l_2_6
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button = l_2_7
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text = l_2_9
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image = l_2_10
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_8
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl = l_2_8:Lookup("Image_TL")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc = l_2_8:Lookup("Image_TC")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr = l_2_8:Lookup("Image_TR")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl = l_2_8:Lookup("Image_CL")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc = l_2_8:Lookup("Image_CC")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr = l_2_8:Lookup("Image_CR")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl = l_2_8:Lookup("Image_BL")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc = l_2_8:Lookup("Image_BC")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br = l_2_8:Lookup("Image_BR")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 0)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 1)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 2)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 3)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 4)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 5)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 6)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 7)
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:FromUITex("Interface\\BF_Base\\widget\\artwork\\button\\button.uitex", 8)
  l_2_7.widget = l_2_0
  l_2_7.OnMouseEnter = function()
    this.widget.OnMouseEnter(this.widget)
    this.widget:_FireEvent("OnMouseEnter")
  end
  l_2_7.OnMouseLeave = function()
    this.widget.OnMouseLeave(this.widget)
    this.widget:_FireEvent("OnMouseLeave")
  end
  l_2_7.OnLButtonDown = function()
    this.widget.OnLButtonDown(this.widget)
    this.widget:_FireEvent("OnMouseDown", "LeftButton")
  end
  l_2_7.OnLButtonUp = function()
    this.widget.OnLButtonUp(this.widget)
    this.widget:_FireEvent("OnMouseUp", "LeftButton")
  end
  l_2_7.OnLButtonClick = function()
    this.widget:_FireEvent("OnClick", "LeftButton")
  end
  l_2_7.OnRButtonDown = function()
    this.widget:_FireEvent("OnMouseDown", "RightButton")
  end
  l_2_7.OnRButtonUp = function()
    this.widget:_FireEvent("OnMouseUp", "RightButton")
  end
  l_2_7.OnRButtonClick = function()
    this.widget:_FireEvent("OnClick", "RightButton")
  end
  l_2_7.OnKillFocus = function()
    this.widget:_FireEvent("OnKillFocus")
  end
  l_2_0:SetSize(l_2_1, l_2_2)
  l_2_0:SetStyle("NORMAL", true)
end

BFButton.SetStyle = function(l_3_0, l_3_1, l_3_2)
  if l_3_1 == "NORMAL" then
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:Show()
  elseif l_3_1 == "TRANSPARENT" then
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:Hide()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:Hide()
  elseif l_3_1 == "TOGGLE" then
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:Show()
    l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:Show()
  else
    assert(false, "Unknown style.")
  end
  l_3_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e = l_3_1
  if not l_3_2 then
    l_3_0:Update()
  end
end

BFButton.SetNormalImage = function(l_4_0, l_4_1, l_4_2)
  local l_4_3 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_4_3 == "string" then
    if l_4_3 then
      l_4_3(l_4_3, l_4_2[1], l_4_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[2])
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_4_3(l_4_3, l_4_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
    end
   -- DECOMPILER ERROR: Overwrote pending register.

  else
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_4_3 then
    l_4_3(l_4_3, l_4_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
  end
end

BFButton.SetHotImage = function(l_5_0, l_5_1, l_5_2)
  do
    local l_5_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BFButton.SetPressedImage = function(l_6_0, l_6_1, l_6_2)
  do
    local l_6_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BFButton.SetDisabledImage = function(l_7_0, l_7_1, l_7_2)
  do
    local l_7_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BFButton.Enable = function(l_8_0)
  l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(true)
  l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(255, 255, 255)
  l_8_0._toggle = nil
  if l_8_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(0)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(1)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(2)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(3)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(4)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(5)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(6)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(7)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(8)
  elseif l_8_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
    if l_8_0:GetToggle() then
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(255, 224, 0)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(18)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(19)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(20)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(21)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(22)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(23)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(24)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(25)
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(26)
    end
  else
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(255, 255, 255)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(0)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(1)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(2)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(3)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(4)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(5)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(6)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(7)
    l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(8)
  end
  if l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c then
    if type(l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1]) == "string" then
      if l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[2] then
        l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1], l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[2])
      end
    else
      l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
    end
  else
    local l_8_1 = type
    l_8_1 = l_8_1(l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1] == "number")
  end
  if l_8_1 then
    l_8_1 = l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_8_1 = l_8_1.image
    l_8_1(l_8_1, l_8_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
  end
end

BFButton.Disable = function(l_9_0)
  l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(false)
  l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(224, 224, 224)
  if l_9_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" or l_9_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(27)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(28)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(29)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(30)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(31)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(32)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(33)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(34)
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(35)
  end
  if l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f then
    if type(l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[1]) == "string" then
      if l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[2] then
        l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[1], l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[2])
      end
    else
      l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[1])
    end
  else
    local l_9_1 = type
    l_9_1 = l_9_1(l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[1] == "number")
  end
  if l_9_1 then
    l_9_1 = l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_9_1 = l_9_1.image
    l_9_1(l_9_1, l_9_0.BigFoot_601f120489a69b480aad90a42b85c17f[1])
  end
end

BFButton.IsEnabled = function(l_10_0)
  local l_10_1, l_10_2 = l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:IsEnabled, l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button
  return l_10_1(l_10_2)
end

BFButton.SetText = function(l_11_0, l_11_1)
  local l_11_2, l_11_3 = l_11_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetText, l_11_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text
  local l_11_4 = nil
  if not l_11_1 then
    l_11_4 = ""
  end
  l_11_2(l_11_3, l_11_4)
end

BFButton.GetText = function(l_12_0)
  local l_12_1, l_12_2 = l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:GetText, l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text
  return l_12_1(l_12_2)
end

BFButton.SetTextVAlign = function(l_13_0, l_13_1)
  if l_13_1 == "TOP" then
    l_13_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetVAlign(0)
  elseif l_13_1 == "CENTER" then
    l_13_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetVAlign(1)
  elseif l_13_1 == "BOTTOM" then
    l_13_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetVAlign(2)
  end
end

BFButton.SetTextHAlign = function(l_14_0, l_14_1)
  if l_14_1 == "LEFT" then
    l_14_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetHAlign(0)
  elseif l_14_1 == "CENTER" then
    l_14_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetHAlign(1)
  elseif l_14_1 == "RIGHT" then
    l_14_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetHAlign(2)
  end
end

BFButton._UpdateContent = function(l_15_0)
  local l_15_1 = l_15_0:GetWidth()
  local l_15_2 = l_15_0:GetHeight()
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetSize(l_15_1, l_15_2)
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetSize(l_15_1, l_15_2)
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:SetSize(l_15_1, l_15_2)
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSize(l_15_1, l_15_2)
  if l_15_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
    local l_15_3 = 5
    local l_15_4 = 10
    local l_15_5 = 15
    local l_15_6 = 7
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetSize(l_15_3, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetRelPos(0, 0)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetSize(l_15_1 - l_15_3 - l_15_4, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetRelPos(l_15_3, 0)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetSize(l_15_4, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetRelPos(l_15_1 - l_15_4, 0)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetSize(l_15_3, l_15_2 - l_15_5 - l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetRelPos(0, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetSize(l_15_1 - l_15_3 - l_15_4, l_15_2 - l_15_5 - l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetRelPos(l_15_3, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetSize(l_15_4, l_15_2 - l_15_5 - l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetRelPos(l_15_1 - l_15_4, l_15_5)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetSize(l_15_3, l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetRelPos(0, l_15_2 - l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetSize(l_15_1 - l_15_3 - l_15_4, l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetRelPos(l_15_3, l_15_2 - l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetSize(l_15_4, l_15_6)
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetRelPos(l_15_1 - l_15_4, l_15_2 - l_15_6)
  end
  if l_15_0.BigFoot_fd33bb5f31231467b05be1be5b75416c then
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:Show()
  else
    l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:Hide()
  end
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:FormatAllItemPos()
  l_15_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSizeByAllItemSize()
end

BFButton.OnLButtonDown = function(l_16_0)
  if l_16_0:IsEnabled() then
    if l_16_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(18)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(19)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(20)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(21)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(22)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(23)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(24)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(25)
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(26)
    elseif l_16_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
      l_16_0:SetToggle(not l_16_0:GetToggle())
    end
  end
  if l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84 then
    if type(l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1]) == "string" then
      if l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[2] then
        l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1], l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[2])
      end
    else
      l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1])
    end
  else
    local l_16_1 = type
    l_16_1 = l_16_1(l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1] == "number")
  end
  if l_16_1 then
    l_16_1 = l_16_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_16_1 = l_16_1.image
    l_16_1(l_16_1, l_16_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1])
  end
end

BFButton.OnLButtonUp = function(l_17_0)
  if l_17_0:IsEnabled() then
    if l_17_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(9)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(10)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(11)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(12)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(13)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(14)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(15)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(16)
      l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(17)
  if l_17_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
    end
    if l_17_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
      if type(l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1]) == "string" then
        if l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2] then
          l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1], l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2])
        end
      else
        l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
      end
    else
      local l_17_1 = type
      l_17_1 = l_17_1(l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1] == "number")
    end
    if l_17_1 then
      l_17_1 = l_17_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
      l_17_1 = l_17_1.image
      l_17_1(l_17_1, l_17_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 57 
end

BFButton.OnMouseEnter = function(l_18_0)
  if l_18_0:IsEnabled() then
    if l_18_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(9)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(10)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(11)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(12)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(13)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(14)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(15)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(16)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(17)
    elseif l_18_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
      if l_18_0._toggle then
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(0)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(1)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(2)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(3)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(4)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(5)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(6)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(7)
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(8)
      end
    else
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(9)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(10)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(11)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(12)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(13)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(14)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(15)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(16)
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(17)
    end
  end
  if l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e then
    if type(l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1]) == "string" then
      if l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2] then
        l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1], l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2])
      end
    else
      l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
    end
  else
    local l_18_1 = type
    l_18_1 = l_18_1(l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1] == "number")
  end
  if l_18_1 then
    l_18_1 = l_18_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_18_1 = l_18_1.image
    l_18_1(l_18_1, l_18_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
  end
end

BFButton.OnMouseLeave = function(l_19_0)
  if l_19_0:IsEnabled() then
    if l_19_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(0)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(1)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(2)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(3)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(4)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(5)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(6)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(7)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(8)
    elseif l_19_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE" then
      if l_19_0._toggle then
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(18)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(19)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(20)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(21)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(22)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(23)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(24)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(25)
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(26)
      end
    else
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(0)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(1)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(2)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(3)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(4)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(5)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(6)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(7)
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(8)
    end
  end
  if l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c then
    if type(l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1]) == "string" then
      if l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[2] then
        l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1], l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[2])
      end
    else
      l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
    end
  else
    local l_19_1 = type
    l_19_1 = l_19_1(l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1] == "number")
  end
  if l_19_1 then
    l_19_1 = l_19_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_19_1 = l_19_1.image
    l_19_1(l_19_1, l_19_0.BigFoot_fd33bb5f31231467b05be1be5b75416c[1])
  end
end

BFButton.OnRButtonDown = function(l_20_0)
  if l_20_0:IsEnabled() then
    if l_20_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(18)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(19)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(20)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(21)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(22)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(23)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(24)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(25)
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(26)
    end
  end
  if l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84 then
    if type(l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1]) == "string" then
      if l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[2] then
        l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1], l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[2])
      end
    else
      l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1])
    end
  else
    local l_20_1 = type
    l_20_1 = l_20_1(l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1] == "number")
  end
  if l_20_1 then
    l_20_1 = l_20_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_20_1 = l_20_1.image
    l_20_1(l_20_1, l_20_0.BigFoot_49f5b9edf1d9c15b29b3ebfddcb89f84[1])
  end
end

BFButton.OnRButtonUp = function(l_21_0)
  if l_21_0:IsEnabled() then
    if l_21_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "NORMAL" then
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tl:SetFrame(9)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tc:SetFrame(10)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.tr:SetFrame(11)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cl:SetFrame(12)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cc:SetFrame(13)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.cr:SetFrame(14)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bl:SetFrame(15)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.bc:SetFrame(16)
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.br:SetFrame(17)
    end
  end
  if l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e then
    if type(l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1]) == "string" then
      if l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2] then
        l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromUITex(l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1], l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[2])
      end
    else
      l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.image:FromTextureFile(l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
    end
  else
    local l_21_1 = type
    l_21_1 = l_21_1(l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1] == "number")
  end
  if l_21_1 then
    l_21_1 = l_21_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_21_1 = l_21_1.image
    l_21_1(l_21_1, l_21_0.BigFoot_e1df4a3c2f72a13ccf8f8a0cc901801e[1])
  end
end

BFButton.GetToggle = function(l_22_0)
  local l_22_1 = assert
  l_22_1(l_22_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE", "style must be toggle.")
  l_22_1 = l_22_0._toggle
  return l_22_1
end

BFButton.SetToggle = function(l_23_0, l_23_1)
  local l_23_2 = assert
  l_23_2(l_23_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "TOGGLE", "style must be toggle.")
  if l_23_1 then
    l_23_0._toggle = true
    l_23_2 = l_23_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
    l_23_2 = l_23_2.text
    l_23_2(l_23_2, 255, 224, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 18)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 19)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 20)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 21)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 22)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 23)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 24)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 25)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 26)
  else
    l_23_0._toggle = nil
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 255, 255, 255)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 1)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 2)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 3)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 4)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 5)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 6)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 7)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_23_2(l_23_2, 8)
  end
end

button_test = function()
  local l_24_0 = BFFrame.new(100, 28, "NONE")
  l_24_0:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", 300, 300)
  local l_24_1 = BFButton.new(l_24_0, 100, 28, "����")
  l_24_1:SetPoint("TOPLEFT", l_24_0, "TOPLEFT", 0, 0)
  l_24_1:Disable()
end


