-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ShowDetail.lua 

local l_0_0 = {}
l_0_0.DAMAGE = "�˺�ͳ��"
l_0_0.BEDAMAGE = "�ܵ��˺�ͳ��"
l_0_0.HEAL = "����ͳ��"
l_0_0.BEHEAL = "�ܵ�����ͳ��"
SHOW_DETAIL_MODE = l_0_0
BF_ShowDetail, l_0_0 = l_0_0, {nCurrentMode = SHOW_DETAIL_MODE.DAMAGE, szPlayeName = nil, nMaxDetailEntryCount = 8, nWidth = 400, FormsSize = 365, nSelectIndex = 0, Drag = false, 
DisplayDataList = {}}
l_0_0 = BF_ShowDetail
l_0_0.Init = function()
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147 = BFFrame.new(360, 342, "NONE")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", 500, 200)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.OnUpdate = function(l_2_0)
    BF_ShowDetail.Display()
  end
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5 = BFWindow.new(BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147, BF_ShowDetail.FormsSize, 342)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5:SetPoint("TOPLEFT", BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147, "TOPLEFT", 0, 0)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5:SetBorder("THIN")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_967863af413a628eac451157ad05e9f4 = BFProgressBar.new(BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5, BF_ShowDetail.FormsSize - 10, 15)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_967863af413a628eac451157ad05e9f4:SetPoint("TOPLEFT", BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5, "TOPLEFT", 5, 180)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_967863af413a628eac451157ad05e9f4:SetRange(0, 100)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_967863af413a628eac451157ad05e9f4:SetPos(100)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_ef507eee0f9a695e9726f2da89b8c55b = BFLabel.new(BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5, BF_ShowDetail.FormsSize - 10, 15)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_ef507eee0f9a695e9726f2da89b8c55b:SetPoint("TOPLEFT", BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5, "TOPLEFT", 5, 180)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_ef507eee0f9a695e9726f2da89b8c55b:SetText("���弼��ͳ������")
  local l_1_0 = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5:GetHandle()
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450 = l_1_0:AppendItemFromIni("Interface\\BF_CombatStat\\ShowDetail.ini", "Handle_OutputA")
  for l_1_4 = 1, 8 do
    for l_1_8 = 1, 4 do
      BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450:Lookup("Text_Entry_A" .. l_1_4 .. "_" .. l_1_8).OnItemLButtonClick = function()
        local l_3_0 = tonumber(string.match(this:GetName(), "%d+"))
        if not l_3_0 then
          return 
        end
        if #BF_ShowDetail.DisplayDataList < l_3_0 then
          return 
        end
        BF_ShowDetail.Select(l_3_0)
        BF_ShowDetail.Display()
      end
    end
  end
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_b3f6409be38add4404146a3579a8b36a = l_1_0:AppendItemFromIni("Interface\\BF_CombatStat\\ShowDetail.ini", "Handle_OutputB")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450:SetRelPos(8, 35)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_b3f6409be38add4404146a3579a8b36a:SetRelPos(5, 205)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824 = BFButton.new(BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147, BF_ShowDetail.FormsSize - 10, 40)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824:SetPoint("TOPLEFT", BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147, "TOPLEFT", 0, 0)
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824:SetStyle("TRANSPARENT")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824:SetText("�����ϸͳ������")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824.OnMouseDown = function(l_4_0)
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Drag = true
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:StartMoving()
  end
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824.OnMouseUp = function(l_5_0)
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:EndMoving()
  end
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
end

l_0_0 = BF_ShowDetail
l_0_0.OnFrameCreate = function()
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147 = Station.Lookup("Normal/BF_ShowDetail")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_Separator = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Lookup("Wnd_Separator")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_Title = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Lookup("Wnd_Title")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_OutputA = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Lookup("Wnd_OutputA")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_OutputB = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Lookup("Wnd_OutputB")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824 = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_Title:Lookup("", "Text_Title")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5 = {}
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450 = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_OutputA:Lookup("", "")
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_b3f6409be38add4404146a3579a8b36a = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_OutputB:Lookup("", "")
  local l_2_0 = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.Wnd_Separator:Lookup("", "")
  BF_ShowDetail.UpdateBar(l_2_0, 350, 15)
end

l_0_0 = BF_ShowDetail
l_0_0.UpdateBar = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = l_3_0:Lookup("Image_Highlight_TL")
  local l_3_4 = l_3_0:Lookup("Image_Highlight_TC")
  local l_3_5 = l_3_0:Lookup("Image_Highlight_TR")
  local l_3_6 = l_3_0:Lookup("Image_Highlight_CL")
  local l_3_7 = l_3_0:Lookup("Image_Highlight_CC")
  local l_3_8 = l_3_0:Lookup("Image_Highlight_CR")
  local l_3_9 = l_3_0:Lookup("Image_Highlight_BL")
  local l_3_10 = l_3_0:Lookup("Image_Highlight_BC")
  local l_3_11 = l_3_0:Lookup("Image_Highlight_BR")
  local l_3_12 = l_3_0:Lookup("Shadow_Highlight_L")
  local l_3_13 = l_3_0:Lookup("Shadow_Highlight_C")
  local l_3_14 = l_3_0:Lookup("Shadow_Highlight_R")
  local l_3_15 = l_3_0:Lookup("Shadow_Separator")
  l_3_15:SetColorRGB(255, 0, 0)
  l_3_15:SetAlpha(160)
  l_3_12:Hide()
  l_3_13:Hide()
  l_3_14:Hide()
  l_3_15:SetRelPos(3, 16)
  l_3_15:SetSize(l_3_1 - 5, 3)
  local l_3_16 = 9
  local l_3_17 = 9
  local l_3_18 = l_3_1
  local l_3_19 = l_3_2 + 7
  if l_3_18 < l_3_16 * 2 or l_3_19 < l_3_17 * 2 then
    local l_3_20 = l_3_18 / (l_3_16 * 2)
    local l_3_21 = l_3_19 / (l_3_17 * 2)
    local l_3_22 = math.min(l_3_20, l_3_21)
    local l_3_23 = l_3_16 * l_3_22
    local l_3_24 = l_3_17 * l_3_22
    l_3_12:SetSize(1, l_3_19 / 2 - 3)
    l_3_12:SetRelPos(2, 3)
    l_3_13:SetSize(l_3_18 - 6, l_3_19 / 2 - 3)
    l_3_13:SetRelPos(3, 2)
    l_3_14:SetSize(1, l_3_19 / 2 - 3)
    l_3_14:SetRelPos(l_3_18 - 2, 3)
    l_3_3:SetSize(l_3_23, l_3_24)
    l_3_3:SetRelPos(0, 0)
    l_3_4:SetSize(l_3_18 - 2 * l_3_23, l_3_24)
    l_3_4:SetRelPos(l_3_23, 0)
    l_3_5:SetSize(l_3_23, l_3_24)
    l_3_5:SetRelPos(l_3_18 - l_3_23, 0)
    l_3_6:SetSize(l_3_23, l_3_19 - 2 * l_3_24)
    l_3_6:SetRelPos(0, l_3_24)
    l_3_7:SetSize(l_3_18 - 2 * l_3_23, l_3_19 - 2 * l_3_24)
    l_3_7:SetRelPos(l_3_23, l_3_24)
    l_3_8:SetSize(l_3_23, l_3_19 - 2 * l_3_24)
    l_3_8:SetRelPos(l_3_18 - l_3_23, l_3_24)
    l_3_9:SetSize(l_3_23, l_3_24)
    l_3_9:SetRelPos(0, l_3_19 - l_3_24)
    l_3_10:SetSize(l_3_18 - 2 * l_3_23, l_3_24)
    l_3_10:SetRelPos(l_3_23, l_3_19 - l_3_24)
    l_3_11:SetSize(l_3_23, l_3_24)
    l_3_11:SetRelPos(l_3_18 - l_3_23, l_3_19 - l_3_24)
  else
    local l_3_25 = l_3_16
    local l_3_26 = l_3_17
    l_3_12:SetSize(1, l_3_19 / 2 - 3)
    l_3_12:SetRelPos(3, 3)
    l_3_13:SetSize(l_3_18 - 6, l_3_19 / 2 - 3)
    l_3_13:SetRelPos(3, 2)
    l_3_14:SetSize(1, l_3_19 / 2 - 3)
    l_3_14:SetRelPos(l_3_18 - 3, 3)
    l_3_3:SetSize(l_3_25, l_3_26)
    l_3_4:SetSize(l_3_18 - 2 * l_3_25, l_3_26)
    l_3_4:SetRelPos(l_3_25, 0)
    l_3_5:SetSize(l_3_25, l_3_26)
    l_3_5:SetRelPos(l_3_18 - l_3_25, 0)
    l_3_6:SetSize(l_3_25, l_3_19 - 2 * l_3_26)
    l_3_6:SetRelPos(0, l_3_26)
    l_3_7:SetSize(l_3_18 - 2 * l_3_25, l_3_19 - 2 * l_3_26)
    l_3_7:SetRelPos(l_3_25, l_3_26)
    l_3_8:SetSize(l_3_25, l_3_19 - 2 * l_3_26)
    l_3_8:SetRelPos(l_3_18 - l_3_25, l_3_26)
    l_3_9:SetSize(l_3_25, l_3_26)
    l_3_9:SetRelPos(0, l_3_19 - l_3_26)
    l_3_10:SetSize(l_3_18 - 2 * l_3_25, l_3_26)
    l_3_10:SetRelPos(l_3_25, l_3_19 - l_3_26)
    l_3_11:SetSize(l_3_25, l_3_26)
    l_3_11:SetRelPos(l_3_18 - l_3_25, l_3_19 - l_3_26)
  end
end

l_0_0 = BF_ShowDetail
l_0_0.OnFrameShow = function()
  BF_ShowDetail.Drag = false
end

l_0_0 = BF_ShowDetail
l_0_0.OnFrameBreathe = function()
  BF_ShowDetail.Display()
end

l_0_0 = BF_ShowDetail
l_0_0.OnFrameDragEnd = function()
end

l_0_0 = BF_ShowDetail
l_0_0.OnFrameDrag = function()
  BF_ShowDetail.Drag = true
end

l_0_0 = BF_ShowDetail
l_0_0.OnLButtonClick = function()
  local l_8_0 = this:GetName()
  if l_8_0 == "Btn_Close" then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
  end
end

l_0_0 = BF_ShowDetail
l_0_0.OnItemLButtonClick = function()
  local l_9_0 = this:GetName()
  local l_9_1 = tonumber(string.match(l_9_0, "%d+"))
  if not l_9_1 then
    return 
  end
  if #BF_ShowDetail.DisplayDataList < l_9_1 then
    return 
  end
  BF_ShowDetail.Select(l_9_1)
  BF_ShowDetail.Display()
end

l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_0("Interface\\BF_CombatStat\\ShowDetail.ini", "BF_ShowDetail")
l_0_0 = BF_ShowDetail
l_0_0.Show = function(l_10_0)
  if not l_10_0 then
    return 
  end
  BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Show()
  BF_ShowDetail.szPlayerName = l_10_0
  BF_ShowDetail.Display()
  BF_ShowDetail.Select(1)
end

l_0_0 = BF_ShowDetail
l_0_0.Select = function(l_11_0)
  local l_11_1 = BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450
  local l_11_2, l_11_3, l_11_4 = nil, nil, nil
  if l_11_0 ~= BF_ShowDetail.nSelectIndex then
    l_11_2 = l_11_1:Lookup("Shadow_Entry_A" .. BF_ShowDetail.nSelectIndex)
    if l_11_2 then
      l_11_3 = l_11_2:GetSize()
      l_11_2:SetSize(0, l_11_4)
    end
    l_11_2 = l_11_1:Lookup("Shadow_Entry_A" .. l_11_0)
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_11_2 then
      l_11_3 = l_11_2:GetSize()
      l_11_2:SetSize(345, l_11_4)
    end
    BF_ShowDetail.nSelectIndex = l_11_0
  end
end

l_0_0 = BF_ShowDetail
l_0_0.Display = function()
  if not BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
  end
  local l_12_0 = Station.Lookup("Normal/BF_CombatStat")
  if not l_12_0 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  else
    if not BF_ShowDetail.Drag then
      local l_12_1, l_12_2 = l_12_0:GetAbsPos()
      BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:SetAbsPos(l_12_1 - 365, l_12_2)
    end
  end
  local l_12_3 = ""
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.DAMAGE then
    BF_ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.DAMAGE
    l_12_3 = "�Եй���"
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEDAMAGE then
      BF_ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.BEDAMAGE
      l_12_3 = "�ܵ��˺�"
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.HEAL then
      BF_ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.HEAL
      l_12_3 = "���ѷ�����"
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEHEAL then
      BF_ShowDetail.nCurrentMode = SHOW_DETAIL_MODE.BEHEAL
      l_12_3 = "�ܵ�����"
    end
  end
  if BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_6c29f3b90d6d4ade8ea51866bb03f824:SetText("��ϸͳ������:" .. BF_ShowDetail.szPlayerName .. "��" .. l_12_3)
  end
  if BF_ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.DAMAGE then
    BF_ShowDetail.DisplayByDamage()
  else
    if BF_ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.HEAL then
      BF_ShowDetail.DisplayByHeal()
    end
  else
    if BF_ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.BEDAMAGE then
      BF_ShowDetail.DisplayByBeDamage()
    end
  else
    if BF_ShowDetail.nCurrentMode == SHOW_DETAIL_MODE.BEHEAL then
      BF_ShowDetail.DisplayByBeHeal()
    end
  end
end

l_0_0 = BF_ShowDetail
l_0_0.DisplayByDamage = function()
  local l_13_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_13_1 = "#".BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_13_5 = "��������", "�˺�", "%" do
    local l_13_6 = l_13_1:Lookup("Text_Title_A_" .. l_13_5)
    l_13_6:SetText(l_13_0[l_13_5])
  end
  if not BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  if not BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName] then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_13_7 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].nTotalDamage
  if not l_13_7 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  do
    local l_13_8 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].DamageRecordList
    if not l_13_8 then
      BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
      return 
    end
    BF_ShowDetail.DisplayDataList = {}
    for l_13_12,l_13_13 in pairs(l_13_8) do
      BF_ShowDetail.DisplayDataList[#BF_ShowDetail.DisplayDataList + 1] = l_13_13
    end
    table.sort(BF_ShowDetail.DisplayDataList, function(l_14_0, l_14_1)
    return l_14_1.nTotalDamage < l_14_0.nTotalDamage
  end)
    local l_13_14 = nil
    for l_13_18,l_13_19 in ipairs(BF_ShowDetail.DisplayDataList) do
      if l_13_18 <= BF_ShowDetail.nMaxDetailEntryCount then
        l_13_14 = l_13_1:Lookup("Text_Entry_A" .. l_13_18 .. "_1")
        l_13_14:SetText(l_13_18)
        l_13_14 = l_13_1:Lookup("Text_Entry_A" .. l_13_18 .. "_2")
        l_13_14:SetText(l_13_19.szSkillName)
        l_13_14 = l_13_1:Lookup("Text_Entry_A" .. l_13_18 .. "_3")
        l_13_14:SetText(l_13_19.nTotalDamage)
        local l_13_20 = l_13_19.nTotalDamage / l_13_7 * 100
        l_13_14 = l_13_1:Lookup("Text_Entry_A" .. l_13_18 .. "_4")
        l_13_14:SetText(string.format("%.1f", l_13_20) .. "%")
      end
    end
    for l_13_24 = #BF_ShowDetail.DisplayDataList + 1, BF_ShowDetail.nMaxDetailEntryCount do
      for l_13_28 = 1, 4 do
        l_13_14 = l_13_1:Lookup("Text_Entry_A" .. l_13_24 .. "_" .. l_13_28)
        l_13_14:SetText("")
      end
    end
    local l_13_29 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    for i = l_13_29, "#", "����" do
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_13_33 = "ƽ��"("���", "����" .. "%")
      l_13_33:SetText(l_13_0[l_13_32])
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_13_34 = nil
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex] then
      l_13_34(l_13_34)
      return 
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_13_35 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_13_35 > 0 then
      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_35(l_13_14, l_13_34)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_35(l_13_14, "����")
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinHitDamage)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_13_35 == 0 then
        l_13_35(l_13_14, "**")
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      else
        l_13_35(l_13_14, string.format("%.0f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalHitDamage / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount))
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxHitDamage)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Confused about usage of registers!

      l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_13_14 = l_13_35
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_13_35 == 0 then
        l_13_35(l_13_14, "**")
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      else
        l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
         -- DECOMPILER ERROR: Overwrote pending register.

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_13_35 > 0 then
        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_35(l_13_14, l_13_34)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_35(l_13_14, "����")
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinCriticalDamage)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_13_35 == 0 then
          l_13_35(l_13_14, "**")
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        else
          l_13_35(l_13_14, string.format("%.0f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCriticalDamage / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount))
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxCriticalDamage)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_13_14 = l_13_35
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_13_35 == 0 then
          l_13_35(l_13_14, "**")
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        else
          l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
           -- DECOMPILER ERROR: Overwrote pending register.

        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_13_35 > 0 then
          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_35(l_13_14, l_13_34)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_35(l_13_14, "BLOCK")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_35(l_13_14, "")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_35(l_13_14, 0)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_35(l_13_14, "")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Confused about usage of registers!

          l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_13_14 = l_13_35
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_13_35 == 0 then
            l_13_35(l_13_14, "**")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

          else
            l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
             -- DECOMPILER ERROR: Overwrote pending register.

          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_13_35 > 0 then
            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_35(l_13_14, l_13_34)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_35(l_13_14, "SHIELD")
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_35(l_13_14, "")
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_35(l_13_14, 0)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_35(l_13_14, "")
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Confused about usage of registers!

            l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_13_14 = l_13_35
             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_13_35 == 0 then
              l_13_35(l_13_14, "**")
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Confused about usage of registers!

            else
              l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
               -- DECOMPILER ERROR: Overwrote pending register.

            end
             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_13_35 > 0 then
              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_35(l_13_14, l_13_34)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_35(l_13_14, "δ����")
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_35(l_13_14, "")
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_35(l_13_14, 0)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_35(l_13_14, "")
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Confused about usage of registers!

              l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_13_14 = l_13_35
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              if l_13_35 == 0 then
                l_13_35(l_13_14, "**")
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Confused about usage of registers!

              else
                l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
                 -- DECOMPILER ERROR: Overwrote pending register.

              end
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              if l_13_35 > 0 then
                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, l_13_34)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "����")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, 0)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Confused about usage of registers!

                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
                 -- DECOMPILER ERROR: Overwrote pending register.

              end
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              if l_13_35 > 0 then
                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, l_13_34)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "ʶ��")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, 0)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_35(l_13_14, "")
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_13_35(l_13_14, l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShipoCount)
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_13_14 = l_13_35
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Confused about usage of registers!

                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_13_35(l_13_14, string.format("%.1f", l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShipoCount / l_13_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
                 -- DECOMPILER ERROR: Overwrote pending register.

              end
               -- DECOMPILER ERROR: Overwrote pending register.

              for l_13_39 = l_13_35, 7 do
                do
                  local l_13_39 = nil
                  l_13_39 = 1
                  for l_13_43 = l_13_39, 7 do
                    local l_13_43 = nil
                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_13_14 = l_13_43
                     -- DECOMPILER ERROR: Overwrote pending register.

                    l_13_43(l_13_14, "")
                  end
                end
                 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

              end
            end
             -- WARNING: missing end command somewhere! Added here
          end
           -- WARNING: missing end command somewhere! Added here
        end
         -- WARNING: missing end command somewhere! Added here
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0 = BF_ShowDetail
l_0_0.DisplayByBeDamage = function()
  local l_14_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_14_1 = "#".BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_14_5 = "��������", "���˺�", "%" do
    local l_14_6 = l_14_1:Lookup("Text_Title_A_" .. l_14_5)
    l_14_6:SetText(l_14_0[l_14_5])
  end
  if not BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  if not BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName] then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_14_7 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].nTotalBeDamage
  if not l_14_7 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_14_8 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].BeDamageRecordList
  if not l_14_8 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  BF_ShowDetail.DisplayDataList = {}
  for l_14_12,l_14_13 in pairs(l_14_8) do
    BF_ShowDetail.DisplayDataList[#BF_ShowDetail.DisplayDataList + 1] = l_14_13
  end
  table.sort(BF_ShowDetail.DisplayDataList, function(l_15_0, l_15_1)
    return l_15_1.nTotalBeDamage < l_15_0.nTotalBeDamage
  end)
  local l_14_14 = nil
  for l_14_18,l_14_19 in ipairs(BF_ShowDetail.DisplayDataList) do
    if l_14_18 <= BF_ShowDetail.nMaxDetailEntryCount then
      l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_18 .. "_1")
      l_14_14:SetText(l_14_18)
      l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_18 .. "_2")
      l_14_14:SetText(l_14_19.szSkillName)
      l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_18 .. "_3")
      l_14_14:SetText(l_14_19.nTotalBeDamage)
      if l_14_7 == 0 then
        l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_18 .. "_4")
        l_14_14:SetText("**")
      end
    else
      local l_14_20 = l_14_19.nTotalBeDamage / l_14_7 * 100
      l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_18 .. "_4")
      l_14_14:SetText(string.format("%.1f", l_14_20) .. "%")
    end
  end
  for l_14_24 = #BF_ShowDetail.DisplayDataList + 1, BF_ShowDetail.nMaxDetailEntryCount do
    for l_14_28 = 1, 4 do
      l_14_14 = l_14_1:Lookup("Text_Entry_A" .. l_14_24 .. "_" .. l_14_28)
      l_14_14:SetText("")
    end
  end
  local l_14_29 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for i = l_14_29, "#", "����" do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_14_33 = "ƽ��"("���", "����" .. "%")
    l_14_33:SetText(l_14_0[l_14_32])
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_14_34 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex] then
    l_14_34(l_14_34)
    return 
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_14_35 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinHitBeDamage)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.0f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalHitBeDamage / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxHitBeDamage)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinCriticalBeDamage)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.0f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCriticalBeDamage / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxCriticalBeDamage)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "BLOCK")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "SHIELD")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "δ����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_14_35 > 0 then
    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, l_14_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_35(l_14_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_14_14 = l_14_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_35(l_14_14, string.format("%.1f", l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount / l_14_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_14_39 = l_14_35, 7 do
    do
      local l_14_39 = nil
      l_14_39 = 1
      for l_14_43 = l_14_39, 7 do
        local l_14_43 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        l_14_14 = l_14_43
         -- DECOMPILER ERROR: Overwrote pending register.

        l_14_43(l_14_14, "")
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_0 = BF_ShowDetail
l_0_0.DisplayByHeal = function()
  local l_15_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_15_1 = "#".BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_15_5 = "��������", "����", "%" do
    local l_15_6 = l_15_1:Lookup("Text_Title_A_" .. l_15_5)
    l_15_6:SetText(l_15_0[l_15_5])
  end
  if not BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  if not BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName] then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_15_7 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].nTotalHeal
  if not l_15_7 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_15_8 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].HealRecordList
  if not l_15_8 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  BF_ShowDetail.DisplayDataList = {}
  for l_15_12,l_15_13 in pairs(l_15_8) do
    BF_ShowDetail.DisplayDataList[#BF_ShowDetail.DisplayDataList + 1] = l_15_13
  end
  table.sort(BF_ShowDetail.DisplayDataList, function(l_16_0, l_16_1)
    return l_16_1.nTotalHeal < l_16_0.nTotalHeal
  end)
  local l_15_14 = nil
  for l_15_18,l_15_19 in ipairs(BF_ShowDetail.DisplayDataList) do
    if l_15_18 <= BF_ShowDetail.nMaxDetailEntryCount then
      l_15_14 = l_15_1:Lookup("Text_Entry_A" .. l_15_18 .. "_1")
      l_15_14:SetText(l_15_18)
      l_15_14 = l_15_1:Lookup("Text_Entry_A" .. l_15_18 .. "_2")
      l_15_14:SetText(l_15_19.szSkillName)
      l_15_14 = l_15_1:Lookup("Text_Entry_A" .. l_15_18 .. "_3")
      l_15_14:SetText(l_15_19.nTotalHeal)
      local l_15_20 = l_15_19.nTotalHeal / l_15_7 * 100
      l_15_14 = l_15_1:Lookup("Text_Entry_A" .. l_15_18 .. "_4")
      l_15_14:SetText(string.format("%.1f", l_15_20) .. "%")
    end
  end
  for l_15_24 = #BF_ShowDetail.DisplayDataList + 1, BF_ShowDetail.nMaxDetailEntryCount do
    for l_15_28 = 1, 4 do
      l_15_14 = l_15_1:Lookup("Text_Entry_A" .. l_15_24 .. "_" .. l_15_28)
      l_15_14:SetText("")
    end
  end
  local l_15_29 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for i = l_15_29, "#", "����" do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_15_33 = "ƽ��"("���", "����" .. "%")
    l_15_33:SetText(l_15_0[l_15_32])
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_15_34 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex] then
    l_15_34(l_15_34)
    return 
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_15_35 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinHitHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.0f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalHitHeal / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxHitHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinCriticalHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.0f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCriticalHeal / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxCriticalHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "BLOCK")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "SHIELD")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "δ����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_15_35 > 0 then
    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, l_15_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_35(l_15_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_15_14 = l_15_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_15_35(l_15_14, string.format("%.1f", l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount / l_15_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_15_39 = l_15_35, 7 do
    do
      local l_15_39 = nil
      l_15_39 = 1
      for l_15_43 = l_15_39, 7 do
        local l_15_43 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        l_15_14 = l_15_43
         -- DECOMPILER ERROR: Overwrote pending register.

        l_15_43(l_15_14, "")
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_0 = BF_ShowDetail
l_0_0.DisplayByBeHeal = function()
  local l_16_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_16_1 = "#".BigFoot_472c2502c09d0103ec5bb3a07a794147.BigFoot_efa19646f7090865e6b9216bab39cbc5.BigFoot_6f665b66bb0a7bdd35f1eb855424b450
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for l_16_5 = "��������", "������", "%" do
    local l_16_6 = l_16_1:Lookup("Text_Title_A_" .. l_16_5)
    l_16_6:SetText(l_16_0[l_16_5])
  end
  if not BF_ShowDetail.szPlayerName then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  if not BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName] then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_16_7 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].nTotalBeHeal
  if not l_16_7 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  local l_16_8 = BF_CombatStat.PlayerDataRecordList[BF_ShowDetail.szPlayerName].BeHealRecordList
  if not l_16_8 then
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    return 
  end
  BF_ShowDetail.DisplayDataList = {}
  for l_16_12,l_16_13 in pairs(l_16_8) do
    BF_ShowDetail.DisplayDataList[#BF_ShowDetail.DisplayDataList + 1] = l_16_13
  end
  table.sort(BF_ShowDetail.DisplayDataList, function(l_17_0, l_17_1)
    return l_17_1.nTotalBeHeal < l_17_0.nTotalBeHeal
  end)
  local l_16_14 = nil
  for l_16_18,l_16_19 in ipairs(BF_ShowDetail.DisplayDataList) do
    if l_16_18 <= BF_ShowDetail.nMaxDetailEntryCount then
      l_16_14 = l_16_1:Lookup("Text_Entry_A" .. l_16_18 .. "_1")
      l_16_14:SetText(l_16_18)
      l_16_14 = l_16_1:Lookup("Text_Entry_A" .. l_16_18 .. "_2")
      l_16_14:SetText(l_16_19.szSkillName)
      l_16_14 = l_16_1:Lookup("Text_Entry_A" .. l_16_18 .. "_3")
      l_16_14:SetText(l_16_19.nTotalBeHeal)
      local l_16_20 = l_16_19.nTotalBeHeal / l_16_7 * 100
      l_16_14 = l_16_1:Lookup("Text_Entry_A" .. l_16_18 .. "_4")
      l_16_14:SetText(string.format("%.1f", l_16_20) .. "%")
    end
  end
  for l_16_24 = #BF_ShowDetail.DisplayDataList + 1, BF_ShowDetail.nMaxDetailEntryCount do
    for l_16_28 = 1, 4 do
      l_16_14 = l_16_1:Lookup("Text_Entry_A" .. l_16_24 .. "_" .. l_16_28)
      l_16_14:SetText("")
    end
  end
  local l_16_29 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  for i = l_16_29, "#", "����" do
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_16_33 = "ƽ��"("���", "����" .. "%")
    l_16_33:SetText(l_16_0[l_16_32])
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_16_34 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex] then
    l_16_34(l_16_34)
    return 
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_16_35 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinHitBeHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.0f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalHitBeHeal / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxHitBeHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nHitCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMinCriticalBeHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.0f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCriticalBeHeal / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount))
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMaxCriticalBeHeal)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nCriticalCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "BLOCK")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nBlockCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "SHIELD")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nShieldCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "δ����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nMissCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_16_35 > 0 then
    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, l_16_34)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "����")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, 0)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_35(l_16_14, "")
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_16_14 = l_16_35
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_16_35(l_16_14, string.format("%.1f", l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nDodgeCount / l_16_29.DisplayDataList[BF_ShowDetail.nSelectIndex].nTotalCount * 100) .. "%")
     -- DECOMPILER ERROR: Overwrote pending register.

  end
   -- DECOMPILER ERROR: Overwrote pending register.

  for l_16_39 = l_16_35, 7 do
    do
      local l_16_39 = nil
      l_16_39 = 1
      for l_16_43 = l_16_39, 7 do
        local l_16_43 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        l_16_14 = l_16_43
         -- DECOMPILER ERROR: Overwrote pending register.

        l_16_43(l_16_14, "")
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end


