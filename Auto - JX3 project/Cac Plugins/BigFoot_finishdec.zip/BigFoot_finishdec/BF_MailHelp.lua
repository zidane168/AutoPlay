-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_MailHelp.lua 

local l_0_0 = {}
l_0_0.myloothandl = 0
l_0_0.MailDate = {}
l_0_0.BShowTipInfo = true
BF_MailHelp = l_0_0
l_0_0 = BF_MailHelp
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0.myAllXuanzeList, l_0_1 = l_0_1, {"��Ʒ����", "���������ż�", "�޷����ŵ��ż�"}
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "Account\\BF_MailHelp.MailDate"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = "BF_MailHelp.BShowTipInfo"
l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

l_0_1 = function()
  return "", "BigFoot_338ba3af568cfc03a5cef209704bd588"
end

IsMailPanelOpened = function()
  local l_3_0 = Station.Lookup("Normal/MailPanel")
  if l_3_0 and l_3_0:IsVisible() then
    return true
  end
  return false
end

BF_MailHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(0, 0, "NONE")
BF_MailHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:RegisterEvent("GET_MAIL_CONTENT")
local l_0_2 = 0
local l_0_3 = false
BF_MailHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnUpdate = function(l_4_0)
  -- upvalues: l_0_2 , l_0_3
  if BF_MailHelp.EnableMailHelp and GetTime() - l_0_2 >= 1000 then
    l_0_2 = GetTime()
    BF_MailHelp.OpenBigBagPanel()
    if IsMailPanelOpened() then
      if not l_0_3 then
        BF_MailHelp.CreatLoootButton()
        l_0_3 = true
      end
      local l_4_1 = Station.Lookup("Normal/MailPanel")
      local l_4_2 = l_4_1:Lookup("PageSet_Total/Page_Receive")
      local l_4_3 = l_4_2:Lookup("", "")
      if l_4_3 then
        BF_MailHelp.myloothandl = l_4_3.dwID
      end
    end
    if BF_MailHelp.EnableMailHelp then
      if not GetMailClient().GetMailList("all") then
        local l_4_4, l_4_5, l_4_13 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      for l_4_9,l_4_10 in ipairs(l_4_4) do
        local l_4_6 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        local l_4_12 = GetMailClient().GetMailInfo(R9_PC63)
        if Station.Lookup("Normal/Target") then
          l_4_12.RequestContent(Station.Lookup("Normal/Target").dwID)
        end
      end
      BigFoot_DelayCall(BF_MailHelp.updateALLMailItem, 1000)
    end
  else
    l_0_3 = false
    BF_MailHelp.DelLoootButton()
  end
end

BF_MailHelp.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.OnEvent = function(l_5_0, l_5_1, l_5_2, ...)
  if l_5_2 == "GET_MAIL_CONTENT" and BF_MailHelp.EnableMailHelp then
    BF_MailHelp.DelAllNoneMail()
    BF_MailHelp.myloothandl = arg0
  end
end

BF_MailHelp.UpdateMailInfo = function(l_6_0)
  BF_MailHelp.BigFoot_2403b6c533920f40081a3f9e35068204(l_6_0)
  if BF_MailHelp.EnableMailHelp then
    BF_MailHelp.DelAllNoneMail()
    BF_MailHelp.myloothandl = l_6_0.dwID
  end
end

BF_MailHelp.UpdateMailList = function(l_7_0, l_7_1)
  BF_MailHelp.BigFoot_ab1c5a57c0f484766d227c451af9be4a(l_7_0, l_7_1)
  if BF_MailHelp.EnableMailHelp then
    if not GetMailClient().GetMailList(MailPanel.szFilter) then
      local l_7_2, l_7_3, l_7_10 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_7_7,l_7_8 in ipairs(l_7_2) do
      local l_7_4 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      GetMailClient().GetMailInfo(R7_PC25).RequestContent(MailPanel.dwTargetID)
    end
    BigFoot_DelayCall(BF_MailHelp.updateALLMailItem, 1000)
  end
end

BF_MailHelp.DelAllNoneMail = function()
  local l_8_0 = Station.Lookup("Normal/MailPanel")
  local l_8_1 = l_8_0:Lookup("PageSet_Total/Page_Receive")
  local l_8_2 = l_8_1:Lookup("", "")
  local l_8_3 = l_8_2:Lookup("Handle_MailList")
  local l_8_4 = GetMailClient()
  if not GetMailClient().GetMailList("all") then
    local l_8_5, l_8_6 = {}
  end
  local l_8_7 = nil
  for l_8_11,l_8_12 in ipairs(l_8_7) do
    local l_8_8 = false
     -- DECOMPILER ERROR: Confused about usage of registers!

    if BF_MailHelp.EnableDelAllNoneMail and l_8_4.GetMailInfo(R11_PC30) and not l_8_4.GetMailInfo(R11_PC30).bItemFlag and not l_8_4.GetMailInfo(R11_PC30).bMoneyFlag and l_8_4.GetMailInfo(R11_PC30).GetText() == "" then
      l_8_4.DeleteMail(l_8_13)
      l_8_8 = true
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_8_8 then
    MailPanel.UpdateMailList(l_8_3)
  end
end

BF_MailHelp.whyMastthis = function(l_9_0)
  if not IsMailPanelOpened() then
    return 
  end
  local l_9_1 = GetMailClient().GetMailInfo(l_9_0)
  if not l_9_1 then
    return 
  end
  if l_9_1.bItemFlag or l_9_1.bMoneyFlag then
    BF_MailHelp.LootAllItemByID(l_9_0)
  end
end

MailPanel_FireMailReadEvent = function(l_10_0)
  local l_10_1 = arg0
  arg0 = l_10_0
  FireEvent("MAIL_READED")
  arg0 = l_10_1
end

BF_MailHelp.LootAllItemByID = function(l_11_0)
  local l_11_1 = GetMailClient().GetMailInfo(l_11_0)
  if not l_11_1 then
    return 
  end
  if l_11_1.bGotContentFlag then
    l_11_1.Read()
    MailPanel_FireMailReadEvent(l_11_0)
  else
    local l_11_2 = Station.Lookup("Normal/Target")
  end
  if l_11_2 then
    l_11_1.RequestContent(l_11_2.dwID)
  end
  local l_11_3 = 0
  for l_11_7 = 1, 8 do
    local l_11_8, l_11_9 = l_11_1.GetItem(l_11_7 - 1)
    if l_11_8 then
      l_11_3 = l_11_3 + 1
      GetMailClient().GetMailInfo(l_11_0).TakeItem(l_11_7 - 1)
    end
  end
  if l_11_1.nMoney ~= 0 then
    l_11_1.TakeMoney()
  end
  if l_11_3 > 0 then
    BigFoot_DelayCall(BF_MailHelp.whyMastthis, 500, l_11_0)
  end
end

BF_MailHelp.LootAllItembyselete = function()
  local l_12_0 = Station.Lookup("Normal/MailPanel")
  local l_12_1 = l_12_0:Lookup("PageSet_Total/Page_Receive")
  local l_12_2 = l_12_1:Lookup("", "")
  local l_12_3 = l_12_2:Lookup("Handle_MailList")
  local l_12_4 = l_12_3:GetItemCount() - 1
  for l_12_8 = 0, l_12_4 do
    local l_12_9 = l_12_3:Lookup(l_12_8)
    if l_12_9 and l_12_9.bChoose then
      BF_MailHelp.whyMastthis(l_12_9.dwID)
    end
  end
end

BF_MailHelp.LootAllItem = function()
  local l_13_0 = Station.Lookup("Normal/MailPanel")
  local l_13_1 = l_13_0:Lookup("PageSet_Total/Page_Receive")
  local l_13_2 = l_13_1:Lookup("", "")
  local l_13_3 = l_13_2:Lookup("Handle_MailList")
  local l_13_4 = l_13_3:GetItemCount() - 1
  for l_13_8 = 0, l_13_4 - 1 do
    local l_13_9 = l_13_3:Lookup(l_13_8)
    if l_13_9 and l_13_9.dwID then
      BF_MailHelp.whyMastthis(l_13_9.dwID)
    end
  end
end

BF_MailHelp.DelLoootButton = function()
  BF_MailHelp.LoootButton = nil
  BF_MailHelp.LoootAllButton = nil
  BF_MailHelp.LoootSeleteButton = nil
  BF_MailHelp.OpenMyMailPanel = nil
end

BF_MailHelp.CreatLoootButton = function(l_15_0)
  -- upvalues: l_0_0 , l_0_1
  local l_15_1 = Station.Lookup("Normal/MailPanel")
  local l_15_2 = l_15_1:Lookup("PageSet_Total/Page_Receive")
  BF_MailHelp.LoootButton = BFButton.new(l_15_2, 35, 35)
  BF_MailHelp.LoootButton:SetStyle("TRANSPARENT")
  BF_MailHelp.LoootButton:SetNormalImage("ui\\Image\\UICommon\\CommonPanel.UITex", 76)
  BF_MailHelp.LoootButton:SetHotImage("Interface\\BF_MailHelp\\highlight.tga")
  BF_MailHelp.LoootButton:SetPressedImage("Interface\\BF_MailHelp\\pressed.tga")
  local l_15_3, l_15_4 = l_15_1:GetAbsPos()
  BF_MailHelp.LoootButton:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_15_3 + 730, l_15_4 + 435)
  local l_15_5, l_15_6 = BF_MailHelp.LoootButton:AddListener, BF_MailHelp.LoootButton
  local l_15_7 = {}
  l_15_7.OnMouseEnter = function()
    local l_16_0, l_16_1 = this:GetAbsPos()
    local l_16_2 = OutputTip
    local l_16_3 = "<text>text=\"ʰȡ���ż�ȫ����Ʒ\"</text>"
    local l_16_4 = 200
    do
      local l_16_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_16_2(l_16_3, l_16_4, l_16_5)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_15_7.OnMouseLeave = function()
    HideTip()
  end
  l_15_5(l_15_6, l_15_7)
  l_15_5 = BF_MailHelp
  l_15_5 = l_15_5.LoootButton
  l_15_6 = function(l_18_0)
    -- upvalues: l_0_0
    if BF_MailHelp.myloothandl == 0 then
      l_0_0("û���ż���Ϣ����ѡ���ż�֮���ٵ�ʰȡ")
    else
      BF_MailHelp.whyMastthis(BF_MailHelp.myloothandl)
    end
  end
  l_15_5.OnClick = l_15_6
  l_15_5 = BF_MailHelp
  l_15_6 = BFButton
  l_15_6 = l_15_6.new
  l_15_7 = l_15_2
  l_15_6 = l_15_6(l_15_7, 102, 26)
  l_15_5.OpenMyMailPanel = l_15_6
  l_15_5 = BF_MailHelp
  l_15_5 = l_15_5.OpenMyMailPanel
  l_15_5, l_15_6 = l_15_5:SetStyle, l_15_5
  l_15_7 = "TRANSPARENT"
  l_15_5(l_15_6, l_15_7)
  l_15_5 = BF_MailHelp
  l_15_5 = l_15_5.OpenMyMailPanel
  l_15_5, l_15_6 = l_15_5:SetNormalImage, l_15_5
  l_15_7 = "interface\\BF_MailHelp\\mailhelp.tga"
  l_15_5(l_15_6, l_15_7)
  l_15_5 = BF_MailHelp
  l_15_5 = l_15_5.OpenMyMailPanel
  l_15_5, l_15_6 = l_15_5:SetHotImage, l_15_5
  l_15_7 = "interface\\BF_MailHelp\\mailhelp.tga"
  l_15_5(l_15_6, l_15_7)
  l_15_5 = BF_MailHelp
  l_15_5 = l_15_5.OpenMyMailPanel
  l_15_5, l_15_6 = l_15_5:SetPressedImage, l_15_5
  l_15_7 = "interface\\BF_MailHelp\\mailhelp.tga"
  l_15_5(l_15_6, l_15_7)
  l_15_5, l_15_6 = l_15_1:GetAbsPos, l_15_1
  l_15_5 = l_15_5(l_15_6)
  l_15_7 = BF_MailHelp
  l_15_7 = l_15_7.OpenMyMailPanel
  l_15_7(l_15_7, "TOPLEFT", BFScreen, "TOPLEFT", l_15_5 + 50, l_15_6 + 8)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  local l_15_8 = l_15_7
  local l_15_9 = {}
  l_15_9.OnMouseEnter = function()
    local l_19_0, l_19_1 = this:GetAbsPos()
    local l_19_2 = OutputTip
    local l_19_3 = "<text>text=\"��������ʼ��ֿ�\"</text>"
    local l_19_4 = 200
    do
      local l_19_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_19_2(l_19_3, l_19_4, l_19_5)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_15_9.OnMouseLeave = function()
    HideTip()
  end
  l_15_7(l_15_8, l_15_9)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_15_8 = function(l_21_0)
    -- upvalues: l_0_1
    local l_21_1 = {}
    l_21_1.szName = "�ʼ��ֿ�"
    l_21_1.szMessage = " ����ͨ����ʹ���ʼ��ֿ⣬�����Ʒ��ֱ��ʰȡ���ʼ���Ʒ\n ���벻Ҫ�뿪��ʹ������"
    l_21_1.fnCancelAction = function()
    end
    local l_21_2 = {}
    l_21_2.szOption = "ȷ��"
    l_21_2.fnAction = function()
      -- upvalues: l_0_1
      local l_23_0 = GetClientPlayer()
      local l_23_1, l_23_2 = l_0_1()
      local l_23_3 = nil
      if BF_MailHelp.MailDate[l_23_2] then
        l_23_3 = BF_MailHelp.MailDate[l_23_2][l_23_0.szName]
      end
      BF_MailHelp.MYItemDate = nil
      BF_MailHelp.pagenumber = 1
      if l_23_3 then
        BF_MailHelp.MYItemDate = l_23_3
        BF_MailHelp.bObline = true
        BigFoot_fd94df882a4b49258e3186e780ef5d26()
        BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
      end
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    Msg = l_21_1
    l_21_1 = MessageBox
    l_21_2 = Msg
    l_21_1(l_21_2)
  end
  l_15_7.OnClick = l_15_8
end

BF_MailHelp.OpenBigBagPanel = function(...)
  if Station.Lookup("Normal/BigBagPanel") and not BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5 then
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5 = BFButton.new(Station.Lookup("Normal/BigBagPanel"), 36, 33)
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetStyle("TRANSPARENT")
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetNormalImage("ui\\Image\\UICommon\\CommonPanel.UITex", 76)
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetHotImage("ui\\Image\\UICommon\\CommonPanel.UITex", 76)
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetPressedImage("ui\\Image\\UICommon\\CommonPanel.UITex", 76)
    local l_16_1, l_16_2 = , Station.Lookup("Normal/BigBagPanel"):GetAbsPos()
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_16_2 + 120, Station.Lookup("Normal/BigBagPanel") + 2)
    local l_16_3, l_16_4 = , BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:AddListener
    local l_16_5 = BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5
    l_16_4(l_16_5, {OnMouseEnter = function()
      local l_17_0, l_17_1 = this:GetAbsPos()
      local l_17_2 = OutputTip
      local l_17_3 = "<text>text=\"����������\"</text>"
      local l_17_4 = 200
      do
        local l_17_5 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_17_2(l_17_3, l_17_4, l_17_5)
      end
       -- WARNING: undefined locals caused missing assignments!
    end, OnMouseLeave = function()
      HideTip()
    end})
    l_16_4 = BF_MailHelp
    l_16_4 = l_16_4.BigFoot_2fccb5df73f6c431451c4e5b55054af5
    l_16_5 = function(l_19_0)
      local l_19_1 = {}
      l_19_1.szName = "�ʼ��ֿ�"
      l_19_1.szMessage = " ���ڴ������ʼ�, �����ʼ������Ʒ��Ϣ�����������ʼ���Ϣ"
      l_19_1.fnCancelAction = function()
      end
      local l_19_2 = {}
      l_19_2.szOption = "ȷ��"
      l_19_2.fnAction = function()
        BF_MailHelp.OpenOffLineMailDefauit()
      end
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      Msg = l_19_1
      l_19_1 = MessageBox
      l_19_2 = Msg
      l_19_1(l_19_2)
    end
    l_16_4.OnClick = l_16_5
  end
end

BF_MailHelp.OnFrameCreate = function()
  local l_17_0 = Station.Lookup("Normal/BF_MailHelp")
  if not l_17_0 then
    return 
  end
  local l_17_1 = l_17_0:Lookup("", "Text_Title")
  if l_17_1 then
    l_17_1:SetText("1233333333")
  end
  local l_17_2 = l_17_0:Lookup("", "Handle_Box")
  if l_17_2 then
    l_17_2:Clear()
  end
  for l_17_6 = 1, 7 do
    for l_17_10 = 1, 14 do
      l_17_2:AppendItemFromIni("InterFace/BF_MailHelp/BF_MailHelp.ini", "Box_Item")
      local l_17_11 = l_17_2:Lookup(l_17_2:GetItemCount() - 1)
      if l_17_11 then
        l_17_11:Show()
        l_17_11.x = l_17_6
        l_17_11.y = l_17_10
        l_17_11:SetRelPos((l_17_10 - 1) * 51, (l_17_6 - 1) * 51)
      end
    end
  end
  l_17_2:FormatAllItemPos()
  BF_MailHelp.handleBox = l_17_2
end

RegisterEvent("BAG_ITEM_UPDATE", function()
  if BF_MailHelp.bObline then
    BigFoot_DelayCall(BF_MailHelp.updateALLMailItem, 1000)
  end
end
)
BF_MailHelp.updateALLMailItem = function()
  -- upvalues: l_0_1
  local l_19_0 = Station.Lookup("Normal/MailPanel")
  if not l_19_0 then
    return 
  end
  local l_19_1 = l_19_0:Lookup("PageSet_Total/Page_Receive")
  local l_19_2 = l_19_1:Lookup("", "")
  local l_19_3 = l_19_2:Lookup("Handle_MailList")
  if not l_19_3 then
    return 
  end
  local l_19_4 = l_19_3:GetItemCount()
  local l_19_5 = 0
  local l_19_6 = GetClientPlayer()
  local l_19_7, l_19_8 = l_0_1()
  if not BF_MailHelp.MailDate[l_19_8] then
    BF_MailHelp.MailDate[l_19_8] = {}
  end
  local l_19_9 = BF_MailHelp.MailDate[l_19_8]
  local l_19_10 = l_19_6.szName
  l_19_9[l_19_10] = {}
  l_19_9 = 0
  l_19_10 = l_19_4 - 1
  for i = l_19_9, l_19_10 do
    local l_19_13 = l_19_3:Lookup(l_19_12)
    if l_19_13 and l_19_13.dwID then
      local l_19_14 = l_19_13.dwID
      local l_19_15 = GetMailClient().GetMailInfo(l_19_14)
      if l_19_15.bGotContentFlag then
        l_19_15.Read()
        MailPanel_FireMailReadEvent(l_19_14)
      else
        local l_19_16 = Station.Lookup("Normal/Target")
      end
      if l_19_16 then
        l_19_15.RequestContent(l_19_16.dwID)
      end
      BF_MailHelp.SaveItem(l_19_5, l_19_14)
    end
  end
  if BigFoot_4f7315bb64d3054297d89684c8033e9b() then
    BF_MailHelp.MYItemDate = BF_MailHelp.MailDate[l_19_8][l_19_6.szName]
    BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

BF_MailHelp.SaveItem = function(l_20_0, l_20_1)
  -- upvalues: l_0_1
  local l_20_2 = GetClientPlayer()
  local l_20_3, l_20_4 = l_0_1()
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1] = {}
  local l_20_5 = GetMailClient().GetMailInfo(l_20_1)
  local l_20_6 = l_20_5.szSenderName
  local l_20_7 = GetTime() + l_20_5.GetLeftTime() * 1000
  local l_20_8 = l_20_5.szTitle
  local l_20_9 = l_20_5.GetType()
  local l_20_10 = l_20_5.bMoneyFlag
  local l_20_11 = l_20_5.bItemFlag
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].sendname = l_20_6
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].dwTime = l_20_7
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].title = l_20_8
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].mailIType = l_20_9
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].bMoneyFlag = l_20_10
  BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1].bItemFlag = l_20_11
  for l_20_15 = 1, 8 do
    local l_20_16, l_20_17 = l_20_5.GetItem(l_20_15 - 1)
    if l_20_16 then
      local l_20_18 = {}
      l_20_18.TabType = l_20_16.dwTabType
      l_20_18.Index = l_20_16.dwIndex
      l_20_18.StackNum = l_20_16.nStackNum
      l_20_18.bCanStack = l_20_16.bCanStack
      l_20_18.dwID = l_20_16.dwID
      l_20_18.nBookID = l_20_16.nBookID
      l_20_18.nUiId = l_20_16.nUiId
      l_20_18.i = l_20_15 - 1
      table.insert(BF_MailHelp.MailDate[l_20_4][l_20_2.szName][l_20_1], l_20_18)
    end
  end
end

BF_MailHelp.ClearAllBox = function()
  local l_21_0 = BF_MailHelp.handleBox:GetItemCount()
  for l_21_4 = 0, l_21_0 - 1 do
    local l_21_5 = BF_MailHelp.handleBox:Lookup(l_21_4)
    l_21_5:Hide()
  end
end

BF_MailHelp.OnItemMouseEnter = function()
  if this.BItemBox then
    this:SetObjectMouseOver(true)
    local l_22_0, l_22_1 = this:GetAbsPos()
    local l_22_2, l_22_3 = this:GetSize()
    local l_22_4 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_22_5 = l_22_0
     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_22_1() then
      if BF_MailHelp.BShowTipInfo then
        local l_22_6 = this.sendname
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_22_8 = l_22_2.dwTime
        local l_22_9 = l_22_3.title
        local l_22_7 = ""
        if l_22_8 >= 86400 then
          l_22_7 = FormatString(g_tStrings.STR_MAIL_LEFT_DAY, math.floor(l_22_8 / 86400))
        elseif l_22_8 >= 3600 then
          l_22_7 = FormatString(g_tStrings.STR_MAIL_LEFT_HOURE, math.floor(l_22_8 / 3600))
        elseif l_22_8 >= 60 then
          l_22_7 = FormatString(g_tStrings.STR_MAIL_LEFT_MINUTE, math.floor(l_22_8 / 60))
        else
          l_22_7 = g_tStrings.STR_MAIL_LEFT_LESS_ONE_M
        end
        if string.len(l_22_9) > 20 then
          l_22_9 = string.sub(l_22_9, 0, 20)
          l_22_9 = l_22_9 .. "..."
        end
        local l_22_14, l_22_15 = nil
        l_22_15 = l_22_5
        l_22_5 = l_22_15 .. "<Text>text=\"������:" .. l_22_6 .. " ʣ��ʱ�䣨 " .. l_22_7 .. " ��\n�ż����⣺" .. l_22_9 .. "\n\" r=0 g=255 b=0</Text>"
      end
      local l_22_10 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_22_8.dwTabType == 5 then
        l_22_10 = this.nBookID
      else
        l_22_10 = this.nStackNum
      end
      local l_22_11 = OutputTip
      local l_22_12 = l_22_5
      local l_22_13 = 345
      l_22_11(l_22_12, l_22_13, l_22_4, nil, nil, "iteminfo")
    end
  else
    local l_22_16 = nil
    if this.dwTabType == 5 then
      l_22_16 = this.nBookID
    else
      l_22_16 = this.nStackNum
    end
    local l_22_17 = OutputItemTip
    local l_22_18 = UI_OBJECT_ITEM_INFO
    local l_22_19 = 1
    local l_22_20 = this.dwTabType
    local l_22_21 = this.dwIndex
    local l_22_22 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_22_17(l_22_18, l_22_19, l_22_20, l_22_21, l_22_22, l_22_0, l_22_1, l_22_2, l_22_3, l_22_16)
  end
end

BF_MailHelp.OnItemMouseLeave = function()
  this:SetObjectMouseOver(false)
  HideTip()
end

BF_MailHelp.OnItemLButtonDown = function()
  if IsCtrlKeyDown() and this.BItemBox then
    EditBox_AppendLinkItemInfo(nil, this.dwTabType, this.dwIndex)
    return 
  end
  if this.BItemBox and BF_MailHelp.bObline then
    GetMailClient().GetMailInfo(this.dwmail).TakeItem(this.lootNumber)
    this:SetAlpha(32)
  end
end

BF_MailHelp.OnCheckBoxCheck = function()
  local l_25_0 = this:GetName()
  if l_25_0 == "CheckBox_ShowTipInfo" then
    BF_MailHelp.BShowTipInfo = true
  end
end

BF_MailHelp.OnCheckBoxUncheck = function()
  local l_26_0 = this:GetName()
  if l_26_0 == "CheckBox_ShowTipInfo" then
    BF_MailHelp.BShowTipInfo = false
  end
end

BF_MailHelp.UpdateBoxItem = function(l_27_0, l_27_1)
  local l_27_2 = 0
  local l_27_3 = 0
  local l_27_4 = 0
  do
    local l_27_5 = false
    if not l_27_1 then
      l_27_1 = 1
    end
    if not l_27_0 then
      l_27_0 = {}
      l_27_5 = true
    end
    BF_MailHelp.ClearAllBox()
    do break end
    do
      local l_27_6, l_27_7, l_27_8, l_27_9, l_27_10 = pairs(l_27_0)
      l_27_3 = l_27_3 + 1
      for l_27_14,l_27_15 in pairs(l_27_10) do
        local l_27_16 = l_27_10.sendname
        local l_27_17 = l_27_10.dwTime
        if l_27_4 == 0 then
          l_27_4 = l_27_17
        elseif l_27_17 < l_27_4 then
          l_27_4 = l_27_17
        end
        local l_27_18 = l_27_10.title
        local l_27_19 = l_27_10.mailIType
        local l_27_20 = l_27_10.bMoneyFlag
        local l_27_21 = l_27_10.bItemFlag
        if type(l_27_15) == "table" then
          local l_27_22 = l_27_15.TabType
          local l_27_23 = l_27_15.Index
          local l_27_24 = l_27_15.StackNum
          local l_27_25 = l_27_15.nBookID
          local l_27_26 = l_27_15.i
          local l_27_27 = l_27_15.nUiId
          local l_27_28 = l_27_15.dwID
          local l_27_29 = l_27_15.bCanStack
          local l_27_30 = BF_MailHelp.GetItem(l_27_22, l_27_23, l_27_24, l_27_25, l_27_9, l_27_17, l_27_19, l_27_20, l_27_21)
        end
        if l_27_30 then
          l_27_2 = l_27_2 + 1
          local l_27_31 = BF_MailHelp.GetBoxBYnumber(l_27_2, l_27_1)
        end
        if l_27_31 then
          l_27_31:Show()
          l_27_31:SetAlpha(255)
          l_27_31:SetObject(UI_OBJECT_NOT_NEED_KNOWN, 1)
          l_27_31:SetObjectIcon(Table_GetItemIconID(l_27_27))
          l_27_31.BItemBox = true
          l_27_31.dwTabType = l_27_30.dwTabType
          l_27_31.dwIndex = l_27_30.dwIndex
          l_27_31.nStackNum = l_27_30.nStackNum
          l_27_31.nBookID = l_27_30.nBookID
          l_27_31.nUiId = l_27_27
          l_27_31.dwID = l_27_28
          l_27_31.dwmail = l_27_9
          l_27_31.lootNumber = l_27_26
          l_27_31.sendname = l_27_16
          l_27_31.dwTime = l_27_17
          l_27_31.title = l_27_18
          l_27_31.mailIType = l_27_19
          l_27_31.bMoneyFlag = l_27_20
          l_27_31.bItemFlag = l_27_21
          if l_27_29 and l_27_24 > 1 then
            l_27_31:SetOverText(0, l_27_24)
          else
            l_27_31:SetOverText(0, "")
          end
          UpdateItemBoxExtend(l_27_31, l_27_30)
        end
      end
    end
  end
  BF_MailHelp.bNodate = l_27_5
  BF_MailHelp.lastTime = l_27_4
  BF_MailHelp.MailNumber = l_27_3
  BF_MailHelp.CurrentItemNumber = l_27_2
  BF_MailHelp.CurrentPageNumber = math.ceil(BF_MailHelp.CurrentItemNumber / 98)
  BF_MailHelp.UpdateMailTitle()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

BF_MailHelp.UpdateMailTitle = function()
  local l_28_0 = Station.Lookup("Normal/BF_MailHelp")
  if not l_28_0 then
    return 
  end
  local l_28_1 = l_28_0:Lookup("", "Text_Title")
  if not l_28_1 then
    return 
  end
  local l_28_2 = ""
  if not BF_MailHelp.bNodate then
    local l_28_3 = 0
    local l_28_4 = ""
    if BF_MailHelp.lastTime then
      l_28_3 = (BF_MailHelp.lastTime - GetTime()) / 1000
    end
    if l_28_3 >= 86400 then
      l_28_4 = FormatString(g_tStrings.STR_MAIL_LEFT_DAY, math.floor(l_28_3 / 86400))
    elseif l_28_3 >= 3600 then
      l_28_4 = FormatString(g_tStrings.STR_MAIL_LEFT_HOURE, math.floor(l_28_3 / 3600))
    elseif l_28_3 >= 60 then
      l_28_4 = FormatString(g_tStrings.STR_MAIL_LEFT_MINUTE, math.floor(l_28_3 / 60))
    else
      l_28_4 = "1����"
    end
    if BF_MailHelp.MailNumber then
      l_28_2 = l_28_2 .. "��ǰ��ɫ�¹��� " .. BF_MailHelp.MailNumber .. "���ʼ�"
    end
    l_28_2 = l_28_2 .. " " .. l_28_4 .. " ֮�����ʼ�����"
    if BF_MailHelp.CurrentItemNumber then
      l_28_2 = l_28_2 .. " ��ǰ״̬�¹��� " .. BF_MailHelp.CurrentItemNumber .. "����Ʒ"
    end
  else
    l_28_2 = l_28_2 .. "û�е�ǰ��ɫ���ݣ����ȴ����䡣"
  end
  l_28_1:SetText(l_28_2)
end

GetItemNameByItemInfo = function(l_29_0, l_29_1)
  if l_29_0.nGenre == ITEM_GENRE.BOOK then
    if l_29_1 then
      local l_29_2, l_29_3 = GlobelRecipeID2BookID(l_29_1)
      local l_29_7, l_29_12 = Table_GetSegmentName, l_29_2
      local l_29_8, l_29_13 = l_29_3
      l_29_7 = l_29_7(l_29_12, l_29_8)
      if not l_29_7 then
        l_29_7 = g_tStrings
        l_29_7 = l_29_7.BOOK
        local l_29_6, l_29_11 = nil
      end
      return l_29_7
    else
      local l_29_4 = Table_GetItemName
      local l_29_5 = l_29_0.nUiId
      return l_29_4(l_29_5)
    end
  else
    local l_29_9 = Table_GetItemName
    local l_29_10 = l_29_0.nUiId
    return l_29_9(l_29_10)
  end
end

BF_MailHelp.GetItem = function(l_30_0, l_30_1, l_30_2, l_30_3, l_30_4, l_30_5, l_30_6, l_30_7, l_30_8)
  local l_30_9 = GetItemInfo(l_30_0, l_30_1)
  local l_30_10 = {}
  if l_30_9 then
    l_30_10.nUiId = l_30_9.nUiId
    l_30_10.szName = l_30_9.szName
    l_30_10.nVersion = 1
    l_30_10.nBookID = l_30_3
    l_30_10.dwTabType = l_30_0
    l_30_10.bCanStack = l_30_9.bCanStack
    l_30_10.nStackNum = l_30_2
    l_30_10.nGenre = l_30_9.nGenre
    l_30_10.nQuality = l_30_9.nQuality
    if not BF_MailHelp.mySearchKey then
      BF_MailHelp.mySearchKey = ""
    end
    if not BF_MailHelp.myAllXuanzeType then
      BF_MailHelp.myAllXuanzeType = "��ʾȫ���ż�"
    end
    l_30_5 = (l_30_5 - GetTime()) / 1000
     -- DECOMPILER ERROR: unhandled construct in 'if'

    if BF_MailHelp.myAllXuanzeType == "���������ż�" and l_30_5 > 86400 then
      return false
    end
    do return end
    if BF_MailHelp.myAllXuanzeType == "�޷����ŵ��ż�" and l_30_6 == MAIL_TYPE.PLAYER and (l_30_7 or l_30_8) then
      return false
    end
    if BF_MailHelp.mySearchKey ~= "" then
      if string.find(l_30_10.szName, BF_MailHelp.mySearchKey) then
        return l_30_10
      end
    end
    do return end
    return false
    return l_30_10
  else
    return false
  end
end

BF_MailHelp.GetBoxBYnumber = function(l_31_0, l_31_1)
  if 98 * l_31_1 < l_31_0 then
    return false
  else
    if l_31_0 < 98 * (l_31_1 - 1) then
      return false
    end
  else
    local l_31_2 = l_31_0 - 98 * (l_31_1 - 1)
    local l_31_3 = BF_MailHelp.handleBox:Lookup(l_31_2 - 1)
    if l_31_3 then
      return l_31_3
    end
  end
  do return end
  return false
end

BF_MailHelp.OnFrameBreathe = function()
end

BF_MailHelp.OnFrameShow = function()
  local l_33_0 = Station.Lookup("Normal/BF_MailHelp")
  local l_33_1 = l_33_0:Lookup("CheckBox_ShowTipInfo")
  l_33_1:Check(BF_MailHelp.BShowTipInfo)
end

BF_MailHelp.OnEditChanged = function()
  local l_34_0 = GetKeyName(Station.GetMessageKey())
  local l_34_1 = this:GetParent():Lookup("Edit_Search")
  local l_34_2 = l_34_1:GetText()
  BF_MailHelp.mySearchKey = l_34_2
  BF_MailHelp.pagenumber = 1
  BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
end

BF_MailHelp.OnLButtonClick = function()
  local l_35_0 = this:GetName()
  if l_35_0 == "Btn_Close" then
    BigFoot_3fe89d2cba7135865e0fa62fb7ce77b2()
  elseif l_35_0 == "Btn_Up" then
    BF_MailHelp.pagenumber = BF_MailHelp.pagenumber - 1
    if BF_MailHelp.pagenumber < 1 then
      BF_MailHelp.pagenumber = 1
    end
    BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
  elseif l_35_0 == "Btn_Down" then
    BF_MailHelp.pagenumber = BF_MailHelp.pagenumber + 1
    if BF_MailHelp.CurrentPageNumber < BF_MailHelp.pagenumber then
      BF_MailHelp.pagenumber = BF_MailHelp.CurrentPageNumber
    end
    BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
  elseif l_35_0 == "Btn_Shaixuan" then
    local l_35_1 = Station.Lookup("Normal/BF_MailHelp")
    do
      local l_35_2 = l_35_1:Lookup("", "Text_Shaixuan")
      if l_35_2 then
        local l_35_3, l_35_4 = l_35_2:GetAbsPos()
        local l_35_5, l_35_6 = l_35_2:GetSize()
        local l_35_7 = {}
        l_35_7.nMiniWidth = l_35_5
        l_35_7.x = l_35_3
        l_35_7.y = l_35_4 + l_35_6
        l_35_7.fnAction = function(l_36_0, l_36_1)
          -- upvalues: l_35_2
          l_35_2:SetText(l_36_0)
        end
        l_35_7.fnAutoClose = function()
          return false
        end
        for l_35_11,l_35_12 in pairs(BF_MailHelp.myXuanzeList) do
          local l_35_13 = table.insert
          local l_35_14 = l_35_7
          local l_35_15 = {}
          l_35_15.szOption = l_35_12
          l_35_15.UserData = l_35_12
          l_35_13(l_35_14, l_35_15)
        end
        PopupMenu(l_35_7)
      end
    end
  elseif l_35_0 == "Btn_AllShaixuan" then
    local l_35_16 = Station.Lookup("Normal/BF_MailHelp")
    local l_35_17 = l_35_16:Lookup("", "Text_AllShaixuan")
    if l_35_17 then
      local l_35_18, l_35_19 = l_35_17:GetAbsPos()
      local l_35_20, l_35_21 = l_35_17:GetSize()
      local l_35_22 = {}
      l_35_22.nMiniWidth = l_35_20
      l_35_22.x = l_35_18
      l_35_22.y = l_35_19 + l_35_21
      l_35_22.fnAction = function(l_38_0, l_38_1)
        -- upvalues: l_35_2
        l_35_2:SetText(l_38_0)
        BF_MailHelp.pagenumber = 1
        BF_MailHelp.myAllXuanzeType = l_38_0
        BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
      end
      l_35_22.fnAutoClose = function()
        return false
      end
      for l_35_26,l_35_27 in pairs(BF_MailHelp.myAllXuanzeList) do
        local l_35_28 = table.insert
        local l_35_29 = l_35_22
        local l_35_30 = {}
        l_35_30.szOption = l_35_27
        l_35_30.UserData = l_35_27
        l_35_28(l_35_29, l_35_30)
      end
      PopupMenu(l_35_22)
    end
  elseif l_35_0 == "Btn_Zhanghao" then
    local l_35_31 = Station.Lookup("Normal/BF_MailHelp")
    local l_35_32 = l_35_31:Lookup("", "Text_Zhanghao")
    if l_35_32 then
      local l_35_33, l_35_34 = l_35_32:GetAbsPos()
      local l_35_35, l_35_36 = l_35_32:GetSize()
      local l_35_37 = {}
      l_35_37.nMiniWidth = l_35_35
      l_35_37.x = l_35_33
      l_35_37.y = l_35_34 + l_35_36
      l_35_37.fnAction = function(l_40_0, l_40_1)
        local l_40_2 = {}
        l_40_2.szName = "�ʼ��ֿ�"
        l_40_2.szMessage = " ���ڴ������ʼ�, �����ʼ������Ʒ��Ϣ�����������ʼ���Ϣ"
        l_40_2.fnCancelAction = function()
        end
        local l_40_3 = {}
        l_40_3.szOption = "ȷ��"
        l_40_3.fnAction = function()
          -- upvalues: l_5_0
          BF_MailHelp.OpenOffLineMailDefauit(l_5_0)
        end
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        Msg = l_40_2
        l_40_2 = MessageBox
        l_40_3 = Msg
        l_40_2(l_40_3)
      end
      l_35_37.fnAutoClose = function()
        return false
      end
      local l_35_38 = BF_MailHelp.CheckMailDate()
      for l_35_42,l_35_43 in pairs(l_35_38) do
        local l_35_44 = table.insert
        local l_35_45 = l_35_37
        local l_35_46 = {}
        l_35_46.szOption = l_35_43.name
        l_35_46.UserData = l_35_43.date
        l_35_44(l_35_45, l_35_46)
      end
      PopupMenu(l_35_37)
    end
  elseif l_35_0 == "Btn_ZhanghaoShanchu" then
    BF_MailHelp.DelzhanghaoDateFuc()
  end
end

BF_MailHelp.DelzhanghaoDateFuc = function()
  -- upvalues: l_0_0
  local l_36_0 = {}
  l_36_0.fnAction = function(l_37_0, l_37_1)
    -- upvalues: l_0_0
    local l_37_2 = {}
    l_37_2.szName = "�ʼ��ֿ�"
    l_37_2.szMessage = " ȷ��ɾ�������ɫ�����ݣ�"
    l_37_2.fnCancelAction = function()
    end
    local l_37_3 = {}
    l_37_3.szOption = "ȷ��"
    l_37_3.fnAction = function()
      -- upvalues: l_1_0 , l_0_0
      if BF_MailHelp.MailDate[l_1_0[1]] and BF_MailHelp.MailDate[l_1_0[1]][l_1_0[2]] then
        BF_MailHelp.MailDate[l_1_0[1]][l_1_0[2]] = nil
        l_0_0("��ǰ�˺��µ�<" .. l_1_0[2] .. ">��ɫ�ʼ����ݱ����")
      end
    end
    local l_37_4 = {}
    l_37_4.szOption = "ȡ��"
    l_37_4.fnAction = function()
    end
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    Msg = l_37_2
    l_37_2 = MessageBox
    l_37_3 = Msg
    l_37_2(l_37_3)
  end
  l_36_0.fnAutoClose = function()
    return false
  end
  do
    local l_36_1 = BF_MailHelp.CheckMailDate()
    for l_36_5,l_36_6 in pairs(l_36_1) do
      local l_36_7 = table.insert
      local l_36_8 = l_36_0
      local l_36_9 = {}
      l_36_9.szOption = l_36_6.name
      local l_36_10 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_36_7(l_36_8, l_36_9)
    end
    PopupMenu(l_36_0)
  end
   -- WARNING: undefined locals caused missing assignments!
end

BF_MailHelp.OpenOffLineMailDefauit = function(l_37_0)
  -- upvalues: l_0_1
  BF_MailHelp.MYItemDate = nil
  BF_MailHelp.pagenumber = 1
  BF_MailHelp.bObline = false
  if not l_37_0 then
    local l_37_1 = GetClientPlayer()
    local l_37_2, l_37_3 = l_0_1()
    local l_37_4 = BF_MailHelp.MailDate[l_37_3]
    local l_37_5 = nil
    if l_37_4 then
      l_37_5 = l_37_4[l_37_1.szName]
    end
    if l_37_5 then
      BF_MailHelp.MYItemDate = l_37_5
    end
  else
    BF_MailHelp.MYItemDate = l_37_0
  end
  BigFoot_fd94df882a4b49258e3186e780ef5d26()
  BF_MailHelp.UpdateBoxItem(BF_MailHelp.MYItemDate, BF_MailHelp.pagenumber)
end

BF_MailHelp.CheckMailDate = function()
  local l_38_0 = {}
  do break end
  do
    local l_38_1, l_38_2, l_38_3, l_38_4, l_38_5 = pairs(BF_MailHelp.MailDate)
    for l_38_9,l_38_10 in pairs(l_38_5) do
      local l_38_11 = table.insert
      local l_38_12 = l_38_0
      local l_38_13 = {}
      l_38_13.server = l_38_4
      l_38_13.name = l_38_9
      l_38_13.date = l_38_10
      l_38_11(l_38_12, l_38_13)
    end
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers!

return l_38_0
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

BigFoot_fd94df882a4b49258e3186e780ef5d26 = function()
  local l_39_0 = Station.Lookup("Normal/BF_MailHelp")
  if l_39_0 then
    l_39_0:Show()
  else
    l_39_0 = Wnd.OpenWindow("Interface\\BF_MailHelp\\BF_MailHelp.ini", "BF_MailHelp")
  end
  l_39_0:SetDragArea(0, 0, 400, 20)
  l_39_0:BringToTop()
end

BigFoot_3fe89d2cba7135865e0fa62fb7ce77b2 = function()
  local l_40_0 = Station.Lookup("Normal/BF_MailHelp")
  if l_40_0 then
    l_40_0:Hide()
  end
  BF_MailHelp.bObline = false
end

BigFoot_4f7315bb64d3054297d89684c8033e9b = function()
  local l_41_0 = Station.Lookup("Normal/BF_MailHelp")
  local l_41_1 = Station.Lookup("Normal/BF_MailHelp")
  if l_41_1 and l_41_1:IsVisible() then
    return true
  end
  return false
end

BigFoot_fd94df882a4b49258e3186e780ef5d26()
BigFoot_3fe89d2cba7135865e0fa62fb7ce77b2()
BFConfigPanel.RegisterMod("MailHelp", "�ʼ�����", "\\ui\\image\\icon\\skill_wanhua_jiexue.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("MailHelp", "EnableMailHelp", "�����ʼ�����", true, function(l_42_0, l_42_1)
  BF_MailHelp.EnableMailHelp = l_42_0
  if l_42_0 and BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5 then
    BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Station.Lookup("Normal/BigBagPanel")
    BigFoot_501f4ced3ddc79c3b6c356708976f663 = BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:GetAbsPos()
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", BigFoot_501f4ced3ddc79c3b6c356708976f663 + 120, BigFoot_26ce521b077c8ab0ce51b62c48c0b6c3 + 2)
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:Show()
  end
  do return end
  if BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5 then
    BF_MailHelp.BigFoot_2fccb5df73f6c431451c4e5b55054af5:Hide()
  end
end
)

