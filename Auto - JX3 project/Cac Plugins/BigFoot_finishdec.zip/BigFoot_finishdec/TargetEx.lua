-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetEx.lua 

local l_0_0 = {}
l_0_0.bIsEnemy = false
l_0_0.nBuffMax = 16
l_0_0.nDebuffMax = 16
l_0_0.nBuffSize = 30
l_0_0.bShieldOthersBuff = false
l_0_0.bShowTTBuffTime = false
l_0_0.bShowChannel = true
l_0_0.bShowSpecialBuff = true
l_0_0.bTopLeftBuffTime = false
l_0_0.tChannelList = {}
local l_0_1 = {}
l_0_1[570] = 80
l_0_1[7319] = 96
l_0_1[2724] = 40
l_0_1[3100] = 48
l_0_1[1645] = 84
l_0_1[7320] = 128
l_0_1[2674] = 8
l_0_1[2707] = 48
l_0_1[2589] = 96
l_0_1[7317] = 48
l_0_1[3093] = 40
l_0_1[7318] = 64
l_0_1[565] = 48
l_0_1[567] = 160
l_0_1[2233] = 80
l_0_1[2235] = 128
l_0_1[368] = 80
l_0_1[300] = 80
l_0_1[2636] = 80
l_0_1[7314] = 32
l_0_1[368] = 80
l_0_0.tChannelSkill = l_0_1
TargetEx = l_0_0
l_0_0 = TargetEx
local l_0_2 = 910
l_0_2 = 911
l_0_2 = 912
l_0_2 = 913
l_0_2 = 914
l_0_2 = 915
l_0_2 = 916
l_0_2 = 917
l_0_2 = 918
l_0_2 = 919
l_0_2 = 1001
l_0_2 = 1101
l_0_2 = 1102
l_0_2 = 1103
l_0_2 = 1104
l_0_2 = 1105
l_0_2 = 1106
l_0_2 = 1107
l_0_2 = 1108
l_0_2 = 1109
l_0_2 = 1110
l_0_2 = 1111
l_0_2 = 1112
l_0_0.tSpecialBuffList_Common, l_0_1 = l_0_1, {[1] = 730, [2] = 1903, [3] = 374, [4] = 411, [5] = 2781, [6] = 1186, [7] = 855, [8] = 2756, [9] = 2847, [10] = 1676, [11] = 1856, [12] = 2544, [13] = 3822, [14] = 2840, [15] = 3275, [16] = 3279, [17] = 2315, [100] = 1802, [101] = 367, [102] = 360, [103] = 2177, [104] = 122, [105] = 399, [106] = 2983, [108] = 684, [109] = 2542, [110] = 3068, [111] = 2953, [112] = 2849, [113] = 3315, [114] = 3274, [115] = 3214, [116] = 1187, [200] = 2726, [201] = 2757, [202] = 3276, [203] = 3858, [204] = 3859, [205] = 2704, [206] = 3316, [207] = 1911, [208] = 1913, [209] = 1915, [210] = 1916, [211] = 1917, [212] = 1919, [213] = 1921, [214] = 1722, [215] = 1922, [216] = 3028, [217] = 3487, [218] = 3488, [300] = 213, [400] = 377, [401] = 3851, [402] = 3425, [403] = 772, [404] = 961, [501] = 388, [502] = 389, [503] = 390, [504] = 2792, [505] = 2793, [506] = 2794, [507] = 2795, [508] = 2796, [509] = 2797, [600] = 854, [601] = 1242, [602] = 203, [603] = 126, [604] = 198, [605] = 2763, [606] = 2765, [701] = 1801, [702] = 1931, [703] = 1937, [704] = 558, [705] = 2290, [706] = 2289, [707] = 749, [708] = 2799, [709] = 2492, [710] = 2504, [711] = 2547, [712] = 3359, [801] = 1857, [802] = 554, [803] = 1229, [804] = 2834, [805] = 556, [806] = 675, [807] = 685, [808] = 1247, [809] = 686, [810] = 1936, [811] = 2311, [812] = 737, [901] = 1721, [902] = 1904, [903] = 1927, [904] = 1902, [905] = 548, [906] = 727, [907] = 2275, [908] = 2877, [909] = 2755, [l_0_2] = 2780, [l_0_2] = 682, [l_0_2] = 2489, [l_0_2] = 2522, [l_0_2] = 3223, [l_0_2] = 3224, [l_0_2] = 464, [l_0_2] = 569, [l_0_2] = 572, [l_0_2] = 740, [l_0_2] = 994, [l_0_2] = 726, [l_0_2] = 2182, [l_0_2] = 557, [l_0_2] = 585, [l_0_2] = 712, [l_0_2] = 690, [l_0_2] = 2838, [l_0_2] = 2490, [l_0_2] = 2807, [l_0_2] = 3227, [l_0_2] = 445, [l_0_2] = 734}
l_0_0 = TargetEx
l_0_1 = "tSpecialBuffList_Physics"
local l_0_3 = 1
l_0_3 = 2
l_0_3 = 101
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = 2065, [l_0_3] = 677, [l_0_3] = 1730}
l_0_0 = TargetEx
l_0_1 = "tSpecialBuffList_Magic"
l_0_3 = 1
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = 2805}
l_0_0 = TargetEx
l_0_1 = "tSpecialBuffList_Lethal"
l_0_3 = 1
l_0_3 = 2
l_0_3 = 3
l_0_3 = 4
l_0_3 = 5
l_0_3 = 6
l_0_0[l_0_1], l_0_2 = l_0_2, {[l_0_3] = 2774, [l_0_3] = 574, [l_0_3] = 2496, [l_0_3] = 2502, [l_0_3] = 3195, [l_0_3] = 576}
l_0_0 = TargetEx
l_0_1 = "bPhysics"
l_0_2 = function()
  local l_1_0 = GetClientPlayer()
  do
    if l_1_0 then
      local l_1_1 = l_1_0.GetKungfuMount().dwSkillID
    if l_1_1 ~= 10026 and l_1_1 ~= 10062 and l_1_1 ~= 10015 and l_1_1 ~= 10144 and l_1_1 ~= 10145 then
      end
    if l_1_1 ~= 10026 then
      end
    end
    return true
  end
  return false
end

l_0_0[l_0_1] = l_0_2
l_0_0 = TargetEx
l_0_1 = "IsSpecialBuff"
l_0_2 = function(l_2_0, l_2_1)
  if not TargetEx.bShowSpecialBuff then
    return false
  end
  local l_2_2 = GetClientPlayer().GetKungfuMount().dwSkillID
  if l_2_2 and (l_2_2 == 10021 or l_2_2 == 10028) and (l_2_0 == 886 or l_2_0 == 1674) then
    return true
  elseif l_2_2 and (l_2_2 == 10144 or l_2_2 == 10145) and (l_2_0 == 512 or l_2_0 == 1738) then
    return true
  elseif l_2_2 and l_2_2 == 10080 and l_2_0 == 1727 then
    return true
  elseif l_2_2 and l_2_2 == 10176 and (l_2_0 == 2316 or l_2_0 == 2313) then
    return true
  elseif l_2_2 and l_2_2 == 10175 and (l_2_0 == 2313 or l_2_0 == 2494 or l_2_0 == 2495) then
    return true
  elseif l_2_2 and (l_2_2 == 10224 or l_2_2 == 10225) and l_2_0 == 3253 then
    return true
  end
  if l_2_1 == TARGET.PLAYER then
    for l_2_6,l_2_7 in pairs(TargetEx.tSpecialBuffList_Lethal) do
      if l_2_0 == l_2_7 then
        return true
      end
    end
  end
  for l_2_11,l_2_12 in pairs(TargetEx.tSpecialBuffList_Common) do
    if l_2_0 == l_2_12 then
      return true
    end
  end
  if TargetEx.bPhysics() then
    for l_2_16,l_2_17 in pairs(TargetEx.tSpecialBuffList_Physics) do
      if l_2_0 == l_2_17 then
        return true
      end
    end
    do break end
  end
  for l_2_21,l_2_22 in pairs(TargetEx.tSpecialBuffList_Magic) do
    if l_2_0 == l_2_22 then
      return true
    end
  end
  return false
end

l_0_0[l_0_1] = l_0_2
l_0_0 = "Interface\\BF_TargetEx\\TargetEx.ini"
l_0_1 = "ui/config/default/TargetCommon.ini"
local l_0_4, l_0_5, l_0_6 = nil, nil, nil
local l_0_7 = TargetEx
local l_0_8 = "HideSystemTargetBuff"
l_0_7[l_0_8] = function(l_3_0)
  local l_3_1 = l_3_0:Lookup("", "")
  local l_3_2 = l_3_1:Lookup("Handle_Buff")
  local l_3_3 = l_3_1:Lookup("Handle_TextBuff")
  local l_3_4 = l_3_1:Lookup("Handle_Debuff")
  local l_3_5 = l_3_1:Lookup("Handle_TextDebuff")
  local l_3_6 = l_3_1:Lookup("Image_BuffBG")
  local l_3_7 = l_3_1:Lookup("Image_DebuffBG")
  l_3_2:Hide()
  l_3_3:Hide()
  l_3_4:Hide()
  l_3_5:Hide()
  l_3_6:Hide()
  l_3_7:Hide()
end

l_0_7 = TargetEx
l_0_8 = "AdjustAllItems"
l_0_7[l_0_8] = function(l_4_0)
  local l_4_1 = l_4_0:Lookup("", "")
  local l_4_2 = l_4_1:Lookup("Handle_Bar")
  local l_4_3, l_4_4 = l_4_1:GetAbsPos()
  l_4_2:SetAbsPos(l_4_3 + 82, l_4_4 + 78)
  if not nil then
    local l_4_9, l_4_15, l_4_22, l_4_26, l_4_30, l_4_35, l_4_40 = nil, nil, nil, l_4_1:AppendItemFromIni("Interface/BF_TargetEx/TargetEx.ini", "Image_Mana_New")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_4_9 then
    local l_4_5, l_4_6, l_4_10, l_4_12, l_4_16, l_4_19, l_4_23, l_4_27, l_4_31, l_4_32, l_4_37 = l_4_1:AppendItemFromIni("Interface/BF_TargetEx/TargetEx.ini", "Text_Health_New")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_4_6 then
    local l_4_7, l_4_11, l_4_13, l_4_17, l_4_20, l_4_24, l_4_28, l_4_33, l_4_38 = , l_4_1:AppendItemFromIni("Interface/BF_TargetEx/TargetEx.ini", "Text_Mana_New")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_4_13 then
    local l_4_8, l_4_14, l_4_18, l_4_21, l_4_25, l_4_29, l_4_34, l_4_39 = , l_4_1:AppendItemFromIni("Interface/BF_TargetEx/TargetEx.ini", "Text_Target_New")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_4_0.dwType == TARGET.PLAYER then
    l_4_8:SetAbsPos(l_4_3 + 87, l_4_4 + 46)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_14:SetAbsPos(l_4_3 + 107, l_4_4 + 62)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_18:SetAbsPos(l_4_3 + 110, l_4_4 + 21)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_21:SetAbsPos(l_4_3 + 106, l_4_4 + 63)
  else
    if l_4_0.dwType == TARGET.NPC then
      local l_4_36 = nil
      if l_4_0.nIntensity == 1 then
        l_4_36:SetAbsPos(l_4_3 + 90, l_4_4 + 50)
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_4_14:SetAbsPos(l_4_3 + 110, l_4_4 + 63)
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_4_18:SetAbsPos(l_4_3 + 110, l_4_4 + 22)
      end
    end
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_4_0.nIntensity == 2 then
    l_4_36:SetAbsPos(l_4_3 + 200, l_4_4 + 50)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_14:SetAbsPos(l_4_3 + 107, l_4_4 + 63)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_18:SetAbsPos(l_4_3 + 210, l_4_4 + 22)
   -- DECOMPILER ERROR: Confused about usage of registers!

  elseif l_4_0.nIntensity == 3 then
    l_4_36:SetAbsPos(l_4_3 + 230, l_4_4 + 50)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_14:SetAbsPos(l_4_3 + 107, l_4_4 + 63)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_18:SetAbsPos(l_4_3 + 250, l_4_4 + 22)
  else
    l_4_36:SetAbsPos(l_4_3 + 220, l_4_4 + 48)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_14:SetAbsPos(l_4_3 + 107, l_4_4 + 63)
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_4_18:SetAbsPos(l_4_3 + 240, l_4_4 + 22)
  end
  local l_4_41 = nil
  local l_4_42 = nil
  Station.Lookup("Normal/TargetEx"):Lookup("", ""):SetAbsPos(l_4_3 + 90, l_4_4 + 96)
end

l_0_7 = TargetEx
l_0_8 = "FixTargetBgImage"
l_0_7[l_0_8] = function(l_5_0)
  local l_5_1 = l_5_0:Lookup("", "")
  local l_5_2 = l_5_1:Lookup("Image_FBgC")
  local l_5_3 = l_5_1:Lookup("Image_FBgCR")
  local l_5_4 = l_5_1:Lookup("Image_FBgCRR")
  local l_5_5 = l_5_1:Lookup("Image_FBgR")
  local l_5_6 = l_5_1:Lookup("Image_FBgL")
  if l_5_0.dwType == TARGET.NPC then
    return 
  end
  if l_5_0.dwMountType == 6 or l_5_0.dwMountType == 10 then
    if not IsEnemy(l_5_0.dwID, UI_GetClientPlayerID()) then
      l_5_2:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 30)
      l_5_3:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 16)
      l_5_4:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 24)
      l_5_5:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 17)
      l_5_6:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 4)
    end
  else
    l_5_2:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 29)
    l_5_3:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 13)
    l_5_4:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 22)
    l_5_5:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 19)
    l_5_6:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 5)
  end
end

l_0_7 = TargetEx
l_0_8 = "FixTargetTextAndImage"
l_0_7[l_0_8] = function(l_6_0)
  local l_6_1 = l_6_0:Lookup("", "")
  local l_6_2 = l_6_1:Lookup("Text_Health")
  local l_6_3 = l_6_1:Lookup("Text_Mana")
  local l_6_4 = l_6_1:Lookup("Image_Mana")
  local l_6_5 = l_6_1:Lookup("Text_Target")
  l_6_2:SetAlpha(0)
  l_6_3:SetAlpha(0)
  l_6_5:SetAlpha(0)
  if l_6_0.dwType == TARGET.PLAYER then
    l_6_4:SetAlpha(0)
  end
end

l_0_7 = TargetEx
l_0_8 = "AdjustBuffTextPos"
l_0_7[l_0_8] = function()
  -- upvalues: l_0_5 , l_0_4 , l_0_6
  local l_7_0 = Station.Lookup("Normal/TargetEx")
  local l_7_1 = l_7_0:Lookup("", "")
  local l_7_2, l_7_3 = l_7_1:GetAbsPos()
  if TargetEx.bTopLeftBuffTime then
    l_0_5:SetAbsPos(l_7_2, l_7_3 + TargetEx.nBuffSize + 5)
  else
    l_0_4:SetAbsPos(l_7_2, l_7_3 + TargetEx.nBuffSize + 5)
    l_0_5:SetAbsPos(l_7_2, l_7_3 + TargetEx.nBuffSize + 20)
    l_0_6:SetAbsPos(l_7_2, l_7_3 + 2 * TargetEx.nBuffSize + 25)
  end
end

l_0_7 = TargetEx
l_0_8 = "GetLeftTime"
l_0_7[l_0_8] = function(l_8_0)
  local l_8_1 = ""
  local l_8_2 = 162
  local l_8_3 = GetLogicFrameCount()
  local l_8_4 = l_8_0 - l_8_3
  local l_8_5, l_8_6, l_8_7 = GetTimeToHourMinuteSecond(l_8_4, true)
  if l_8_5 >= 2 then
    l_8_1 = ""
  elseif l_8_5 >= 1 then
    if l_8_6 >= 1 or l_8_7 >= 1 then
      l_8_5 = l_8_5 + 1
    end
    l_8_1 = l_8_5 .. ""
    l_8_2 = 7
  elseif l_8_6 >= 1 then
    if l_8_7 >= 1 then
      l_8_6 = l_8_6 + 1
    end
    l_8_1 = l_8_6 .. "'"
    l_8_2 = 16
  elseif l_8_6 < 1 then
    if l_8_7 > 5 then
      l_8_1 = l_8_7 .. "''"
      l_8_2 = 16
    end
  else
    l_8_1 = l_8_7 .. "''"
    l_8_2 = 159
  end
  return l_8_1, l_8_2, l_8_4
end

l_0_7 = TargetEx
l_0_8 = "OnFrameCreate"
l_0_7[l_0_8] = function()
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
  TargetEx.Init(this)
end

l_0_7 = TargetEx
l_0_8 = "Init"
l_0_7[l_0_8] = function(l_10_0)
  -- upvalues: l_0_2 , l_0_3 , l_0_4 , l_0_5 , l_0_6
  l_0_2 = l_10_0:Lookup("", "")
  l_0_3 = l_0_2:Lookup("Handle_Buff")
  l_0_4 = l_0_2:Lookup("Handle_TextBuff")
  l_0_5 = l_0_2:Lookup("Handle_Debuff")
  l_0_6 = l_0_2:Lookup("Handle_TextDebuff")
  l_0_3:Clear()
  l_0_4:Clear()
  l_0_5:Clear()
  l_0_6:Clear()
  l_0_3.tItem = {}
  l_0_3.nNeedBox = 0
  l_0_5.nNeedBox = 0
  l_0_4.tItem = {}
  l_0_5.tItem = {}
  l_0_6.tItem = {}
end

l_0_7 = TargetEx
l_0_8 = "nBreatheCount"
l_0_7[l_0_8] = 0
l_0_7 = TargetEx
l_0_8 = "OnFrameBreathe"
l_0_7[l_0_8] = function()
  -- upvalues: l_0_3 , l_0_5 , l_0_4 , l_0_6
  local l_11_0 = Station.Lookup("Normal/Target")
  if not l_11_0 or not l_11_0:IsVisible() then
    return 
  end
  TargetEx.UpdateName(l_11_0)
  TargetEx.UpdateAction(l_11_0)
  TargetEx.UpdateLM(l_11_0)
  TargetEx.nBreatheCount = TargetEx.nBreatheCount + 1
  if TargetEx.nBreatheCount == 3 then
    TargetEx.nBreatheCount = 0
  else
    return 
  end
  if l_11_0 and not l_11_0:IsVisible() and (l_0_3:IsVisible() or l_0_5:IsVisible()) then
    l_0_3:Clear()
    l_0_4:Clear()
    l_0_5:Clear()
    l_0_6:Clear()
  end
  TargetEx.UpdateBufferTime(l_0_3, l_0_4)
  TargetEx.UpdateBufferTime(l_0_5, l_0_6)
end

l_0_7 = TargetEx
l_0_8 = "OnFrameDragEnd"
l_0_7[l_0_8] = function()
  this:CorrectPos()
  TargetEx.Anchor = GetFrameAnchor(this)
end

l_0_7 = TargetEx
l_0_8 = "UpdateAnchor"
l_0_7[l_0_8] = function(l_13_0)
  l_13_0:SetPoint(TargetEx.Anchor.s, 0, 0, TargetEx.Anchor.r, TargetEx.Anchor.x, TargetEx.Anchor.y)
  l_13_0:CorrectPos()
end

l_0_7 = function(l_14_0, l_14_1)
  local l_14_2 = nil
  if l_14_0 == TARGET.PLAYER then
    if not l_14_2 then
      return 
    end
     -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    if l_14_0 == TARGET.NPC then
      if not l_14_2 then
        return 
      end
       -- DECOMPILER ERROR: Overwrote pending register.

    end
  end
  if l_14_2.dwEmployer ~= 0 then
    local l_14_3 = ""
    if not GetPlayer(l_14_2.dwEmployer) then
      l_14_3 = g_tStrings.STR_SOME_BODY .. g_tStrings.STR_PET_SKILL_LOG .. l_14_2.szName
    end
  else
    l_14_3 = GetPlayer(l_14_2.dwEmployer).szName .. g_tStrings.STR_PET_SKILL_LOG .. l_14_2.szName
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_14_3
end

l_0_8 = TargetEx
local l_0_9 = "UpdateName"
l_0_8[l_0_9] = function(l_15_0)
  -- upvalues: l_0_7
  local l_15_1 = GetClientPlayer()
  if not l_15_1 then
    return 
  end
  local l_15_2 = GetTargetHandle(l_15_0.dwType, l_15_0.dwID)
  local l_15_3 = l_15_0:Lookup("", "Text_Target_New")
  l_15_3:SetFontColor(GetForceFontColor(l_15_0.dwID, l_15_1.dwID))
  local l_15_4 = l_0_7(l_15_0.dwType, l_15_0.dwID)
  if l_15_2 then
    local l_15_5 = "%.1f":format(GetCharacterDistance(l_15_1.dwID, l_15_0.dwID) / 64)
    local l_15_6 = ""
    if l_15_0.dwType == TARGET.PLAYER then
      if not l_15_2.GetKungfuMount() then
        local l_15_7, l_15_8, l_15_9 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_15_7 then
        l_15_6 = l_15_6 .. Table_GetSkillName(l_15_7.dwSkillID, 0)
        l_15_6 = "��" .. string.sub(l_15_6, 0, 4)
      end
      if l_15_0.dwID == l_15_1.dwID then
        l_15_3:SetText(l_15_4 .. l_15_6)
      else
        l_15_3:SetText(l_15_5 .. "��" .. l_15_4 .. l_15_6)
      end
    else
      l_15_3:SetText(l_15_5 .. "��" .. l_15_4)
    end
  else
    l_15_3:SetText("")
  end
end

l_0_8 = TargetEx
l_0_9 = "UpdateLM"
l_0_8[l_0_9] = function(l_16_0)
  local l_16_1 = GetTargetHandle(l_16_0.dwType, l_16_0.dwID)
  local l_16_2 = l_16_0:Lookup("", "")
  local l_16_3 = l_16_2:Lookup("Text_Health_New")
  local l_16_4 = l_16_2:Lookup("Text_Mana_New")
  local l_16_5 = l_16_2:Lookup("Image_Mana_New")
  local l_16_6 = ""
  local l_16_7 = ""
  local l_16_8 = 0
  local l_16_9 = 0
  if l_16_0.dwType == TARGET.PLAYER then
    if l_16_0.dwMountType == 6 then
      l_16_5:SetFrame(86)
    elseif l_16_0.dwMountType == 10 then
      l_16_5:SetFrame(87)
    else
      l_16_5:SetFrame(37)
    end
    l_16_5:Show()
  else
    l_16_5:Hide()
  end
  if l_16_1 then
    if l_16_1.nMaxLife > 0 then
      l_16_8 = l_16_1.nCurrentLife / l_16_1.nMaxLife
      l_16_6 = TargetEx.GetStateString(l_16_1.nCurrentLife, l_16_1.nMaxLife, l_16_0.dwType, true)
    end
    if l_16_0.dwType == TARGET.PLAYER then
      if l_16_0.dwMountType == 6 then
        l_16_9 = l_16_1.nCurrentRage / l_16_1.nMaxRage
        l_16_7 = l_16_1.nCurrentRage .. "/" .. l_16_1.nMaxRage
      end
    elseif l_16_0.dwMountType == 10 then
      l_16_9 = l_16_1.nCurrentEnergy / l_16_1.nMaxEnergy
      l_16_7 = l_16_1.nCurrentEnergy .. "/" .. l_16_1.nMaxEnergy
    elseif l_16_1.nMaxMana > 0 and l_16_1.nMaxMana ~= 1 then
      l_16_9 = l_16_1.nCurrentMana / l_16_1.nMaxMana
      l_16_7 = TargetEx.GetStateString(l_16_1.nCurrentMana, l_16_1.nMaxMana, l_16_0.dwType, true)
    end
  elseif l_16_1.nMaxMana > 0 and l_16_1.nMaxMana ~= 1 then
    l_16_9 = l_16_1.nCurrentMana / l_16_1.nMaxMana
    l_16_7 = TargetEx.GetStateString(l_16_1.nCurrentMana, l_16_1.nMaxMana, l_16_0.dwType, true, "npc")
  end
  l_16_5:SetPercentage(l_16_9)
  l_16_3:SetText(l_16_6)
  l_16_3:Show()
  l_16_4:SetText(l_16_7)
  l_16_4:Show()
end

l_0_8 = TargetEx
l_0_9 = "GetStateString"
l_0_8[l_0_9] = function(l_17_0, l_17_1, l_17_2, l_17_3, l_17_4)
  local l_17_5 = ""
  local l_17_6 = ""
  if l_17_2 == TARGET.PLAYER then
    l_17_6 = math.floor(100 * l_17_0 / l_17_1) .. "%"
  else
    if l_17_2 == TARGET.NPC then
      l_17_6 = "%.2f":format(100 * l_17_0 / l_17_1) .. "%"
    end
  end
  if l_17_1 >= 100000000 then
    if l_17_0 >= 100000000 then
      l_17_5 = math.floor(l_17_0 / 100000000) .. "��" .. math.floor(l_17_0 / 100000000 % 1 * 10000) .. "��/" .. math.floor(l_17_1 / 100000000) .. "��" .. math.floor(l_17_1 / 100000000 % 1 * 10000) .. "��"
    elseif l_17_0 >= 100000 then
      l_17_5 = math.floor(l_17_0 / 10000) .. "��/" .. math.floor(l_17_1 / 100000000) .. "��" .. math.floor(l_17_1 / 100000000 % 1 * 10000) .. "��"
    else
      l_17_5 = l_17_0 .. "/" .. math.floor(l_17_1 / 100000000) .. "��" .. math.floor(l_17_1 / 100000000 % 1 * 10000) .. "��"
    end
  elseif l_17_1 >= 100000 then
    if l_17_0 >= 100000 then
      l_17_5 = math.floor(l_17_0 / 10000) .. "��/" .. math.floor(l_17_1 / 10000) .. "��"
    else
      l_17_5 = math.floor(l_17_0) .. "/" .. math.floor(l_17_1 / 10000) .. "��"
    end
  else
    l_17_5 = l_17_0 .. "/" .. l_17_1
  end
  if l_17_3 then
    l_17_5 = l_17_5 .. "(" .. l_17_6 .. ")"
  end
  if l_17_4 and l_17_4 == "npc" then
    l_17_5 = ""
  end
  return l_17_5
end

l_0_8 = TargetEx
l_0_9 = "UpdateAction"
l_0_8[l_0_9] = function(l_18_0)
  local l_18_1 = GetTargetHandle(l_18_0.dwType, l_18_0.dwID)
  local l_18_2 = l_18_0:Lookup("", "Handle_Bar")
  if not l_18_1 then
    l_18_2:Hide()
    return 
  end
  if l_18_0.dwType == TARGET.PLAYER and l_18_1.GetOTActionState() == 2 then
    local l_18_3, l_18_4, l_18_5 = TargetEx.GetSkillChannelState(l_18_0.dwID)
  end
  if l_18_3 then
    l_18_2:SetAlpha(255)
    l_18_2:Show()
    l_18_2:Lookup("Image_Progress"):Show()
    l_18_2:Lookup("Image_FlashS"):Hide()
    l_18_2:Lookup("Image_FlashF"):Hide()
    l_18_2:Lookup("Text_Name"):SetText(l_18_3)
    l_18_2:Lookup("Image_Progress"):SetPercentage(l_18_4)
    l_18_2.nActionState = 5
  end
  if l_18_4 < 0.0175 then
    TargetEx.tChannelList[l_18_0.dwID] = nil
  end
end

l_0_8 = TargetEx
l_0_9 = "ReDrawKungFuIcon"
l_0_8[l_0_9] = function(l_19_0)
  local l_19_1 = nil
  if IsPlayer(l_19_0.dwID) then
    l_19_1 = GetPlayer(l_19_0.dwID)
  else
    return 
  end
  l_19_0:Lookup("", "Text_Others"):SetText("")
  if not l_19_1.GetKungfuMount() then
    local l_19_2, l_19_3 = l_19_0:Lookup("", "Image_Target"), {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_19_3 then
    local l_19_4 = nil
    l_19_4:FromIconID(Table_GetSkillIconID(l_19_3.dwSkillID, 0))
  end
end

l_0_8 = TargetEx
l_0_9 = "RefreshBuff"
l_0_8[l_0_9] = function(l_20_0, l_20_1, l_20_2)
  -- upvalues: l_0_3 , l_0_4 , l_0_5 , l_0_6
  local l_20_3 = GetTargetHandle(l_20_0.dwType, l_20_0.dwID)
  local l_20_4 = l_0_3
  local l_20_5 = l_0_4
  local l_20_6 = l_0_5
  local l_20_7 = l_0_6
  if not l_20_3 then
    return 
  end
  if l_20_1 then
    l_20_4.nNeedBox = 0
  end
  if l_20_2 then
    l_20_6.nNeedBox = 0
  end
  local l_20_8 = l_20_4:GetItemCount()
  local l_20_9 = l_20_6:GetItemCount()
  local l_20_11 = function(l_21_0)
    -- upvalues: l_20_0 , l_20_1 , l_20_4 , l_20_8 , l_20_5 , l_20_2 , l_20_6 , l_20_9 , l_20_7
    local l_21_1, l_21_2 = nil, nil
    if not Table_BuffIsVisible(l_21_0.dwID, l_21_0.nLevel) then
      return 
    end
    do return end
    if TargetEx.bShieldOthersBuff and l_21_0.dwSkillSrcID and l_21_0.dwSkillSrcID ~= 0 and l_21_0.dwSkillSrcID ~= l_20_0.dwID and l_21_0.dwSkillSrcID ~= UI_GetClientPlayerID() and IsPlayer(l_21_0.dwSkillSrcID) then
      return 
    end
    if l_20_1 and l_21_0.bCanCancel then
      if l_20_4.nNeedBox < l_20_8 then
        l_21_1 = l_20_4:Lookup(l_20_4.nNeedBox)
        l_21_2 = l_20_5:Lookup(l_20_4.nNeedBox)
      end
      l_20_4.nNeedBox = l_20_4.nNeedBox + 1
      TargetEx.CreateBuff(l_20_4, l_20_5, l_21_1, l_21_2, l_21_0.nIndex, true, l_21_0.dwID, l_21_0.nStackNum, l_21_0.nEndFrame, l_21_0.nLevel, l_21_0.dwSkillSrcID)
    elseif l_20_2 and not l_21_0.bCanCancel then
      if l_20_6.nNeedBox < l_20_9 then
        l_21_1 = l_20_6:Lookup(l_20_6.nNeedBox)
        l_21_2 = l_20_7:Lookup(l_20_6.nNeedBox)
      end
      l_20_6.nNeedBox = l_20_6.nNeedBox + 1
      TargetEx.CreateBuff(l_20_6, l_20_7, l_21_1, l_21_2, l_21_0.nIndex, false, l_21_0.dwID, l_21_0.nStackNum, l_21_0.nEndFrame, l_21_0.nLevel, l_21_0.dwSkillSrcID)
    end
  end
  if l_20_3.GetBuffList() then
    local l_20_12 = nil
    local l_20_13 = UI_GetClientPlayerID()
    for l_20_17,l_20_18 in pairs(l_20_12) do
      local l_20_14 = {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      if R18_PC42.dwSkillSrcID == l_20_13 or TargetEx.IsSpecialBuff(R18_PC42.dwID, l_20_0.dwType) then
        l_20_11(R18_PC42)
      else
        table.insert(l_20_14, l_20_18)
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_20_22,l_20_23 in pairs(l_20_14) do
      local l_20_19 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_20_11(l_20_12[R18_PC42])
    end
  end
  if l_20_1 then
    l_20_13 = TargetEx
    l_20_13 = l_20_13.HideLeftItem
    l_20_13(l_20_4, l_20_4.nNeedBox)
    l_20_13 = TargetEx
    l_20_13 = l_20_13.HideLeftItem
    l_20_13(l_20_5, l_20_4.nNeedBox)
  end
  if l_20_2 then
    l_20_13 = TargetEx
    l_20_13 = l_20_13.HideLeftItem
    l_20_13(l_20_6, l_20_6.nNeedBox)
    l_20_13 = TargetEx
    l_20_13 = l_20_13.HideLeftItem
    l_20_13(l_20_7, l_20_6.nNeedBox)
  end
end

l_0_8 = TargetEx
l_0_9 = "CreateBuff"
l_0_8[l_0_9] = function(l_21_0, l_21_1, l_21_2, l_21_3, l_21_4, l_21_5, l_21_6, l_21_7, l_21_8, l_21_9, l_21_10, l_21_11)
  -- upvalues: l_0_3 , l_0_5
  local l_21_12 = (Station.Lookup("Normal/Target"))
  local l_21_13 = nil
  if not l_21_2 or not l_21_3 then
     -- DECOMPILER ERROR: unhandled construct in 'if'

    if l_21_5 and l_0_3:GetItemCount() == TargetEx.nBuffMax then
      if (l_21_10 and UI_GetClientPlayerID() == l_21_10) or TargetEx.IsSpecialBuff(l_21_6, l_21_12.dwType) then
        l_21_0:RemoveItem(TargetEx.nBuffMax - 1)
        l_21_0:FormatAllItemPos()
        l_21_1:RemoveItem(TargetEx.nBuffMax - 1)
        l_21_1:FormatAllItemPos()
      end
    else
      return 
    end
    do return end
    if l_0_5:GetItemCount() == TargetEx.nDebuffMax then
      if (l_21_10 and UI_GetClientPlayerID() == l_21_10) or TargetEx.IsSpecialBuff(l_21_6, l_21_12.dwType) then
        l_21_0:RemoveItem(TargetEx.nDebuffMax - 1)
        l_21_0:FormatAllItemPos()
        l_21_1:RemoveItem(TargetEx.nDebuffMax - 1)
        l_21_1:FormatAllItemPos()
      end
    else
      return 
    end
    local l_21_14 = l_21_1:GetItemCount()
    l_21_1:AppendItemFromString("<text>postype=7 halign=1 valign=1</text>")
    l_21_3 = l_21_1:Lookup(l_21_14)
    l_21_14 = l_21_0:GetItemCount()
    l_21_0:AppendItemFromString("<box>w=" .. TargetEx.nBuffSize .. " h=" .. TargetEx.nBuffSize .. " postype=7 eventid=262912</box>")
    l_21_2 = l_21_0:Lookup(l_21_14)
    l_21_3:SetText("")
    local l_21_15, l_21_16 = l_21_2:GetSize()
    l_21_2.nW = l_21_15
    l_21_2.OnItemMouseEnter = function()
      -- upvalues: l_21_12 , l_21_2
      this:SetObjectMouseOver(1)
      local l_22_2, l_22_3 = math.floor(this.nEndFrame - GetLogicFrameCount()) / 16 + 1, this:GetAbsPos()
      local l_22_4, l_22_5 = , this:GetSize()
      if l_22_2 < 0 then
        l_22_2 = 0
        local l_22_0, l_22_1 = nil
      end
      local l_22_6 = nil
      local l_22_7 = OutputBuffTip
      local l_22_8 = l_21_12.dwID
      local l_22_9 = this.dwBuffID
      local l_22_10 = this.nLevel
      if this.bShowTime then
        local l_22_11 = this.nCount
      end
      local l_22_12 = nil
      local l_22_13 = not l_21_2.bCanCancel
      l_22_7(l_22_8, l_22_9, l_22_10, l_22_12, l_22_13, l_22_2, {l_22_3, l_22_4, l_22_5, l_22_6})
    end
    l_21_2.OnItemMouseHover = l_21_2.OnItemMouseEnter
    l_21_2.OnItemMouseLeave = function()
      HideTip()
      this:SetObjectMouseOver(0)
    end
    l_21_13 = true
  end
  local l_21_17 = "b" .. l_21_4
  l_21_2:SetName(l_21_17)
  l_21_3:SetName(l_21_17)
  l_21_0.tItem[l_21_17] = l_21_2
  l_21_1.tItem[l_21_17] = l_21_3
  local l_21_18, l_21_19 = l_21_3:GetSize()
  if (l_21_10 and UI_GetClientPlayerID() == l_21_10) or TargetEx.IsSpecialBuff(l_21_6, l_21_12.dwType) then
    l_21_2:SetSize(l_21_2.nW + 5, l_21_2.nH + 5)
    l_21_3:SetSize(l_21_2.nW + 5, l_21_19)
    if l_21_11 then
      l_21_2:SetIndex(0)
      l_21_13 = true
    end
  else
    l_21_2:SetSize(l_21_2.nW, l_21_2.nH)
    l_21_3:SetSize(l_21_2.nW, l_21_19)
  end
  l_21_2:Show()
  l_21_2:SetName("b" .. l_21_4)
  l_21_2.nCount = l_21_7
  l_21_2.nEndFrame = l_21_8
  l_21_2.bCanCancel = l_21_5
  l_21_2.dwBuffID = l_21_6
  l_21_2.nLevel = l_21_9
  l_21_2.nIndex = l_21_4
  l_21_2.bSparking = Table_BuffNeedSparking(l_21_6, l_21_9)
  l_21_2.bShowTime = Table_BuffNeedShowTime(l_21_6, l_21_9)
  l_21_2:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_21_6)
  l_21_2:SetObjectIcon(Table_GetBuffIconID(l_21_6, l_21_9))
  l_21_2:SetOverTextFontScheme(0, 15)
  l_21_2:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
  l_21_2:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
  l_21_2:SetAlpha(255)
  l_21_3:Show()
  l_21_3.szTime = nil
  l_21_3:SetText("")
  local l_21_20, l_21_21, l_21_22 = TargetEx.GetLeftTime(l_21_2.nEndFrame)
  if l_21_22 > 0 then
    if TargetEx.bTopLeftBuffTime then
      l_21_2:SetOverTextFontScheme(1, l_21_21)
      l_21_2:SetOverText(1, l_21_20)
    else
      l_21_3:SetText(l_21_20)
      l_21_3:SetFontScheme(l_21_21)
    end
    l_21_3.szTime = l_21_20
    local l_21_23, l_21_24, l_21_25, l_21_26 = l_21_3:GetSize()
  end
  if l_21_7 > 1 then
    l_21_2:SetOverText(0, l_21_7)
  else
    l_21_2:SetOverText(0, "")
  end
  return l_21_13
end

l_0_8 = TargetEx
l_0_9 = "UpdateSingleBuff"
l_0_8[l_0_9] = function(l_22_0, l_22_1, l_22_2, l_22_3, l_22_4, l_22_5, l_22_6, l_22_7, l_22_8)
  local l_22_9 = Station.Lookup("Normal/Target")
  if not Table_BuffIsVisible(l_22_4, l_22_7) then
    return 
  end
  do return end
  if TargetEx.bShieldOthersBuff and l_22_8 and l_22_8 ~= 0 and l_22_8 ~= l_22_9.dwID and l_22_8 ~= UI_GetClientPlayerID() and IsPlayer(l_22_8) then
    return 
  end
  local l_22_11 = l_22_0:Lookup("b" .. l_22_2)
  if not l_22_11 then
    local l_22_12 = l_22_1:Lookup("b" .. l_22_2)
    if l_22_0.nNeedBox < l_22_0:GetItemCount() then
      l_22_11 = l_22_0:Lookup(l_22_0.nNeedBox)
      local l_22_10 = nil
      l_22_12 = l_22_1:Lookup(l_22_0.nNeedBox)
    end
    l_22_0.nNeedBox = l_22_0.nNeedBox + 1
  end
  local l_22_13 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if nil then
    l_22_0:FormatAllItemPos()
    l_22_1:FormatAllItemPos()
  end
end

l_0_8 = TargetEx
l_0_9 = "HideLeftItem"
l_0_8[l_0_9] = function(l_23_0, l_23_1)
  local l_23_2 = l_23_0:GetItemCount()
  local l_23_3 = l_23_2 - l_23_1
  if l_23_3 > 10 then
    for l_23_7 = 1, l_23_3 do
      l_23_0:RemoveItem(l_23_2 - l_23_7)
    end
    do break end
  end
  l_23_2 = l_23_2 - 1
  for l_23_11 = l_23_1, l_23_2 do
    local l_23_12 = l_23_0:Lookup(l_23_11)
    l_23_12:Hide()
    l_23_12:SetName("")
  end
  l_23_0:FormatAllItemPos()
end

l_0_8 = TargetEx
l_0_9 = "UpdateBufferTime"
l_0_8[l_0_9] = function(l_24_0, l_24_1)
  local l_24_2 = l_24_0.nNeedBox - 1
  if l_24_2 < 0 then
    return 
  end
  for l_24_6 = 0, l_24_2 do
    local l_24_7 = l_24_0:Lookup(l_24_6)
    local l_24_8 = l_24_1:Lookup(l_24_6)
    if not l_24_7 and not l_24_8 then
      return 
    end
    local l_24_9, l_24_10, l_24_11 = TargetEx.GetLeftTime(l_24_7.nEndFrame)
    if TargetEx.bTopLeftBuffTime then
      if l_24_1:IsVisible() then
        l_24_1:Hide()
      end
      if l_24_11 > 0 and l_24_9 ~= l_24_8.szTime then
        l_24_7:SetOverTextFontScheme(1, l_24_10)
        l_24_7:SetOverText(1, l_24_9)
        l_24_8.szTime = l_24_9
      end
    else
      if not l_24_1:IsVisible() then
        l_24_1:Show()
      end
    end
    if l_24_11 > 0 and l_24_9 ~= l_24_8.szTime then
      l_24_8:SetText(l_24_9)
      l_24_8:SetFontScheme(l_24_10)
      l_24_8.szTime = l_24_9
    end
  end
end

l_0_8 = TargetEx
l_0_9 = "OnEvent"
l_0_8[l_0_9] = function(l_25_0)
  -- upvalues: l_0_5 , l_0_6 , l_0_3 , l_0_4
  if l_25_0 == "BUFF_UPDATE" then
    local l_25_1 = Station.Lookup("Normal/Target")
    if not l_25_1 or not l_25_1:IsVisible() then
      return 
    end
    if l_25_1 and l_25_1.dwID == arg0 then
      if arg7 then
        TargetEx.RefreshBuff(l_25_1, true, true)
      end
    else
      local l_25_2 = arg1
      local l_25_3 = arg3
      if l_25_2 then
        TargetEx.RefreshBuff(l_25_1, l_25_3, not l_25_3)
      end
    else
      local l_25_4 = l_0_5
      local l_25_5 = l_0_6
      if l_25_3 then
        l_25_4 = l_0_3
        l_25_5 = l_0_4
      end
      TargetEx.UpdateSingleBuff(l_25_4, l_25_5, arg2, l_25_3, arg4, arg5, arg6, arg8, arg9)
    end
  elseif l_25_0 == "DO_SKILL_CAST" then
    TargetEx.OnSkillCast(arg0, arg1, arg2)
  elseif l_25_0 == "SYS_MSG" then
    if arg0 == "UI_OME_SKILL_HIT_LOG" and arg3 == SKILL_EFFECT_TYPE.SKILL then
      TargetEx.OnSkillCast(arg1, arg4, arg5)
    elseif arg0 == "UI_OME_SKILL_EFFECT_LOG" and arg4 == SKILL_EFFECT_TYPE.SKILL then
      TargetEx.OnSkillCast(arg1, arg5, arg6)
    elseif (arg0 == "UI_OME_SKILL_BLOCK_LOG" or arg0 == "UI_OME_SKILL_SHIELD_LOG" or arg0 == "UI_OME_SKILL_MISS_LOG" or arg0 == "UI_OME_SKILL_DODGE_LOG") and arg3 == SKILL_EFFECT_TYPE.SKILL then
      TargetEx.OnSkillCast(arg1, arg4, arg5)
    end
  elseif l_25_0 == "OT_ACTION_PROGRESS_BREAK" then
    TargetEx.tChannelList[arg0] = nil
  end
end

l_0_8 = TargetEx
l_0_9 = "OnSkillCast"
l_0_8[l_0_9] = function(l_26_0, l_26_1, l_26_2)
  if not TargetEx.bShowChannel then
    return 
  end
  local l_26_3 = GetLogicFrameCount()
  local l_26_4 = Table_GetSkillName(l_26_1, l_26_2)
  local l_26_5 = GetSkill(l_26_1, l_26_2)
  if not l_26_5.bIsChannelSkill then
    return 
  end
  if TargetEx.tChannelSkill[l_26_1] and l_26_4 and l_26_4 ~= "" then
    for l_26_9,l_26_10 in pairs(TargetEx.tChannelList) do
      if not l_26_10[3] < l_26_3 - l_26_10[2] then
        local l_26_14 = nil
        l_26_14 = GetPlayer(l_26_9) ~= nil and GetPlayer(l_26_9).GetOTActionState() ~= 2
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_26_14 then
        TargetEx.tChannelList[l_26_9] = nil
      end
    end
    if not TargetEx.tChannelList[l_26_0] then
      TargetEx.tChannelList[l_26_0] = {}
    end
    if TargetEx.tChannelList[l_26_0][1] and TargetEx.tChannelList[l_26_0][1] ~= "" then
      return 
    end
    local l_26_17 = TargetEx.tChannelList
    do
      local l_26_18 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_8 = TargetEx
l_0_9 = "GetSkillChannelState"
l_0_8[l_0_9] = function(l_27_0)
  local l_27_1 = TargetEx.tChannelList[l_27_0]
  if l_27_1 then
    local l_27_2 = GetLogicFrameCount() - l_27_1[2]
  end
  if l_27_2 < l_27_1[3] then
    local l_27_3 = 1 - l_27_2 / l_27_1[3]
    return l_27_1[1], l_27_3, l_27_1[2]
  end
end

l_0_8 = RegisterEvent
l_0_9 = "UPDATE_SELECT_TARGET"
l_0_8(l_0_9, function()
  -- upvalues: l_0_3 , l_0_4 , l_0_5 , l_0_6
  local l_28_0 = Station.Lookup("Normal/Target")
  if l_28_0:IsVisible() then
    TargetEx.FixTargetBgImage(l_28_0)
    TargetEx.FixTargetTextAndImage(l_28_0)
    TargetEx.AdjustAllItems(l_28_0)
    TargetEx.HideSystemTargetBuff(l_28_0)
    TargetEx.AdjustBuffTextPos()
    TargetEx.RefreshBuff(l_28_0, true, true)
    TargetTargetEx.HideSystemTTargetBuff()
    TargetTargetEx.FixTargetTextAndImage()
    TargetTargetEx.AdjustAllItems()
  else
    l_0_3:Clear()
    l_0_4:Clear()
    l_0_5:Clear()
    l_0_6:Clear()
  end
end
)
l_0_8 = TargetEx
l_0_9 = "GetMenu"
l_0_8[l_0_9] = function()
  local l_29_0 = {}
  l_29_0.szOption = "Ŀ����ǿ"
  local l_29_1 = {}
  l_29_1.szOption = "Ŀ��BUFF��ǿ"
  local l_29_2 = {}
  l_29_2.szOption = "��ʾ��������"
  l_29_2.bCheck = true
  l_29_2.bChecked = TargetEx.bShowChannel
  l_29_2.fnAction = function()
    TargetEx.bShowChannel = not TargetEx.bShowChannel
  end
  local l_29_3 = {}
  l_29_3.szOption = "��ʾ����BUFF"
  l_29_3.bCheck = true
  l_29_3.bChecked = TargetEx.bShowSpecialBuff
  l_29_3.fnAction = function()
    TargetEx.bShowSpecialBuff = not TargetEx.bShowSpecialBuff
  end
  local l_29_4 = {}
  l_29_4.szOption = "��������BUFF"
  l_29_4.bCheck = true
  l_29_4.bChecked = TargetEx.bShieldOthersBuff
  l_29_4.fnAction = function()
    TargetEx.bShieldOthersBuff = not TargetEx.bShieldOthersBuff
  end
  local l_29_5 = {}
  l_29_5.szOption = "�����ʾ " .. TargetEx.nBuffMax .. " ��BUFF"
  l_29_5.fnAction = function()
    local l_33_0, l_33_1 = this:GetAbsPos()
    local l_33_2, l_33_3 = this:GetSize()
    local l_33_4 = GetUserInputNumber
    local l_33_5 = TargetEx.nBuffMax
    local l_33_6 = 25
    do
      local l_33_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_33_4(l_33_5, l_33_6, l_33_7, l_33_0, l_33_1, l_33_0 + l_33_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  local l_29_6 = {}
  l_29_6.szOption = "�����ʾ " .. TargetEx.nDebuffMax .. " ��DEBUFF"
  l_29_6.fnAction = function()
    local l_34_0, l_34_1 = this:GetAbsPos()
    local l_34_2, l_34_3 = this:GetSize()
    local l_34_4 = GetUserInputNumber
    local l_34_5 = TargetEx.nDebuffMax
    local l_34_6 = 25
    do
      local l_34_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_34_4(l_34_5, l_34_6, l_34_7, l_34_0, l_34_1, l_34_0 + l_34_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  local l_29_7 = {}
  l_29_7.szOption = "BUFF��С " .. TargetEx.nBuffSize
  l_29_7.fnAction = function()
    local l_35_0, l_35_1 = this:GetAbsPos()
    local l_35_2, l_35_3 = this:GetSize()
    local l_35_4 = GetUserInputNumber
    local l_35_5 = TargetEx.nBuffSize
    local l_35_6 = 40
    do
      local l_35_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_35_4(l_35_5, l_35_6, l_35_7, l_35_0, l_35_1, l_35_0 + l_35_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  local l_29_8 = {}
  l_29_8.szOption = "��ʾĿ���Ŀ��BUFFʱ��"
  l_29_8.bCheck = true
  l_29_8.bChecked = TargetEx.bShowTTBuffTime
  l_29_8.fnAction = function()
    TargetEx.bShowTTBuffTime = not TargetEx.bShowTTBuffTime
  end
  local l_29_9 = {}
  l_29_9.szOption = "��ʾʱ������ڱ�"
  l_29_9.bCheck = true
  l_29_9.bChecked = TargetEx.bFontShadow
  l_29_9.fnAction = function()
    TargetEx.bFontShadow = not TargetEx.bFontShadow
    if TargetEx.bFontShadow then
      local l_37_0 = TargetEx
      local l_37_1 = TargetEx
      local l_37_2 = TargetEx
      local l_37_3, l_37_4 = unpack(tBuffTimeFont[2])
      l_37_2.nFont3 = R5_PC16
      l_37_1.nFont2 = l_37_4
      l_37_0.nFont1 = l_37_3
    else
      local l_37_5 = TargetEx
      local l_37_6 = TargetEx
      local l_37_7 = TargetEx
      local l_37_8, l_37_9 = unpack(tBuffTimeFont[1])
      l_37_7.nFont3 = R5_PC16
      l_37_6.nFont2 = l_37_9
      l_37_5.nFont1 = l_37_8
    end
  end
  local l_29_10 = {}
  l_29_10.szOption = "ʱ�����Ͻ���ʾ"
  l_29_10.bCheck = true
  l_29_10.bChecked = TargetEx.bTopLeftBuffTime
  l_29_10.fnAction = function()
    TargetEx.bTopLeftBuffTime = not TargetEx.bTopLeftBuffTime
    if TargetEx.bTopLeftBuffTime then
      local l_38_0 = TargetEx
      local l_38_1 = TargetEx
      local l_38_2 = TargetEx
      local l_38_3, l_38_4 = unpack(tBuffTimeFont[2])
      l_38_2.nFont3 = R5_PC16
      l_38_1.nFont2 = l_38_4
      l_38_0.nFont1 = l_38_3
    else
      local l_38_5 = TargetEx
      local l_38_6 = TargetEx
      local l_38_7 = TargetEx
      local l_38_8, l_38_9 = unpack(tBuffTimeFont[1])
      l_38_7.nFont3 = R5_PC16
      l_38_6.nFont2 = l_38_9
      l_38_5.nFont1 = l_38_8
    end
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_29_3 = TargetState
  l_29_3 = l_29_3.bShowTargetState
  l_29_3 = function()
    TargetState.bShowTargetState = not TargetState.bShowTargetState
    TargetState.Switch(TargetState.bShowTargetState)
  end
  l_29_4 = TargetDirection
  l_29_4 = l_29_4.bShowTargetDirection
  l_29_4 = function()
    TargetDirection.bShowTargetDirection = not TargetDirection.bShowTargetDirection
    TargetDirection.Switch(TargetState.bShowTargetDirection)
  end
  l_29_5 = TargetDirection
  l_29_5 = l_29_5.bShowBg
  l_29_5 = function()
    TargetDirection.bShowBg = not TargetDirection.bShowBg
  end
  l_29_6 = TargetDirection
  l_29_6 = l_29_6.bShowForce
  l_29_6 = function()
    TargetDirection.bShowForce = not TargetDirection.bShowForce
  end
  l_29_5, l_29_4 = {szOption = "��ʾ����ͼ��", bCheck = true, bChecked = l_29_6, fnAction = l_29_6}, {szOption = "��ʾ���뱳��", bCheck = true, bChecked = l_29_5, fnAction = l_29_5}
  l_29_6 = TargetLine
  l_29_6 = l_29_6.btargetline
  l_29_6 = function()
    TargetLine.btargetline = not TargetLine.btargetline
  end
  l_29_7 = TargetLine
  l_29_7 = l_29_7.bttargetline
  l_29_7 = function()
    TargetLine.bttargetline = not TargetLine.bttargetline
  end
  l_29_8 = TargetLine
  l_29_8 = l_29_8.bPoint
  l_29_8 = function()
    TargetLine.bPoint = not TargetLine.bPoint
  end
  l_29_9 = "׷����͸���� "
  l_29_10 = TargetLine
  l_29_10 = l_29_10.nLineAlpha
  l_29_9 = l_29_9 .. l_29_10
  l_29_9 = function()
    local l_46_0, l_46_1 = this:GetAbsPos()
    local l_46_2, l_46_3 = this:GetSize()
    local l_46_4 = GetUserInputNumber
    local l_46_5 = TargetLine.nLineAlpha
    local l_46_6 = 100
    do
      local l_46_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_46_4(l_46_5, l_46_6, l_46_7, l_46_0, l_46_1, l_46_0 + l_46_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_29_10 = "׷������ʼ���� "
  l_29_10 = l_29_10 .. TargetLine.nStartWidth
  l_29_10 = function()
    local l_47_0, l_47_1 = this:GetAbsPos()
    local l_47_2, l_47_3 = this:GetSize()
    local l_47_4 = GetUserInputNumber
    local l_47_5 = TargetLine.nStartWidth
    local l_47_6 = 4
    do
      local l_47_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_47_4(l_47_5, l_47_6, l_47_7, l_47_0, l_47_1, l_47_0 + l_47_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_29_10, l_29_9, l_29_8, l_29_7, l_29_6, l_29_5 = {szOption = "׷���߽������� " .. TargetLine.nEndWidth, fnAction = function()
    local l_48_0, l_48_1 = this:GetAbsPos()
    local l_48_2, l_48_3 = this:GetSize()
    local l_48_4 = GetUserInputNumber
    local l_48_5 = TargetLine.nEndWidth
    local l_48_6 = 2
    do
      local l_48_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_48_4(l_48_5, l_48_6, l_48_7, l_48_0, l_48_1, l_48_0 + l_48_2)
    end
     -- WARNING: undefined locals caused missing assignments!
  end}, {szOption = l_29_10, fnAction = l_29_10}, {szOption = l_29_9, fnAction = l_29_9}, {szOption = "����Ŀ����˸��ʾ", bCheck = true, bChecked = l_29_8, fnAction = l_29_8}, {szOption = "����Ŀ���Ŀ��׷����", bCheck = true, bChecked = l_29_7, fnAction = l_29_7}, {szOption = "����Ŀ��׷����", bCheck = true, bChecked = l_29_6, fnAction = l_29_6}
  l_29_5 = table
  l_29_5 = l_29_5.insert
  l_29_6 = l_29_0
  l_29_7 = l_29_1
  l_29_5(l_29_6, l_29_7)
  l_29_5 = table
  l_29_5 = l_29_5.insert
  l_29_6 = l_29_0
  l_29_7, l_29_2 = l_29_2, {szOption = "����Ŀ���ƶ�״̬", bCheck = true, bChecked = l_29_3, fnAction = l_29_3}
  l_29_5(l_29_6, l_29_7)
  l_29_5 = table
  l_29_5 = l_29_5.insert
  l_29_6 = l_29_0
  l_29_7, l_29_3 = l_29_3, {l_29_4, l_29_5; szOption = "����Ŀ�귽��ָʾ", bCheck = true, bChecked = l_29_4, fnAction = l_29_4}
  l_29_5(l_29_6, l_29_7)
  l_29_5 = table
  l_29_5 = l_29_5.insert
  l_29_6 = l_29_0
  l_29_7, l_29_4 = l_29_4, {l_29_5, l_29_6, l_29_7, l_29_8, l_29_9, l_29_10; szOption = "Ŀ��׷����"}
  l_29_5(l_29_6, l_29_7)
  return l_29_0
end

l_0_8 = Wnd
l_0_9 = "OpenWindow"
l_0_8 = l_0_8[l_0_9]
l_0_9 = l_0_0
l_0_8(l_0_9, "TargetEx")
l_0_8 = BFConfigPanel
l_0_9 = "RegisterMod"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "Ŀ����ǿ", "\\ui\\image\\icon\\ty_wudu_08.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShowChannel", "��ʾ��������", true, function(l_30_0)
  TargetEx.bShowChannel = l_30_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShieldOthersBuff", "��������BUFF", false, function(l_31_0)
  TargetEx.bShieldOthersBuff = l_31_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShowSpecialBuff", "��ʾ����BUFF", true, function(l_32_0)
  TargetEx.bShowSpecialBuff = l_32_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterSmallEditBox"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "ChangeSize", "BUFF��С(30-40):", "30", function(l_33_0, l_33_1)
  if tonumber(l_33_0) then
    if tonumber(l_33_0) > 40 then
      TargetEx.nBuffSize = 30
      return 
    end
    if tonumber(l_33_0) < 30 then
      TargetEx.nBuffSize = 30
      return 
    end
    TargetEx.nBuffSize = tonumber(l_33_0)
  elseif not l_33_1 then
    TargetEx.nBuffSize = 30
  end
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterSmallEditBox"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "ChangeBuffMax", "BUFF������", "16", function(l_34_0, l_34_1)
  if tonumber(l_34_0) then
    if tonumber(l_34_0) > 25 then
      TargetEx.nBuffMax = 16
      return 
    end
    if tonumber(l_34_0) < 10 then
      TargetEx.nBuffMax = 16
      return 
    end
    TargetEx.nBuffMax = tonumber(l_34_0)
  elseif not l_34_1 then
    TargetEx.nBuffMax = 16
  end
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterSmallEditBox"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "ChangeDebuffMax", "DEBUFF������:", "16", function(l_35_0, l_35_1)
  if tonumber(l_35_0) then
    if tonumber(l_35_0) > 25 then
      TargetEx.nDebuffMax = 16
      return 
    end
    if tonumber(l_35_0) < 10 then
      TargetEx.nDebuffMax = 16
      return 
    end
    TargetEx.nDebuffMax = tonumber(l_35_0)
  elseif not l_35_1 then
    TargetEx.nDebuffMax = 16
  end
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShowTTBuffTime", "��ʾĿ���Ŀ��BUFFʱ��", false, function(l_36_0)
  TargetEx.bShowTTBuffTime = l_36_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bTopLeftBuffTime", "ʱ�����Ͻ���ʾ", false, function(l_37_0)
  TargetEx.bTopLeftBuffTime = l_37_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShowTargetState", "����Ŀ���ƶ�״̬", true, function(l_38_0)
  TargetState.bShowTargetState = l_38_0
  TargetState.Switch(l_38_0)
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bShowTargetDirection", "����Ŀ�귽��ָʾ", true, function(l_39_0)
  TargetDirection.bShowTargetDirection = l_39_0
  TargetDirection.Switch(l_39_0)
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "btargetline", "����Ŀ��׷����", true, function(l_40_0)
  TargetLine.btargetline = l_40_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bttargetline", "����Ŀ���Ŀ��׷����", true, function(l_41_0)
  TargetLine.bttargetline = l_41_0
end
)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "TargetEx"
l_0_8(l_0_9, "bPoint", "����Ŀ����˸��ʾ", true, function(l_42_0)
  TargetLine.bPoint = l_42_0
end
)

