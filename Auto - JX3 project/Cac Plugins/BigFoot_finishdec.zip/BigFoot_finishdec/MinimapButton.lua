-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: MinimapButton.lua 

local l_0_0 = {}
l_0_0.MinibuttonPos = math.pi * math.pi * -0.2708
l_0_0.Buttons = {}
BF_MinimapButtons = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BF_MinimapButtons.MinibuttonPos")
l_0_0 = BigFoot
l_0_0.RegisterMinimapButton = function(l_1_0, l_1_1, l_1_2, l_1_3)
  local l_1_4 = BFImage.new(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 52, 35)
  local l_1_5 = BFImage.new(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 52, 53)
  local l_1_6 = BFButton.new(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30)
  local l_1_7 = BFImage.new(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa, 30, 30)
  l_1_5:SetImage("Interface\\BF_Base\\artwork\\minibuttonbgleft.tga")
  l_1_7:SetImage("Interface\\BF_Base\\artwork\\highlight.tga")
  l_1_4:SetImage("Interface\\BF_Base\\artwork\\minibuttonbg.tga")
  l_1_7:SetMousePenetrable(true)
  l_1_7:Hide()
  if type(l_1_0) == "string" then
    l_1_6:SetNormalImage(l_1_0)
  else
    if type(l_1_0) == "table" then
      l_1_6:SetNormalImage(l_1_0[1], l_1_0[2])
    end
  end
  l_1_6:SetStyle("TRANSPARENT")
  l_1_6.OnMouseEnter = function()
    -- upvalues: l_1_7 , l_1_1
    local l_2_0, l_2_1 = Cursor.GetPos()
    l_1_7:Show()
    local l_2_2 = OutputTip
    local l_2_3 = l_1_1
    local l_2_4 = 300
    do
      local l_2_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_2_2(l_2_3, l_2_4, l_2_5)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_1_6.OnMouseLeave = function()
    -- upvalues: l_1_7
    l_1_7:Hide()
    HideTip()
  end
  l_1_6.OnLButtonDown = function()
    -- upvalues: l_1_7
    l_1_7:SetImage("Interface\\BF_Base\\artwork\\dark.tga")
  end
  l_1_6.OnLButtonUp = function()
    -- upvalues: l_1_7
    l_1_7:SetImage("Interface\\BF_Base\\artwork\\highlight.tga")
  end
  l_1_6.OnClick = function()
    -- upvalues: l_1_2 , l_1_3
    Station.SetActiveFrame(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:GetContainer())
    Station.SetFocusWindow(BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:GetContainer())
    if type(l_1_2) == "string" and BFMods and BFMods[l_1_2] then
      for l_6_3,l_6_4 in ipairs(BFMods[l_1_2]) do
        if l_6_4.tag == l_1_3 then
          local l_6_5 = BFGetModValue(l_1_2, l_1_3)
          BFSetModValue(l_1_2, l_1_3, not l_6_5)
          l_6_4.callback(not l_6_5)
          return 
        end
      end
    else
      if type(l_1_2) == "function" then
        l_1_2()
      end
    end
  end
  l_1_6.BigFoot_4118e1548bb891f95329d159511be390 = l_1_5
  table.insert(BF_MinimapButtons.Buttons, l_1_6)
  l_1_6.BigFoot_0803f9243edd18283df33b531be925c7 = l_1_7
  l_1_6.BigFoot_c56784577f9c1590bb81071ee435206b = l_1_4
  BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetSize(32 * #BF_MinimapButtons.Buttons, 32)
  BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a.BigFoot_5d92f48160d113a56eb68ffaff9f5daa:SetSize(32 * #BF_MinimapButtons.Buttons, 32)
  local l_1_8 = 1
  for l_1_12 = #BF_MinimapButtons.Buttons, 1, -1 do
    local l_1_13 = BF_MinimapButtons.Buttons[l_1_12]
    l_1_13.BigFoot_c56784577f9c1590bb81071ee435206b:SetRelPos(31 * (l_1_8 - 1) - 12, -1)
    l_1_13.BigFoot_0803f9243edd18283df33b531be925c7:SetRelPos(31 * (l_1_8 - 1) + 7, 1)
    l_1_13:SetRelPos(31 * (l_1_8 - 1) + 7, 2)
    l_1_8 = l_1_8 + 1
    l_1_6.BigFoot_4118e1548bb891f95329d159511be390:SetRelPos(-35, -11)
  end
end

l_0_0 = BF_MinimapButtons
l_0_0.IsCursorPosChanged = function()
  local l_2_0, l_2_1 = Cursor.GetPos()
  return l_2_0 ~= BF_MinimapButtons.CursorX and l_2_1 ~= BF_MinimapButtons.CursorY
end

l_0_0 = BF_MinimapButtons
l_0_0.Create = function()
  local l_3_0 = BFFrame.new(0, 0, "NONE")
  local l_3_1 = BFButton.new(BFScreen, 28, 28)
  BF_MinimapButtons.ButtonSelf = l_3_1
  l_3_1:SetNormalImage("Interface\\BF_Base\\artwork\\minibutton.UITex", 0)
  l_3_1:SetHotImage("Interface\\BF_Base\\artwork\\minibutton.UITex", 1)
  l_3_1:SetPressedImage("Interface\\BF_Base\\artwork\\minibutton.UITex", 2)
  l_3_1:SetStyle("TRANSPARENT")
  local l_3_2, l_3_3 = l_3_0:AddListener, l_3_0
  local l_3_4 = {}
  l_3_4.OnUpdate = function()
    -- upvalues: l_3_1
    local l_4_0, l_4_1 = Cursor.GetPos()
    if BF_MinimapButtons.MinibuttonDragging and BF_MinimapButtons.IsCursorPosChanged() then
      local l_4_2 = Station.Lookup("Topmost/Minimap")
      local l_4_3, l_4_4 = l_4_2:GetAbsPos()
      local l_4_5, l_4_6 = l_4_2:GetSize()
      local l_4_7 = l_4_3 + l_4_5 / 2 - 20
      local l_4_8 = l_4_4 + l_4_6 / 2 - 10
      local l_4_9 = l_4_0 - l_4_7 - 14
      local l_4_10 = l_4_1 - l_4_8 - 14
      local l_4_11 = math.atan2(l_4_10, l_4_9)
      l_4_9 = math.sin(l_4_11 + math.pi / 2) * 105
      l_4_10 = math.cos(l_4_11 + math.pi / 2) * 105
      l_3_1:SetAbsPos(l_4_7 + l_4_9, l_4_8 - l_4_10)
      BF_MinimapButtons.MinibuttonPos = l_4_11
    end
  end
  l_3_2(l_3_3, l_3_4)
  l_3_2 = Station
  l_3_2 = l_3_2.Lookup
  l_3_3 = "Topmost/Minimap"
  l_3_2 = l_3_2(l_3_3)
  l_3_3, l_3_4 = l_3_2:Lookup, l_3_2
  l_3_3 = l_3_3(l_3_4, "Wnd_Minimap")
  l_3_3, l_3_4 = l_3_3:Lookup, l_3_3
  l_3_3 = l_3_3(l_3_4, "Wnd_Over")
  l_3_4(l_3_1, l_3_3)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_4(l_3_1)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_4(l_3_4, 140, 0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_0 = l_3_4
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_4(l_3_4, (Station.Lookup("Topmost1")), nil, true)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_4(l_3_0)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_3_4.OnKillFocus = function()
    -- upvalues: l_3_1 , l_3_0
    local l_5_0, l_5_1 = l_3_1:GetAbsPos()
    local l_5_2, l_5_3 = l_3_1:GetSize()
    local l_5_4, l_5_5 = Cursor.GetPos()
    if l_5_0 > l_5_4 or l_5_4 > l_5_0 + l_5_2 or l_5_1 > l_5_5 or l_5_5 > l_5_1 + l_5_3 then
      local l_5_6, l_5_7 = l_3_0:GetAbsPos()
      local l_5_8, l_5_9 = Cursor.GetPos()
      local l_5_10, l_5_11 = l_3_0:GetSize()
    if l_5_6 <= l_5_8 and l_5_8 <= l_5_6 + l_5_10 and l_5_7 <= l_5_9 then
      end
    if l_5_6 <= l_5_8 then
      end
    end
    l_3_0:Hide()
  end
  l_3_0.BigFoot_5d92f48160d113a56eb68ffaff9f5daa = l_3_4
  BF_MinimapButtons.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 = l_3_1
  BF_MinimapButtons.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = l_3_0
  l_3_0:SetPoint("TOPRIGHT", l_3_1, "TOPLEFT", -5, 0)
  l_3_1.OnMouseEnter = function(l_6_0)
  end
  l_3_1.OnClick = function(l_7_0, l_7_1)
    -- upvalues: l_3_0 , l_3_4
    if l_3_0:IsShown() then
      l_3_0:Hide()
    else
      l_3_0:Show()
    end
    Station.SetActiveFrame(l_3_0:GetContainer())
    Station.SetFocusWindow(l_3_4:GetContainer())
  end
  l_3_1.OnMouseDown = function(l_8_0)
    -- upvalues: l_3_0
    l_3_0:SetAutoRePos(true)
    BF_MinimapButtons.MinibuttonDragging = this
    local l_8_1 = BF_MinimapButtons
    local l_8_2 = BF_MinimapButtons
    local l_8_3 = Cursor.GetPos()
    l_8_2.CursorY = R4_PC12
    l_8_1.CursorX = l_8_3
  end
  l_3_1.OnMouseUp = function(l_9_0)
    -- upvalues: l_3_0 , l_3_1
    l_3_0:SetAutoRePos(false)
    BF_MinimapButtons.MinibuttonDragging = nil
    local l_9_1, l_9_2 = this:GetAbsPos()
    l_3_1:SetAbsPos(l_9_1, l_9_2)
    this:SetRelPos(0, 0)
  end
end

l_0_0 = RegisterEvent
l_0_0("CUSTOM_DATA_LOADED", function()
  local l_4_0 = Station.Lookup("Topmost/Minimap")
  local l_4_1 = BF_MinimapButtons.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5
  local l_4_2, l_4_3 = l_4_0:GetAbsPos()
  local l_4_4, l_4_5 = l_4_0:GetSize()
  local l_4_6 = l_4_2 + l_4_4 / 2 - 20
  local l_4_7 = l_4_3 + l_4_5 / 2 - 10
  local l_4_8 = math.sin(BF_MinimapButtons.MinibuttonPos + math.pi / 2) * 105
  local l_4_9 = math.cos(BF_MinimapButtons.MinibuttonPos + math.pi / 2) * 105
  l_4_1:SetAbsPos(l_4_6 + l_4_8, l_4_7 - l_4_9)
end
)
l_0_0 = BF_MinimapButtons
l_0_0 = l_0_0.Create
l_0_0()

