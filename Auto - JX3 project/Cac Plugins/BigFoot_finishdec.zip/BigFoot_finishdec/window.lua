-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: window.lua 

BFWindow = classv2(BFWidget)
BFWindow.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3)
  local l_1_4 = assert
  l_1_4(l_1_2 >= 0 and l_1_3 >= 0, "Invalid widget size.")
  l_1_4(l_1_0, l_1_2, l_1_3)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_4(l_1_0, l_1_1)
end

BFWindow.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\window.ini", l_2_0:GetName())
  local l_2_4 = l_2_3:Lookup("Wnd_Main")
  l_2_0:SetContainer(l_2_4)
  local l_2_5 = l_2_4:Lookup("", "")
  local l_2_6 = l_2_5:Lookup("Image_Border")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_5
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border = l_2_6
  l_2_4.widget = l_2_0
  l_2_5.widget = l_2_0
  l_2_0:SetSize(l_2_1, l_2_2)
  l_2_4.OnKillFocus = function()
    this.widget:_FireEvent("OnKillFocus")
  end
  l_2_4.OnMouseEnter = function()
    this.widget:_FireEvent("OnMouseEnter")
  end
  l_2_4.OnMouseLeave = function()
    this.widget:_FireEvent("OnMouseLeave")
  end
  l_2_4.OnMouseHover = function()
    this.widget:_FireEvent("OnMouseMove")
  end
end

BFWindow.GetHandle = function(l_3_0)
  return l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle
end

BFWindow.SetBorder = function(l_4_0, l_4_1, l_4_2)
  l_4_0._border = l_4_1
  if not l_4_2 then
    l_4_0:Update()
  end
end

BFWindow.Enable = function(l_5_0)
  local l_5_1, l_5_2 = nil, nil
  for i_1,i_2 in pairs(l_5_0.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe) do
    i_2:Enable()
  end
end

BFWindow.Disable = function(l_6_0)
  local l_6_1, l_6_2 = nil, nil
  for i_1,i_2 in pairs(l_6_0.BigFoot_81afa7ee183f31d4a5c2c7226da03bfe) do
    i_2:Disable()
  end
end

BFWindow.StartMoving = function(l_7_0)
  local l_7_1 = l_7_0:GetContainer()
  l_7_1:StartMoving()
end

BFWindow.StopMoving = function(l_8_0)
  local l_8_1 = l_8_0:GetContainer()
  l_8_1:StopMoving()
end

BFWindow._UpdateContent = function(l_9_0)
  local l_9_1 = l_9_0:GetWidth()
  local l_9_2 = l_9_0:GetHeight()
  l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSize(l_9_1, l_9_2)
  l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:SetSize(l_9_1, l_9_2)
  if l_9_0._border then
    if l_9_0._border == "NONE" then
      l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:Hide()
    elseif l_9_0._border == "THIN" then
      l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:FromUITex("\\Interface\\BF_Base\\widget\\border.UITex", 0)
      l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:Show()
    else
      assert(false, "Invalid border type.")
    end
  else
    l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:Hide()
  end
end


