-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: minimapicon.lua 

BFMinimapIcon = classv2()
local l_0_0 = {}
l_0_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9 = 13333
l_0_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656 = 13333
local l_0_1 = {}
local l_0_2 = {}
local l_0_3 = {}
local l_0_6 = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4, l_1_5)
  -- upvalues: l_0_2 , l_0_1
  local l_1_6, l_1_11, l_1_12, l_1_13, l_1_14, l_1_15, l_1_16, l_1_17, l_1_18, l_1_19, l_1_20, l_1_21, l_1_22, l_1_23 = nil
  if #l_0_2 == 0 then
    l_1_6 = BFButton.new(Station.Lookup("Topmost/Minimap/Wnd_Minimap/Minimap_Map"), l_1_1, l_1_2)
    l_1_6:SetStyle("TRANSPARENT")
    l_1_6.OnMouseEnter = function(l_2_0)
      local l_2_1, l_2_2 = l_2_0:GetAbsPos()
      local l_2_3, l_2_4 = l_2_0:GetSize()
      local l_2_5 = OutputTip
      local l_2_6 = l_2_0.tip
      local l_2_7 = 200
      do
        local l_2_8 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_2_5(l_2_6, l_2_7, l_2_8)
      end
       -- WARNING: undefined locals caused missing assignments!
    end
    l_1_6.OnMouseLeave = function(l_3_0)
      HideTip()
    end
    table.insert(l_0_1, l_1_6)
    do break end
  end
  for l_1_10,i_2 in pairs(l_0_2) do
    l_1_6 = i_2
    l_1_6:SetSize(l_1_1, l_1_2)
    table.insert(l_0_1, l_1_6)
    table.remove(l_0_2, l_1_10)
    do break end
  end
  l_1_6:SetNormalImage(l_1_3, l_1_4)
  l_1_6:SetHotImage(l_1_3, l_1_4)
  l_1_6:SetPressedImage(l_1_3, l_1_4)
  l_1_6:SetDisabledImage(l_1_3, l_1_4)
  l_1_6.tip = l_1_5
  l_1_6.widget = l_1_0
  l_1_6:Show()
  return l_1_6
end

do
  function()
  -- upvalues: l_0_6 , l_0_0 , l_0_3 , l_0_4 , l_0_5
  local l_3_0 = BFFrame.new(0, 0, "NONE")
  local l_3_1, l_3_2 = l_3_0:AddListener, l_3_0
  local l_3_3 = {}
  l_3_3.OnUpdate = function()
    -- upvalues: l_0_6 , l_0_0 , l_0_3 , l_0_4 , l_0_5
    if GetTime() - l_0_6 < 500 then
      return 
    end
    l_0_6 = GetTime()
    local l_4_0 = (GetClientPlayer())
    local l_4_1, l_4_2, l_4_3, l_4_4, l_4_5, l_4_6, l_4_7 = nil, nil, nil, nil, nil, nil, nil
    local l_4_8 = {}
    if l_4_0 then
      l_4_3 = math.modf(l_4_0.nX / l_0_0.BigFoot_aacf928ffa23e474a000b1b6292d02a9)
      l_4_5 = math.modf(l_4_0.nY / l_0_0.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656)
    end
    if l_4_3 and l_4_5 and l_0_3[l_4_3] and l_0_3[l_4_5] then
      table.insert(l_4_8, l_0_3[l_4_3][l_4_5])
      if l_4_4 < 0.5 and l_0_3[l_4_3 - 1] then
        table.insert(l_4_8, l_0_3[l_4_3 - 1][l_4_5])
        if l_4_6 < 0.5 then
          table.insert(l_4_8, l_0_3[l_4_3][l_4_5 - 1])
          table.insert(l_4_8, l_0_3[l_4_3 - 1][l_4_5 - 1])
        end
      else
        table.insert(l_4_8, l_0_3[l_4_3][l_4_5 + 1])
        table.insert(l_4_8, l_0_3[l_4_3 - 1][l_4_5 + 1])
      end
    elseif l_4_4 >= 0.5 and l_0_3[l_4_3 + 1] then
      table.insert(l_4_8, l_0_3[l_4_3 + 1][l_4_5])
      if l_4_6 < 0.5 then
        table.insert(l_4_8, l_0_3[l_4_3][l_4_5 - 1])
        table.insert(l_4_8, l_0_3[l_4_3 + 1][l_4_5 - 1])
      end
    else
      table.insert(l_4_8, l_0_3[l_4_3][l_4_5 + 1])
      table.insert(l_4_8, l_0_3[l_4_3 + 1][l_4_5 + 1])
    end
    do break end
    do
      local l_4_9, l_4_10, l_4_11, l_4_12, l_4_13 = ipairs(l_4_8)
      for l_4_17,l_4_18 in ipairs(l_4_13) do
        l_4_7 = math.sqrt(math.abs((l_4_0.nX - l_4_18.BigFoot_b254e387cf58e982ba24fcb3e8a63995) * (l_4_0.nX - l_4_18.BigFoot_b254e387cf58e982ba24fcb3e8a63995) + (l_4_0.nY - l_4_18.BigFoot_a0f453fd098c0b0fda780f69cda6ffbf) * (l_4_0.nY - l_4_18.BigFoot_a0f453fd098c0b0fda780f69cda6ffbf)))
        l_4_1 = BigFoot_MinimapPosToScreenPos(l_4_18.BigFoot_b254e387cf58e982ba24fcb3e8a63995, l_4_18.BigFoot_a0f453fd098c0b0fda780f69cda6ffbf, l_4_18.z)
        if not l_4_18.button and l_4_7 < 6000 then
          l_4_18.button = l_0_4(l_4_18, l_4_18.BigFoot_aacf928ffa23e474a000b1b6292d02a9, l_4_18.BigFoot_ba70ac59c8a4b2cc67cf63223c84b656, l_4_18.BigFoot_51bbc6646cac6748cc62569220600b52, l_4_18._frame, l_4_18.BigFoot_b3949a5a54bc96b70d9d923c7aa1becb)
          l_4_18.button:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_4_1 - l_4_18.button:GetWidth() / 2, l_4_2 - l_4_18.button:GetHeight() / 2)
        elseif l_4_18.button and l_4_7 < 6000 then
          l_4_18.button:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_4_1 - l_4_18.button:GetWidth() / 2, l_4_2 - l_4_18.button:GetHeight() / 2)
          if l_4_18.BigFoot_005f68c584de72ac333e94bace719d7a and l_4_18.BigFoot_7ea16d69ee68978a562320944cf1ea36 then
            if l_4_7 < 2500 and not l_4_18.button._iconTmp then
              l_4_18.button._iconTmp = l_4_18.BigFoot_51bbc6646cac6748cc62569220600b52
              l_4_18.button:SetNormalImage("Interface\\BF_Base\\widget\\artwork\\minimapicon\\circle.tga")
              l_4_18.button:SetHotImage("Interface\\BF_Base\\widget\\artwork\\minimapicon\\circle.tga")
              l_4_18.button:SetPressedImage("Interface\\BF_Base\\widget\\artwork\\minimapicon\\circle.tga")
              l_4_18.button:SetDisabledImage("Interface\\BF_Base\\widget\\artwork\\minimapicon\\circle.tga")
            end
          elseif l_4_7 >= 2500 and l_4_18.button._iconTmp then
            l_4_18.button:SetNormalImage(l_4_18.button._iconTmp, l_4_18._frame)
            l_4_18.button:SetHotImage(l_4_18.button._iconTmp, l_4_18._frame)
            l_4_18.button:SetPressedImage(l_4_18.button._iconTmp, l_4_18._frame)
            l_4_18.button:SetDisabledImage(l_4_18.button._iconTmp, l_4_18._frame)
            l_4_18.button._iconTmp = nil
          end
        elseif l_4_18.button and l_4_7 >= 6000 then
          l_0_5(l_4_18.button)
          l_4_18.button = nil
        end
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
  l_3_1(l_3_2, l_3_3)
end
()
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

 -- WARNING: undefined locals caused missing assignments!

