-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetTargetEx.lua 

if not TargetTargetEx then
  TargetTargetEx = {}
end
TargetTargetEx.nLastdwID = 0
local l_0_0, l_0_1, l_0_2 = nil, nil, nil
local l_0_3 = "Interface\\BF_TargetEx\\TargetTargetEx.ini"
TargetTargetEx.HideSystemTTargetBuff = function()
  local l_1_0 = Station.Lookup("Normal/TargetTarget")
  if not l_1_0 or not l_1_0:IsVisible() then
    return 
  end
  local l_1_1 = l_1_0:Lookup("", "")
  local l_1_2 = l_1_1:Lookup("Handle_Buff")
  local l_1_3 = l_1_1:Lookup("Handle_Debuff")
  l_1_2:Hide()
  l_1_3:Hide()
end

TargetTargetEx.FixTargetBgImage = function()
  local l_2_0 = Station.Lookup("Normal/TargetTarget")
  if not l_2_0 or not l_2_0:IsVisible() then
    return 
  end
  local l_2_1 = l_2_0:Lookup("", "")
  local l_2_2 = l_2_1:Lookup("Image_TarBgF")
  if l_2_0.dwType == TARGET.NPC then
    return 
  end
  if l_2_0.dwMountType == 6 or l_2_0.dwMountType == 10 then
    l_2_2:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 6)
  end
end

TargetTargetEx.FixTargetTextAndImage = function()
  local l_3_0 = Station.Lookup("Normal/TargetTarget")
  if not l_3_0 or not l_3_0:IsVisible() then
    return 
  end
  local l_3_1 = l_3_0:Lookup("", "")
  local l_3_2 = l_3_1:Lookup("Text_Health")
  local l_3_3 = l_3_1:Lookup("Text_Mana")
  l_3_2:SetAlpha(0)
  l_3_3:SetAlpha(0)
end

TargetTargetEx.AdjustAllItems = function()
  -- upvalues: l_0_1 , l_0_2
  local l_4_0 = Station.Lookup("Normal/TargetTarget")
  if not l_4_0 or not l_4_0:IsVisible() then
    l_0_1:Clear()
    l_0_2:Clear()
    return 
  end
  local l_4_1 = l_4_0:Lookup("", "")
  local l_4_2 = l_4_1:Lookup("Handle_Bar")
  local l_4_3, l_4_4 = l_4_1:GetAbsPos()
  l_4_2:SetAbsPos(l_4_3 + 50, l_4_4 + 55)
  local l_4_5 = Station.Lookup("Normal/TargetTargetEx")
  local l_4_6 = l_4_5:Lookup("", "")
  l_4_6:SetAbsPos(l_4_3 + 10, l_4_4 + 73)
end

TargetTargetEx.AppendText = function()
  local l_5_0 = Station.Lookup("Normal/TargetTarget")
  if not l_5_0 or not l_5_0:IsVisible() then
    return 
  end
  local l_5_1 = l_5_0:Lookup("", "")
  local l_5_2, l_5_3 = l_5_1:GetAbsPos()
  if not nil then
    local l_5_4, l_5_5, l_5_7, l_5_9 = l_5_1:AppendItemFromIni("Interface/BF_TargetEx/TargetTargetEx.ini", "Text_Health_New"), nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_5_5 then
    local l_5_6, l_5_8, l_5_10 = , l_5_1:AppendItemFromIni("Interface/BF_TargetEx/TargetTargetEx.ini", "Text_Mana_New")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_5_6:SetAbsPos(l_5_2 + 70, l_5_3 + 28)
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_5_8:SetAbsPos(l_5_2 + 88, l_5_3 + 43)
end

TargetTargetEx.OnFrameCreate = function()
  this:RegisterEvent("BUFF_UPDATE")
  TargetTargetEx.Init(this)
end

TargetTargetEx.OnFrameBreathe = function()
  -- upvalues: l_0_1 , l_0_2
  local l_7_0 = Station.Lookup("Normal/TargetTarget")
  if not l_7_0 or not l_7_0:IsVisible() then
    l_0_1:Clear()
    l_0_2:Clear()
    TargetTargetEx.nLastdwID = 0
    return 
  end
  TargetTargetEx.AppendText()
  if l_7_0 and l_7_0:IsVisible() and TargetTargetEx.nLastdwID ~= l_7_0.dwLastTarget then
    TargetTargetEx.nLastdwID = l_7_0.dwLastTarget
    TargetTargetEx.RefreshBuff(l_7_0, true, true)
  end
  if TargetEx.bShowTTBuffTime then
    TargetTargetEx.UpdateTargetTargetBufferTime(l_0_1)
    TargetTargetEx.UpdateTargetTargetBufferTime(l_0_2)
  end
  TargetTargetEx.UpdateLM(l_7_0)
  TargetTargetEx.UpdateAction(l_7_0)
end

TargetTargetEx.Init = function(l_8_0)
  -- upvalues: l_0_0 , l_0_1 , l_0_2
  l_0_0 = l_8_0:Lookup("", "")
  l_0_1 = l_0_0:Lookup("Handle_Buff")
  l_0_2 = l_0_0:Lookup("Handle_Debuff")
  l_0_1:Clear()
  l_0_2:Clear()
  l_0_1.tItem = {}
  l_0_2.tItem = {}
end

local l_0_4 = function(l_9_0, l_9_1)
  if not l_9_0 and l_9_1 then
    local l_9_2 = GetPlayer(l_9_1)
    if not l_9_2 then
      return false
    end
    l_9_0 = l_9_2.GetKungfuMount().dwMountType
  end
  if not l_9_0 then
    return false
  end
  if l_9_0 == 6 or l_9_0 == 10 then
    return true
  end
  return false
end

TargetTargetEx.UpdateLM = function(l_10_0)
  -- upvalues: l_0_4
  local l_10_1 = GetTargetHandle(l_10_0.dwType, l_10_0.dwID)
  local l_10_2 = l_10_0:Lookup("", "")
  local l_10_3 = l_10_2:Lookup("Text_Health_New")
  local l_10_4 = l_10_2:Lookup("Text_Mana_New")
  local l_10_5 = ""
  local l_10_6 = ""
  local l_10_7 = 0
  local l_10_8 = 0
  if l_10_1 then
    if l_10_1.nMaxLife > 0 then
      l_10_7 = l_10_1.nCurrentLife / l_10_1.nMaxLife
      l_10_5 = TargetEx.GetStateString(l_10_1.nCurrentLife, l_10_1.nMaxLife, l_10_0.dwType, false)
    end
  end
  if l_10_1.nMaxMana > 0 and l_10_1.nMaxMana ~= 1 then
    l_10_8 = l_10_1.nCurrentMana / l_10_1.nMaxMana
    if l_10_0.dwType == TARGET.PLAYER then
      l_10_6 = TargetEx.GetStateString(l_10_1.nCurrentMana, l_10_1.nMaxMana, l_10_0.dwType, false)
    end
  else
    if l_10_0.dwType == TARGET.NPC then
      l_10_6 = TargetEx.GetStateString(l_10_1.nCurrentMana, l_10_1.nMaxMana, l_10_0.dwType, false, "npc")
    end
  end
  l_10_3:SetText(l_10_5)
  l_10_3:Show()
  l_10_4:SetText(l_10_6)
  l_10_4:Show()
  if l_10_0.dwType == TARGET.PLAYER and l_10_0.dwMountType and l_0_4(l_10_0.dwMountType) then
    l_10_4:Hide()
  end
end

TargetTargetEx.UpdateAction = function(l_11_0)
  local l_11_1 = GetTargetHandle(l_11_0.dwType, l_11_0.dwID)
  local l_11_2 = l_11_0:Lookup("", "Handle_Bar")
  if not l_11_1 then
    l_11_2:Hide()
    return 
  end
  if l_11_0.dwType == TARGET.PLAYER and l_11_1.GetOTActionState() == 2 then
    local l_11_3, l_11_4, l_11_5 = TargetEx.GetSkillChannelState(l_11_0.dwID)
  end
  if l_11_3 then
    l_11_2:SetAlpha(255)
    l_11_2:Show()
    l_11_2:Lookup("Image_Progress"):Show()
    l_11_2:Lookup("Image_FlashS"):Hide()
    l_11_2:Lookup("Image_FlashF"):Hide()
    l_11_2:Lookup("Text_Name"):SetText(l_11_3)
    l_11_2:Lookup("Image_Progress"):SetPercentage(l_11_4)
    l_11_2.nActionState = 5
  end
  if l_11_4 < 0.0175 then
    TargetEx.tChannelList[l_11_0.dwID] = nil
  end
end

TargetTargetEx.OnEvent = function(l_12_0)
  -- upvalues: l_0_1 , l_0_2
  if l_12_0 == "BUFF_UPDATE" then
    local l_12_1 = Station.Lookup("Normal/TargetTarget")
    if not l_12_1 or not l_12_1:IsVisible() then
      return 
    end
  end
  if l_12_1 and l_12_1.dwID == arg0 then
    if arg7 then
      TargetTargetEx.RefreshBuff(l_12_1, true, true)
    end
  else
    local l_12_2 = arg1
    local l_12_3 = arg3
    if l_12_2 then
      TargetTargetEx.RefreshBuff(l_12_1, l_12_3, not l_12_3)
    end
  elseif l_12_3 then
    TargetTargetEx.UpdateSingleBuff(l_0_1, arg2, l_12_3, arg4, arg5, arg6, arg8, arg9)
  else
    TargetTargetEx.UpdateSingleBuff(l_0_2, arg2, l_12_3, arg4, arg5, arg6, arg8, arg9)
  end
end

TargetTargetEx.RefreshBuff = function(l_13_0, l_13_1, l_13_2)
  -- upvalues: l_0_1 , l_0_2
  local l_13_3 = GetTargetHandle(l_13_0.dwType, l_13_0.dwID)
  local l_13_4 = l_0_1
  local l_13_5 = l_0_2
  if not l_13_3 then
    return 
  end
  if l_13_1 then
    l_13_4.nNeedBox = 0
  end
  if l_13_2 then
    l_13_5.nNeedBox = 0
  end
  local l_13_6 = l_13_4:GetItemCount()
  local l_13_7 = l_13_5:GetItemCount()
  local l_13_9 = function(l_14_0)
    -- upvalues: l_13_0 , l_13_1 , l_13_4 , l_13_6 , l_13_2 , l_13_5 , l_13_7
    local l_14_1 = nil
    if not Table_BuffIsVisible(l_14_0.dwID, l_14_0.nLevel) then
      return 
    end
    do return end
    if TargetEx.bShieldOthersBuff and l_14_0.dwSkillSrcID and l_14_0.dwSkillSrcID ~= 0 and l_14_0.dwSkillSrcID ~= l_13_0.dwID and l_14_0.dwSkillSrcID ~= UI_GetClientPlayerID() and IsPlayer(l_14_0.dwSkillSrcID) then
      return 
    end
    if l_13_1 and l_14_0.bCanCancel then
      if l_13_4.nNeedBox < l_13_6 then
        l_14_1 = l_13_4:Lookup(l_13_4.nNeedBox)
      end
      l_13_4.nNeedBox = l_13_4.nNeedBox + 1
      TargetTargetEx.CreateBuff(l_13_4, l_14_1, l_14_0.nIndex, true, l_14_0.dwID, l_14_0.nStackNum, l_14_0.nEndFrame, l_14_0.nLevel, l_14_0.dwSkillSrcID)
    elseif l_13_2 and not l_14_0.bCanCancel then
      if l_13_5.nNeedBox < l_13_7 then
        l_14_1 = l_13_5:Lookup(l_13_5.nNeedBox)
      end
      l_13_5.nNeedBox = l_13_5.nNeedBox + 1
      TargetTargetEx.CreateBuff(l_13_5, l_14_1, l_14_0.nIndex, false, l_14_0.dwID, l_14_0.nStackNum, l_14_0.nEndFrame, l_14_0.nLevel, l_14_0.dwSkillSrcID)
    end
  end
  if l_13_3.GetBuffList() then
    local l_13_10 = nil
    local l_13_11 = UI_GetClientPlayerID()
    for l_13_15,l_13_16 in pairs(l_13_10) do
      local l_13_12 = {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      if R16_PC38.dwSkillSrcID == l_13_11 or TargetEx.IsSpecialBuff(R16_PC38.dwID, l_13_0.dwType) then
        l_13_9(R16_PC38)
      else
        table.insert(l_13_12, l_13_16)
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_13_20,l_13_21 in pairs(l_13_12) do
      local l_13_17 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_13_9(l_13_10[R16_PC38])
    end
  end
  if l_13_1 then
    l_13_11 = TargetTargetEx
    l_13_11 = l_13_11.HideLeftItem
    l_13_11(l_13_4, l_13_4.nNeedBox)
  end
  if l_13_2 then
    l_13_11 = TargetTargetEx
    l_13_11 = l_13_11.HideLeftItem
    l_13_11(l_13_5, l_13_5.nNeedBox)
  end
end

TargetTargetEx.CreateBuff = function(l_14_0, l_14_1, l_14_2, l_14_3, l_14_4, l_14_5, l_14_6, l_14_7, l_14_8)
  -- upvalues: l_0_1 , l_0_2
  local l_14_9 = (Station.Lookup("Normal/TargetTarget"))
  local l_14_10 = nil
  if not l_14_1 then
     -- DECOMPILER ERROR: unhandled construct in 'if'

    if l_14_3 and l_0_1:GetItemCount() == TargetEx.nBuffMax then
      if (l_14_8 and UI_GetClientPlayerID() == l_14_8) or TargetEx.IsSpecialBuff(l_14_4, l_14_9.dwType) then
        l_14_0:RemoveItem(TargetEx.nBuffMax - 1)
        l_14_0:FormatAllItemPos()
      end
    else
      return 
    end
    do return end
    if l_0_2:GetItemCount() == TargetEx.nDebuffMax then
      if (l_14_8 and UI_GetClientPlayerID() == l_14_8) or TargetEx.IsSpecialBuff(l_14_4, l_14_9.dwType) then
        l_14_0:RemoveItem(TargetEx.nDebuffMax - 1)
        l_14_0:FormatAllItemPos()
      end
    else
      return 
    end
    local l_14_11 = l_14_0:GetItemCount()
    l_14_0:AppendItemFromString("<box>w=30 h=30 postype=7 eventid=262912</box>")
    l_14_1 = l_14_0:Lookup(l_14_11)
    local l_14_12, l_14_13 = l_14_1:GetSize()
    l_14_1.nW = l_14_12
    l_14_1.OnItemMouseEnter = function()
      -- upvalues: l_14_9 , l_14_1
      this:SetObjectMouseOver(1)
      local l_15_2, l_15_3 = math.floor(this.nEndFrame - GetLogicFrameCount()) / 16 + 1, this:GetAbsPos()
      local l_15_4, l_15_5 = , this:GetSize()
      if l_15_2 < 0 then
        l_15_2 = 0
        local l_15_0, l_15_1 = nil
      end
      local l_15_6 = nil
      local l_15_7 = OutputBuffTip
      local l_15_8 = l_14_9.dwID
      local l_15_9 = this.dwBuffID
      local l_15_10 = this.nLevel
      if this.bShowTime then
        local l_15_11 = this.nCount
      end
      local l_15_12 = nil
      local l_15_13 = not l_14_1.bCanCancel
      l_15_7(l_15_8, l_15_9, l_15_10, l_15_12, l_15_13, l_15_2, {l_15_3, l_15_4, l_15_5, l_15_6})
    end
    l_14_1.OnItemMouseHover = l_14_1.OnItemMouseEnter
    l_14_1.OnItemMouseLeave = function()
      HideTip()
      this:SetObjectMouseOver(0)
    end
    l_14_10 = true
  end
  local l_14_14 = "b" .. l_14_2
  l_14_1:SetName(l_14_14)
  l_14_0.tItem[l_14_14] = l_14_1
  if (l_14_8 and UI_GetClientPlayerID() == l_14_8) or TargetEx.IsSpecialBuff(l_14_4, l_14_9.dwType) then
    l_14_1:SetIndex(0)
  end
  l_14_1:SetSize(l_14_1.nW, l_14_1.nH)
  l_14_1:Show()
  l_14_1:SetName("b" .. l_14_2)
  l_14_1.nCount = l_14_5
  l_14_1.nEndFrame = l_14_6
  l_14_1.bCanCancel = l_14_3
  l_14_1.dwBuffID = l_14_4
  l_14_1.nLevel = l_14_7
  l_14_1.nIndex = l_14_2
  l_14_1.bSparking = Table_BuffNeedSparking(l_14_4, l_14_7)
  l_14_1.bShowTime = Table_BuffNeedShowTime(l_14_4, l_14_7)
  l_14_1:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_14_4)
  l_14_1:SetObjectIcon(Table_GetBuffIconID(l_14_4, l_14_7))
  l_14_1:SetOverTextFontScheme(0, 15)
  l_14_1:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
  l_14_1:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
  l_14_1:SetAlpha(255)
  if l_14_5 > 1 then
    l_14_1:SetOverText(0, l_14_5)
  else
    l_14_1:SetOverText(0, "")
  end
  return l_14_10
end

TargetTargetEx.UpdateSingleBuff = function(l_15_0, l_15_1, l_15_2, l_15_3, l_15_4, l_15_5, l_15_6, l_15_7)
  if not Table_BuffIsVisible(l_15_3, l_15_6) then
    return 
  end
  do return end
  if TargetEx.bShieldOthersBuff and l_15_7 and l_15_7 ~= 0 and l_15_7 ~= Station.Lookup("Normal/TargetTarget").dwID and l_15_7 ~= UI_GetClientPlayerID() and IsPlayer(l_15_7) then
    return 
  end
  if not l_15_0:Lookup("b" .. l_15_1) then
    local l_15_9 = nil
    if l_15_0.nNeedBox < l_15_0:GetItemCount() then
      l_15_9 = l_15_0:Lookup(l_15_0.nNeedBox)
      local l_15_8, l_15_10, l_15_11 = nil
    end
    l_15_0.nNeedBox = l_15_0.nNeedBox + 1
  end
  local l_15_12 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if nil then
    l_15_0:FormatAllItemPos()
  end
end

TargetTargetEx.HideLeftItem = function(l_16_0, l_16_1)
  local l_16_2 = l_16_0:GetItemCount()
  local l_16_3 = l_16_2 - l_16_1
  if l_16_3 > 10 then
    for l_16_7 = 1, l_16_3 do
      l_16_0:RemoveItem(l_16_2 - l_16_7)
    end
    do break end
  end
  l_16_2 = l_16_2 - 1
  for l_16_11 = l_16_1, l_16_2 do
    local l_16_12 = l_16_0:Lookup(l_16_11)
    l_16_12:Hide()
    l_16_12:SetName("")
  end
  l_16_0:FormatAllItemPos()
end

TargetTargetEx.UpdateTargetTargetBufferTime = function(l_17_0)
  local l_17_1 = l_17_0:GetItemCount() - 1
  for l_17_5 = 0, l_17_1 do
    local l_17_6 = l_17_0:Lookup(l_17_5)
    if l_17_6 then
      local l_17_7, l_17_8, l_17_9 = TargetEx.GetLeftTime(l_17_6.nEndFrame)
    end
    if l_17_9 > 0 then
      l_17_6:SetOverTextFontScheme(1, l_17_8)
      l_17_6:SetOverText(1, l_17_7)
    end
  end
end

Wnd.OpenWindow(l_0_3, "TargetTargetEx")

