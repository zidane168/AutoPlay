-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: DebuffSettingPanel.lua 

DebuffSettingPanel = {}
DebuffSettingPanel.frameSelf = nil
DebuffSettingPanel.handleList = nil
DebuffSettingPanel.handleListSelected = nil
local l_0_0 = DebuffSettingPanel
local l_0_1 = {}
local l_0_2 = {}
l_0_2.szName = "ݶ��ʥ��"
l_0_2.szDesc = "��Ÿ���debuff����"
l_0_2.szContent = "����ָ,ʹѪָ,����ӡ,���ư˵�,ʥ��,ԭ�︿Ѩ��"
l_0_2.bEnable = true
local l_0_3 = {}
l_0_3.szName = "��Ԩ��"
l_0_3.szDesc = "��Ÿ���debuff����"
l_0_3.szContent = "���,ͬ����֦,����,�ױ�,ǧ����Ǵ�"
l_0_3.bEnable = true
local l_0_4 = {}
l_0_4.szName = "��������hot"
l_0_4.szDesc = "���buff����"
l_0_4.szContent = "��Ԫ����,����"
l_0_4.bEnable = false
local l_0_5 = {}
l_0_5.szName = "������hot"
l_0_5.szDesc = "���buff����"
l_0_5.szContent = "����"
l_0_5.bEnable = false
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

l_0_0.BF_DebuffListContent1 = l_0_1
l_0_0 = RegisterCustomData
l_0_1 = "DebuffSettingPanel.BF_DebuffListContent1"
l_0_0(l_0_1)
l_0_0 = 1520
l_0_1 = 646
l_0_2 = "Interface/BF_RaidGridEx/DebuffSettingPanel.ini"
l_0_3 = DebuffSettingPanel
l_0_5 = {255, 0, 0}
l_0_5 = {0, 255, 0}
l_0_5 = {0, 0, 255}
l_0_5 = {255, 255, 0}
l_0_5 = {255, 0, 255}
l_0_5 = {0, 255, 255}
l_0_5 = {255, 128, 0}
l_0_5 = {0, 0, 0}
l_0_5 = {255, 255, 255}
l_0_3.tColorCover, l_0_4 = l_0_4, {["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5, ["��"] = l_0_5}
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_1_0 = {}
  do break end
  do
    local l_1_1, l_1_2, l_1_3, l_1_4, l_1_5 = pairs(DebuffSettingPanel.BF_DebuffListContent1)
    local l_1_6 = l_1_5.szContent
    if l_1_5.bEnable and l_1_6 and type(l_1_6) == "string" and l_1_6 ~= "" then
      l_1_6 = l_1_6:gsub("%s", "")
      l_1_6 = l_1_6:gsub("��", ",")
      l_1_6 = l_1_6:gsub("��", "(")
      l_1_6 = l_1_6:gsub("��", ")")
      l_1_6 = l_1_6 .. ","
      local l_1_7 = 0
      for l_1_11 = 1, 20 do
        local l_1_12, l_1_13, l_1_14 = l_1_6:find(",(.*)")
      if not l_1_12 then
        end
        do break end
      end
      local l_1_15 = l_1_6:sub(1, l_1_12 - 1)
      if l_1_15 and l_1_15 ~= "" then
        local l_1_16 = l_1_15:match("%b()")
        if l_1_16 and l_1_16 ~= "" then
          l_1_16 = l_1_16:sub(2, -2)
          l_1_15 = l_1_15:gsub("%b()", "")
        end
      end
      if not l_1_0[l_1_15] then
        l_1_7 = l_1_7 + 1
        local l_1_17 = {}
        local l_1_18 = l_1_7
        local l_1_19 = nil
        if not l_1_16 then
          l_1_19 = ""
        end
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_1_0[l_1_15] = l_1_17
      end
      l_1_6 = l_1_14
    end
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers!

return l_1_0
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_3.FormatDebuffNameList = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  this:RegisterEvent("UI_SCALED")
  DebuffSettingPanel.OnEvent("UI_SCALED")
  DebuffSettingPanel.frameSelf = this
  DebuffSettingPanel.handleList = this:Lookup("", "Handle_List")
  DebuffSettingPanel.UpdateList()
end

l_0_3.OnFrameCreate = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  if not GetClientPlayer() then
    return 
  end
end

l_0_3.OnFrameBreathe = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function(l_4_0)
  if l_4_0 == "UI_SCALED" then
    this:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  end
end

l_0_3.OnEvent = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_5_0 = DebuffSettingPanel.handleList
  l_5_0:Clear()
  for l_5_4,l_5_5 in pairs(DebuffSettingPanel.BF_DebuffListContent1) do
    DebuffSettingPanel.NewListDebuffGroup(l_5_4)
  end
end

l_0_3.UpdateList = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function(l_6_0, l_6_1)
  -- upvalues: l_0_2 , l_0_1 , l_0_0
  local l_6_2 = DebuffSettingPanel.BF_DebuffListContent1
  local l_6_3 = nil
  if not l_6_0 then
    l_6_3 = -1
  end
  l_6_2 = l_6_2[l_6_3]
  if not l_6_2 then
    l_6_3 = DebuffSettingPanel
    l_6_3 = l_6_3.BF_DebuffListContent1
    l_6_3 = #l_6_3
    l_6_0 = l_6_3 + 1
    l_6_2, l_6_3 = l_6_3, {szName = "�½��飨" .. l_6_0 .. "��", szDesc = "", szContent = "", bEnable = true}
    l_6_3 = table
    l_6_3 = l_6_3.insert
    l_6_3(DebuffSettingPanel.BF_DebuffListContent1, l_6_2)
  end
  l_6_3 = DebuffSettingPanel
  l_6_3 = l_6_3.handleList
  local l_6_4 = l_6_3:AppendItemFromIni(l_0_2, "HI")
  l_6_4:Lookup("Name"):SetText(l_6_2.szName)
  l_6_4.nIndex = l_6_0
  local l_6_5 = l_6_4:Lookup("Box_Skill")
  local l_6_6 = l_0_1
  if l_6_2.bEnable then
    l_6_6 = l_0_0
  end
  l_6_5:Show()
  l_6_5:SetObject(1, 0)
  l_6_5:ClearObjectIcon()
  l_6_5:SetObjectIcon(l_6_6)
  l_6_5.nIndex = l_6_0
  if l_6_1 then
    DebuffSettingPanel.SelectListHandle(l_6_4)
  end
  DebuffSettingPanel.UpdateScrollInfo()
  return l_6_4
end

l_0_3.NewListDebuffGroup = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function(l_7_0)
  local l_7_1 = l_7_0.nIndex
  local l_7_2 = DebuffSettingPanel.BF_DebuffListContent1[l_7_1]
  if l_7_2 then
    table.remove(DebuffSettingPanel.BF_DebuffListContent1, l_7_1)
    DebuffSettingPanel.UpdateList()
    DebuffSettingPanel.UpdateScrollInfo()
    DebuffSettingPanel.handleListSelected = nil
  end
end

l_0_3.DelListDebuffGroup = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_8_0 = DebuffSettingPanel.handleList
  l_8_0:FormatAllItemPos()
  local l_8_1, l_8_2 = l_8_0:GetSize()
  local l_8_3, l_8_4 = l_8_0:GetAllItemSize()
  local l_8_5 = math.ceil((l_8_4 - l_8_2) / 10)
  local l_8_6 = l_8_0:GetRoot():Lookup("Scroll_List")
  if l_8_5 > 0 then
    l_8_6:Show()
    l_8_6:GetParent():Lookup("Btn_Up"):Show()
    l_8_6:GetParent():Lookup("Btn_Down"):Show()
  else
    l_8_6:Hide()
    l_8_6:GetParent():Lookup("Btn_Up"):Hide()
    l_8_6:GetParent():Lookup("Btn_Down"):Hide()
  end
  l_8_6:SetStepCount(l_8_5)
end

l_0_3.UpdateScrollInfo = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_9_0 = this:GetName()
  if l_9_0:match("HI") then
    local l_9_1 = this:Lookup("Sel")
    if l_9_1 then
      l_9_1:Show()
    end
  else
    if l_9_0:match("Box_Skill") then
      this:SetObjectMouseOver(true)
      local l_9_2 = DebuffSettingPanel.BF_DebuffListContent1[this.nIndex]
    end
  end
  if not l_9_2.szDesc then
    local l_9_3 = not l_9_2 or ""
  end
  local l_9_4, l_9_5 = , Cursor.GetPos()
  local l_9_6 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_9_2.bEnable then
    local l_9_7 = "<Text>text=" .. EncodeComponentsString("��ǰ����ģ���Ѿ��رգ���ɫͼ�꣩\n") .. " font=102 </text>"
  end
  local l_9_8 = OutputTip
  local l_9_9 = l_9_7 .. "<Text>text=" .. EncodeComponentsString(l_9_4) .. " font=100 </text>"
  local l_9_10 = 1000
  l_9_8(l_9_9, l_9_10, {l_9_5, l_9_6, 0, 0})
end

l_0_3.OnItemMouseEnter = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_10_0 = this:GetName()
  if l_10_0:match("HI") then
    local l_10_1 = this:Lookup("Sel")
    local l_10_2 = -1
    if DebuffSettingPanel.handleListSelected and DebuffSettingPanel.handleListSelected.nIndex then
      l_10_2 = DebuffSettingPanel.handleListSelected.nIndex
    end
    if l_10_1 and this.nIndex ~= l_10_2 then
      l_10_1:Hide()
    end
  else
    if l_10_0:match("Box_Skill") then
      this:SetObjectMouseOver(false)
      HideTip()
    end
  end
end

l_0_3.OnItemMouseLeave = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  -- upvalues: l_0_1 , l_0_0
  local l_11_0 = this:GetName()
  if l_11_0:match("Box_Skill") then
    local l_11_1 = this.nIndex
    local l_11_2 = DebuffSettingPanel.BF_DebuffListContent1[l_11_1]
    if l_11_2 then
      local l_11_3 = this
      local l_11_4 = l_0_1
      if l_11_2.bEnable then
        l_11_2.bEnable = false
      else
        l_11_2.bEnable = true
        l_11_4 = l_0_0
      end
      l_11_3:SetObjectIcon(l_11_4)
      DebuffSettingPanel.OnItemMouseEnter()
    end
  else
    if l_11_0:match("HI") then
      DebuffSettingPanel.SelectListHandle(this)
    end
  end
end

l_0_3.OnItemLButtonClick = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function(l_12_0)
  if DebuffSettingPanel.handleListSelected then
    local l_12_1 = DebuffSettingPanel.handleListSelected:Lookup("Sel")
  end
  if l_12_1 then
    l_12_1:Hide()
  end
  DebuffSettingPanel.handleListSelected = l_12_0
  local l_12_2 = l_12_0:Lookup("Sel")
  if l_12_2 then
    l_12_2:Show()
  end
  local l_12_3 = DebuffSettingPanel.BF_DebuffListContent1[l_12_0.nIndex]
  if not l_12_3.szName then
    DebuffSettingPanel.frameSelf:Lookup("Edit_Name"):SetText(not l_12_3 or "")
  end
  DebuffSettingPanel.frameSelf:Lookup("Edit_Desc"):SetText(l_12_3.szDesc or "")
  DebuffSettingPanel.frameSelf:Lookup("Edit_Content"):SetText(l_12_3.szContent or "")
  do return end
  DebuffSettingPanel.frameSelf:Lookup("Edit_Name"):SetText("")
  DebuffSettingPanel.frameSelf:Lookup("Edit_Desc"):SetText("")
  DebuffSettingPanel.frameSelf:Lookup("Edit_Content"):SetText("")
end

l_0_3.SelectListHandle = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_13_0 = this:GetName()
  local l_13_1 = DebuffSettingPanel.handleListSelected
  if l_13_1 then
    local l_13_2 = DebuffSettingPanel.handleListSelected.nIndex
    local l_13_3 = DebuffSettingPanel.BF_DebuffListContent1[l_13_2]
  end
  if l_13_3 then
    if l_13_0:match("Edit_Name") then
      l_13_3.szName = this:GetText()
      l_13_1:Lookup("Name"):SetText(l_13_3.szName)
    end
  else
    if l_13_0:match("Edit_Desc") then
      l_13_3.szDesc = this:GetText()
    end
  else
    if l_13_0:match("Edit_Content") then
      l_13_3.szContent = this:GetText()
    end
  end
end

l_0_3.OnEditChanged = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_14_0 = this:GetScrollPos()
  local l_14_1 = this:GetName()
  if l_14_1 == "Scroll_List" then
    local l_14_2 = this:GetScrollPos()
    local l_14_3 = this:GetParent()
    if l_14_2 == 0 then
      l_14_3:Lookup("Btn_Up"):Enable(false)
    else
      l_14_3:Lookup("Btn_Up"):Enable(true)
    end
    if l_14_2 == this:GetStepCount() then
      l_14_3:Lookup("Btn_Down"):Enable(false)
    else
      l_14_3:Lookup("Btn_Down"):Enable(true)
    end
    local l_14_4 = l_14_3:Lookup("", "Handle_List")
    l_14_4:SetItemStartRelPos(0, -l_14_2 * 10)
  end
end

l_0_3.OnScrollBarPosChanged = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_15_0 = this:GetName()
  if l_15_0 == "Btn_Up" then
    this:GetParent():Lookup("Scroll_List"):ScrollPrev(1)
  elseif l_15_0 == "Btn_Down" then
    this:GetParent():Lookup("Scroll_List"):ScrollNext(1)
  end
end

l_0_3.OnLButtonHold = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_16_0 = Station.GetMessageWheelDelta()
  this:GetParent():Lookup("Scroll_List"):ScrollNext(l_16_0)
  return 1
end

l_0_3.OnItemMouseWheel = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  DebuffSettingPanel.OnLButtonHold()
end

l_0_3.OnLButtonDown = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  local l_18_0 = this:GetName()
  if l_18_0 == "Btn_Cancel" then
    DebuffSettingPanel.ClosePanel()
  elseif l_18_0 == "Btn_New" then
    DebuffSettingPanel.NewListDebuffGroup(nil, true)
    PlaySound(SOUND.UI_SOUND, g_sound.Button)
  elseif l_18_0 == "Btn_Close" then
    DebuffSettingPanel.ClosePanel()
  elseif l_18_0 == "Btn_Delete" then
    if not DebuffSettingPanel.handleListSelected then
      return 
    end
    local l_18_1 = function()
      local l_19_0 = DebuffSettingPanel.handleListSelected
      if not l_19_0 then
        return 
      end
      local l_19_1 = DebuffSettingPanel.handleListSelected.nIndex
      local l_19_2 = DebuffSettingPanel.BF_DebuffListContent1[l_19_1]
      if not l_19_2 then
        return 
      end
      DebuffSettingPanel.DelListDebuffGroup(l_19_0)
    end
    do
      if IsShiftKeyDown() then
        l_18_1()
      else
        local l_18_2 = {}
        l_18_2.szMessage = "��ȷ��Ҫɾ��ô������סSHIFT����������ȷ�Ͽ�"
        l_18_2.szName = "del_debufflist_sure"
        l_18_2.fnAutoClose = function()
          return not DebuffSettingPanel.IsPanelOpened()
        end
        local l_18_3 = {}
        l_18_3.szOption = g_tStrings.STR_HOTKEY_SURE
        l_18_3.fnAction = function()
          -- upvalues: l_18_1
          l_18_1()
        end
        local l_18_4 = {}
        l_18_4.szOption = g_tStrings.STR_HOTKEY_CANCEL
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_18_3 = MessageBox
        l_18_4 = l_18_2
        l_18_3(l_18_4)
      end
    end
  end
end

l_0_3.OnLButtonClick = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  if DebuffSettingPanel.IsPanelOpened() then
    return 
  end
  if not Station.Lookup("Topmost/DebuffSettingPanel") then
    local l_19_0, l_19_1 = Wnd.OpenWindow("Interface\\BF_RaidGridEx\\DebuffSettingPanel.ini", "DebuffSettingPanel")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_19_0:Show()
end

l_0_3.OpenPanel = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  if not DebuffSettingPanel.IsPanelOpened() then
    return 
  end
  if not DebuffSettingPanel.frameSelf then
    local l_20_0, l_20_1 = Station.Lookup("Topmost/DebuffSettingPanel")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_20_0:Hide()
end

l_0_3.ClosePanel = l_0_4
l_0_3 = DebuffSettingPanel
l_0_4 = function()
  if not DebuffSettingPanel.frameSelf then
    local l_21_0 = Station.Lookup("Topmost/DebuffSettingPanel")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_21_0 and l_21_0:IsVisible() then
    return true
  end
  return false
end

l_0_3.IsPanelOpened = l_0_4

