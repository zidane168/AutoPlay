-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: LootListExSingle.lua 

LootListExSingle = {}
LootListExSingle.bEnable = false
LootListExSingle.frameSelf = nil
LootListExSingle.HandleTotal = nil
LootListExSingle.handleBox = nil
LootListExSingle.HandleBG = nil
LootListExSingle.SynDoodadList = {}
LootListExSingle.RequestDoodadList = {}
LootListExSingle.ItemsTable = {}
LootListExSingle.LootMoneylower = 0
RegisterCustomData("LootListExSingle.LootMoneylower")
LootListExSingle.NotLootItemTab = {}
RegisterCustomData("LootListExSingle.NotLootItemTab")
LootListExSingle.NotLootDoodadTab = {}
LootListExSingle.doonetimeList = {}
LootListExSingle.LootListType = 1
RegisterCustomData("LootListExSingle.LootListType")
LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 = 0
RegisterCustomData("LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49")
LootListExSingle.bLootGray = true
RegisterCustomData("LootListExSingle.bLootGray")
LootListExSingle.onlyItem = false
RegisterCustomData("LootListExSingle.onlyItem")
LootListExSingle.OnFrameCreate = function()
  local l_1_0 = Station.Lookup("Normal/LootListExSingle")
  l_1_0:RegisterEvent("SYNC_LOOT_LIST")
  l_1_0:RegisterEvent("OPEN_DOODAD")
  l_1_0:RegisterEvent("DOODAD_LEAVE_SCENE")
  l_1_0:RegisterEvent("CUSTOM_DATA_LOADED")
end

local l_0_0 = function(l_2_0)
  local l_2_1 = GetMsgFontString("MSG_SYS")
  OutputMessage("MSG_SYS", FormatString("<text>text=\"<ʰȡ����> \" font=10 r=0 g=196 b=196</text><text>text=\"<D0> \"</text><D1><text>text=\"\n\" font=<D1></text>", l_2_0, l_2_1), true)
end

RegisterEvent("BEGIN_ROLL_ITEM", function()
  if not LootListExSingle.bEnable then
    return 
  end
  local l_3_0 = {}
  l_3_0["ݶ��ӡ"] = true
  l_3_0["�����ֻ�֮��"] = true
  l_3_0["�ȷ���׹"] = true
  l_3_0["������Ƭ"] = true
  local l_3_1 = GetItem(arg1)
  if not l_3_1 then
    return 
  end
  local l_3_2 = l_3_1.nQuality
  local l_3_3 = 2
  if l_3_2 == l_3_3 and (l_3_1.nBindType ~= ITEM_BIND.BIND_ON_PICKED or l_3_1.nBindType ~= ITEM_BIND.BIND_ON_PICKED or l_3_0[l_3_1.szName]) then
    RollItem(arg0, arg1, 2)
    for l_3_7 = 1, 4 do
      do
        local l_3_8 = Station.Lookup("Normal/LootRoll" .. l_3_7)
        if l_3_8 and l_3_8.dwDoodadID == arg0 and l_3_8.dwItemID == arg1 then
          Wnd.CloseWindow(l_3_8:GetName())
        end
        do break end
      end
    end
    local l_3_9 = MakeItemLink("[" .. l_3_1.szName .. "]", " font=10 r=0 g=255 b=32 ", l_3_1.dwID)
    OutputMessage("MSG_SYS", FormatString("<text>text=\"<ʰȡ����> �Զ�ROLL��ɫ���� \" font=10 r=0 g=196 b=196</text> <D0> <text>text=\"��\n\"</text>", l_3_9) .. "\n", true)
  end
end
)
LootListExSingle.OnEvent = function(l_4_0)
  local l_4_1 = GetDoodad(arg0)
  local l_4_2 = GetClientPlayer()
  if l_4_0 == "SYNC_LOOT_LIST" then
    LootListExSingle.AppendSynDoodadList(arg0)
  elseif l_4_0 == "DOODAD_LEAVE_SCENE" then
    LootListExSingle.RemoveSynDoodadList(arg0)
  elseif l_4_0 == "OPEN_DOODAD" then
    LootListExSingle.OpenDoodadEventRecall(arg0)
  elseif l_4_0 == "CUSTOM_DATA_LOADED" then
    LootListExSingle.OnCustomDataLoaded()
  end
end

LootListExSingle.OnLButtonClick = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "Btn_Close" or l_5_0 == "Btn_Cancel" then
    LootListExSingle.ClosePanel()
  elseif l_5_0 == "Btn_LootAll" then
    LootListExSingle.LootAllItems()
  end
end

LootListExSingle.OnItemMouseEnter = function()
  if this:GetType() == "Box" then
    this.bOver = true
    this:SetObjectMouseOver(1)
  end
  if this:GetName():match("ItemBox_") then
    local l_6_0, l_6_1 = this:GetAbsPos()
    local l_6_2, l_6_3 = this:GetSize()
    local l_6_4 = OutputItemTip
    local l_6_5 = UI_OBJECT_ITEM_ONLY_ID
    local l_6_6 = this.dwItemID
    local l_6_7, l_6_8 = nil, nil
    local l_6_9 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_4(l_6_5, l_6_6, l_6_7, l_6_8, l_6_9, l_6_0, l_6_1)
  end
   -- WARNING: undefined locals caused missing assignments!
end

LootListExSingle.OnItemMouseLeave = function()
  HideTip()
  if this:GetName():match("ItemBox_") then
    this.bOver = false
    this:SetObjectMouseOver(0)
  end
end

LootListExSingle.OnItemLButtonClick = function()
  if IsCtrlKeyDown() then
    if IsGMPanelReceiveItem() then
      GMPanel_LinkItem(this.dwItemID)
    else
      EditBox_AppendLinkItem(this.dwItemID)
      return 
    end
    local l_8_0 = this
    if not l_8_0:GetName():match("ItemBox_") or l_8_0:GetAlpha() < 150 then
      return 
    end
    local l_8_1 = GetDoodad(l_8_0.dwDoodadID)
    local l_8_2 = GetClientPlayer()
    if l_8_0.bNeedDistribute then
      local l_8_3 = GetClientTeam().GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE)
      if l_8_3 ~= l_8_2.dwID then
        OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.ERROR_LOOT_DISTRIBUTE)
        return 
      end
      local l_8_4 = l_8_1.GetLooterList()
      if l_8_4 then
        local l_8_5 = l_8_0.dwItemID
        do
          local l_8_7 = function(l_9_0)
            -- upvalues: l_8_0 , l_8_5
            local l_9_1 = GetDoodad(l_8_0.dwDoodadID)
            l_9_1.DistributeItem(l_8_5, l_9_0)
          end
          for l_8_11,l_8_12 in ipairs(l_8_4) do
            local l_8_8 = {fnAction = l_8_7}
            local l_8_14 = table.insert
            local l_8_15 = l_8_8
            l_8_14(l_8_15, {szOption = l_8_13.szName, UserData = l_8_13.dwID, bDisable = not l_8_13.bOnlineFlag})
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          PopupMenu(l_8_8)
        end
      end
      return 
    end
    if l_8_0.bNeedRoll then
      OutputMessage("MSG_ANNOUNCE_RED", g_tStrings.ERROR_LOOT_ROLL)
      return 
    end
    do
      local l_8_17 = nil
      if GetItem(l_8_0.dwItemID) and GetItem(l_8_0.dwItemID).nBindType == ITEM_BIND.BIND_ON_PICKED then
        function()
      -- upvalues: l_8_0 , l_8_1 , l_8_2
      if l_8_0 and l_8_1 and l_8_2 then
        local l_10_0 = GetItem(l_8_0.dwItemID)
        if l_10_0 then
          if l_8_1.CanLoot(l_8_2.dwID) then
            LootItem(l_8_0.dwDoodadID, l_8_0.dwItemID)
            l_8_0:SetAlpha(32)
          end
        else
          OutputMessage("MSG_ANNOUNCE_RED", "�����Ѿ���ʰȡ�������ظ�ʰȡ")
          l_8_0:SetAlpha(32)
          l_8_0:SetObjectCoolDown(true)
        end
      else
        OutputMessage("MSG_ANNOUNCE_RED", "���߲����ڣ�����ʰȡ")
        l_8_0:SetAlpha(32)
        l_8_0:SetObjectCoolDown(true)
      end
      LootListExSingle.CheckEmptyToClose()
    end()
        PlayItemSound(l_8_0.nUiId, true)
       -- DECOMPILER ERROR: Confused about usage of registers!

      else
        function()
      -- upvalues: l_8_0 , l_8_1 , l_8_2
      if l_8_0 and l_8_1 and l_8_2 then
        local l_10_0 = GetItem(l_8_0.dwItemID)
        if l_10_0 then
          if l_8_1.CanLoot(l_8_2.dwID) then
            LootItem(l_8_0.dwDoodadID, l_8_0.dwItemID)
            l_8_0:SetAlpha(32)
          end
        else
          OutputMessage("MSG_ANNOUNCE_RED", "�����Ѿ���ʰȡ�������ظ�ʰȡ")
          l_8_0:SetAlpha(32)
          l_8_0:SetObjectCoolDown(true)
        end
      else
        OutputMessage("MSG_ANNOUNCE_RED", "���߲����ڣ�����ʰȡ")
        l_8_0:SetAlpha(32)
        l_8_0:SetObjectCoolDown(true)
      end
      LootListExSingle.CheckEmptyToClose()
    end()
        PlayItemSound(l_8_0.nUiId, true)
      end
      LootListExSingle.CheckEmptyToClose()
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- WARNING: missing end command somewhere! Added here
  end
end

LootListExSingle.OnCheckBoxCheck = function()
  local l_9_0 = this:GetName()
  if l_9_0 == "CheckBox_LootGray" then
    LootListExSingle.bLootGray = true
  end
end

LootListExSingle.OnCheckBoxUncheck = function()
  local l_10_0 = this:GetName()
  if l_10_0 == "CheckBox_LootGray" then
    LootListExSingle.bLootGray = false
  end
end

LootListExSingle.OnFrameBreathe = function()
  if Station.Lookup("Normal/LootList") then
    Station.Lookup("Normal/LootList").IsVisible = function()
    return false
  end
  end
  if LootListExSingle.LootListType ~= 2 and not LootListExSingle.IsOpened() then
    return 
  end
  if LootListExSingle.LootListType == 2 then
    LootListExSingle.StratOpenDoodadRequest()
  end
  local l_11_0 = LootListExSingle.RequestDoodadList[#LootListExSingle.RequestDoodadList]
  local l_11_1 = false
  if l_11_0 and LootListExSingle.doonetimeList[l_11_0] and LootListExSingle.doonetimeList[l_11_0].done then
    l_11_1 = true
  end
  if l_11_0 and LootListExSingle.CanOpen(l_11_0) and not l_11_1 then
    LootListExSingle.OpenDoodad(l_11_0)
  end
  for l_11_5,l_11_6 in pairs(LootListExSingle.doonetimeList) do
    if GetTime() - l_11_6.time > 1000 then
      LootListExSingle.doonetimeList[l_11_5] = nil
    end
  end
end

LootListExSingle.OnCustomDataLoaded = function()
  if arg0 ~= "Role" then
    return 
  end
  local l_12_0 = Station.Lookup("Normal/LootListExSingle")
  local l_12_1 = l_12_0:Lookup("CheckBox_LootGray")
  l_12_1:Check(LootListExSingle.bLootGray)
end

LootListExSingle.OpenDoodadEventRecall = function(l_13_0)
  local l_13_1 = GetDoodad(l_13_0)
  if l_13_1.nKind ~= DOODAD_KIND.CORPSE then
    return 
  end
  if not LootListExSingle.IsOpened() and LootListExSingle.LootListType == 2 then
    LootListExSingle.SwitchOpenState()
  else
    if not LootListExSingle.IsOpened() then
      return 
    end
  end
  local l_13_2 = Station.Lookup("Normal/LootList")
  if l_13_2 and LootListExSingle.LootListType == 1 then
    l_13_2:Hide()
  elseif not l_13_2 then
    return 
  end
  local l_13_3 = 48
  local l_13_4 = 48
  local l_13_5 = "Interface/BF_LootListExSingle/LootListExSingle.ini"
  local l_13_6 = l_13_2:Lookup("", "Handle_LootList")
  local l_13_7 = l_13_6:GetItemCount()
  for l_13_11 = 0, l_13_7 - 1 do
    local l_13_12 = l_13_6:Lookup(l_13_11)
    local l_13_13 = GetItem(l_13_12.dwID)
    itemtemp = l_13_13
    if l_13_13 then
      local l_13_14 = l_13_13.nQuality
      local l_13_15 = 0
      if l_13_13.nGenre ~= ITEM_GENRE.TASK_ITEM then
        l_13_15 = l_13_14 + 1
      end
      if not LootListExSingle.ItemsTable[l_13_15] then
        LootListExSingle.ItemsTable[l_13_15] = {}
      end
      local l_13_16 = LootListExSingle.handleBox:AppendItemFromIni(l_13_5, "Box_Bag1", "ItemBox_" .. l_13_15 .. "_" .. #LootListExSingle.ItemsTable[l_13_15])
      l_13_16.dwDoodadID = l_13_0
      l_13_16.dwItemID = l_13_13.dwID
      l_13_16.bNeedRoll = l_13_12.bNeedRoll
      l_13_16.bNeedDistribute = l_13_12.bNeedDistribute
      l_13_16.nLootIndex = l_13_12.nLootIndex
      l_13_16.nUiId = l_13_13.nUiId
      l_13_16:SetObject(UI_OBJECT_ITEM_ONLY_ID, l_13_13.nUiId, l_13_13.dwID, l_13_13.nVersion, l_13_13.dwTabType, l_13_13.dwIndex)
      l_13_16:SetObjectIcon(Table_GetItemIconID(l_13_13.nUiId))
      l_13_16:SetSize(l_13_3 - 4, l_13_4 - 4)
      if l_13_16.bNeedRoll or l_13_16.bNeedDistribute then
        l_13_16:SetAlpha(100)
        l_13_16:SetObjectCoolDown(true)
      else
        l_13_16:SetAlpha(200)
        l_13_16:SetObjectCoolDown(false)
      end
      l_13_16:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
      l_13_16:SetOverTextFontScheme(0, 15)
      if l_13_13.bCanStack and l_13_13.nStackNum > 1 then
        l_13_16:SetOverText(0, l_13_13.nStackNum)
      else
        l_13_16:SetOverText(0, "")
      end
      l_13_16:Show()
      local l_13_17 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_13_18 = "Image_White".HandleBG:AppendItemFromIni("Image_Blue", "Image_Purple", "Image_Orange" .. l_13_15 .. "_" .. #LootListExSingle.ItemsTable[l_13_15])
      l_13_18:SetSize(l_13_3, l_13_4)
      l_13_18:SetAlpha(200)
      if l_13_14 > 0 then
        l_13_18:Show()
      else
        l_13_18:Hide()
      end
      table.insert(LootListExSingle.ItemsTable[l_13_15], l_13_16)
    end
  end
  if LootListExSingle.LootListType == 1 then
    CloseLootList(true)
  end
  LootListExSingle.AdjustAllPosAndSize()
  if LootListExSingle.LootListType == 2 then
    LootListExSingle.LootAllItems()
  end
end

LootListExSingle.AdjustAllPosAndSize = function()
  if not LootListExSingle.IsOpened() then
    return 
  end
  local l_14_0 = Station.Lookup("Normal/LootListExSingle")
  local l_14_1 = LootListExSingle.handleBox
  local l_14_2 = LootListExSingle.HandleBG
  local l_14_3 = 48
  local l_14_4 = 48
  local l_14_5 = 0
  local l_14_6 = 0
  for l_14_10 = 0, 6 do
    if LootListExSingle.ItemsTable[l_14_10] and #LootListExSingle.ItemsTable[l_14_10] > 0 then
      l_14_6 = l_14_6 + 1
    end
    if l_14_5 < #LootListExSingle.ItemsTable[l_14_10] then
      l_14_5 = #LootListExSingle.ItemsTable[l_14_10]
    end
  end
  local l_14_11 = 340
  if 64 + (l_14_3 + 4) * l_14_5 < l_14_11 then
    local l_14_12 = l_14_11
  end
  local l_14_13 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if 137 + 32 + (l_14_4 + 4) * (l_14_6) < 137 then
    local l_14_14 = nil
  end
  local l_14_15 = nil
  local l_14_16 = 137
  LootListExSingle.HandleTotal:Lookup("Image_Bg1C"):SetSize(l_14_13 - l_14_11, 52)
  local l_14_17 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg1R"):SetRelPos(l_14_17 + 170 - 1, 0)
  local l_14_18 = nil
  local l_14_19 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg2L"):SetSize(8, l_14_16 - l_14_15)
  local l_14_20 = nil
  local l_14_21 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg2C"):SetSize(l_14_13 - 16, l_14_20)
  local l_14_22 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg2R"):SetRelPos(8 + l_14_22, 52)
  LootListExSingle.HandleTotal:Lookup("Image_Bg2R"):SetSize(8, l_14_20)
  local l_14_23 = nil
  local l_14_24 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg3L"):SetRelPos(0, l_14_20 + 52)
  local l_14_25 = nil
  local l_14_26 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg3C"):SetRelPos(124, l_14_25)
  LootListExSingle.HandleTotal:Lookup("Image_Bg3C"):SetSize(l_14_13 - 124 - 8, 85)
  local l_14_27 = nil
  LootListExSingle.HandleTotal:Lookup("Image_Bg3R"):SetRelPos(l_14_27 + 124, l_14_25)
  local l_14_28 = nil
  LootListExSingle.frameSelf:Lookup("Btn_Close"):SetRelPos(l_14_13 - 40, 10)
  local l_14_29 = nil
  LootListExSingle.frameSelf:Lookup("Btn_LootAll"):SetRelPos(l_14_13 - 190, l_14_16 - 35)
  LootListExSingle.frameSelf:Lookup("Btn_LootAll"):Lookup("", "Text_LootAll"):SetText("ʰȡ����")
  local l_14_30 = nil
  LootListExSingle.frameSelf:Lookup("Btn_Cancel"):SetRelPos(l_14_13 - 100, l_14_16 - 35)
  local l_14_31 = nil
  LootListExSingle.frameSelf:Lookup("CheckBox_LootGray"):SetRelPos(10, l_14_16 - 37)
  LootListExSingle.frameSelf:Lookup("CheckBox_LootGray"):Lookup("", "Text_LootGray"):SetText("ʰȡ��ɫ����")
  LootListExSingle.frameSelf:Lookup("CheckBox_LootGray"):Show()
  LootListExSingle.frameSelf:SetSize(l_14_13, l_14_16)
  LootListExSingle.HandleTotal:SetSize(l_14_13, l_14_16)
  LootListExSingle.handleBox:SetSize(l_14_13, l_14_16)
  LootListExSingle.HandleBG:SetSize(l_14_13, l_14_16)
  local l_14_32 = nil
  for l_14_36 = 0, 6 do
    local l_14_33, l_14_34 = , 0
     -- DECOMPILER ERROR: Confused about usage of registers!

    if LootListExSingle.ItemsTable[R32_PC230] and #LootListExSingle.ItemsTable[R32_PC230] > 0 then
      for l_14_41 = 1, #LootListExSingle.ItemsTable[R32_PC230] do
        local l_14_39 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_14_39[R37_PC246] then
          l_14_39[R37_PC246]:SetRelPos((R37_PC246 - 1) * (l_14_3 + 4) + 34, l_14_34 * (l_14_4 + 8) + 70)
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        local l_14_44 = nil
        if LootListExSingle.HandleBG:Lookup(l_14_39[R37_PC246]:GetName():gsub("ItemBox_", "ImageBox_")) then
          LootListExSingle.HandleBG:Lookup(l_14_39[R37_PC246]:GetName():gsub("ItemBox_", "ImageBox_")):SetRelPos((l_14_43 - 1) * (l_14_3 + 4) + 32, l_14_34 * (l_14_4 + 8) + 68)
        end
      end
      l_14_34 = l_14_34 + 1
    end
  end
  LootListExSingle.HandleTotal:Lookup("Text_Title"):SetText("������ " .. LootListExSingle.handleBox:GetItemCount() .. " �����ߣ���ȷ�������еģ���")
  LootListExSingle.HandleTotal:Lookup("Text_Author"):SetRelPos(l_14_13 - 265, l_14_16 - 65)
  LootListExSingle.handleBox:FormatAllItemPos()
  LootListExSingle.HandleBG:FormatAllItemPos()
  LootListExSingle.HandleTotal:FormatAllItemPos()
end

LootListExSingle.CheckEmptyToClose = function()
  local l_15_0 = true
  for l_15_4 = 0, LootListExSingle.handleBox:GetItemCount() - 1 do
    local l_15_5 = LootListExSingle.handleBox:Lookup(l_15_4)
    if l_15_5 and l_15_5:GetAlpha() > 150 then
      l_15_0 = false
    end
  end
  if l_15_0 then
    LootListExSingle.ClosePanel()
  end
end

LootListExSingle.LootAllItems = function()
  if not LootListExSingle.IsOpened() then
    return 
  end
  for l_16_3 = 0, LootListExSingle.handleBox:GetItemCount() - 1 do
    local l_16_4 = LootListExSingle.handleBox:Lookup(l_16_3)
    if l_16_4 then
      local l_16_5 = l_16_4.dwDoodadID
      local l_16_6 = l_16_4.dwItemID
      local l_16_7 = GetItem(l_16_6)
      local l_16_8 = GetDoodad(l_16_5)
      local l_16_9 = l_16_7.nQuality
      local l_16_10 = nil
      l_16_10 = true
      if LootListExSingle.onlyItem then
        l_16_10 = false
        for l_16_14,l_16_15 in pairs(LootListExSingle.NotLootItemTab) do
          if l_16_15 == GetItemNameByItem(l_16_7) and l_16_8 and l_16_7 and l_16_8.CanLoot(GetClientPlayer().dwID) then
            LootItem(l_16_5, l_16_7.dwID)
          end
        end
        do break end
      end
      l_16_10 = true
      for l_16_19,l_16_20 in pairs(LootListExSingle.NotLootItemTab) do
        if l_16_20 == GetItemNameByItem(l_16_7) then
          l_16_10 = false
        end
      end
      if l_16_7.nPrice < LootListExSingle.LootMoneylower then
        l_16_10 = false
      end
      if l_16_9 <= LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 and l_16_7.nGenre ~= ITEM_GENRE.TASK_ITEM then
        l_16_10 = false
      end
      if l_16_10 and l_16_8 and l_16_7 and l_16_8.CanLoot(GetClientPlayer().dwID) then
        LootItem(l_16_5, l_16_7.dwID)
      end
      do return end
      LootListExSingle.NotLootDoodadTab[l_16_5] = l_16_5
      l_16_4:SetAlpha(32)
    end
  end
  LootListExSingle.ClosePanel()
  CloseLootList(true)
  LootListExSingle.RemoveSynDoodadList(dwDoodadID)
end

LootListExSingle.AppendSynDoodadList = function(l_17_0)
  local l_17_1 = GetDoodad(l_17_0)
  local l_17_2 = GetClientPlayer()
  if l_17_1 and l_17_1.nKind == DOODAD_KIND.CORPSE and l_17_1.CanLoot(l_17_2.dwID) then
    LootListExSingle.SynDoodadList[l_17_0] = l_17_0
  else
    LootListExSingle.RemoveSynDoodadList(l_17_0)
  end
end

LootListExSingle.RemoveSynDoodadList = function(l_18_0)
  if LootListExSingle.SynDoodadList[l_18_0] then
    LootListExSingle.SynDoodadList[l_18_0] = nil
  end
  if LootListExSingle.NotLootDoodadTab[l_18_0] then
    LootListExSingle.NotLootDoodadTab[l_18_0] = nil
  end
end

LootListExSingle.GetSynDoodadListCount = function()
  local l_19_0 = 0
  for l_19_4,l_19_5 in pairs(LootListExSingle.SynDoodadList) do
    l_19_0 = l_19_0 + 1
  end
  return l_19_0
end

LootListExSingle.StratOpenDoodadRequest = function()
  LootListExSingle.ClearPanel()
  if not LootListExSingle.SynDoodadList then
    return false
  end
  for l_20_3,l_20_4 in pairs(LootListExSingle.SynDoodadList) do
    local l_20_5 = false
    if LootListExSingle.NotLootDoodadTab[l_20_3] then
      l_20_5 = true
    end
    if not l_20_5 then
      local l_20_6 = GetDoodad(l_20_3)
      local l_20_7 = GetClientPlayer()
    end
    if l_20_6.CanLoot(l_20_7.dwID) and LootListExSingle.CanOpen(l_20_3) then
      table.insert(LootListExSingle.RequestDoodadList, l_20_3)
    end
  end
  if #LootListExSingle.RequestDoodadList <= 0 then
    return false
  end
  return true
end

LootListExSingle.GetRequestDoodadListCount = function()
  return #LootListExSingle.RequestDoodadList
end

LootListExSingle.OpenDoodad = function(l_22_0)
  local l_22_1 = GetClientPlayer()
  if LootListExSingle.CanOpen(l_22_0) then
    LootListExSingle.removedoodaListbyID(l_22_0)
    l_22_1.Open(l_22_0)
    local l_22_2 = LootListExSingle.doonetimeList
    local l_22_3 = {}
    l_22_3.done = true
    l_22_3.time = GetTime()
    l_22_2[l_22_0] = l_22_3
    l_22_2 = true
    return l_22_2
  end
  return false
end

LootListExSingle.removedoodaListbyID = function(l_23_0)
  for l_23_4,l_23_5 in pairs(LootListExSingle.RequestDoodadList) do
    if l_23_5 == l_23_0 then
      table.remove(LootListExSingle.RequestDoodadList, l_23_4)
    end
  end
end

LootListExSingle.CanOpen = function(l_24_0)
  local l_24_1 = GetDoodad(l_24_0)
  local l_24_2 = GetClientPlayer()
  if not l_24_2 or not l_24_1 then
    return false
  end
  if math.floor(l_24_2.nX - l_24_1.nX ^ 2 + l_24_2.nY - l_24_1.nY ^ 2 ^ 0.5) > 249 then
    return false
  end
  return true
end

LootListExSingle.AutoLootMoney = function()
  for l_25_3,l_25_4 in pairs(LootListExSingle.SynDoodadList) do
    if LootListExSingle.CanOpen(l_25_3) then
      LootMoney(l_25_3)
    end
  end
end

LootListExSingle.Message = function(l_26_0, l_26_1)
  OutputMessage("MSG_SYS", "[LootListExSingle] " .. tostring(l_26_1) .. "\n")
end

LootListExSingle.MessageBox = function(l_27_0, l_27_1, l_27_2, l_27_3, l_27_4, l_27_5)
  local l_27_6 = {}
  l_27_6.szMessage = l_27_1
  l_27_6.szName = "LootListExSingleMessageBox"
  l_27_6.fnAutoClose = false
  local l_27_7 = {}
  local l_27_8 = nil
  if not l_27_4 then
    l_27_8 = g_tStrings
    l_27_8 = l_27_8.STR_HOTKEY_SURE
  end
  l_27_7.szOption = l_27_8
  if not l_27_2 then
    l_27_8 = function()
  end
  end
  l_27_7.fnAction = l_27_8
  l_27_8 = g_sound
  l_27_8 = l_27_8.Trade
  l_27_7.szSound = l_27_8
  local l_27_9 = nil
  if not l_27_5 then
    l_27_9 = g_tStrings
    l_27_9 = l_27_9.STR_HOTKEY_CANCEL
  end
  if not l_27_3 then
    l_27_9 = function()
  end
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_27_7 = MessageBox
   -- DECOMPILER ERROR: Overwrote pending register.

  l_27_7(l_27_8)
  l_27_8 = {szOption = l_27_9, fnAction = l_27_9, szSound = nil}
end

LootListExSingle.ClearPanel = function()
  if not LootListExSingle.frameSelf then
    return 
  end
  if LootListExSingle.handleBox then
    LootListExSingle.handleBox:Clear()
  end
  if LootListExSingle.HandleBG then
    LootListExSingle.HandleBG:Clear()
  end
  LootListExSingle.RequestDoodadList = {}
  LootListExSingle.ItemsTable = {}
end

LootListExSingle.OpenPanel = function(l_29_0)
  if not Station.Lookup("Normal/LootListExSingle") then
    local l_29_1, l_29_2, l_29_3, l_29_4, l_29_5, l_29_6, l_29_7, l_29_8, l_29_9, l_29_10, l_29_11, l_29_12, l_29_13, l_29_14, l_29_15, l_29_16, l_29_17, l_29_18, l_29_19, l_29_20, l_29_21, l_29_22, l_29_23, l_29_24, l_29_25, l_29_26 = Wnd.OpenWindow("Interface/BF_LootListExSingle/LootListExSingle.ini", "LootListExSingle")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  LootListExSingle.frameSelf = l_29_1
   -- DECOMPILER ERROR: Confused about usage of registers!

  LootListExSingle.HandleTotal = l_29_1:Lookup("", "")
   -- DECOMPILER ERROR: Confused about usage of registers!

  LootListExSingle.handleBox = l_29_1:Lookup("", "Handle_Box")
   -- DECOMPILER ERROR: Confused about usage of registers!

  LootListExSingle.HandleBG = l_29_1:Lookup("", "Handle_BG")
  LootListExSingle.HandleTotal:Lookup("Text_Title"):SetText("������ ?? �����߿���ʰȡ��")
  LootListExSingle.HandleTotal:Lookup("Text_Author"):SetText("")
  LootListExSingle.HandleTotal:Lookup("Text_Author"):SetFontColor(0, 255, 32)
  LootListExSingle.HandleTotal:Lookup("Text_Author"):SetAlpha(64)
  LootListExSingle.frameSelf:Lookup("CheckBox_LootGray"):Hide()
  LootListExSingle.frameSelf:Lookup("CheckBox_BindNotice"):Hide()
  LootListExSingle.frameSelf:Lookup("CheckBox_LootGreen"):Hide()
  LootListExSingle.frameSelf:Lookup("CheckBox_AutoLoot"):Hide()
  if GetClientPlayer() and GetClientPlayer().nMoveState ~= MOVE_STATE.ON_STAND then
    OutputMessage("MSG_ANNOUNCE_RED", "ֻ����վ��״̬��ʰȡ���")
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_29_1:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_29_1:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_29_1:BringToTop()
  LootListExSingle:AutoLootMoney()
  if not LootListExSingle.StratOpenDoodadRequest() then
    if not l_29_0 then
      OutputMessage("MSG_ANNOUNCE_RED", "����û�п���ʰȡ��ʬ��")
    end
    LootListExSingle.ClosePanel(true)
  end
  if not l_29_0 then
    PlaySound(SOUND.UI_SOUND, g_sound.OpenFrame)
  end
end

LootListExSingle.IsOpened = function()
  local l_30_0 = Station.Lookup("Normal/LootListExSingle")
  if l_30_0 and l_30_0:IsVisible() then
    return true
  end
  return false
end

LootListExSingle.ClosePanel = function(l_31_0)
  if not LootListExSingle.IsOpened() then
    return 
  end
  local l_31_1 = Station.Lookup("Normal/LootListExSingle")
  l_31_1:Hide()
  if not l_31_0 then
    PlaySound(SOUND.UI_SOUND, g_sound.CloseFrame)
  end
end

LootListExSingle.SwitchOpenState = function()
  if LootListExSingle.IsOpened() then
    LootListExSingle.ClosePanel()
  else
    LootListExSingle.OpenPanel()
  end
end

LootListExSingle.OpenPanel(true)
Hotkey.AddBinding("LootListExSingle_OpenPanel", "�򿪹ر����", "ʰȡ����", LootListExSingle.SwitchOpenState, nil)
Hotkey.AddBinding("LootListExSingle_LootAll", "ʰȡ����(���˺�)", "", LootListExSingle.LootAllItems, nil)
LootListExSingle.TogglePanel = TogglePanel
TogglePanel = function(l_33_0)
  if LootListExSingle.IsOpened() then
    LootListExSingle.ClosePanel()
    return 
  end
  LootListExSingle.TogglePanel(l_33_0)
end

LootListExSingle.BigFoot_ec37d18bf73542c59e2c0417b341046a = InsertPlayerMenu
LootListExSingle.InsertPlayerMenu = function(l_34_0)
  -- upvalues: l_0_0
  LootListExSingle.BigFoot_ec37d18bf73542c59e2c0417b341046a(l_34_0)
  if LootListExSingle.EnableChangeLootListType then
    local l_34_1 = {}
    l_34_1.szOption = "ʰȡ����"
    l_34_1.fnAutoClose = function()
      return true
    end
    local l_34_2 = table.insert
    local l_34_3 = l_34_1
    local l_34_4 = {}
    l_34_4.szOption = "�ֶ�ʰȡģʽ"
    l_34_4.r = 255
    l_34_4.g = 255
    l_34_4.b = 255
    l_34_4.bMCheck = true
    l_34_4.bChecked = LootListExSingle.LootListType == 1
    l_34_4.fnAutoClose = function()
      return true
    end
    l_34_4.fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.LootListType = 1
      l_0_0("�Ѿ������ֶ�ʰȡģʽ,�����ð�����ʰȡ��Ʒ.")
    end
    l_34_2(l_34_3, l_34_4)
    l_34_2 = table
    l_34_2 = l_34_2.insert
    l_34_3 = l_34_1
    l_34_2(l_34_3, l_34_4)
    l_34_4 = {szOption = "�Զ�ʰȡģʽ", r = 255, g = 255, b = 255, bMCheck = true, bChecked = LootListExSingle.LootListType == 2, fnAutoClose = function()
      return true
    end, fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.LootListType = 2
      l_0_0("�Ѿ������Զ�ʰȡģʽ,��Ʒ�����Զ�ʰȡ,�����κβ���.")
    end}
    l_34_2 = table
    l_34_2 = l_34_2.insert
    l_34_3 = l_34_1
    l_34_2(l_34_3, l_34_4)
    l_34_4 = {bDevide = true}
    l_34_3 = function()
      return true
    end
    l_34_3 = table
    l_34_3 = l_34_3.insert
    l_34_4, l_34_2 = l_34_2, {szOption = "��ƷƷ�ʹ�������", fnAutoClose = l_34_3}
    local l_34_9 = {}
    l_34_9.szOption = "�ر�"
    l_34_9.r = 255
    l_34_9.g = 255
    l_34_9.b = 255
    l_34_9.bMCheck = true
    l_34_9.bChecked = LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 == -1
    l_34_9.fnAutoClose = function()
      return true
    end
    l_34_9.fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 = -1
      l_0_0("�ر���ƷƷ�ʹ���")
    end
    l_34_3(l_34_4, l_34_9)
    l_34_3 = table
    l_34_3 = l_34_3.insert
    l_34_4 = l_34_2
    l_34_3(l_34_4, l_34_9)
    l_34_9 = {szOption = "��", r = 128, g = 128, b = 128, bMCheck = true, bChecked = LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 == 0, fnAutoClose = function()
      return true
    end, fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 = 0
      l_0_0("�Ѿ�������ƷƷ�ʹ���Ϊ��ɫ")
    end}
    l_34_3 = table
    l_34_3 = l_34_3.insert
    l_34_4 = l_34_2
    l_34_3(l_34_4, l_34_9)
    l_34_9 = {szOption = "��", r = 255, g = 255, b = 255, bMCheck = true, bChecked = LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 == 1, fnAutoClose = function()
      return true
    end, fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 = 1
      l_0_0("�Ѿ�������ƷƷ�ʹ���Ϊ��ɫ")
    end}
    l_34_3 = table
    l_34_3 = l_34_3.insert
    l_34_4 = l_34_2
    l_34_3(l_34_4, l_34_9)
    l_34_9 = {szOption = "��", r = 0, g = 255, b = 0, bMCheck = true, bChecked = LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 == 2, fnAutoClose = function()
      return true
    end, fnAction = function()
      -- upvalues: l_0_0
      LootListExSingle.BigFoot_87ea82208b31325390668929bae39c49 = 2
      l_0_0("�Ѿ�������ƷƷ�ʹ���Ϊ��ɫ")
    end}
    l_34_3 = table
    l_34_3 = l_34_3.insert
    l_34_4 = l_34_2
    l_34_3(l_34_4, l_34_9)
    l_34_9 = {bDevide = true}
    l_34_4 = function()
      return true
    end
    l_34_4 = pairs
    l_34_9 = LootListExSingle
    l_34_9 = l_34_9.NotLootItemTab
    l_34_4 = l_34_4(l_34_9)
    for i_1,i_2 in l_34_4 do
      local l_34_21 = table.insert
      local l_34_22 = l_34_3
      local l_34_23 = {}
      l_34_23.szOption = l_34_20
      l_34_23.r = 255
      l_34_23.g = 255
      l_34_23.b = 0
      l_34_23.bChecked = false
      l_34_23.fnAutoClose = function()
        return true
      end
      l_34_23.fnAction = function()
        -- upvalues: l_34_8
        LootListExSingle.DelNotLootItem(l_34_8)
      end
      l_34_21(l_34_22, l_34_23)
    end
    local l_34_24, l_34_32 = nil
    local l_34_25, l_34_33 = nil
    local l_34_26, l_34_34 = nil
    table.insert(l_34_3, l_34_24)
    l_34_24 = {bDevide = true}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    table.insert(l_34_3, l_34_24)
    l_34_24 = {szOption = l_34_32, r = 255, g = 255, b = 255, bChecked = false, fnAutoClose = l_34_32, fnAction = l_34_32}
    table.insert(l_34_3, l_34_24)
    l_34_24 = {bDevide = true}
    table.insert(l_34_3, l_34_24)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    table.insert(l_34_24, l_34_32)
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

    do
      local l_34_27, l_34_35 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      table.insert(l_34_24, l_34_32)
      l_34_32 = {szOption = "������Ʒ", r = 255, g = 255, b = 255, bChecked = false, fnAutoClose = l_34_25, fnAction = l_34_25}
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      table.insert(l_34_24, l_34_32)
      l_34_32 = {szOption = "���˵�ǰ������Ʒ", r = 255, g = 255, b = 255, bMCheck = true, bChecked = l_34_25, fnAutoClose = l_34_25, fnAction = l_34_25}
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      table.insert(l_34_24, l_34_32)
      l_34_32 = {szOption = "ֻʰȡ��ǰ������Ʒ", r = 255, g = 255, b = 255, bMCheck = true, bChecked = l_34_25, fnAutoClose = l_34_25, fnAction = l_34_25}
       -- DECOMPILER ERROR: Overwrote pending register.

      table.insert(l_34_24, l_34_32)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

    end
    table.insert(l_34_24, l_34_32)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

InsertPlayerMenu = LootListExSingle.InsertPlayerMenu
LootListExSingle.SetLootMoneylower = function(l_35_0)
  -- upvalues: l_0_0
  LootListExSingle.LootMoneylower = tonumber(l_35_0)
  if tonumber(l_35_0) == 0 then
    l_0_0("�����ü۸���� [" .. l_35_0 .. "] ͭ�ҵĻ�ɫ��Ʒ��ʰȡ")
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 11 
end

LootListExSingle.AddNotLootItem = function(l_36_0)
  -- upvalues: l_0_0
  for l_36_4,l_36_5 in pairs(LootListExSingle.NotLootItemTab) do
    if l_36_5 == l_36_0 then
      l_0_0("��Ʒ [" .. l_36_0 .. "] ���ڹ����б�����Ҫ�������ӡ�")
      return 
    end
  end
  table.insert(LootListExSingle.NotLootItemTab, l_36_0)
  l_0_0("��������Ʒ [" .. l_36_0 .. "]��")
end

LootListExSingle.DelNotLootItem = function(l_37_0)
  -- upvalues: l_0_0
  local l_37_1 = {}
  l_37_1.szName = "ɾ��������Ʒ"
  l_37_1.szMessage = "��ȷ��Ҫɾ�������Ʒ��"
  local l_37_2 = {}
  l_37_2.szOption = "ȷ��"
  l_37_2.fnAction = function()
    -- upvalues: l_37_0 , l_0_0
    for l_38_3,l_38_4 in pairs(LootListExSingle.NotLootItemTab) do
      if l_38_4 == l_37_0 then
        table.remove(LootListExSingle.NotLootItemTab, l_38_3)
        l_0_0("��ɾ����Ʒ[" .. l_37_0 .. "]��")
      end
    end
  end
  local l_37_3 = {}
  l_37_3.szOption = "ȡ��"
  l_37_3.fnAction = function()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  Msg = l_37_1
  l_37_1 = MessageBox
  l_37_2 = Msg
  l_37_1(l_37_2)
end

if not BF_DoodadTopHeadDisplayEx then
  BF_DoodadTopHeadDisplayEx = {}
end
BF_DoodadTopHeadDisplayEx.nSteperCount = -1
BF_DoodadTopHeadDisplayEx.szLoginText = " "
BF_DoodadTopHeadDisplayEx.szAuthor = " "
BF_DoodadTopHeadDisplayEx.frameSelf = nil
BF_DoodadTopHeadDisplayEx.windowCheckBoxes = nil
BF_DoodadTopHeadDisplayEx.frameContant = nil
BF_DoodadTopHeadDisplayEx.handleTotal = nil
BF_DoodadTopHeadDisplayEx.SavedCheckState = {}
local l_0_1 = BF_DoodadTopHeadDisplayEx
local l_0_2 = {}
local l_0_3 = {}
l_0_3.bDefault = true
l_0_3.bEnable = true
l_0_3.szName = "��ʯ"
l_0_2.A = l_0_3
l_0_2.B, l_0_3 = l_0_3, {bDefault = true, bEnable = true, szName = "ҩ��"}
l_0_2.C, l_0_3 = l_0_3, {bDefault = true, bEnable = true, szName = "����"}
l_0_2.D, l_0_3 = l_0_3, {bDefault = false, bEnable = true, szName = "����"}
l_0_1.DataList = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_1.SynAnyDoodadList, l_0_2 = l_0_2, {}
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function()
  BF_DoodadTopHeadDisplayEx:Message(BF_DoodadTopHeadDisplayEx.szLoginText .. "(��ݼ�������) ����...")
  BF_DoodadTopHeadDisplayEx.frameSelf = Station.Lookup("Normal/BF_DoodadTopHeadDisplayEx")
  BF_DoodadTopHeadDisplayEx.windowCheckBoxes = BF_DoodadTopHeadDisplayEx.frameSelf:Lookup("Window_Checkboxes")
  BF_DoodadTopHeadDisplayEx.frameContant = Station.Lookup("Lowest/BF_DoodadTopHeadHandle")
  if not BF_DoodadTopHeadDisplayEx.frameContant then
    BF_DoodadTopHeadDisplayEx.frameContant = Wnd.OpenWindow("Interface\\BF_LootListExSingle\\BF_DoodadTopHeadHandle.ini", "BF_DoodadTopHeadHandle")
  end
  BF_DoodadTopHeadDisplayEx.handleTotal = BF_DoodadTopHeadDisplayEx.frameContant:Lookup("", "")
  BF_DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("RENDER_FRAME_UPDATE")
  BF_DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("DOODAD_ENTER_SCENE")
  BF_DoodadTopHeadDisplayEx.frameSelf:RegisterEvent("DOODAD_LEAVE_SCENE")
  BF_DoodadTopHeadDisplayEx:SetTitleAndAuthor(BF_DoodadTopHeadDisplayEx.szLoginText, BF_DoodadTopHeadDisplayEx.szAuthor)
  BF_DoodadTopHeadDisplayEx.frameSelf:Lookup("", "Text_Edit_Filtrate"):SetText("���ְ���")
  for l_38_3,l_38_4 in pairs(BF_DoodadTopHeadDisplayEx.DataList) do
    local l_38_5 = BF_DoodadTopHeadDisplayEx:GetCheckBox(l_38_3)
    BF_DoodadTopHeadDisplayEx:SetCheckBoxText(l_38_3, l_38_4.szName)
    l_38_5:Enable(l_38_4.bEnable)
  end
end

l_0_1.OnFrameCreate = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function()
  local l_39_0 = this:GetName()
  if l_39_0 == "Button_MainSwitch" then
    BF_DoodadTopHeadDisplayEx:ClosePanel()
  end
end

l_0_1.OnLButtonClick = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_40_0)
  local l_40_1 = this:GetName():gsub("CheckBox_", "")
  if BF_DoodadTopHeadDisplayEx.DataList[l_40_1] and BF_DoodadTopHeadDisplayEx.DataList[l_40_1].funcCheck then
    BF_DoodadTopHeadDisplayEx.DataList[l_40_1].funcCheck()
  end
  if l_40_1 == "A" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("A", true)
  elseif l_40_1 == "B" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("B", true)
  elseif l_40_1 == "C" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("C", true)
  elseif l_40_1 == "D" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("D", true)
  end
end

l_0_1.OnCheckBoxCheck = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_41_0)
  local l_41_1 = this:GetName():gsub("CheckBox_", "")
  if BF_DoodadTopHeadDisplayEx.DataList[l_41_1] and BF_DoodadTopHeadDisplayEx.DataList[l_41_1].funcUncheck then
    BF_DoodadTopHeadDisplayEx.DataList[l_41_1].funcUncheck()
  end
  if l_41_1 == "A" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("A", false)
  elseif l_41_1 == "B" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("B", false)
  elseif l_41_1 == "C" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("C", false)
  elseif l_41_1 == "D" then
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState("D", false)
  end
end

l_0_1.OnCheckBoxUncheck = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function()
  if GetKeyName(Station.GetMessageKey()) == "Enter" then
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 8 
end

l_0_1.OnEditSpecialKeyDown = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_43_0)
  if l_43_0 == "RENDER_FRAME_UPDATE" then
    BF_DoodadTopHeadDisplayEx:RefreshDoodadTopHeadDisplay()
  elseif l_43_0 == "DOODAD_ENTER_SCENE" then
    BF_DoodadTopHeadDisplayEx:AppendAnyDoodadToList(arg0)
  elseif l_43_0 == "DOODAD_LEAVE_SCENE" then
    BF_DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(arg0)
  end
end

l_0_1.OnEvent = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function()
  BF_DoodadTopHeadDisplayEx:Steper()
  BF_DoodadTopHeadDisplayEx:UpdateAllDoodadNameLable()
end

l_0_1.OnFrameBreathe = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_45_0)
  for l_45_4,l_45_5 in pairs(BF_DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    BF_DoodadTopHeadDisplayEx:UpdateAnyDoodadNameLable(l_45_4)
  end
end

l_0_1.UpdateAllDoodadNameLable = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_46_0)
  local l_46_1 = 0
  for l_46_5,l_46_6 in pairs(BF_DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    l_46_1 = l_46_1 + 1
  end
  return l_46_1
end

l_0_1.GetAnyDoodadListCount = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_47_0, l_47_1)
  if not l_47_1 then
    return 
  end
  local l_47_2 = GetDoodad(l_47_1)
  if BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_47_1] and not l_47_2 then
    BF_DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(l_47_1)
  end
  return 
  if not l_47_2 or l_47_2.nKind == DOODAD_KIND.CORPSE then
    return 
  end
  local l_47_3 = BF_DoodadTopHeadDisplayEx.SynAnyDoodadList
  local l_47_4 = {}
  l_47_4.dwID = l_47_1
  l_47_4.szName = l_47_2.szName
  l_47_4.szTopHead = l_47_2.szName
  l_47_4.nDistance = 0
  l_47_4.nCameraDistance = 0
  l_47_3[l_47_1] = l_47_4
  l_47_3 = BF_DoodadTopHeadDisplayEx
  l_47_3 = l_47_3.handleTotal
  l_47_4 = "Name_DOODAD_"
  l_47_4 = l_47_4 .. l_47_1
  local l_47_5 = l_47_3:Lookup(l_47_4)
  if not l_47_5 then
    l_47_3:AppendItemFromIni("Interface/BF_LootListExSingle/BF_DoodadTopHeadHandle.ini", "Handle_Label", l_47_4)
    l_47_5 = l_47_3:Lookup(l_47_3:GetItemCount() - 1)
    l_47_5.dwDoodadID = l_47_1
    l_47_5.textLable = l_47_5:Lookup("Text_Content")
    l_47_5.textLable:SetFontScheme(40)
    BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_47_1].handleLabel_Name = l_47_5
  end
  BF_DoodadTopHeadDisplayEx:UpdateAnyDoodadNameLable(l_47_1)
end

l_0_1.AppendAnyDoodadToList = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_48_0, l_48_1)
  if not l_48_1 or not BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_48_1] then
    return 
  end
  local l_48_2 = BF_DoodadTopHeadDisplayEx.handleTotal
  local l_48_3 = l_48_2:Lookup("Name_DOODAD_" .. l_48_1)
  if l_48_3 then
    l_48_2:RemoveItem(l_48_3:GetIndex())
  end
  BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_48_1] = nil
end

l_0_1.RemoveAnyDoodadFromList = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_49_0, l_49_1)
  local l_49_2 = BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_49_1]
  local l_49_3 = GetDoodad(l_49_1)
  if not l_49_3 and l_49_2 then
    BF_DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(l_49_1)
  end
  return 
  if not l_49_2 then
    BF_DoodadTopHeadDisplayEx:AppendAnyDoodadToList(l_49_1)
    return 
  end
  if not l_49_2.handleLabel_Name then
    return 
  end
  l_49_2.szName = l_49_3.szName
  local l_49_4 = GetDoodadTemplate(l_49_3.dwTemplateID)
  l_49_2.szTopHead = ""
  if BF_DoodadTopHeadDisplayEx:GetCheckBoxState("A") and l_49_4.dwCraftID == 1 then
    l_49_2.szTopHead = l_49_2.szName
  else
    if BF_DoodadTopHeadDisplayEx:GetCheckBoxState("B") and l_49_4.dwCraftID == 2 then
      l_49_2.szTopHead = l_49_2.szName
    end
  else
    if BF_DoodadTopHeadDisplayEx:GetCheckBoxState("C") and l_49_4.dwCraftID == 12 then
      l_49_2.szTopHead = l_49_2.szName
    end
  else
    if BF_DoodadTopHeadDisplayEx:GetCheckBoxState("D") and l_49_4.dwCraftID ~= 1 and l_49_4.dwCraftID ~= 2 and l_49_4.dwCraftID ~= 12 then
      l_49_2.szTopHead = l_49_2.szName
    end
  end
  if not LootListExSingle.EnableShowDoodad then
    l_49_2.szTopHead = ""
  end
  local l_49_5 = BF_DoodadTopHeadDisplayEx:GetEditValue()
  if l_49_2.szTopHead ~= "" and l_49_5 and l_49_5 ~= "" and l_49_5 ~= "���á�/���ָ�������" then
    l_49_2.szTopHead = ""
    l_49_5 = l_49_5 .. "/"
    do
      local l_49_6 = 1
      for l_49_10 = 1, #l_49_5 do
        if l_49_5:sub(l_49_10, l_49_10) == "/" and l_49_6 <= l_49_10 then
          local l_49_11 = l_49_5:sub(l_49_6, l_49_10 - 1):gsub("%s", "")
          if l_49_11 and l_49_11 ~= "" and l_49_2.szName:match(l_49_11) then
            l_49_2.szTopHead = l_49_2.szName
          end
          do break end
        end
        l_49_6 = l_49_10 + 1
      end
    end
  end
  l_49_2.handleLabel_Name.textLable:SetText(l_49_2.szTopHead)
end

l_0_1.UpdateAnyDoodadNameLable = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_50_0)
  local l_50_1 = GetClientPlayer()
  if not l_50_1 then
    return 
  end
  local l_50_2 = l_50_1.dwID
  for l_50_6,l_50_7 in pairs(BF_DoodadTopHeadDisplayEx.SynAnyDoodadList) do
    local l_50_8 = GetDoodad(l_50_6)
    if not l_50_8 then
      BF_DoodadTopHeadDisplayEx:RemoveAnyDoodadFromList(l_50_6)
      return 
    end
    local l_50_9 = 196
    local l_50_10 = 64
    local l_50_11 = 255
    local l_50_12 = math.floor(l_50_1.nX - l_50_8.nX ^ 2 + l_50_1.nY - l_50_8.nY ^ 2 ^ 0.5)
    local l_50_13 = l_50_12 * -0.001
    local l_50_14 = 0
    local l_50_15, l_50_16, l_50_17 = Scene_GameWorldPositionToScenePosition(l_50_8.nX, l_50_8.nY, l_50_8.nZ, 0)
    local l_50_18 = 0
    local l_50_19 = 0
    local l_50_20 = false
    if l_50_15 and l_50_16 and l_50_17 then
      l_50_18 = Scene_ScenePointToScreenPoint(l_50_15, l_50_16 - l_50_14, l_50_17)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_50_20 then
      l_50_18 = Station.AdjustToOriginalPos(l_50_18, l_50_19)
    elseif l_50_7.handleLabel_Name then
      l_50_7.handleLabel_Name:SetAbsPos(-4096, -4096)
    end
    if l_50_20 then
      if BF_DoodadTopHeadDisplayEx.nSteperCount % 4 == 0 or BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_50_6].nCameraDistance == 0 then
        BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_50_6].nCameraDistance = math.floor(l_50_1.nX - l_50_8.nX ^ 2 + l_50_1.nY - l_50_8.nY ^ 2 + l_50_1.nZ / 8 - l_50_8.nZ / 8 ^ 2 ^ 0.5)
      end
      local l_50_21 = BF_DoodadTopHeadDisplayEx.SynAnyDoodadList[l_50_6].nCameraDistance
      local l_50_22 = l_50_7.handleLabel_Name
      local l_50_23 = nil
      if l_50_22 then
        l_50_23 = l_50_22.textLable
        local l_50_24, l_50_25 = l_50_23:GetSize()
        local l_50_26 = math.ceil(l_50_18 - l_50_24 / 2) - 8
        local l_50_27 = math.floor(l_50_19 - l_50_25 / 2) - 80
        l_50_22:SetAbsPos(l_50_26, l_50_27)
        l_50_23:Show()
        l_50_22:SetUserData(-l_50_21)
      end
      local l_50_28 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_50_23 and 16.nSteperCount % 2 == 0 then
        if l_50_21 < 800 then
          l_50_23:SetFontScheme(40)
          l_50_23:SetFontScale(1)
        end
      elseif l_50_21 < 1600 then
        l_50_23:SetFontScheme(l_50_28[2])
        l_50_23:SetFontScale(1)
      elseif l_50_21 < 2400 then
        l_50_23:SetFontScheme(l_50_28[1])
        l_50_23:SetFontScale(1)
      else
        local l_50_29 = l_50_21 - 2400
        if 1 - l_50_29 / 4000 <= 0.7 then
          local l_50_30, l_50_31, l_50_32 = 0.7
        end
        l_50_23:SetFontScheme(l_50_28[1])
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_50_23:SetFontScale(l_50_30)
      end
      local l_50_33 = true
      if l_50_33 and (l_50_21 - 900 > 0 or 210 - math.floor(0 / 50) <= 0) then
        local l_50_34, l_50_35, l_50_36, l_50_37 = 0
      end
    end
    if l_50_23 then
      l_50_23:SetAlpha(210)
      l_50_23:SetFontColor(l_50_9, l_50_10, l_50_11)
    end
  end
  if BF_DoodadTopHeadDisplayEx.nSteperCount % 16 == 0 then
    BF_DoodadTopHeadDisplayEx.handleTotal:Sort()
  end
end

l_0_1.RefreshDoodadTopHeadDisplay = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_51_0)
  if arg0 ~= "Role" then
    return 
  end
  for l_51_4,l_51_5 in pairs(BF_DoodadTopHeadDisplayEx.DataList) do
    local l_51_6 = nil
    if BF_DoodadTopHeadDisplayEx.SavedCheckState[l_51_4] == nil then
      l_51_6 = l_51_5.bDefault
    else
      l_51_6 = BF_DoodadTopHeadDisplayEx.SavedCheckState[l_51_4]
    end
    BF_DoodadTopHeadDisplayEx:SetCheckBoxState(l_51_4, l_51_6)
  end
  BF_DoodadTopHeadDisplayEx:SetEditValue("���á�/���ָ�������")
end

l_0_1.OnCustomDataLoaded = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_52_0)
  return BF_DoodadTopHeadDisplayEx.frameSelf
end

l_0_1.GetSelfFrame = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_53_0)
  return BF_DoodadTopHeadDisplayEx.windowCheckBoxes
end

l_0_1.GetCheckboxesWindow = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_54_0)
  local l_54_1 = BF_DoodadTopHeadDisplayEx.frameSelf:Lookup("Edit_Filtrate")
  return tostring(l_54_1:GetText())
end

l_0_1.GetEditValue = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_55_0, l_55_1)
  local l_55_2 = BF_DoodadTopHeadDisplayEx.frameSelf:Lookup("Edit_Filtrate")
  l_55_1 = tostring(l_55_1) or "���á�/���ָ�������"
  l_55_2:SetText(l_55_1)
end

l_0_1.SetEditValue = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_56_0, l_56_1)
  local l_56_2 = l_56_0:GetCheckboxesWindow()
  local l_56_3, l_56_4 = l_56_2:Lookup, l_56_2
  local l_56_6 = "CheckBox_"
  l_56_6 = l_56_6 .. l_56_1
  local l_56_5 = nil
  return l_56_3(l_56_4, l_56_6)
end

l_0_1.GetCheckBox = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_57_0, l_57_1)
  local l_57_2 = l_57_0:GetCheckBox(l_57_1)
  if l_57_2:IsCheckBoxChecked() then
    return BF_DoodadTopHeadDisplayEx.DataList[l_57_1].bEnable
  end
end

l_0_1.GetCheckBoxState = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_58_0, l_58_1, l_58_2)
  local l_58_3 = l_58_0:GetCheckBox(l_58_1)
  l_58_3:Check(l_58_2)
  BF_DoodadTopHeadDisplayEx.SavedCheckState[l_58_1] = l_58_2
end

l_0_1.SetCheckBoxState = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_59_0, l_59_1, l_59_2)
  local l_59_3 = l_59_0:GetCheckBox(l_59_1)
  local l_59_4 = l_59_3:Lookup("", "Text_" .. l_59_1)
  l_59_4:SetText(l_59_2)
end

l_0_1.SetCheckBoxText = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_60_0, l_60_1)
  local l_60_2 = l_60_0:GetCheckBox(l_60_1)
  local l_60_7 = l_60_2:Lookup
  local l_60_6 = l_60_2
  l_60_7 = l_60_7(l_60_6, "", "Text_" .. l_60_1)
  local l_60_3 = nil
  l_60_6, l_60_3 = l_60_7:GetText, l_60_7
  local l_60_4, l_60_5 = nil
  return l_60_6(l_60_3)
end

l_0_1.GetCheckBoxText = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_61_0, l_61_1, l_61_2)
  l_61_0.frameSelf:Lookup("", "Text_Title"):SetText(l_61_1)
  l_61_0.frameSelf:Lookup("", "Text_Title"):SetFontColor(32, 255, 128)
  l_61_0.frameSelf:Lookup("", "Text_Author"):SetText(l_61_2)
end

l_0_1.SetTitleAndAuthor = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_62_0, l_62_1)
  if l_62_1 < 0 then
    l_62_1 = 0
  end
  if l_62_1 > 255 then
    l_62_1 = 255
  end
  for l_62_5,l_62_6 in pairs(ScreenShotHelper.DataList) do
    ScreenShotHelper:GetCheckBox(l_62_5):SetAlpha(l_62_1)
  end
  do
    local l_62_7, l_62_8 = ScreenShotHelper.frameSelf:Lookup("Edit_Quality")
    if l_62_1 <= 80 then
      l_62_8(l_62_7)
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_62_8(l_62_7)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_62_8(l_62_8, l_62_1)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_62_8(l_62_8, l_62_1)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_62_8(l_62_8, l_62_1)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_62_8(l_62_8, l_62_1 / 3.5)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_62_8(l_62_8, l_62_1)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_62_1 <= 80 then
      l_62_8(l_62_8, 32, 32)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_62_8.bOpened = false
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_62_8(l_62_8, ScreenShotHelper.nOrgWidth, ScreenShotHelper.nOrgHeight)
       -- DECOMPILER ERROR: Overwrote pending register.

    end
    l_62_8.bOpened = true
  end
end

l_0_1.FadeOptionPanel = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_63_0, l_63_1)
end

l_0_1.Message = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_64_0)
  l_64_0.nSteperCount = l_64_0.nSteperCount + 1
  if l_64_0.nSteperCount >= 100000000 then
    l_64_0.nSteperCount = -1
  end
end

l_0_1.Steper = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_65_0, l_65_1)
  if not l_65_1 then
    l_65_1 = 8
  end
  if math.fmod(l_65_0.nSteperCount, l_65_1) ~= 0 then
    return false
  end
  return true
end

l_0_1.CheckSteper = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_66_0, l_66_1, l_66_2)
  if not l_66_1 or not l_66_2 then
    BF_DoodadTopHeadDisplayEx.frameSelf:SetPoint("CENTER", 64, 0, "CENTER", -256, 0)
  else
    local l_66_3, l_66_4 = Station.GetClientSize(true)
    if l_66_1 < 0 then
      l_66_1 = 0
    end
    if l_66_3 - 255 < l_66_1 then
      l_66_1 = l_66_3 - 255
    end
    if l_66_2 < 0 then
      l_66_2 = 0
    end
    if l_66_4 - 110 < l_66_2 then
      l_66_2 = l_66_4 - 110
    end
    BF_DoodadTopHeadDisplayEx.frameSelf:SetRelPos(l_66_1, l_66_2)
  end
end

l_0_1.SetPanelPos = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_67_0)
  if IsOptionOrOptionChildPanelOpened() then
    return 
  end
  if not Station.Lookup("Normal/BF_DoodadTopHeadDisplayEx") then
    local l_67_1, l_67_2, l_67_3 = Wnd.OpenWindow("Interface\\BF_LootListExSingle\\BF_DoodadTopHeadDisplayEx.ini", "BF_DoodadTopHeadDisplayEx")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_67_1:Show()
  BF_DoodadTopHeadDisplayEx:SetPanelPos()
end

l_0_1.OpenPanel = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_68_0)
  local l_68_1 = Station.Lookup("Normal/BF_DoodadTopHeadDisplayEx")
  if not l_68_1 then
    return 
  end
  l_68_1:Hide()
end

l_0_1.ClosePanel = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_69_0)
  local l_69_1 = Station.Lookup("Normal/BF_DoodadTopHeadDisplayEx")
  if l_69_1 and l_69_1:IsVisible() then
    return true
  end
  return false
end

l_0_1.IsOpened = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_2 = function(l_70_0)
  if BF_DoodadTopHeadDisplayEx:IsOpened() then
    BF_DoodadTopHeadDisplayEx:ClosePanel()
  else
    BF_DoodadTopHeadDisplayEx:OpenPanel()
  end
end

l_0_1.SwitchOpenState = l_0_2
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_1, l_0_2 = l_0_1:OpenPanel, l_0_1
l_0_1(l_0_2)
l_0_1 = BF_DoodadTopHeadDisplayEx
l_0_1, l_0_2 = l_0_1:ClosePanel, l_0_1
l_0_1(l_0_2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_2 = "LootList"
l_0_3 = "ʰȡ����"
l_0_1(l_0_2, l_0_3, "\\ui\\image\\icon\\coin05.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableLootList"
l_0_1(l_0_2, l_0_3, "����ʰȡ����", false, function(l_71_0)
  LootListExSingle.bLootGray = l_71_0
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableChangeLootListType"
l_0_1(l_0_2, l_0_3, "����ʰȡģʽ�л������һ����ͷ�����þ���ģʽ��", false, function(l_72_0)
  LootListExSingle.EnableChangeLootListType = l_72_0
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableRoll"
l_0_1(l_0_2, l_0_3, "�����Զ�ROLL��ɫ��Ʒ", false, function(l_73_0, l_73_1)
  if l_73_0 then
    LootListExSingle.bEnable = true
  else
    LootListExSingle.bEnable = false
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableShowDoodad"
l_0_1(l_0_2, l_0_3, "���������������������ʾ", false, function(l_74_0, l_74_1)
  LootListExSingle.EnableShowDoodad = l_74_0
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableShowDoodad1"
l_0_1(l_0_2, l_0_3, "��ʾ��ʯ", false, function(l_75_0, l_75_1)
  BF_DoodadTopHeadDisplayEx:SetCheckBoxState("A", l_75_0)
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableShowDoodad2"
l_0_1(l_0_2, l_0_3, "��ʾ��ҩ", false, function(l_76_0, l_76_1)
  BF_DoodadTopHeadDisplayEx:SetCheckBoxState("B", l_76_0)
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableShowDoodad3"
l_0_1(l_0_2, l_0_3, "��ʾ����", false, function(l_77_0, l_77_1)
  BF_DoodadTopHeadDisplayEx:SetCheckBoxState("C", l_77_0)
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "LootList"
l_0_3 = "EnableShowDoodad4"
l_0_1(l_0_2, l_0_3, "��ʾ���������������·�ƣ�", false, function(l_78_0, l_78_1)
  BF_DoodadTopHeadDisplayEx:SetCheckBoxState("D", l_78_0)
end
, 2)

