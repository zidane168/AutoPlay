-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: MiDKP.lua 

if BigFoot then
  local l_0_0 = {}
  do
    local l_0_1 = {}
    l_0_1.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a = {}
    l_0_1.BigFoot_f72f5262271114d1924b773eba1af0fd = {}
    l_0_0.Core = l_0_1
    l_0_0.Config, l_0_1 = l_0_1, {}
    l_0_0.Raid, l_0_1 = l_0_1, {}
    l_0_0.Event, l_0_1 = l_0_1, {}
    l_0_0.Member, l_0_1 = l_0_1, {}
    l_0_0.DKP, l_0_1 = l_0_1, {}
    l_0_0.Item, l_0_1 = l_0_1, {}
    l_0_0.Util, l_0_1 = l_0_1, {}
    l_0_0.EventHandler, l_0_1 = l_0_1, {}
    l_0_0.Error, l_0_1 = l_0_1, {RAID_ALREADY_EXISTS = 1, EMPTY_RAID_NAME = 2, EMPTY_MEMBER_NAME = 3, EMPTY_MEMBER_CLASS = 4, MEMBER_INLIST = 5, EVENT_EMPTY_MEMBERS = 6, ITEM_ERROR_ARGS = 7, ITEM_LOOTER_NOT_IN_RAID = 8, ANOTHER_RAID_STARTED = 10, NOT_IN_RAID = 11, RAID_NOT_START = 12, MEMBER_HAS_ITEM = 13, ITEM_EVENT = 14}
    local l_0_2 = {}
    l_0_2.SPLIT_ITEM_SCORE = "ƽ���������"
    l_0_0.Locales, l_0_1 = l_0_1, {zhCN = l_0_2}
    l_0_0.DefaultLocale = "zhCN"
    l_0_0.VERSION = "1.20"
    MiDKP = l_0_0
    l_0_0 = MiDKP
    l_0_2 = {[1] = true, [2] = true, [3] = true, [4] = true, [5] = true}
    l_0_2 = {}
    l_0_2 = PLAYER_TALK_CHANNEL
    l_0_2 = l_0_2.RAID
    l_0_0.ConfigData, l_0_1 = l_0_1, {RecordItemLevel = 4, DefaultParties = l_0_2, AllMembersOnEvent = true, OffLineMember = true, SplitItemScore = false, IgnoreItems = l_0_2, ReportEventInfo = nil, ReportItemInfo = nil, ReportMemberInfo = true, FilterWhisperMessage = true, EnableWhisperQuery = true, ActionOnEventLevel = 2, WhisperCommand = "dkp", DefaultMessageChannel = l_0_2}
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_1_0)
      MiDKP.Util:SaveConfigData()
      MiDKP.Util:SaveRaidData()
      MiDKP.Locale = MiDKP.Locales[MiDKP.DefaultLocale]
    end
    l_0_0.Init = l_0_1
    l_0_0 = MiDKP
    l_0_1 = function()
      FireEvent("UI_LUA_RESET")
    end
    l_0_0.SaveRaidDate = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_3_0, l_3_1, l_3_2)
      if not l_3_0.BigFoot_f72f5262271114d1924b773eba1af0fd[l_3_1] then
        l_3_0.BigFoot_f72f5262271114d1924b773eba1af0fd[l_3_1] = {}
      end
      table.insert(l_3_0.BigFoot_f72f5262271114d1924b773eba1af0fd[l_3_1], l_3_2)
    end
    l_0_0.RegisterEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_4_0, l_4_1, ...)
      if l_4_0.BigFoot_f72f5262271114d1924b773eba1af0fd[l_4_1] then
        for l_4_6,i_2 in ipairs(l_4_0.BigFoot_f72f5262271114d1924b773eba1af0fd[l_4_1]) do
          i_2(...)
        end
      end
    end
    l_0_0.FireEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_5_0, l_5_1, l_5_2)
      if not l_5_1 or #l_5_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_RAID_NAME)
        return 
      end
      if l_5_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_5_1] then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_ALREADY_EXISTS)
        return 
      end
      local l_5_3 = {}
      l_5_3.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_5_1
      if type(l_5_2) == "string" then
        l_5_2 = MiDKP.DKP:GetDKPByName(l_5_2)
        l_5_3.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_5_2:GetName()
      else
        if type(l_5_2) == "number" then
          l_5_2 = MiDKP.DKPGetDKPByIndex(l_5_2)
          l_5_3.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_5_2:GetName()
        end
      end
      local l_5_4 = setmetatable
      local l_5_5 = l_5_3
      local l_5_6 = {}
      l_5_6.__index = MiDKP.Raid
      l_5_4(l_5_5, l_5_6)
      l_5_4 = l_5_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a
      l_5_4[l_5_1] = l_5_3
      l_5_4 = MiDKP
      l_5_4 = l_5_4.Util
      l_5_4, l_5_5 = l_5_4:GetCurrentTime, l_5_4
      l_5_4 = l_5_4(l_5_5)
      l_5_3.BigFoot_71000f71402f150a72717bfb31cbd071 = l_5_4
      l_5_3.BigFoot_688fec9138c1fc6d0dd768683db73267, l_5_4 = l_5_4, {}
      l_5_3.BigFoot_f9542af0fc240db769f6a4369804f562, l_5_4 = l_5_4, {}
      l_5_3.BigFoot_3b9d336b2a6a475b46a21da367b594a7, l_5_4 = l_5_4, {}
      l_5_3.BigFoot_5d35e93b1cdcec64e01223b342633b87, l_5_4 = l_5_4, {}
      l_5_3.BigFoot_91458a0c1f732495f5644fd474a3f79f = 0
      l_5_4, l_5_5 = l_5_0:FireEvent, l_5_0
      l_5_6 = "RAID_CREATED"
      l_5_4(l_5_5, l_5_6, l_5_3)
      l_5_4 = MiDKP
      l_5_4 = l_5_4.SaveRaidDate
      l_5_4()
      return l_5_3
    end
    l_0_0.CreateRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_6_0, l_6_1)
      for l_6_5,l_6_6 in pairs(l_6_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a) do
        if l_6_1 == l_6_6 then
          l_6_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_6_5] = nil
          if MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b == l_6_6 then
            MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b = nil
          end
          l_6_0:FireEvent("RAID_DELETED", l_6_1)
        end
      end
      MiDKP.SaveRaidDate()
    end
    l_0_0.DeleteRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_7_0)
      local l_7_1 = 0
      for l_7_5 in pairs(MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a) do
        l_7_1 = l_7_1 + 1
      end
      return l_7_1
    end
    l_0_0.GetRaidCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_8_0, l_8_1)
      if not l_8_1 or #l_8_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_RAID_NAME)
        return 
      end
      return l_8_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_8_1]
    end
    l_0_0.GetRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_9_0)
      local l_9_1 = {}
      for l_9_5 in pairs(l_9_0.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a) do
        table.insert(l_9_1, l_9_5)
      end
      return l_9_1
    end
    l_0_0.GetAllRaidNames = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_10_0)
      return MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b
    end
    l_0_0.GetCurrentRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Core
    l_0_1 = function(l_11_0)
      local l_11_1 = MiDKP.Core:GetCurrentRaid()
      if l_11_1 and l_11_1:IsStarted() and not l_11_1:IsFinished() and MiDKP.Util:IsInRaid() then
        local l_11_2 = l_11_1:GetAllMemberNames()
        for l_11_6,l_11_7 in ipairs(l_11_2) do
          if not MiDKP.Util:IsMemberInRaid(l_11_7) then
            local l_11_8 = l_11_1:GetMember(l_11_7)
            l_11_8:Leave()
          end
        end
        for l_11_12 = 1, MiDKP.Util:GetMaxRaidSize() do
          local l_11_13, l_11_14, l_11_15, l_11_16 = MiDKP.Util:GetRaidMember(l_11_12)
          local l_11_17 = l_11_1:GetMember(l_11_13)
          if l_11_17 then
            l_11_17:SetParty(l_11_15)
            if l_11_16 then
              l_11_17:OnLine()
            end
          else
            l_11_17:OffLine()
          end
        end
         -- WARNING: missing end command somewhere! Added here
      end
    end
    l_0_0.UpdateCurrentRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_12_0)
      return l_12_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
    end
    l_0_0.GetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_13_0, l_13_1)
      if not l_13_1 or #l_13_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_RAID_NAME)
        return 
      end
      if MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_13_1] then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_ALREADY_EXISTS)
        return 
      end
      local l_13_2 = l_13_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
      l_13_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_13_1
      MiDKP.Core:FireEvent("RAID_NAME_CHANGED", l_13_0, l_13_2, l_13_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584)
    end
    l_0_0.SetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_14_0)
      if not MiDKP.Util:IsInRaid() then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.NOT_IN_RAID)
        return 
      end
      if MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ANOTHER_RAID_STARTED)
        return 
      end
      if not l_14_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b = l_14_0
        l_14_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f = true
        l_14_0.BigFoot_84b858c262498d7b2211041076e7a8fe = MiDKP.Util:GetCurrentTime()
        local l_14_1 = MiDKP.Util:GetMaxRaidSize()
        for l_14_5 = 1, l_14_1 do
          local l_14_6, l_14_7, l_14_8, l_14_9 = MiDKP.Util:GetRaidMember(l_14_5)
          if l_14_6 and l_14_7 then
            l_14_0:AddMember(l_14_6, l_14_7, l_14_8, l_14_9, true)
          end
        end
        MiDKP.Core:FireEvent("RAID_STARTED", l_14_0)
      end
    end
    l_0_0.Start = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_15_0)
      if l_15_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f and not l_15_0.BigFoot_9324ffd8707783d1899c5d020ebb2b0d then
        l_15_0.BigFoot_9324ffd8707783d1899c5d020ebb2b0d = true
        l_15_0.BigFoot_0a89786d7f7d1b51d0ebcc6a1a92954b = MiDKP.Util:GetCurrentTime()
        for l_15_4,l_15_5 in pairs(MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b.BigFoot_f9542af0fc240db769f6a4369804f562) do
          l_15_5.BigFoot_639cc82727cceae5afc908ea9c9704f3 = l_15_0.BigFoot_0a89786d7f7d1b51d0ebcc6a1a92954b
        end
        MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b = nil
        MiDKP.Core:FireEvent("RAID_FINISHED", l_15_0)
      end
    end
    l_0_0.Finish = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_16_0, l_16_1, l_16_2)
      if not l_16_1 or #l_16_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_RAID_NAME)
        return 
      end
      if MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_16_1] and MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a[l_16_1] ~= l_16_0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_ALREADY_EXISTS)
        return 
      end
      l_16_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_16_1
      if type(l_16_2) == "string" then
        l_16_2 = MiDKP.DKP:GetDKPByName(l_16_2)
        l_16_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_16_2:GetName()
      else
        if type(l_16_2) == "number" then
          l_16_2 = MiDKP.DKPGetDKPByIndex(l_16_2)
          l_16_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_16_2:GetName()
        end
      else
        l_16_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = nil
      end
      MiDKP.Core:FireEvent("RAID_MODIFIED", l_16_0)
    end
    l_0_0.Modify = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_17_0)
      return l_17_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f
    end
    l_0_0.IsStarted = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_18_0)
      return l_18_0.BigFoot_9324ffd8707783d1899c5d020ebb2b0d
    end
    l_0_0.IsFinished = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_19_0, l_19_1)
      local l_19_2, l_19_7, l_19_8, l_19_9 = nil
      for l_19_6,i_2 in ipairs(l_19_0.BigFoot_5d35e93b1cdcec64e01223b342633b87) do
        if i_2 == l_19_1 then
          l_19_2 = true
          do break end
        end
      end
      if not l_19_2 then
        table.insert(l_19_0.BigFoot_5d35e93b1cdcec64e01223b342633b87, l_19_1)
        MiDKP.Core:FireEvent("RAID_NEW_LOCATION_ADDED", l_19_0, l_19_1)
      end
    end
    l_0_0.AddLocation = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_20_0)
      return l_20_0.BigFoot_5d35e93b1cdcec64e01223b342633b87
    end
    l_0_0.GetLocations = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_21_0)
      return l_21_0.BigFoot_84b858c262498d7b2211041076e7a8fe
    end
    l_0_0.GetStartTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_22_0)
      return l_22_0.BigFoot_0a89786d7f7d1b51d0ebcc6a1a92954b
    end
    l_0_0.GetFinishTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_23_0)
      return l_23_0.BigFoot_71000f71402f150a72717bfb31cbd071
    end
    l_0_0.GetCreationTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_24_0)
      local l_24_1, l_24_2 = MiDKP.DKP:GetDKPByName, MiDKP.DKP
      local l_24_3 = l_24_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393
      return l_24_1(l_24_2, l_24_3)
    end
    l_0_0.GetDKP = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_25_0, l_25_1)
      local l_25_2 = l_25_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393
      if type(l_25_1) == "string" then
        l_25_1 = MiDKP.DKP:GetDKPByName(l_25_1)
        l_25_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_25_1:GetName()
      else
        if type(l_25_1) == "number" then
          l_25_1 = MiDKP.DKPGetDKPByIndex(l_25_1)
          l_25_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_25_1:GetName()
        end
      else
        l_25_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = nil
      end
      MiDKP.Core:FireEvent("RAID_DKP_CHANGED", l_25_0, l_25_2, l_25_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393)
    end
    l_0_0.SetDKP = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_26_0, l_26_1, l_26_2, l_26_3, l_26_4, l_26_5)
      if not l_26_1 or #l_26_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_MEMBER_NAME)
        return 
      end
      if not l_26_2 or #l_26_2 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_MEMBER_CLASS)
        return 
      end
      if l_26_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_26_1] then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.MEMBER_INLIST)
        return 
      end
      if not l_26_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      local l_26_6 = nil
      if l_26_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_26_1] and l_26_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_26_1].BigFoot_e92196103715b8c5899eb5a04a0ef4c0 then
        l_26_6 = l_26_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_26_1]
        l_26_6.BigFoot_593bd0ea37e18d7a17b89b961d822981 = l_26_4
        local l_26_7 = nil
        if not l_26_3 then
          l_26_7 = 0
        end
        l_26_6.BigFoot_25daf5581aad0afcae714dddb26e519c = l_26_7
        l_26_6.BigFoot_e92196103715b8c5899eb5a04a0ef4c0 = nil
      else
        l_26_6 = {}
        l_26_6.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_26_1
        l_26_6.BigFoot_b962f54280c77029bc350c2b321adc64 = l_26_2
        l_26_6.BigFoot_593bd0ea37e18d7a17b89b961d822981 = l_26_4
        local l_26_8 = nil
        if not l_26_3 then
          l_26_8 = 0
        end
        l_26_6.BigFoot_25daf5581aad0afcae714dddb26e519c = l_26_8
        l_26_8 = MiDKP
        l_26_8 = l_26_8.Util
         -- DECOMPILER ERROR: Overwrote pending register.

        l_26_6.BigFoot_088aed45c27da9d4db431a8e159a9a44 = l_26_8
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_26_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_26_8
        l_26_6.BigFoot_99295537feebf0af77699930b0973c1f = 0
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_26_9 = l_26_6
        local l_26_10 = {}
        l_26_10.__index = MiDKP.Member
        l_26_8(l_26_9, l_26_10)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_26_8[l_26_1] = l_26_6
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      l_26_0.BigFoot_91458a0c1f732495f5644fd474a3f79f = l_26_8 + 1
      if not l_26_5 then
        MiDKP.Core:FireEvent("RAID_MEMBER_ADDED", l_26_0, l_26_1, l_26_2, l_26_6)
      end
    end
    l_0_0.AddMember = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_27_0, l_27_1)
      if not l_27_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      if l_27_1:HasItem() then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.MEMBER_HAS_ITEM)
        return 
      end
      if type(l_27_1) == "string" then
        l_27_1 = l_27_0:GetMember(l_27_1)
      else
        if type(l_27_1) == "table" then
          l_27_1 = l_27_0:GetMember(l_27_1:GetName())
        end
      end
      if l_27_1 then
        for l_27_5,l_27_6 in ipairs(l_27_0.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          local l_27_7 = nil
          local l_27_8 = l_27_6:GetMembers()
          for l_27_12 = 1, #l_27_8 do
            if l_27_8[l_27_12] == l_27_1:GetName() then
              l_27_7 = true
              do break end
            end
          end
          if l_27_7 then
            local l_27_13 = {}
            for l_27_17 = 1, #l_27_8 do
              if l_27_8[l_27_17] ~= l_27_1:GetName() then
                table.insert(l_27_13, l_27_8[l_27_17])
              end
            end
            if #l_27_13 > 0 then
              l_27_6:Modify(l_27_6.BigFoot_58bf64b2530594f4163e4cd743249693, l_27_6.BigFoot_20c03d41df6d325491f00a3df9858f08, l_27_13, l_27_6.BigFoot_2fa468158e8ccca35651477aab291193)
            end
          else
            l_27_0:DeleteEvent(l_27_6)
          end
        end
        l_27_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_27_1:GetName()] = nil
        l_27_0.BigFoot_91458a0c1f732495f5644fd474a3f79f = l_27_0.BigFoot_91458a0c1f732495f5644fd474a3f79f - 1
        MiDKP.Core:FireEvent("MEMBER_DELETED", l_27_0, l_27_1:GetName(), l_27_1)
      end
    end
    l_0_0.DeleteMember = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_28_0, l_28_1)
      if not l_28_1 or #l_28_1 == 0 then
        return 
      end
      return l_28_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_28_1]
    end
    l_0_0.GetMember = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_29_0)
      return l_29_0.BigFoot_91458a0c1f732495f5644fd474a3f79f
    end
    l_0_0.GetMemberCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_30_0)
      local l_30_1 = {}
      for l_30_5,l_30_6 in pairs(l_30_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
        table.insert(l_30_1, l_30_6:GetName())
      end
      return l_30_1
    end
    l_0_0.GetAllMemberNames = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_31_0, l_31_1, l_31_2, l_31_3, l_31_4, l_31_5, l_31_6)
      if not l_31_5 and (not l_31_3 or #l_31_3 == 0) then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EVENT_EMPTY_MEMBERS)
        return 
      end
      if not l_31_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      local l_31_7 = {}
      local l_31_8 = setmetatable
      local l_31_9 = l_31_7
      local l_31_10 = {}
      l_31_10.__index = MiDKP.Event
      l_31_8(l_31_9, l_31_10)
      l_31_8 = l_31_1 or ""
      l_31_7.BigFoot_58bf64b2530594f4163e4cd743249693 = l_31_8
      if not l_31_3 then
        l_31_7.BigFoot_f9542af0fc240db769f6a4369804f562, l_31_8 = l_31_8, {}
      end
      l_31_8 = MiDKP
      l_31_8 = l_31_8.Util
      l_31_8, l_31_9 = l_31_8:GetCurrentTime, l_31_8
      l_31_8 = l_31_8(l_31_9)
      l_31_7.BigFoot_71000f71402f150a72717bfb31cbd071 = l_31_8
      if l_31_6 then
        l_31_7.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_31_6
        l_31_7.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d = true
      else
        l_31_7.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d = l_31_5
        l_31_7.BigFoot_2fa468158e8ccca35651477aab291193 = l_31_4
      end
      l_31_8 = l_31_2 or 0
      l_31_7.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_31_8
      l_31_8 = table
      l_31_8 = l_31_8.insert
      l_31_9 = l_31_0.BigFoot_688fec9138c1fc6d0dd768683db73267
      l_31_10 = l_31_7
      l_31_8(l_31_9, l_31_10)
      l_31_8, l_31_9 = l_31_0:GetName, l_31_0
      l_31_8 = l_31_8(l_31_9)
      l_31_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_31_8
      l_31_8 = ipairs
      l_31_9 = l_31_3
      l_31_8 = l_31_8(l_31_9)
      for i_1,i_2 in l_31_8 do
        local l_31_13 = l_31_0:GetMember(l_31_12)
        l_31_13:AddScore(l_31_2)
      end
      if l_31_5 and not l_31_6 then
        MiDKP.Core:FireEvent("AUTO_EVENT_CREATED", l_31_0, l_31_7)
      end
      MiDKP.Core:FireEvent("EVENT_CREATED", l_31_0, l_31_7)
      return l_31_7
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    l_0_0.CreateEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_32_0, l_32_1, l_32_2)
      if not l_32_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      if type(l_32_1) == "number" and l_32_0.BigFoot_688fec9138c1fc6d0dd768683db73267[l_32_1] then
        local l_32_3 = l_32_0.BigFoot_688fec9138c1fc6d0dd768683db73267[l_32_1]
        if l_32_3:IsItemEvent() and not l_32_2 then
          MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_EVENT)
          return 
        end
        for l_32_7,l_32_8 in ipairs(l_32_3.BigFoot_f9542af0fc240db769f6a4369804f562) do
          local l_32_9 = l_32_0:GetMember(l_32_8)
          l_32_9:AddScore(-l_32_3.BigFoot_20c03d41df6d325491f00a3df9858f08)
        end
        table.remove(l_32_0.BigFoot_688fec9138c1fc6d0dd768683db73267, l_32_1)
        MiDKP.Core:FireEvent("EVENT_DELETED", l_32_0, l_32_3)
      end
      do return end
      if type(l_32_1) == "table" then
        for l_32_13,l_32_14 in ipairs(l_32_0.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          if l_32_14 == l_32_1 then
            if l_32_14:IsItemEvent() and not l_32_2 then
              MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_EVENT)
              return 
            end
            for l_32_18,l_32_19 in ipairs(l_32_14.BigFoot_f9542af0fc240db769f6a4369804f562) do
              local l_32_20 = l_32_0:GetMember(l_32_19)
              l_32_20:AddScore(-l_32_14.BigFoot_20c03d41df6d325491f00a3df9858f08)
            end
            table.remove(l_32_0.BigFoot_688fec9138c1fc6d0dd768683db73267, l_32_13)
            MiDKP.Core:FireEvent("EVENT_DELETED", l_32_0, l_32_1)
          end
        end
      end
    end
    l_0_0.DeleteEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_33_0, l_33_1)
      return l_33_0.BigFoot_688fec9138c1fc6d0dd768683db73267[l_33_1]
    end
    l_0_0.GetEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_34_0)
      return #l_34_0.BigFoot_688fec9138c1fc6d0dd768683db73267
    end
    l_0_0.GetEventCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_35_0, l_35_1, l_35_2, l_35_3, l_35_4, l_35_5)
      if not l_35_1 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_ERROR_ARGS)
        return 
      end
      if not l_35_2 or not l_35_0:GetMember(l_35_2) then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_LOOTER_NOT_IN_RAID)
        return 
      end
      if not l_35_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      local l_35_6 = {}
      local l_35_7 = setmetatable
      local l_35_8 = l_35_6
      local l_35_9 = {}
      l_35_9.__index = MiDKP.Item
      l_35_7(l_35_8, l_35_9)
      l_35_7 = MiDKP
      l_35_7 = l_35_7.Util
      l_35_7, l_35_8 = l_35_7:GetCurrentTime, l_35_7
      l_35_7 = l_35_7(l_35_8)
      l_35_6.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b = l_35_7
      l_35_6.BigFoot_4cf6e7d7de970d76ed602b6363820676 = l_35_2
      l_35_7 = type
      l_35_8 = l_35_3
      l_35_7 = l_35_7(l_35_8)
      l_35_7 = l_35_7 == "number" and l_35_3 or 0
      l_35_6.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_35_7
      l_35_7 = type
      l_35_8 = l_35_1
      l_35_7 = l_35_7(l_35_8)
      if l_35_7 == "table" then
        l_35_7 = MiDKP
        l_35_7 = l_35_7.Util
        l_35_7, l_35_8 = l_35_7:GetItemName, l_35_7
        l_35_9 = l_35_1
        l_35_7 = l_35_7(l_35_8, l_35_9)
        l_35_6.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_35_7
        l_35_7 = MiDKP
        l_35_7 = l_35_7.Util
        l_35_7, l_35_8 = l_35_7:GetItemLink, l_35_7
        l_35_9 = l_35_1
        l_35_7 = l_35_7(l_35_8, l_35_9)
        l_35_6.BigFoot_15ad1e501e228eb80be1cc7800ab967d = l_35_7
        l_35_6.BigFoot_4ac22e939c7fd1fac854933eb2a943a3 = l_35_1
        l_35_6.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d = true
      else
        l_35_7 = type
        l_35_8 = l_35_1
        l_35_7 = l_35_7(l_35_8)
      end
      if l_35_7 == "string" then
        l_35_6.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_35_1
        l_35_6.BigFoot_15ad1e501e228eb80be1cc7800ab967d = l_35_1
      end
      l_35_6.BigFoot_4ac22e939c7fd1fac854933eb2a943a3 = l_35_1
      l_35_7, l_35_8 = l_35_0:GetMember, l_35_0
      l_35_9 = l_35_2
      l_35_7 = l_35_7(l_35_8, l_35_9)
      l_35_2 = l_35_7
      l_35_7, l_35_8 = l_35_2:AddScore, l_35_2
      l_35_9 = -l_35_3
      l_35_7(l_35_8, l_35_9)
      if l_35_4 then
        l_35_7 = MiDKP
        l_35_7 = l_35_7.Config
        l_35_7, l_35_8 = l_35_7:GetValue, l_35_7
        l_35_9 = "AllMembersOnEvent"
        l_35_7 = l_35_7(l_35_8, l_35_9)
        l_35_8 = MiDKP
        l_35_8 = l_35_8.Config
        l_35_8, l_35_9 = l_35_8:GetValue, l_35_8
        l_35_8 = l_35_8(l_35_9, "DefaultParties")
        l_35_9 = MiDKP
        l_35_9 = l_35_9.Config
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_35_10 = {}
        if l_35_7 then
          l_35_10 = l_35_0:GetAllMemberNames()
          do break end
        end
        for l_35_14,l_35_15 in ipairs(l_35_0:GetAllMemberNames()) do
          local l_35_16 = l_35_0:GetMember(l_35_15)
          if l_35_16 and l_35_8[l_35_16:GetParty()] and (l_35_9 or l_35_16:IsOnLine()) then
            table.insert(l_35_10, l_35_16:GetName())
          end
        end
        l_35_6.BigFoot_715bbba62fd4f6c84e70080d536eca0e = MiDKP.Util:GetCurrentTime() * 10000 + math.random(1000, 10000)
        l_35_0:CreateEvent(l_35_6.BigFoot_8983c60d66c8593ec7165ea9dbedb584 .. " " .. MiDKP.Locale.SPLIT_ITEM_SCORE, math.floor(l_35_3 / #l_35_10 + 0.5), l_35_10, nil, true, l_35_6.BigFoot_715bbba62fd4f6c84e70080d536eca0e)
      end
      l_35_7, l_35_8 = l_35_0:GetName, l_35_0
      l_35_7 = l_35_7(l_35_8)
      l_35_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_35_7
      l_35_6.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d = l_35_5
      l_35_7 = table
      l_35_7 = l_35_7.insert
      l_35_8 = l_35_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7
       -- DECOMPILER ERROR: Overwrote pending register.

      l_35_7(l_35_8, l_35_9)
      if l_35_5 then
        l_35_7 = MiDKP
        l_35_7 = l_35_7.Core
        l_35_7, l_35_8 = l_35_7:FireEvent, l_35_7
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_35_17 = l_35_0
        local l_35_18 = l_35_6
        local l_35_19 = l_35_1
        l_35_7(l_35_8, l_35_9, l_35_17, l_35_18, l_35_19, type(args) == "table")
      end
      l_35_7 = MiDKP
      l_35_7 = l_35_7.Core
      l_35_7, l_35_8 = l_35_7:FireEvent, l_35_7
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_35_22 = l_35_0
      local l_35_23 = l_35_6
      local l_35_24 = l_35_1
      l_35_7(l_35_8, l_35_9, l_35_22, l_35_23, l_35_24, type(l_35_1) == "table")
      return l_35_6
    end
    l_0_0.CreateItem = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_36_0)
      return #l_36_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7
    end
    l_0_0.GetItemCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_37_0, l_37_1)
      return l_37_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7[l_37_1]
    end
    l_0_0.GetItem = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_38_0, l_38_1)
      if not l_38_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      if type(l_38_1) == "number" and l_38_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7[l_38_1] then
        local l_38_2 = l_38_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7[l_38_1]
        if l_38_2.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
          for l_38_6,l_38_7 in ipairs(l_38_0.BigFoot_688fec9138c1fc6d0dd768683db73267) do
            if l_38_7.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_38_2.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
              l_38_0:DeleteEvent(l_38_7, true)
            end
        else
          end
        end
        do
          local l_38_8, l_38_9 = l_38_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_38_2:GetLooter()]
          if l_38_8 then
            l_38_9(l_38_8, l_38_2:GetScore())
          end
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_38_9(l_38_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7, l_38_1)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

        end
        l_38_9(l_38_9, "ITEM_DELETED", l_38_0, l_38_2)
      end
      do return end
      if type(l_38_1) == "table" then
        for l_38_13,l_38_14 in ipairs(l_38_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
          if l_38_14 == l_38_1 then
            if l_38_14.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
              for l_38_18,l_38_19 in ipairs(l_38_0.BigFoot_688fec9138c1fc6d0dd768683db73267) do
                if l_38_19.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_38_14.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
                  l_38_0:DeleteEvent(l_38_19, true)
                end
                do break end
              end
            end
            do
              local l_38_20, l_38_21 = l_38_0.BigFoot_f9542af0fc240db769f6a4369804f562[l_38_14:GetLooter()]
              if l_38_20 then
                l_38_21(l_38_20, l_38_14:GetScore())
              end
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_38_21(l_38_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7, l_38_13)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

            end
            l_38_21(l_38_21, "ITEM_DELETED", l_38_0, l_38_1)
          end
          do break end
        end
      end
    end
    l_0_0.DeleteItem = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_39_0)
      if l_39_0:IsFinished() then
        local l_39_1 = "<midkp>"
        l_39_1 = l_39_1 .. "<raid>"
        l_39_1 = l_39_1 .. "<name>" .. l_39_0:GetName() .. "</name>"
        l_39_1 = l_39_1 .. "<version>" .. MiDKP.VERSION .. "</version>"
        local l_39_2 = MiDKP.Util:TimeToDate(l_39_0:GetStartTime())
        l_39_1 = l_39_1 .. "<start>" .. string.format("%04d.%02d.%02d %02d:%02d", l_39_2.year, l_39_2.month, l_39_2.day, l_39_2.hour, l_39_2.minute) .. "</start>"
        l_39_2 = MiDKP.Util:TimeToDate(l_39_0:GetFinishTime())
        l_39_1 = l_39_1 .. "<end>" .. string.format("%04d.%02d.%02d %02d:%02d", l_39_2.year, l_39_2.month, l_39_2.day, l_39_2.hour, l_39_2.minute) .. "</end>"
        l_39_1 = l_39_1 .. "<creator>" .. MiDKP.Util:GetClientPlayer() .. "</creator>"
        l_39_1 = l_39_1 .. "<places>"
        for l_39_6,l_39_7 in ipairs(l_39_0.BigFoot_5d35e93b1cdcec64e01223b342633b87) do
          l_39_1 = l_39_1 .. "<place>" .. l_39_7 .. "</place>"
        end
        l_39_1 = l_39_1 .. "</places>"
        l_39_1 = l_39_1 .. "<members>"
        if l_39_0:GetMemberCount() == 0 then
          l_39_1 = l_39_1 .. "<member/>"
        end
        for l_39_11,l_39_12 in ipairs(l_39_0:GetAllMemberNames()) do
          l_39_1 = l_39_1 .. "<member>"
          local l_39_13 = l_39_0:GetMember(l_39_12)
          l_39_1 = l_39_1 .. "<name>" .. l_39_13:GetName() .. "</name>"
          l_39_1 = l_39_1 .. "<class>" .. l_39_13:GetClass() .. "</class>"
          l_39_1 = l_39_1 .. "</member>"
        end
        l_39_1 = l_39_1 .. "</members>"
        l_39_1 = l_39_1 .. "<events>"
        if l_39_0:GetEventCount() == 0 then
          l_39_1 = l_39_1 .. "<event/>"
        end
        for l_39_17 = 1, l_39_0:GetEventCount() do
          local l_39_18 = l_39_0:GetEvent(l_39_17)
          l_39_1 = l_39_1 .. "<event>"
          l_39_1 = l_39_1 .. "<name>" .. l_39_18:GetDesc() .. "</name>"
          if l_39_18:IsBossEvent() then
            l_39_1 = l_39_1 .. "<boss>1</boss>"
          else
            if l_39_18:GetScore() < 0 then
              l_39_1 = l_39_1 .. "<punish>true</punish>"
            end
          end
          l_39_2 = MiDKP.Util:TimeToDate(l_39_18:GetCreationTime())
          l_39_1 = l_39_1 .. "<time>" .. string.format("%04d.%02d.%02d %02d:%02d", l_39_2.year, l_39_2.month, l_39_2.day, l_39_2.hour, l_39_2.minute) .. "</time>"
          l_39_1 = l_39_1 .. "<members>"
          if l_39_18:GetMemberCount() == 0 then
            l_39_1 = l_39_1 .. "<member/>"
          end
          local l_39_19 = l_39_18:GetMembers()
          for l_39_23,l_39_24 in ipairs(l_39_19) do
            l_39_1 = l_39_1 .. "<member>" .. l_39_24 .. "</member>"
          end
          l_39_1 = l_39_1 .. "</members>"
          l_39_1 = l_39_1 .. "<point>" .. math.abs(l_39_18:GetScore()) .. "</point>"
          l_39_1 = l_39_1 .. "</event>"
        end
        l_39_1 = l_39_1 .. "</events>"
        l_39_1 = l_39_1 .. "<items>"
        if l_39_0:GetItemCount() == 0 then
          l_39_1 = l_39_1 .. "<item/>"
        end
        for l_39_28 = 1, l_39_0:GetItemCount() do
          local l_39_29 = l_39_0:GetItem(l_39_28)
          l_39_1 = l_39_1 .. "<item>"
          l_39_1 = l_39_1 .. "<name>" .. l_39_29:GetLink() .. "</name>"
          l_39_2 = MiDKP.Util:TimeToDate(l_39_29:GetLootTime())
          l_39_1 = l_39_1 .. "<time>" .. string.format("%04d.%02d.%02d %02d:%02d", l_39_2.year, l_39_2.month, l_39_2.day, l_39_2.hour, l_39_2.minute) .. "</time>"
          l_39_1 = l_39_1 .. "<looter>" .. l_39_29:GetLooter() .. "</looter>"
          l_39_1 = l_39_1 .. "<point>" .. l_39_29:GetScore() .. "</point>"
          l_39_1 = l_39_1 .. "</item>"
        end
        l_39_1 = l_39_1 .. "</items>"
        l_39_1 = l_39_1 .. "</raid>"
        l_39_1 = l_39_1 .. "</midkp>"
        return l_39_1
      end
    end
    l_0_0.Export = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_40_0, l_40_1)
      local l_40_2 = {}
      for l_40_6,l_40_7 in pairs(l_40_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
        if l_40_7:GetClass() == l_40_1 then
          local l_40_8 = table.insert
          local l_40_9 = l_40_2
          local l_40_10 = {}
          l_40_10.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_40_7:GetName()
          l_40_10.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_40_7:GetScore()
          l_40_8(l_40_9, l_40_10)
        end
      end
      return l_40_2
    end
    l_0_0.QueryClass = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Raid
    l_0_1 = function(l_41_0, l_41_1, l_41_2)
      if not l_41_0.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.RAID_NOT_START)
        return 
      end
      local l_41_3 = MiDKP.Config:GetValue("ReportEventInfo")
      local l_41_4 = MiDKP.Config:GetValue("ReportItemInfo")
      local l_41_5 = MiDKP.Config:GetValue("ReportMemberInfo")
      local l_41_6 = {}
      if l_41_0.BigFoot_9324ffd8707783d1899c5d020ebb2b0d then
        l_41_6.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b = l_41_0.BigFoot_0a89786d7f7d1b51d0ebcc6a1a92954b - l_41_0.BigFoot_84b858c262498d7b2211041076e7a8fe
      else
        l_41_6.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b = MiDKP.Util:GetCurrentTime() - l_41_0.BigFoot_84b858c262498d7b2211041076e7a8fe
      end
      l_41_6.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_41_0:GetName()
      if l_41_3 then
        l_41_6.BigFoot_688fec9138c1fc6d0dd768683db73267 = {}
        for l_41_10,l_41_11 in ipairs(l_41_0.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          if l_41_11.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
            for l_41_15,l_41_16 in ipairs(l_41_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
              if l_41_11.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_41_16.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
                local l_41_17 = table.insert
                local l_41_18 = l_41_6.BigFoot_688fec9138c1fc6d0dd768683db73267
                local l_41_19 = {}
                l_41_19.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = true
                l_41_19.BigFoot_4ac22e939c7fd1fac854933eb2a943a3 = l_41_16:GetArgs()
                l_41_19.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_41_11:GetScore()
                l_41_17(l_41_18, l_41_19)
            else
              end
            end
          else
            local l_41_20 = table.insert
            local l_41_21 = l_41_6.BigFoot_688fec9138c1fc6d0dd768683db73267
            local l_41_22 = {}
            l_41_22.BigFoot_58bf64b2530594f4163e4cd743249693 = l_41_11:GetDesc()
            l_41_22.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_41_11:GetScore()
            l_41_20(l_41_21, l_41_22)
          end
        end
      end
      if l_41_4 then
        l_41_6.BigFoot_3b9d336b2a6a475b46a21da367b594a7 = {}
        for l_41_26,l_41_27 in ipairs(l_41_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
          local l_41_28 = table.insert
          local l_41_29 = l_41_6.BigFoot_3b9d336b2a6a475b46a21da367b594a7
          local l_41_30 = {}
          l_41_30.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_41_27:GetName()
          l_41_30.BigFoot_4cf6e7d7de970d76ed602b6363820676 = l_41_27:GetLooter()
          l_41_30.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_41_27:GetScore()
          l_41_30.BigFoot_4ac22e939c7fd1fac854933eb2a943a3 = l_41_27:GetArgs()
          l_41_28(l_41_29, l_41_30)
        end
      end
      if l_41_5 then
        l_41_6.BigFoot_f9542af0fc240db769f6a4369804f562 = {}
        for l_41_34,l_41_35 in pairs(l_41_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
          if (not l_41_1 or l_41_35:GetParty() ~= 0) and (not l_41_2 or not l_41_2[l_41_35:GetClass()]) then
            local l_41_36 = table.insert
            local l_41_37 = l_41_6.BigFoot_f9542af0fc240db769f6a4369804f562
            local l_41_38 = {}
            l_41_38.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_41_35:GetName()
            l_41_38.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_41_35:GetScore()
            l_41_36(l_41_37, l_41_38)
          end
        end
      end
      return l_41_6
    end
    l_0_0.GetReport = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_42_0, l_42_1, l_42_2, l_42_3, l_42_4)
      if l_42_0.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d and (not l_42_3 or #l_42_3 == 0) then
        MiDKP.Core:FireEvent("error", MiDKP.Error.EVENT_EMPTY_MEMBERS)
        return 
      end
      local l_42_5 = MiDKP.Core:GetRaid(l_42_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      local l_42_6 = l_42_0.BigFoot_20c03d41df6d325491f00a3df9858f08
      for l_42_10,l_42_11 in ipairs(l_42_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
        local l_42_12 = l_42_5:GetMember(l_42_11)
        l_42_12:AddScore(-l_42_6)
      end
      if l_42_0.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
        for l_42_16 = 1, l_42_5:GetItemCount() do
          local l_42_17 = l_42_5:GetItem(l_42_16)
          if l_42_17.BigFoot_715bbba62fd4f6c84e70080d536eca0e == l_42_0.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
            l_42_2 = math.floor(l_42_17:GetScore() / #l_42_3)
          end
        end
      end
      l_42_0.BigFoot_f9542af0fc240db769f6a4369804f562 = l_42_3
      local l_42_18 = nil
      if not l_42_1 then
        l_42_18 = ""
      end
      l_42_0.BigFoot_58bf64b2530594f4163e4cd743249693 = l_42_18
      l_42_18 = l_42_2 or 0
      l_42_0.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_42_18
      l_42_0.BigFoot_2fa468158e8ccca35651477aab291193 = l_42_4
      l_42_18 = ipairs
      l_42_18 = l_42_18(l_42_0.BigFoot_f9542af0fc240db769f6a4369804f562)
      for l_42_22,i_2 in l_42_18 do
        local l_42_23 = l_42_5:GetMember(l_42_22)
        l_42_23:AddScore(l_42_0.BigFoot_20c03d41df6d325491f00a3df9858f08)
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      MiDKP.Core:FireEvent("EVENT_MODIFIED", l_42_5, l_42_0)
    end
    l_0_0.Modify = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_43_0)
      return l_43_0.BigFoot_58bf64b2530594f4163e4cd743249693
    end
    l_0_0.GetDesc = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_44_0)
      return l_44_0.BigFoot_71000f71402f150a72717bfb31cbd071
    end
    l_0_0.GetCreationTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_45_0)
      return l_45_0.BigFoot_20c03d41df6d325491f00a3df9858f08
    end
    l_0_0.GetScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_46_0)
      return l_46_0.BigFoot_f9542af0fc240db769f6a4369804f562
    end
    l_0_0.GetMembers = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_47_0)
      return #l_47_0.BigFoot_f9542af0fc240db769f6a4369804f562
    end
    l_0_0.GetMemberCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_48_0)
      return l_48_0.BigFoot_2fa468158e8ccca35651477aab291193
    end
    l_0_0.IsBossEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_49_0)
      return l_49_0.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d
    end
    l_0_0.IsAutoEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_50_0)
      return l_50_0.BigFoot_2e00ffac12aadb3a1fd865993ec505b9
    end
    l_0_0.IsItemEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Event
    l_0_1 = function(l_51_0, l_51_1)
      if type(l_51_1) == "table" then
        l_51_1 = l_51_1:GetName()
      end
      for l_51_5,l_51_6 in ipairs(l_51_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
        if l_51_1 == l_51_6 then
          return true
        end
      end
      return false
    end
    l_0_0.HasMember = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_52_0)
      return l_52_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
    end
    l_0_0.GetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_53_0)
      return l_53_0.BigFoot_b962f54280c77029bc350c2b321adc64
    end
    l_0_0.GetClass = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_54_0, l_54_1, l_54_2, l_54_3)
      if not l_54_1 or #l_54_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_MEMBER_NAME)
        return 
      end
      if not l_54_2 or #l_54_2 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_MEMBER_CLASS)
        return 
      end
      local l_54_4 = l_54_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
      local l_54_5 = l_54_0.BigFoot_b962f54280c77029bc350c2b321adc64
      local l_54_6 = l_54_0.BigFoot_25daf5581aad0afcae714dddb26e519c
      l_54_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_54_1
      l_54_0.BigFoot_b962f54280c77029bc350c2b321adc64 = l_54_2
      l_54_0.BigFoot_25daf5581aad0afcae714dddb26e519c = l_54_3
      MiDKP.Core:FireEvent("RAID_MEMBER_MODIFIED", MiDKP.Core:GetRaid(l_54_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_54_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584, l_54_0, l_54_4, l_54_5, l_54_6)
    end
    l_0_0.Modify = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_55_0, l_55_1)
      if not l_55_1 or #l_55_1 == 0 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.EMPTY_MEMBER_NAME)
        return 
      end
      local l_55_2 = l_55_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
      l_55_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_55_1
      MiDKP.Core:FireEvent("RAID_MEMBER_NAME_CHANGED", l_55_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, l_55_2, l_55_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584)
    end
    l_0_0.SetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_56_0, l_56_1)
      local l_56_2 = l_56_0.BigFoot_b962f54280c77029bc350c2b321adc64
      l_56_0.BigFoot_b962f54280c77029bc350c2b321adc64 = l_56_1
      MiDKP.Core:FireEvent("RAID_MEMBER_CLASS_CHANGED", l_56_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, l_56_2, l_56_0.BigFoot_b962f54280c77029bc350c2b321adc64)
    end
    l_0_0.SetClass = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_57_0)
      return l_57_0.BigFoot_25daf5581aad0afcae714dddb26e519c
    end
    l_0_0.GetParty = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_58_0, l_58_1)
      local l_58_2 = l_58_0.BigFoot_25daf5581aad0afcae714dddb26e519c
      local l_58_3 = nil
      if not l_58_1 then
        l_58_3 = 0
      end
      l_58_0.BigFoot_25daf5581aad0afcae714dddb26e519c = l_58_3
      l_58_3 = MiDKP
      l_58_3 = l_58_3.Core
      l_58_3(l_58_3, "RAID_MEMBER_PARTY_CHANGED", MiDKP.Core:GetRaid(l_58_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_58_2, l_58_0.BigFoot_25daf5581aad0afcae714dddb26e519c)
    end
    l_0_0.SetParty = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_59_0, l_59_1)
      l_59_0.BigFoot_639cc82727cceae5afc908ea9c9704f3 = nil
      local l_59_2 = nil
      if not l_59_1 then
        l_59_2 = 0
      end
      l_59_0.BigFoot_25daf5581aad0afcae714dddb26e519c = l_59_2
      l_59_2 = MiDKP
      l_59_2 = l_59_2.Util
       -- DECOMPILER ERROR: Overwrote pending register.

      l_59_0.BigFoot_088aed45c27da9d4db431a8e159a9a44 = l_59_2
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_59_2(l_59_2, "RAID_MEMBER_JOIN", MiDKP.Core:GetRaid(l_59_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_59_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584, l_59_0)
    end
    l_0_0.Join = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_60_0)
      l_60_0.BigFoot_639cc82727cceae5afc908ea9c9704f3 = MiDKP.Util:GetCurrentTime()
      l_60_0.BigFoot_25daf5581aad0afcae714dddb26e519c = 0
      MiDKP.Core:FireEvent("RAID_MEMBER_LEAVED", MiDKP.Core:GetRaid(l_60_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_60_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584, l_60_0)
    end
    l_0_0.Leave = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_61_0)
      return l_61_0.BigFoot_25daf5581aad0afcae714dddb26e519c ~= 0
    end
    l_0_0.IsInRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_62_0)
      l_62_0.BigFoot_593bd0ea37e18d7a17b89b961d822981 = true
      MiDKP.Core:FireEvent("MEMBER_ONLINE", MiDKP.Core:GetRaid(l_62_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_62_0)
    end
    l_0_0.OnLine = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_63_0)
      l_63_0.BigFoot_593bd0ea37e18d7a17b89b961d822981 = nil
      MiDKP.Core:FireEvent("MEMBER_OFFLINE", MiDKP.Core:GetRaid(l_63_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af), l_63_0)
    end
    l_0_0.OffLine = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_64_0)
      return l_64_0.BigFoot_593bd0ea37e18d7a17b89b961d822981
    end
    l_0_0.IsOnLine = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_65_0, l_65_1)
      local l_65_2 = l_65_0.BigFoot_99295537feebf0af77699930b0973c1f
      l_65_0.BigFoot_99295537feebf0af77699930b0973c1f = l_65_0.BigFoot_99295537feebf0af77699930b0973c1f + l_65_1
      MiDKP.Core:FireEvent("MEMBER_REWARD_VALUE_CHANGED", l_65_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, l_65_0, l_65_2, l_65_0.BigFoot_99295537feebf0af77699930b0973c1f)
    end
    l_0_0.AddScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_66_0)
      return l_66_0.BigFoot_99295537feebf0af77699930b0973c1f
    end
    l_0_0.GetReward = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_67_0)
      local l_67_1 = MiDKP.Core:GetRaid(l_67_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af):GetDKP()
      if l_67_1 then
        return l_67_1:GetScore(l_67_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584) + l_67_0.BigFoot_99295537feebf0af77699930b0973c1f
      else
        return l_67_0.BigFoot_99295537feebf0af77699930b0973c1f
      end
    end
    l_0_0.GetScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_68_0)
      local l_68_1 = MiDKP.Core:GetRaid(l_68_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      for l_68_5 = 1, l_68_1:GetEventCount() do
        local l_68_6 = l_68_1:GetEvent(l_68_5)
        if l_68_6:HasMember(l_68_0) then
          return true
        end
      end
      return false
    end
    l_0_0.HasEvent = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_69_0)
      local l_69_1 = MiDKP.Core:GetRaid(l_69_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      for l_69_5 = 1, l_69_1:GetItemCount() do
        local l_69_6 = l_69_1:GetItem(l_69_5)
        if l_69_6:GetLooter() == l_69_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 then
          return true
        end
      end
      return false
    end
    l_0_0.HasItem = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_70_0)
      local l_70_1 = MiDKP.Core:GetRaid(l_70_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af):GetDKP()
      if l_70_1 then
        local l_70_2, l_70_3 = l_70_1:GetScore, l_70_1
        local l_70_4 = l_70_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
        return l_70_2(l_70_3, l_70_4)
      else
        return 0
      end
    end
    l_0_0.GetHistoryScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_71_0)
      return l_71_0.BigFoot_088aed45c27da9d4db431a8e159a9a44
    end
    l_0_0.GetJoinTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Member
    l_0_1 = function(l_72_0)
      return l_72_0.BigFoot_639cc82727cceae5afc908ea9c9704f3
    end
    l_0_0.GetLeaveTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_73_0)
      return l_73_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584
    end
    l_0_0.GetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_74_0)
      return l_74_0.BigFoot_15ad1e501e228eb80be1cc7800ab967d
    end
    l_0_0.GetLink = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_75_0)
      return l_75_0.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
    end
    l_0_0.GetArgs = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_76_0)
      return l_76_0.BigFoot_20c03d41df6d325491f00a3df9858f08
    end
    l_0_0.GetScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_77_0, l_77_1, l_77_2, l_77_3, l_77_4)
      if not l_77_1 then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_ERROR_ARGS)
        return 
      end
      local l_77_5 = MiDKP.Core:GetRaid(l_77_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      if not l_77_2 or not l_77_5:GetMember(l_77_2) then
        MiDKP.Core:FireEvent("ERROR", MiDKP.Error.ITEM_LOOTER_NOT_IN_RAID)
        return 
      end
      local l_77_6 = MiDKP.Core:GetRaid(l_77_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      if not tonumber(l_77_3) or not l_77_3 then
        l_77_3 = 0
      end
      if l_77_0.BigFoot_4cf6e7d7de970d76ed602b6363820676 ~= l_77_2 then
        l_77_6:GetMember(l_77_0.BigFoot_4cf6e7d7de970d76ed602b6363820676):AddScore(l_77_0.BigFoot_20c03d41df6d325491f00a3df9858f08)
        l_77_6:GetMember(l_77_2):AddScore(-l_77_3)
      else
        l_77_6:GetMember(l_77_0.BigFoot_4cf6e7d7de970d76ed602b6363820676):AddScore(l_77_0.BigFoot_20c03d41df6d325491f00a3df9858f08 - l_77_3)
      end
      l_77_0.BigFoot_4cf6e7d7de970d76ed602b6363820676 = l_77_2
      l_77_0.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_77_3
      if l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e and not l_77_4 then
        for l_77_10,l_77_11 in ipairs(l_77_6.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          if l_77_11.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
            l_77_6:DeleteEvent(l_77_11, true)
            l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e = nil
        else
          end
        end
      elseif l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e and l_77_4 then
        for l_77_15,l_77_16 in ipairs(l_77_6.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          if l_77_16.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e then
            l_77_16:Modify(l_77_16:GetDesc(), math.floor(l_77_3 / #l_77_16:GetMembers() + 0.5), (l_77_16:GetMembers()), nil)
        else
          end
        end
      elseif not l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e and l_77_4 then
        local l_77_17 = MiDKP.Config:GetValue("AllMembersOnEvent")
        local l_77_18 = {}
        if l_77_17 then
          l_77_18 = l_77_6:GetAllMemberNames()
          do break end
        end
        local l_77_19 = MiDKP.Config:GetValue("DefaultParties")
        for l_77_23,l_77_24 in ipairs(l_77_6:GetAllMemberNames()) do
          if l_77_19[l_77_6:GetMember(l_77_24):GetParty()] then
            table.insert(l_77_18, l_77_24)
          end
        end
        l_77_19 = MiDKP
        l_77_19 = l_77_19.Util
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e = l_77_19
         -- DECOMPILER ERROR: Overwrote pending register.

        l_77_19(l_77_6, l_77_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 .. " " .. MiDKP.Locale.SPLIT_ITEM_SCORE, math.floor(l_77_3 / #l_77_18 + 0.5), l_77_18, nil, true, l_77_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e)
      end
      l_77_17 = l_77_0.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d
      if not l_77_17 then
        l_77_17 = type
        l_77_17 = l_77_17(l_77_1)
        if l_77_17 == "table" then
          l_77_17 = MiDKP
          l_77_17 = l_77_17.Util
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_77_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_77_17
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_77_0.BigFoot_15ad1e501e228eb80be1cc7800ab967d = l_77_17
          l_77_0.BigFoot_4ac22e939c7fd1fac854933eb2a943a3 = l_77_1
        end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      else
        if l_77_17 == "string" then
          l_77_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_77_1
          l_77_0.BigFoot_15ad1e501e228eb80be1cc7800ab967d = l_77_1
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_77_25, l_77_26 = l_77_17
      l_77_26 = "ITEM_MODIFIED"
      local l_77_27 = nil
      l_77_27 = l_77_6
      local l_77_28 = nil
      l_77_28 = l_77_0
      local l_77_29 = nil
      l_77_29 = l_77_1
      local l_77_30 = nil
      l_77_30 = type
      l_77_30 = l_77_30(l_77_1)
      l_77_30 = l_77_30 == "table"
      l_77_17(l_77_25, l_77_26, l_77_27, l_77_28, l_77_29, l_77_30)
    end
    l_0_0.Modify = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_78_0, l_78_1)
      local l_78_2 = l_78_0.BigFoot_20c03d41df6d325491f00a3df9858f08
      local l_78_3 = nil
      if not l_78_1 then
        l_78_3 = 0
      end
      l_78_0.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_78_3
      l_78_3 = MiDKP
      l_78_3 = l_78_3.Core
      l_78_3(l_78_3, "ITEM_SCORE_CHANGED", l_78_0, l_78_2, l_78_0.BigFoot_20c03d41df6d325491f00a3df9858f08)
    end
    l_0_0.SetScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_79_0)
      return l_79_0.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b
    end
    l_0_0.GetLootTime = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_80_0)
      return l_80_0.BigFoot_4cf6e7d7de970d76ed602b6363820676
    end
    l_0_0.GetLooter = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_81_0)
      return l_81_0.BigFoot_715bbba62fd4f6c84e70080d536eca0e
    end
    l_0_0.IsSplitScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Item
    l_0_1 = function(l_82_0)
      return l_82_0.BigFoot_fa7307fe0773c5bc7c9b34cafd8d8a1d
    end
    l_0_0.IsAutoItem = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Config
    l_0_1 = function(l_83_0, l_83_1)
      return MiDKP.ConfigData[l_83_1]
    end
    l_0_0.GetValue = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.Config
    l_0_1 = function(l_84_0, l_84_1, l_84_2)
      local l_84_3 = MiDKP.ConfigData[l_84_1]
      MiDKP.ConfigData[l_84_1] = l_84_2
      MiDKP.Core:FireEvent("CONFIG_DATA_CHANGED", l_84_1, l_84_3, l_84_2)
    end
    l_0_0.SetValue = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_85_0)
      local l_85_1 = {}
      if MiDKPData then
        for l_85_5,l_85_6 in pairs(MiDKPData.dkp) do
          table.insert(l_85_1, l_85_6.name)
        end
      end
      return l_85_1
    end
    l_0_0.GetDKPNames = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_86_0, l_86_1)
      local l_86_2 = {}
      for l_86_6,l_86_7 in ipairs(MiDKP.DKP:GetDKPNames()) do
        if not MiDKP.Config:GetValue("BanedDKP" .. l_86_7) then
          local l_86_8 = MiDKP.DKP:GetDKPByName(l_86_7)
          local l_86_9 = l_86_8:GetMember(l_86_1)
          local l_86_10 = table.insert
          local l_86_11 = l_86_2
          local l_86_12 = {}
          l_86_12.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_86_7
          l_86_12.BigFoot_20c03d41df6d325491f00a3df9858f08 = l_86_9 and l_86_9.score or 0
          l_86_10(l_86_11, l_86_12)
        end
      end
      return l_86_2
    end
    l_0_0.Query = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_87_0)
      if MiDKPData then
        return #MiDKPData.dkp
      end
      return 0
    end
    l_0_0.GetDKPCount = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_88_0, l_88_1)
      if l_88_1 and MiDKPData then
        for l_88_5,l_88_6 in pairs(MiDKPData.dkp) do
          if l_88_6.name == l_88_1 then
            local l_88_7 = setmetatable
            local l_88_8 = l_88_6
            local l_88_9 = {}
            l_88_9.__index = l_88_0
            l_88_7(l_88_8, l_88_9)
            return l_88_6
          end
        end
      end
    end
    l_0_0.GetDKPByName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_89_0, l_89_1)
      if l_89_1 and MiDKPData and MiDKPData.dkp[l_89_1] then
        local l_89_2 = setmetatable
        local l_89_3 = MiDKPData.dkp[l_89_1]
        local l_89_4 = {}
        l_89_4.__index = l_89_0
        l_89_2(l_89_3, l_89_4)
        l_89_2 = MiDKPData
        l_89_2 = l_89_2.dkp
        l_89_2 = l_89_2[l_89_1]
        return l_89_2
      end
    end
    l_0_0.GetDKPByIndex = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_90_0)
      return l_90_0.name
    end
    l_0_0.GetName = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_91_0, l_91_1)
      local l_91_2 = l_91_0:GetMember(l_91_1)
      return l_91_2 and l_91_2.score or 0
    end
    l_0_0.GetScore = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_92_0, l_92_1)
      if type(l_92_1) == "string" then
        if l_92_0.members[l_92_1] then
          local l_92_2 = l_92_0.members[l_92_1]
          l_92_2.name = l_92_1
          return l_92_2
        else
          local l_92_3 = {}
          l_92_3.name = l_92_1
          l_92_3.score = 0
          return l_92_3
        end
      else
        if type(l_92_1) == "table" then
          if l_92_0.members[l_92_1:GetName()] then
            local l_92_4 = l_92_0.members[l_92_1:GetName()]
            l_92_4.name = l_92_1:GetName()
            return l_92_4
          end
        end
      else
        local l_92_5 = {}
        l_92_5.name = l_92_1:GetName()
        l_92_5.score = 0
        return l_92_5
      end
    end
    l_0_0.GetMember = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_93_0)
      local l_93_1 = {}
      for l_93_5 in pairs(l_93_0.members) do
        table.insert(l_93_1, l_93_5)
      end
      return l_93_1
    end
    l_0_0.GetAllMemberNames = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.DKP
    l_0_1 = function(l_94_0, l_94_1)
      local l_94_2 = 1
      local l_94_3 = {}
      l_94_3.dkp = {}
      MiDKPData = l_94_3
      l_94_3 = string
      l_94_3 = l_94_3.gmatch
      l_94_3 = l_94_3(l_94_1, "dkp:(.-):=>([^\n]*)")
      for l_94_7,i_2 in l_94_3 do
        MiDKPData.dkp[l_94_2] = {}
        MiDKPData.dkp[l_94_2].name = l_94_6
        MiDKPData.dkp[l_94_2].members = {}
        local l_94_8 = MiDKPData.dkp[l_94_2].members
        for l_94_12,l_94_13,l_94_14 in string.gmatch(l_94_7, "%[:([^:]+):|:([^:]+):|:(%-?[%d%.]+):%]") do
          local l_94_15 = {}
          l_94_15.class = l_94_13
          l_94_15.score = tonumber(l_94_14)
          l_94_8[l_94_12] = l_94_15
        end
        l_94_2 = l_94_2 + 1
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    l_0_0.ParseDKPData = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_95_0)
      local l_95_1 = {}
      l_95_1.__index = MiDKP.Raid
      local l_95_2 = {}
      l_95_2.__index = MiDKP.Event
      local l_95_3 = {}
      l_95_3.__index = MiDKP.Member
      local l_95_4 = {}
      l_95_4.__index = MiDKP.Item
      for l_95_8,l_95_9 in pairs(MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a) do
        setmetatable(l_95_9, l_95_1)
        for l_95_13,l_95_14 in pairs(l_95_9.BigFoot_f9542af0fc240db769f6a4369804f562) do
          setmetatable(l_95_14, l_95_3)
        end
        for l_95_18,l_95_19 in pairs(l_95_9.BigFoot_688fec9138c1fc6d0dd768683db73267) do
          setmetatable(l_95_19, l_95_2)
        end
        for l_95_23,l_95_24 in pairs(l_95_9.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
          setmetatable(l_95_24, l_95_4)
        end
        if l_95_9.BigFoot_34f060cd141b38ec35a51d6a3ab08d4f and not l_95_9.BigFoot_9324ffd8707783d1899c5d020ebb2b0d then
          MiDKP.Core.BigFoot_e5691af7955e04be12cdbef48c3ca49b = l_95_9
        end
      end
    end
    l_0_0.OnCustomDataLoaded = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_96_0)
      MiDKP.Core:UpdateCurrentRaid()
    end
    l_0_0.OnLoginGame = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_97_0)
      MiDKP.Core:UpdateCurrentRaid()
    end
    l_0_0.OnJoinRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_98_0)
    end
    l_0_0.OnLeaveRaid = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_99_0, l_99_1, l_99_2, l_99_3)
      local l_99_4 = MiDKP.Core:GetCurrentRaid()
      if l_99_4 then
        local l_99_5 = l_99_4:GetMember(l_99_1)
        if not l_99_5 then
          l_99_4:AddMember(l_99_1, l_99_2, l_99_3, true)
        end
      else
        l_99_5:SetClass(l_99_2)
        l_99_5:Join(l_99_3)
      end
    end
    l_0_0.OnMemberJoin = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_100_0, l_100_1)
      local l_100_2 = MiDKP.Core:GetCurrentRaid()
      if l_100_2 then
        local l_100_3 = l_100_2:GetMember(l_100_1)
      end
      if l_100_3 then
        l_100_3:Leave()
      end
    end
    l_0_0.OnMemberLeave = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_101_0, l_101_1)
      local l_101_2 = MiDKP.Core:GetCurrentRaid()
      if l_101_2 then
        local l_101_3 = l_101_2:GetMember(l_101_1)
      end
      if l_101_3 then
        l_101_3:OnLine()
      end
    end
    l_0_0.OnMemberOnLine = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_102_0, l_102_1)
      local l_102_2 = MiDKP.Core:GetCurrentRaid()
      if l_102_2 then
        local l_102_3 = l_102_2:GetMember(l_102_1)
      end
      if l_102_3 then
        l_102_3:OffLine()
      end
    end
    l_0_0.OnMemberOffLine = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_103_0, l_103_1, l_103_2)
      local l_103_3 = MiDKP.Core:GetCurrentRaid()
      if l_103_3 then
        local l_103_4 = l_103_3:GetMember(l_103_1)
      end
      if l_103_4 then
        l_103_4:SetParty(l_103_2)
      end
    end
    l_0_0.OnMemberPartyChanged = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_104_0, l_104_1, l_104_2)
      local l_104_3 = MiDKP.Core:GetCurrentRaid()
      if l_104_3 then
        local l_104_4 = MiDKP.Config:GetValue("AllMembersOnEvent")
        local l_104_5 = MiDKP.Config:GetValue("DefaultParties")
        local l_104_6 = MiDKP.Config:GetValue("OffLineMember")
        local l_104_7 = {}
        if l_104_4 then
          l_104_7 = l_104_3:GetAllMemberNames()
          do break end
        end
        for l_104_11,l_104_12 in ipairs(l_104_3:GetAllMemberNames()) do
          local l_104_13 = l_104_3:GetMember(l_104_12)
          if l_104_13 and l_104_5[l_104_13:GetParty()] and (l_104_6 or l_104_13:IsOnLine()) then
            table.insert(l_104_7, l_104_13:GetName())
          end
        end
        l_104_3:CreateEvent(l_104_1, 0, l_104_7, true, true)
      end
    end
    l_0_0.OnBossKilled = l_0_1
    l_0_0 = MiDKP
    l_0_0 = l_0_0.EventHandler
    l_0_1 = function(l_105_0, l_105_1, l_105_2, l_105_3)
      local l_105_4 = MiDKP.Util:GetItemName(l_105_2)
      local l_105_5 = MiDKP.Config:GetValue("IgnoreItems")
      for l_105_9,l_105_10 in ipairs(l_105_5) do
        if l_105_4 == l_105_10 then
          return 
        end
      end
      local l_105_11, l_105_17 = MiDKP.Core:GetCurrentRaid()
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_105_11 then
        l_105_1 = l_105_17
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_105_1 and MiDKP.Config:GetValue("RecordItemLevel") <= l_105_17 then
        local l_105_12, l_105_13, l_105_18, l_105_19 = l_105_11
        l_105_13 = l_105_2
        local l_105_14, l_105_20 = nil
        l_105_18, l_105_19 = l_105_1:GetName, l_105_1
        l_105_18 = l_105_18(l_105_19)
        local l_105_15, l_105_21 = nil
        do
          local l_105_16, l_105_22 = nil
          if not l_105_3 then
            l_105_19 = 0
          end
          l_105_14 = MiDKP
          l_105_14 = l_105_14.Config
          l_105_14, l_105_20 = l_105_14:GetValue, l_105_14
          l_105_15 = "SplitItemScore"
          l_105_14 = l_105_14(l_105_20, l_105_15)
          l_105_20 = true
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_105_17(l_105_12, l_105_13, l_105_18, l_105_19, l_105_14, l_105_20)
      end
    end
    l_0_0.OnLootItem = l_0_1
    l_0_1 = {[0] = "����", [1] = "����", [2] = "��", [3] = "���", [4] = "����", [5] = "����", [8] = "�ؽ�", [6] = "�嶾", [7] = "����", [9] = "ؤ��", [10] = "����"}
    l_0_1 = {["����"] = 0, ["���"] = 3, ["��"] = 2, ["����"] = 4, ["����"] = 5, ["����"] = 1, ["�ؽ�"] = 8, ["�嶾"] = 6, ["����"] = 7, ["ؤ��"] = 9, ["����"] = 10}
    l_0_1 = {jh = "����", sl = "����", wh = "��", tc = "���", cy = "����", qx = "����", cj = "�ؽ�", wd = "�嶾", tm = "����", jb = "ؤ��", mj = "����"}
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetCurrentTime = function(l_106_0)
      local l_106_1 = GetCurrentTime
      return l_106_1()
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.TimeToDate = function(l_107_0, l_107_1)
      local l_107_2 = TimeToDate
      local l_107_3 = l_107_1
      return l_107_2(l_107_3)
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetItemName = function(l_108_0, l_108_1)
      if type(l_108_1) == "string" then
        return l_108_1
      end
      do return end
      if type(l_108_1) == "table" then
        if not l_108_1.BookID or l_108_1.BookID == 0 then
          local l_108_2 = GetItemInfo(l_108_1.TabType, l_108_1.TabIndex)
        end
        if l_108_2 then
          return l_108_2.szName
        end
      else
        local l_108_3, l_108_4 = GlobelRecipeID2BookID(l_108_1.BookID)
        local l_108_5 = Table_GetSegmentName
        local l_108_6 = l_108_3
        local l_108_7 = l_108_4
        return l_108_5(l_108_6, l_108_7)
      end
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetItemLink = function(l_109_0, l_109_1)
      -- upvalues: l_0_1
      if type(l_109_1) == "string" then
        return l_109_1
      end
      do return end
      if type(l_109_1) == "table" then
        local l_109_2 = GetItemInfo(l_109_1.TabType, l_109_1.TabIndex)
        local l_109_3 = 0
        if l_109_2.GetRequireAttrib and l_109_2.GetRequireAttrib() then
          for l_109_7,l_109_8 in ipairs(l_109_2.GetRequireAttrib()) do
            if l_109_8.nID == 5 then
              l_109_3 = l_109_8.nValue
            end
            do break end
          end
        end
        local l_109_9, l_109_12 = nil
        l_109_12 = l_109_1.BookID
        if l_109_12 then
          l_109_12 = l_109_1.BookID
        if l_109_12 == 0 then
          end
        end
        l_109_9 = l_109_2.szName
        do return end
        l_109_12 = GlobelRecipeID2BookID
        l_109_12 = l_109_12(l_109_1.BookID)
        do
          local l_109_10, l_109_11 = nil
          l_109_11 = Table_GetSegmentName
          l_109_11 = l_109_11(l_109_12, l_109_10)
          l_109_9 = l_109_11
        end
        l_109_12 = string
        l_109_12 = l_109_12.format
        local l_109_13 = nil
        l_109_13 = "$cff%s$Hitem:%d,%d,%d:0:0:0:0:0:0:0:%d$h[%s]$h$r"
        local l_109_14 = nil
        l_109_14 = l_0_1
        l_109_14 = l_109_14[l_109_2.nQuality]
        local l_109_15 = nil
        l_109_15 = l_109_1.BookID
        if not l_109_15 then
          l_109_15 = 0
          local l_109_16 = nil
        end
        local l_109_17 = l_109_1.TabType
        local l_109_18 = l_109_1.TabIndex
        local l_109_19 = l_109_3
        local l_109_20 = l_109_9
        return l_109_12(l_109_13, l_109_14, l_109_15, l_109_17, l_109_18, l_109_19, l_109_20)
      end
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetItemIcon = function(l_110_0, l_110_1)
      if l_110_1 then
        local l_110_2 = GetItemInfo(l_110_1.TabType, l_110_1.TabIndex)
      end
      if l_110_2 then
        local l_110_3 = Table_GetItemIconID
        local l_110_4 = l_110_2.nUiId
        return l_110_3(l_110_4)
      end
      return 0
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetItemQuality = function(l_111_0, l_111_1)
      if l_111_1 then
        local l_111_2 = GetItemInfo(l_111_1.TabType, l_111_1.TabIndex)
      end
      if l_111_2 then
        return l_111_2.nQuality
      end
      return -1
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.SaveConfigData = function(l_112_0)
      RegisterCustomData("Account/MiDKP.ConfigData")
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.SaveRaidData = function(l_113_0)
      RegisterCustomData("Account/MiDKP.Core.BigFoot_d03e84492323c4c8c9b7658c96ec6b7a")
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetItem = function(l_114_0)
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetClientPlayer = function(l_115_0)
      return GetClientPlayer().szName
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetRaidMember = function(l_116_0, l_116_1)
      -- upvalues: l_0_0
      l_116_1 = l_116_1 - 1
      local l_116_2 = GetClientTeam()
      local l_116_3 = (l_116_1) % 5
      local l_116_4 = math.floor((l_116_1) / 5)
      local l_116_5 = l_116_2.GetGroupInfo(l_116_4)
      if l_116_5.MemberList then
        local l_116_6 = l_116_5.MemberList[l_116_3 + 1]
      end
      if l_116_6 then
        local l_116_7 = l_116_2.GetMemberInfo(l_116_6)
      end
      if l_116_7 then
        return l_116_7.szName, l_0_0[1][l_116_7.dwForceID], l_116_4 + 1, l_116_7.bIsOnLine
      end
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.IsInRaid = function(l_117_0)
      return GetClientTeam().nGroupNum > 1
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.IsMemberInRaid = function(l_118_0, l_118_1)
      local l_118_2 = GetClientTeam()
      for l_118_6 = 0, 4 do
        local l_118_7 = l_118_2.GetGroupInfo(l_118_6)
        if l_118_7.MemberList then
          for l_118_11,l_118_12 in ipairs(l_118_7.MemberList) do
            local l_118_13 = l_118_2.GetMemberInfo(l_118_12)
            if l_118_13 and l_118_13.szName == l_118_1 then
              return l_118_13
            end
          end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetMaxRaidSize = function(l_119_0)
      return 25
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Util
    l_0_2.GetPartySize = function(l_120_0)
      return 5
    end
    l_0_2 = MiDKP
    l_0_2 = l_0_2.Core
    l_0_2(l_0_2)
    local l_0_3 = {}
    local l_0_4 = {}
    local l_0_5 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_0_4["ݶ��ʥ��"], l_0_5 = l_0_5, {"ĵ��", "ʥ�ߡ�����˫", "���÷", "�ձ��¹�", "ɳ����", "Ľ�ݷ���׿����", "����֮ŭ", "����֮��", "��Գ֮Ӱ", "̰��֮��"}
    l_0_5 = RegisterEvent
    l_0_5("CUSTOM_DATA_LOADED", function()
      if arg0 == "Account" then
        MiDKP.EventHandler:OnCustomDataLoaded()
        MiDKP.UI.UpdateRaidList()
        MiDKP.UI.UpdateOptions()
      end
    end)
    l_0_5 = MiDKP
    local l_0_6 = {}
    l_0_6.INI_FILE = "Interface\\BF_MiDKP\\MiDKP.ini"
    l_0_6.RAID_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Raid.ini"
    l_0_6.MEMBER_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Member.ini"
    l_0_6.IGNORE_ITEMS_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_IgnoreItems.ini"
    l_0_6.EVENT_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Event.ini"
    l_0_6.ITEM_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Item.ini"
    l_0_6.MSGCONFIG_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_MsgConfig.ini"
    l_0_6.NOTIFY_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Notify.ini"
    l_0_6.EXPORT_INI_FILE = "Interface\\BF_MiDKP\\MiDKP_Export.ini"
    l_0_6.BigFoot_bc79420cec13ad6e07e69aae1f0211e9 = {}
    l_0_6.BigFoot_09c56c132940994583d4f06226c6b4b0 = {}
    l_0_5.UI = l_0_6
    l_0_5 = MiDKP
    l_0_5 = l_0_5.UI
    l_0_6 = function(l_122_0, l_122_1)
      if l_122_0 == "error" then
        OutputMessage("MSG_SYS", "<text>text=\"<MiDKP> \" font=166</text><text>text=\"" .. l_122_1 .. "\n\" font=166 r=255 g=255 b=255</text>", true)
      elseif l_122_0 == "info" then
        OutputMessage("MSG_SYS", "<text>text=\"<MiDKP> \" font=165 r=0 g=196 b=196</text><text>text=\"" .. l_122_1 .. "\n\" font=165 r=255 g=255 b=255</text>", true)
      end
    end
    l_0_5.Print = l_0_6
    l_0_5 = function(l_123_0, l_123_1)
      if #l_123_0 <= l_123_1 then
        return l_123_0
      end
      do return end
      local l_123_2 = string.sub(l_123_0, 0, l_123_1 - 2)
      l_123_2 = l_123_2 .. ".."
      return l_123_2
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnFrameCreate = function()
      this:Lookup("", ""):Lookup("Text_Version"):SetText(MiDKP.VERSION)
      local l_124_0 = this:Lookup("PageSet_Tabs")
      for l_124_4 = 2, 5 do
        local l_124_5 = l_124_0:Lookup("Page_Option/CheckBox_RecordLevel_" .. l_124_4):Lookup("", ""):Lookup("Text_RecordLevel_" .. l_124_4)
        l_124_5:SetFontColor(GetItemFontColorByQuality(l_124_4))
      end
      MiDKP.UI.UpdateRaidList()
      MiDKP.UI.UpdateMemberList()
      MiDKP.UI.UpdateEventList()
      MiDKP.UI.UpdateItemList()
      MiDKP.UI.UpdateDKPList()
      this:RegisterEvent("CUSTOM_DATA_LOADED")
      this:RegisterEvent("PARTY_ADD_MEMBER")
      this:RegisterEvent("PARTY_DELETE_MEMBER")
      this:RegisterEvent("PARTY_UPDATE_BASE_INFO")
      this:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
      this:RegisterEvent("TEAM_CHANGE_MEMBER_GROUP")
      this:RegisterEvent("LOOT_ITEM")
      this:RegisterEvent("SYS_MSG")
      this:RegisterEvent("NPC_ENTER_SCENE")
      this:RegisterEvent("PLAYER_ENTER_SCENE")
      this:RegisterEvent("PLAYER_TALK")
      this:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
      this:RegisterEvent("PARTY_LEVEL_UP_RAID")
      this:RegisterEvent("SYNC_ROLE_DATA_END")
      this:RegisterEvent("INTERACTION_REQUEST_RESULT")
      this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
      MiDKP.Core:RegisterEvent("RAID_CREATED", MiDKP.UI.OnRaidCreated)
      MiDKP.Core:RegisterEvent("RAID_MODIFIED", MiDKP.UI.OnRaidChaged)
      MiDKP.Core:RegisterEvent("RAID_DELETED", MiDKP.UI.OnRaidDeleted)
      MiDKP.Core:RegisterEvent("RAID_STARTED", MiDKP.UI.OnRaidStarted)
      MiDKP.Core:RegisterEvent("RAID_FINISHED", MiDKP.UI.OnRaidFinished)
      MiDKP.Core:RegisterEvent("RAID_MEMBER_ADDED", MiDKP.UI.OnMemberAdded)
      MiDKP.Core:RegisterEvent("RAID_MEMBER_JOIN", MiDKP.UI.UpdateMemberInfo)
      MiDKP.Core:RegisterEvent("RAID_MEMBER_LEAVED", MiDKP.UI.UpdateMemberInfo)
      MiDKP.Core:RegisterEvent("RAID_MEMBER_MODIFIED", MiDKP.UI.UpdateMemberInfo)
      MiDKP.Core:RegisterEvent("MEMBER_DELETED", MiDKP.UI.OnMemberDeleted)
      MiDKP.Core:RegisterEvent("EVENT_CREATED", MiDKP.UI.OnEventCreated)
      MiDKP.Core:RegisterEvent("EVENT_DELETED", MiDKP.UI.OnEventDeleted)
      MiDKP.Core:RegisterEvent("EVENT_MODIFIED", MiDKP.UI.OnEventModified)
      MiDKP.Core:RegisterEvent("ITEM_CREATED", MiDKP.UI.OnItemCreated)
      MiDKP.Core:RegisterEvent("ITEM_DELETED", MiDKP.UI.OnItemDeleted)
      MiDKP.Core:RegisterEvent("ITEM_MODIFIED", MiDKP.UI.OnItemModified)
      MiDKP.Core:RegisterEvent("AUTO_EVENT_CREATED", MiDKP.UI.OnAutoEventCreated)
      MiDKP.Core:RegisterEvent("AUTO_ITEM_CREATED", MiDKP.UI.OnAutoItemCreated)
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidCreated = function(l_125_0)
      local l_125_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      l_125_1:InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_RaidInfo")
      local l_125_2 = l_125_1:Lookup(0)
      MiDKP.UI.RaidInfo.UpdateInfo(l_125_2, l_125_0)
      MiDKP.UI.RaidInfo.Select(l_125_2)
      l_125_1:FormatAllItemPos()
      l_125_1:SetSizeByAllItemSize()
      MiDKP.UI.UpdateRaidScrollBar()
      MiDKP.UI.Print("info", string.format("�Ŷӻ<%s>�����ɹ���", l_125_0:GetName()))
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidChaged = function(l_126_0)
      -- upvalues: l_0_5
      local l_126_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_126_5 = 0, l_126_1:GetItemCount() - 1 do
        local l_126_6 = l_126_1:Lookup(l_126_5)
        if l_126_0 == l_126_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
          l_126_6:Lookup("Text_RaidInfo_Name"):SetText(l_0_5(l_126_0:GetName(), 28))
          l_126_6:Lookup("Text_RaidInfo_DKP"):SetText(l_0_5(l_126_0:GetDKP() and l_126_0:GetDKP():GetName() or "", 20))
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidDeleted = function(l_127_0)
      MiDKP.UI.RaidInfo.Select(nil)
      local l_127_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_127_5 = 0, l_127_1:GetItemCount() - 1 do
        do
          local l_127_6 = l_127_1:Lookup(l_127_5)
          if l_127_0 == l_127_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
            if l_127_6 == MiDKP.UI.GetActiveRaid() then
              MiDKP.UI.ActiveRaid(nil)
            end
            l_127_1:RemoveItem(l_127_6)
          end
          do break end
        end
      end
      l_127_1:FormatAllItemPos()
      l_127_1:SetSizeByAllItemSize()
      MiDKP.UI.UpdateRaidScrollBar()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidActived = function()
      MiDKP.UI.UpdateMemberList()
      MiDKP.UI.UpdateEventList()
      MiDKP.UI.UpdateItemList()
      if not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
        MiDKP.UI.UpdateDKPList()
      end
      local l_128_0 = MiDKP.UI.GetActiveRaid()
      if l_128_0 then
        local l_128_1 = l_128_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        MiDKP.UI.Print("info", string.format("��ǰ����Ϊ<%s>", l_128_1:GetName()))
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidStarted = function(l_129_0)
      local l_129_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_129_5 = 0, l_129_1:GetItemCount() - 1 do
        do
          local l_129_6 = l_129_1:Lookup(l_129_5)
          if l_129_0 == l_129_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
            MiDKP.UI.ActiveRaid(l_129_6)
          end
          do break end
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnRaidFinished = function(l_130_0)
      local l_130_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_130_5 = 0, l_130_1:GetItemCount() - 1 do
        do
          local l_130_6 = l_130_1:Lookup(l_130_5)
          if l_130_0 == l_130_6.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
            MiDKP.UI.RaidInfo.UpdateInfo(l_130_6, l_130_0)
            MiDKP.UI.UpdateMemberList()
            MiDKP.UI.UpdateDKPList()
          end
          do break end
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnMemberAdded = function(l_131_0, l_131_1, l_131_2, l_131_3)
      local l_131_4 = Station.Lookup("Normal/MiDKP")
      local l_131_5 = l_131_4:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_131_9 = 0, l_131_5:GetItemCount() - 1 do
        local l_131_10 = l_131_5:Lookup(l_131_9)
        if l_131_0 == l_131_10.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
          MiDKP.UI.RaidInfo.UpdateInfo(l_131_10, l_131_0)
          if MiDKP.UI.IsActiveRaid(l_131_10) then
            local l_131_11 = l_131_4:Lookup("PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
            l_131_11:InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_MemberInfo")
            local l_131_12 = l_131_11:Lookup(0)
            MiDKP.UI.MemberInfo.UpdateInfo(l_131_12, l_131_3)
            l_131_11:SetSizeByAllItemSize()
            l_131_11:FormatAllItemPos()
            MiDKP.UI.UpdateMemberScrollBar()
            MiDKP.UI.UpdateDKPList()
          end
          do break end
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.UpdateMemberInfo = function(l_132_0, l_132_1, l_132_2)
      local l_132_3 = Station.Lookup("Normal/MiDKP")
      local l_132_4 = l_132_3:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_132_8 = 0, l_132_4:GetItemCount() - 1 do
        local l_132_9 = l_132_4:Lookup(l_132_8)
        if l_132_0 == l_132_9.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af and MiDKP.UI.IsActiveRaid(l_132_9) then
          MiDKP.UI.MemberInfo.Select(nil)
          local l_132_10 = l_132_3:Lookup("PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
          for l_132_14 = 0, l_132_10:GetItemCount() - 1 do
            do
              local l_132_15 = l_132_10:Lookup(l_132_14)
              if l_132_15.BigFoot_1210e713fbe7372fde7a5518a1f280ec == l_132_2 then
                MiDKP.UI.MemberInfo.UpdateInfo(l_132_15, l_132_2)
              end
              do break end
            end
          end
          l_132_10:SetSizeByAllItemSize()
          l_132_10:FormatAllItemPos()
          do
            local l_132_16 = l_132_3:Lookup("PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
            for l_132_20 = 0, l_132_16:GetItemCount() - 1 do
              local l_132_21 = l_132_16:Lookup(l_132_20)
              if l_132_21.BigFoot_f8c6f4951c524600d5984ab47a0d8393 == l_132_2 then
                MiDKP.UI.DKPInfo.UpdateInfo(l_132_21, l_132_2)
              end
              do break end
            end
          end
        end
        do break end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnMemberDeleted = function(l_133_0, l_133_1, l_133_2)
      local l_133_3 = Station.Lookup("Normal/MiDKP")
      local l_133_4 = l_133_3:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      for l_133_8 = 0, l_133_4:GetItemCount() - 1 do
        local l_133_9 = l_133_4:Lookup(l_133_8)
        if l_133_0 == l_133_9.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
          MiDKP.UI.RaidInfo.UpdateInfo(l_133_9, l_133_0)
          if MiDKP.UI.IsActiveRaid(l_133_9) then
            MiDKP.UI.MemberInfo.Select(nil)
            local l_133_10 = l_133_3:Lookup("PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
            for l_133_14 = 0, l_133_10:GetItemCount() - 1 do
              do
                local l_133_15 = l_133_10:Lookup(l_133_14)
                if l_133_15.BigFoot_1210e713fbe7372fde7a5518a1f280ec == l_133_2 then
                  l_133_10:RemoveItem(l_133_15)
                end
                do break end
              end
            end
            l_133_10:SetSizeByAllItemSize()
            l_133_10:FormatAllItemPos()
            MiDKP.UI.UpdateMemberScrollBar()
            MiDKP.UI.UpdateDKPList()
          end
          do break end
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.OnMemberClassFilterChaged = function(l_134_0, l_134_1)
      if l_134_0 == 0 then
        local l_134_2 = GetPopupMenu()
        if l_134_2 then
          local l_134_3 = l_134_2:Lookup("", ""):Lookup(0):Lookup(1)
          for l_134_7 = 1, 6 do
            local l_134_8 = l_134_3:Lookup(l_134_7)
            if l_134_1 then
              l_134_8:Lookup("Image_Check"):Show()
            else
              l_134_8:Lookup("Image_Check"):Hide()
            end
            MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[l_134_7] = not l_134_1
          end
        end
      else
        MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[l_134_0] = not l_134_1
        if MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[1] or MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[2] or MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[3] or MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[4] or MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[5] or MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[6] then
          local l_134_9 = GetPopupMenu()
        end
        if l_134_9 then
          local l_134_10 = l_134_9:Lookup("", ""):Lookup(0):Lookup(1)
          l_134_10:Lookup(0):Lookup("Image_Check"):Hide()
        end
      else
        if not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[1] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[2] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[3] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[4] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[5] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[6] then
          local l_134_11 = GetPopupMenu()
        end
      end
      if l_134_11 then
        local l_134_12 = l_134_11:Lookup("", ""):Lookup(0):Lookup(1)
        l_134_12:Lookup(0):Lookup("Image_Check"):Show()
      end
      MiDKP.UI.UpdateMemberList()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    local l_0_7 = "OnEventCreated"
    l_0_6[l_0_7] = function(l_135_0, l_135_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_135_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_135_2 == l_135_0 then
        local l_135_3 = nil
        Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList"):InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_EventInfo")
        local l_135_4 = nil
        MiDKP.UI.EventInfo.UpdateInfo(Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList"):Lookup(0), l_135_1)
        l_135_4:FormatAllItemPos()
        l_135_4:SetSizeByAllItemSize()
        MiDKP.UI.UpdateMemberScore()
        MiDKP.UI.UpdateDKPScore()
        MiDKP.UI.UpdateEventScrollBar()
        local l_135_5 = nil
        MiDKP.UI.Print("info", string.format("�������¼�<%s>, ʱ��Ϊ%04d.%02d.%02d %02d:%02d��", l_135_1:GetDesc(), TimeToDate(l_135_1:GetCreationTime()).year, TimeToDate(l_135_1:GetCreationTime()).month, TimeToDate(l_135_1:GetCreationTime()).day, TimeToDate(l_135_1:GetCreationTime()).hour, TimeToDate(l_135_1:GetCreationTime()).minute))
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnEventDeleted"
    l_0_6[l_0_7] = function(l_136_0, l_136_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_136_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_136_2 == l_136_0 then
        local l_136_3 = nil
        for l_136_7 = 0, Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList"):GetItemCount() - 1 do
          local l_136_4 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          do
            if l_136_4:Lookup(R7_PC34).BigFoot_d0708241b607c9a9dd1953c812fadfb7 == l_136_1 then
              MiDKP.UI.EventInfo.Select(nil)
              l_136_4:RemoveItem(l_136_4:Lookup(R7_PC34))
              l_136_4:FormatAllItemPos()
              l_136_4:SetSizeByAllItemSize()
              MiDKP.UI.UpdateEventScrollBar()
            end
            do break end
          end
        end
        MiDKP.UI.UpdateMemberScore()
        MiDKP.UI.UpdateDKPScore()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnEventModified"
    l_0_6[l_0_7] = function(l_137_0, l_137_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_137_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_137_2 == l_137_0 then
        local l_137_3 = nil
        for l_137_7 = 0, Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList"):GetItemCount() - 1 do
          local l_137_4 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          do
            if l_137_4:Lookup(R7_PC34).BigFoot_d0708241b607c9a9dd1953c812fadfb7 == l_137_1 then
              MiDKP.UI.EventInfo.UpdateInfo(l_137_4:Lookup(R7_PC34), l_137_1)
            end
            do break end
          end
        end
        MiDKP.UI.UpdateMemberScore()
        MiDKP.UI.UpdateDKPScore()
        MiDKP.UI.Print("info", string.format("�¼�<%s>�޸ĳɹ���", l_137_1:GetDesc()))
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemCreated"
    l_0_6[l_0_7] = function(l_138_0, l_138_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_138_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_138_2 == l_138_0 then
        local l_138_3 = nil
        Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList"):InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_ItemInfo")
        local l_138_4 = nil
        MiDKP.UI.ItemInfo.UpdateInfo(Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList"):Lookup(0), l_138_1)
        l_138_4:FormatAllItemPos()
        l_138_4:SetSizeByAllItemSize()
        MiDKP.UI.UpdateMemberScore()
        MiDKP.UI.UpdateDKPScore()
        MiDKP.UI.UpdateItemScrollBar()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemDeleted"
    l_0_6[l_0_7] = function(l_139_0, l_139_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_139_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_139_2 == l_139_0 then
        local l_139_3 = nil
        for l_139_7 = 0, Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList"):GetItemCount() - 1 do
          local l_139_4 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          do
            if l_139_4:Lookup(R7_PC34).BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_139_1 then
              MiDKP.UI.ItemInfo.Select(nil)
              l_139_4:RemoveItem(l_139_4:Lookup(R7_PC34))
              l_139_4:FormatAllItemPos()
              l_139_4:SetSizeByAllItemSize()
              MiDKP.UI.UpdateItemScrollBar()
            end
            do break end
          end
        end
        MiDKP.UI.UpdateMemberScore()
        MiDKP.UI.UpdateDKPScore()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemModified"
    l_0_6[l_0_7] = function(l_140_0, l_140_1)
      if MiDKP.UI.GetActiveRaid() then
        local l_140_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_140_2 == l_140_0 then
        local l_140_3 = nil
        for l_140_7 = 0, Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList"):GetItemCount() - 1 do
          local l_140_4 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_140_4:Lookup(R7_PC34).BigFoot_2e00ffac12aadb3a1fd865993ec505b9 == l_140_1 then
            MiDKP.UI.ItemInfo.UpdateInfo(l_140_4:Lookup(R7_PC34), l_140_1)
            MiDKP.UI.UpdateMemberScore()
            MiDKP.UI.UpdateDKPScore()
          end
          do break end
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnAutoEventCreated"
    l_0_6[l_0_7] = function(l_141_0, l_141_1)
      local l_141_2 = MiDKP.Config:GetValue("ActionOnEventLevel")
      if l_141_2 == 2 then
        MiDKP.UI.Notify.CreateEventIcon(l_141_0, l_141_1)
      elseif l_141_2 == 3 then
        MiDKP.UI.Event.OpenEventPanel(l_141_0, l_141_1)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnAutoItemCreated"
    l_0_6[l_0_7] = function(l_142_0, l_142_1)
      local l_142_2 = MiDKP.Config:GetValue("ActionOnEventLevel")
      if l_142_2 == 2 then
        MiDKP.UI.Notify.CreateItemIcon(l_142_0, l_142_1)
      elseif l_142_2 == 3 then
        MiDKP.UI.Item.OpenItemPanel(l_142_0, l_142_1)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnDKPClassFilterChanged"
    l_0_6[l_0_7] = function(l_143_0, l_143_1)
      if l_143_0 == 0 then
        local l_143_2 = GetPopupMenu()
        if l_143_2 then
          local l_143_3 = l_143_2:Lookup("", ""):Lookup(0):Lookup(1)
          for l_143_7 = 1, 5 do
            local l_143_8 = l_143_3:Lookup(l_143_7)
            if l_143_1 then
              l_143_8:Lookup("Image_Check"):Show()
            else
              l_143_8:Lookup("Image_Check"):Hide()
            end
            MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[l_143_7] = not l_143_1
          end
        end
      else
        MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[l_143_0] = not l_143_1
        if MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[1] or MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[2] or MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[3] or MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[4] or MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[5] then
          local l_143_9 = GetPopupMenu()
        end
        if l_143_9 then
          local l_143_10 = l_143_9:Lookup("", ""):Lookup(0):Lookup(1)
          l_143_10:Lookup(0):Lookup("Image_Check"):Hide()
        end
      else
        if not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[1] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[2] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[3] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[4] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[5] then
          local l_143_11 = GetPopupMenu()
        end
      end
      if l_143_11 then
        local l_143_12 = l_143_11:Lookup("", ""):Lookup(0):Lookup(1)
        l_143_12:Lookup(0):Lookup("Image_Check"):Show()
      end
      MiDKP.UI.UpdateDKPList()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnDKPSystemChanged"
    l_0_6[l_0_7] = function(l_144_0)
      MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 = l_144_0
      MiDKP.UI.UpdateDKPList()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateRaidList"
    l_0_6[l_0_7] = function()
      local l_145_0 = Station.Lookup("Normal/MiDKP")
      local l_145_1 = MiDKP.Core:GetAllRaidNames()
      local l_145_2 = {}
      for l_145_6,l_145_7 in ipairs(l_145_1) do
        table.insert(l_145_2, MiDKP.Core:GetRaid(l_145_7))
      end
      table.sort(l_145_2, function(l_146_0, l_146_1)
        if not l_146_0 or not l_146_1 then
          return false
        end
        return l_146_1:GetCreationTime() < l_146_0:GetCreationTime()
      end)
      MiDKP.UI.RaidInfo.Select(nil)
      local l_145_8, l_145_15 = l_145_0:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      l_145_15(l_145_8)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      for l_145_12,l_145_13 in l_145_15 do
        local l_145_13 = nil
        l_145_13(l_145_8, MiDKP.UI.INI_FILE, "Handle_RaidInfo")
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_145_14 = nil
        l_145_14 = MiDKP
        l_145_14 = l_145_14.UI
        l_145_14 = l_145_14.RaidInfo
        l_145_14 = l_145_14.UpdateInfo
        l_145_14(l_145_13, l_145_12)
        l_145_14 = MiDKP
        l_145_14 = l_145_14.Core
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_145_14 == l_145_12 then
          l_145_14(l_145_13)
        end
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      l_145_15(l_145_8)
      l_145_8:SetSizeByAllItemSize()
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      MiDKP.UI.UpdateRaidScrollBar()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateMemberList"
    l_0_6[l_0_7] = function()
      if MiDKP.UI.GetActiveRaid() then
        local l_146_0 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
      local l_146_1 = nil
      MiDKP.UI.MemberInfo.Select(nil)
      Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList"):Clear()
      if l_146_1 then
        local l_146_2 = nil
        local l_146_3 = l_146_1:GetAllMemberNames()
        local l_146_4 = {}
        for l_146_8,l_146_9 in ipairs(l_146_3) do
          local l_146_5 = {["����"] = 1, ["��"] = 2, ["���"] = 3, ["����"] = 4, ["����"] = 5, ["�ؽ�"] = 6, ["�嶾"] = 7}
           -- DECOMPILER ERROR: Confused about usage of registers!

          if not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[l_146_5[l_146_1:GetMember(R9_PC51):GetClass()]] then
            table.insert(l_146_4, l_146_1:GetMember(R9_PC51))
          end
        end
        if not MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 then
          table.sort(l_146_4, MiDKP.UI.MemberSortByNameAsc)
        end
        for l_146_14,l_146_15 in ipairs(l_146_4) do
          local l_146_11 = nil
          l_146_2:AppendItemFromIni(MiDKP.UI.INI_FILE, "Handle_MemberInfo")
          MiDKP.UI.MemberInfo.UpdateInfo(l_146_2:Lookup(l_146_2:GetItemCount() - 1), l_146_16)
        end
      end
      l_146_3, l_146_4 = l_146_2:SetSizeByAllItemSize, l_146_2
      l_146_3(l_146_4)
      l_146_3, l_146_4 = l_146_2:FormatAllItemPos, l_146_2
      l_146_3(l_146_4)
      l_146_3 = MiDKP
      l_146_3 = l_146_3.UI
      l_146_3 = l_146_3.UpdateMemberScrollBar
      l_146_3()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateMemberScore"
    l_0_6[l_0_7] = function()
      local l_147_0 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
      for l_147_4 = 0, l_147_0:GetItemCount() - 1 do
        local l_147_5 = l_147_0:Lookup(l_147_4)
        local l_147_6 = l_147_5.BigFoot_1210e713fbe7372fde7a5518a1f280ec
        MiDKP.UI.MemberInfo.UpdateInfo(l_147_5, l_147_6)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateEventList"
    l_0_6[l_0_7] = function()
      if MiDKP.UI.GetActiveRaid() then
        local l_148_0 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
      local l_148_1 = nil
      MiDKP.UI.EventInfo.Select(nil)
      Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList"):Clear()
      if l_148_1 then
        for l_148_5 = 1, l_148_1:GetEventCount() do
          local l_148_2 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_148_2:InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_EventInfo")
          local l_148_7 = l_148_1:GetEvent(R5_PC41)
          MiDKP.UI.EventInfo.UpdateInfo(l_148_2:Lookup(0), l_148_7)
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_148_2:FormatAllItemPos()
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_148_2:SetSizeByAllItemSize()
      MiDKP.UI.UpdateEventScrollBar()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateItemList"
    l_0_6[l_0_7] = function()
      if MiDKP.UI.GetActiveRaid() then
        local l_149_0 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
      local l_149_1 = nil
      MiDKP.UI.ItemInfo.Select(nil)
      Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList"):Clear()
      if l_149_1 then
        for l_149_5 = 1, l_149_1:GetItemCount() do
          local l_149_2 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_149_2:InsertItemFromIni(0, false, MiDKP.UI.INI_FILE, "Handle_ItemInfo")
          local l_149_7 = l_149_1:GetItem(R5_PC41)
          MiDKP.UI.ItemInfo.UpdateInfo(l_149_2:Lookup(0), l_149_7)
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_149_2:FormatAllItemPos()
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_149_2:SetSizeByAllItemSize()
      MiDKP.UI.UpdateItemScrollBar()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateDKPList"
    l_0_6[l_0_7] = function()
      -- upvalues: l_0_0
      local l_150_0 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
      MiDKP.UI.DKPInfo.Select(nil)
      l_150_0:Clear()
      if not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
        if MiDKP.UI.GetActiveRaid() then
          local l_150_1, l_150_2 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_150_1 then
          local l_150_3 = nil
          local l_150_4 = l_150_1:GetAllMemberNames()
          for l_150_8,l_150_9 in ipairs(l_150_4) do
            local l_150_5 = {}
             -- DECOMPILER ERROR: Confused about usage of registers!

            if (not MiDKP.UI.BigFoot_41b28dbf7273c33155e3cbd7389a37e3 or l_150_3:GetMember(R8_PC48):GetParty() ~= 0) and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[l_0_0[2][l_150_3:GetMember(R8_PC48):GetClass()]] then
              table.insert(l_150_5, l_150_3:GetMember(R8_PC48))
            end
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          if not MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 then
            table.sort(l_150_5, MiDKP.UI.DKPSortByNameAsc)
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          for l_150_14,l_150_15 in ipairs(l_150_5) do
            local l_150_11 = nil
            l_150_0:AppendItemFromIni(MiDKP.UI.INI_FILE, "Handle_DKPInfo")
            MiDKP.UI.DKPInfo.UpdateInfo(l_150_0:Lookup(l_150_0:GetItemCount() - 1), l_150_16)
          end
        end
        do break end
      end
      if MiDKP.UI.GetActiveRaid() then
        local l_150_17 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
      local l_150_18 = nil
      if MiDKP.DKP:GetDKPByName(MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616) then
        local l_150_19 = nil
        local l_150_20 = MiDKP.DKP:GetDKPByName(MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616):GetAllMemberNames()
        for l_150_24,l_150_25 in ipairs(l_150_20) do
          local l_150_21 = {}
          if (not MiDKP.UI.BigFoot_41b28dbf7273c33155e3cbd7389a37e3 or not l_150_18 or not l_150_18:GetMember(l_150_26) or l_150_18:GetMember(l_150_26):GetParty() ~= 0) and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[l_0_0[2][l_150_19:GetMember(l_150_0:Lookup(l_150_0:GetItemCount() - 1)).class]] then
            table.insert(l_150_21, l_150_19:GetMember(l_150_0:Lookup(l_150_0:GetItemCount() - 1)))
          end
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        if not MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 then
          table.sort(l_150_21, MiDKP.UI.DKPSortByNameAsc)
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        for l_150_30,l_150_31 in ipairs(l_150_21) do
          local l_150_27 = nil
          l_150_0:AppendItemFromIni(MiDKP.UI.INI_FILE, "Handle_DKPInfo")
          do
            local l_150_33 = l_150_0:Lookup(l_150_0:GetItemCount() - 1)
          end
          MiDKP.UI.DKPInfo.UpdateInfo(l_150_33, l_150_32)
        end
      end
      l_150_0:FormatAllItemPos()
      l_150_0:SetSizeByAllItemSize()
      MiDKP.UI.UpdateDKPScrollBar()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateDKPScore"
    l_0_6[l_0_7] = function()
      local l_151_0 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
      for l_151_4 = 0, l_151_0:GetItemCount() - 1 do
        local l_151_5 = l_151_0:Lookup(l_151_4)
        MiDKP.UI.DKPInfo.UpdateInfo(l_151_5, l_151_5.BigFoot_f8c6f4951c524600d5984ab47a0d8393)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByNameAsc"
    l_0_6[l_0_7] = function(l_152_0, l_152_1)
      return l_152_0:GetName() < l_152_1:GetName()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByNameDesc"
    l_0_6[l_0_7] = function(l_153_0, l_153_1)
      return l_153_1:GetName() < l_153_0:GetName()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByClassAsc"
    l_0_6[l_0_7] = function(l_154_0, l_154_1)
      return l_154_0:GetClass() < l_154_1:GetClass()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByClassDesc"
    l_0_6[l_0_7] = function(l_155_0, l_155_1)
      return l_155_1:GetClass() < l_155_0:GetClass()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByRewardAsc"
    l_0_6[l_0_7] = function(l_156_0, l_156_1)
      return l_156_0:GetReward() < l_156_1:GetReward()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByRewardDesc"
    l_0_6[l_0_7] = function(l_157_0, l_157_1)
      return l_157_1:GetReward() < l_157_0:GetReward()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByScoreAsc"
    l_0_6[l_0_7] = function(l_158_0, l_158_1)
      return l_158_0:GetScore() < l_158_1:GetScore()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberSortByScoreDesc"
    l_0_6[l_0_7] = function(l_159_0, l_159_1)
      return l_159_1:GetScore() < l_159_0:GetScore()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByNameAsc"
    l_0_6[l_0_7] = function(l_160_0, l_160_1)
      if l_160_0.name >= l_160_1.name then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_160_0:GetName() < l_160_1:GetName()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByNameDesc"
    l_0_6[l_0_7] = function(l_161_0, l_161_1)
      if l_161_1.name >= l_161_0.name then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_161_1:GetName() < l_161_0:GetName()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByClassAsc"
    l_0_6[l_0_7] = function(l_162_0, l_162_1)
      if l_162_0.class >= l_162_1.class then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_162_0:GetClass() < l_162_1:GetClass()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByClassDesc"
    l_0_6[l_0_7] = function(l_163_0, l_163_1)
      if l_163_1.class >= l_163_0.class then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_163_1:GetClass() < l_163_0:GetClass()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByScoreAsc"
    l_0_6[l_0_7] = function(l_164_0, l_164_1)
      if l_164_0.score >= l_164_1.score then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_164_0:GetScore() < l_164_1:GetScore()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPSortByScoreDesc"
    l_0_6[l_0_7] = function(l_165_0, l_165_1)
      if l_165_1.score >= l_165_0.score then
        return not MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616
      end
      do return end
      return l_165_1:GetScore() < l_165_0:GetScore()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateOptions"
    l_0_6[l_0_7] = function()
      local l_166_0 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Option")
      do
        local l_166_1, l_166_2, l_166_3, l_166_4 = MiDKP.Config:GetValue("RecordItemLevel") or 4
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_166_5 = nil
      l_166_0:Lookup("CheckBox_RecordLevel_" .. l_166_1).disabled = true
      l_166_0:Lookup("CheckBox_RecordLevel_" .. l_166_5):Check(true)
      l_166_0:Lookup("CheckBox_RecordLevel_" .. l_166_1).disabled = nil
      l_166_0:Lookup("CheckBox_WhisperCommand").disabled = true
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("CheckBox_WhisperCommand"):Check(MiDKP.Config:GetValue("EnableWhisperQuery"))
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("CheckBox_WhisperCommand").disabled = nil
      l_166_0:Lookup("Edit_WhisperCommand").disabled = true
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("Edit_WhisperCommand"):SetText(MiDKP.Config:GetValue("WhisperCommand"))
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("Edit_WhisperCommand").disabled = nil
      l_166_0:Lookup("CheckBox_HideWhisperMessage").disabled = true
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("CheckBox_HideWhisperMessage"):Check(MiDKP.Config:GetValue("FilterWhisperMessage"))
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_166_0:Lookup("CheckBox_HideWhisperMessage").disabled = nil
      do
        local l_166_6, l_166_7, l_166_8, l_166_9, l_166_10, l_166_11 = , MiDKP.Config:GetValue("ActionOnEventLevel") or 2
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_166_7 == 1 then
        l_166_0:Lookup("CheckBox_NoActionOnEvent").disabled = true
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_NoActionOnEvent"):Check(true)
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_NoActionOnEvent").disabled = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif l_166_7 == 2 then
        l_166_0:Lookup("CheckBox_InfoOnEvent").disabled = true
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_InfoOnEvent"):Check(true)
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_InfoOnEvent").disabled = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif l_166_7 == 3 then
        l_166_0:Lookup("CheckBox_PromptOnEvent").disabled = true
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_PromptOnEvent"):Check(true)
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_166_0:Lookup("CheckBox_PromptOnEvent").disabled = nil
      end
      if not MiDKP.Config:GetValue("DefaultParties") then
        local l_166_12 = nil
      end
      local l_166_13 = nil
      if MiDKP.Config:GetValue("AllMembersOnEvent") then
        l_166_13 = l_166_0:Lookup("CheckBox_AllPartiesByDefalut")
        l_166_13.disabled = true
        l_166_13:Check(true)
        l_166_13.disabled = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif ({})[1] and ({})[2] and not ({})[3] and not ({})[4] and not ({})[5] then
        l_166_13 = l_166_0:Lookup("CheckBox_2PartiesByDefault")
        l_166_13.disabled = true
        l_166_13:Check(true)
        l_166_13.disabled = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif ({})[1] and ({})[2] and ({})[3] and ({})[4] and ({})[5] then
        l_166_13 = l_166_0:Lookup("CheckBox_AllPartiesByDefalut")
        l_166_13.disabled = true
        l_166_13:Check(true)
        l_166_13.disabled = nil
      end
      l_166_13 = l_166_0:Lookup("CheckBox_OffLineByDefalut")
      l_166_13.disabled = true
      l_166_13:Check(MiDKP.Config:GetValue("OffLineMember"))
      l_166_13.disabled = nil
      l_166_13 = l_166_0:Lookup("CheckBox_SplitItemScore")
      l_166_13.disabled = true
      l_166_13:Check(MiDKP.Config:GetValue("SplitItemScore"))
      l_166_13.disabled = nil
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateRaidScrollBar"
    l_0_6[l_0_7] = function()
      local l_167_0 = Station.Lookup("Normal/MiDKP")
      local l_167_1 = l_167_0:Lookup("PageSet_Tabs/Page_Raid/Scroll_Raid")
      local l_167_2 = l_167_0:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      local l_167_3 = l_167_2:GetSize()
      local l_167_4 = math.floor((l_167_2 - 505) / 20) + 1
      local l_167_5, l_167_6 = l_167_1:SetStepCount, l_167_1
      do
        if l_167_4 > 0 then
          local l_167_7, l_167_8 = nil
      end
      if l_167_4 > 0 then
        end
      end
      l_167_5(l_167_6, 0)
      l_167_5, l_167_6 = l_167_0:Lookup, l_167_0
      l_167_5 = l_167_5(l_167_6, "PageSet_Tabs/Page_Raid/Btn_RaidUp")
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_167_4 > 0 then
        l_167_5:Show()
        l_167_6:Show()
      else
        l_167_5:Hide()
        l_167_6:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateMemberScrollBar"
    l_0_6[l_0_7] = function()
      local l_168_0 = Station.Lookup("Normal/MiDKP")
      local l_168_1 = l_168_0:Lookup("PageSet_Tabs/Page_Member/Scroll_Member")
      local l_168_2 = l_168_0:Lookup("PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
      local l_168_3 = l_168_2:GetSize()
      local l_168_4 = math.floor((l_168_2 - 475) / 20) + 1
      local l_168_5, l_168_6 = l_168_1:SetStepCount, l_168_1
      do
        if l_168_4 > 0 then
          local l_168_7, l_168_8 = nil
      end
      if l_168_4 > 0 then
        end
      end
      l_168_5(l_168_6, 0)
      l_168_5, l_168_6 = l_168_0:Lookup, l_168_0
      l_168_5 = l_168_5(l_168_6, "PageSet_Tabs/Page_Member/Btn_MemberUp")
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_168_4 > 0 then
        l_168_5:Show()
        l_168_6:Show()
      else
        l_168_5:Hide()
        l_168_6:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateEventScrollBar"
    l_0_6[l_0_7] = function()
      local l_169_0 = Station.Lookup("Normal/MiDKP")
      local l_169_1 = l_169_0:Lookup("PageSet_Tabs/Page_Event/Scroll_Event")
      local l_169_2 = l_169_0:Lookup("PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList")
      local l_169_3 = l_169_2:GetSize()
      local l_169_4 = math.floor((l_169_2 - 500) / 20) + 1
      local l_169_5, l_169_6 = l_169_1:SetStepCount, l_169_1
      do
        if l_169_4 > 0 then
          local l_169_7, l_169_8 = nil
      end
      if l_169_4 > 0 then
        end
      end
      l_169_5(l_169_6, 0)
      l_169_5, l_169_6 = l_169_0:Lookup, l_169_0
      l_169_5 = l_169_5(l_169_6, "PageSet_Tabs/Page_Event/Btn_EventUp")
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_169_4 > 0 then
        l_169_5:Show()
        l_169_6:Show()
      else
        l_169_5:Hide()
        l_169_6:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateItemScrollBar"
    l_0_6[l_0_7] = function()
      local l_170_0 = Station.Lookup("Normal/MiDKP")
      local l_170_1 = l_170_0:Lookup("PageSet_Tabs/Page_Item/Scroll_Item")
      local l_170_2 = l_170_0:Lookup("PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList")
      local l_170_3 = l_170_2:GetSize()
      local l_170_4 = math.floor((l_170_2 - 500) / 20) + 1
      local l_170_5, l_170_6 = l_170_1:SetStepCount, l_170_1
      do
        if l_170_4 > 0 then
          local l_170_7, l_170_8 = nil
      end
      if l_170_4 > 0 then
        end
      end
      l_170_5(l_170_6, 0)
      l_170_5, l_170_6 = l_170_0:Lookup, l_170_0
      l_170_5 = l_170_5(l_170_6, "PageSet_Tabs/Page_Item/Btn_ItemUp")
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_170_4 > 0 then
        l_170_5:Show()
        l_170_6:Show()
      else
        l_170_5:Hide()
        l_170_6:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "UpdateDKPScrollBar"
    l_0_6[l_0_7] = function()
      local l_171_0 = Station.Lookup("Normal/MiDKP")
      local l_171_1 = l_171_0:Lookup("PageSet_Tabs/Page_DKP/Scroll_DKP")
      local l_171_2 = l_171_0:Lookup("PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
      local l_171_3 = l_171_2:GetSize()
      local l_171_4 = math.floor((l_171_2 - 475) / 20) + 1
      local l_171_5, l_171_6 = l_171_1:SetStepCount, l_171_1
      do
        if l_171_4 > 0 then
          local l_171_7, l_171_8 = nil
      end
      if l_171_4 > 0 then
        end
      end
      l_171_5(l_171_6, 0)
      l_171_5, l_171_6 = l_171_0:Lookup, l_171_0
      l_171_5 = l_171_5(l_171_6, "PageSet_Tabs/Page_DKP/Btn_DKPUp")
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_171_4 > 0 then
        l_171_5:Show()
        l_171_6:Show()
      else
        l_171_5:Hide()
        l_171_6:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnScrollBarPosChanged"
    l_0_6[l_0_7] = function()
      local l_172_0 = this:GetScrollPos()
      local l_172_1 = Station.Lookup("Normal/MiDKP")
      local l_172_2 = this:GetName()
      if l_172_2 == "Scroll_Raid" then
        local l_172_3 = l_172_1:Lookup("PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll")
        l_172_3:SetItemStartRelPos(0, -l_172_0 * 20)
        if l_172_0 == 0 then
          l_172_1:Lookup("PageSet_Tabs/Page_Raid/Btn_RaidUp"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Raid/Btn_RaidUp"):Enable(1)
        end
        if l_172_0 == this:GetStepCount() then
          l_172_1:Lookup("PageSet_Tabs/Page_Raid/Btn_RaidDown"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Raid/Btn_RaidDown"):Enable(1)
        end
      elseif l_172_2 == "Scroll_Member" then
        local l_172_4 = l_172_1:Lookup("PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll")
        l_172_4:SetItemStartRelPos(0, -l_172_0 * 20)
        if l_172_0 == 0 then
          l_172_1:Lookup("PageSet_Tabs/Page_Member/Btn_MemberUp"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Member/Btn_MemberUp"):Enable(1)
        end
        if l_172_0 == this:GetStepCount() then
          l_172_1:Lookup("PageSet_Tabs/Page_Member/Btn_MemberDown"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Member/Btn_MemberDown"):Enable(1)
        end
      elseif l_172_2 == "Scroll_Event" then
        local l_172_5 = l_172_1:Lookup("PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll")
        l_172_5:SetItemStartRelPos(0, -l_172_0 * 20)
        if l_172_0 == 0 then
          l_172_1:Lookup("PageSet_Tabs/Page_Event/Btn_EventUp"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Event/Btn_EventUp"):Enable(1)
        end
        if l_172_0 == this:GetStepCount() then
          l_172_1:Lookup("PageSet_Tabs/Page_Event/Btn_EventDown"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Event/Btn_EventDown"):Enable(1)
        end
      elseif l_172_2 == "Scroll_Item" then
        local l_172_6 = l_172_1:Lookup("PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll")
        l_172_6:SetItemStartRelPos(0, -l_172_0 * 20)
        if l_172_0 == 0 then
          l_172_1:Lookup("PageSet_Tabs/Page_Item/Btn_ItemUp"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Item/Btn_ItemUp"):Enable(1)
        end
        if l_172_0 == this:GetStepCount() then
          l_172_1:Lookup("PageSet_Tabs/Page_Item/Btn_ItemDown"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_Item/Btn_ItemDown"):Enable(1)
        end
      elseif l_172_2 == "Scroll_DKP" then
        local l_172_7 = l_172_1:Lookup("PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll")
        l_172_7:SetItemStartRelPos(0, -l_172_0 * 20)
        if l_172_0 == 0 then
          l_172_1:Lookup("PageSet_Tabs/Page_DKP/Btn_DKPUp"):Enable(0)
        else
          l_172_1:Lookup("PageSet_Tabs/Page_DKP/Btn_DKPUp"):Enable(1)
        end
        if l_172_0 == this:GetStepCount() then
          l_172_1:Lookup("PageSet_Tabs/Page_DKP/Btn_DKPDown"):Enable(0)
        end
      else
        l_172_1:Lookup("PageSet_Tabs/Page_DKP/Btn_DKPDown"):Enable(1)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemLButtonDown"
    l_0_6[l_0_7] = function()
      if this.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
        MiDKP.UI.RaidInfo.Select(this)
      else
        if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
          MiDKP.UI.MemberInfo.Select(this)
        end
      else
        if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
          MiDKP.UI.EventInfo.Select(this)
        end
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          MiDKP.UI.ItemInfo.Select(this)
        end
      else
        if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 then
          MiDKP.UI.DKPInfo.Select(this)
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemMouseWheel"
    l_0_6[l_0_7] = function()
      local l_174_0 = this:GetName()
      if l_174_0 == "Handle_RaidScroll" then
        this:GetParent():GetParent():Lookup("Scroll_Raid"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      elseif l_174_0 == "Handle_MemberScroll" then
        this:GetParent():GetParent():Lookup("Scroll_Member"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      elseif l_174_0 == "Handle_EventScroll" then
        this:GetParent():GetParent():Lookup("Scroll_Event"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      elseif l_174_0 == "Handle_ItemScroll" then
        this:GetParent():GetParent():Lookup("Scroll_Item"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      elseif l_174_0 == "Handle_DKPScroll" then
        this:GetParent():GetParent():Lookup("Scroll_DKP"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemMouseEnter"
    l_0_6[l_0_7] = function()
      if this.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af and not MiDKP.UI.RaidInfo.IsSelectedRaid(this) then
        this:Lookup("Image_RaidInfo_Highlight"):Show()
      else
        if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec and not MiDKP.UI.MemberInfo.IsSelectedMember(this) then
          this:Lookup("Image_MemberInfo_Highlight"):Show()
        end
      else
        if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 and not MiDKP.UI.EventInfo.IsSelectedEvent(this) then
          this:Lookup("Image_EventInfo_Highlight"):Show()
        end
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 and not MiDKP.UI.ItemInfo.IsSelectedItem(this) then
          this:Lookup("Image_ItemInfo_Highlight"):Show()
        end
      else
        if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 and not MiDKP.UI.DKPInfo.IsSelectedDKP(this) then
          this:Lookup("Image_DKPInfo_Highlight"):Show()
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemMouseLeave"
    l_0_6[l_0_7] = function()
      if this.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af and not MiDKP.UI.RaidInfo.IsSelectedRaid(this) then
        this:Lookup("Image_RaidInfo_Highlight"):Hide()
      else
        if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec and not MiDKP.UI.MemberInfo.IsSelectedMember(this) then
          this:Lookup("Image_MemberInfo_Highlight"):Hide()
        end
      else
        if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 and not MiDKP.UI.EventInfo.IsSelectedEvent(this) then
          this:Lookup("Image_EventInfo_Highlight"):Hide()
        end
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 and not MiDKP.UI.ItemInfo.IsSelectedItem(this) then
          this:Lookup("Image_ItemInfo_Highlight"):Hide()
        end
      else
        if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 and not MiDKP.UI.DKPInfo.IsSelectedDKP(this) then
          this:Lookup("Image_DKPInfo_Highlight"):Hide()
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnItemRButtonDown"
    l_0_6[l_0_7] = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        MiDKP.UI.MemberInfo.Select(this)
        local l_177_0, l_177_1 = Cursor.GetPos()
        do
          local l_177_2 = this.BigFoot_1210e713fbe7372fde7a5518a1f280ec
          local l_177_3 = {}
          l_177_3.x = l_177_0
          l_177_3.y = l_177_1
          local l_177_4 = {}
          l_177_4.szOption = "�����¼�"
          l_177_4.fnAction = function()
            -- upvalues: l_177_2
            if MiDKP.UI.GetActiveRaid() then
              local l_178_0, l_178_1, l_178_2, l_178_3 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_178_0 and l_177_2 then
              MiDKP.UI.Event.OpenEventPanel(l_178_0)
              MiDKP.UI.Event.CheckMember(l_177_2:GetName())
            end
            do return end
            MiDKP.UI.Print("error", "���ȼ���һ�����")
          end
          local l_177_5 = {}
          l_177_5.szOption = "ɾ��"
          l_177_5.fnAction = function()
            -- upvalues: l_177_2
            local l_179_0 = {}
            l_179_0.szMessage = "ȷ��Ҫɾ����" .. l_177_2:GetName() .. "����"
            l_179_0.szName = "MiDKP_DeleteMember"
            local l_179_1 = {}
            l_179_1.szOption = g_tStrings.STR_HOTKEY_SURE
            l_179_1.fnAction = function()
              -- upvalues: l_177_2
              if MiDKP.UI.GetActiveRaid() then
                local l_180_0, l_180_1, l_180_5, l_180_6 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
              end
               -- DECOMPILER ERROR: Confused about usage of registers!

              if l_180_0 then
                if l_177_2:HasEvent() then
                  local l_180_2 = nil
                  local l_180_3 = {szMessage = "�Ƿ����Ӧ���¼���ɾ������ң�", szName = "MiDKP_DeleteMemberFromEvents"}
                  local l_180_4 = {szOption = g_tStrings.STR_HOTKEY_SURE, fnAction = function()
                    -- upvalues: l_1_0 , l_177_2
                    l_1_0:DeleteMember(l_177_2)
                  end}
                   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                  l_180_4 = MessageBox
                   -- DECOMPILER ERROR: Overwrote pending register.

                  l_180_4({szOption = g_tStrings.STR_HOTKEY_CANCEL})
                end
               -- DECOMPILER ERROR: Confused about usage of registers!

              else
                l_180_2:DeleteMember(l_177_2)
              end
            end
            local l_179_2 = {}
            l_179_2.szOption = g_tStrings.STR_HOTKEY_CANCEL
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_179_1 = MessageBox
            l_179_2 = l_179_0
            l_179_1(l_179_2)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_177_4 = PopupMenu
          l_177_5 = l_177_3
          l_177_4(l_177_5)
        end
      else
        if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
          MiDKP.UI.EventInfo.Select(this)
          local l_177_6 = this.BigFoot_d0708241b607c9a9dd1953c812fadfb7
          local l_177_7, l_177_8 = Cursor.GetPos()
          local l_177_9 = {}
          l_177_9.x = l_177_7
          l_177_9.y = l_177_8
          local l_177_10 = {}
          l_177_10.szOption = "�޸�"
          l_177_10.fnAction = function()
            -- upvalues: l_177_0
            local l_180_0 = MiDKP.UI.GetActiveRaid()
            if l_180_0 then
              MiDKP.UI.Event.OpenEventPanel(l_180_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, l_177_0)
            end
          end
          local l_177_11 = {}
          l_177_11.szOption = "ɾ��"
          l_177_11.fnAction = function()
            -- upvalues: l_177_0
            local l_181_0 = MiDKP.UI.GetActiveRaid()
            if l_181_0 then
              local l_181_1 = {}
              l_181_1.szMessage = "ȷ��Ҫɾ����" .. l_177_0:GetDesc() .. "������¼���"
              l_181_1.szName = "MiDKP_DeleteEvent"
              local l_181_2 = {}
              l_181_2.szOption = g_tStrings.STR_HOTKEY_SURE
              l_181_2.fnAction = function()
                -- upvalues: l_4_0 , l_177_0
                if l_4_0 and l_4_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
                  l_4_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:DeleteEvent(l_177_0)
                end
              end
              local l_181_3 = {}
              l_181_3.szOption = g_tStrings.STR_HOTKEY_CANCEL
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_181_2 = MessageBox
              l_181_3 = l_181_1
              l_181_2(l_181_3)
            end
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_177_10 = PopupMenu
          l_177_11 = l_177_9
          l_177_10(l_177_11)
        end
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          MiDKP.UI.ItemInfo.Select(this)
          local l_177_12 = this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9
          local l_177_13, l_177_14 = Cursor.GetPos()
          local l_177_15 = {}
          l_177_15.x = l_177_13
          l_177_15.y = l_177_14
          local l_177_16 = {}
          l_177_16.szOption = "�޸�"
          l_177_16.fnAction = function()
            -- upvalues: l_177_0
            if MiDKP.UI.GetActiveRaid() then
              local l_182_0, l_182_1 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_182_0 then
              MiDKP.UI.Item.OpenItemPanel(l_182_0, l_177_0)
            end
          end
          local l_177_17 = {}
          l_177_17.szOption = "ɾ��"
          l_177_17.fnAction = function()
            -- upvalues: l_177_0
            local l_183_0 = MiDKP.UI.GetActiveRaid()
            if l_183_0 then
              local l_183_1 = {}
              l_183_1.szMessage = "ȷ��Ҫɾ����" .. l_177_0:GetName() .. "�������Ʒ��"
              l_183_1.szName = "MiDKP_DeleteEvent"
              local l_183_2 = {}
              l_183_2.szOption = g_tStrings.STR_HOTKEY_SURE
              l_183_2.fnAction = function()
                -- upvalues: l_6_0 , l_177_0
                if l_6_0 and l_6_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
                  l_6_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:DeleteItem(l_177_0)
                end
              end
              local l_183_3 = {}
              l_183_3.szOption = g_tStrings.STR_HOTKEY_CANCEL
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_183_2 = MessageBox
              l_183_3 = l_183_1
              l_183_2(l_183_3)
            end
          end
          local l_177_18 = {}
          l_177_18.szOption = "���ӵ�������Ʒ"
          l_177_18.fnAction = function()
            -- upvalues: l_177_0
            if not MiDKP.Config:GetValue("IgnoreItems") then
              local l_184_0, l_184_1, l_184_2, l_184_3 = {}
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert(l_184_0, l_177_0:GetName())
             -- DECOMPILER ERROR: Confused about usage of registers!

            MiDKP.Config:SetValue("IgnoreItems", l_184_0)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_177_16 = PopupMenu
          l_177_17 = l_177_15
          l_177_16(l_177_17)
        end
      else
        if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 then
          MiDKP.UI.DKPInfo.Select(this)
          local l_177_19, l_177_20 = Cursor.GetPos()
          local l_177_21 = this.BigFoot_f8c6f4951c524600d5984ab47a0d8393
          local l_177_22 = nil
          if MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
            l_177_22 = l_177_21.name
          else
            l_177_22 = l_177_21:GetName()
          end
          local l_177_23 = {}
          l_177_23.x = l_177_19
          l_177_23.y = l_177_20
          local l_177_24 = {}
          l_177_24.szOption = "���͵�����"
          l_177_24.fnAction = function()
            -- upvalues: l_177_3
            if type(MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616) == "string" then
              MiDKP.UI.SendDKPInfo(PLAYER_TALK_CHANNEL.WHISPER, l_177_3)
            else
              MiDKP.UI.WhisperRaidInfo(l_177_3)
            end
          end
          local l_177_25 = {}
          l_177_25.szOption = "���͵�С��"
          l_177_25.fnAction = function()
            -- upvalues: l_177_3
            MiDKP.UI.SendDKPInfo(PLAYER_TALK_CHANNEL.TEAM, l_177_3)
          end
          local l_177_26 = {}
          l_177_26.szOption = "���͵����"
          l_177_26.fnAction = function()
            -- upvalues: l_177_3
            MiDKP.UI.SendDKPInfo(PLAYER_TALK_CHANNEL.TONG, l_177_3)
          end
          local l_177_27 = {}
          l_177_27.szOption = "���͵��Ŷ�"
          l_177_27.fnAction = function()
            -- upvalues: l_177_3
            MiDKP.UI.SendDKPInfo(PLAYER_TALK_CHANNEL.RAID, l_177_3)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_177_24 = PopupMenu
          l_177_25 = l_177_23
          l_177_24(l_177_25)
        end
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnLButtonClick"
    l_0_6[l_0_7] = function()
      -- upvalues: l_0_0
      local l_178_0 = this:GetName()
      if l_178_0 == "Btn_Close" then
        local l_178_1 = {}
        do
          l_178_1.szMessage = "�˳�DKP���棬�Ƿ񱣴�DKP�������ݣ�"
          l_178_1.szName = "MiDKP_SaveData"
          local l_178_2 = {}
          l_178_2.szOption = "����"
          l_178_2.fnAction = function()
            MiDKP.SaveRaidDate()
            MiDKP.UI.CloseMiDKPPanel()
          end
          local l_178_3 = {}
          l_178_3.szOption = "������"
          l_178_3.fnAction = function()
            MiDKP.UI.CloseMiDKPPanel()
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_178_2 = MessageBox
          l_178_3 = l_178_1
          l_178_2(l_178_3)
        end
      elseif l_178_0 == "Btn_NewRaid" then
        MiDKP.UI.Raid.OpenRaidPanel()
      elseif l_178_0 == "Btn_ModifyRaid" and MiDKP.UI.RaidInfo.GetSelectedRaid() then
        MiDKP.UI.Raid.OpenRaidPanel(MiDKP.UI.RaidInfo.GetSelectedRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      end
      do return end
      if l_178_0 == "Btn_DeleteRaid" and MiDKP.UI.RaidInfo.GetSelectedRaid() then
        local l_178_4 = {}
        l_178_4.szMessage = "ȷ��Ҫɾ����" .. MiDKP.UI.RaidInfo.GetSelectedRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:GetName() .. "����λ��"
        l_178_4.szName = "MiDKP_DeleteRaid"
        local l_178_5 = {}
        l_178_5.szOption = g_tStrings.STR_HOTKEY_SURE
        l_178_5.fnAction = function()
          MiDKP.Core:DeleteRaid(MiDKP.UI.RaidInfo.GetSelectedRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
        end
        local l_178_6 = {}
        l_178_6.szOption = g_tStrings.STR_HOTKEY_CANCEL
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_178_5 = MessageBox
        l_178_6 = l_178_4
        l_178_5(l_178_6)
      end
      do return end
      if l_178_0 == "Btn_StartRaid" then
        local l_178_7 = MiDKP.UI.RaidInfo.GetSelectedRaid()
        if l_178_7 then
          if not l_178_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:IsStarted() then
            l_178_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:Start()
          else
            if not l_178_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:IsFinished() then
              l_178_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:Finish()
            end
          else
            local l_178_8 = l_178_7.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:Export()
          end
          if l_178_8 then
            MiDKP.UI.Export.OpenExportPanel(l_178_8)
          end
          MiDKP.UI.RaidInfo.Select(l_178_7)
        end
      elseif l_178_0 == "Btn_ActiveRaid" then
        MiDKP.UI.ActiveRaid(MiDKP.UI.RaidInfo.GetSelectedRaid())
      elseif l_178_0 == "Btn_RaidUp" then
        this:GetParent():Lookup("Scroll_Raid"):ScrollPrev(1)
      elseif l_178_0 == "Btn_RaidDown" then
        this:GetParent():Lookup("Scroll_Raid"):ScrollNext(1)
      elseif l_178_0 == "Btn_IgnoredItems" then
        MiDKP.UI.IgnoreItems.OpenIgnoreItemsPanel()
      elseif l_178_0 == "Btn_Member_AddMember" then
        if MiDKP.UI.GetActiveRaid() then
          local l_178_9, l_178_10, l_178_11 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_178_9 then
          MiDKP.UI.Member.OpenMemberPanel(l_178_9)
        else
          MiDKP.UI.Print("error", "���ȼ���һ�����")
        end
      elseif l_178_0 == "Btn_Member_AddEvent" then
        if MiDKP.UI.GetActiveRaid() then
          local l_178_12, l_178_13, l_178_15, l_178_17, l_178_19 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_178_12 then
          if MiDKP.UI.MemberInfo.GetSelectedMember() then
            local l_178_14, l_178_16, l_178_18 = , MiDKP.UI.MemberInfo.GetSelectedMember().BigFoot_1210e713fbe7372fde7a5518a1f280ec
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_178_16 then
            MiDKP.UI.Event.OpenEventPanel(l_178_14)
             -- DECOMPILER ERROR: Confused about usage of registers!

            MiDKP.UI.Event.CheckMember(l_178_16:GetName())
          end
        else
          MiDKP.UI.Print("error", "���ȼ���һ�����")
        end
      elseif l_178_0 == "Btn_Member_Delete" then
        local l_178_20 = MiDKP.UI.MemberInfo.GetSelectedMember()
        if MiDKP.UI.GetActiveRaid() then
          local l_178_21, l_178_22 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_178_21 and l_178_20 then
          local l_178_23 = nil
          local l_178_24 = {szMessage = "ȷ��Ҫɾ����" .. l_178_20.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName() .. "����", szName = "MiDKP_DeleteMember"}
          local l_178_25 = {szOption = g_tStrings.STR_HOTKEY_SURE, fnAction = function()
            local l_182_0 = MiDKP.UI.MemberInfo.GetSelectedMember()
            local l_182_1 = l_182_0.BigFoot_1210e713fbe7372fde7a5518a1f280ec
            if MiDKP.UI.GetActiveRaid() then
              local l_182_2, l_182_3, l_182_7, l_182_8 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_182_2 then
              if l_182_1:HasEvent() then
                local l_182_4 = nil
                local l_182_5 = {szMessage = "�Ƿ����Ӧ���¼���ɾ������ң�", szName = "MiDKP_DeleteMemberFromEvents"}
                local l_182_6 = {szOption = g_tStrings.STR_HOTKEY_SURE, fnAction = function()
                  -- upvalues: l_4_2 , l_4_1
                  l_4_2:DeleteMember(l_4_1)
                end}
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                l_182_6 = MessageBox
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_182_6({szOption = g_tStrings.STR_HOTKEY_CANCEL})
              end
             -- DECOMPILER ERROR: Confused about usage of registers!

            else
              l_182_4:DeleteMember(l_182_1)
            end
          end}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_178_25 = MessageBox
           -- DECOMPILER ERROR: Overwrote pending register.

          l_178_25({szOption = g_tStrings.STR_HOTKEY_CANCEL})
        end
      elseif l_178_0 == "Btn_MemberUp" then
        this:GetParent():Lookup("Scroll_Member"):ScrollPrev(1)
      elseif l_178_0 == "Btn_MemberDown" then
        this:GetParent():Lookup("Scroll_Member"):ScrollNext(1)
      elseif l_178_0 == "Btn_Member_ClassDropdown" then
        local l_178_26, l_178_27 = this:GetParent():Lookup("CheckBox_Member_SortByClass"):GetAbsPos()
        local l_178_28 = {}
        l_178_28.x = l_178_26
        l_178_28.y = l_178_27 + 25
        local l_178_29 = {}
        l_178_29.szOption = "��������"
        l_178_29.bCheck = true
        if not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[1] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[2] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[3] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[4] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[5] and not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[6] then
          local l_178_30 = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[7]
        else
          l_178_29.bChecked = false
        end
        l_178_29.UserData = 0
        l_178_29.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_31 = {}
        l_178_31.szOption = "����"
        l_178_31.bCheck = true
        l_178_31.UserData = 1
        l_178_31.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[1]
        l_178_31.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_32 = {}
        l_178_32.szOption = "��"
        l_178_32.bCheck = true
        l_178_32.UserData = 2
        l_178_32.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[2]
        l_178_32.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_33 = {}
        l_178_33.szOption = "���"
        l_178_33.bCheck = true
        l_178_33.UserData = 3
        l_178_33.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[3]
        l_178_33.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_34 = {}
        l_178_34.szOption = "����"
        l_178_34.bCheck = true
        l_178_34.UserData = 4
        l_178_34.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[4]
        l_178_34.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_35 = {}
        l_178_35.szOption = "����"
        l_178_35.bCheck = true
        l_178_35.UserData = 5
        l_178_35.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[5]
        l_178_35.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_36 = {}
        l_178_36.szOption = "�ؽ�"
        l_178_36.bCheck = true
        l_178_36.UserData = 6
        l_178_36.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[6]
        l_178_36.fnAction = MiDKP.UI.OnMemberClassFilterChaged
        local l_178_37 = {}
        l_178_37.szOption = "�嶾"
        l_178_37.bCheck = true
        l_178_37.UserData = 7
        l_178_37.bChecked = not MiDKP.UI.BigFoot_bc79420cec13ad6e07e69aae1f0211e9[7]
        l_178_37.fnAction = MiDKP.UI.OnMemberClassFilterChaged
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_178_29 = PopupMenu
        l_178_31 = l_178_28
        l_178_29(l_178_31)
      elseif l_178_0 == "Btn_NewEvent" then
        if MiDKP.UI.GetActiveRaid() then
          local l_178_38, l_178_39, l_178_40 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_178_38 then
          MiDKP.UI.Event.OpenEventPanel(l_178_38)
        else
          MiDKP.UI.Print("error", "���ȼ���һ�����")
        end
      elseif l_178_0 == "Btn_DeleteEvent" then
        local l_178_41 = MiDKP.UI.GetActiveRaid()
        local l_178_42 = MiDKP.UI.EventInfo.GetSelectedEvent()
        if l_178_41 and l_178_42 then
          local l_178_43 = {}
          l_178_43.szMessage = "ȷ��Ҫɾ����" .. l_178_42.BigFoot_d0708241b607c9a9dd1953c812fadfb7:GetDesc() .. "������¼���"
          l_178_43.szName = "MiDKP_DeleteEvent"
          local l_178_44 = {}
          l_178_44.szOption = g_tStrings.STR_HOTKEY_SURE
          l_178_44.fnAction = function()
            -- upvalues: l_178_1 , l_178_2
            if l_178_1 and l_178_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
              l_178_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:DeleteEvent(l_178_2.BigFoot_d0708241b607c9a9dd1953c812fadfb7)
            end
          end
          local l_178_45 = {}
          l_178_45.szOption = g_tStrings.STR_HOTKEY_CANCEL
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_178_44 = MessageBox
          l_178_45 = l_178_43
          l_178_44(l_178_45)
        end
      elseif l_178_0 == "Btn_ModifyEvent" then
        local l_178_46 = MiDKP.UI.GetActiveRaid()
        local l_178_47 = MiDKP.UI.EventInfo.GetSelectedEvent()
        if l_178_46 and l_178_47 then
          MiDKP.UI.Event.OpenEventPanel(l_178_46.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, l_178_47.BigFoot_d0708241b607c9a9dd1953c812fadfb7)
        end
      elseif l_178_0 == "Btn_EventUp" then
        this:GetParent():Lookup("Scroll_Event"):ScrollPrev(1)
      elseif l_178_0 == "Btn_EventDown" then
        this:GetParent():Lookup("Scroll_Event"):ScrollNext(1)
      elseif l_178_0 == "Btn_NewItem" then
        local l_178_48 = MiDKP.UI.GetActiveRaid()
        if l_178_48 then
          MiDKP.UI.Item.OpenItemPanel(l_178_48.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
        else
          MiDKP.UI.Print("error", "���ȼ���һ�����")
        end
      elseif l_178_0 == "Btn_DeleteItem" then
        local l_178_49 = MiDKP.UI.GetActiveRaid()
        local l_178_50 = MiDKP.UI.ItemInfo.GetSelectedItem()
        if l_178_49 and l_178_50 then
          local l_178_51 = {}
          l_178_51.szMessage = "ȷ��Ҫɾ����" .. l_178_50.BigFoot_2e00ffac12aadb3a1fd865993ec505b9:GetName() .. "�������Ʒ��"
          l_178_51.szName = "MiDKP_DeleteEvent"
          local l_178_52 = {}
          l_178_52.szOption = g_tStrings.STR_HOTKEY_SURE
          l_178_52.fnAction = function()
            -- upvalues: l_178_1 , l_178_2
            if l_178_1 and l_178_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
              l_178_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:DeleteItem(l_178_2.BigFoot_2e00ffac12aadb3a1fd865993ec505b9)
            end
          end
          local l_178_53 = {}
          l_178_53.szOption = g_tStrings.STR_HOTKEY_CANCEL
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_178_52 = MessageBox
          l_178_53 = l_178_51
          l_178_52(l_178_53)
        end
      elseif l_178_0 == "Btn_ModifyItem" then
        if MiDKP.UI.GetActiveRaid() then
          local l_178_54, l_178_55 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
        local l_178_56 = nil
        if l_178_56 and MiDKP.UI.ItemInfo.GetSelectedItem() then
          MiDKP.UI.Item.OpenItemPanel(l_178_56, MiDKP.UI.ItemInfo.GetSelectedItem().BigFoot_2e00ffac12aadb3a1fd865993ec505b9)
        end
      elseif l_178_0 == "Btn_ItemUp" then
        this:GetParent():Lookup("Scroll_Item"):ScrollPrev(1)
      elseif l_178_0 == "Btn_ItemDown" then
        this:GetParent():Lookup("Scroll_Item"):ScrollNext(1)
      elseif l_178_0 == "Btn_DKP_ClassDropdown" then
        local l_178_57, l_178_58 = this:GetParent():Lookup("CheckBox_DKP_SortByClass"):GetAbsPos()
        local l_178_59 = {}
        l_178_59.x = l_178_57
        l_178_59.y = l_178_58 + 25
        local l_178_60 = {}
        l_178_60.szOption = "��������"
        l_178_60.bCheck = true
        if not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[1] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[2] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[3] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[4] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[5] and not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[6] then
          local l_178_61 = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[7]
        else
          l_178_60.bChecked = false
        end
        l_178_60.UserData = 0
        l_178_60.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_62 = {}
        l_178_62.szOption = "����"
        l_178_62.bCheck = true
        l_178_62.UserData = 1
        l_178_62.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[1]
        l_178_62.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_63 = {}
        l_178_63.szOption = "��"
        l_178_63.bCheck = true
        l_178_63.UserData = 2
        l_178_63.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[2]
        l_178_63.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_64 = {}
        l_178_64.szOption = "���"
        l_178_64.bCheck = true
        l_178_64.UserData = 3
        l_178_64.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[3]
        l_178_64.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_65 = {}
        l_178_65.szOption = "����"
        l_178_65.bCheck = true
        l_178_65.UserData = 4
        l_178_65.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[4]
        l_178_65.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_66 = {}
        l_178_66.szOption = "����"
        l_178_66.bCheck = true
        l_178_66.UserData = 5
        l_178_66.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[5]
        l_178_66.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_67 = {}
        l_178_67.szOption = "�ؽ�"
        l_178_67.bCheck = true
        l_178_67.UserData = 6
        l_178_67.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[6]
        l_178_67.fnAction = MiDKP.UI.OnDKPClassFilterChanged
        local l_178_68 = {}
        l_178_68.szOption = "�嶾"
        l_178_68.bCheck = true
        l_178_68.UserData = 7
        l_178_68.bChecked = not MiDKP.UI.BigFoot_09c56c132940994583d4f06226c6b4b0[7]
        l_178_68.fnAction = MiDKP.UI.OnDKPClassFilterChanged
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_178_60 = PopupMenu
        l_178_62 = l_178_59
        l_178_60(l_178_62)
      elseif l_178_0 == "Btn_DKP_ScoreDropdown" then
        local l_178_69, l_178_70 = this:GetParent():Lookup("CheckBox_DKP_SortByScore"):GetAbsPos()
        local l_178_71 = {}
        l_178_71.x = l_178_69
        l_178_71.y = l_178_70 + 25
        local l_178_72 = {}
        l_178_72.szOption = "��ǰ�����"
        l_178_72.bMCheck = true
        l_178_72.UserData = nil
        l_178_72.bChecked = MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 == nil
        l_178_72.fnAction = MiDKP.UI.OnDKPSystemChanged
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_178_72 = MiDKP
        l_178_72 = l_178_72.DKP
         -- DECOMPILER ERROR: Overwrote pending register.

        for l_178_78,l_178_79 in ipairs(l_178_72) do
          local l_178_80 = table.insert
          local l_178_81 = l_178_71
          local l_178_82 = {}
          l_178_82.szOption = l_178_79
          l_178_82.bMCheck = true
          l_178_82.UserData = l_178_79
          l_178_82.bChecked = MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 == l_178_79
          l_178_82.fnAction = MiDKP.UI.OnDKPSystemChanged
          l_178_80(l_178_81, l_178_82)
        end
        PopupMenu(l_178_71)
      elseif l_178_0 == "Btn_DKPUp" then
        this:GetParent():Lookup("Scroll_DKP"):ScrollPrev(1)
      elseif l_178_0 == "Btn_DKPDown" then
        this:GetParent():Lookup("Scroll_DKP"):ScrollNext(1)
      elseif l_178_0 == "Btn_ConfigDKP" then
        MiDKP.UI.MsgConfig.OpenMsgConfigPanel()
      elseif l_178_0 == "Btn_ReportDKP" then
        if MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
          MiDKP.UI.SendDKP()
        else
          if MiDKP.UI.GetActiveRaid() then
            local l_178_85 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

        end
        if l_178_85 then
          local l_178_86 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

          for l_178_90,l_178_91 in pairs(l_178_72.UI.BigFoot_09c56c132940994583d4f06226c6b4b0) do
            local l_178_87 = {}
            l_178_87[l_0_0[1][l_178_91]] = l_178_77
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          do
            local l_178_92, l_178_93 = , l_178_86:GetReport(MiDKP.UI.BigFoot_41b28dbf7273c33155e3cbd7389a37e3, l_178_87)
          end
        end
        if l_178_93 then
          MiDKP.UI.SendReport(l_178_93)
        end
      elseif l_178_0 == "Btn_RefreshDKP" then
        local l_178_94 = MiDKP.Config:GetValue("GuildUrl")
        if l_178_94 and #l_178_94 > 0 then
          Output("Btn_RefreshDKP")
        end
      elseif l_178_0 == "Btn_OpenDKP" then
        local l_178_95 = MiDKP.Config:GetValue("GuildUrl")
        if l_178_95 and #l_178_95 > 0 then
          do return end
        end
      elseif l_178_0 == "Btn_UpdateData" then
        local l_178_96 = MiDKP.Config:GetValue("GuildUrl")
      end
      if l_178_96 and #l_178_96 > 0 then
        Output("Btn_UpdateData")
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnCheckBoxCheck"
    l_0_6[l_0_7] = function()
      if this.disabled then
        return 
      end
      local l_179_0 = this:GetName()
      if l_179_0 == "CheckBox_RecordLevel_2" then
        MiDKP.Config:SetValue("RecordItemLevel", 2)
        local l_179_1 = this:GetParent()
        local l_179_2 = l_179_1:Lookup("CheckBox_RecordLevel_3")
        l_179_2.disabled = true
        l_179_2:Check(false)
        l_179_2.disabled = nil
        l_179_2 = l_179_1:Lookup("CheckBox_RecordLevel_4")
        l_179_2.disabled = true
        l_179_2:Check(false)
        l_179_2.disabled = nil
        l_179_2 = l_179_1:Lookup("CheckBox_RecordLevel_5")
        l_179_2.disabled = true
        l_179_2:Check(false)
        l_179_2.disabled = nil
      elseif l_179_0 == "CheckBox_RecordLevel_3" then
        MiDKP.Config:SetValue("RecordItemLevel", 3)
        local l_179_3 = this:GetParent()
        local l_179_4 = l_179_3:Lookup("CheckBox_RecordLevel_2")
        l_179_4.disabled = true
        l_179_4:Check(false)
        l_179_4.disabled = nil
        l_179_4 = l_179_3:Lookup("CheckBox_RecordLevel_4")
        l_179_4.disabled = true
        l_179_4:Check(false)
        l_179_4.disabled = nil
        l_179_4 = l_179_3:Lookup("CheckBox_RecordLevel_5")
        l_179_4.disabled = true
        l_179_4:Check(false)
        l_179_4.disabled = nil
      elseif l_179_0 == "CheckBox_RecordLevel_4" then
        MiDKP.Config:SetValue("RecordItemLevel", 4)
        local l_179_5 = this:GetParent()
        local l_179_6 = l_179_5:Lookup("CheckBox_RecordLevel_2")
        l_179_6.disabled = true
        l_179_6:Check(false)
        l_179_6.disabled = nil
        l_179_6 = l_179_5:Lookup("CheckBox_RecordLevel_3")
        l_179_6.disabled = true
        l_179_6:Check(false)
        l_179_6.disabled = nil
        l_179_6 = l_179_5:Lookup("CheckBox_RecordLevel_5")
        l_179_6.disabled = true
        l_179_6:Check(false)
        l_179_6.disabled = nil
      elseif l_179_0 == "CheckBox_RecordLevel_5" then
        MiDKP.Config:SetValue("RecordItemLevel", 5)
        local l_179_7 = this:GetParent()
        local l_179_8 = l_179_7:Lookup("CheckBox_RecordLevel_2")
        l_179_8.disabled = true
        l_179_8:Check(false)
        l_179_8.disabled = nil
        l_179_8 = l_179_7:Lookup("CheckBox_RecordLevel_3")
        l_179_8.disabled = true
        l_179_8:Check(false)
        l_179_8.disabled = nil
        l_179_8 = l_179_7:Lookup("CheckBox_RecordLevel_4")
        l_179_8.disabled = true
        l_179_8:Check(false)
        l_179_8.disabled = nil
      elseif l_179_0 == "CheckBox_WhisperCommand" then
        MiDKP.Config:SetValue("EnableWhisperQuery", true)
        this:GetParent():Lookup("Edit_WhisperCommand"):Enable(true)
      elseif l_179_0 == "CheckBox_HideWhisperMessage" then
        MiDKP.Config:SetValue("FilterWhisperMessage", true)
      elseif l_179_0 == "CheckBox_NoActionOnEvent" then
        MiDKP.Config:SetValue("ActionOnEventLevel", 1)
        local l_179_9 = this:GetParent()
        local l_179_10 = l_179_9:Lookup("CheckBox_InfoOnEvent")
        l_179_10.disabled = true
        l_179_10:Check(false)
        l_179_10.disabled = nil
        local l_179_11 = l_179_9:Lookup("CheckBox_PromptOnEvent")
        l_179_11.disabled = true
        l_179_11:Check(false)
        l_179_11.disabled = nil
      elseif l_179_0 == "CheckBox_InfoOnEvent" then
        MiDKP.Config:SetValue("ActionOnEventLevel", 2)
        local l_179_12 = this:GetParent()
        local l_179_13 = l_179_12:Lookup("CheckBox_NoActionOnEvent")
        l_179_13.disabled = true
        l_179_13:Check(false)
        l_179_13.disabled = nil
        local l_179_14 = l_179_12:Lookup("CheckBox_PromptOnEvent")
        l_179_14.disabled = true
        l_179_14:Check(false)
        l_179_14.disabled = nil
      elseif l_179_0 == "CheckBox_PromptOnEvent" then
        MiDKP.Config:SetValue("ActionOnEventLevel", 3)
        local l_179_15 = this:GetParent()
        local l_179_16 = l_179_15:Lookup("CheckBox_NoActionOnEvent")
        l_179_16.disabled = true
        l_179_16:Check(false)
        l_179_16.disabled = nil
        local l_179_17 = l_179_15:Lookup("CheckBox_InfoOnEvent")
        l_179_17.disabled = true
        l_179_17:Check(false)
        l_179_17.disabled = nil
      elseif l_179_0 == "CheckBox_2PartiesByDefault" then
        MiDKP.Config:SetValue("AllMembersOnEvent", false)
        local l_179_18, l_179_19 = MiDKP.Config:SetValue, MiDKP.Config
        local l_179_20 = "DefaultParties"
        local l_179_21 = {}
        l_179_21[1] = true
        l_179_21[2] = true
        l_179_18(l_179_19, l_179_20, l_179_21)
        l_179_18 = this
        l_179_18, l_179_19 = l_179_18:GetParent, l_179_18
        l_179_18 = l_179_18(l_179_19)
        l_179_19, l_179_20 = l_179_18:Lookup, l_179_18
        l_179_21 = "CheckBox_AllPartiesByDefalut"
        l_179_19 = l_179_19(l_179_20, l_179_21)
        l_179_19.disabled = true
        l_179_20, l_179_21 = l_179_19:Check, l_179_19
        l_179_20(l_179_21, false)
        l_179_19.disabled = nil
        l_179_20, l_179_21 = l_179_18:Lookup, l_179_18
        l_179_20 = l_179_20(l_179_21, "CheckBox_AllMembersByDefalut")
        l_179_19 = l_179_20
        l_179_19.disabled = true
        l_179_20, l_179_21 = l_179_19:Check, l_179_19
        l_179_20(l_179_21, false)
        l_179_19.disabled = nil
        l_179_20, l_179_21 = l_179_18:Lookup, l_179_18
        l_179_20 = l_179_20(l_179_21, "CheckBox_OffLineByDefalut")
        l_179_19 = l_179_20
        l_179_20, l_179_21 = l_179_19:Enable, l_179_19
        l_179_20(l_179_21, true)
        l_179_19.disabled = true
        l_179_20, l_179_21 = l_179_19:Check, l_179_19
        l_179_20(l_179_21, MiDKP.Config:GetValue("OffLineMember"))
        l_179_19.disabled = nil
        l_179_20, l_179_21 = l_179_19:Lookup, l_179_19
        l_179_20 = l_179_20(l_179_21, "", "")
        l_179_20, l_179_21 = l_179_20:Lookup, l_179_20
        l_179_20 = l_179_20(l_179_21, "Text_OfflineByDefalut")
        l_179_20, l_179_21 = l_179_20:SetFontColor, l_179_20
        l_179_20(l_179_21, 255, 255, 255)
      elseif l_179_0 == "CheckBox_AllPartiesByDefalut" then
        MiDKP.Config:SetValue("AllMembersOnEvent", false)
        local l_179_22, l_179_23 = MiDKP.Config:SetValue, MiDKP.Config
        local l_179_24 = "DefaultParties"
        local l_179_25 = {}
        l_179_25[1] = true
        l_179_25[2] = true
        l_179_25[3] = true
        l_179_25[4] = true
        l_179_25[5] = true
        l_179_22(l_179_23, l_179_24, l_179_25)
        l_179_22 = this
        l_179_22, l_179_23 = l_179_22:GetParent, l_179_22
        l_179_22 = l_179_22(l_179_23)
        l_179_23, l_179_24 = l_179_22:Lookup, l_179_22
        l_179_25 = "CheckBox_2PartiesByDefault"
        l_179_23 = l_179_23(l_179_24, l_179_25)
        l_179_23.disabled = true
        l_179_24, l_179_25 = l_179_23:Check, l_179_23
        l_179_24(l_179_25, false)
        l_179_23.disabled = nil
        l_179_24, l_179_25 = l_179_22:Lookup, l_179_22
        l_179_24 = l_179_24(l_179_25, "CheckBox_AllMembersByDefalut")
        l_179_23 = l_179_24
        l_179_23.disabled = true
        l_179_24, l_179_25 = l_179_23:Check, l_179_23
        l_179_24(l_179_25, false)
        l_179_23.disabled = nil
        l_179_24, l_179_25 = l_179_22:Lookup, l_179_22
        l_179_24 = l_179_24(l_179_25, "CheckBox_OffLineByDefalut")
        l_179_23 = l_179_24
        l_179_24, l_179_25 = l_179_23:Enable, l_179_23
        l_179_24(l_179_25, true)
        l_179_23.disabled = true
        l_179_24, l_179_25 = l_179_23:Check, l_179_23
        l_179_24(l_179_25, MiDKP.Config:GetValue("OffLineMember"))
        l_179_23.disabled = nil
        l_179_24, l_179_25 = l_179_23:Lookup, l_179_23
        l_179_24 = l_179_24(l_179_25, "", "")
        l_179_24, l_179_25 = l_179_24:Lookup, l_179_24
        l_179_24 = l_179_24(l_179_25, "Text_OfflineByDefalut")
        l_179_24, l_179_25 = l_179_24:SetFontColor, l_179_24
        l_179_24(l_179_25, 255, 255, 255)
      elseif l_179_0 == "CheckBox_AllMembersByDefalut" then
        MiDKP.Config:SetValue("AllMembersOnEvent", true)
        local l_179_26 = this:GetParent()
        local l_179_27 = l_179_26:Lookup("CheckBox_2PartiesByDefault")
        l_179_27.disabled = true
        l_179_27:Check(false)
        l_179_27.disabled = nil
        l_179_27 = l_179_26:Lookup("CheckBox_AllPartiesByDefalut")
        l_179_27.disabled = true
        l_179_27:Check(false)
        l_179_27.disabled = nil
        l_179_27 = l_179_26:Lookup("CheckBox_OffLineByDefalut")
        l_179_27:Enable(false)
        l_179_27.disabled = true
        l_179_27:Check(true)
        l_179_27.disabled = nil
        l_179_27:Lookup("", ""):Lookup("Text_OfflineByDefalut"):SetFontColor(128, 128, 128)
      elseif l_179_0 == "CheckBox_OffLineByDefalut" then
        MiDKP.Config:SetValue("OffLineMember", true)
      elseif l_179_0 == "CheckBox_SplitItemScore" then
        MiDKP.Config:SetValue("SplitItemScore", true)
      elseif l_179_0 == "CheckBox_Member_SortByName" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByNameAsc
        MiDKP.UI.UpdateMemberList()
      elseif l_179_0 == "CheckBox_Member_SortByClass" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByClassAsc
        MiDKP.UI.UpdateMemberList()
      elseif l_179_0 == "CheckBox_Member_SortByReward" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByRewardAsc
        MiDKP.UI.UpdateMemberList()
      elseif l_179_0 == "CheckBox_Member_SortByScore" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByScoreAsc
        MiDKP.UI.UpdateMemberList()
      elseif l_179_0 == "CheckBox_MemberInRaid" then
        MiDKP.UI.BigFoot_41b28dbf7273c33155e3cbd7389a37e3 = true
        MiDKP.UI.UpdateDKPList()
      elseif l_179_0 == "CheckBox_DKP_SortByName" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByNameAsc
        MiDKP.UI.UpdateDKPList()
      elseif l_179_0 == "CheckBox_DKP_SortByClass" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByClassAsc
        MiDKP.UI.UpdateDKPList()
      elseif l_179_0 == "CheckBox_DKP_SortByScore" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByScoreAsc
        MiDKP.UI.UpdateDKPList()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnCheckBoxUncheck"
    l_0_6[l_0_7] = function()
      if this.disabled then
        return 
      end
      local l_180_0 = this:GetName()
      if l_180_0 == "CheckBox_WhisperCommand" then
        MiDKP.Config:SetValue("EnableWhisperQuery", false)
        this:GetParent():Lookup("Edit_WhisperCommand"):Enable(false)
      elseif l_180_0 == "CheckBox_HideWhisperMessage" then
        MiDKP.Config:SetValue("FilterWhisperMessage", false)
      elseif l_180_0 == "CheckBox_OffLineByDefalut" then
        MiDKP.Config:SetValue("OffLineMember", false)
      elseif l_180_0 == "CheckBox_SplitItemScore" then
        MiDKP.Config:SetValue("SplitItemScore", false)
      elseif l_180_0 == "CheckBox_Member_SortByName" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByNameDesc
        MiDKP.UI.UpdateMemberList()
      elseif l_180_0 == "CheckBox_Member_SortByClass" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByClassDesc
        MiDKP.UI.UpdateMemberList()
      elseif l_180_0 == "CheckBox_Member_SortByReward" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByRewardDesc
        MiDKP.UI.UpdateMemberList()
      elseif l_180_0 == "CheckBox_Member_SortByScore" then
        MiDKP.UI.BigFoot_85711cc4fe7f1d7fcaf5b99f66ba7361 = MiDKP.UI.MemberSortByScoreDesc
        MiDKP.UI.UpdateMemberList()
      elseif l_180_0 == "CheckBox_MemberInRaid" then
        MiDKP.UI.BigFoot_41b28dbf7273c33155e3cbd7389a37e3 = nil
        MiDKP.UI.UpdateDKPList()
      elseif l_180_0 == "CheckBox_DKP_SortByName" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByNameDesc
        MiDKP.UI.UpdateDKPList()
      elseif l_180_0 == "CheckBox_DKP_SortByClass" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByClassDesc
        MiDKP.UI.UpdateDKPList()
      elseif l_180_0 == "CheckBox_DKP_SortByScore" then
        MiDKP.UI.BigFoot_ed76c3a094b2c2cdcfd74527181393a5 = MiDKP.UI.DKPSortByScoreDesc
        MiDKP.UI.UpdateDKPList()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnEditChanged"
    l_0_6[l_0_7] = function()
      if this.disabled then
        return 
      end
      local l_181_0 = this:GetName()
      if l_181_0 == "Edit_WhisperCommand" then
        MiDKP.Config:SetValue("WhisperCommand", this:GetText())
      elseif l_181_0 == "Edit_GuildUrl" then
        MiDKP.Config:SetValue("GuildUrl", this:GetText())
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnEvent"
    l_0_6[l_0_7] = function(l_182_0)
      -- upvalues: l_0_0 , l_0_4 , l_0_3 , l_0_2
      if not MiDKP.BigFoot_98a5dc0296fddcc9b5b804f038f1994c then
        return 
      end
       -- DECOMPILER ERROR: unhandled construct in 'if'

      if BigFoot_7cfeb6c045d2dd3d8659cb5b3a631d32 == "CUSTOM_DATA_LOADED" and arg0 == "Account" then
        MiDKP.EventHandler:OnCustomDataLoaded()
        MiDKP.UI.UpdateRaidList()
        MiDKP.UI.UpdateOptions()
      end
      do return end
      if l_182_0 == "PARTY_LEVEL_UP_RAID" then
        MiDKP.EventHandler:OnJoinRaid()
      elseif l_182_0 == "SYNC_ROLE_DATA_END" then
        MiDKP.EventHandler:OnLoginGame()
      elseif l_182_0 == "PARTY_UPDATE_BASE_INFO" and MiDKP.Util:IsInRaid() then
        MiDKP.EventHandler:OnJoinRaid()
      end
      do return end
      if (l_182_0 == "PARTY_SYNC_MEMBER_DATA" or l_182_0 == "PARTY_ADD_MEMBER") and MiDKP.Util:IsInRaid() then
        local l_182_1 = GetClientTeam()
        local l_182_2 = l_182_1.GetMemberInfo(arg1)
      end
      if l_182_2 then
        local l_182_3 = 0
        for l_182_7 = 0, 4 do
          local l_182_8 = l_182_1.GetGroupInfo(l_182_7)
          for l_182_12,l_182_13 in ipairs(l_182_8.MemberList) do
            if l_182_13 == arg1 then
              l_182_3 = l_182_7 + 1
              do break end
            end
          end
        end
        MiDKP.EventHandler:OnMemberJoin(l_182_2.szName, l_0_0[1][l_182_2.dwForceID], l_182_3)
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
      do return end
      if l_182_0 == "PARTY_UPDATE_MEMBER_INFO" then
        l_182_1 = MiDKP
        l_182_1 = l_182_1.Util
        l_182_1, l_182_2 = l_182_1:IsInRaid, l_182_1
        l_182_1 = l_182_1(l_182_2)
        if l_182_1 then
          l_182_1 = GetClientTeam
          l_182_1 = l_182_1()
          local l_182_14 = nil
          l_182_2 = l_182_1.GetMemberInfo
          l_182_3 = arg1
          l_182_2 = l_182_2(l_182_3)
          local l_182_15 = nil
          l_182_3 = MiDKP
          l_182_3 = l_182_3.Core
          l_182_3, l_182_14 = l_182_3:GetCurrentRaid, l_182_3
          l_182_3 = l_182_3(l_182_14)
          local l_182_16 = nil
        end
        if l_182_2 and l_182_3 and l_182_3 then
          l_182_14, l_182_15 = l_182_3:GetMember, l_182_3
          l_182_16 = l_182_2.szName
          l_182_14 = l_182_14(l_182_15, l_182_16)
          local l_182_17 = nil
        end
        if l_182_14 then
          l_182_15 = 0
          local l_182_18 = nil
          l_182_16 = 0
          l_182_17 = 4
          l_182_18 = 1
          for l_182_22 = l_182_16, l_182_17, l_182_18 do
            local l_182_20, l_182_21, l_182_22 = nil
            l_182_20 = l_182_1.GetGroupInfo
            l_182_21 = l_182_19
            l_182_20 = l_182_20(l_182_21)
            local l_182_23 = nil
            l_182_21 = ipairs
            l_182_22 = l_182_20.MemberList
            l_182_21 = l_182_21(l_182_22)
            for l_182_27,l_182_28 in l_182_21 do
              local l_182_26, l_182_27, l_182_28 = nil
              l_182_26 = arg1
              if l_182_25 == l_182_26 then
                l_182_15 = l_182_19 + 1
                do break end
              end
            end
             -- DECOMPILER ERROR: Confused about usage of registers for local variables.

          end
           -- DECOMPILER ERROR: Overwrote pending register.

          l_182_14:Modify(l_182_2.szName, l_0_0[1][l_182_20], l_182_20)
           -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        end
        do break end
      end
      if l_182_0 == "PARTY_DELETE_MEMBER" then
        l_182_1 = MiDKP
        l_182_1 = l_182_1.Util
        l_182_1, l_182_2 = l_182_1:IsInRaid, l_182_1
        l_182_1 = l_182_1(l_182_2)
        if l_182_1 then
          l_182_1 = arg1
          l_182_2 = GetClientPlayer
          l_182_2 = l_182_2()
          l_182_2 = l_182_2.dwID
          if l_182_1 == l_182_2 then
            l_182_1 = MiDKP
            l_182_1 = l_182_1.EventHandler
            l_182_1, l_182_2 = l_182_1:OnLeaveRaid, l_182_1
            l_182_1(l_182_2)
          end
          do break end
        end
        l_182_1 = MiDKP
        l_182_1 = l_182_1.EventHandler
        l_182_1, l_182_2 = l_182_1:OnMemberLeave, l_182_1
        l_182_3 = arg2
        l_182_1(l_182_2, l_182_3)
        do break end
      end
      if l_182_0 == "PARTY_SET_MEMBER_ONLINE_FLAG" then
        l_182_1 = MiDKP
        l_182_1 = l_182_1.Util
        l_182_1, l_182_2 = l_182_1:IsInRaid, l_182_1
        l_182_1 = l_182_1(l_182_2)
        if l_182_1 then
          l_182_1 = GetClientTeam
          l_182_1 = l_182_1()
          l_182_1 = l_182_1.GetMemberInfo
          l_182_2 = arg1
          l_182_1 = l_182_1(l_182_2)
          do
            local l_182_29 = nil
            l_182_2 = l_182_1.bIsOnLine
            if l_182_2 then
              l_182_2 = MiDKP
              l_182_2 = l_182_2.EventHandler
              l_182_2, l_182_3 = l_182_2:OnMemberOnLine, l_182_2
              l_182_14 = l_182_1.szName
              l_182_2(l_182_3, l_182_14)
            end
            do break end
          end
          l_182_2 = MiDKP
          l_182_2 = l_182_2.EventHandler
          l_182_2, l_182_3 = l_182_2:OnMemberOffLine, l_182_2
          l_182_14 = l_182_1.szName
          l_182_2(l_182_3, l_182_14)
        end
        do break end
      end
      if l_182_0 == "TEAM_CHANGE_MEMBER_GROUP" then
        l_182_1 = GetClientTeam
        l_182_1 = l_182_1()
        local l_182_30 = nil
        l_182_2 = l_182_1.GetMemberInfo
        l_182_3 = arg0
        l_182_2 = l_182_2(l_182_3)
        local l_182_31 = nil
        if l_182_2 then
          l_182_3 = MiDKP
          l_182_3 = l_182_3.EventHandler
          l_182_3, l_182_14 = l_182_3:OnMemberPartyChanged, l_182_3
          l_182_15 = l_182_2.szName
          l_182_3(l_182_14, l_182_15, arg2 + 1)
        end
        do break end
      end
      if l_182_0 == "LOOT_ITEM" then
        l_182_1 = print
        l_182_2 = "LOOT_ITEM"
        l_182_1(l_182_2)
        l_182_1 = GetPlayer
        l_182_2 = arg0
        l_182_1 = l_182_1(l_182_2)
        local l_182_32 = nil
        l_182_2 = GetItem
        l_182_3 = arg1
        l_182_2 = l_182_2(l_182_3)
        local l_182_33 = nil
        local l_182_34 = nil
        l_182_14 = l_182_2.dwTabType
        l_182_14 = l_182_2.dwIndex
        l_182_14 = l_182_2.nGenre
        l_182_15 = ITEM_GENRE
        l_182_15 = l_182_15.BOOK
        if l_182_14 == l_182_15 then
          l_182_14 = l_182_2.nBookID
        else
          l_182_14 = MiDKP
        end
        l_182_14 = l_182_14.Config
        l_182_14, l_182_15 = l_182_14:GetValue, l_182_14
        l_182_14 = (l_182_14(l_182_15, "IgnoreItems"))
        local l_182_35 = nil
        l_182_15 = nil
        local l_182_36 = nil
        for l_182_40,l_182_20 in ipairs(l_182_14) do
          local l_182_37, l_182_38, l_182_39, l_182_40, l_182_41 = nil
          if l_182_20 == l_182_2.szName then
            l_182_15 = true
        else
          end
        end
        if not l_182_15 then
          MiDKP.EventHandler:OnLootItem(l_182_1.szName, l_182_3)
        end
        do break end
      end
      if l_182_0 == "PLAYER_ENTER_SCENE" then
        l_182_1 = GetClientPlayer
        l_182_1 = l_182_1()
        local l_182_42 = nil
        if not l_182_1 then
          return 
        end
        l_182_2 = l_182_1.GetScene
        l_182_2 = l_182_2()
        l_182_2 = l_182_2.dwMapID
        local l_182_43 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        l_182_14 = l_182_2
         -- DECOMPILER ERROR: Overwrote pending register.

        do
          local l_182_44 = nil
          l_182_14 = pairs
          l_182_15 = l_0_4
          l_182_14 = l_182_14(l_182_15)
          for l_182_48,l_182_49 in l_182_14 do
            local l_182_45, l_182_46, l_182_47, l_182_48, l_182_49 = nil
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Confused about usage of registers!

            if l_182_3:match(MiDKP.EventHandler) then
              for l_182_42,l_182_43 in ipairs(l_182_1.szName) do
                local l_182_50, l_182_51, l_182_52, l_182_53, l_182_54 = nil
                l_182_44 = l_0_3
                l_182_44[l_182_43] = true
              end
            end
          end
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        do break end
      end
      if l_182_0 == "NPC_ENTER_SCENE" then
        l_182_1 = GetNpc
        l_182_2 = arg0
        l_182_1 = l_182_1(l_182_2)
        do
          local l_182_55 = nil
          l_182_2 = pairs
           -- DECOMPILER ERROR: Overwrote pending register.

          l_182_2 = l_182_2(l_182_3)
          for l_182_59,l_182_60 in l_182_2 do
            local l_182_56, l_182_57, l_182_58, l_182_59, l_182_60 = nil
            if l_182_15 == l_182_1.szName then
              l_0_2[l_182_15] = false
            end
          end
        end
        do break end
      end
      if l_182_0 == "SYS_MSG" then
        l_182_1 = arg0
        if l_182_1 == "UI_OME_DEATH_NOTIFY" then
          l_182_1 = IsPlayer
          l_182_1 = l_182_1(arg1)
          if not l_182_1 then
            l_182_1 = GetNpc
            l_182_1 = l_182_1(arg1)
            local l_182_61 = nil
            do
              local l_182_62 = nil
               -- DECOMPILER ERROR: Overwrote pending register.

              for l_182_66,l_182_67 in l_182_3(l_0_2) do
                local l_182_63, l_182_64, l_182_65, l_182_66, l_182_67 = nil
                if l_182_1.szName == MiDKP.EventHandler:OnLootItem then
                  for l_182_71,l_182_72 in pairs(l_0_2) do
                    local l_182_68, l_182_69, l_182_70, l_182_71, l_182_72 = nil
                     -- DECOMPILER ERROR: Overwrote pending register.

                    if l_182_61 == false then
                      return 
                    end
                  end
                end
                if true then
                  MiDKP.EventHandler:OnBossKilled(R10_PC369, 0)
                  l_0_2 = {}
                end
                do break end
              end
            end
          end
          do break end
        end
        l_182_1 = arg0
        if l_182_1 == "UI_OME_SKILL_EFFECT_LOG" then
          l_182_1 = IsPlayer
          l_182_1 = l_182_1(arg1)
        end
        if not l_182_1 then
          l_182_1 = GetTargetHandle
          l_182_1 = l_182_1(TARGET.NPC, arg1)
          local l_182_73 = l_182_61
        end
        if l_182_1 then
          l_0_2[l_182_1.szName] = nil
        end
        do break end
      end
      if l_182_0 == "PLAYER_TALK" then
        l_182_1 = MiDKP
        l_182_1 = l_182_1.UI
        l_182_1 = l_182_1.OnPlayerTalk
        l_182_1()
        l_182_1 = arg1
        if l_182_1 == PLAYER_TALK_CHANNEL.WHISPER then
          l_182_1 = arg2
        end
        if not l_182_1 then
          l_182_1 = GetClientPlayer
          l_182_1 = l_182_1()
          l_182_1 = l_182_1.GetTalkData
          l_182_1 = l_182_1()
          local l_182_74 = nil
        end
        if l_182_1[1].type == "text" then
          local l_182_75 = nil
          local l_182_76 = nil
          local l_182_77, l_182_78, l_182_79 = nil
        end
        do
          if MiDKP.Config:GetValue("EnableWhisperQuery") and string.find(string.lower(l_182_1[1].text), string.lower(MiDKP.Config:GetValue("WhisperCommand")) .. "([%s%a%d]*)") == 1 and string.lower(l_182_1[1].text) then
            local l_182_80 = nil
             -- DECOMPILER ERROR: Overwrote pending register.

            if string.lower(MiDKP.Config:GetValue("WhisperCommand")) .. "([%s%a%d]*)" and #string.lower(MiDKP.Config:GetValue("WhisperCommand")) .. "([%s%a%d]*)" > 1 then
              if string.lower(select(R10_PC369, string.find(R12_PC462, l_182_74), R12_PC462, l_182_74, l_182_75, l_182_76, l_182_77, l_182_78, l_182_79, l_182_80), R10_PC369) == "help" then
                local l_182_81 = nil
                local l_182_82 = nil
                 -- DECOMPILER ERROR: Overwrote pending register.

                local l_182_83 = nil
                local l_182_84 = nil
                local l_182_85 = nil
                GetClientPlayer().Talk(PLAYER_TALK_CHANNEL.WHISPER, R10_PC369, {R12_PC462})
              end
              do break end
            end
            if MiDKP.UI.GetActiveRaid() then
              local l_182_86, l_182_87, l_182_105 = nil
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            if MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
              local l_182_88 = nil
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              if l_0_0[3][string.lower(select(R10_PC369, string.find(R12_PC462, l_182_74), R12_PC462, l_182_74, l_182_75, l_182_76, l_182_77, l_182_78, l_182_79, l_182_80), R10_PC369)] then
                local l_182_89 = nil
                if #R10_PC369 > 0 then
                  local l_182_90 = nil
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  local l_182_91 = nil
                   -- DECOMPILER ERROR: Overwrote pending register.

                  local l_182_92 = nil
                  local l_182_93 = nil
                  local l_182_94 = nil
                   -- DECOMPILER ERROR: Confused about usage of registers!

                   -- DECOMPILER ERROR: Overwrote pending register.

                  GetClientPlayer().Talk(R12_PC462, l_182_74, l_182_75)
                  l_182_75 = {l_182_76}
                   -- DECOMPILER ERROR: Overwrote pending register.

                  for l_182_75,l_182_76 in ipairs(R12_PC462) do
                     -- DECOMPILER ERROR: Overwrote pending register.

                    local l_182_95 = nil
                     -- DECOMPILER ERROR: Overwrote pending register.

                     -- DECOMPILER ERROR: Overwrote pending register.

                    local l_182_96 = nil
                     -- DECOMPILER ERROR: Overwrote pending register.

                    local l_182_97 = nil
                    local l_182_98 = nil
                    local l_182_99 = nil
                    l_182_89 = string
                    l_182_89 = l_182_89.format
                    l_182_90 = "%d. %s(%d��)"
                    l_182_91 = l_182_75
                    l_182_92 = l_182_76.BigFoot_8983c60d66c8593ec7165ea9dbedb584
                    l_182_93 = l_182_76.BigFoot_20c03d41df6d325491f00a3df9858f08
                    l_182_89 = l_182_89(l_182_90, l_182_91, l_182_92, l_182_93)
                    l_182_88 = {type = "text", text = l_182_89}
                    l_182_77(l_182_78, l_182_79, l_182_80)
                    l_182_80 = {l_182_88}
                  end
                end
              else
                local l_182_100 = nil
                 -- DECOMPILER ERROR: Overwrote pending register.

                local l_182_101 = nil
                 -- DECOMPILER ERROR: Overwrote pending register.

                local l_182_102 = nil
                local l_182_103 = nil
                local l_182_104 = nil
                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Confused about usage of registers!

                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                GetClientPlayer().Talk(R12_PC462.WHISPER, l_182_74, {
{type = "text", text = l_182_77}})
              end
            else
              local l_182_106 = nil
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              local l_182_107 = nil
              local l_182_108 = nil
              local l_182_109 = nil
              local l_182_110 = nil
              GetClientPlayer().Talk(R10_PC369, arg3, {
{type = "text", text = "��ǰ�޻��"}})
            end
           -- DECOMPILER ERROR: Overwrote pending register.

          else
            if MiDKP.Config:GetValue(R10_PC369) then
              MiDKP.UI.WhisperRaidInfo(arg3)
            end
             -- DECOMPILER ERROR: Confused about usage of registers for local variables.

          end
        elseif l_182_0 == "INTERACTION_REQUEST_RESULT" then
          l_182_1 = arg0
        end
        if l_182_1 == "MIDKP_REQUEST_DATA" then
          l_182_1 = arg1
          if l_182_1 then
            l_182_1 = arg3
          end
          if l_182_1 > 0 then
            l_182_1 = string
            l_182_1 = l_182_1.find
            l_182_1 = l_182_1(arg2, "error dkpurl")
            if l_182_1 then
              l_182_1 = MiDKP
              l_182_1 = l_182_1.UI
              l_182_1 = l_182_1.Print
              l_182_1("error", "����ʧ�ܣ�δ�ҵ��˹��ᡣ")
              return 
            end
            l_182_1 = string
            l_182_1 = l_182_1.find
            l_182_1 = l_182_1(arg2, "no data")
            if l_182_1 then
              l_182_1 = MiDKP
              l_182_1 = l_182_1.UI
              l_182_1 = l_182_1.Print
              l_182_1("error", "����ʧ�ܣ��˹���û�н�����Ե����DKP���ݡ�")
              return 
            end
            l_182_1 = MiDKP
            l_182_1 = l_182_1.DKP
            l_182_1(l_182_1, arg2)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_182_1()
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_182_1("info", "���ݸ�����ϡ�")
          end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        else
          l_182_1("error", "����ʧ�ܣ��޷����ӵ���������")
           -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        end
         -- WARNING: missing end command somewhere! Added here
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OpenMiDKPPanel"
    l_0_6[l_0_7] = function()
      if not MiDKP.BigFoot_98a5dc0296fddcc9b5b804f038f1994c then
        return 
      end
      if not Station.Lookup("Normal/MiDKP") then
        local l_183_0, l_183_1, l_183_2 = Wnd.OpenWindow(MiDKP.UI.INI_FILE, "MiDKP")
      end
      local l_183_3, l_183_4 = , Station.GetClientSize(true)
      local l_183_5, l_183_6 = , l_183_3:GetSize()
      l_183_3:SetAbsPos((l_183_4 - l_183_6) / 2, (l_183_5 - l_183_3) / 2)
      l_183_3:Show()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "CloseMiDKPPanel"
    l_0_6[l_0_7] = function()
      local l_184_0 = Station.Lookup("Normal/MiDKP")
      if l_184_0 then
        l_184_0:Hide()
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "IsMiDKPPanelOpened"
    l_0_6[l_0_7] = function()
      local l_185_0, l_185_1 = Station.Lookup("Normal/MiDKP"):IsVisible, Station.Lookup("Normal/MiDKP")
      return l_185_0(l_185_1)
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "GetActiveRaid"
    l_0_6[l_0_7] = function()
      return MiDKP.UI.BigFoot_d0f8a4520deaa5a1a45e9dc125de6077
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ActiveRaid"
    l_0_6[l_0_7] = function(l_187_0)
      local l_187_1 = MiDKP.UI.BigFoot_d0f8a4520deaa5a1a45e9dc125de6077
      MiDKP.UI.BigFoot_d0f8a4520deaa5a1a45e9dc125de6077 = l_187_0
      if l_187_1 then
        MiDKP.UI.RaidInfo.UpdateInfo(l_187_1, l_187_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      end
      if l_187_0 then
        MiDKP.UI.RaidInfo.UpdateInfo(l_187_0, l_187_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af)
      end
      MiDKP.UI.OnRaidActived()
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "IsActiveRaid"
    l_0_6[l_0_7] = function(l_188_0)
      return MiDKP.UI.BigFoot_d0f8a4520deaa5a1a45e9dc125de6077 == l_188_0
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "SendReport"
    l_0_6[l_0_7] = function(l_189_0)
      local l_189_1 = GetClientPlayer()
      local l_189_2 = MiDKP.Config:GetValue("DefaultMessageChannel")
      local l_189_3 = l_189_0.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b
      local l_189_4 = l_189_3 % 60
      local l_189_5 = l_189_4 .. "��"
      l_189_3 = math.floor(l_189_3 / 60)
      if l_189_3 > 0 then
        local l_189_6 = l_189_3 % 60
        l_189_5 = l_189_6 .. "��" .. l_189_5
        l_189_3 = math.floor(l_189_3 / 60)
      end
      if l_189_3 > 0 then
        local l_189_7 = l_189_3 % 24
        l_189_5 = l_189_7 .. "Сʱ" .. l_189_5
        l_189_3 = math.floor(l_189_3 / 24)
      end
      if l_189_3 > 0 then
        l_189_5 = l_189_3 .. "��" .. l_189_5
      end
      local l_189_8 = l_189_1.Talk
      local l_189_9 = l_189_2
      local l_189_10 = ""
      local l_189_11 = {}
      do
        local l_189_12 = {}
        l_189_12.type = "text"
        l_189_12.text = string.format("�<%s>ʱ��%s��", l_189_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584, l_189_5)
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_189_8(l_189_9, l_189_10, l_189_11)
        l_189_8 = l_189_0.BigFoot_688fec9138c1fc6d0dd768683db73267
        if l_189_8 then
          l_189_8 = l_189_0.BigFoot_688fec9138c1fc6d0dd768683db73267
          l_189_8 = #l_189_8
        end
        if l_189_8 > 0 then
          l_189_8 = l_189_1.Talk
          l_189_9 = l_189_2
          l_189_10 = ""
          l_189_12 = {type = "text", text = "�������¼��У�"}
          l_189_8(l_189_9, l_189_10, l_189_11)
          l_189_11 = {l_189_12}
          l_189_8 = ipairs
          l_189_9 = l_189_0.BigFoot_688fec9138c1fc6d0dd768683db73267
          l_189_8 = l_189_8(l_189_9)
          for l_189_11,l_189_12 in l_189_8 do
            if l_189_12.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
              if type(l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3) == "string" then
                local l_189_13 = l_189_1.Talk
                local l_189_14 = l_189_2
                local l_189_15 = ""
                local l_189_16 = {}
                local l_189_17 = {}
                l_189_17.type = "text"
                l_189_17.text = string.format("%d.%s(%d��)", l_189_11, l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3, l_189_12.BigFoot_20c03d41df6d325491f00a3df9858f08)
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                l_189_13(l_189_14, l_189_15, l_189_16)
              else
                if not l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.BookID or l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.BookID == 0 then
                  local l_189_18 = l_189_1.Talk
                  local l_189_19 = l_189_2
                  local l_189_20 = ""
                  local l_189_21 = {}
                  local l_189_22 = {}
                  l_189_22.type = "text"
                  l_189_22.text = string.format("%d.", l_189_11)
                  local l_189_23 = {}
                  l_189_23.type = "iteminfo"
                  l_189_23.version = 0
                  l_189_23.tabtype = l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.TabType
                  l_189_23.index = l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.TabIndex
                  local l_189_24 = {}
                  l_189_24.type = "text"
                  l_189_24.text = string.format("ƽ���������(%d��)", l_189_12.BigFoot_20c03d41df6d325491f00a3df9858f08)
                   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                  l_189_18(l_189_19, l_189_20, l_189_21)
                end
              else
                local l_189_25 = l_189_1.Talk
                local l_189_26 = l_189_2
                local l_189_27 = ""
                local l_189_28 = {}
                local l_189_29 = {}
                l_189_29.type = "text"
                l_189_29.text = string.format("%d.", l_189_11)
                local l_189_30 = {}
                l_189_30.type = "book"
                l_189_30.version = 0
                l_189_30.tabtype = l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.TabType
                l_189_30.index = l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.TabIndex
                l_189_30.bookinfo = l_189_12.BigFoot_4ac22e939c7fd1fac854933eb2a943a3.BookID
                local l_189_31 = {}
                l_189_31.type = "text"
                l_189_31.text = string.format("ƽ���������(%d��)", l_189_12.BigFoot_20c03d41df6d325491f00a3df9858f08)
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                l_189_25(l_189_26, l_189_27, l_189_28)
              end
            else
              local l_189_32 = l_189_1.Talk
              local l_189_33 = l_189_2
              local l_189_34 = ""
              local l_189_35 = {}
              local l_189_36 = {}
              l_189_36.type = "text"
              l_189_36.text = string.format("%d.%s(%d��)", l_189_11, l_189_12.BigFoot_58bf64b2530594f4163e4cd743249693, l_189_12.BigFoot_20c03d41df6d325491f00a3df9858f08)
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

              l_189_32(l_189_33, l_189_34, l_189_35)
            end
          end
        end
        if l_189_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7 and #l_189_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7 > 0 then
          local l_189_37 = nil
          local l_189_38 = nil
          local l_189_39 = nil
          local l_189_40 = nil
          local l_189_41 = nil
          l_189_1.Talk(l_189_2, "", {
{type = "text", text = "��õ���Ʒ�У�"}})
          for i_1,i_2 in ipairs(l_189_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
            l_189_37 = type
            l_189_38 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
            l_189_37 = l_189_37(l_189_38)
            if l_189_37 == "table" then
              l_189_37 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
              l_189_37 = l_189_37.BookID
              if l_189_37 then
                l_189_37 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
                l_189_37 = l_189_37.BookID
              if l_189_37 == 0 then
                end
              end
              l_189_37 = l_189_1.Talk
              local l_189_42 = nil
              l_189_38 = l_189_2
              local l_189_43 = nil
              l_189_39 = ""
              local l_189_44 = nil
              local l_189_45 = nil
              local l_189_46 = nil
              l_189_42 = string
              l_189_42 = l_189_42.format
              l_189_43 = "%d."
              l_189_44 = i_1
              l_189_42 = l_189_42(l_189_43, l_189_44)
              local l_189_47 = nil
              l_189_43 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
              l_189_43 = l_189_43.TabType
              l_189_43 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
              l_189_43 = l_189_43.TabIndex
              do
                local l_189_48 = nil
                l_189_44 = string
                l_189_44 = l_189_44.format
                l_189_45 = "(%s���)(%d��)"
                l_189_46 = i_2.BigFoot_4cf6e7d7de970d76ed602b6363820676
                l_189_47 = i_2.BigFoot_20c03d41df6d325491f00a3df9858f08
                l_189_44 = l_189_44(l_189_45, l_189_46, l_189_47)
                l_189_43, l_189_42, l_189_41 = {type = "text", text = l_189_44}, {type = "iteminfo", version = 0, tabtype = l_189_43, index = l_189_43}, {type = "text", text = l_189_42}
                l_189_37(l_189_38, l_189_39, l_189_40)
                l_189_40 = {l_189_41, l_189_42, l_189_43}
              end
              for i_1,i_2 in ipairs(l_189_0.BigFoot_3b9d336b2a6a475b46a21da367b594a7) do
                l_189_37 = l_189_1.Talk
                local l_189_49 = nil
                l_189_38 = l_189_2
                local l_189_50 = nil
                l_189_39 = ""
                local l_189_51 = nil
                local l_189_52 = nil
                local l_189_53 = nil
                l_189_49 = string
                l_189_49 = l_189_49.format
                l_189_50 = "%d."
                l_189_51 = i_1
                l_189_49 = l_189_49(l_189_50, l_189_51)
                local l_189_54 = nil
                l_189_50 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
                l_189_50 = l_189_50.TabType
                l_189_50 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
                l_189_50 = l_189_50.TabIndex
                l_189_50 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
                l_189_50 = l_189_50.BookID
                local l_189_55 = nil
                l_189_51 = string
                l_189_51 = l_189_51.format
                l_189_52 = "(%s���)(%d��)"
                l_189_53 = i_2.BigFoot_4cf6e7d7de970d76ed602b6363820676
                l_189_54 = i_2.BigFoot_20c03d41df6d325491f00a3df9858f08
                l_189_51 = l_189_51(l_189_52, l_189_53, l_189_54)
                l_189_50, l_189_49, l_189_41 = {type = "text", text = l_189_51}, {type = "book", version = 0, tabtype = l_189_50, index = l_189_50, bookinfo = l_189_50}, {type = "text", text = l_189_49}
                l_189_37(l_189_38, l_189_39, l_189_40)
                l_189_40 = {l_189_41, l_189_49, l_189_50}
              else
                l_189_37 = l_189_1.Talk
                local l_189_56 = nil
                l_189_38 = l_189_2
                local l_189_57 = nil
                l_189_39 = ""
                local l_189_58 = nil
                local l_189_59 = nil
                local l_189_60 = nil
                l_189_56 = string
                l_189_56 = l_189_56.format
                l_189_57 = "%d."
                l_189_58 = i_1
                l_189_56 = l_189_56(l_189_57, l_189_58)
                local l_189_61 = nil
                l_189_57 = string
                l_189_57 = l_189_57.format
                l_189_58 = "%s(%s���)(%d��)"
                l_189_59 = MiDKP
                l_189_59 = l_189_59.Util
                l_189_59, l_189_60 = l_189_59:GetItemName, l_189_59
                l_189_61 = i_2.BigFoot_4ac22e939c7fd1fac854933eb2a943a3
                l_189_59 = l_189_59(l_189_60, l_189_61)
                l_189_60 = i_2.BigFoot_4cf6e7d7de970d76ed602b6363820676
                l_189_61 = i_2.BigFoot_20c03d41df6d325491f00a3df9858f08
                l_189_57 = l_189_57(l_189_58, l_189_59, l_189_60, l_189_61)
                l_189_56, l_189_41 = {type = "text", text = l_189_57}, {type = "text", text = l_189_56}
                l_189_37(l_189_38, l_189_39, l_189_40)
                l_189_40 = {l_189_41, l_189_56}
              end
            end
          end
          if l_189_0.BigFoot_f9542af0fc240db769f6a4369804f562 and #l_189_0.BigFoot_f9542af0fc240db769f6a4369804f562 > 0 then
            local l_189_62 = nil
            local l_189_63 = nil
            local l_189_64 = nil
            local l_189_65 = nil
            local l_189_66 = nil
            l_189_1.Talk(l_189_2, "", {
{type = "text", text = "��Ա�У�"}})
            for i_1,i_2 in ipairs(l_189_0.BigFoot_f9542af0fc240db769f6a4369804f562) do
              l_189_37 = l_189_1.Talk
              local l_189_67 = nil
              l_189_38 = l_189_2
              local l_189_68 = nil
              l_189_39 = ""
              local l_189_69 = nil
              local l_189_70 = nil
              local l_189_71 = nil
              l_189_62 = string
              l_189_62 = l_189_62.format
              l_189_63 = "%d.%s(%d��)"
              l_189_64 = i_1
              l_189_65 = i_2.BigFoot_8983c60d66c8593ec7165ea9dbedb584
              l_189_66 = i_2.BigFoot_20c03d41df6d325491f00a3df9858f08
              l_189_62 = l_189_62(l_189_63, l_189_64, l_189_65, l_189_66)
              l_189_41 = {type = "text", text = l_189_62}
              l_189_37(l_189_38, l_189_39, l_189_40)
              l_189_40 = {l_189_41}
            end
          end
           -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        end
         -- WARNING: missing end command somewhere! Added here
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "SendDKP"
    l_0_6[l_0_7] = function()
      if MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
        local l_190_0 = GetClientPlayer()
        local l_190_1 = MiDKP.Config:GetValue("DefaultMessageChannel")
        local l_190_2 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
        local l_190_3 = l_190_0.Talk
        local l_190_4 = l_190_1
        local l_190_5 = ""
        local l_190_6 = {}
        do
          local l_190_7 = {}
          l_190_7.type = "text"
          l_190_7.text = string.format("<%s>�����б���", MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616)
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_190_3(l_190_4, l_190_5, l_190_6)
          l_190_3 = 0
          l_190_4, l_190_5 = l_190_2:GetItemCount, l_190_2
          l_190_4 = l_190_4(l_190_5)
          l_190_4 = l_190_4 - 1
          l_190_5 = 1
          for l_190_6 = l_190_3, l_190_4, l_190_5 do
             -- DECOMPILER ERROR: Overwrote pending register.

            local l_190_8 = l_190_7.BigFoot_f8c6f4951c524600d5984ab47a0d8393
            local l_190_9 = l_190_0.Talk
            local l_190_10 = l_190_1
            local l_190_11 = ""
            local l_190_12 = {}
            local l_190_13 = {}
            l_190_13.type = "text"
            l_190_13.text = string.format("%d.%s(%s��)", l_190_6 + 1, l_190_8.name, l_190_8.score)
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_190_9(l_190_10, l_190_11, l_190_12)
          end
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "WhisperRaidInfo"
    l_0_6[l_0_7] = function(l_191_0)
      MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = 0
      local l_191_1 = GetClientPlayer()
      local l_191_2 = l_191_1.Talk
      local l_191_3 = PLAYER_TALK_CHANNEL.WHISPER
      local l_191_4 = l_191_0
      local l_191_5 = {}
      local l_191_6 = {}
      l_191_6.type = "text"
      l_191_6.text = "ʹ��\"dkp help\"���鿴������������"
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_191_2(l_191_3, l_191_4, l_191_5)
      l_191_2 = MiDKP
      l_191_2 = l_191_2.UI
      l_191_3 = MiDKP
      l_191_3 = l_191_3.UI
      l_191_3 = l_191_3.BigFoot_a3e7c26e3e18312643399cefe1c6b20f
      l_191_3 = l_191_3 + 1
      l_191_2.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = l_191_3
      l_191_2 = MiDKP
      l_191_2 = l_191_2.UI
      l_191_2 = l_191_2.GetActiveRaid
      l_191_2 = l_191_2()
      if l_191_2 then
        l_191_2 = MiDKP
        l_191_2 = l_191_2.UI
        l_191_2 = l_191_2.GetActiveRaid
        l_191_2 = l_191_2()
        l_191_2 = l_191_2.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
      end
      if l_191_2 then
        l_191_3, l_191_4 = l_191_2:GetMember, l_191_2
        l_191_5 = l_191_0
        l_191_3 = l_191_3(l_191_4, l_191_5)
      end
      if l_191_3 then
        l_191_4 = l_191_1.Talk
        l_191_5 = PLAYER_TALK_CHANNEL
        l_191_5 = l_191_5.WHISPER
        l_191_6 = l_191_0
        local l_191_7 = {}
        local l_191_8 = {}
        l_191_8.type = "text"
        l_191_8.text = "���λΪ��" .. l_191_2:GetName()
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_191_4(l_191_5, l_191_6, l_191_7)
        l_191_4 = MiDKP
        l_191_4 = l_191_4.UI
        l_191_5 = MiDKP
        l_191_5 = l_191_5.UI
        l_191_5 = l_191_5.BigFoot_a3e7c26e3e18312643399cefe1c6b20f
        l_191_5 = l_191_5 + 1
        l_191_4.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = l_191_5
        l_191_4 = l_191_1.Talk
        l_191_5 = PLAYER_TALK_CHANNEL
        l_191_5 = l_191_5.WHISPER
        l_191_6 = l_191_0
        l_191_8 = {type = "text", text = "���ڱ��λ�е�ǰ��/��ʷ��Ϊ" .. l_191_3:GetScore() .. "/" .. l_191_3:GetHistoryScore() .. "�֡�"}
        l_191_4(l_191_5, l_191_6, l_191_7)
        l_191_7 = {l_191_8}
        l_191_4 = MiDKP
        l_191_4 = l_191_4.UI
        l_191_5 = MiDKP
        l_191_5 = l_191_5.UI
        l_191_5 = l_191_5.BigFoot_a3e7c26e3e18312643399cefe1c6b20f
        l_191_5 = l_191_5 + 1
        l_191_4.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = l_191_5
      end
      l_191_3 = MiDKP
      l_191_3 = l_191_3.DKP
      l_191_3, l_191_4 = l_191_3:Query, l_191_3
      l_191_5 = l_191_0
      l_191_3 = l_191_3(l_191_4, l_191_5)
      l_191_4 = ipairs
      l_191_5 = l_191_3
      l_191_4 = l_191_4(l_191_5)
      for i_1,i_2 in l_191_4 do
        if l_191_10.BigFoot_20c03d41df6d325491f00a3df9858f08 then
          local l_191_11 = l_191_1.Talk
          local l_191_12 = PLAYER_TALK_CHANNEL.WHISPER
          local l_191_13 = l_191_0
          local l_191_14 = {}
          local l_191_15 = {}
          l_191_15.type = "text"
          l_191_15.text = "����<" .. l_191_10.BigFoot_8983c60d66c8593ec7165ea9dbedb584 .. ">��ӵ�е��ܷ�ֵΪ" .. l_191_10.BigFoot_20c03d41df6d325491f00a3df9858f08 .. "�֡�"
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_191_11(l_191_12, l_191_13, l_191_14)
          l_191_11 = MiDKP
          l_191_11 = l_191_11.UI
          l_191_12 = MiDKP
          l_191_12 = l_191_12.UI
          l_191_12 = l_191_12.BigFoot_a3e7c26e3e18312643399cefe1c6b20f
          l_191_12 = l_191_12 + 1
          l_191_11.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = l_191_12
        else
          local l_191_16 = l_191_1.Talk
          local l_191_17 = PLAYER_TALK_CHANNEL.WHISPER
          local l_191_18 = l_191_0
          local l_191_19 = {}
          local l_191_20 = {}
          l_191_20.type = "text"
          l_191_20.text = "����<" .. l_191_10.BigFoot_8983c60d66c8593ec7165ea9dbedb584 .. ">��û�з�ֵ��"
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_191_16(l_191_17, l_191_18, l_191_19)
          l_191_16 = MiDKP
          l_191_16 = l_191_16.UI
          l_191_17 = MiDKP
          l_191_17 = l_191_17.UI
          l_191_17 = l_191_17.BigFoot_a3e7c26e3e18312643399cefe1c6b20f
          l_191_17 = l_191_17 + 1
          l_191_16.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = l_191_17
        end
      end
      local l_191_21, l_191_26 = nil
      do
        local l_191_22, l_191_27 = nil
        local l_191_23 = nil
        local l_191_24 = nil
        local l_191_25 = nil
        l_191_1.Talk(PLAYER_TALK_CHANNEL.WHISPER, l_191_0, l_191_21)
        l_191_21 = {l_191_26}
      end
      MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f + 1
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "SendDKPInfo"
    l_0_6[l_0_7] = function(l_192_0, l_192_1)
      local l_192_2 = GetClientPlayer()
      if type(MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616) == "string" then
        local l_192_3 = MiDKP.DKP:GetDKPByName(MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616)
        if l_192_3 then
          local l_192_4 = string.format(">%s<��<%s>��ӵ�У���ʷ��%d��", l_192_1, l_192_3:GetName(), l_192_3:GetScore(l_192_1))
          if l_192_0 == PLAYER_TALK_CHANNEL.WHISPER then
            local l_192_5 = l_192_2.Talk
            local l_192_6 = l_192_0
            local l_192_7 = l_192_1
            local l_192_8 = {}
            local l_192_9 = {}
            l_192_9.type = "text"
            l_192_9.text = l_192_4
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_192_5(l_192_6, l_192_7, l_192_8)
          end
        else
          local l_192_10 = l_192_2.Talk
          local l_192_11 = l_192_0
          local l_192_12 = ""
          local l_192_13 = {}
          local l_192_14 = {}
          l_192_14.type = "text"
          l_192_14.text = l_192_4
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_192_10(l_192_11, l_192_12, l_192_13)
        end
      else
        if MiDKP.UI.GetActiveRaid() then
          local l_192_15, l_192_16, l_192_17 = MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_192_15 then
        local l_192_18 = nil
        local l_192_19 = l_192_15:GetMember(l_192_1)
        local l_192_20 = (l_192_18:GetDKP())
         -- DECOMPILER ERROR: Overwrote pending register.

        if l_192_20 then
          do return end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

      end
      if l_192_19 then
        if BigFoot_4b67b4dfdf00cf0f28c62af16784a3e6 == PLAYER_TALK_CHANNEL.WHISPER then
          local l_192_21 = nil
          local l_192_22 = l_192_2.Talk
          local l_192_23 = l_192_0
          local l_192_24 = l_192_1
          local l_192_25 = {}
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_192_22(l_192_23, l_192_24, l_192_25)
        end
      else
        local l_192_26 = nil
        local l_192_27 = l_192_2.Talk
        local l_192_28 = l_192_0
        local l_192_29 = ""
        local l_192_30 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_192_27(l_192_28, l_192_29, l_192_30)
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "OnPlayerTalk"
    l_0_6[l_0_7] = function(...)
      if arg2 and MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f then
        MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f - 1
        if MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f >= 0 and MiDKP.Config:GetValue("FilterWhisperMessage") then
          return 
        end
        MiDKP.UI.BigFoot_a3e7c26e3e18312643399cefe1c6b20f = nil
      end
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "BigFoot_8abda466f497a375dc17fcd07263d27c"
    l_0_6[l_0_7] = TogglePanel
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "TogglePanel"
    l_0_6[l_0_7] = function(l_194_0)
      if l_194_0 == "OPTION" then
        if MiDKP.UI.Export.IsExportPanelOpened() then
          MiDKP.UI.Export.CloseExportPanel()
          return 
        end
        if MiDKP.UI.MsgConfig.IsMsgConfigPanelOpened() then
          MiDKP.UI.MsgConfig.CloseMsgConfigPanel()
          return 
        end
        if MiDKP.UI.IgnoreItems.IsIgnoreItemsPanelOpened() then
          MiDKP.UI.IgnoreItems.CloseIgnoreItemsPanel()
          return 
        end
        if MiDKP.UI.Member.IsMemberPanelOpened() then
          MiDKP.UI.Member.CloseMemberPanel()
          return 
        end
        if MiDKP.UI.Event.IsEventPanelOpened() then
          MiDKP.UI.Event.CloseEventPanel()
          return 
        end
        if MiDKP.UI.Item.IsItemPanelOpened() then
          MiDKP.UI.Item.CloseItemPanel()
          return 
        end
        if MiDKP.UI.Raid.IsRaidPanelOpened() then
          MiDKP.UI.Raid.CloseRaidPanel()
          return 
        end
      end
      if MiDKP.UI.IsMiDKPPanelOpened() then
        MiDKP.UI.CloseMiDKPPanel()
        return 
      end
      MiDKP.UI.BigFoot_8abda466f497a375dc17fcd07263d27c(l_194_0)
    end
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "TogglePanel"
    l_0_6 = l_0_6[l_0_7]
    TogglePanel = l_0_6
    l_0_6 = setmetatable
    l_0_7 = MiDKP
    local l_0_8 = {}
    local l_0_9 = "__index"
    l_0_8[l_0_9] = MiDKP.UI
    l_0_6(l_0_7, l_0_8)
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "RaidInfo"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "RaidInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Select"
    l_0_8 = function(l_195_0)
      local l_195_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("", ""):Lookup("Handle_RaidScroll"):Lookup("Handle_RaidList")
      if MiDKP.UI.RaidInfo.GetSelectedRaid() and not MiDKP.UI.RaidInfo.IsSelectedRaid(l_195_0) then
        local l_195_2 = MiDKP.UI.RaidInfo.GetSelectedRaid()
        l_195_2:Lookup("Image_RaidInfo_Highlight"):Hide()
        l_195_2:Lookup("Image_RaidInfo_Highlight"):SetFrame(2)
        l_195_2:Lookup("Image_RaidInfo_Highlight"):SetSize(455, 35)
        l_195_2:SetSize(455, 35)
        l_195_2:Lookup("Handle_RaidInfo_Other"):Hide()
      end
      MiDKP.UI.BigFoot_4c4a81d6ccf0bdc91dacea346e60557c = l_195_0
      if l_195_0 then
        l_195_0:Lookup("Image_RaidInfo_Highlight"):Show()
        l_195_0:Lookup("Image_RaidInfo_Highlight"):SetFrame(1)
        l_195_0:SetSize(455, 60)
        l_195_0:Lookup("Image_RaidInfo_Highlight"):SetSize(455, 60)
        l_195_0:Lookup("Handle_RaidInfo_Other"):Show()
        local l_195_3 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Raid"):Lookup("Btn_StartRaid")
        if not l_195_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:IsStarted() then
          l_195_3:Lookup("", ""):Lookup("Text_StartRaid"):SetText("��ʼ")
        end
      else
        if not l_195_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:IsFinished() then
          l_195_3:Lookup("", ""):Lookup("Text_StartRaid"):SetText("����")
        end
      else
        l_195_3:Lookup("", ""):Lookup("Text_StartRaid"):SetText("����")
      end
      l_195_1:FormatAllItemPos()
      l_195_1:SetSizeByAllItemSize()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "RaidInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsSelectedRaid"
    l_0_8 = function(l_196_0)
      if l_196_0 and l_196_0 == MiDKP.UI.BigFoot_4c4a81d6ccf0bdc91dacea346e60557c then
        return true
      end
      return false
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "RaidInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "GetSelectedRaid"
    l_0_8 = function()
      return MiDKP.UI.BigFoot_4c4a81d6ccf0bdc91dacea346e60557c
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "RaidInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UpdateInfo"
    l_0_8 = function(l_198_0, l_198_1)
      -- upvalues: l_0_5
      local l_198_2 = l_198_1:GetName()
      l_198_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_198_2
      l_198_0:Lookup("Text_RaidInfo_Name"):SetText(l_0_5(l_198_2, 28))
      local l_198_3 = l_198_1:GetDKP()
      if l_198_3 then
        l_198_0:Lookup("Text_RaidInfo_DKP"):SetText(l_0_5(l_198_3:GetName(), 20))
      end
      if not l_198_1:IsStarted() then
        l_198_0:Lookup("Text_RaidInfo_Status"):SetText("(δ��ʼ)")
        l_198_0:Lookup("Text_RaidInfo_Status"):SetFontScheme(83)
      else
        if l_198_1:IsStarted() and not l_198_1:IsFinished() then
          l_198_0:Lookup("Text_RaidInfo_Status"):SetText("(������)")
          l_198_0:Lookup("Text_RaidInfo_Status"):SetFontScheme(79)
        end
      else
        if l_198_1:IsFinished() then
          l_198_0:Lookup("Text_RaidInfo_Status"):SetText("(�ѽ���)")
          l_198_0:Lookup("Text_RaidInfo_Status"):SetFontScheme(84)
        end
      end
      local l_198_4 = l_198_0:Lookup("Handle_RaidInfo_Other")
      l_198_4:Clear()
      local l_198_5 = l_198_1:GetLocations()
      for l_198_9,l_198_10 in ipairs(l_198_5) do
        if l_198_9 ~= #locations then
          l_198_4:AppendItemFromString(string.format("<Text>text=\"%s\" font=189 postype=7</Text>"), l_198_10 .. ",")
        else
          l_198_4:AppendItemFromString(string.format("<Text>text=\"%s\" font=189 postype=7</Text>"), l_198_10 .. " ")
        end
      end
      l_198_4:AppendItemFromString(string.format("<Text>text=\"�ܹ�%d�� \" font=189 postype=7</Text>", l_198_1:GetMemberCount()))
      if l_198_1:IsStarted() then
        local l_198_11 = TimeToDate(l_198_1:GetStartTime())
        l_198_4:AppendItemFromString(string.format("<Text>text=\"��ʼ %04d.%02d.%02d %02d:%02d \" font=189 postype=10</Text>", l_198_11.year, l_198_11.month, l_198_11.day, l_198_11.hour, l_198_11.minute))
      end
      if l_198_1:IsFinished() then
        local l_198_12 = TimeToDate(l_198_1:GetFinishTime())
        l_198_4:AppendItemFromString(string.format("<Text>text=\"���� %04d.%02d.%02d %02d:%02d\" font=189 postype=7</Text>", l_198_12.year, l_198_12.month, l_198_12.day, l_198_12.hour, l_198_12.minute))
      end
      if MiDKP.UI.GetActiveRaid() and MiDKP.UI.GetActiveRaid().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af == l_198_1 then
        l_198_4:AppendItemFromString("<Text>text=\"�Ѽ���\" font=165 postype=0 x=378 y=2</Text>")
      end
      l_198_4:FormatAllItemPos()
      l_198_4:SetSizeByAllItemSize()
      if MiDKP.UI.RaidInfo.GetSelectedRaid() ~= l_198_0 then
        l_198_0:Lookup("Image_RaidInfo_Highlight"):Hide()
        l_198_4:Hide()
      end
      l_198_0.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_198_1
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberInfo"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Select"
    l_0_8 = function(l_199_0)
      local l_199_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Member"):Lookup("", ""):Lookup("Handle_MemberScroll"):Lookup("Handle_MemberList")
      if MiDKP.UI.MemberInfo.GetSelectedMember() and not MiDKP.UI.MemberInfo.IsSelectedMember(l_199_0) then
        local l_199_2 = MiDKP.UI.MemberInfo.GetSelectedMember()
        l_199_2:Lookup("Image_MemberInfo_Highlight"):Hide()
        l_199_2:Lookup("Image_MemberInfo_Highlight"):SetFrame(2)
        l_199_2:Lookup("Image_MemberInfo_Highlight"):SetSize(460, 25)
        l_199_2:SetSize(460, 25)
        l_199_2:Lookup("Handle_MemberInfo_Other"):Hide()
      end
      MiDKP.UI.BigFoot_87e1203c5898c5451b860784065dbe15 = l_199_0
      if l_199_0 then
        l_199_0:Lookup("Image_MemberInfo_Highlight"):Show()
        l_199_0:Lookup("Image_MemberInfo_Highlight"):SetFrame(1)
        l_199_0:SetSize(460, 40)
        l_199_0:Lookup("Image_MemberInfo_Highlight"):SetSize(460, 40)
        l_199_0:Lookup("Handle_MemberInfo_Other"):Show()
      end
      l_199_1:FormatAllItemPos()
      l_199_1:SetSizeByAllItemSize()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsSelectedMember"
    l_0_8 = function(l_200_0)
      if l_200_0 and l_200_0 == MiDKP.UI.BigFoot_87e1203c5898c5451b860784065dbe15 then
        return true
      end
      return false
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "GetSelectedMember"
    l_0_8 = function()
      return MiDKP.UI.BigFoot_87e1203c5898c5451b860784065dbe15
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MemberInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UpdateInfo"
    l_0_8 = function(l_202_0, l_202_1)
      local l_202_2 = l_202_1:GetName()
      l_202_0:Lookup("Image_MemberInfo_Highlight"):Hide()
      l_202_0.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_202_2
      l_202_0:Lookup("Text_MemberInfo_Name"):SetText(l_202_2)
      l_202_0:Lookup("Text_MemberInfo_Class"):SetText(l_202_1:GetClass())
      l_202_0:Lookup("Text_MemberInfo_Reward"):SetText(l_202_1:GetReward())
      if l_202_1:GetReward() > 0 then
        l_202_0:Lookup("Text_MemberInfo_Reward"):SetFontScheme(80)
      else
        if l_202_1:GetReward() < 0 then
          l_202_0:Lookup("Text_MemberInfo_Reward"):SetFontScheme(83)
        end
      else
        l_202_0:Lookup("Text_MemberInfo_Reward"):SetFontScheme(44)
      end
      l_202_0:Lookup("Text_MemberInfo_Score"):SetText(l_202_1:GetScore())
      if l_202_1:GetScore() > 0 then
        l_202_0:Lookup("Text_MemberInfo_Score"):SetFontScheme(80)
      else
        if l_202_1:GetScore() < 0 then
          l_202_0:Lookup("Text_MemberInfo_Score"):SetFontScheme(83)
        end
      else
        l_202_0:Lookup("Text_MemberInfo_Score"):SetFontScheme(44)
      end
      local l_202_3 = l_202_0:Lookup("Handle_MemberInfo_Other")
      l_202_3:Clear()
      local l_202_4 = TimeToDate(l_202_1:GetJoinTime())
      l_202_3:AppendItemFromString(string.format("<Text>text=\"����ʱ�� %04d.%02d.%02d %02d:%02d \" font=189 postype=10</Text>", l_202_4.year, l_202_4.month, l_202_4.day, l_202_4.hour, l_202_4.minute))
      if l_202_1:GetLeaveTime() then
        l_202_4 = TimeToDate(l_202_1:GetLeaveTime())
        l_202_3:AppendItemFromString(string.format("<Text>text=\"����ʱ�� %04d.%02d.%02d %02d:%02d \" font=189 postype=7</Text>", l_202_4.year, l_202_4.month, l_202_4.day, l_202_4.hour, l_202_4.minute))
      end
      l_202_3:SetSizeByAllItemSize()
      l_202_3:FormatAllItemPos()
      l_202_3:Hide()
      l_202_0.BigFoot_1210e713fbe7372fde7a5518a1f280ec = l_202_1
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "EventInfo"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "EventInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Select"
    l_0_8 = function(l_203_0)
      local l_203_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Event"):Lookup("", ""):Lookup("Handle_EventScroll"):Lookup("Handle_EventList")
      if MiDKP.UI.EventInfo.GetSelectedEvent() and not MiDKP.UI.EventInfo.IsSelectedEvent(l_203_0) then
        local l_203_2 = MiDKP.UI.EventInfo.GetSelectedEvent()
        l_203_2:Lookup("Image_EventInfo_Highlight"):Hide()
        l_203_2:Lookup("Image_EventInfo_Highlight"):SetFrame(2)
        l_203_2:Lookup("Image_EventInfo_Highlight"):SetSize(460, 25)
        l_203_2:SetSize(460, 25)
        l_203_2:Lookup("Handle_EventInfo_Other"):Hide()
      end
      MiDKP.UI.BigFoot_3535e4be15b8d6f33d3bb4190f196cf5 = l_203_0
      if l_203_0 then
        l_203_0:Lookup("Image_EventInfo_Highlight"):Show()
        l_203_0:Lookup("Image_EventInfo_Highlight"):SetFrame(1)
        l_203_0:SetSize(460, 40)
        l_203_0:Lookup("Image_EventInfo_Highlight"):SetSize(460, 40)
        l_203_0:Lookup("Handle_EventInfo_Other"):Show()
      end
      l_203_1:FormatAllItemPos()
      l_203_1:SetSizeByAllItemSize()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "EventInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsSelectedEvent"
    l_0_8 = function(l_204_0)
      if l_204_0 and l_204_0 == MiDKP.UI.BigFoot_3535e4be15b8d6f33d3bb4190f196cf5 then
        return true
      end
      return false
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "EventInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "GetSelectedEvent"
    l_0_8 = function()
      return MiDKP.UI.BigFoot_3535e4be15b8d6f33d3bb4190f196cf5
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "EventInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UpdateInfo"
    l_0_8 = function(l_206_0, l_206_1)
      l_206_0.BigFoot_d0708241b607c9a9dd1953c812fadfb7 = l_206_1
      l_206_0:Lookup("Text_EventInfo_Desc"):SetText(l_206_1:GetDesc())
      local l_206_2 = l_206_1:GetScore()
      if l_206_2 >= 0 then
        l_206_0:Lookup("Text_EventInfo_Score"):SetText("��ã�" .. l_206_2)
      else
        l_206_0:Lookup("Text_EventInfo_Score"):SetText("�۳���" .. math.abs(l_206_2))
      end
      l_206_0:Lookup("Text_EventInfo_Score"):AutoSize()
      local l_206_3 = l_206_0:Lookup("Text_EventInfo_Score"):GetSize()
      l_206_0:Lookup("Text_EventInfo_Score"):SetRelPos(435 - l_206_3, 5)
      local l_206_4 = l_206_0:Lookup("Handle_EventInfo_Other")
      l_206_4:Clear()
      local l_206_5 = TimeToDate(l_206_1:GetCreationTime())
      l_206_4:AppendItemFromString(string.format("<Text>text=\"������ %04d.%02d.%02d %02d:%02d\" font=189</Text>", l_206_5.year, l_206_5.month, l_206_5.day, l_206_5.hour, l_206_5.minute))
      l_206_4:AppendItemFromString(string.format("<Text>text=\"�ܹ�%d��\" font=189 x=370 y=0</Text>", l_206_1:GetMemberCount()))
      l_206_4:FormatAllItemPos()
      l_206_4:SetSizeByAllItemSize()
      if MiDKP.UI.EventInfo.GetSelectedEvent() ~= l_206_0 then
        l_206_0:Lookup("Image_EventInfo_Highlight"):Hide()
        l_206_4:Hide()
      end
      l_206_0:FormatAllItemPos()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ItemInfo"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ItemInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Select"
    l_0_8 = function(l_207_0)
      local l_207_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_Item"):Lookup("", ""):Lookup("Handle_ItemScroll"):Lookup("Handle_ItemList")
      if MiDKP.UI.ItemInfo.GetSelectedItem() and not MiDKP.UI.ItemInfo.IsSelectedItem(l_207_0) then
        local l_207_2 = MiDKP.UI.ItemInfo.GetSelectedItem()
        l_207_2:Lookup("Image_ItemInfo_Highlight"):Hide()
        l_207_2:Lookup("Image_ItemInfo_Highlight"):SetFrame(2)
        l_207_2:Lookup("Image_ItemInfo_Highlight"):SetSize(460, 25)
        l_207_2:SetSize(460, 25)
        l_207_2:Lookup("Handle_ItemInfo_Other"):Hide()
      end
      MiDKP.UI.BigFoot_994c9ba769b856c205fb84df1bf794c0 = l_207_0
      if l_207_0 then
        l_207_0:Lookup("Image_ItemInfo_Highlight"):Show()
        l_207_0:Lookup("Image_ItemInfo_Highlight"):SetFrame(1)
        l_207_0:SetSize(460, 40)
        l_207_0:Lookup("Image_ItemInfo_Highlight"):SetSize(460, 40)
        l_207_0:Lookup("Handle_ItemInfo_Other"):Show()
      end
      l_207_1:FormatAllItemPos()
      l_207_1:SetSizeByAllItemSize()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ItemInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsSelectedItem"
    l_0_8 = function(l_208_0)
      if l_208_0 and l_208_0 == MiDKP.UI.BigFoot_994c9ba769b856c205fb84df1bf794c0 then
        return true
      end
      return false
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ItemInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "GetSelectedItem"
    l_0_8 = function()
      return MiDKP.UI.BigFoot_994c9ba769b856c205fb84df1bf794c0
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "ItemInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UpdateInfo"
    l_0_8 = function(l_210_0, l_210_1)
      l_210_0.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_210_1
      l_210_0:Lookup("Text_ItemInfo_Name"):SetText(l_210_1:GetName())
      l_210_0:Lookup("Text_ItemInfo_Score"):SetText("���ѣ�" .. l_210_1:GetScore())
      l_210_0:Lookup("Text_ItemInfo_Score"):AutoSize()
      local l_210_2 = l_210_0:Lookup("Text_ItemInfo_Score"):GetSize()
      l_210_0:Lookup("Text_ItemInfo_Score"):SetRelPos(435 - l_210_2, 5)
      local l_210_3 = l_210_0:Lookup("Handle_ItemInfo_Other")
      l_210_3:Clear()
      local l_210_4 = TimeToDate(l_210_1:GetLootTime())
      l_210_3:AppendItemFromString(string.format("<Text>text=\"������ %04d.%02d.%02d %02d:%02d\" font=189</Text>", l_210_4.year, l_210_4.month, l_210_4.day, l_210_4.hour, l_210_4.minute))
      l_210_3:AppendItemFromString(string.format("<Text>text=\"%s ���\" font=189 x=350 y=0</Text>", l_210_1:GetLooter()))
      local l_210_5 = l_210_3:Lookup(1)
      local l_210_6 = l_210_5:GetSize()
      l_210_5:SetRelPos(430 - l_210_6, 0)
      l_210_3:FormatAllItemPos()
      l_210_3:SetSizeByAllItemSize()
      if MiDKP.UI.ItemInfo.GetSelectedItem() ~= l_210_0 then
        l_210_0:Lookup("Image_ItemInfo_Highlight"):Hide()
        l_210_3:Hide()
      end
      l_210_0:FormatAllItemPos()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPInfo"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Select"
    l_0_8 = function(l_211_0)
      local l_211_1 = Station.Lookup("Normal/MiDKP/PageSet_Tabs/Page_DKP"):Lookup("", ""):Lookup("Handle_DKPScroll"):Lookup("Handle_DKPList")
      if MiDKP.UI.DKPInfo.GetSelectedDKP() and not MiDKP.UI.DKPInfo.IsSelectedDKP(l_211_0) then
        local l_211_2 = MiDKP.UI.DKPInfo.GetSelectedDKP()
        l_211_2:Lookup("Image_DKPInfo_Highlight"):Hide()
        l_211_2:Lookup("Image_DKPInfo_Highlight"):SetFrame(2)
        l_211_2:Lookup("Image_DKPInfo_Highlight"):SetSize(460, 25)
        l_211_2:SetSize(460, 25)
        l_211_2:Lookup("Handle_DKPInfo_Other"):Hide()
      end
      MiDKP.UI.BigFoot_dd43ac28032a458daf156a32f7b1e523 = l_211_0
      if l_211_0 then
        l_211_0:Lookup("Image_DKPInfo_Highlight"):Show()
        l_211_0:Lookup("Image_DKPInfo_Highlight"):SetFrame(1)
        l_211_0:SetSize(460, 40)
        l_211_0:Lookup("Image_DKPInfo_Highlight"):SetSize(460, 40)
        l_211_0:Lookup("Handle_DKPInfo_Other"):Show()
      end
      l_211_1:FormatAllItemPos()
      l_211_1:SetSizeByAllItemSize()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsSelectedDKP"
    l_0_8 = function(l_212_0)
      if l_212_0 and l_212_0 == MiDKP.UI.BigFoot_dd43ac28032a458daf156a32f7b1e523 then
        return true
      end
      return false
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "GetSelectedDKP"
    l_0_8 = function()
      return MiDKP.UI.BigFoot_dd43ac28032a458daf156a32f7b1e523
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "DKPInfo"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UpdateInfo"
    l_0_8 = function(l_214_0, l_214_1)
      l_214_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_214_1
      local l_214_2 = l_214_0:Lookup("Handle_DKPInfo_Other")
      l_214_2:Clear()
      if MiDKP.UI.BigFoot_ca5ee9024fd5eafb4f078bec52aa1616 then
        l_214_0:Lookup("Text_DKPInfo_Name"):SetText(l_214_1.name)
        l_214_0:Lookup("Text_DKPInfo_Class"):SetText(l_214_1.class)
        l_214_0:Lookup("Text_DKPInfo_ScoreTitle"):SetText("��ʷ�� ")
        l_214_0:Lookup("Text_DKPInfo_Score"):SetText(l_214_1.score)
        if l_214_1.score > 0 then
          l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(80)
        elseif l_214_1.score < 0 then
          l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(83)
        else
          l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(44)
        end
      else
        l_214_0:Lookup("Text_DKPInfo_Name"):SetText(l_214_1:GetName())
        l_214_0:Lookup("Text_DKPInfo_Class"):SetText(l_214_1:GetClass())
        l_214_0:Lookup("Text_DKPInfo_ScoreTitle"):SetText("��ǰ�� ")
        l_214_0:Lookup("Text_DKPInfo_Score"):SetText(l_214_1:GetScore())
        if l_214_1:GetScore() > 0 then
          l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(80)
        else
          if l_214_1:GetScore() < 0 then
            l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(83)
          end
        else
          l_214_0:Lookup("Text_DKPInfo_Score"):SetFontScheme(44)
        end
        local l_214_3 = TimeToDate(l_214_1:GetJoinTime())
        l_214_2:AppendItemFromString(string.format("<Text>text=\"����%04d.%02d.%02d %02d:%02d\" postype=10 font=189</Text>", l_214_3.year, l_214_3.month, l_214_3.day, l_214_3.hour, l_214_3.minute))
        if l_214_1:GetLeaveTime() then
          l_214_3 = TimeToDate(l_214_1:GetLeaveTime())
          l_214_2:AppendItemFromString(string.format("<Text>text=\" ����%04d.%02d.%02d %02d:%02d\" postype=7 font=189</Text>", l_214_3.year, l_214_3.month, l_214_3.day, l_214_3.hour, l_214_3.minute))
        end
        l_214_2:AppendItemFromString(string.format("<Text>text=\"��ã�%d\" font=189 x=325 y=0</Text>", l_214_1:GetReward()))
        l_214_2:FormatAllItemPos()
        l_214_2:SetSizeByAllItemSize()
      end
      if MiDKP.UI.DKPInfo.GetSelectedDKP() ~= l_214_0 then
        l_214_0:Lookup("Image_DKPInfo_Highlight"):Hide()
        l_214_2:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.Raid, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = function()
      -- upvalues: l_0_5
      local l_215_0 = this:Lookup("", "")
      local l_215_1 = l_215_0:Lookup("Handle_DKPList")
      l_215_1:Clear()
      local l_215_2 = MiDKP.DKP:GetDKPCount()
      for l_215_6 = 1, l_215_2 do
        l_215_1:AppendItemFromIni(MiDKP.UI.RAID_INI_FILE, "Handle_DKP")
        local l_215_7 = l_215_1:Lookup(l_215_1:GetItemCount() - 1)
        local l_215_8 = MiDKP.DKP:GetDKPByIndex(l_215_6):GetName()
        l_215_7:Lookup("Text_DKP_Name"):SetText(l_0_5(l_215_8, 40))
        l_215_7.BigFoot_00d6fc9c826cd4ce4b18d6e6d4bc2937 = true
        l_215_7.BigFoot_8983c60d66c8593ec7165ea9dbedb584 = l_215_8
        l_215_7:Lookup("Image_DKP_Highlight"):Hide()
      end
      l_215_1:FormatAllItemPos()
      l_215_1:SetSizeByAllItemSize()
      local l_215_9 = l_215_2 * 20
      l_215_0:Lookup("Image_Bg03"):SetSize(8, 100 + l_215_9)
      l_215_0:Lookup("Image_Bg05"):SetSize(8, 100 + l_215_9)
      l_215_0:Lookup("Image_Bg08"):SetRelPos(0, 170 + l_215_9)
      l_215_0:Lookup("Image_Bg07"):SetRelPos(124, 170 + l_215_9)
      l_215_0:Lookup("Image_Bg06"):SetRelPos(373, 170 + l_215_9)
      l_215_0:Lookup("Image_Bg04"):SetSize(365, 100 + l_215_9)
      l_215_0:Lookup("Image_DKPBg"):SetSize(360, 30 + l_215_9)
      this:Lookup("Btn_OK"):SetRelPos(95, 180 + l_215_9)
      this:Lookup("Btn_Cancel"):SetRelPos(215, 180 + l_215_9)
      this:SetSize(378, 250 + l_215_9)
      l_215_0:SetSize(378, 250 + l_215_9)
      l_215_0:FormatAllItemPos()
    end
    l_0_6.OnFrameCreate = l_0_7
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_216_0 = this:GetName()
      if l_216_0 == "Btn_Cancel" then
        MiDKP.UI.Raid.CloseRaidPanel()
      elseif l_216_0 == "Btn_OK" then
        local l_216_1 = this:GetRoot()
        local l_216_2 = l_216_1:Lookup("Edit_Name"):GetText()
        local l_216_3 = MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212
        if not l_216_2 or #l_216_2 == 0 then
          MiDKP.UI.Print("error", "����Ʋ���Ϊ�ա�")
          return 
        end
        if MiDKP.UI.Raid.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
          local l_216_4, l_216_5 = MiDKP.UI.Raid.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:Modify, MiDKP.UI.Raid.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af
          local l_216_6 = l_216_2
          local l_216_7 = nil
          if l_216_3 then
            l_216_7 = l_216_3.BigFoot_8983c60d66c8593ec7165ea9dbedb584
          end
          l_216_4(l_216_5, l_216_6, l_216_7)
          l_216_4 = MiDKP
          l_216_4 = l_216_4.UI
          l_216_4 = l_216_4.Raid
          l_216_4 = l_216_4.CloseRaidPanel
          l_216_4()
          return 
        end
        local l_216_8, l_216_9 = MiDKP.Core:CreateRaid, MiDKP.Core
        local l_216_10 = l_216_2
        local l_216_11 = nil
        if l_216_3 then
          l_216_11 = l_216_3.BigFoot_8983c60d66c8593ec7165ea9dbedb584
        end
        l_216_8(l_216_9, l_216_10, l_216_11)
        l_216_8 = MiDKP
        l_216_8 = l_216_8.UI
        l_216_8 = l_216_8.Raid
        l_216_8 = l_216_8.CloseRaidPanel
        l_216_8()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      if MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 then
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):Hide()
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):SetFrame(3)
      end
      MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 = this
      this:Lookup("Image_DKP_Highlight"):SetFrame(0)
      this:Lookup("Image_DKP_Highlight"):Show()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_00d6fc9c826cd4ce4b18d6e6d4bc2937 and MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 ~= this then
        this:Lookup("Image_DKP_Highlight"):Show()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_00d6fc9c826cd4ce4b18d6e6d4bc2937 and MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 ~= this then
        this:Lookup("Image_DKP_Highlight"):Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "Update"
    l_0_8 = function(l_220_0, l_220_1)
      if MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 then
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):Hide()
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):SetFrame(3)
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 = nil
      end
      l_220_0:Lookup("Edit_Name"):SetText("")
      do
        if l_220_1 then
          if l_220_1:GetDKP() then
            local l_220_2 = l_220_0:Lookup("", ""):Lookup("Handle_DKPList")
            for l_220_6 = 0, l_220_2:GetItemCount() - 1 do
              local l_220_7 = l_220_2:Lookup(l_220_6)
              if l_220_7.BigFoot_8983c60d66c8593ec7165ea9dbedb584 == l_220_1:GetDKP():GetName() then
                MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 = l_220_7
                l_220_7:Lookup("Image_DKP_Highlight"):SetFrame(0)
                l_220_7:Lookup("Image_DKP_Highlight"):Show()
              end
              do break end
            end
          end
        end
        l_220_0:Lookup("Edit_Name"):SetText(l_220_1:GetName())
        l_220_0:Lookup("", ""):Lookup("Text_Title"):SetText("�޸Ļ")
      else
        local l_220_8 = GetCurrentTime()
        local l_220_9 = TimeToDate(l_220_8)
        l_220_0:Lookup("Edit_Name"):SetText(string.format("�Ŷӻ (%04d.%02d.%02d %02d:%02d)", l_220_9.year, l_220_9.month, l_220_9.day, l_220_9.hour, l_220_9.minute))
        l_220_0:Lookup("", ""):Lookup("Text_Title"):SetText("�����")
        local l_220_10 = l_220_0:Lookup("", ""):Lookup("Handle_DKPList")
      end
      if l_220_10:GetItemCount() > 0 then
        local l_220_11 = l_220_10:Lookup(0)
        if MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 then
          MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):Hide()
          MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212:Lookup("Image_DKP_Highlight"):SetFrame(3)
        end
        MiDKP.UI.Raid.BigFoot_69eb4f4ad2e555e4dc911f038f744212 = l_220_11
        l_220_11:Lookup("Image_DKP_Highlight"):SetFrame(0)
        l_220_11:Lookup("Image_DKP_Highlight"):Show()
      end
      Station.SetFocusWindow(l_220_0:Lookup("Edit_Name"))
      MiDKP.UI.Raid.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_220_1
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "OpenRaidPanel"
    l_0_8 = function(l_221_0)
      if not Station.Lookup("Normal1/MiDKP_Raid") then
        local l_221_1, l_221_2, l_221_3, l_221_4, l_221_5, l_221_6, l_221_7, l_221_8, l_221_9, l_221_10, l_221_11 = Wnd.OpenWindow(MiDKP.UI.RAID_INI_FILE, "MiDKP_Raid")
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_221_1:Show()
       -- DECOMPILER ERROR: Confused about usage of registers!

      Station.SetActiveFrame(l_221_1)
       -- DECOMPILER ERROR: Confused about usage of registers!

      MiDKP.UI.Raid.Update(l_221_1, l_221_0)
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_221_1:BringToTop()
      local l_221_12, l_221_13 = , Station.GetClientSize()
      local l_221_14, l_221_15 = , l_221_12:GetSize()
      l_221_12:SetAbsPos((l_221_13 - l_221_15) / 2, (l_221_14 - l_221_12) / 2)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "CloseRaidPanel"
    l_0_8 = function()
      local l_222_0 = Station.Lookup("Normal1/MiDKP_Raid")
      if l_222_0 then
        l_222_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    l_0_7 = "IsRaidPanelOpened"
    l_0_8 = function()
      local l_223_0 = Station.Lookup("Normal1/MiDKP_Raid")
      local l_223_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_223_0 then
        return l_223_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Raid
    MiDKP_Raid = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.Member, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_224_0 = this:GetName()
      if l_224_0 == "Btn_Close" or l_224_0 == "Btn_Cancel" then
        MiDKP.UI.Member.CloseMemberPanel()
      elseif l_224_0 == "Btn_Add" and this:GetRoot().BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af then
        local l_224_1 = this:GetRoot()
        local l_224_2 = l_224_1:Lookup("Edit_Name"):GetText()
        if #l_224_2 == 0 then
          MiDKP.UI.Print("error", "��������Ϊ�ա�")
          return 
        end
        do
          local l_224_3, l_224_4, l_224_5 = l_224_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 or "����"
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_224_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:AddMember(l_224_2, l_224_3)
        MiDKP.UI.Member.CloseMemberPanel()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    l_0_7 = "OnCheckBoxCheck"
    l_0_8 = function()
      if this.disabled then
        return true
      end
      local l_225_0 = this:GetName()
      local l_225_1 = this:GetRoot()
      if l_225_0 == "CheckBox_Shaolin" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "����"
        local l_225_2 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
        l_225_2 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_2.disabled = true
        l_225_2:Check(false)
        l_225_2.disabled = nil
      elseif l_225_0 == "CheckBox_Wanhua" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "��"
        local l_225_3 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
        l_225_3 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_3.disabled = true
        l_225_3:Check(false)
        l_225_3.disabled = nil
      elseif l_225_0 == "CheckBox_Tiance" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "���"
        local l_225_4 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
        l_225_4 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_4.disabled = true
        l_225_4:Check(false)
        l_225_4.disabled = nil
      elseif l_225_0 == "CheckBox_Chunyang" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "����"
        local l_225_5 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
        l_225_5 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_5.disabled = true
        l_225_5:Check(false)
        l_225_5.disabled = nil
      elseif l_225_0 == "CheckBox_Qixiu" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "����"
        local l_225_6 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
        l_225_6 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_6.disabled = true
        l_225_6:Check(false)
        l_225_6.disabled = nil
      elseif l_225_0 == "CheckBox_cangjian" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "�ؽ�"
        local l_225_7 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
        l_225_7 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_7.disabled = true
        l_225_7:Check(false)
        l_225_7.disabled = nil
      elseif l_225_0 == "CheckBox_Wudu" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "�嶾"
        local l_225_8 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
        l_225_8 = l_225_1:Lookup("CheckBox_TangMen")
        l_225_8.disabled = true
        l_225_8:Check(false)
        l_225_8.disabled = nil
      elseif l_225_0 == "CheckBox_TangMen" then
        l_225_1.BigFoot_c72fd7a33d51d9f4185e7fd38082e551 = "����"
        local l_225_9 = l_225_1:Lookup("CheckBox_Shaolin")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_Wanhua")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_Tiance")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_Chunyang")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_Qixiu")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_cangjian")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
        l_225_9 = l_225_1:Lookup("CheckBox_Wudu")
        l_225_9.disabled = true
        l_225_9:Check(false)
        l_225_9.disabled = nil
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    l_0_7 = "OpenMemberPanel"
    l_0_8 = function(l_226_0)
      if not Station.Lookup("Normal1/MiDKP_Member") then
        local l_226_1, l_226_2, l_226_3, l_226_4, l_226_5 = Wnd.OpenWindow(MiDKP.UI.MEMBER_INI_FILE, "MiDKP_Member")
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_226_1.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_226_0
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_226_1:Show()
      local l_226_6, l_226_7 = , Station.GetClientSize()
      local l_226_8, l_226_9 = , l_226_6:GetSize()
      l_226_6:SetAbsPos((l_226_7 - l_226_9) / 2, (l_226_8 - l_226_6) / 2)
      Station.SetFocusWindow(l_226_6:Lookup("Edit_Name"))
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    l_0_7 = "CloseMemberPanel"
    l_0_8 = function()
      local l_227_0 = Station.Lookup("Normal1/MiDKP_Member")
      if l_227_0 then
        l_227_0:Lookup("Edit_Name"):SetText("")
        l_227_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    l_0_7 = "IsMemberPanelOpened"
    l_0_8 = function()
      local l_228_0 = Station.Lookup("Normal1/MiDKP_Member")
      local l_228_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_228_0 then
        return l_228_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Member
    MiDKP_Member = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.Event, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "Update"
    l_0_8 = function(l_229_0, l_229_1)
      MiDKP.UI.Event.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_229_0
      MiDKP.UI.Event.BigFoot_d0708241b607c9a9dd1953c812fadfb7 = l_229_1
      MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db = {}
      local l_229_2 = Station.Lookup("Normal1/MiDKP_Event")
      local l_229_3 = l_229_2:Lookup("", "")
      local l_229_4 = l_229_3:Lookup("Handle_MemberList")
      l_229_4:Clear()
      local l_229_5 = l_229_0:GetAllMemberNames()
      local l_229_6 = 1
      for l_229_10,l_229_11 in ipairs(l_229_5) do
        local l_229_12 = l_229_0:GetMember(l_229_11)
        l_229_4:AppendItemFromIni(MiDKP.UI.EVENT_INI_FILE, "Handle_Member")
        local l_229_13 = l_229_4:Lookup(l_229_4:GetItemCount() - 1)
        l_229_13.BigFoot_1210e713fbe7372fde7a5518a1f280ec = l_229_12
        if not l_229_12:IsInRaid() then
          l_229_13:Lookup("Text_MemberName"):SetText(l_229_12:GetName() .. "(��)")
        else
          if not l_229_12:IsOnLine() then
            l_229_13:Lookup("Text_MemberName"):SetText(l_229_12:GetName() .. "(��)")
          end
        else
          l_229_13:Lookup("Text_MemberName"):SetText(l_229_12:GetName())
        end
        local l_229_14 = 10 + 140 * ((l_229_10 - 1) % 5)
        local l_229_15 = 30 * math.floor((l_229_10 - 1) / 5)
        l_229_13:SetRelPos(l_229_14, l_229_15)
        if l_229_10 ~= 1 and (l_229_10 - 1) % 5 == 0 then
          l_229_6 = l_229_6 + 1
        end
        l_229_13:SetSize(140, 30)
        if l_229_1 then
          local l_229_16 = nil
          for l_229_20,l_229_21 in ipairs(l_229_1:GetMembers()) do
            if l_229_21 == l_229_11 then
              l_229_16 = true
              do break end
            end
          end
          if l_229_16 then
            MiDKP.UI.Event.Check(l_229_13)
          else
            MiDKP.UI.Event.UnCheck(l_229_13)
          end
        else
          MiDKP.UI.Event.UnCheck(l_229_13)
        end
      end
      do
        local l_229_22, l_229_23 = 30 * (l_229_6)
        l_229_23(l_229_4)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_4, 700, l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 710, 10 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 8, 120 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 8, 120 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 755, 120 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 763, 190 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 124, 190 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 0, 190 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_3)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 250, 215 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_23, 450, 215 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_229_23(l_229_2, 770, 272 + l_229_22)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_229_1 then
          l_229_23(l_229_23, "�޸��¼�")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, l_229_1:GetDesc())
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, l_229_1:GetScore())
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, l_229_1:IsBossEvent())
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, not l_229_1:IsAutoEvent())
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, not l_229_1:IsItemEvent())
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, not l_229_1:IsAutoEvent())
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        else
          l_229_23(l_229_23, "�����¼�")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, true)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, true)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_229_23(l_229_23, true)
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

      end
      l_229_23(l_229_2:Lookup("Edit_Name"))
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "Check"
    l_0_8 = function(l_230_0)
      if l_230_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_230_0:Lookup("Image_Check"):SetFrame(7)
      else
        l_230_0:Lookup("Image_Check"):SetFrame(6)
      end
      l_230_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = true
      local l_230_1 = nil
      local l_230_2 = l_230_0.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName()
      for l_230_6,l_230_7 in ipairs(MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db) do
        if l_230_2 == l_230_7 then
          l_230_1 = true
          do break end
        end
      end
      if not l_230_1 then
        table.insert(MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db, l_230_2)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "UnCheck"
    l_0_8 = function(l_231_0)
      if l_231_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_231_0:Lookup("Image_Check"):SetFrame(3)
      else
        l_231_0:Lookup("Image_Check"):SetFrame(5)
      end
      l_231_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = nil
      local l_231_1 = l_231_0.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName()
      for l_231_5,l_231_6 in ipairs(MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db) do
        if l_231_1 == l_231_6 then
          table.remove(MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db, l_231_5)
          do break end
        end
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "CheckMember"
    l_0_8 = function(l_232_0)
      local l_232_1 = Station.Lookup("Normal1/MiDKP_Event")
      local l_232_2 = l_232_1:Lookup("", "")
      local l_232_3 = l_232_2:Lookup("Handle_MemberList")
      for l_232_7 = 0, l_232_3:GetItemCount() do
        do
          local l_232_8 = l_232_3:Lookup(l_232_7)
          if l_232_8.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName() == l_232_0 then
            MiDKP.UI.Event.Check(l_232_8)
          end
          do break end
        end
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          MiDKP.UI.Event.UnCheck(this)
        end
      else
        MiDKP.UI.Event.Check(this)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(7)
        else
          this:Lookup("Image_Check"):SetFrame(3)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = true
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(6)
        else
          this:Lookup("Image_Check"):SetFrame(5)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = nil
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_236_0 = this:GetName()
      local l_236_1 = this:GetRoot()
      if l_236_0 == "Btn_Cancel" or l_236_0 == "Btn_Close" then
        l_236_1:Lookup("Edit_Name"):SetText("")
        l_236_1:Lookup("Edit_Score"):SetText("")
        l_236_1:Lookup("CheckBox_FirstTwoParty"):Check(false)
        l_236_1:Lookup("CheckBox_AllRaidMember"):Check(false)
        l_236_1:Lookup("CheckBox_AllMember"):Check(false)
        MiDKP.UI.Event.CloseEventPanel()
      elseif l_236_0 == "Btn_OK" then
        local l_236_2 = this:GetRoot()
        local l_236_3 = l_236_2:Lookup("Edit_Name"):GetText()
        local l_236_4 = tonumber(l_236_2:Lookup("Edit_Score"):GetText())
        if not l_236_3 or #l_236_3 == 0 then
          MiDKP.UI.Print("error", "�¼�������Ϊ�ա�")
          return 
        end
        if not l_236_4 then
          MiDKP.UI.Print("error", "��������Ϊ��ֵ��")
          return 
        end
        if #MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db == 0 then
          MiDKP.UI.Print("error", "�¼���Ա����Ϊ�ա�")
          return 
        end
        if MiDKP.UI.Event.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
          MiDKP.UI.Event.BigFoot_d0708241b607c9a9dd1953c812fadfb7:Modify(l_236_3, l_236_4, MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db, l_236_2:Lookup("CheckBox_Boss"):IsCheckBoxChecked())
        else
          MiDKP.UI.Event.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:CreateEvent(l_236_3, l_236_4, MiDKP.UI.Event.BigFoot_fe59e32362f6c11a9ecb659fa153c3db, l_236_2:Lookup("CheckBox_Boss"):IsCheckBoxChecked())
        end
        l_236_2:Lookup("Edit_Name"):SetText("")
        l_236_2:Lookup("Edit_Score"):SetText("")
        l_236_2:Lookup("CheckBox_FirstTwoParty"):Check(false)
        l_236_2:Lookup("CheckBox_AllRaidMember"):Check(false)
        l_236_2:Lookup("CheckBox_AllMember"):Check(false)
        MiDKP.UI.Event.CloseEventPanel()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OnCheckBoxCheck"
    l_0_8 = function()
      if this.disabled then
        return 
      end
      local l_237_0 = this:GetName()
      if l_237_0 == "CheckBox_FirstTwoParty" then
        local l_237_1 = this:GetRoot()
        local l_237_2 = l_237_1:Lookup("", ""):Lookup("Handle_MemberList")
        for l_237_6 = 0, l_237_2:GetItemCount() - 1 do
          local l_237_7 = l_237_2:Lookup(l_237_6)
          if l_237_7.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetParty() == 1 or l_237_7.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetParty() == 2 then
            MiDKP.UI.Event.Check(l_237_7)
          else
            MiDKP.UI.Event.UnCheck(l_237_7)
          end
        end
        local l_237_8 = l_237_1:Lookup("CheckBox_AllRaidMember")
        l_237_8.disabled = true
        l_237_8:Check(false)
        l_237_8.disabled = nil
        local l_237_9 = l_237_1:Lookup("CheckBox_AllMember")
        l_237_9.disabled = true
        l_237_9:Check(false)
        l_237_9.disabled = nil
      elseif l_237_0 == "CheckBox_AllRaidMember" then
        local l_237_10 = this:GetRoot()
        local l_237_11 = l_237_10:Lookup("", ""):Lookup("Handle_MemberList")
        for l_237_15 = 0, l_237_11:GetItemCount() - 1 do
          local l_237_16 = l_237_11:Lookup(l_237_15)
          if l_237_16.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetParty() >= 1 and l_237_16.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetParty() <= 5 then
            MiDKP.UI.Event.Check(l_237_16)
          else
            MiDKP.UI.Event.UnCheck(l_237_16)
          end
        end
        local l_237_17 = l_237_10:Lookup("CheckBox_FirstTwoParty")
        l_237_17.disabled = true
        l_237_17:Check(false)
        l_237_17.disabled = nil
        local l_237_18 = l_237_10:Lookup("CheckBox_AllMember")
        l_237_18.disabled = true
        l_237_18:Check(false)
        l_237_18.disabled = nil
      elseif l_237_0 == "CheckBox_AllMember" then
        local l_237_19 = this:GetRoot()
        local l_237_20 = l_237_19:Lookup("", ""):Lookup("Handle_MemberList")
        for l_237_24 = 0, l_237_20:GetItemCount() - 1 do
          local l_237_25 = l_237_20:Lookup(l_237_24)
          MiDKP.UI.Event.Check(l_237_25)
        end
        local l_237_26 = l_237_19:Lookup("CheckBox_FirstTwoParty")
        l_237_26.disabled = true
        l_237_26:Check(false)
        l_237_26.disabled = nil
        local l_237_27 = l_237_19:Lookup("CheckBox_AllRaidMember")
        l_237_27.disabled = true
        l_237_27:Check(false)
        l_237_27.disabled = nil
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "OpenEventPanel"
    l_0_8 = function(l_238_0, l_238_1)
      if not Station.Lookup("Normal1/MiDKP_Event") then
        local l_238_2, l_238_3, l_238_4, l_238_5, l_238_6, l_238_7 = Wnd.OpenWindow(MiDKP.UI.EVENT_INI_FILE, "MiDKP_Event")
      end
      MiDKP.UI.Event.Update(l_238_0, l_238_1)
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_238_2:Show()
      local l_238_8, l_238_9 = , Station.GetClientSize()
      local l_238_10, l_238_11 = , l_238_8:GetSize()
      l_238_8:SetAbsPos((l_238_9 - l_238_11) / 2, (l_238_10 - l_238_8) / 2)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "CloseEventPanel"
    l_0_8 = function()
      local l_239_0 = Station.Lookup("Normal1/MiDKP_Event")
      if l_239_0 then
        l_239_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    l_0_7 = "IsEventPanelOpened"
    l_0_8 = function()
      local l_240_0 = Station.Lookup("Normal1/MiDKP_Event")
      local l_240_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_240_0 then
        return l_240_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Event
    MiDKP_Event = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.Item, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "Update"
    l_0_8 = function(l_241_0, l_241_1)
      MiDKP.UI.Item.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_241_0
      MiDKP.UI.Item.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_241_1
      local l_241_2 = Station.Lookup("Normal1/MiDKP_Item")
      local l_241_3 = l_241_2:Lookup("", "")
      local l_241_4 = l_241_3:Lookup("Handle_MemberList")
      l_241_4:Clear()
      MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef = nil
      local l_241_5 = l_241_0:GetAllMemberNames()
      local l_241_6 = 1
      for l_241_10,l_241_11 in ipairs(l_241_5) do
        local l_241_12 = l_241_0:GetMember(l_241_11)
        l_241_4:AppendItemFromIni(MiDKP.UI.EVENT_INI_FILE, "Handle_Member")
        local l_241_13 = l_241_4:Lookup(l_241_4:GetItemCount() - 1)
        l_241_13.BigFoot_1210e713fbe7372fde7a5518a1f280ec = l_241_12
        if not l_241_12:IsInRaid() then
          l_241_13:Lookup("Text_MemberName"):SetText(l_241_12:GetName() .. "(��)")
        else
          if not l_241_12:IsOnLine() then
            l_241_13:Lookup("Text_MemberName"):SetText(l_241_12:GetName() .. "(��)")
          end
        else
          l_241_13:Lookup("Text_MemberName"):SetText(l_241_12:GetName())
        end
        local l_241_14 = 10 + 140 * ((l_241_10 - 1) % 5)
        local l_241_15 = 30 * math.floor((l_241_10 - 1) / 5)
        l_241_13:SetRelPos(l_241_14, l_241_15)
        if l_241_10 ~= 1 and (l_241_10 - 1) % 5 == 0 then
          l_241_6 = l_241_6 + 1
        end
        l_241_13:SetSize(140, 30)
        if l_241_1 and l_241_1:GetLooter() == l_241_12:GetName() then
          MiDKP.UI.Item.Check(l_241_13)
        else
          MiDKP.UI.Item.UnCheck(l_241_13)
        end
      end
      do
        local l_241_16, l_241_30 = 30 * (l_241_6)
        l_241_30(l_241_4)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_4, 700, l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 710, 10 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 8, 90 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 8, 90 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 755, 90 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 763, 160 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 124, 160 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 0, 160 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_3)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 250, 185 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_30, 450, 185 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_241_30(l_241_2, 770, 242 + l_241_16)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_241_1 then
          l_241_30(l_241_30, "�޸���Ʒ")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          do
            local l_241_17 = nil
            l_241_17 = type
            l_241_17 = l_241_17(l_241_30)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_241_17 == "string" then
              l_241_17(l_241_17, l_241_1:GetName())
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            else
              if l_241_17 == "table" then
                if not l_241_17 or l_241_17 == 0 then
                  local l_241_18 = nil
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  l_241_18(l_241_18)
                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                   -- DECOMPILER ERROR: Overwrote pending register.

                  local l_241_19, l_241_20 = l_241_18
                  l_241_20 = "["
                  l_241_20 = l_241_20 .. l_241_17.szName .. "]"
                  local l_241_21 = nil
                  local l_241_22 = nil
                  l_241_22 = l_241_17.szName
                  l_241_22 = l_241_30.TabType
                  l_241_22 = l_241_30.TabIndex
                  l_241_18(l_241_19, l_241_20, l_241_21)
                  l_241_21 = {type = "iteminfo", text = l_241_22, version = 0, tabtype = l_241_22, index = l_241_22}
                end
              end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            else
              local l_241_23, l_241_24 = nil
              l_241_24 = Table_GetSegmentName
              l_241_24 = l_241_24(l_241_17, l_241_23)
              local l_241_25 = nil
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_241_25(l_241_25)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              local l_241_26, l_241_27 = l_241_25
              l_241_27 = "["
              l_241_27 = l_241_27 .. l_241_24 .. "]"
              local l_241_28 = nil
              local l_241_29 = nil
              l_241_29 = l_241_30.TabType
              l_241_29 = l_241_30.TabIndex
              l_241_29 = l_241_30.BookID
              l_241_25(l_241_26, l_241_27, l_241_28)
              l_241_28 = {type = "book", text = l_241_24, version = 0, tabtype = l_241_29, index = l_241_29, bookinfo = l_241_29}
            end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_241_17(l_241_17, l_241_1:GetScore())
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_241_17(l_241_17, l_241_1:IsSplitScore())
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_241_17 then
              l_241_17(l_241_17, false)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            else
              l_241_17(l_241_17, true)
            end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_241_17(l_241_2:Lookup("Edit_Score"))
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        else
          l_241_30(l_241_30, false)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_241_30(l_241_30, "")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_241_30(l_241_30, true)
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_241_30(l_241_30, "0")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          l_241_30(l_241_30, "������Ʒ")
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

        end
        l_241_30(l_241_2:Lookup("Edit_Name"))
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "Check"
    l_0_8 = function(l_242_0)
      if MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef then
        MiDKP.UI.Item.UnCheck(MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef)
      end
      if l_242_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_242_0:Lookup("Image_Check"):SetFrame(7)
      else
        l_242_0:Lookup("Image_Check"):SetFrame(6)
      end
      l_242_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = true
      MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef = l_242_0
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "UnCheck"
    l_0_8 = function(l_243_0)
      if l_243_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_243_0:Lookup("Image_Check"):SetFrame(3)
      else
        l_243_0:Lookup("Image_Check"):SetFrame(5)
      end
      l_243_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = nil
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(7)
        else
          this:Lookup("Image_Check"):SetFrame(3)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = true
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(6)
        else
          this:Lookup("Image_Check"):SetFrame(5)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = nil
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      if this.BigFoot_1210e713fbe7372fde7a5518a1f280ec then
        MiDKP.UI.Item.Check(this)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_247_0 = this:GetName()
      if l_247_0 == "Btn_Cancel" or l_247_0 == "Btn_Close" then
        local l_247_1 = this:GetRoot()
        l_247_1:Lookup("Edit_Name"):SetText("")
        l_247_1:Lookup("Edit_Score"):SetText("")
        MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef = nil
        MiDKP.UI.Item.CloseItemPanel()
      elseif l_247_0 == "Btn_OK" then
        local l_247_2 = this:GetRoot()
        local l_247_3 = l_247_2:Lookup("Edit_Name"):GetTextStruct()
        local l_247_4 = {}
        if #l_247_3 > 0 and (l_247_3[1].type == "iteminfo" or l_247_3[1].type == "book") then
          l_247_4.TabType = l_247_3[1].tabtype
          l_247_4.TabIndex = l_247_3[1].index
          l_247_4.BookID = l_247_3[1].bookinfo or 0
        else
          l_247_4 = l_247_2:Lookup("Edit_Name"):GetText()
        end
        local l_247_5 = tonumber(l_247_2:Lookup("Edit_Score"):GetText())
        if not l_247_4 or ((#l_247_4 == 0 and type(l_247_4) == "string") or type(l_247_4) ~= "table" or not l_247_4.TabType) then
          MiDKP.UI.Print("error", "��Ʒ���Ʋ���Ϊ�ա�")
          return 
        end
        if not l_247_5 then
          MiDKP.UI.Print("error", "��Ʒ��ֵ����Ϊ���֡�")
          return 
        end
        if not MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef then
          MiDKP.UI.Print("error", "��ѡ����Ʒ�����Ա��")
          return 
        end
        if MiDKP.UI.Item.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          MiDKP.UI.Item.BigFoot_2e00ffac12aadb3a1fd865993ec505b9:Modify(l_247_4, MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName(), l_247_5, l_247_2:Lookup("CheckBox_SplitScore"):IsCheckBoxChecked())
        else
          MiDKP.UI.Item.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af:CreateItem(l_247_4, MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef.BigFoot_1210e713fbe7372fde7a5518a1f280ec:GetName(), l_247_5, l_247_2:Lookup("CheckBox_SplitScore"):IsCheckBoxChecked())
        end
        l_247_2:Lookup("Edit_Name"):SetText("")
        l_247_2:Lookup("Edit_Score"):SetText("")
        MiDKP.UI.Item.BigFoot_9c0abab3f01ac09dff868a5ce36a80ef = nil
        MiDKP.UI.Item.CloseItemPanel()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "OpenItemPanel"
    l_0_8 = function(l_248_0, l_248_1)
      if not Station.Lookup("Normal1/MiDKP_Item") then
        local l_248_2, l_248_3, l_248_4, l_248_5, l_248_6, l_248_7 = Wnd.OpenWindow(MiDKP.UI.ITEM_INI_FILE, "MiDKP_Item")
      end
      MiDKP.UI.Item.Update(l_248_0, l_248_1)
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_248_2:Show()
      local l_248_8, l_248_9 = , Station.GetClientSize()
      local l_248_10, l_248_11 = , l_248_8:GetSize()
      l_248_8:SetAbsPos((l_248_9 - l_248_11) / 2, (l_248_10 - l_248_8) / 2)
      MiDKP.UI.Item.BigFoot_926a8632d536cb9f0cf1024ad10c3071 = EditBox_AppendLinkItem
      MiDKP.UI.Item.BigFoot_eb3e0de64de43487b07adb084d1ff6a3 = EditBox_AppendLinkItemInfo
      EditBox_AppendLinkItem = function(l_249_0, l_249_1)
        if l_249_1 then
          local l_249_2, l_249_3, l_249_4, l_249_5 = GetPlayerItem(GetClientPlayer(), l_249_0, l_249_1)
        do
          else
            local l_249_6 = GetItem(l_249_0)
            if l_249_6.nGenre == ITEM_GENRE.BOOK then
              local l_249_7, l_249_8 = Station.Lookup("Normal1/MiDKP_Item/Edit_Name"), GlobelRecipeID2BookID(l_249_6.nStackNum)
              local l_249_9 = nil
              local l_249_10, l_249_11 = Table_GetSegmentName(l_249_8, R8_PC29), l_249_7:InsertObj
              local l_249_12 = R8_PC29
              do
                local l_249_13 = "[" .. l_249_10 .. "]"
                l_249_11(l_249_12, l_249_13, {type = "book", text = l_249_10, version = l_249_6.nVersion, tabtype = l_249_6.dwTabType, index = l_249_6.dwIndex, bookinfo = l_249_6.nStackNum})
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            else
              local l_249_14, l_249_15 = , l_249_7:InsertObj
               -- DECOMPILER ERROR: Overwrote pending register.

              local l_249_16 = l_249_7
              local l_249_17 = "[" .. l_249_6.szName .. l_249_12
              l_249_15(l_249_16, l_249_17, {type = "iteminfo", verion = l_249_6.nVersion, tabtype = l_249_6.dwTabType, index = l_249_6.dwIndex})
            end
            return true
          end
           -- WARNING: missing end command somewhere! Added here
        end
        -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 15 
      end
      EditBox_AppendLinkItemInfo = function(l_250_0, l_250_1, l_250_2, l_250_3)
        local l_250_4 = GetItemInfo(l_250_1, l_250_2)
        local l_250_5 = Station.Lookup("Normal1/MiDKP_Item/Edit_Name")
        if l_250_4.nGenre == ITEM_GENRE.BOOK then
          local l_250_6, l_250_7 = GlobelRecipeID2BookID(BigFoot_8ea5df5997209ee25345c8605a366742.nStackNum)
          local l_250_8 = Table_GetSegmentName(l_250_6, BigFoot_a2b2ab62e5e30aaf9b618cb433123527)
          local l_250_9, l_250_10 = l_250_5:InsertObj, l_250_5
          local l_250_11 = "[" .. l_250_8 .. "]"
          local l_250_12 = {}
          l_250_12.type = "book"
          l_250_12.text = l_250_8
          l_250_12.version = 0
          l_250_12.tabtype = l_250_1
          l_250_12.index = l_250_2
          l_250_12.bookinfo = l_250_3
          l_250_9(l_250_10, l_250_11, l_250_12)
        else
          local l_250_13, l_250_14 = l_250_5:InsertObj, l_250_5
          local l_250_15 = "[" .. l_250_4.szName .. "]"
          local l_250_16 = {}
          l_250_16.type = "iteminfo"
          l_250_16.text = l_250_4.szName
          l_250_16.version = 0
          l_250_16.tabtype = l_250_1
          l_250_16.index = l_250_2
          l_250_13(l_250_14, l_250_15, l_250_16)
        end
        return true
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "CloseItemPanel"
    l_0_8 = function()
      local l_249_0 = Station.Lookup("Normal1/MiDKP_Item")
      if l_249_0 then
        l_249_0:Hide()
      end
      EditBox_AppendLinkItem = MiDKP.UI.Item.BigFoot_926a8632d536cb9f0cf1024ad10c3071
      EditBox_AppendLinkItemInfo = MiDKP.UI.Item.BigFoot_eb3e0de64de43487b07adb084d1ff6a3
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    l_0_7 = "IsItemPanelOpened"
    l_0_8 = function()
      local l_250_0 = Station.Lookup("Normal1/MiDKP_Item")
      local l_250_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_250_0 then
        return l_250_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Item
    MiDKP_Item = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.IgnoreItems, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = function()
      MiDKP.UI.IgnoreItems.UpdateList()
    end
    l_0_6.OnFrameCreate = l_0_7
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "UpdateList"
    l_0_8 = function()
      local l_252_0 = Station.Lookup("Normal1/MiDKP_IgnoreItems")
      local l_252_1 = l_252_0:Lookup("", ""):Lookup("Handle_Scroll"):Lookup("Handle_ItemList")
      l_252_1:Clear()
      if not MiDKP.Config:GetValue("IgnoreItems") then
        local l_252_2, l_252_3, l_252_10, l_252_11, l_252_12, l_252_20 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      for l_252_7,l_252_8 in ipairs(l_252_2) do
        local l_252_4 = nil
        l_252_1:AppendItemFromIni(MiDKP.UI.IGNORE_ITEMS_INI_FILE, "Handle_Item")
        l_252_1:Lookup(l_252_1:GetItemCount() - 1).BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_252_9
        l_252_1:Lookup(l_252_1:GetItemCount() - 1):Lookup("Image_Item_Highlight"):Hide()
        l_252_1:Lookup(l_252_1:GetItemCount() - 1):Lookup("Text_Item_Name"):SetText(l_252_9)
      end
      l_252_1:SetSizeByAllItemSize()
      l_252_1:FormatAllItemPos()
      local l_252_13, l_252_21 = , l_252_1:GetSize()
      local l_252_14, l_252_22 = math.floor((l_252_1 - 290) / 20) + 1
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_252_15, l_252_23 = nil
      l_252_15, l_252_23 = l_252_22:SetStepCount, l_252_22
      do
        local l_252_16, l_252_17, l_252_24, l_252_25 = nil
        do
          if l_252_14 > 0 then
            local l_252_18, l_252_19 = nil
        end
        if l_252_14 > 0 then
          end
        end
        l_252_16 = 0
        l_252_15(l_252_23, l_252_16)
        l_252_15, l_252_23 = l_252_0:Lookup, l_252_0
        l_252_16 = "Btn_ItemsUp"
        l_252_15 = l_252_15(l_252_23, l_252_16)
        l_252_23, l_252_16 = l_252_0:Lookup, l_252_0
        l_252_17 = "Btn_ItemsDown"
        l_252_23 = l_252_23(l_252_16, l_252_17)
        if l_252_14 > 0 then
          l_252_16, l_252_17 = l_252_15:Show, l_252_15
          l_252_16(l_252_17)
          l_252_16, l_252_17 = l_252_23:Show, l_252_23
          l_252_16(l_252_17)
        else
          l_252_16, l_252_17 = l_252_15:Hide, l_252_15
          l_252_16(l_252_17)
          l_252_16, l_252_17 = l_252_23:Hide, l_252_23
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        l_252_16(l_252_17)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 and MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 ~= this then
        this:Lookup("Image_Item_Highlight"):Show()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 and MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 ~= this then
        this:Lookup("Image_Item_Highlight"):Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
        if MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 then
          MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656:Lookup("Image_Item_Highlight"):Hide()
          MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656:Lookup("Image_Item_Highlight"):SetFrame(3)
        end
        this:Lookup("Image_Item_Highlight"):Show()
        this:Lookup("Image_Item_Highlight"):SetFrame(2)
        MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 = this
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_256_0 = this:GetName()
      if l_256_0 == "Btn_Close" or l_256_0 == "Btn_Cancel" then
        MiDKP.UI.IgnoreItems.CloseIgnoreItemsPanel()
      elseif l_256_0 == "Btn_Add" then
        local l_256_1 = this:GetParent():Lookup("Edit_ItemName"):GetText()
        if #l_256_1 == 0 then
          MiDKP.UI.Print("error", "��Ʒ���Ʋ���Ϊ�ա�")
          return 
        end
        if not MiDKP.Config:GetValue("IgnoreItems") then
          local l_256_2, l_256_3, l_256_4, l_256_5, l_256_6, l_256_7 = {}
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        table.insert(l_256_2, l_256_1)
         -- DECOMPILER ERROR: Confused about usage of registers!

        MiDKP.Config:SetValue("IgnoreItems", l_256_2)
        MiDKP.UI.IgnoreItems.UpdateList()
        this:GetParent():Lookup("Edit_ItemName"):SetText("")
      elseif l_256_0 == "Btn_Delete" and MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 then
        local l_256_8 = MiDKP.Config:GetValue("IgnoreItems")
        for l_256_12,l_256_13 in ipairs(l_256_8) do
          if l_256_13 == MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
            table.remove(l_256_8, l_256_12)
            MiDKP.Config:SetValue("IgnoreItems", l_256_8)
            do break end
          end
        end
        MiDKP.UI.IgnoreItems.BigFoot_37aa9b7ad5c522c529716fb922bd4656 = nil
        MiDKP.UI.IgnoreItems.UpdateList()
      end
      do return end
      if l_256_0 == "Btn_Default" then
        MiDKP.Config:SetValue("IgnoreItems", {})
        MiDKP.UI.IgnoreItems.UpdateList()
      elseif l_256_0 == "Btn_ItemsUp" then
        this:GetParent():Lookup("Scroll_Items"):ScrollPrev(1)
      elseif l_256_0 == "Btn_ItemsDown" then
        this:GetParent():Lookup("Scroll_Items"):ScrollNext(1)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnScrollBarPosChanged"
    l_0_8 = function()
      local l_257_0 = this:GetScrollPos()
      local l_257_1 = Station.Lookup("Normal1/MiDKP_IgnoreItems")
      local l_257_2 = l_257_1:Lookup("", ""):Lookup("Handle_Scroll")
      l_257_2:SetItemStartRelPos(0, -l_257_0 * 20)
      if l_257_0 == 0 then
        l_257_1:Lookup("Btn_ItemsUp"):Enable(0)
      else
        l_257_1:Lookup("Btn_ItemsUp"):Enable(1)
      end
      if l_257_0 == this:GetStepCount() then
        l_257_1:Lookup("Btn_ItemsDown"):Enable(0)
      else
        l_257_1:Lookup("Btn_ItemsDown"):Enable(1)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OnItemMouseWheel"
    l_0_8 = function()
      local l_258_0 = this:GetName()
      if l_258_0 == "Handle_Scroll" then
        this:GetRoot():Lookup("Scroll_Items"):ScrollNext(Station.GetMessageWheelDelta())
        return 1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "OpenIgnoreItemsPanel"
    l_0_8 = function()
      if not Station.Lookup("Normal1/MiDKP_IgnoreItems") then
        local l_259_0, l_259_1, l_259_2, l_259_3, l_259_4 = Wnd.OpenWindow(MiDKP.UI.IGNORE_ITEMS_INI_FILE, "MiDKP_IgnoreItems")
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_259_0:Show()
      local l_259_5, l_259_6 = , Station.GetClientSize()
      local l_259_7, l_259_8 = , l_259_5:GetSize()
      l_259_5:SetAbsPos((l_259_6 - l_259_8) / 2, (l_259_7 - l_259_5) / 2)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "CloseIgnoreItemsPanel"
    l_0_8 = function()
      local l_260_0 = Station.Lookup("Normal1/MiDKP_IgnoreItems")
      if l_260_0 then
        l_260_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    l_0_7 = "IsIgnoreItemsPanelOpened"
    l_0_8 = function()
      local l_261_0 = Station.Lookup("Normal1/MiDKP_IgnoreItems")
      local l_261_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_261_0 then
        return l_261_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.IgnoreItems
    MiDKP_IgnoreItems = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6[l_0_7], l_0_8 = l_0_8, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = function()
      local l_262_0 = MiDKP.DKP:GetDKPNames()
      local l_262_1 = this:Lookup("", "")
      local l_262_2 = l_262_1:Lookup("Handle_DKPList")
      l_262_2:Clear()
      local l_262_3 = 1
      for l_262_7,l_262_8 in ipairs(l_262_0) do
        l_262_2:AppendItemFromIni(MiDKP.UI.MSGCONFIG_INI_FILE, "Handle_DKP")
        local l_262_9 = l_262_2:Lookup(l_262_2:GetItemCount() - 1)
        l_262_9:Lookup("Text_DKPName"):SetText(l_262_8)
        l_262_9.BigFoot_f8c6f4951c524600d5984ab47a0d8393 = l_262_8
        local l_262_10 = 250 * ((l_262_7 - 1) % 3)
        local l_262_11 = 50 * math.floor((l_262_7 - 1) / 3)
        l_262_9:SetRelPos(l_262_10, l_262_11)
        if l_262_7 ~= 1 and (l_262_7 - 1) % 5 == 0 then
          l_262_3 = l_262_3 + 1
        end
        if MiDKP.Config:GetValue("BanedDKP" .. l_262_8) then
          MiDKP.UI.MsgConfig.UnCheck(l_262_9, true)
        else
          MiDKP.UI.MsgConfig.Check(l_262_9, true)
        end
      end
      local l_262_12, l_262_22 = 50 * (l_262_3)
      l_262_22(l_262_2)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_2, 700, l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 8, 230 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 8, 230 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 755, 230 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 763, 300 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 124, 300 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 0, 300 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_1)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 350, 335 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_262_22(l_262_22, 770, 386 + l_262_12)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      do
        local l_262_13, l_262_23 = nil
        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        local l_262_14, l_262_15 = nil
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_14 = l_262_14(l_262_15, "DefaultMessageChannel")
        l_262_15 = PLAYER_TALK_CHANNEL
        l_262_15 = l_262_15.RAID
        l_262_14 = l_262_14 == l_262_15
        l_262_13(l_262_23, l_262_14)
        l_262_22.disabled = nil
        l_262_13 = this
        l_262_13, l_262_23 = l_262_13:Lookup, l_262_13
        l_262_14 = "CheckBox_Guild"
        l_262_13 = l_262_13(l_262_23, l_262_14)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_14 = l_262_14(l_262_15, "DefaultMessageChannel")
        l_262_15 = PLAYER_TALK_CHANNEL
        l_262_15 = l_262_15.TONG
        l_262_14 = l_262_14 == l_262_15
        l_262_13(l_262_23, l_262_14)
        l_262_22.disabled = nil
        l_262_13 = this
        l_262_13, l_262_23 = l_262_13:Lookup, l_262_13
        l_262_14 = "CheckBox_Party"
        l_262_13 = l_262_13(l_262_23, l_262_14)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_14 = l_262_14(l_262_15, "DefaultMessageChannel")
        l_262_15 = PLAYER_TALK_CHANNEL
        l_262_15 = l_262_15.TEAM
        l_262_14 = l_262_14 == l_262_15
        l_262_13(l_262_23, l_262_14)
        l_262_22.disabled = nil
        l_262_13 = this
        l_262_13, l_262_23 = l_262_13:Lookup, l_262_13
        l_262_14 = "CheckBox_EventInfo"
        l_262_13 = l_262_13(l_262_23, l_262_14)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_15, l_262_14 = .end, l_262_14(l_262_15, "ReportEventInfo")
        l_262_13(l_262_23, l_262_14, l_262_15)
        l_262_22.disabled = nil
        l_262_13 = this
        l_262_13, l_262_23 = l_262_13:Lookup, l_262_13
        l_262_14 = "CheckBox_ItemInfo"
        l_262_13 = l_262_13(l_262_23, l_262_14)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_15, l_262_14 = .end, l_262_14(l_262_15, "ReportItemInfo")
        l_262_13(l_262_23, l_262_14, l_262_15)
        l_262_22.disabled = nil
        l_262_13 = this
        l_262_13, l_262_23 = l_262_13:Lookup, l_262_13
        l_262_14 = "CheckBox_MemberInfo"
        l_262_13 = l_262_13(l_262_23, l_262_14)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_262_22.disabled = true
        l_262_13, l_262_23 = l_262_22:Check, l_262_22
        l_262_14 = MiDKP
        l_262_14 = l_262_14.Config
        l_262_14, l_262_15 = l_262_14:GetValue, l_262_14
        l_262_15, l_262_14 = .end, l_262_14(l_262_15, "ReportMemberInfo")
        l_262_13(l_262_23, l_262_14, l_262_15)
      end
      l_262_22.disabled = nil
    end
    l_0_6.OnFrameCreate = l_0_7
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(7)
        else
          this:Lookup("Image_Check"):SetFrame(3)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = true
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          this:Lookup("Image_Check"):SetFrame(6)
        else
          this:Lookup("Image_Check"):SetFrame(5)
        end
        this.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 = nil
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      if this.BigFoot_f8c6f4951c524600d5984ab47a0d8393 then
        if this.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 then
          MiDKP.UI.MsgConfig.UnCheck(this)
        end
      else
        MiDKP.UI.MsgConfig.Check(this)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "Check"
    l_0_8 = function(l_266_0, l_266_1)
      if l_266_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_266_0:Lookup("Image_Check"):SetFrame(7)
      else
        l_266_0:Lookup("Image_Check"):SetFrame(6)
      end
      l_266_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = true
      if l_266_1 then
        return 
      end
      MiDKP.Config:SetValue("BanedDKP" .. l_266_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393, nil)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "UnCheck"
    l_0_8 = function(l_267_0, l_267_1)
      if l_267_0.BigFoot_7ea4cfc3b8fb1cc39516212c4de975e5 then
        l_267_0:Lookup("Image_Check"):SetFrame(3)
      else
        l_267_0:Lookup("Image_Check"):SetFrame(5)
      end
      l_267_0.BigFoot_30b6f278098f3fa7bf562ea6d5620a66 = nil
      if l_267_1 then
        return 
      end
      MiDKP.Config:SetValue("BanedDKP" .. l_267_0.BigFoot_f8c6f4951c524600d5984ab47a0d8393, true)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnCheckBoxCheck"
    l_0_8 = function()
      if this.disabled then
        return 
      end
      local l_268_0 = this:GetName()
      if l_268_0 == "CheckBox_Raid" then
        MiDKP.Config:SetValue("DefaultMessageChannel", PLAYER_TALK_CHANNEL.RAID)
        this:GetParent():Lookup("CheckBox_Guild"):Check(false)
        this:GetParent():Lookup("CheckBox_Party"):Check(false)
      elseif l_268_0 == "CheckBox_Guild" then
        MiDKP.Config:SetValue("DefaultMessageChannel", PLAYER_TALK_CHANNEL.TONG)
        this:GetParent():Lookup("CheckBox_Raid"):Check(false)
        this:GetParent():Lookup("CheckBox_Party"):Check(false)
      elseif l_268_0 == "CheckBox_Party" then
        MiDKP.Config:SetValue("DefaultMessageChannel", PLAYER_TALK_CHANNEL.TEAM)
        this:GetParent():Lookup("CheckBox_Raid"):Check(false)
        this:GetParent():Lookup("CheckBox_Guild"):Check(false)
      elseif l_268_0 == "CheckBox_EventInfo" then
        MiDKP.Config:SetValue("ReportEventInfo", true)
      elseif l_268_0 == "CheckBox_ItemInfo" then
        MiDKP.Config:SetValue("ReportItemInfo", true)
      elseif l_268_0 == "CheckBox_MemberInfo" then
        MiDKP.Config:SetValue("ReportMemberInfo", true)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnCheckBoxUncheck"
    l_0_8 = function()
      if this.disabled then
        return 
      end
      local l_269_0 = this:GetName()
      if l_269_0 == "CheckBox_EventInfo" then
        MiDKP.Config:SetValue("ReportEventInfo", nil)
      elseif l_269_0 == "CheckBox_ItemInfo" then
        MiDKP.Config:SetValue("ReportItemInfo", nil)
      elseif l_269_0 == "CheckBox_MemberInfo" then
        MiDKP.Config:SetValue("ReportMemberInfo", nil)
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_270_0 = this:GetName()
      if l_270_0 == "Btn_Close" or l_270_0 == "Btn_Cancel" then
        MiDKP.UI.MsgConfig.CloseMsgConfigPanel()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OpenMsgConfigPanel"
    l_0_8 = function()
      if not Station.Lookup("Normal1/MiDKP_MsgConfig") then
        local l_271_0, l_271_1, l_271_2, l_271_3, l_271_4 = Wnd.OpenWindow(MiDKP.UI.MSGCONFIG_INI_FILE, "MiDKP_MsgConfig")
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_271_0:Show()
      local l_271_5, l_271_6 = , Station.GetClientSize()
      local l_271_7, l_271_8 = , l_271_5:GetSize()
      l_271_5:SetAbsPos((l_271_6 - l_271_8) / 2, (l_271_7 - l_271_5) / 2)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "CloseMsgConfigPanel"
    l_0_8 = function()
      local l_272_0 = Station.Lookup("Normal1/MiDKP_MsgConfig")
      if l_272_0 then
        l_272_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "IsMsgConfigPanelOpened"
    l_0_8 = function()
      local l_273_0 = Station.Lookup("Normal1/MiDKP_MsgConfig")
      local l_273_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_273_0 then
        return l_273_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "MsgConfig"
    l_0_6 = l_0_6[l_0_7]
    MiDKP_MsgConfig = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_9 = "Pos"
    local l_0_10 = {}
    local l_0_11 = "x"
    l_0_10[l_0_11] = 0
    l_0_11 = "y"
    l_0_10[l_0_11] = 0
    l_0_6[l_0_7], l_0_8 = l_0_8, {[l_0_9] = l_0_10}
    l_0_6 = RegisterCustomData
    l_0_7 = "MiDKP.UI.Notify.Pos"
    l_0_6(l_0_7)
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OpenNotifyPanel"
    l_0_8 = function()
      if not Station.Lookup("Normal1/MiDKP_Notify") then
        local l_274_0, l_274_5, l_274_6 = Wnd.OpenWindow(MiDKP.UI.NOTIFY_INI_FILE, "MiDKP_Notify")
        l_274_5, l_274_6 = l_274_0:SetAbsPos, l_274_0
        l_274_5(l_274_6, MiDKP.UI.Notify.Pos.x, MiDKP.UI.Notify.Pos.y)
        l_274_5, l_274_6 = l_274_0:GetAbsPos, l_274_0
        l_274_5 = l_274_5(l_274_6)
        local l_274_1, l_274_2 = nil
      end
      if l_274_5 == 0 and l_274_6 == 0 then
        l_274_1 = Station
        l_274_1 = l_274_1.GetClientSize
        l_274_2 = false
        l_274_1 = l_274_1(l_274_2)
        local l_274_3, l_274_4 = nil
        l_274_3 = MiDKP
        l_274_3 = l_274_3.UI
        l_274_3 = l_274_3.Notify
        l_274_3 = l_274_3.Pos
        l_274_4 = l_274_1 / 3
        l_274_4 = l_274_1 - l_274_4
        l_274_3.x = l_274_4
        l_274_3 = MiDKP
        l_274_3 = l_274_3.UI
        l_274_3 = l_274_3.Notify
        l_274_3 = l_274_3.Pos
        l_274_4 = l_274_2 / 3
        l_274_4 = l_274_2 - l_274_4
        l_274_3.y = l_274_4
        l_274_3, l_274_4 = l_274_0:SetAbsPos, l_274_0
        l_274_3(l_274_4, MiDKP.UI.Notify.Pos.x, MiDKP.UI.Notify.Pos.y)
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_274_0:Show()
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnLButtonDown"
    l_0_8 = function()
      local l_275_0 = this:GetName()
      if l_275_0 == "Btn_Drag" then
        this:GetRoot():StartMoving()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnLButtonUp"
    l_0_8 = function()
      local l_276_0 = this:GetName()
      if l_276_0 == "Btn_Drag" then
        this:GetRoot():EndMoving()
        local l_276_1 = MiDKP.UI.Notify.Pos
        local l_276_2 = MiDKP.UI.Notify.Pos
        local l_276_3 = this:GetRoot():GetAbsPos()
        l_276_2.y = this:GetRoot()
        l_276_1.x = l_276_3
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemLButtonDown"
    l_0_8 = function()
      local l_277_0 = Station.Lookup("Normal1/MiDKP_Notify"):Lookup("", "")
      if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
        MiDKP.UI.Event.OpenEventPanel(this.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, this.BigFoot_d0708241b607c9a9dd1953c812fadfb7)
        this:SetSize(0, 0)
        this:Hide()
        l_277_0:FormatAllItemPos()
        l_277_0:SetSizeByAllItemSize()
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          MiDKP.UI.Item.OpenItemPanel(this.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af, this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9)
          this:SetSize(0, 0)
          this:Hide()
          l_277_0:FormatAllItemPos()
          l_277_0:SetSizeByAllItemSize()
        end
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemMouseEnter"
    l_0_8 = function()
      if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
        this:SetFrame(9)
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          this:SetFrame(2)
        end
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "OnItemMouseLeave"
    l_0_8 = function()
      if this.BigFoot_d0708241b607c9a9dd1953c812fadfb7 then
        this:SetFrame(8)
      else
        if this.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 then
          this:SetFrame(1)
        end
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "CreateEventIcon"
    l_0_8 = function(l_280_0, l_280_1)
      local l_280_2 = Station.Lookup("Normal1/MiDKP_Notify")
      if not l_280_2 then
        MiDKP.UI.Notify.OpenNotifyPanel()
        l_280_2 = Station.Lookup("Normal1/MiDKP_Notify")
      end
      local l_280_3 = l_280_2:Lookup("", "")
      l_280_3:AppendItemFromString("<image>path=\"ui\\image\\button\\systembutton.UITex\" frame=8 postype=7 eventid=257</image>")
      local l_280_4 = l_280_3:Lookup(l_280_3:GetItemCount() - 1)
      l_280_4.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_280_0
      l_280_4.BigFoot_d0708241b607c9a9dd1953c812fadfb7 = l_280_1
      l_280_3:FormatAllItemPos()
      l_280_3:SetSizeByAllItemSize()
      local l_280_5, l_280_6 = l_280_3:GetSize()
      l_280_2:SetSize(l_280_5, l_280_6)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "CreateItemIcon"
    l_0_8 = function(l_281_0, l_281_1)
      local l_281_2 = Station.Lookup("Normal1/MiDKP_Notify")
      if not l_281_2 then
        MiDKP.UI.Notify.OpenNotifyPanel()
        l_281_2 = Station.Lookup("Normal1/MiDKP_Notify")
      end
      local l_281_3 = l_281_2:Lookup("", "")
      l_281_3:AppendItemFromString("<image>path=\"ui\\image\\button\\systembutton_1.UITex\" frame=1 postype=7 eventid=257</image>")
      local l_281_4 = l_281_3:Lookup(l_281_3:GetItemCount() - 1)
      l_281_4.BigFoot_b5ec3bd1f1909e6b5ef04493c27f77af = l_281_0
      l_281_4.BigFoot_2e00ffac12aadb3a1fd865993ec505b9 = l_281_1
      l_281_3:FormatAllItemPos()
      l_281_3:SetSizeByAllItemSize()
      local l_281_5, l_281_6 = l_281_3:GetSize()
      l_281_2:SetSize(l_281_5, l_281_6)
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_7 = "Notify"
    l_0_6 = l_0_6[l_0_7]
    MiDKP_Notify = l_0_6
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6.Export, l_0_7 = l_0_7, {}
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Export
    l_0_7 = "OnLButtonClick"
    l_0_8 = function()
      local l_282_0 = this:GetName()
      if l_282_0 == "Btn_Close" then
        MiDKP.UI.Export.CloseExportPanel()
      do
        elseif l_282_0 == "Btn_Upload" then
          local l_282_1 = MiDKP.Config:GetValue("GuildUrl")
        end
      end
      if l_282_1 and #l_282_1 > 0 then
         -- WARNING: missing end command somewhere! Added here
      end
      -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 25 
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Export
    l_0_7 = "OpenExportPanel"
    l_0_8 = function(l_283_0)
      if not Station.Lookup("Normal1/MiDKP_Export") then
        local l_283_1, l_283_2, l_283_3, l_283_4, l_283_5, l_283_6 = Wnd.OpenWindow(MiDKP.UI.EXPORT_INI_FILE, "MiDKP_Export")
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_283_1:Show()
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_283_1:Lookup("Edit_String"):ClearText()
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_283_7, l_283_8 = , l_283_1:Lookup("Edit_String"):InsertObj
      local l_283_9 = l_283_1:Lookup("Edit_String")
      local l_283_10 = l_283_0
      l_283_8(l_283_9, l_283_10, {type = "text", text = l_283_0})
      l_283_8, l_283_9 = l_283_7:Lookup, l_283_7
      l_283_10 = "Edit_String"
      l_283_8 = l_283_8(l_283_9, l_283_10)
      l_283_8, l_283_9 = l_283_8:SelectAll, l_283_8
      l_283_8(l_283_9)
      l_283_8 = Station
      l_283_8 = l_283_8.GetClientSize
      l_283_8 = l_283_8()
       -- DECOMPILER ERROR: Overwrote pending register.

      l_283_7:SetAbsPos((l_283_8 - l_283_10) / 2, (l_283_9 - l_283_7) / 2)
      Station.SetFocusWindow(l_283_7:Lookup("Edit_String"))
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Export
    l_0_7 = "CloseExportPanel"
    l_0_8 = function()
      local l_284_0 = Station.Lookup("Normal1/MiDKP_Export")
      if l_284_0 then
        l_284_0:Hide()
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Export
    l_0_7 = "IsExportPanelOpened"
    l_0_8 = function()
      local l_285_0 = Station.Lookup("Normal1/MiDKP_Export")
      local l_285_1 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

      if l_285_0 then
        return l_285_1
      end
    end
    l_0_6[l_0_7] = l_0_8
    l_0_6 = MiDKP
    l_0_6 = l_0_6.UI
    l_0_6 = l_0_6.Export
    MiDKP_Export = l_0_6
    l_0_6 = Wnd
    l_0_7 = "OpenWindow"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = MiDKP
    l_0_7 = l_0_7.UI
    l_0_7 = l_0_7.INI_FILE
    l_0_8 = "MiDKP"
    l_0_6 = l_0_6(l_0_7, l_0_8)
    l_0_8 = "Hide"
     -- DECOMPILER ERROR: [l_0_8] should be a SELF Operator

    l_0_6, l_0_7 = l_0_6[l_0_8], l_0_6
    l_0_6(l_0_7)
    l_0_6 = MiDKP
    l_0_6 = l_0_6.Core
    l_0_6, l_0_7 = l_0_6:RegisterEvent, l_0_6
    l_0_8 = "ERROR"
    l_0_9 = function(l_286_0)
      if l_286_0 == MiDKP.Error.RAID_ALREADY_EXISTS then
        MiDKP.UI.Print("error", "�Ѵ�����ͬ���ƵĻ��")
      else
        if l_286_0 == MiDKP.Error.EMPTY_RAID_NAME then
          MiDKP.UI.Print("error", "������Ϸ��Ļ���ơ�")
        end
      else
        if l_286_0 == MiDKP.Error.EMPTY_MEMBER_NAME then
          MiDKP.UI.Print("error", "������Ϸ�����Ա���֡�")
        end
      else
        if l_286_0 == MiDKP.Error.EMPTY_MEMBER_CLASS then
          MiDKP.UI.Print("error", "������Ϸ���ְҵ��")
        end
      else
        if l_286_0 == MiDKP.Error.MEMBER_INLIST then
          MiDKP.UI.Print("error", "�ĳ�Ա�Ѿ����ڡ�")
        end
      else
        if l_286_0 == MiDKP.Error.EVENT_EMPTY_MEMBERS then
          MiDKP.UI.Print("error", "��ѡ��ֻ��һ����Ա��")
        end
      else
        if l_286_0 == MiDKP.Error.ITEM_ERROR_ARGS then
          MiDKP.UI.Print("error", "��Ʒ�����Ƿ���")
        end
      else
        if l_286_0 == MiDKP.Error.ITEM_LOOTER_NOT_IN_RAID then
          MiDKP.UI.Print("error", "��Ʒ����߲��ٴ˴λ�С�")
        end
      else
        if l_286_0 == MiDKP.Error.ANOTHER_RAID_STARTED then
          MiDKP.UI.Print("error", "��һ����Ѿ���ʼ��Ҫ��ʼ�µĻ��������Ѿ���ʼ�Ļ��")
        end
      else
        if l_286_0 == MiDKP.Error.NOT_IN_RAID then
          MiDKP.UI.Print("error", "���봦���Ŷ��С�")
        end
      else
        if l_286_0 == MiDKP.Error.RAID_NOT_START then
          MiDKP.UI.Print("error", "���û�п�ʼ��")
        end
      else
        if l_286_0 == MiDKP.Error.MEMBER_HAS_ITEM then
          MiDKP.UI.Print("error", "�����ڸ������ص���Ʒ��Ҫɾ����ң�����ɾ����Ӧ����Ʒ��")
        end
      else
        if l_286_0 == MiDKP.Error.ITEM_EVENT then
          MiDKP.UI.Print("error", "�޷�ɾ��ƽ��������Ʒ���¼������޸������Ʒ��")
        end
      end
    end
    l_0_6(l_0_7, l_0_8, l_0_9)
    l_0_6 = AppendCommand
    l_0_7 = "midkp"
    l_0_8 = MiDKP
    l_0_8 = l_0_8.UI
    l_0_9 = "OpenMiDKPPanel"
    l_0_8 = l_0_8[l_0_9]
    l_0_6(l_0_7, l_0_8)
    l_0_6 = BFConfigPanel
    l_0_7 = "RegisterMod"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "MiDKP"
    l_0_8 = "MiDKP"
    l_0_9 = "\\ui\\image\\icon\\friend_03.tga"
    l_0_10 = "BigFoot_b6b85020006c3110eba073d7eb8da75f"
    l_0_6(l_0_7, l_0_8, l_0_9, l_0_10)
    l_0_6 = BFConfigPanel
    l_0_7 = "RegisterCheckButton"
    l_0_6 = l_0_6[l_0_7]
    l_0_7 = "MiDKP"
    l_0_8 = "EnableMiDKP"
    l_0_9 = "����MiDKP"
    l_0_10 = false
    l_0_11 = function(l_287_0, l_287_1)
      MiDKP.BigFoot_98a5dc0296fddcc9b5b804f038f1994c = l_287_0
      if l_287_0 then
        local l_287_2 = MiDKP.Config:GetValue("GuildUrl")
      if not l_287_2 or #l_287_2 > 0 then
        end
        if l_287_2 then
          BigFoot.RegisterMinimapButton("Interface\\BF_MiDKP\\Minimap.tga", "<text>text=\"MiDKP\"</text>", function()
          if MiDKP.UI.IsMiDKPPanelOpened() then
            MiDKP.UI.CloseMiDKPPanel()
          else
            MiDKP.UI.OpenMiDKPPanel()
          end
        end)
          MiDKP.BigFoot_48c51eb04964418cff3adab39019c25b = true
        end
         -- WARNING: missing end command somewhere! Added here
      end
      -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 15 
    end
    l_0_6(l_0_7, l_0_8, l_0_9, l_0_10, l_0_11)
  end
end

