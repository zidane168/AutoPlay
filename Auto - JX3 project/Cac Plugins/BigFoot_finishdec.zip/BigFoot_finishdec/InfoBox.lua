-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: InfoBox.lua 

InfoBox_Coordinate = {}
InfoBox_Coordinate.BigFoot_0863dc7b3a0e559f0cc8a802e89ee059 = {}
InfoBox_Coordinate.OnFrameCreate = function()
  local l_1_0 = this:Lookup("", "")
  if not l_1_0 then
    Output("no handle")
  end
  local l_1_1 = l_1_0:Lookup("Text_Coordinate_Text")
  this.BigFoot_99eed1ff9f687c051a0219c86c0ed9c6 = l_1_1
  BigFoot.RegisterFrame("position", "InfoBox_Coordinate", this)
end

InfoBox_Coordinate.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_2_0 = GetTime()
  if this.Time and l_2_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_2_0
  if this.BigFoot_99eed1ff9f687c051a0219c86c0ed9c6 then
    local l_2_1, l_2_2 = InfoBox_Coordinate.GetPlayerMapPosition()
  end
  if l_2_1 and l_2_2 then
    l_2_1 = math.floor(l_2_1 * 10) / 10
    l_2_2 = math.floor(l_2_2 * 10) / 10
    this.BigFoot_99eed1ff9f687c051a0219c86c0ed9c6:SetText(string.format("���꣺(%.1f, %3.1f)", l_2_1, l_2_2))
  end
end

InfoBox_Coordinate.GetPlayerMapPosition = function()
  local l_3_0 = GetClientPlayer()
  if l_3_0 then
    local l_3_1 = l_3_0.GetScene()
    local l_3_2 = l_3_1.dwMapID
    local l_3_3, l_3_4, l_3_5 = Scene_GameWorldPositionToScenePosition(l_3_0.nX, l_3_0.nY, l_3_0.nZ, 0)
    if not InfoBox_Coordinate.BigFoot_0863dc7b3a0e559f0cc8a802e89ee059[l_3_2] then
      MiddleMap.InitMiddleMapInfo(l_3_2)
      local l_3_6 = InfoBox_Coordinate.BigFoot_0863dc7b3a0e559f0cc8a802e89ee059
      local l_3_7 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    end
    return l_3_3, l_3_4
  end
   -- WARNING: undefined locals caused missing assignments!
end

InfoBox_Money = {}
InfoBox_Money.OnFrameCreate = function()
  local l_4_0 = this:Lookup("", "")
  local l_4_1 = l_4_0:Lookup("Text_Money_Gold")
  local l_4_2 = l_4_0:Lookup("Text_Money_Silver")
  local l_4_3 = l_4_0:Lookup("Text_Money_Copper")
  this.BigFoot_57eb98f095d8ec0ba5a82505e4146693 = l_4_1
  this.BigFoot_eff85e9367cf584cee5f5f15217bb0ab = l_4_2
  this.BigFoot_055916812000ee57ba9b0e8c03cd3fca = l_4_3
  BigFoot.RegisterFrame("position", "InfoBox_Money", this)
end

InfoBox_Money.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_5_0 = GetTime()
  if this.Time and l_5_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_5_0
  if this.BigFoot_57eb98f095d8ec0ba5a82505e4146693 and this.BigFoot_eff85e9367cf584cee5f5f15217bb0ab and this.BigFoot_055916812000ee57ba9b0e8c03cd3fca then
    local l_5_1 = GetClientPlayer()
  end
  if l_5_1 then
    local l_5_2 = l_5_1.GetMoney()
    local l_5_3, l_5_4, l_5_5 = MoneyToGoldSilverAndCopper(l_5_2)
    this.BigFoot_57eb98f095d8ec0ba5a82505e4146693:SetText(l_5_3)
    this.BigFoot_eff85e9367cf584cee5f5f15217bb0ab:SetText(l_5_4)
    this.BigFoot_055916812000ee57ba9b0e8c03cd3fca:SetText(l_5_5)
  end
end

InfoBox_Latency = {}
InfoBox_Latency.OnFrameCreate = function()
  local l_6_0 = this:Lookup("", "")
  local l_6_1 = l_6_0:Lookup("Text_Latency_Text")
  this.BigFoot_1ec77ded1507d66ae96235380f042d6e = l_6_1
  this.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b = 0
  BigFoot.RegisterFrame("position", "InfoBox_Latency", this)
end

InfoBox_Latency.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_7_0 = GetTime()
  if this.Time and l_7_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_7_0
  if this.BigFoot_1ec77ded1507d66ae96235380f042d6e and GetTime() - this.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b >= 1000 then
    this.BigFoot_da4b94f92d67ca9ccecb24bec1db6e2b = GetTime()
    local l_7_1 = GetPingValue()
    local l_7_2 = math.floor(l_7_1 / 2)
    this.BigFoot_1ec77ded1507d66ae96235380f042d6e:SetText(string.format("�ӳ٣�%d ms", l_7_2))
  end
end

InfoBox_Time = {}
InfoBox_Time.OnFrameCreate = function()
  local l_8_0 = this:Lookup("", "")
  local l_8_1 = l_8_0:Lookup("Text_Time_Text")
  this.BigFoot_16fbfa51fad8297d120937caf1e21477 = l_8_1
  BigFoot.RegisterFrame("position", "InfoBox_Time", this)
end

InfoBox_Time.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_9_0 = GetTime()
  if this.Time and l_9_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_9_0
  if this.BigFoot_16fbfa51fad8297d120937caf1e21477 then
    local l_9_1 = GetCurrentTime()
    local l_9_2 = (TimeToDate(l_9_1))
    local l_9_3, l_9_4, l_9_5 = nil, nil, nil
    if l_9_3 and l_9_4 and l_9_5 then
      this.BigFoot_16fbfa51fad8297d120937caf1e21477:SetText(string.format("ʱ�䣺%02d:%02d:%02d", l_9_3, l_9_4, l_9_5))
    end
  else
    this.BigFoot_16fbfa51fad8297d120937caf1e21477:SetText(string.format("ʱ�䣺%02d:%02d:%02d", l_9_2.hour, l_9_2.minute, l_9_2.second))
  end
end

InfoBox_Time.GetNewTime = function()
  if not InfoBox_Time.BHaveFromServer then
    Interaction_Request("InfoBox_Time", "http://bfservice.178.com", "/app/jx3/index.php?a=now", "", 80)
    return 
  end
  if InfoBox_Time.beijintimehour and InfoBox_Time.beijintimeminute and InfoBox_Time.beijintimesecond and InfoBox_Time.newtime then
    local l_10_0 = (GetTime() - InfoBox_Time.newtime) / 1000
    local l_10_1 = math.mod(InfoBox_Time.beijintimehour + math.floor(l_10_0 / 3600) + math.floor((InfoBox_Time.beijintimeminute + math.floor(math.mod(l_10_0, 3600) / 60) + math.floor((InfoBox_Time.beijintimesecond + math.mod(math.mod(l_10_0, 3600), 60)) / 60)) / 60), 24)
    local l_10_2 = math.mod(InfoBox_Time.beijintimeminute + math.floor(math.mod(l_10_0, 3600) / 60) + math.floor((InfoBox_Time.beijintimesecond + math.mod(math.mod(l_10_0, 3600), 60)) / 60), 60)
    local l_10_3 = math.mod(InfoBox_Time.beijintimesecond + math.mod(math.mod(l_10_0, 3600), 60), 60)
    return l_10_1, l_10_2, l_10_3
  end
end

RegisterEvent("INTERACTION_REQUEST_RESULT", function()
  if arg0 == "InfoBox_Time" and arg1 and arg3 > 0 then
    local l_11_0 = arg2
    local l_11_1 = InfoBox_Time
    local l_11_2 = InfoBox_Time
    local l_11_3 = InfoBox_Time
    local l_11_4, l_11_5, l_11_6, l_11_7 = string.find(l_11_0, "(%d+)%:(%d+)%:(%d+)")
    l_11_3.beijintimesecond = R8_PC18
    l_11_2.beijintimeminute = l_11_7
    l_11_1.beijintimehour = l_11_6
    __ = l_11_5
    __ = l_11_4
    l_11_1 = InfoBox_Time
    l_11_2 = GetTime
    l_11_2 = l_11_2()
    l_11_1.newtime = l_11_2
    l_11_1 = InfoBox_Time
    l_11_1.BHaveFromServer = true
  end
end
)
InfoBox_FPS = {}
InfoBox_FPS.OnFrameCreate = function()
  local l_12_0 = this:Lookup("", "")
  local l_12_1 = l_12_0:Lookup("Text_FPS_Text")
  this.BigFoot_c94ea18e44d4b9da2e7d3ce0f4255e7d = l_12_1
  BigFoot.RegisterFrame("position", "InfoBox_FPS", this)
end

InfoBox_FPS.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_13_0 = GetTime()
  if this.Time and l_13_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_13_0
  if this.BigFoot_c94ea18e44d4b9da2e7d3ce0f4255e7d then
    local l_13_1 = GetFPS()
    this.BigFoot_c94ea18e44d4b9da2e7d3ce0f4255e7d:SetText(string.format("FPS��%d ֡/��", l_13_1))
  end
end

InfoBox_Distance = {}
InfoBox_Distance.OnFrameCreate = function()
  local l_14_0 = this:Lookup("", "")
  local l_14_1 = l_14_0:Lookup("Text_Distance_Text")
  this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b = l_14_1
  BigFoot.RegisterFrame("position", "InfoBox_Distance", this)
  InfoBox_Distance.BigFoot_646db4f803da0e6216236b552c4d9021 = GetSkill(13, 1)
  InfoBox_Distance.BigFoot_2631aeee980c9204e30791ec90dc204b = false
  InfoBox_Distance.BigFoot_fde30cf2fbd9bf45e8e2b5214ba024e3 = GetSkill(34, 1)
  InfoBox_Distance.BigFoot_d44023da1591ee79927269b226e3e08d = false
end

InfoBox_Distance.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_15_0 = GetTime()
  if this.Time and l_15_0 - this.Time < 100 then
    return 
  end
  this.Time = l_15_0
  if this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b then
    local l_15_1 = GetClientPlayer()
    if not l_15_1 then
      return 
    end
    local l_15_2 = GetTargetHandle(l_15_1.GetTarget())
    local l_15_3 = l_15_1.GetScene()
    if l_15_2 and l_15_2.dwID == l_15_1.dwID then
      this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetText("Ŀ�����Լ�")
      this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetFontColor(255, 255, 255)
    end
  elseif l_15_2 then
    local l_15_4 = GetCharacterDistance(l_15_2.dwID, l_15_1.dwID) / 64
    local l_15_5 = nil
    l_15_5 = string.format("���룺%.2f��", l_15_4)
    this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetText(l_15_5)
    if l_15_4 <= 4 then
      this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetFontColor(255, 0, 0)
    elseif l_15_4 > 4 and l_15_4 < 20 then
      this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetFontColor(0, 255, 0)
    elseif l_15_4 >= 20 then
      this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetFontColor(255, 255, 255)
    end
  else
    this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetText("û��Ŀ��")
    this.BigFoot_6d208a0fc5e3d675c37ab8d29dff0f2b:SetFontColor(255, 255, 255)
  end
end

local l_0_0 = function(l_16_0)
  local l_16_1 = GetMsgFontString("MSG_SYS")
  OutputMessage("MSG_SYS", FormatString("<text>text=\"<ս����ʱ>\" font=10 r=0 g=196 b=196</text><text>text=\"<D0> \"</text><D1><text>text=\"\n\" font=<D1></text>", l_16_0, l_16_1), true)
end

local l_0_1 = {}
l_0_1.StartTime = false
l_0_1.BigFoot_440c0c5652cbf900befe252dff263681 = ""
InfoBox_FightTime = l_0_1
l_0_1 = InfoBox_FightTime
l_0_1.OnFrameCreate = function()
  local l_17_0 = this:Lookup("", "")
  local l_17_1 = l_17_0:Lookup("Text_Time_Text")
  this.BigFoot_16fbfa51fad8297d120937caf1e21477 = l_17_1
  BigFoot.RegisterFrame("position", "InfoBox_FightTime", this)
end

l_0_1 = RegisterEvent
l_0_1("FIGHT_HINT", function()
  if arg0 then
    InfoBox_FightTime.StartTime = GetTime()
  else
    InfoBox_FightTime.StartTime = false
  end
end
)
l_0_1 = InfoBox_FightTime
l_0_1.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_19_0 = GetTime()
  if this.Time and l_19_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_19_0
  if this.BigFoot_16fbfa51fad8297d120937caf1e21477 then
    if InfoBox_FightTime.StartTime then
      local l_19_1 = math.floor((GetTime() - InfoBox_FightTime.StartTime) / 1000)
      InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = ""
      if l_19_1 >= 3600 then
        local l_19_2, l_19_3 = math.modf(l_19_1 / 3600)
        local l_19_4, l_19_5 = math.modf(l_19_3 * 60)
        local l_19_6 = math.modf(l_19_5 * 60)
        InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = l_19_2 .. ":" .. l_19_4 .. ":" .. l_19_6
      elseif l_19_1 >= 60 then
        local l_19_7, l_19_8 = math.modf(l_19_1 / 60)
        local l_19_9 = math.modf(l_19_8 * 60)
        if l_19_7 < 10 then
          l_19_7 = "0" .. l_19_7
        end
        if l_19_9 < 10 then
          l_19_9 = "0" .. l_19_9
        end
        InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = l_19_7 .. ":" .. l_19_9
      else
        local l_19_10 = l_19_1
        if l_19_10 < 10 then
          l_19_10 = "0" .. l_19_10
        end
        InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = l_19_10
      end
      InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = "��ս��: " .. InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681
      this.BigFoot_16fbfa51fad8297d120937caf1e21477:SetText(InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681)
      InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681 = string.gsub(InfoBox_FightTime.BigFoot_440c0c5652cbf900befe252dff263681, " ", "")
    end
  else
    this.BigFoot_16fbfa51fad8297d120937caf1e21477:SetText("����ս��")
  end
end

l_0_1 = InfoBox_FightTime
l_0_1.OnRButtonDown = function()
  -- upvalues: l_0_0
  local l_20_0, l_20_1, l_20_2, l_20_3, l_20_4, l_20_5, l_20_6 = nil, nil, nil, nil, nil, nil, nil
  if not GetClientPlayer() then
    return 
  end
  if not R9_PC7 or R9_PC7 == 0 then
    if not GetClientPlayer().bFightState then
      l_0_0("û��Ŀ�꣬Ҳû����ս��")
      return 
    else
      InfoBox_FightTime.say(l_20_6)
      return 
    end
  else
    if GetPlayer(R11_PC37) or not l_20_0 then
      return 
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if tonumber(R11_PC37) >= 10000 then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if GetClientPlayer().bFightState then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    InfoBox_FightTime.say(R11_PC37)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1 = InfoBox_FightTime
l_0_1.getName = function(l_21_0)
  if not GetNpc(l_21_0) then
    local l_21_1, l_21_2 = GetPlayer(l_21_0)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_21_1 then
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_21_3 = nil
  if not l_21_1.szName then
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_21_1.szName
end

l_0_1 = InfoBox_FightTime
l_0_1.OnMouseEnter = function()
  local l_22_0 = ""
  l_22_0 = l_22_0 .. "<Text>text=\"�һ�����ս����ʱ,����Ƶ��Ϊ��ҵ�ǰƵ��\n\" r=255 g=255 b=255/Text>"
  local l_22_1, l_22_2 = this:GetAbsPos()
  local l_22_3 = OutputTip
  local l_22_4 = l_22_0
  local l_22_5 = 200
  do
    local l_22_6 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_22_3(l_22_4, l_22_5, l_22_6)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1 = InfoBox_FightTime
l_0_1.OnMouseLeave = function()
  HideTip()
end

l_0_1 = InfoBox_FightTime
l_0_1.say = function(l_24_0)
  local l_24_1 = GetClientPlayer()
  if not R3_PC4 then
    local l_24_4, l_24_6 = EditBox_GetChannel(), R3_PC4
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_24_4 then
    local l_24_2, l_24_3, l_24_5 = PLAYER_TALK_CHANNEL.PARTY, l_24_6
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_24_1.Talk(l_24_2, l_24_3, l_24_0)
end

InfoBox_Shenji, l_0_1 = l_0_1, {}
l_0_1 = InfoBox_Shenji
l_0_1.OnFrameCreate = function()
  local l_25_0 = this:Lookup("", "")
  local l_25_1 = l_25_0:Lookup("Text_lujian_Text")
  local l_25_2 = l_25_0:Lookup("Text_jiguan_Text")
  this.BigFoot_0bc39d9e607c9fd004fee9977b9ba1d8 = l_25_1
  this.BigFoot_ade7098433d870e19a3058b7d528849a = l_25_2
  BigFoot.RegisterFrame("position", "InfoBox_Shenji", this)
end

l_0_1 = InfoBox_Shenji
l_0_1.OnFrameBreathe = function()
  if Info_lock then
    this:SetDragArea(0, 0, 0, 0)
  else
    this:SetDragArea(0, 0, 500, 500)
  end
  local l_26_0 = GetTime()
  if this.Time and l_26_0 - this.Time < 1000 then
    return 
  end
  this.Time = l_26_0
  if this.BigFoot_0bc39d9e607c9fd004fee9977b9ba1d8 and this.BigFoot_ade7098433d870e19a3058b7d528849a then
    local l_26_1, l_26_2 = InfoBox_Shenji.Getnumber()
    this.BigFoot_0bc39d9e607c9fd004fee9977b9ba1d8:SetText("�����" .. l_26_2)
    this.BigFoot_ade7098433d870e19a3058b7d528849a:SetText("���أ�" .. l_26_1)
  end
end

l_0_1 = InfoBox_Shenji
l_0_1.Getnumber = function()
  local l_27_0 = GetClientPlayer()
  local l_27_1 = 0
  local l_27_2 = 0
  if l_27_0 then
    local l_27_3 = l_27_0.GetBoxSize(INVENTORY_INDEX.BULLET_PACKAGE)
    for l_27_7 = 1, l_27_3 do
      local l_27_8 = l_27_0.GetItem(INVENTORY_INDEX.BULLET_PACKAGE, l_27_7 - 1)
      if l_27_8 then
        if l_27_8.dwTabType == 6 and l_27_8.dwIndex == 4014 then
          l_27_1 = l_27_1 + l_27_8.nStackNum
        end
      elseif l_27_8.dwTabType == 6 and l_27_8.dwIndex == 4000 then
        l_27_2 = l_27_2 + l_27_8.nStackNum
      end
    end
  end
  return l_27_1, l_27_2
end

InfoBox_Config, l_0_1 = l_0_1, {version = 1.1}
l_0_1 = InfoBox_Coordinate
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Coordinate.ini", "InfoBox_Coordinate")
l_0_1 = InfoBox_Money
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Money.ini", "InfoBox_Money")
l_0_1 = InfoBox_Latency
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Latency.ini", "InfoBox_Latency")
l_0_1 = InfoBox_Time
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Time.ini", "InfoBox_Time")
l_0_1 = InfoBox_FPS
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_FPS.ini", "InfoBox_FPS")
l_0_1 = InfoBox_Distance
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Distance.ini", "InfoBox_Distance")
l_0_1 = InfoBox_FightTime
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_FightTime.ini", "InfoBox_FightTime")
l_0_1 = InfoBox_Shenji
l_0_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = Wnd.OpenWindow("Interface\\BF_InfoBox\\InfoBox_Shenji.ini", "InfoBox_Shenji")
l_0_1 = RegisterCustomData
l_0_1("Global\\InfoBox_Config")
InfoBox, l_0_1 = l_0_1, {}
l_0_1 = RegisterEvent
l_0_1("CUSTOM_DATA_LOADED", function()
  if arg0 ~= "Global" then
    return 
  end
  if not InfoBox_Config.userplace then
    InfoBox_Distance.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1340, 30)
    InfoBox_Latency.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1340, 64)
    InfoBox_FPS.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1340, 98)
    InfoBox_Money.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1180, 30)
    InfoBox_Time.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1180, 64)
    InfoBox_Coordinate.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1180, 98)
    InfoBox_FightTime.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1340, 132)
    InfoBox_Shenji.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:SetAbsPos(1340, 132)
    InfoBox_Config.userplace = true
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_1("InfoBox", "��Ϣ��", "\\ui\\image\\icon\\extend10.tga", "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowCoordinatev2", "��ʾ����", false, function(l_29_0)
  if l_29_0 then
    InfoBox_Coordinate.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Coordinate.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowMoneyv2", "��ʾ��Ǯ", false, function(l_30_0)
  if l_30_0 then
    InfoBox_Money.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Money.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowLatencyv2", "��ʾ�����ӳ�", false, function(l_31_0)
  if l_31_0 then
    InfoBox_Latency.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Latency.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowTimev2", "��ʾʱ��", true, function(l_32_0)
  if l_32_0 then
    InfoBox_Time.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Time.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowFPSv2", "��ʾFPS", false, function(l_33_0)
  if l_33_0 then
    InfoBox_FPS.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_FPS.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowDistancev2", "��ʾĿ�����", true, function(l_34_0)
  if l_34_0 then
    InfoBox_Distance.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Distance.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowFightTime", "��ʾս��ʱ��", false, function(l_35_0)
  if l_35_0 then
    InfoBox_FightTime.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_FightTime.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "ShowShenjiNumber", "��ʾ�������ͻ�������", false, function(l_36_0)
  if l_36_0 then
    InfoBox_Shenji.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Show()
  else
    InfoBox_Shenji.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a:Hide()
  end
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("InfoBox", "infolock", "������Ϣ��λ��", false, function(l_37_0)
  Info_lock = l_37_0
end
)

