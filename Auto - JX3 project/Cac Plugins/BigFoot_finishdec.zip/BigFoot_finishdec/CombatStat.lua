-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: CombatStat.lua 

local l_0_0 = {}
l_0_0.HIT = 0
l_0_0.BLOCK = 1
l_0_0.SHIELD = 2
l_0_0.MISS = 3
l_0_0.DODGE = 4
l_0_0.CRITICAL = 5
SKILL_RESULT = l_0_0
BF_CombatStat_FANGSHI, l_0_0 = l_0_0, {fangshi = "TotalDamage"}
BF_CombatStat_MODE, l_0_0 = l_0_0, {DAMAGE = "�˺�ͳ��", BEDAMAGE = "�ܵ��˺�ͳ��", HEAL = "����ͳ��", BEHEAL = "�ܵ�����ͳ��", THREAT = "���ͳ��"}
BF_CombatStat, l_0_0 = l_0_0, {nCurrentMode = BF_CombatStat_MODE.DAMAGE, nHeight = 210, nWidth = 250, nMaxEntryCount = 10, 
PlayerDataRecordList = {}, 
PlayerDataDisplayList = {}, 
ProgressBars = {}, startfighttime = 0, endfighttime = 0, totalfighttime = 0, fighttime = 0, fightingtime = 0, isfighting = false, countboss = false, BshoweffectiveValue = false, ISMoreSetOpen = false, WidthSelect = "Loose", LooseWidth = 400, terseWidth = 200, x = 0, y = 0}
l_0_0 = PLAYER_TALK_CHANNEL
l_0_0 = l_0_0.TEAM
zBF_CombatStatspeak = l_0_0
BF_CombatStat_Speakxm, l_0_0 = l_0_0, {damage = true, damgeper = false, dps = true, heal = false, healper = false, hps = false}
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.countboss")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.ISMoreSetOpen")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.WidthSelect")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.x")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.y")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat_Speakxm")
l_0_0 = RegisterCustomData
l_0_0("zBF_CombatStatspeak")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat.nCurrentMode")
l_0_0 = RegisterCustomData
l_0_0("BF_CombatStat_FANGSHI")
l_0_0 = 10
BF_CombatStat.OnFrameCreate = function()
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("ON_BG_CHANNEL_MSG")
  this:RegisterEvent("FIGHT_HINT")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  BF_CombatStat.frame = Station.Lookup("Normal/BF_CombatStat")
  local l_1_0 = BF_CombatStat.frame:Lookup("Wnd_Output")
  BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6 = l_1_0:Lookup("", "Handle_OutputText")
  BF_CombatStat.Clear()
  BF_CombatStat.AddbuttonHiden()
end

BF_CombatStat.AddbuttonHiden = function()
  local l_2_0 = BF_CombatStat.frame
  local l_2_1 = BFButton.new(l_2_0, 22, 22)
  l_2_1:SetStyle("TRANSPARENT")
  l_2_1:SetNormalImage("Interface\\BF_Inventory\\normal.tga")
  l_2_1:SetHotImage("Interface\\BF_Inventory\\highlight.tga")
  l_2_1:SetPressedImage("Interface\\BF_Inventory\\pressed.tga")
  local l_2_2, l_2_3 = l_2_0:GetAbsPos()
  l_2_1:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_2_2 + 80, l_2_3 + 2)
  local l_2_4, l_2_5 = l_2_1:AddListener, l_2_1
  local l_2_6 = {}
  l_2_6.OnMouseEnter = function()
    local l_3_0, l_3_1 = this:GetAbsPos()
    local l_3_2 = OutputTip
    local l_3_3 = "<text>text=\"չ��/�������\"</text>"
    local l_3_4 = 200
    do
      local l_3_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_3_2(l_3_3, l_3_4, l_3_5)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  l_2_6.OnMouseLeave = function()
    HideTip()
  end
  l_2_4(l_2_5, l_2_6)
  l_2_4 = function()
    BF_CombatStat.bHideMost = not BF_CombatStat.bHideMost
    BF_CombatStat.UpdateButtonImage(BF_CombatStat.bHideMost)
  end
  l_2_1.OnClick = l_2_4
  l_2_4 = BF_CombatStat
  l_2_4.hideButton = l_2_1
  l_2_4 = BF_CombatStat
  l_2_4 = l_2_4.UpdateButtonImage
  l_2_5 = BF_CombatStat
  l_2_5 = l_2_5.bHideMost
  l_2_4(l_2_5)
end

BF_CombatStat.UpdateButtonImage = function(l_3_0)
  if l_3_0 then
    local l_3_1, l_3_2, l_3_4, l_3_7, l_3_11, l_3_12, l_3_14, l_3_18, l_3_19, l_3_22, l_3_26, l_3_27, l_3_31 = "ui\\Image\\UICommon\\Commonpanel.UITex"
    l_3_2 = 69
    local l_3_3, l_3_5, l_3_8, l_3_13, l_3_15, l_3_20, l_3_23, l_3_28, l_3_32 = nil
    l_3_4 = 70
    local l_3_6, l_3_9, l_3_16, l_3_21, l_3_24, l_3_29, l_3_33 = nil
    l_3_7 = 72
    local l_3_10, l_3_17, l_3_25, l_3_30, l_3_34 = nil
  else
    BF_CombatStat.hideButton:SetNormalImage("ui\\Image\\UICommon\\Commonpanel.UITex", 73)
     -- DECOMPILER ERROR: Confused about usage of registers!

    BF_CombatStat.hideButton:SetHotImage("ui\\Image\\UICommon\\Commonpanel.UITex", 74)
     -- DECOMPILER ERROR: Confused about usage of registers!

    BF_CombatStat.hideButton:SetPressedImage("ui\\Image\\UICommon\\Commonpanel.UITex", 68)
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 12 
end

BF_CombatStat.SetHidenButtonPos = function()
  local l_4_0, l_4_1 = BF_CombatStat.frame:GetAbsPos()
  BF_CombatStat.hideButton:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_4_0 + 250, l_4_1 + 7)
end

BF_CombatStat.text = function()
  for l_5_3 = 1, 20 do
    local l_5_4 = {}
    l_5_4.szName = "����" .. l_5_3
    BF_CombatStat.InitPlayerData(l_5_4)
  end
end

BF_CombatStat.OnFrameShow = function()
  if BF_CombatStat.x ~= 0 and BF_CombatStat.y ~= 0 then
    this:GetRoot():SetAbsPos(BF_CombatStat.x, BF_CombatStat.y)
  else
    this:GetRoot():SetAbsPos(1200, 700)
  end
  BF_CombatStat.SetHidenButtonPos()
end

BF_CombatStat.OnFrameHide = function()
end

BF_CombatStat.OnFrameBreathe = function()
  BF_CombatStat.UpdateTitleButton()
  BF_CombatStat.initwidth(BF_CombatStat.frame)
  BF_CombatStat.initHight(BF_CombatStat.frame)
  if not BF_CombatStat.bHideMost then
    BF_CombatStat.Display()
  end
end

BF_CombatStat.OnFrameDragEnd = function()
  local l_9_0 = this:GetRoot()
  local l_9_1, l_9_2 = l_9_0:GetAbsPos()
  BF_CombatStat.x = l_9_1
  BF_CombatStat.y = l_9_2
end

BF_CombatStat.UpdateTitleText = function()
  local l_10_0 = BF_CombatStat.frame:Lookup("Wnd_Title")
  local l_10_1 = l_10_0:Lookup("", "Text_name")
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.DAMAGE then
    l_10_1:SetText("�˺�ͳ��")
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.HEAL then
      l_10_1:SetText("����ͳ��")
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEDAMAGE then
      l_10_1:SetText("����ͳ��")
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEHEAL then
      l_10_1:SetText("����ͳ��")
    end
  end
end

BF_CombatStat.initHight = function(l_11_0)
  if not BF_CombatStat.oldHight then
    BF_CombatStat.oldHight = {}
    local l_11_1, l_11_2 = nil, nil
    l_11_1 = l_11_0:GetSize()
    local l_11_3 = BF_CombatStat.oldHight
    local l_11_4 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_5 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_6 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_7 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_8 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_11_1.bHideMost then
    l_11_0:SetSize(l_11_3.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[1] + 10, l_11_4.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[2] + 10)
    local l_11_9 = l_11_0:Lookup("Wnd_Main")
     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_9:SetSize(BF_CombatStat.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[1] + 10, l_11_5.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[2] + 10)
    local l_11_10 = l_11_9:Lookup("", "Image_Border")
     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_10:SetSize(BF_CombatStat.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[1] + 10, l_11_6.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[2] + 10)
    local l_11_11 = l_11_0:Lookup("Wnd_Output")
     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_11:SetSize(BF_CombatStat.oldHight.BigFoot_f26ec5f1f2736fc75fe52715c1dd8d83[1], l_11_7)
    if BF_CombatStat.UpdateScrollInfo(BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6) then
      BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(250, 0)
    else
      BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(270, 0)
    end
    BF_CombatStat.HideScroll(BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6, false)
  else
    l_11_0:SetSize(BF_CombatStat.oldHight.BigFoot_472c2502c09d0103ec5bb3a07a794147[1], BF_CombatStat.oldHight.BigFoot_472c2502c09d0103ec5bb3a07a794147[2])
    local l_11_12 = l_11_0:Lookup("Wnd_Main")
    l_11_12:SetSize(BF_CombatStat.oldHight.BigFoot_407802c72e4dfd2b7c59ac5ea0f9f54c[1], BF_CombatStat.oldHight.BigFoot_407802c72e4dfd2b7c59ac5ea0f9f54c[2])
    local l_11_13 = l_11_12:Lookup("", "Image_Border")
    l_11_13:SetSize(BF_CombatStat.oldHight.BigFoot_828fcde928414548d68b741c73cbb0d1[1], BF_CombatStat.oldHight.BigFoot_828fcde928414548d68b741c73cbb0d1[2])
    local l_11_14 = l_11_0:Lookup("Wnd_Output")
    l_11_14:SetSize(BF_CombatStat.oldHight.BigFoot_7ee81d986983869fcf0913182df081ce[1], BF_CombatStat.oldHight.BigFoot_7ee81d986983869fcf0913182df081ce[2])
    if BF_CombatStat.UpdateScrollInfo(BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6) then
      BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(250, 200)
    else
      BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(270, 200)
    end
    BF_CombatStat.HideScroll(BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6, true)
  end
   -- WARNING: undefined locals caused missing assignments!
end

BF_CombatStat.initwidth = function(l_12_0)
  local l_12_1 = l_12_0
  local l_12_2, l_12_3 = l_12_1:GetSize()
  l_12_1:SetSize(BF_CombatStat.nWidth + 5 + 20, l_12_3)
  local l_12_4 = l_12_1:Lookup("Wnd_Main")
  l_12_2 = l_12_4:GetSize()
  l_12_4:SetSize(BF_CombatStat.nWidth + 5 + 20, l_12_3)
  local l_12_5 = l_12_4:Lookup("", "Image_Border")
   -- DECOMPILER ERROR: Overwrote pending register.

  l_12_2 = l_12_5:GetSize()
  l_12_5:SetSize(BF_CombatStat.nWidth + 10 + 20, l_12_3)
  local l_12_6 = l_12_1:Lookup("Wnd_Title")
   -- DECOMPILER ERROR: Overwrote pending register.

  l_12_2 = l_12_6:GetSize()
  l_12_6:SetSize(BF_CombatStat.nWidth + 20, l_12_3)
  local l_12_7 = l_12_1:Lookup("Wnd_Output")
   -- DECOMPILER ERROR: Overwrote pending register.

  l_12_2 = l_12_7:GetSize()
  l_12_7:SetSize(BF_CombatStat.nWidth + 20, l_12_3)
  if BF_CombatStat.UpdateScrollInfo(BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6) then
    BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(250, 200)
  else
    BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:SetSize(270, 200)
  end
end

BF_CombatStat.OnLButtonClick = function()
  local l_13_0 = this:GetName()
  if l_13_0 == "Btn_Close" then
    BF_CombatStatHide()
    BF_COMBATSTAT_ENABLED = false
    BF_CombatStat.Clear()
  elseif l_13_0 == "Btn_Clear" then
    BF_CombatStat.Clear()
  elseif l_13_0 == "Btn_Config" then
    BF_CombatStat.config()
  elseif l_13_0 == "Btn_Speak" then
    BF_CombatStat.speakdamage()
  elseif l_13_0 == "Btn_Left" then
    local l_13_1 = BF_CombatStat.GetCurrentMode() - 1
    BF_CombatStat.SetCurrentMode(l_13_1)
  elseif l_13_0 == "Btn_Right" then
    local l_13_2 = BF_CombatStat.GetCurrentMode() + 1
    BF_CombatStat.SetCurrentMode(l_13_2)
  end
end

BF_CombatStat.UpdateTitleButton = function()
  local l_14_0 = BF_CombatStat.GetCurrentMode()
  local l_14_1 = BF_CombatStat.frame:Lookup("Wnd_Title")
  local l_14_2 = l_14_1:Lookup("Btn_Left")
  local l_14_3 = l_14_1:Lookup("Btn_Right")
  if l_14_0 == 1 then
    l_14_2:Enable(false)
    l_14_3:Enable(true)
  elseif l_14_0 == 4 then
    l_14_2:Enable(true)
    l_14_3:Enable(false)
  else
    l_14_2:Enable(true)
    l_14_3:Enable(true)
  end
end

BF_CombatStat.GetCurrentMode = function()
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.DAMAGE then
    return 1
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.HEAL then
      return 2
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEDAMAGE then
      return 3
    end
  else
    if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEHEAL then
      return 4
    end
  else
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.DAMAGE
    return 1
  end
end

BF_CombatStat.SetCurrentMode = function(l_16_0)
  if l_16_0 == 1 then
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.DAMAGE
  elseif l_16_0 == 2 then
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.HEAL
  elseif l_16_0 == 3 then
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.BEDAMAGE
  elseif l_16_0 == 4 then
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.BEHEAL
  else
    BF_CombatStat.nCurrentMode = BF_CombatStat_MODE.DAMAGE
  end
  BF_CombatStat.UpdateTitleText()
end

BF_CombatStat.UpdateScrollInfo = function(l_17_0)
  local l_17_1, l_17_2 = l_17_0:GetAllItemSize()
  local l_17_3, l_17_4 = l_17_0:GetSize()
  local l_17_5 = l_17_0:GetItemCount()
  local l_17_6 = math.ceil((l_17_2 - l_17_4) / 10)
  local l_17_7 = l_17_0:GetParent():GetParent()
  hScroll = l_17_7:Lookup("Scroll_List1")
  hScroll:SetStepCount(l_17_6)
  if l_17_6 > 0 then
    hScroll:Show()
    l_17_7:Lookup("Btn_Up1"):Show()
    l_17_7:Lookup("Btn_Down1"):Show()
    return true
  else
    hScroll:Hide()
    l_17_7:Lookup("Btn_Up1"):Hide()
    l_17_7:Lookup("Btn_Up1"):Enable(false)
    l_17_7:Lookup("Btn_Down1"):Hide()
    l_17_7:Lookup("Btn_Down1"):Enable(false)
    return false
  end
end

BF_CombatStat.HideScroll = function(l_18_0, l_18_1)
  local l_18_2 = l_18_0:GetParent():GetParent()
  local l_18_3 = l_18_2:Lookup("Scroll_List1")
  if l_18_1 then
    l_18_3:Show()
    l_18_2:Lookup("Btn_Up1"):Show()
    l_18_2:Lookup("Btn_Down1"):Show()
  else
    l_18_3:Hide()
    l_18_2:Lookup("Btn_Up1"):Hide()
    l_18_2:Lookup("Btn_Down1"):Hide()
  end
end

BF_CombatStat.OnItemMouseWheel = function()
  local l_19_0 = Station.GetMessageWheelDelta()
  local l_19_1 = this:GetName()
  if l_19_1 == "Handle_OutputText" then
    this:GetParent():GetParent():Lookup("Scroll_List1"):ScrollNext(l_19_0)
  end
  return 1
end

BF_CombatStat.OnScrollBarPosChanged = function()
  -- upvalues: l_0_0
  local l_20_0 = this:GetName()
  local l_20_1 = this:GetScrollPos()
  if l_20_0 == "Scroll_List1" then
    if l_20_1 == 0 then
      this:GetParent():Lookup("Btn_Up1"):Enable(false)
    else
      this:GetParent():Lookup("Btn_Up1"):Enable(true)
    end
    if l_20_1 == this:GetStepCount() then
      this:GetParent():Lookup("Btn_Down1"):Enable(false)
    else
      this:GetParent():Lookup("Btn_Down1"):Enable(true)
    end
    local l_20_2 = Station.Lookup("Normal/BF_CombatStat")
    local l_20_3 = l_20_2:Lookup("Wnd_Output")
    local l_20_4 = l_20_3:Lookup("", "Handle_OutputText")
    l_20_4:SetItemStartRelPos(0, -l_20_1 * l_0_0)
  end
end

BF_CombatStat.OnLButtonDown = function()
  BF_CombatStat.OnLButtonHold()
end

BF_CombatStat.OnLButtonHold = function()
  local l_22_0 = this:GetName()
  local l_22_1 = this:GetParent()
  if l_22_0 == "Btn_Up1" then
    l_22_1:Lookup("Scroll_List1"):ScrollPrev(1)
  elseif l_22_0 == "Btn_Down1" then
    l_22_1:Lookup("Scroll_List1"):ScrollNext(1)
  end
end

BF_CombatStat.OnItemMouseEnter = function()
  if this.BigFoot_b6676774baf2007174952747c40323e3 then
    local l_23_0 = BF_CombatStat.PlayerDataDisplayList[this.BigFoot_b6676774baf2007174952747c40323e3]
    if not l_23_0 then
      return 
    end
  end
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.DAMAGE then
    BF_CombatStat.ShowTipByDamage(l_23_0.DamageRecordList)
  end
end

BF_CombatStat.OnItemMouseLeave = function()
  local l_24_0 = this:GetName()
  if this.BigFoot_b6676774baf2007174952747c40323e3 then
    HideTip()
  end
end

BF_CombatStat.OnItemLButtonClick = function()
  local l_25_0 = this:GetName()
  if this.BigFoot_b6676774baf2007174952747c40323e3 then
    BF_ShowDetail.Show(BF_CombatStat.PlayerDataDisplayList[this.BigFoot_b6676774baf2007174952747c40323e3].szName)
  end
end

BF_CombatStat.ShowTipByDamage = function(l_26_0)
  if not l_26_0 then
    return 
  end
  local l_26_1 = ""
  for l_26_5,l_26_6 in pairs(l_26_0) do
    l_26_1 = l_26_1 .. l_26_5 .. " ���˺�:" .. l_26_6.nTotalDamage .. "\n"
    l_26_1 = l_26_1 .. string.format("����:%d, ����:%d, δ����:%d, ����:%d\n", l_26_6.nHitCount, l_26_6.nCriticalCount, l_26_6.nMissCount, l_26_6.nDodgeCount)
  end
  local l_26_7, l_26_12 = "<text>text=" .. EncodeComponentsString(l_26_1) .. " font=106 </text>"
  l_26_12 = this
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_26_8, l_26_9, l_26_13, l_26_14 = nil
  l_26_9 = this
  l_26_9, l_26_13 = l_26_9:GetSize, l_26_9
  l_26_9 = l_26_9(l_26_13)
  local l_26_10, l_26_11, l_26_15, l_26_16 = nil
  l_26_14 = OutputTip
  local l_26_17 = nil
  l_26_10 = l_26_7
  local l_26_18 = nil
  l_26_11 = 400
  local l_26_19 = nil
  do
    local l_26_20 = nil
    l_26_16 = l_26_12
    l_26_17 = l_26_8
    l_26_18 = l_26_9
    l_26_19 = 
    l_26_16 = 0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  l_26_14(l_26_10, l_26_11, {l_26_16, l_26_17, l_26_18, l_26_19}, l_26_16)
end

BF_CombatStat.OnEvent = function(l_27_0)
  if BF_COMBATSTAT_ENABLED then
    if l_27_0 == "SYS_MSG" then
      if arg0 == "UI_OME_SKILL_CAST_LOG" then
        do return end
      end
    end
    if arg0 == "UI_OME_SKILL_CAST_RESPOND_LOG" then
      do return end
    end
    if arg0 == "UI_OME_SKILL_EFFECT_LOG" then
      if arg7 and arg7 ~= 0 then
        BF_CombatStat.OnSkillEffect(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.CRITICAL, arg8, arg9)
      else
        BF_CombatStat.OnSkillEffect(arg1, arg2, arg4, arg5, arg6, SKILL_RESULT.HIT, arg8, arg9)
      end
    elseif arg0 == "UI_OME_SKILL_BLOCK_LOG" then
      BF_CombatStat.OnSkillEffect(arg1, arg2, arg3, arg4, arg5, SKILL_RESULT.BLOCK, arg6, 0)
    elseif arg0 == "UI_OME_SKILL_SHIELD" then
      BF_CombatStat.OnSkillEffect(arg1, arg2, arg3, arg4, arg5, SKILL_RESULT.SHIELD, nil, 0)
    elseif arg0 == "UI_OME_SKILL_MISS_LOG" then
      BF_CombatStat.OnSkillEffect(arg1, arg2, arg3, arg4, arg5, SKILL_RESULT.MISS, nil, 0)
    elseif arg0 == "UI_OME_SKILL_HIT_LOG" then
      do return end
    end
    if arg0 == "UI_OME_SKILL_DODGE_LOG" then
      BF_CombatStat.OnSkillEffect(arg1, arg2, arg3, arg4, arg5, SKILL_RESULT.DODGE, nil, 0)
     -- DECOMPILER ERROR: unhandled construct in 'if'

    elseif arg0 ~= "UI_OME_COMMON_HEALTH_LOG" or l_27_0 == "ON_BG_CHANNEL_MSG" then
      BF_CombatStat.ReceiveFocusInfo(arg0, arg1, arg2, arg3, GetClientPlayer().GetTalkData())
    end
  end
  if l_27_0 == "FIGHT_HINT" then
    if arg0 then
      BF_CombatStat.isfighting = true
      BF_CombatStat.startfighttime = GetTime()
      BF_CombatStat.totalfighttime = BF_CombatStat.totalfighttime + 0.01
      BF_CombatStat.fighttime = 0
    end
  else
    BF_CombatStat.isfighting = false
    BF_CombatStat.endfighttime = GetTime()
    BF_CombatStat.fighttime = BF_CombatStat.endfighttime - BF_CombatStat.startfighttime
    BF_CombatStat.totalfighttime = BF_CombatStat.totalfighttime + BF_CombatStat.fighttime
    BF_CombatStat.fighttime = 0
  end
  if l_27_0 == "CUSTOM_DATA_LOADED" then
    if BF_CombatStat.x ~= 0 and BF_CombatStat.y ~= 0 then
      this:GetRoot():SetAbsPos(BF_CombatStat.x, BF_CombatStat.y)
    else
      this:GetRoot():SetAbsPos(1200, 700)
    end
    BF_CombatStat.UpdateTitleText()
  end
end

BF_CombatStat.InitPlayerData = function(l_28_0)
  local l_28_1 = BF_CombatStat.PlayerDataRecordList
  local l_28_2 = l_28_0.szName
  local l_28_3 = {}
  l_28_3.szName = l_28_0.szName
  l_28_3.dwForceID = l_28_0.dwForceID
  l_28_3.playerID = l_28_0.dwID
  l_28_3.nTotalDamage = 0
  l_28_3.nTotalBeDamage = 0
  l_28_3.nTotalHeal = 0
  l_28_3.nTotalBeHeal = 0
  l_28_3.nTotalDeathCount = 0
  l_28_3.fDps = 0
  l_28_3.fHps = 0
  l_28_3.DamageRecordList = {}
  l_28_3.BeDamageRecordList = {}
  l_28_3.HealRecordList = {}
  l_28_3.BeHealRecordList = {}
  l_28_1[l_28_2] = l_28_3
  l_28_1 = Station
  l_28_1 = l_28_1.Lookup
  l_28_2 = "Normal/BF_CombatStat"
  l_28_1 = l_28_1(l_28_2)
  l_28_2, l_28_3 = l_28_1:Lookup, l_28_1
  l_28_2 = l_28_2(l_28_3, "Wnd_Output")
   -- DECOMPILER ERROR: Overwrote pending register.

  local l_28_4 = l_28_3:AppendItemFromIni("interface\\BF_CombatStat\\BF_CombatStat.ini", "Handle_Text")
  if l_28_0 and l_28_0.szName then
    l_28_4.name = l_28_0.szName
  else
    l_28_4.name = "**"
  end
  BF_CombatStat.initItem()
end

BF_CombatStat.initItem = function()
  local l_29_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_29_1 = l_29_0:Lookup("Wnd_Output")
  local l_29_2 = l_29_1:Lookup("", "Handle_OutputText")
  local l_29_3 = l_29_2:GetItemCount()
  for l_29_7 = 0, l_29_3 - 1 do
    local l_29_8 = l_29_2:Lookup(l_29_7)
    local l_29_9 = l_29_8:Lookup("Shadow_Entry_1")
    if not l_29_9 then
      return 
    end
    l_29_9:SetSize(0, 24)
    l_29_9:SetAlpha(120)
    l_29_9:SetRelPos(0, 2)
    l_29_8:Lookup("Image_Highlight_TL"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_TC"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_TR"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_CL"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_CC"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_CR"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_BL"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_BC"):SetSize(0, 0)
    l_29_8:Lookup("Image_Highlight_BR"):SetSize(0, 0)
    l_29_8:Lookup("Shadow_Highlight_L"):SetSize(0, 0)
    l_29_8:Lookup("Shadow_Highlight_C"):SetSize(0, 0)
    l_29_8:Lookup("Shadow_Highlight_R"):SetSize(0, 0)
    local l_29_10 = l_29_8:Lookup("Text_Entry_L1")
    l_29_10:SetText(l_29_8.name)
    local l_29_11 = l_29_8:Lookup("Text_Entry_R1")
    if not l_29_11 then
      return 
    end
    l_29_11:SetText("***")
    l_29_8:SetRelPos(0, 26 * l_29_7)
    l_29_8:Hide()
  end
  l_29_2:FormatAllItemPos()
  BF_CombatStat.UpdateScrollInfo(l_29_2)
end

BF_CombatStat.GetValueandTypefromResult = function(l_30_0, l_30_1)
  local l_30_2, l_30_3, l_30_4 = nil, nil, nil
  if type(l_30_1) == "table" then
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.PHYSICS_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.PHYSICS_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.POISON_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.POISON_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.THERAPY]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_THERAPY]
      l_30_4 = SKILL_RESULT_TYPE.THERAPY
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.REFLECTIED_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.REFLECTIED_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.STEAL_LIFE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.STEAL_LIFE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.ABSORB_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.ABSORB_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.SHIELD_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.SHIELD_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.PARRY_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.PARRY_DAMAGE
    end
    l_30_3 = l_30_1[SKILL_RESULT_TYPE.INSIGHT_DAMAGE]
    if l_30_3 and l_30_3 > 0 then
      l_30_2 = l_30_3
      if BF_CombatStat.BshoweffectiveValue then
        l_30_2 = l_30_1[SKILL_RESULT_TYPE.EFFECTIVE_DAMAGE]
      end
      l_30_4 = SKILL_RESULT_TYPE.INSIGHT_DAMAGE
    end
  else
    l_30_2 = 0
    l_30_4 = l_30_0
  end
  return l_30_2, l_30_4
end

BF_CombatStat.SpeakMPetCombat = function(l_31_0, l_31_1, l_31_2, l_31_3, l_31_4, l_31_5, l_31_6, l_31_7, l_31_8)
  local l_31_9 = GetClientPlayer()
  if not l_31_9 then
    return 
  end
  local l_31_10 = {}
  local l_31_11 = {}
  l_31_11.type = "text"
  l_31_11.text = "BG_CHANNEL_MSG"
  local l_31_12 = {}
  l_31_12.type = "text"
  l_31_12.text = "BF_Shaitongji"
  local l_31_13 = {}
  l_31_13.type = "text"
  l_31_13.text = tostring(l_31_0)
  local l_31_14 = {}
  l_31_14.type = "text"
  l_31_14.text = tostring(l_31_1)
  local l_31_15 = {}
  l_31_15.type = "text"
  l_31_15.text = tostring(l_31_2)
  local l_31_16 = {}
  l_31_16.type = "text"
  l_31_16.text = tostring(l_31_3)
  local l_31_17 = {}
  l_31_17.type = "text"
  l_31_17.text = tostring(l_31_4)
  local l_31_18 = {}
  l_31_18.type = "text"
  l_31_18.text = tostring(l_31_5)
  local l_31_19 = {}
  l_31_19.type = "text"
  l_31_19.text = tostring(l_31_6)
  local l_31_20 = {}
  l_31_20.type = "text"
  l_31_20.text = tonumber(l_31_7)
  local l_31_21 = {}
  l_31_21.type = "text"
  l_31_21.text = tonumber(l_31_8)
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_31_11 = l_31_9.Talk
  l_31_12 = 1
  l_31_13 = ""
  l_31_14 = l_31_10
  l_31_11(l_31_12, l_31_13, l_31_14)
end

BF_CombatStat.ReceiveFocusInfo = function(l_32_0, l_32_1, l_32_2, l_32_3, l_32_4)
  local l_32_5 = GetClientPlayer()
  if not l_32_5 then
    return 
  end
  if l_32_5.dwID == l_32_0 then
    return 
  end
  if not BF_COMBATSTAT_ENABLED then
    return 
  end
  if not l_32_4[2].text or l_32_4[2].text ~= "BF_Shaitongji" then
    return 
  end
  if not l_32_4[3].text then
    return 
  end
  do
    local l_32_6, l_32_7, l_32_9, l_32_12, l_32_16, l_32_21, l_32_27, l_32_34 = tonumber(l_32_4[3].text) or 0
  do
    end
    local l_32_8, l_32_10, l_32_13, l_32_17, l_32_22, l_32_28, l_32_35 = , tonumber(l_32_4[4].text) or 0
  do
    end
    local l_32_11, l_32_14, l_32_18, l_32_23, l_32_29, l_32_36 = , tonumber(l_32_4[5].text) or 0
  do
    end
    local l_32_15, l_32_19, l_32_24, l_32_30, l_32_37 = , tonumber(l_32_4[6].text) or 0
  do
    end
    local l_32_20, l_32_25, l_32_31, l_32_38 = nil
  do
    end
    local l_32_26, l_32_32, l_32_39 = nil
  do
    end
    local l_32_33, l_32_40 = nil
  end
  local l_32_41 = nil
  do
    local l_32_42, l_32_43, l_32_45 = nil
  do
    end
    local l_32_44, l_32_46 = nil
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  BF_CombatStat.OnSkillEffect(l_32_41, l_32_44, l_32_46, l_32_45, tonumber(l_32_4[7].text) or 0, tonumber(l_32_4[8].text) or 0, tonumber(l_32_4[9].text) or 0, {}, true, tonumber(l_32_4[10].text) or 0, tonumber(l_32_4[11].text) or 0)
end

BF_CombatStat.OnSkillEffect = function(l_33_0, l_33_1, l_33_2, l_33_3, l_33_4, l_33_5, l_33_6, l_33_7, l_33_8, l_33_9, l_33_10)
  local l_33_16, l_33_17 = nil
  if not l_33_8 then
    l_33_9 = BF_CombatStat.GetValueandTypefromResult(l_33_6, l_33_7)
  end
  if not l_33_9 then
    return 
  end
  if IsPlayer(l_33_0) then
    local l_33_11, l_33_12, l_33_13, l_33_14, l_33_15 = GetPlayer(l_33_0)
  else
    if not GetNpc(l_33_0) then
      return 
    end
    local l_33_18 = nil
    if IsPlayer(l_33_0) or l_33_18.dwEmployer == 0 or true then
      if IsPlayer(l_33_0) then
        l_33_18 = GetPlayer(l_33_0)
      else
        l_33_18 = GetNpc(l_33_0)
      end
    end
    if not l_33_18 then
      return 
    end
    if IsPlayer(l_33_1) then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if not GetPlayer(l_33_1) then
      return 
    end
    if l_33_2 == SKILL_EFFECT_TYPE.SKILL then
      do return end
    end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Overwrote pending register.

    if ((l_33_2 == SKILL_EFFECT_TYPE.BUFF and not l_33_8) or true) and not l_33_8 and l_33_10 ~= SKILL_RESULT_TYPE.THERAPY then
      BF_CombatStat.SpeakMPetCombat(l_33_0, l_33_1, l_33_2, l_33_3, l_33_4, l_33_5, l_33_6, l_33_9, l_33_10)
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if not Table_GetSkillName(l_33_3, l_33_4) or Table_GetSkillName(l_33_3, l_33_4) == "" then
      return 
    end
    local l_33_19 = nil
    local l_33_20 = nil
    do
      if IsPlayer(l_33_0) and function(l_34_0)
      -- upvalues: l_33_15 , l_33_16
      return l_33_15.IsPlayerInMyParty(l_34_0) or l_33_16.IsPlayerInTeam(l_34_0) or l_34_0 == l_33_15.dwID
    end(l_33_0) then
        function(l_35_0, l_35_1)
      -- upvalues: l_33_10 , l_33_1 , l_33_0 , l_33_12 , l_33_13 , l_33_2 , l_33_9 , l_33_5
      if BF_CombatStat.PlayerDataRecordList[l_35_0.szName] == nil then
        BF_CombatStat.InitPlayerData(l_35_0)
      end
      if l_33_10 ~= SKILL_RESULT_TYPE.THERAPY and l_33_1 ~= l_33_0 then
        BF_CombatStat.AddDamageRecord(l_35_0.szName, l_33_12.szName, l_33_13, l_33_2, l_33_9, l_33_5, l_33_10)
      else
        BF_CombatStat.AddHealRecord(l_35_0.szName, l_33_12.szName, l_33_13, l_33_2, l_33_9, l_33_5)
      end
    end(l_33_18)
      end
      do return end
      if (l_33_18.nIntensity == 2 or l_33_18.nIntensity == 6) and BF_CombatStat.countboss == true then
        if BF_CombatStat.PlayerDataRecordList[l_33_18.szName] == nil then
          BF_CombatStat.InitPlayerData(l_33_18)
        end
        if l_33_10 ~= SKILL_RESULT_TYPE.THERAPY then
          BF_CombatStat.AddDamageRecord(l_33_18.szName, l_33_19.szName, l_33_20, l_33_2, l_33_9, l_33_5)
        else
          BF_CombatStat.AddHealRecord(l_33_18.szName, l_33_19.szName, l_33_20, l_33_2, l_33_9, l_33_5)
        end
       -- DECOMPILER ERROR: Confused about usage of registers!

      elseif l_33_18.dwEmployer ~= 0 and function(l_34_0)
      -- upvalues: l_33_15 , l_33_16
      return l_33_15.IsPlayerInMyParty(l_34_0) or l_33_16.IsPlayerInTeam(l_34_0) or l_34_0 == l_33_15.dwID
    end(l_33_18.dwEmployer) then
        local l_33_23 = nil
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if GetPlayer(l_33_18.dwEmployer) then
        function(l_35_0, l_35_1)
      -- upvalues: l_33_10 , l_33_1 , l_33_0 , l_33_12 , l_33_13 , l_33_2 , l_33_9 , l_33_5
      if BF_CombatStat.PlayerDataRecordList[l_35_0.szName] == nil then
        BF_CombatStat.InitPlayerData(l_35_0)
      end
      if l_33_10 ~= SKILL_RESULT_TYPE.THERAPY and l_33_1 ~= l_33_0 then
        BF_CombatStat.AddDamageRecord(l_35_0.szName, l_33_12.szName, l_33_13, l_33_2, l_33_9, l_33_5, l_33_10)
      else
        BF_CombatStat.AddHealRecord(l_35_0.szName, l_33_12.szName, l_33_13, l_33_2, l_33_9, l_33_5)
      end
    end(GetPlayer(l_33_18.dwEmployer), true)
      end
      if IsPlayer(l_33_1) and (GetClientPlayer().IsPlayerInMyParty(l_33_1) or GetClientTeam().IsPlayerInTeam(l_33_1) or l_33_1 == GetClientPlayer().dwID) then
        if BF_CombatStat.PlayerDataRecordList[l_33_19.szName] == nil then
          BF_CombatStat.InitPlayerData(l_33_19)
        end
        if l_33_10 ~= SKILL_RESULT_TYPE.THERAPY then
          if l_33_10 == SKILL_RESULT_TYPE.REFLECTIED_DAMAGE then
            BF_CombatStat.AddDamageRecord(l_33_19.szName, l_33_18.szName, "����", l_33_2, l_33_9, l_33_5)
          end
          if l_33_10 == SKILL_RESULT_TYPE.ABSORB_DAMAGE then
            BF_CombatStat.AddBeDamageRecord(l_33_18.szName, l_33_19.szName, "���ջ���", l_33_2, l_33_9, l_33_5)
          end
          BF_CombatStat.AddBeDamageRecord(l_33_18.szName, l_33_19.szName, l_33_20, l_33_2, l_33_9, l_33_5)
        end
      else
        BF_CombatStat.AddBeHealRecord(l_33_18.szName, l_33_19.szName, l_33_20, l_33_2, l_33_9, l_33_5)
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 27 
end

BF_CombatStat.OnSkillBlock = function(l_34_0, l_34_1, l_34_2, l_34_3, l_34_4, l_34_5)
end

BF_CombatStat.OnSkillShield = function(l_35_0, l_35_1, l_35_2, l_35_3, l_35_4)
end

BF_CombatStat.OnSkillMiss = function(l_36_0, l_36_1, l_36_2, l_36_3, l_36_4)
end

BF_CombatStat.OnSkillHit = function(l_37_0, l_37_1, l_37_2, l_37_3, l_37_4)
end

BF_CombatStat.OnSkillDodge = function(l_38_0, l_38_1, l_38_2, l_38_3, l_38_4)
end

BF_CombatStat.AddDamageRecord = function(l_39_0, l_39_1, l_39_2, l_39_3, l_39_4, l_39_5, l_39_6)
  if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList == nil then
    return 
  end
  if not l_39_4 then
    l_39_4 = 0
  end
  if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2] == nil then
    local l_39_7 = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList
    local l_39_8 = {}
    l_39_8.szSkillName = l_39_2
    l_39_8.nMinHitDamage = nil
    l_39_8.nMaxHitDamage = nil
    l_39_8.nTotalHitDamage = 0
    l_39_8.nMinCriticalDamage = nil
    l_39_8.nMaxCriticalDamage = nil
    l_39_8.nTotalCriticalDamage = 0
    l_39_8.nTotalDamage = 0
    l_39_8.nTotalCount = 0
    l_39_8.nHitCount = 0
    l_39_8.nBlockCount = 0
    l_39_8.nShieldCount = 0
    l_39_8.nMissCount = 0
    l_39_8.nDodgeCount = 0
    l_39_8.nCriticalCount = 0
    l_39_8.nShipoCount = 0
    l_39_7[l_39_2] = l_39_8
  end
  local l_39_9 = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinDamage
  if l_39_9 == nil or l_39_4 < l_39_9 then
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinDamage = l_39_4
  end
  local l_39_10 = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxDamage
  if l_39_10 == nil or l_39_10 < l_39_4 then
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxDamage = l_39_4
  end
  BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalDamage = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalDamage + l_39_4
  BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalCount + 1
  if l_39_5 == SKILL_RESULT.HIT then
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalHitDamage = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalHitDamage + l_39_4
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nHitCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nHitCount + 1
    if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinHitDamage == nil or l_39_4 < BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinHitDamage then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinHitDamage = l_39_4
    end
    if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxHitDamage == nil or BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxHitDamage < l_39_4 then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxHitDamage = l_39_4
    end
  else
    if l_39_5 == SKILL_RESULT.CRITICAL then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalCriticalDamage = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nTotalCriticalDamage + l_39_4
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nCriticalCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nCriticalCount + 1
      if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinCriticalDamage == nil or l_39_4 < BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinCriticalDamage then
        BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMinCriticalDamage = l_39_4
      end
    if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxCriticalDamage ~= nil then
      end
    if BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxCriticalDamage ~= nil then
      end
    end
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMaxCriticalDamage = l_39_4
  else
    if l_39_5 == SKILL_RESULT.BLOCK then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nBlockCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nBlockCount + 1
    end
  else
    if l_39_5 == SKILL_RESULT.SHIELD then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nShieldCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nShieldCount + 1
    end
  else
    if l_39_5 == SKILL_RESULT.MISS then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMissCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nMissCount + 1
    end
  else
    if l_39_5 == SKILL_RESULT.DODGE then
      BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nDodgeCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nDodgeCount + 1
    end
  end
  if l_39_6 == SKILL_RESULT_TYPE.INSIGHT_DAMAGE then
    BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nShipoCount = BF_CombatStat.PlayerDataRecordList[l_39_0].DamageRecordList[l_39_2].nShipoCount + 1
  end
  BF_CombatStat.PlayerDataRecordList[l_39_0].nTotalDamage = BF_CombatStat.PlayerDataRecordList[l_39_0].nTotalDamage + l_39_4
end

BF_CombatStat.AddBeDamageRecord = function(l_40_0, l_40_1, l_40_2, l_40_3, l_40_4, l_40_5)
  if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList == nil then
    return 
  end
  if not l_40_4 then
    l_40_4 = 0
  end
  if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2] == nil then
    local l_40_6 = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList
    local l_40_7 = {}
    l_40_7.szSkillName = l_40_2
    l_40_7.nMinHitBeDamage = nil
    l_40_7.nMaxHitBeDamage = nil
    l_40_7.nTotalHitBeDamage = 0
    l_40_7.nMinCriticalBeDamage = nil
    l_40_7.nMaxCriticalBeDamage = nil
    l_40_7.nTotalCriticalBeDamage = 0
    l_40_7.nTotalBeDamage = 0
    l_40_7.nTotalCount = 0
    l_40_7.nHitCount = 0
    l_40_7.nBlockCount = 0
    l_40_7.nShieldCount = 0
    l_40_7.nMissCount = 0
    l_40_7.nDodgeCount = 0
    l_40_7.nCriticalCount = 0
    l_40_6[l_40_2] = l_40_7
  end
  local l_40_8 = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinBeDamage
  if l_40_8 == nil or l_40_4 < l_40_8 then
    BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinBeDamage = l_40_4
  end
  local l_40_9 = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxBeDamage
  if l_40_9 == nil or l_40_9 < l_40_4 then
    BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxBeDamage = l_40_4
  end
  BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalBeDamage = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalBeDamage + l_40_4
  BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalCount + 1
  if l_40_5 == SKILL_RESULT.HIT then
    BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalHitBeDamage = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalHitBeDamage + l_40_4
    BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nHitCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nHitCount + 1
    if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinHitBeDamage == nil or l_40_4 < BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinHitBeDamage then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinHitBeDamage = l_40_4
    end
    if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxHitBeDamage == nil or BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxHitBeDamage < l_40_4 then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxHitBeDamage = l_40_4
    end
  else
    if l_40_5 == SKILL_RESULT.CRITICAL then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalCriticalBeDamage = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nTotalCriticalBeDamage + l_40_4
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nCriticalCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nCriticalCount + 1
      if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinCriticalBeDamage == nil or l_40_4 < BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinCriticalBeDamage then
        BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMinCriticalBeDamage = l_40_4
      end
    if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxCriticalBeDamage ~= nil then
      end
    if BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxCriticalBeDamage ~= nil then
      end
    end
    BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMaxCriticalBeDamage = l_40_4
  else
    if l_40_5 == SKILL_RESULT.BLOCK then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nBlockCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nBlockCount + 1
    end
  else
    if l_40_5 == SKILL_RESULT.SHIELD then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nShieldCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nShieldCount + 1
    end
  else
    if l_40_5 == SKILL_RESULT.MISS then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMissCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nMissCount + 1
    end
  else
    if l_40_5 == SKILL_RESULT.DODGE then
      BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nDodgeCount = BF_CombatStat.PlayerDataRecordList[l_40_1].BeDamageRecordList[l_40_2].nDodgeCount + 1
    end
  end
  BF_CombatStat.PlayerDataRecordList[l_40_1].nTotalBeDamage = BF_CombatStat.PlayerDataRecordList[l_40_1].nTotalBeDamage + l_40_4
end

BF_CombatStat.AddHealRecord = function(l_41_0, l_41_1, l_41_2, l_41_3, l_41_4, l_41_5)
  if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList == nil then
    return 
  end
  if not l_41_4 then
    l_41_4 = 0
  end
  if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2] == nil then
    local l_41_6 = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList
    local l_41_7 = {}
    l_41_7.szSkillName = l_41_2
    l_41_7.nMinHitHeal = nil
    l_41_7.nMaxHitHeal = nil
    l_41_7.nTotalHitHeal = 0
    l_41_7.nMinCriticalHeal = nil
    l_41_7.nMaxCriticalHeal = nil
    l_41_7.nTotalCriticalHeal = 0
    l_41_7.nTotalHeal = 0
    l_41_7.nTotalCount = 0
    l_41_7.nHitCount = 0
    l_41_7.nBlockCount = 0
    l_41_7.nShieldCount = 0
    l_41_7.nMissCount = 0
    l_41_7.nDodgeCount = 0
    l_41_7.nCriticalCount = 0
    l_41_6[l_41_2] = l_41_7
  end
  local l_41_8 = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinHeal
  if l_41_8 == nil or l_41_4 < l_41_8 then
    BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinHeal = l_41_4
  end
  local l_41_9 = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxHeal
  if l_41_9 == nil or l_41_9 < l_41_4 then
    BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxHeal = l_41_4
  end
  BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalHeal = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalHeal + l_41_4
  BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalCount + 1
  if l_41_5 == SKILL_RESULT.HIT then
    BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalHitHeal = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalHitHeal + l_41_4
    BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nHitCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nHitCount + 1
    if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinHitHeal == nil or l_41_4 < BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinHitHeal then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinHitHeal = l_41_4
    end
    if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxHitHeal == nil or BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxHitHeal < l_41_4 then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxHitHeal = l_41_4
    end
  else
    if l_41_5 == SKILL_RESULT.CRITICAL then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalCriticalHeal = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nTotalCriticalHeal + l_41_4
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nCriticalCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nCriticalCount + 1
      if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinCriticalHeal == nil or l_41_4 < BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinCriticalHeal then
        BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMinCriticalHeal = l_41_4
      end
    if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxCriticalHeal ~= nil then
      end
    if BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxCriticalHeal ~= nil then
      end
    end
    BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMaxCriticalHeal = l_41_4
  else
    if l_41_5 == SKILL_RESULT.BLOCK then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nBlockCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nBlockCount + 1
    end
  else
    if l_41_5 == SKILL_RESULT.SHIELD then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nShieldCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nShieldCount + 1
    end
  else
    if l_41_5 == SKILL_RESULT.MISS then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMissCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nMissCount + 1
    end
  else
    if l_41_5 == SKILL_RESULT.DODGE then
      BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nDodgeCount = BF_CombatStat.PlayerDataRecordList[l_41_0].HealRecordList[l_41_2].nDodgeCount + 1
    end
  end
  BF_CombatStat.PlayerDataRecordList[l_41_0].nTotalHeal = BF_CombatStat.PlayerDataRecordList[l_41_0].nTotalHeal + l_41_4
end

BF_CombatStat.AddBeHealRecord = function(l_42_0, l_42_1, l_42_2, l_42_3, l_42_4, l_42_5)
  if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList == nil then
    return 
  end
  if not l_42_4 then
    l_42_4 = 0
  end
  if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2] == nil then
    local l_42_6 = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList
    local l_42_7 = {}
    l_42_7.szSkillName = l_42_2
    l_42_7.nMinHitBeHeal = nil
    l_42_7.nMaxHitBeHeal = nil
    l_42_7.nTotalHitBeHeal = 0
    l_42_7.nMinCriticalBeHeal = nil
    l_42_7.nMaxCriticalBeHeal = nil
    l_42_7.nTotalCriticalBeHeal = 0
    l_42_7.nTotalBeHeal = 0
    l_42_7.nTotalCount = 0
    l_42_7.nHitCount = 0
    l_42_7.nBlockCount = 0
    l_42_7.nShieldCount = 0
    l_42_7.nMissCount = 0
    l_42_7.nDodgeCount = 0
    l_42_7.nCriticalCount = 0
    l_42_6[l_42_2] = l_42_7
  end
  local l_42_8 = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinBeHeal
  if l_42_8 == nil or l_42_4 < l_42_8 then
    BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinBeHeal = l_42_4
  end
  local l_42_9 = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxBeHeal
  if l_42_9 == nil or l_42_9 < l_42_4 then
    BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxBeHeal = l_42_4
  end
  BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalBeHeal = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalBeHeal + l_42_4
  BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalCount + 1
  if l_42_5 == SKILL_RESULT.HIT then
    BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalHitBeHeal = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalHitBeHeal + l_42_4
    BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nHitCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nHitCount + 1
    if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinHitBeHeal == nil or l_42_4 < BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinHitBeHeal then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinHitBeHeal = l_42_4
    end
    if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxHitBeHeal == nil or BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxHitBeHeal < l_42_4 then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxHitBeHeal = l_42_4
    end
  else
    if l_42_5 == SKILL_RESULT.CRITICAL then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalCriticalBeHeal = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nTotalCriticalBeHeal + l_42_4
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nCriticalCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nCriticalCount + 1
      if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinCriticalBeHeal == nil or l_42_4 < BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinCriticalBeHeal then
        BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMinCriticalBeHeal = l_42_4
      end
    if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxCriticalBeHeal ~= nil then
      end
    if BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxCriticalBeHeal ~= nil then
      end
    end
    BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMaxCriticalBeHeal = l_42_4
  else
    if l_42_5 == SKILL_RESULT.BLOCK then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nBlockCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nBlockCount + 1
    end
  else
    if l_42_5 == SKILL_RESULT.SHIELD then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nShieldCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nShieldCount + 1
    end
  else
    if l_42_5 == SKILL_RESULT.MISS then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMissCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nMissCount + 1
    end
  else
    if l_42_5 == SKILL_RESULT.DODGE then
      BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nDodgeCount = BF_CombatStat.PlayerDataRecordList[l_42_1].BeHealRecordList[l_42_2].nDodgeCount + 1
    end
  end
  BF_CombatStat.PlayerDataRecordList[l_42_1].nTotalBeHeal = BF_CombatStat.PlayerDataRecordList[l_42_1].nTotalBeHeal + l_42_4
end

BF_CombatStat.Display = function()
  BF_CombatStat.initItem()
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.DAMAGE then
    BF_CombatStat.DisplayByDamage()
  end
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.HEAL then
    BF_CombatStat.DisplayByHeal()
  end
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEDAMAGE then
    BF_CombatStat.DisplayByBeDamage()
  end
  if BF_CombatStat.nCurrentMode == BF_CombatStat_MODE.BEHEAL then
    BF_CombatStat.DisplayByBeHeal()
  end
end

BF_CombatStat.DisplayByDamage = function()
  local l_44_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_44_1 = l_44_0:Lookup("Wnd_Output")
  local l_44_2 = l_44_1:Lookup("", "Handle_OutputText")
  local l_44_3 = 0
  local l_44_4 = 0
  local l_44_5 = 0
  BF_CombatStat.PlayerDataDisplayList = {}
  for l_44_9,l_44_10 in pairs(BF_CombatStat.PlayerDataRecordList) do
    BF_CombatStat.PlayerDataDisplayList[#BF_CombatStat.PlayerDataDisplayList + 1] = l_44_10
    l_44_3 = l_44_3 + l_44_10.nTotalDamage
  end
  table.sort(BF_CombatStat.PlayerDataDisplayList, function(l_45_0, l_45_1)
    return l_45_1.nTotalDamage < l_45_0.nTotalDamage
  end)
  for l_44_14,l_44_15 in ipairs(BF_CombatStat.PlayerDataDisplayList) do
    if l_44_14 == 1 then
      if l_44_15.nTotalDamage == 0 then
        do break end
      end
      l_44_4 = l_44_15.nTotalDamage
    end
    local l_44_16 = l_44_2:Lookup(l_44_14 - 1)
    if l_44_16 then
      local l_44_17, l_44_18 = BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:GetSize()
      local l_44_19 = l_44_15.nTotalDamage / l_44_4 * l_44_17
      local l_44_20 = l_44_16:Lookup("Shadow_Entry_1")
      if not l_44_20 then
        return 
      end
      local l_44_21, l_44_22 = l_44_20:GetSize()
      l_44_20:SetSize(l_44_19, l_44_22)
      l_44_20:SetRelPos(0, 0)
      local l_44_23 = l_44_16:Lookup("Image_Highlight_TL")
      local l_44_24 = l_44_16:Lookup("Image_Highlight_TC")
      local l_44_25 = l_44_16:Lookup("Image_Highlight_TR")
      local l_44_26 = l_44_16:Lookup("Image_Highlight_CL")
      local l_44_27 = l_44_16:Lookup("Image_Highlight_CC")
      local l_44_28 = l_44_16:Lookup("Image_Highlight_CR")
      local l_44_29 = l_44_16:Lookup("Image_Highlight_BL")
      local l_44_30 = l_44_16:Lookup("Image_Highlight_BC")
      local l_44_31 = l_44_16:Lookup("Image_Highlight_BR")
      local l_44_32 = l_44_16:Lookup("Shadow_Highlight_L")
      local l_44_33 = l_44_16:Lookup("Shadow_Highlight_C")
      local l_44_34 = l_44_16:Lookup("Shadow_Highlight_R")
      l_44_32:SetColorRGB(255, 255, 255)
      l_44_33:SetColorRGB(255, 255, 255)
      l_44_34:SetColorRGB(255, 255, 255)
      local l_44_35 = 9
      local l_44_36 = 9
      local l_44_37 = l_44_19
      local l_44_38 = l_44_22 + 7
      if l_44_37 < l_44_35 * 2 or l_44_38 < l_44_36 * 2 then
        local l_44_39 = l_44_37 / (l_44_35 * 2)
        local l_44_40 = l_44_38 / (l_44_36 * 2)
        local l_44_41 = math.min(l_44_39, l_44_40)
        local l_44_42 = l_44_35 * l_44_41
        local l_44_43 = l_44_36 * l_44_41
        l_44_32:SetSize(1, l_44_38 / 2 - 3)
        l_44_32:SetRelPos(2, 3)
        l_44_33:SetSize(l_44_37 - 6, l_44_38 / 2 - 3)
        l_44_33:SetRelPos(3, 2)
        l_44_34:SetSize(1, l_44_38 / 2 - 3)
        l_44_34:SetRelPos(l_44_37 - 2, 3)
        l_44_23:SetSize(l_44_42, l_44_43)
        l_44_23:SetRelPos(0, 0)
        l_44_24:SetSize(l_44_37 - 2 * l_44_42, l_44_43)
        l_44_24:SetRelPos(l_44_42, 0)
        l_44_25:SetSize(l_44_42, l_44_43)
        l_44_25:SetRelPos(l_44_37 - l_44_42, 0)
        l_44_26:SetSize(l_44_42, l_44_38 - 2 * l_44_43)
        l_44_26:SetRelPos(0, l_44_43)
        l_44_27:SetSize(l_44_37 - 2 * l_44_42, l_44_38 - 2 * l_44_43)
        l_44_27:SetRelPos(l_44_42, l_44_43)
        l_44_28:SetSize(l_44_42, l_44_38 - 2 * l_44_43)
        l_44_28:SetRelPos(l_44_37 - l_44_42, l_44_43)
        l_44_29:SetSize(l_44_42, l_44_43)
        l_44_29:SetRelPos(0, l_44_38 - l_44_43)
        l_44_30:SetSize(l_44_37 - 2 * l_44_42, l_44_43)
        l_44_30:SetRelPos(l_44_42, l_44_38 - l_44_43)
        l_44_31:SetSize(l_44_42, l_44_43)
        l_44_31:SetRelPos(l_44_37 - l_44_42, l_44_38 - l_44_43)
      else
        local l_44_44 = l_44_35
        local l_44_45 = l_44_36
        l_44_32:SetSize(1, l_44_38 / 2 - 3)
        l_44_32:SetRelPos(3, 3)
        l_44_33:SetSize(l_44_37 - 6, l_44_38 / 2 - 3)
        l_44_33:SetRelPos(3, 2)
        l_44_34:SetSize(1, l_44_38 / 2 - 3)
        l_44_34:SetRelPos(l_44_37 - 3, 3)
        l_44_23:SetSize(l_44_44, l_44_45)
        l_44_24:SetSize(l_44_37 - 2 * l_44_44, l_44_45)
        l_44_24:SetRelPos(l_44_44, 0)
        l_44_25:SetSize(l_44_44, l_44_45)
        l_44_25:SetRelPos(l_44_37 - l_44_44, 0)
        l_44_26:SetSize(l_44_44, l_44_38 - 2 * l_44_45)
        l_44_26:SetRelPos(0, l_44_45)
        l_44_27:SetSize(l_44_37 - 2 * l_44_44, l_44_38 - 2 * l_44_45)
        l_44_27:SetRelPos(l_44_44, l_44_45)
        l_44_28:SetSize(l_44_44, l_44_38 - 2 * l_44_45)
        l_44_28:SetRelPos(l_44_37 - l_44_44, l_44_45)
        l_44_29:SetSize(l_44_44, l_44_45)
        l_44_29:SetRelPos(0, l_44_38 - l_44_45)
        l_44_30:SetSize(l_44_37 - 2 * l_44_44, l_44_45)
        l_44_30:SetRelPos(l_44_44, l_44_38 - l_44_45)
        l_44_31:SetSize(l_44_44, l_44_45)
        l_44_31:SetRelPos(l_44_37 - l_44_44, l_44_38 - l_44_45)
      end
      if l_44_15.playerID and l_44_15.playerID == GetClientPlayer().dwID then
        l_44_20:SetColorRGB(unpack(BF_ClassColor[l_44_15.dwForceID][2]))
      elseif l_44_15.dwForceID then
        if BF_ClassColor[l_44_15.dwForceID] then
          l_44_20:SetColorRGB(unpack(BF_ClassColor[l_44_15.dwForceID][2]))
        else
          l_44_20:SetColorRGB(0, 0, 255)
        end
      else
        l_44_20:SetColorRGB(0, 0, 255)
      end
      local l_44_46 = l_44_16:Lookup("Text_Entry_L1")
      if not l_44_46 then
        return 
      end
      l_44_46.BigFoot_b6676774baf2007174952747c40323e3 = l_44_14
      l_44_46:SetText(l_44_15.szName)
      l_44_46:SetFontBorder(2, 36, 36, 36)
      local l_44_47 = l_44_16:Lookup("Text_Entry_R1")
      if not l_44_47 then
        return 
      end
      l_44_47.BigFoot_b6676774baf2007174952747c40323e3 = l_44_14
      l_44_47:SetFontBorder(2, 36, 36, 36)
      l_44_16:FormatAllItemPos()
      l_44_16:SetSizeByAllItemSize()
      local l_44_48, l_44_49 = l_44_16:GetSize()
      if BF_CombatStat_FANGSHI.fangshi == "TotalDamage" then
        local l_44_50 = l_44_15.nTotalDamage / (l_44_3) * 100
        l_44_47:SetText(l_44_15.nTotalDamage .. "(" .. string.format("%.1f", l_44_50) .. "%)")
      end
    else
      if BF_CombatStat.totalfighttime > 0 then
        if BF_CombatStat.isfighting then
          l_44_47:SetText(math.floor(l_44_15.nTotalDamage / math.floor((BF_CombatStat.totalfighttime + GetTime() - BF_CombatStat.startfighttime) / 1000)) .. "DPS")
        end
      else
        if math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000) == 0 then
          l_44_47:SetText("**")
        end
      else
        l_44_47:SetText(math.floor(l_44_15.nTotalDamage / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)) .. "DPS")
      end
    else
      l_44_47:SetText(l_44_15.nTotalDamage .. "DPS")
    end
  end
  l_44_2:FormatAllItemPos()
  BF_CombatStat.UpdateScrollInfo(l_44_2)
end

BF_CombatStat.DisplayByHeal = function()
  if BF_CombatStat.PlayerDataRecordList == nil then
    return 
  end
  local l_45_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_45_1 = l_45_0:Lookup("Wnd_Output")
  local l_45_2 = l_45_1:Lookup("", "Handle_OutputText")
  local l_45_3 = 0
  local l_45_4 = 0
  BF_CombatStat.PlayerDataDisplayList = {}
  for l_45_8,l_45_9 in pairs(BF_CombatStat.PlayerDataRecordList) do
    BF_CombatStat.PlayerDataDisplayList[#BF_CombatStat.PlayerDataDisplayList + 1] = l_45_9
    l_45_3 = l_45_3 + l_45_9.nTotalHeal
  end
  table.sort(BF_CombatStat.PlayerDataDisplayList, function(l_46_0, l_46_1)
    return l_46_1.nTotalHeal < l_46_0.nTotalHeal
  end)
  for l_45_13,l_45_14 in ipairs(BF_CombatStat.PlayerDataDisplayList) do
    if l_45_13 == 1 then
      if l_45_14.nTotalHeal == 0 then
        do break end
      end
      l_45_4 = l_45_14.nTotalHeal
    end
    local l_45_15 = l_45_2:Lookup(l_45_13 - 1)
    if l_45_15 then
      local l_45_16, l_45_17 = BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:GetSize()
      local l_45_18 = l_45_14.nTotalHeal / l_45_4 * l_45_16
      local l_45_19 = l_45_15:Lookup("Shadow_Entry_1")
      if not l_45_19 then
        return 
      end
      local l_45_20, l_45_21 = l_45_19:GetSize()
      l_45_19:SetSize(l_45_18 - 2, l_45_21)
      l_45_19:SetRelPos(0, 0)
      local l_45_22 = l_45_15:Lookup("Image_Highlight_TL")
      local l_45_23 = l_45_15:Lookup("Image_Highlight_TC")
      local l_45_24 = l_45_15:Lookup("Image_Highlight_TR")
      local l_45_25 = l_45_15:Lookup("Image_Highlight_CL")
      local l_45_26 = l_45_15:Lookup("Image_Highlight_CC")
      local l_45_27 = l_45_15:Lookup("Image_Highlight_CR")
      local l_45_28 = l_45_15:Lookup("Image_Highlight_BL")
      local l_45_29 = l_45_15:Lookup("Image_Highlight_BC")
      local l_45_30 = l_45_15:Lookup("Image_Highlight_BR")
      local l_45_31 = l_45_15:Lookup("Shadow_Highlight_L")
      local l_45_32 = l_45_15:Lookup("Shadow_Highlight_C")
      local l_45_33 = l_45_15:Lookup("Shadow_Highlight_R")
      l_45_31:SetColorRGB(255, 255, 255)
      l_45_32:SetColorRGB(255, 255, 255)
      l_45_33:SetColorRGB(255, 255, 255)
      local l_45_34 = 9
      local l_45_35 = 9
      local l_45_36 = l_45_18
      local l_45_37 = l_45_21 + 7
      if l_45_36 < l_45_34 * 2 or l_45_37 < l_45_35 * 2 then
        local l_45_38 = l_45_36 / (l_45_34 * 2)
        local l_45_39 = l_45_37 / (l_45_35 * 2)
        local l_45_40 = math.min(l_45_38, l_45_39)
        local l_45_41 = l_45_34 * l_45_40
        local l_45_42 = l_45_35 * l_45_40
        l_45_31:SetSize(1, l_45_37 / 2 - 3)
        l_45_31:SetRelPos(2, 3)
        l_45_32:SetSize(l_45_36 - 6, l_45_37 / 2 - 3)
        l_45_32:SetRelPos(3, 2)
        l_45_33:SetSize(1, l_45_37 / 2 - 3)
        l_45_33:SetRelPos(l_45_36 - 2, 3)
        l_45_22:SetSize(l_45_41, l_45_42)
        l_45_22:SetRelPos(0, 0)
        l_45_23:SetSize(l_45_36 - 2 * l_45_41, l_45_42)
        l_45_23:SetRelPos(l_45_41, 0)
        l_45_24:SetSize(l_45_41, l_45_42)
        l_45_24:SetRelPos(l_45_36 - l_45_41, 0)
        l_45_25:SetSize(l_45_41, l_45_37 - 2 * l_45_42)
        l_45_25:SetRelPos(0, l_45_42)
        l_45_26:SetSize(l_45_36 - 2 * l_45_41, l_45_37 - 2 * l_45_42)
        l_45_26:SetRelPos(l_45_41, l_45_42)
        l_45_27:SetSize(l_45_41, l_45_37 - 2 * l_45_42)
        l_45_27:SetRelPos(l_45_36 - l_45_41, l_45_42)
        l_45_28:SetSize(l_45_41, l_45_42)
        l_45_28:SetRelPos(0, l_45_37 - l_45_42)
        l_45_29:SetSize(l_45_36 - 2 * l_45_41, l_45_42)
        l_45_29:SetRelPos(l_45_41, l_45_37 - l_45_42)
        l_45_30:SetSize(l_45_41, l_45_42)
        l_45_30:SetRelPos(l_45_36 - l_45_41, l_45_37 - l_45_42)
      else
        local l_45_43 = l_45_34
        local l_45_44 = l_45_35
        l_45_31:SetSize(1, l_45_37 / 2 - 3)
        l_45_31:SetRelPos(3, 3)
        l_45_32:SetSize(l_45_36 - 6, l_45_37 / 2 - 3)
        l_45_32:SetRelPos(3, 2)
        l_45_33:SetSize(1, l_45_37 / 2 - 3)
        l_45_33:SetRelPos(l_45_36 - 3, 3)
        l_45_22:SetSize(l_45_43, l_45_44)
        l_45_23:SetSize(l_45_36 - 2 * l_45_43, l_45_44)
        l_45_23:SetRelPos(l_45_43, 0)
        l_45_24:SetSize(l_45_43, l_45_44)
        l_45_24:SetRelPos(l_45_36 - l_45_43, 0)
        l_45_25:SetSize(l_45_43, l_45_37 - 2 * l_45_44)
        l_45_25:SetRelPos(0, l_45_44)
        l_45_26:SetSize(l_45_36 - 2 * l_45_43, l_45_37 - 2 * l_45_44)
        l_45_26:SetRelPos(l_45_43, l_45_44)
        l_45_27:SetSize(l_45_43, l_45_37 - 2 * l_45_44)
        l_45_27:SetRelPos(l_45_36 - l_45_43, l_45_44)
        l_45_28:SetSize(l_45_43, l_45_44)
        l_45_28:SetRelPos(0, l_45_37 - l_45_44)
        l_45_29:SetSize(l_45_36 - 2 * l_45_43, l_45_44)
        l_45_29:SetRelPos(l_45_43, l_45_37 - l_45_44)
        l_45_30:SetSize(l_45_43, l_45_44)
        l_45_30:SetRelPos(l_45_36 - l_45_43, l_45_37 - l_45_44)
      end
      if l_45_14.playerID and l_45_14.playerID == GetClientPlayer().dwID then
        l_45_19:SetColorRGB(unpack(BF_ClassColor[l_45_14.dwForceID][2]))
      elseif l_45_14.dwForceID then
        if BF_ClassColor[l_45_14.dwForceID] then
          l_45_19:SetColorRGB(unpack(BF_ClassColor[l_45_14.dwForceID][2]))
        else
          l_45_19:SetColorRGB(0, 0, 255)
        end
      else
        l_45_19:SetColorRGB(0, 0, 255)
      end
      local l_45_45 = l_45_15:Lookup("Text_Entry_L1")
      if not l_45_45 then
        return 
      end
      l_45_45.BigFoot_b6676774baf2007174952747c40323e3 = l_45_13
      l_45_45:SetFontBorder(2, 36, 36, 36)
      l_45_45:SetText(l_45_14.szName)
      local l_45_46 = l_45_15:Lookup("Text_Entry_R1")
      if not l_45_46 then
        return 
      end
      l_45_46.BigFoot_b6676774baf2007174952747c40323e3 = l_45_13
      l_45_46:SetFontBorder(2, 36, 36, 36)
      l_45_15:FormatAllItemPos()
      l_45_15:SetSizeByAllItemSize()
      if BF_CombatStat_FANGSHI.fangshi == "TotalDamage" then
        local l_45_47 = l_45_14.nTotalHeal / (l_45_3) * 100
        l_45_46:SetText(l_45_14.nTotalHeal .. "(" .. string.format("%.1f", l_45_47) .. "%)")
      else
        if BF_CombatStat.totalfighttime > 0 then
          if BF_CombatStat.isfighting then
            l_45_46:SetText(math.floor(l_45_14.nTotalHeal / math.floor((BF_CombatStat.totalfighttime + GetTime() - BF_CombatStat.startfighttime) / 1000)) .. "HPS")
          end
        else
          if math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000) == 0 then
            l_45_46:SetText("**")
          end
        else
          l_45_46:SetText(math.floor(l_45_14.nTotalHeal / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)) .. "HPS")
        end
      else
        l_45_46:SetText(l_45_14.nTotalHeal .. "HPS")
      end
    else
      l_45_15:Hide()
    end
  end
  l_45_2:FormatAllItemPos()
  BF_CombatStat.UpdateScrollInfo(l_45_2)
end

BF_CombatStat.DisplayByBeDamage = function()
  local l_46_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_46_1 = l_46_0:Lookup("Wnd_Output")
  local l_46_2 = l_46_1:Lookup("", "Handle_OutputText")
  local l_46_3 = 0
  local l_46_4 = 0
  BF_CombatStat.PlayerDataDisplayList = {}
  for l_46_8,l_46_9 in pairs(BF_CombatStat.PlayerDataRecordList) do
    BF_CombatStat.PlayerDataDisplayList[#BF_CombatStat.PlayerDataDisplayList + 1] = l_46_9
    l_46_3 = l_46_3 + l_46_9.nTotalBeDamage
  end
  table.sort(BF_CombatStat.PlayerDataDisplayList, function(l_47_0, l_47_1)
    return l_47_1.nTotalBeDamage < l_47_0.nTotalBeDamage
  end)
  for l_46_13,l_46_14 in ipairs(BF_CombatStat.PlayerDataDisplayList) do
    if l_46_13 == 1 then
      if l_46_14.nTotalBeDamage == 0 then
        do break end
      end
      l_46_4 = l_46_14.nTotalBeDamage
    end
    local l_46_15 = l_46_2:Lookup(l_46_13 - 1)
    if l_46_15 then
      local l_46_16, l_46_17 = BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:GetSize()
      local l_46_18 = l_46_14.nTotalBeDamage / (l_46_3) * l_46_16
      local l_46_19 = l_46_15:Lookup("Shadow_Entry_1")
      if not l_46_19 then
        return 
      end
      local l_46_20, l_46_21 = l_46_19:GetSize()
      l_46_19:SetSize(l_46_18 - 2, l_46_21)
      l_46_19:SetRelPos(0, 0)
      local l_46_22 = l_46_15:Lookup("Image_Highlight_TL")
      local l_46_23 = l_46_15:Lookup("Image_Highlight_TC")
      local l_46_24 = l_46_15:Lookup("Image_Highlight_TR")
      local l_46_25 = l_46_15:Lookup("Image_Highlight_CL")
      local l_46_26 = l_46_15:Lookup("Image_Highlight_CC")
      local l_46_27 = l_46_15:Lookup("Image_Highlight_CR")
      local l_46_28 = l_46_15:Lookup("Image_Highlight_BL")
      local l_46_29 = l_46_15:Lookup("Image_Highlight_BC")
      local l_46_30 = l_46_15:Lookup("Image_Highlight_BR")
      local l_46_31 = l_46_15:Lookup("Shadow_Highlight_L")
      local l_46_32 = l_46_15:Lookup("Shadow_Highlight_C")
      local l_46_33 = l_46_15:Lookup("Shadow_Highlight_R")
      l_46_31:SetColorRGB(255, 255, 255)
      l_46_32:SetColorRGB(255, 255, 255)
      l_46_33:SetColorRGB(255, 255, 255)
      local l_46_34 = 9
      local l_46_35 = 9
      local l_46_36 = l_46_18
      local l_46_37 = l_46_21 + 7
      if l_46_36 < l_46_34 * 2 or l_46_37 < l_46_35 * 2 then
        local l_46_38 = l_46_36 / (l_46_34 * 2)
        local l_46_39 = l_46_37 / (l_46_35 * 2)
        local l_46_40 = math.min(l_46_38, l_46_39)
        local l_46_41 = l_46_34 * l_46_40
        local l_46_42 = l_46_35 * l_46_40
        l_46_31:SetSize(1, l_46_37 / 2 - 3)
        l_46_31:SetRelPos(2, 3)
        l_46_32:SetSize(l_46_36 - 6, l_46_37 / 2 - 3)
        l_46_32:SetRelPos(3, 2)
        l_46_33:SetSize(1, l_46_37 / 2 - 3)
        l_46_33:SetRelPos(l_46_36 - 2, 3)
        l_46_22:SetSize(l_46_41, l_46_42)
        l_46_22:SetRelPos(0, 0)
        l_46_23:SetSize(l_46_36 - 2 * l_46_41, l_46_42)
        l_46_23:SetRelPos(l_46_41, 0)
        l_46_24:SetSize(l_46_41, l_46_42)
        l_46_24:SetRelPos(l_46_36 - l_46_41, 0)
        l_46_25:SetSize(l_46_41, l_46_37 - 2 * l_46_42)
        l_46_25:SetRelPos(0, l_46_42)
        l_46_26:SetSize(l_46_36 - 2 * l_46_41, l_46_37 - 2 * l_46_42)
        l_46_26:SetRelPos(l_46_41, l_46_42)
        l_46_27:SetSize(l_46_41, l_46_37 - 2 * l_46_42)
        l_46_27:SetRelPos(l_46_36 - l_46_41, l_46_42)
        l_46_28:SetSize(l_46_41, l_46_42)
        l_46_28:SetRelPos(0, l_46_37 - l_46_42)
        l_46_29:SetSize(l_46_36 - 2 * l_46_41, l_46_42)
        l_46_29:SetRelPos(l_46_41, l_46_37 - l_46_42)
        l_46_30:SetSize(l_46_41, l_46_42)
        l_46_30:SetRelPos(l_46_36 - l_46_41, l_46_37 - l_46_42)
      else
        local l_46_43 = l_46_34
        local l_46_44 = l_46_35
        l_46_31:SetSize(1, l_46_37 / 2 - 3)
        l_46_31:SetRelPos(3, 3)
        l_46_32:SetSize(l_46_36 - 6, l_46_37 / 2 - 3)
        l_46_32:SetRelPos(3, 2)
        l_46_33:SetSize(1, l_46_37 / 2 - 3)
        l_46_33:SetRelPos(l_46_36 - 3, 3)
        l_46_22:SetSize(l_46_43, l_46_44)
        l_46_23:SetSize(l_46_36 - 2 * l_46_43, l_46_44)
        l_46_23:SetRelPos(l_46_43, 0)
        l_46_24:SetSize(l_46_43, l_46_44)
        l_46_24:SetRelPos(l_46_36 - l_46_43, 0)
        l_46_25:SetSize(l_46_43, l_46_37 - 2 * l_46_44)
        l_46_25:SetRelPos(0, l_46_44)
        l_46_26:SetSize(l_46_36 - 2 * l_46_43, l_46_37 - 2 * l_46_44)
        l_46_26:SetRelPos(l_46_43, l_46_44)
        l_46_27:SetSize(l_46_43, l_46_37 - 2 * l_46_44)
        l_46_27:SetRelPos(l_46_36 - l_46_43, l_46_44)
        l_46_28:SetSize(l_46_43, l_46_44)
        l_46_28:SetRelPos(0, l_46_37 - l_46_44)
        l_46_29:SetSize(l_46_36 - 2 * l_46_43, l_46_44)
        l_46_29:SetRelPos(l_46_43, l_46_37 - l_46_44)
        l_46_30:SetSize(l_46_43, l_46_44)
        l_46_30:SetRelPos(l_46_36 - l_46_43, l_46_37 - l_46_44)
      end
      if l_46_14.playerID and l_46_14.playerID == GetClientPlayer().dwID then
        l_46_19:SetColorRGB(unpack(BF_ClassColor[l_46_14.dwForceID][2]))
      elseif l_46_14.dwForceID then
        if BF_ClassColor[l_46_14.dwForceID] then
          l_46_19:SetColorRGB(unpack(BF_ClassColor[l_46_14.dwForceID][2]))
        else
          l_46_19:SetColorRGB(0, 0, 255)
        end
      else
        l_46_19:SetColorRGB(0, 0, 255)
      end
      local l_46_45 = l_46_15:Lookup("Text_Entry_L1")
      if not l_46_45 then
        return 
      end
      l_46_45.BigFoot_b6676774baf2007174952747c40323e3 = l_46_13
      l_46_45:SetFontBorder(2, 36, 36, 36)
      l_46_45:SetText(l_46_14.szName)
      local l_46_46 = l_46_15:Lookup("Text_Entry_R1")
      if not l_46_46 then
        return 
      end
      l_46_46.BigFoot_b6676774baf2007174952747c40323e3 = l_46_13
      l_46_46:SetFontBorder(2, 36, 36, 36)
      l_46_15:FormatAllItemPos()
      l_46_15:SetSizeByAllItemSize()
      if BF_CombatStat_FANGSHI.fangshi == "TotalDamage" then
        local l_46_47 = l_46_14.nTotalBeDamage / (l_46_3) * 100
        l_46_46:SetText(l_46_14.nTotalBeDamage .. "(" .. string.format("%.1f", l_46_47) .. "%)")
      else
        if BF_CombatStat.totalfighttime > 0 then
          if math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000) == 0 then
            l_46_46:SetText("**")
          end
        else
          l_46_46:SetText(math.floor(l_46_14.nTotalBeDamage / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)) .. "DPS")
        end
      else
        l_46_46:SetText(l_46_14.nTotalBeDamage .. "DPS")
      end
    else
      l_46_15:Hide()
    end
  end
  l_46_2:FormatAllItemPos()
  BF_CombatStat.UpdateScrollInfo(l_46_2)
end

BF_CombatStat.DisplayByBeHeal = function()
  if BF_CombatStat.PlayerDataRecordList == nil then
    return 
  end
  local l_47_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_47_1 = l_47_0:Lookup("Wnd_Output")
  local l_47_2 = l_47_1:Lookup("", "Handle_OutputText")
  local l_47_3 = 0
  local l_47_4 = 0
  BF_CombatStat.PlayerDataDisplayList = {}
  for l_47_8,l_47_9 in pairs(BF_CombatStat.PlayerDataRecordList) do
    BF_CombatStat.PlayerDataDisplayList[#BF_CombatStat.PlayerDataDisplayList + 1] = l_47_9
    l_47_3 = l_47_3 + l_47_9.nTotalBeHeal
  end
  table.sort(BF_CombatStat.PlayerDataDisplayList, function(l_48_0, l_48_1)
    return l_48_1.nTotalBeHeal < l_48_0.nTotalBeHeal
  end)
  for l_47_13,l_47_14 in ipairs(BF_CombatStat.PlayerDataDisplayList) do
    if BF_CombatStat.nMaxEntryCount < l_47_13 then
      do break end
    end
    if l_47_13 == 1 then
      if l_47_14.nTotalBeHeal == 0 then
        do break end
      end
      l_47_4 = l_47_14.nTotalBeHeal
    end
    local l_47_15 = l_47_2:Lookup(l_47_13 - 1)
    if l_47_15 then
      local l_47_16, l_47_17 = BF_CombatStat.BigFoot_9c1ad65d7b0c432cd133715570fd3ae6:GetSize()
      local l_47_18 = l_47_14.nTotalBeHeal / (l_47_3) * l_47_16
      local l_47_19 = l_47_15:Lookup("Shadow_Entry_1")
      if not l_47_19 then
        return 
      end
      local l_47_20, l_47_21 = l_47_19:GetSize()
      l_47_19:SetSize(l_47_18 - 2, l_47_21)
      l_47_19:SetRelPos(0, 0)
      local l_47_22 = l_47_15:Lookup("Image_Highlight_TL")
      local l_47_23 = l_47_15:Lookup("Image_Highlight_TC")
      local l_47_24 = l_47_15:Lookup("Image_Highlight_TR")
      local l_47_25 = l_47_15:Lookup("Image_Highlight_CL")
      local l_47_26 = l_47_15:Lookup("Image_Highlight_CC")
      local l_47_27 = l_47_15:Lookup("Image_Highlight_CR")
      local l_47_28 = l_47_15:Lookup("Image_Highlight_BL")
      local l_47_29 = l_47_15:Lookup("Image_Highlight_BC")
      local l_47_30 = l_47_15:Lookup("Image_Highlight_BR")
      local l_47_31 = l_47_15:Lookup("Shadow_Highlight_L")
      local l_47_32 = l_47_15:Lookup("Shadow_Highlight_C")
      local l_47_33 = l_47_15:Lookup("Shadow_Highlight_R")
      l_47_31:SetColorRGB(255, 255, 255)
      l_47_32:SetColorRGB(255, 255, 255)
      l_47_33:SetColorRGB(255, 255, 255)
      local l_47_34 = 9
      local l_47_35 = 9
      local l_47_36 = l_47_18
      local l_47_37 = l_47_21 + 7
      if l_47_36 < l_47_34 * 2 or l_47_37 < l_47_35 * 2 then
        local l_47_38 = l_47_36 / (l_47_34 * 2)
        local l_47_39 = l_47_37 / (l_47_35 * 2)
        local l_47_40 = math.min(l_47_38, l_47_39)
        local l_47_41 = l_47_34 * l_47_40
        local l_47_42 = l_47_35 * l_47_40
        l_47_31:SetSize(1, l_47_37 / 2 - 3)
        l_47_31:SetRelPos(2, 3)
        l_47_32:SetSize(l_47_36 - 6, l_47_37 / 2 - 3)
        l_47_32:SetRelPos(3, 2)
        l_47_33:SetSize(1, l_47_37 / 2 - 3)
        l_47_33:SetRelPos(l_47_36 - 2, 3)
        l_47_22:SetSize(l_47_41, l_47_42)
        l_47_22:SetRelPos(0, 0)
        l_47_23:SetSize(l_47_36 - 2 * l_47_41, l_47_42)
        l_47_23:SetRelPos(l_47_41, 0)
        l_47_24:SetSize(l_47_41, l_47_42)
        l_47_24:SetRelPos(l_47_36 - l_47_41, 0)
        l_47_25:SetSize(l_47_41, l_47_37 - 2 * l_47_42)
        l_47_25:SetRelPos(0, l_47_42)
        l_47_26:SetSize(l_47_36 - 2 * l_47_41, l_47_37 - 2 * l_47_42)
        l_47_26:SetRelPos(l_47_41, l_47_42)
        l_47_27:SetSize(l_47_41, l_47_37 - 2 * l_47_42)
        l_47_27:SetRelPos(l_47_36 - l_47_41, l_47_42)
        l_47_28:SetSize(l_47_41, l_47_42)
        l_47_28:SetRelPos(0, l_47_37 - l_47_42)
        l_47_29:SetSize(l_47_36 - 2 * l_47_41, l_47_42)
        l_47_29:SetRelPos(l_47_41, l_47_37 - l_47_42)
        l_47_30:SetSize(l_47_41, l_47_42)
        l_47_30:SetRelPos(l_47_36 - l_47_41, l_47_37 - l_47_42)
      else
        local l_47_43 = l_47_34
        local l_47_44 = l_47_35
        l_47_31:SetSize(1, l_47_37 / 2 - 3)
        l_47_31:SetRelPos(3, 3)
        l_47_32:SetSize(l_47_36 - 6, l_47_37 / 2 - 3)
        l_47_32:SetRelPos(3, 2)
        l_47_33:SetSize(1, l_47_37 / 2 - 3)
        l_47_33:SetRelPos(l_47_36 - 3, 3)
        l_47_22:SetSize(l_47_43, l_47_44)
        l_47_23:SetSize(l_47_36 - 2 * l_47_43, l_47_44)
        l_47_23:SetRelPos(l_47_43, 0)
        l_47_24:SetSize(l_47_43, l_47_44)
        l_47_24:SetRelPos(l_47_36 - l_47_43, 0)
        l_47_25:SetSize(l_47_43, l_47_37 - 2 * l_47_44)
        l_47_25:SetRelPos(0, l_47_44)
        l_47_26:SetSize(l_47_36 - 2 * l_47_43, l_47_37 - 2 * l_47_44)
        l_47_26:SetRelPos(l_47_43, l_47_44)
        l_47_27:SetSize(l_47_43, l_47_37 - 2 * l_47_44)
        l_47_27:SetRelPos(l_47_36 - l_47_43, l_47_44)
        l_47_28:SetSize(l_47_43, l_47_44)
        l_47_28:SetRelPos(0, l_47_37 - l_47_44)
        l_47_29:SetSize(l_47_36 - 2 * l_47_43, l_47_44)
        l_47_29:SetRelPos(l_47_43, l_47_37 - l_47_44)
        l_47_30:SetSize(l_47_43, l_47_44)
        l_47_30:SetRelPos(l_47_36 - l_47_43, l_47_37 - l_47_44)
      end
      if l_47_14.playerID and l_47_14.playerID == GetClientPlayer().dwID then
        l_47_19:SetColorRGB(unpack(BF_ClassColor[l_47_14.dwForceID][2]))
      elseif l_47_14.dwForceID then
        if BF_ClassColor[l_47_14.dwForceID] then
          l_47_19:SetColorRGB(unpack(BF_ClassColor[l_47_14.dwForceID][2]))
        else
          l_47_19:SetColorRGB(0, 0, 255)
        end
      else
        l_47_19:SetColorRGB(0, 0, 255)
      end
      local l_47_45 = l_47_15:Lookup("Text_Entry_L1")
      if not l_47_45 then
        return 
      end
      l_47_45.BigFoot_b6676774baf2007174952747c40323e3 = l_47_13
      l_47_45:SetFontBorder(2, 36, 36, 36)
      l_47_45:SetText(l_47_14.szName)
      local l_47_46 = l_47_15:Lookup("Text_Entry_R1")
      if not l_47_46 then
        return 
      end
      l_47_46.BigFoot_b6676774baf2007174952747c40323e3 = l_47_13
      l_47_46:SetFontBorder(2, 36, 36, 36)
      l_47_15:FormatAllItemPos()
      l_47_15:SetSizeByAllItemSize()
      if BF_CombatStat_FANGSHI.fangshi == "TotalDamage" then
        local l_47_47 = l_47_14.nTotalBeHeal / (l_47_3) * 100
        l_47_46:SetText(l_47_14.nTotalBeHeal .. "(" .. string.format("%.1f", l_47_47) .. "%)")
      else
        if BF_CombatStat.totalfighttime > 0 then
          l_47_46:SetText(math.floor(l_47_14.nTotalBeHeal / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)) .. "HPS")
        end
      else
        l_47_46:SetText(l_47_14.nTotalBeHeal .. "HPS")
      end
    else
      l_47_15:Hide()
    end
  end
  l_47_2:FormatAllItemPos()
  BF_CombatStat.UpdateScrollInfo(l_47_2)
end

BF_CombatStat.GetCharacter = function(l_48_0)
  if IsPlayer(l_48_0) then
    local l_48_1 = GetPlayer(l_48_0)
    if not l_48_1 then
      local l_48_2 = GetClientPlayer()
      if not l_48_2 then
        return 
      end
      local l_48_3, l_48_13 = GetClientTeam()
    end
    if l_48_3 then
      l_48_13 = l_48_3.GetMemberGroupIndex
      l_48_13 = l_48_13(l_48_2.dwID)
      local l_48_4, l_48_14 = nil
    end
    if l_48_13 and l_48_13 >= 0 then
      l_48_4 = l_48_3.GetGroupInfo
      l_48_14 = l_48_13
      l_48_4 = l_48_4(l_48_14)
      local l_48_5, l_48_15 = nil
      l_48_14 = pairs
      l_48_5 = l_48_4.MemberList
      l_48_14 = l_48_14(l_48_5)
      for l_48_9,l_48_10 in l_48_14 do
        local l_48_8, l_48_9, l_48_10 = nil
        do
          if l_48_0 == l_48_7 then
            local l_48_16, l_48_17, l_48_18, l_48_19, l_48_20 = nil
          end
          l_48_8 = l_48_3.GetMemberInfo
          l_48_9 = l_48_0
          local l_48_22 = nil
          l_48_8 = l_48_8(l_48_9)
          local l_48_21 = nil
          l_48_1 = l_48_8
        end
        do break end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    return l_48_1
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  else
    l_48_1 = GetNpc
    local l_48_11 = nil
    l_48_2 = l_48_0
    do
      local l_48_12 = nil
      return l_48_1(l_48_2)
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

BF_CombatStat.speakdamage = function()
  if BF_CombatStat.PlayerDataRecordList == nil then
    return 
  end
  local l_49_0 = GetClientPlayer()
  local l_49_1 = 0
  local l_49_2 = 0
  local l_49_3 = 0
  local l_49_4 = 0
  local l_49_5 = {}
  for l_49_9,l_49_10 in pairs(BF_CombatStat.PlayerDataRecordList) do
    l_49_5[#l_49_5 + 1] = l_49_10
    l_49_1 = l_49_1 + l_49_10.nTotalHeal
    l_49_2 = l_49_2 + l_49_10.nTotalDamage
    l_49_3 = l_49_3 + l_49_10.nTotalBeDamage
    l_49_4 = l_49_4 + l_49_10.nTotalBeHeal
  end
  local l_49_11, l_49_35 = 0
  l_49_35 = ""
  local l_49_12, l_49_36 = nil
  l_49_12 = #l_49_5
  if l_49_12 ~= 0 then
    l_49_12 = BF_CombatStat
    l_49_12 = l_49_12.nCurrentMode
    l_49_36 = BF_CombatStat_MODE
    l_49_36 = l_49_36.DAMAGE
    if l_49_12 == l_49_36 then
      l_49_12 = BF_CombatStat_FANGSHI
      l_49_12 = l_49_12.fangshi
    end
    if l_49_12 == "TotalDamage" then
      l_49_12 = l_49_35
      l_49_36 = "���˺���"
      l_49_35 = l_49_12 .. l_49_36
      l_49_12 = table
      l_49_12 = l_49_12.sort
      l_49_36 = l_49_5
      l_49_12(l_49_36, function(l_50_0, l_50_1)
        return l_50_1.nTotalDamage < l_50_0.nTotalDamage
      end)
    else
      l_49_12 = BF_CombatStat
      l_49_12 = l_49_12.nCurrentMode
      l_49_36 = BF_CombatStat_MODE
      l_49_36 = l_49_36.DAMAGE
      if l_49_12 == l_49_36 then
        l_49_12 = BF_CombatStat_FANGSHI
        l_49_12 = l_49_12.fangshi
      end
      if l_49_12 == "DPS" then
        l_49_12 = l_49_35
        l_49_36 = "ÿ���˺���"
        l_49_35 = l_49_12 .. l_49_36
        l_49_12 = table
        l_49_12 = l_49_12.sort
        l_49_36 = l_49_5
        l_49_12(l_49_36, function(l_51_0, l_51_1)
          return l_51_1.nTotalDamage < l_51_0.nTotalDamage
        end)
      end
    else
      l_49_12 = BF_CombatStat
      l_49_12 = l_49_12.nCurrentMode
      l_49_36 = BF_CombatStat_MODE
      l_49_36 = l_49_36.HEAL
      if l_49_12 == l_49_36 then
        l_49_12 = BF_CombatStat_FANGSHI
        l_49_12 = l_49_12.fangshi
      end
      if l_49_12 == "TotalDamage" then
        l_49_12 = l_49_35
        l_49_36 = "�����ƣ�"
        l_49_35 = l_49_12 .. l_49_36
        l_49_12 = table
        l_49_12 = l_49_12.sort
        l_49_36 = l_49_5
        l_49_12(l_49_36, function(l_52_0, l_52_1)
          return l_52_1.nTotalHeal < l_52_0.nTotalHeal
        end)
      end
    else
      l_49_12 = BF_CombatStat
      l_49_12 = l_49_12.nCurrentMode
      l_49_36 = BF_CombatStat_MODE
      l_49_36 = l_49_36.HEAL
      if l_49_12 == l_49_36 then
        l_49_12 = BF_CombatStat_FANGSHI
        l_49_12 = l_49_12.fangshi
      end
      if l_49_12 == "DPS" then
        l_49_12 = l_49_35
        l_49_36 = "ÿ�����ƣ�"
        l_49_35 = l_49_12 .. l_49_36
        l_49_12 = table
        l_49_12 = l_49_12.sort
        l_49_36 = l_49_5
        l_49_12(l_49_36, function(l_53_0, l_53_1)
          return l_53_1.nTotalHeal < l_53_0.nTotalHeal
        end)
      end
    else
      l_49_12 = BF_CombatStat
      l_49_12 = l_49_12.nCurrentMode
      l_49_36 = BF_CombatStat_MODE
      l_49_36 = l_49_36.BEDAMAGE
      if l_49_12 == l_49_36 then
        l_49_12 = l_49_35
        l_49_36 = "���ܵ��˺���"
        l_49_35 = l_49_12 .. l_49_36
        l_49_12 = table
        l_49_12 = l_49_12.sort
        l_49_36 = l_49_5
        l_49_12(l_49_36, function(l_54_0, l_54_1)
          return l_54_1.nTotalBeDamage < l_54_0.nTotalBeDamage
        end)
      end
    else
      l_49_12 = BF_CombatStat
      l_49_12 = l_49_12.nCurrentMode
      l_49_36 = BF_CombatStat_MODE
      l_49_36 = l_49_36.BEHEAL
    end
    if l_49_12 == l_49_36 then
      l_49_12 = l_49_35
      l_49_36 = "���ܵ����ƣ�"
      l_49_35 = l_49_12 .. l_49_36
      l_49_12 = table
      l_49_12 = l_49_12.sort
      l_49_36 = l_49_5
      l_49_12(l_49_36, function(l_55_0, l_55_1)
        return l_55_1.nTotalBeHeal < l_55_0.nTotalBeHeal
      end)
    end
    l_49_12 = l_49_0.Talk
    local l_49_13 = nil
    l_49_36 = zBF_CombatStatspeak
    local l_49_14 = nil
    l_49_13 = ""
    local l_49_15 = nil
    local l_49_16 = nil
    do
      local l_49_17 = nil
      l_49_15 = {type = "text", text = l_49_35}
      l_49_12(l_49_36, l_49_13, l_49_14)
      l_49_14 = {l_49_15}
      l_49_12 = ipairs
      l_49_36 = l_49_5
      l_49_12 = l_49_12(l_49_36)
      for l_49_14,l_49_15 in l_49_12 do
        l_49_16 = l_49_14
        l_49_17 = ":"
        l_49_16 = l_49_16 .. l_49_17 .. l_49_15.szName .. "��"
        local l_49_18 = nil
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.DAMAGE
        if l_49_17 == l_49_18 then
          l_49_17 = l_49_16
          l_49_18 = ""
          l_49_16 = l_49_17 .. l_49_18 .. l_49_15.nTotalDamage
          l_49_17 = nil
          local l_49_19 = nil
          if l_49_2 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = string
            l_49_18 = l_49_18.format
            l_49_19 = "%.2f"
            l_49_18 = l_49_18(l_49_19, l_49_15.nTotalDamage / (l_49_2) * 100)
            l_49_19 = "%"
            l_49_17 = l_49_18 .. l_49_19
          end
          l_49_18 = l_49_16
          l_49_19 = " ("
          l_49_16 = l_49_18 .. l_49_19 .. l_49_17 .. ")"
        end
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.DAMAGE
        if l_49_17 == l_49_18 then
          l_49_17 = nil
          local l_49_20 = nil
          l_49_18 = math
          l_49_18 = l_49_18.floor
          l_49_20 = BF_CombatStat
          l_49_20 = l_49_20.totalfighttime
          l_49_20 = l_49_20 + BF_CombatStat.fighttime
          l_49_20 = (l_49_20) / 1000
          l_49_18 = l_49_18(l_49_20)
          if l_49_18 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = math
            l_49_18 = l_49_18.floor
            l_49_20 = l_49_15.nTotalDamage
            l_49_20 = l_49_20 / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)
            l_49_18 = l_49_18(l_49_20)
            l_49_17 = l_49_18
          end
          l_49_18 = l_49_16
          l_49_20 = " �� "
          l_49_16 = l_49_18 .. l_49_20 .. l_49_17 .. "DPS"
        end
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.HEAL
        if l_49_17 == l_49_18 then
          l_49_17 = l_49_16
          l_49_18 = ""
          l_49_16 = l_49_17 .. l_49_18 .. l_49_15.nTotalHeal
          l_49_17 = nil
          local l_49_21 = nil
          if l_49_1 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = string
            l_49_18 = l_49_18.format
            l_49_21 = "%.2f"
            l_49_18 = l_49_18(l_49_21, l_49_15.nTotalHeal / (l_49_1) * 100)
            l_49_21 = "%"
            l_49_17 = l_49_18 .. l_49_21
          end
          l_49_18 = l_49_16
          l_49_21 = " ("
          l_49_16 = l_49_18 .. l_49_21 .. l_49_17 .. ")"
        end
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.HEAL
        if l_49_17 == l_49_18 then
          l_49_17 = nil
          local l_49_22 = nil
          l_49_18 = math
          l_49_18 = l_49_18.floor
          l_49_22 = BF_CombatStat
          l_49_22 = l_49_22.totalfighttime
          l_49_22 = l_49_22 + BF_CombatStat.fighttime
          l_49_22 = (l_49_22) / 1000
          l_49_18 = l_49_18(l_49_22)
          if l_49_18 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = math
            l_49_18 = l_49_18.floor
            l_49_22 = l_49_15.nTotalHeal
            l_49_22 = l_49_22 / math.floor((BF_CombatStat.totalfighttime + BF_CombatStat.fighttime) / 1000)
            l_49_18 = l_49_18(l_49_22)
            l_49_17 = l_49_18
          end
          l_49_18 = l_49_16
          l_49_22 = " �� "
          l_49_16 = l_49_18 .. l_49_22 .. l_49_17 .. "HPS"
        end
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.BEDAMAGE
        if l_49_17 == l_49_18 then
          l_49_17 = nil
          local l_49_23 = nil
          if l_49_3 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = string
            l_49_18 = l_49_18.format
            l_49_23 = "%.2f"
            l_49_18 = l_49_18(l_49_23, l_49_15.nTotalBeDamage / (l_49_3) * 100)
            l_49_23 = "%"
            l_49_17 = l_49_18 .. l_49_23
          end
          l_49_18 = l_49_16
          l_49_23 = ""
          l_49_16 = l_49_18 .. l_49_23 .. l_49_15.nTotalBeDamage
          l_49_18 = l_49_16
          l_49_23 = " ("
          l_49_16 = l_49_18 .. l_49_23 .. l_49_17 .. ")"
        end
        l_49_17 = BF_CombatStat
        l_49_17 = l_49_17.nCurrentMode
        l_49_18 = BF_CombatStat_MODE
        l_49_18 = l_49_18.BEHEAL
        if l_49_17 == l_49_18 then
          l_49_17 = nil
          local l_49_24 = nil
          if l_49_4 == 0 then
            l_49_17 = "**"
          else
            l_49_18 = string
            l_49_18 = l_49_18.format
            l_49_24 = "%.2f"
            l_49_18 = l_49_18(l_49_24, l_49_15.nTotalBeHeal / (l_49_4) * 100)
            l_49_24 = "%"
            l_49_17 = l_49_18 .. l_49_24
          end
          l_49_18 = l_49_16
          l_49_24 = ""
          l_49_16 = l_49_18 .. l_49_24 .. l_49_15.nTotalBeHeal
          l_49_18 = l_49_16
          l_49_24 = " ("
          l_49_16 = l_49_18 .. l_49_24 .. l_49_17 .. ")"
        end
        l_49_17 = l_49_0.Talk
        local l_49_25 = nil
        l_49_18 = zBF_CombatStatspeak
        local l_49_26 = nil
        l_49_25 = ""
        local l_49_27 = nil
        local l_49_28 = nil
        local l_49_29 = nil
        l_49_27 = {type = "text", text = l_49_16}
        l_49_17(l_49_18, l_49_25, l_49_26)
        l_49_26 = {l_49_27}
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  else
    l_49_35 = "û��ͳ�����ݡ�"
    local l_49_30, l_49_37 = nil
    local l_49_31, l_49_38 = nil
    local l_49_32, l_49_39 = nil
    do
      local l_49_33, l_49_40 = nil
      local l_49_34 = nil
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    l_49_0.Talk(zBF_CombatStatspeak, "", {l_49_30})
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

BF_CombatStat.Clear = function()
  BF_CombatStat.PlayerDataRecordList = {}
  BF_CombatStat.PlayerDataDisplayList = {}
  BF_CombatStat.Display()
  if BF_CombatStat.isfighting then
    BF_CombatStat.startfighttime = GetTime()
    BF_CombatStat.totalfighttime = 0.1
  else
    BF_CombatStat.totalfighttime = 0
    BF_CombatStat.startfighttime = 0
  end
  local l_50_0 = Station.Lookup("Normal/BF_CombatStat")
  local l_50_1 = l_50_0:Lookup("Wnd_Output")
  local l_50_2 = l_50_1:Lookup("", "Handle_OutputText")
  l_50_2:Clear()
end

BF_CombatStat.afterchanegmodle = function()
  local l_51_0 = {}
  l_51_0.szName = "�˺�ͳ��"
  l_51_0.szMessage = "�л�ͳ��ģʽ��Ҫ����֮ǰͳ�Ƶ����� ȷ���л�ô"
  l_51_0.fnCancelAction = function()
  end
  local l_51_1 = {}
  l_51_1.szOption = "ȷ��"
  l_51_1.fnAction = function()
    BF_CombatStat.BshoweffectiveValue = not BF_CombatStat.BshoweffectiveValue
    BF_CombatStat.Clear()
  end
  local l_51_2 = {}
  l_51_2.szOption = "ȡ��"
  l_51_2.fnAction = function()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  Msg = l_51_0
  l_51_0 = MessageBox
  l_51_1 = Msg
  l_51_0(l_51_1)
end

BF_CombatStat.config = function()
  local l_52_0 = {}
  local l_52_1 = {}
  l_52_1.szOption = "ͳ��ģʽ"
  l_52_1.fnAutoClose = function()
    return true
  end
  local l_52_2 = {}
  l_52_2.szOption = "ȫ������ͳ��"
  l_52_2.bDisable = false
  l_52_2.bMCheck = true
  l_52_2.bChecked = not BF_CombatStat.BshoweffectiveValue
  l_52_2.fnAction = function()
    BF_CombatStat.afterchanegmodle()
  end
  l_52_2.fnAutoClose = function()
    return true
  end
  local l_52_3 = {}
  l_52_3.szOption = "��Ч����ͳ��"
  l_52_3.bDisable = false
  l_52_3.bMCheck = true
  l_52_3.bChecked = BF_CombatStat.BshoweffectiveValue
  l_52_3.fnAction = function()
    BF_CombatStat.afterchanegmodle()
  end
  l_52_3.fnAutoClose = function()
    return true
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_52_3 = function()
    return true
  end
  local l_52_6 = {}
  l_52_6.szOption = "�Ŷ�"
  l_52_6.bDisable = false
  l_52_6.bMCheck = true
  l_52_6.bChecked = zBF_CombatStatspeak == PLAYER_TALK_CHANNEL.RAID
  l_52_6.fnAction = function()
    zBF_CombatStatspeak = PLAYER_TALK_CHANNEL.RAID
  end
  l_52_6.fnAutoClose = function()
    return true
  end
  local l_52_9 = {}
  l_52_9.szOption = "����"
  l_52_9.bDisable = false
  l_52_9.bMCheck = true
  l_52_9.bChecked = zBF_CombatStatspeak == PLAYER_TALK_CHANNEL.NEARBY
  l_52_9.fnAction = function()
    zBF_CombatStatspeak = PLAYER_TALK_CHANNEL.NEARBY
  end
  l_52_9.fnAutoClose = function()
    return true
  end
  local l_52_12 = {}
  l_52_12.szOption = "���"
  l_52_12.bDisable = false
  l_52_12.bMCheck = true
  l_52_12.bChecked = zBF_CombatStatspeak == PLAYER_TALK_CHANNEL.TONG
  l_52_12.fnAction = function()
    zBF_CombatStatspeak = PLAYER_TALK_CHANNEL.TONG
  end
  l_52_12.fnAutoClose = function()
    return true
  end
  l_52_3 = {szOption = "����", bDisable = false, bMCheck = true, bChecked = zBF_CombatStatspeak == PLAYER_TALK_CHANNEL.TEAM, fnAction = function()
    zBF_CombatStatspeak = PLAYER_TALK_CHANNEL.TEAM
  end, fnAutoClose = function()
    return true
  end}
  l_52_6 = function()
    return true
  end
  l_52_9 = BF_CombatStat_FANGSHI
  l_52_9 = l_52_9.fangshi
  l_52_9 = l_52_9 == "TotalDamage"
  l_52_9 = function()
    BF_CombatStat_FANGSHI.fangshi = "TotalDamage"
  end
  l_52_9 = function()
    return true
  end
  l_52_12 = BF_CombatStat_FANGSHI
  l_52_12 = l_52_12.fangshi
  l_52_12 = l_52_12 == "DPS"
  l_52_12 = function()
    BF_CombatStat_FANGSHI.fangshi = "DPS"
  end
  l_52_12 = function()
    return true
  end
  l_52_9, l_52_6 = {szOption = "ÿ���˺�������", bDisable = false, bMCheck = true, bChecked = l_52_12, fnAction = l_52_12, fnAutoClose = l_52_12}, {szOption = "�ܵ��˺�������", bDisable = false, bMCheck = true, bChecked = l_52_9, fnAction = l_52_9, fnAutoClose = l_52_9}
  l_52_9 = function()
    return true
  end
  l_52_12 = BF_CombatStat
  l_52_12 = l_52_12.countboss
  l_52_12 = l_52_12 == true
  l_52_12 = function()
    BF_CombatStat.countboss = true
  end
  l_52_12 = function()
    return true
  end
  l_52_12, l_52_9 = {szOption = "��", bDisable = false, bMCheck = true, bChecked = BF_CombatStat.countboss == false, fnAction = function()
    BF_CombatStat.countboss = false
  end, fnAutoClose = function()
    return true
  end}, {szOption = "��", bDisable = false, bMCheck = true, bChecked = l_52_12, fnAction = l_52_12, fnAutoClose = l_52_12}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_52_1 = PopupMenu
   -- DECOMPILER ERROR: Overwrote pending register.

  l_52_1(l_52_2)
  l_52_2 = {l_52_3, l_52_6, l_52_9, l_52_12; szOption = "����Ƶ��", fnAutoClose = l_52_3}
end

BF_CombatStatshow = function()
  local l_53_0 = Station.Lookup("Normal/BF_CombatStat")
  if l_53_0 then
    l_53_0:Show()
  else
    Wnd.OpenWindow("Interface\\BF_CombatStat\\BF_CombatStat.ini", "BF_CombatStat")
  end
end

BF_CombatStatHide = function()
  local l_54_0 = Station.Lookup("Normal/BF_CombatStat")
  if l_54_0 then
    l_54_0:Hide()
  end
end

BF_CombatStatshow()
BFConfigPanel.RegisterMod("CombatStats", "ս��ͳ��", "\\ui\\image\\icon\\skill_55.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
BFConfigPanel.RegisterCheckButton("CombatStats", "EnableCombatStats", "����ս��ͳ��", false, function(l_55_0)
  if l_55_0 then
    BF_COMBATSTAT_ENABLED = true
    BF_CombatStatshow()
  else
    BF_COMBATSTAT_ENABLED = false
    BF_CombatStatHide()
    BF_ShowDetail.BigFoot_472c2502c09d0103ec5bb3a07a794147:Hide()
    BF_CombatStat.Clear()
  end
end
)
BigFoot.RegisterMinimapButton("Interface\\BF_CombatStat\\CombatStat.tga", "<Text>text=\"��/�ر�ս��ͳ�ƴ���\"</Text>", "CombatStats", "EnableCombatStats")

