-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: frame.lua 

BFFrame = classv2(BFWidget)
addwidth = 0
BFFrame.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3)
  local l_1_4 = assert
  l_1_4(l_1_1 >= 0 and l_1_2 >= 0, "Invalid widget size.")
  l_1_4(l_1_0, l_1_1, l_1_2, l_1_3)
end

BFFrame.SetParent = function(l_2_0)
  assert(false, "Frame can not set parent.")
end

BFFrame.Hide = function(l_3_0)
  l_3_0.BigFoot_7ea16d69ee68978a562320944cf1ea36 = nil
  l_3_0.BigFoot_8e4f74b5cb61c65dbb632ec088fb7f6b = nil
  l_3_0.BigFoot_ac0723394133c458cf0a253e512eae56:Hide()
end

BFFrame.SetType = function(l_4_0, l_4_1)
  local l_4_2 = l_4_0:GetContainer()
  local l_4_3 = l_4_2:Lookup("", "")
  local l_4_4 = l_4_3:Lookup("Image_Background")
  local l_4_5 = l_4_2:Lookup("", "")
  local l_4_6 = l_4_2:Lookup("Btn_Close")
  if l_4_1 == "NONE" then
    l_4_4:Hide()
    l_4_6:Hide()
    l_4_5:Lookup("Image_BgTL"):Hide()
    l_4_5:Lookup("Image_BgTC"):Hide()
    l_4_5:Lookup("Image_BgTR"):Hide()
    l_4_5:Lookup("Image_BgML"):Hide()
    l_4_5:Lookup("Image_BgMC"):Hide()
    l_4_5:Lookup("Image_BgMR"):Hide()
    l_4_5:Lookup("Image_BgBL"):Hide()
    l_4_5:Lookup("Image_BgBC"):Hide()
    l_4_5:Lookup("Image_BgBR"):Hide()
  elseif l_4_1 == "PANEL" then
    l_4_4:Hide()
    l_4_6:Show()
    l_4_5:Lookup("Image_BgTL"):Show()
    l_4_5:Lookup("Image_BgTC"):Show()
    l_4_5:Lookup("Image_BgTR"):Show()
    l_4_5:Lookup("Image_BgML"):Show()
    l_4_5:Lookup("Image_BgMC"):Show()
    l_4_5:Lookup("Image_BgMR"):Show()
    l_4_5:Lookup("Image_BgBL"):Show()
    l_4_5:Lookup("Image_BgBC"):Show()
    l_4_5:Lookup("Image_BgBR"):Show()
  elseif l_4_1 == "FRAME" then
    l_4_4:FromUITex("Interface\\BF_Base\\widget\\artwork\\frame.UITex", 1)
    l_4_4:Show()
    l_4_6:Hide()
    l_4_5:Lookup("Image_BgTL"):Hide()
    l_4_5:Lookup("Image_BgTC"):Hide()
    l_4_5:Lookup("Image_BgTR"):Hide()
    l_4_5:Lookup("Image_BgML"):Hide()
    l_4_5:Lookup("Image_BgMC"):Hide()
    l_4_5:Lookup("Image_BgMR"):Hide()
    l_4_5:Lookup("Image_BgBL"):Hide()
    l_4_5:Lookup("Image_BgBC"):Hide()
    l_4_5:Lookup("Image_BgBR"):Hide()
  elseif l_4_1 == "TOOLTIP" then
    l_4_4:FromUITex("Interface\\BF_Base\\widget\\artwork\\frame.UITex", 2)
    l_4_4:Show()
    l_4_6:Hide()
    l_4_5:Lookup("Image_BgTL"):Hide()
    l_4_5:Lookup("Image_BgTC"):Hide()
    l_4_5:Lookup("Image_BgTR"):Hide()
    l_4_5:Lookup("Image_BgML"):Hide()
    l_4_5:Lookup("Image_BgMC"):Hide()
    l_4_5:Lookup("Image_BgMR"):Hide()
    l_4_5:Lookup("Image_BgBL"):Hide()
    l_4_5:Lookup("Image_BgBC"):Hide()
    l_4_5:Lookup("Image_BgBR"):Hide()
  end
  l_4_0.BigFoot_6d5e7d83d8358745ae4dcf61d16bd1f3 = l_4_1
end

BFFrame.Create = function(l_5_0, l_5_1, l_5_2, l_5_3)
  local l_5_4 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\frame.ini", l_5_0:GetName())
  assert(l_5_4, "Failed to create frame widget.")
  if l_5_3 == "PANEL" and (l_5_1 < 341 or l_5_2 < 137) then
    assert(nil, "The frame with PANEL must be larger enough.")
  end
  l_5_0:SetContainer(l_5_4)
  if not l_5_3 then
    l_5_3 = "PANEL"
    l_5_0.BigFoot_6d5e7d83d8358745ae4dcf61d16bd1f3 = "PANEL"
  end
  l_5_0:SetType(l_5_3)
  l_5_0:SetSize(l_5_1, l_5_2)
  l_5_4.BigFoot_4350eb5c77e4c9db3dc7371eeb400075 = l_5_0
  l_5_4.OnFrameShow = function()
    this.BigFoot_4350eb5c77e4c9db3dc7371eeb400075:_FireEvent("OnShow")
  end
  l_5_4.OnFrameHide = function()
    this.BigFoot_4350eb5c77e4c9db3dc7371eeb400075:_FireEvent("OnHide")
  end
  l_5_4.OnFrameBreathe = function()
    this.BigFoot_4350eb5c77e4c9db3dc7371eeb400075:_FireEvent("OnUpdate")
  end
  l_5_4.OnFrameRender = function()
    -- upvalues: l_5_0
    if l_5_0.BigFoot_8e4f74b5cb61c65dbb632ec088fb7f6b then
      local l_9_0 = l_5_0:GetContainer()
      local l_9_1, l_9_2 = l_9_0:GetAbsPos()
      l_5_0:ClearAllPoints()
      l_5_0:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_9_1, l_9_2)
      l_5_0:Update()
    end
    this.BigFoot_4350eb5c77e4c9db3dc7371eeb400075:_FireEvent("OnRender")
  end
  l_5_4.OnEvent = function(l_10_0)
    this.BigFoot_4350eb5c77e4c9db3dc7371eeb400075:_FireEvent("OnEvent", l_10_0)
  end
  l_5_4:Lookup("Btn_Close").OnLButtonClick = function()
    this:GetRoot().BigFoot_4350eb5c77e4c9db3dc7371eeb400075:Hide()
  end
end

BFFrame.StartMoving = function(l_6_0)
  l_6_0.BigFoot_8e4f74b5cb61c65dbb632ec088fb7f6b = true
  local l_6_1 = l_6_0:GetContainer()
  l_6_1:StartMoving()
end

BFFrame.EndMoving = function(l_7_0)
  l_7_0.BigFoot_8e4f74b5cb61c65dbb632ec088fb7f6b = nil
  local l_7_1 = l_7_0:GetContainer()
  local l_7_2, l_7_3 = l_7_1:GetAbsPos()
  l_7_0:ClearAllPoints()
  l_7_0:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_7_2, l_7_3)
  l_7_0:Update()
  l_7_1:EndMoving()
end

BFFrame.RegisterEvent = function(l_8_0, l_8_1)
  local l_8_2 = l_8_0:GetContainer()
  l_8_2:RegisterEvent(l_8_1)
end

BFFrame.SetFrameLevel = function(l_9_0, l_9_1)
  local l_9_2 = l_9_0:GetContainer()
  l_9_2:ChangeRelation(l_9_1)
end

BFFrame.SetTitle = function(l_10_0, l_10_1)
  local l_10_2 = l_10_0:GetContainer()
  local l_10_3 = l_10_2:Lookup("", "")
  local l_10_4 = l_10_3:Lookup("Text_Title")
  l_10_4:SetText(l_10_1)
end

BFFrame.SetStyle = function(l_11_0, ...)
  local l_11_2, l_11_3, l_11_4, l_11_5 = {...}, nil, nil, nil
  for l_11_9,l_11_10 in ipairs(l_11_2) do
    local l_11_6 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if R11_PC8 == "CLOSABLE" then
      l_11_3 = true
    elseif R11_PC8 == "NOCLOSABLE" then
      l_11_4 = true
    end
  end
  local l_11_11, l_11_14 = , assert
  if l_11_3 then
    local l_11_12 = not l_11_4
    l_11_12 = l_11_12
  end
  l_11_14(l_11_12, "The style CLOSABLE conflicts with NOCLOSABLE.")
  l_11_14, l_11_12 = l_11_0:GetContainer, l_11_0
  l_11_14 = l_11_14(l_11_12)
   -- DECOMPILER ERROR: Overwrote pending register.

  do
    local l_11_13, l_11_15 = nil
    if l_11_3 then
      l_11_13, l_11_15 = l_11_12:Show, l_11_12
      l_11_13(l_11_15)
    else
      l_11_13, l_11_15 = l_11_12:Hide, l_11_12
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    l_11_13(l_11_15)
  end
end

BFFrame._UpdateContent = function(l_12_0)
  local l_12_1 = l_12_0:GetContainer()
  local l_12_2 = l_12_1:Lookup("", "")
  local l_12_3 = (l_12_1:Lookup("Btn_Close"))
  local l_12_4, l_12_5 = nil, nil
  if l_12_2 then
    l_12_4 = l_12_2:Lookup("Image_Background")
    l_12_5 = l_12_2:Lookup("Text_Title")
    l_12_2:SetSize(BigFoot_aacf928ffa23e474a000b1b6292d02a9, BigFoot_ba70ac59c8a4b2cc67cf63223c84b656)
  end
  local l_12_6 = l_12_0:GetWidth()
  local l_12_7 = l_12_0:GetHeight()
  if l_12_0.BigFoot_6d5e7d83d8358745ae4dcf61d16bd1f3 == "PANEL" then
    l_12_4:Hide()
    l_12_2:Lookup("Image_BgTL"):Show()
    l_12_2:Lookup("Image_BgTC"):Show()
    l_12_2:Lookup("Image_BgTR"):Show()
    l_12_2:Lookup("Image_BgML"):Show()
    l_12_2:Lookup("Image_BgMC"):Show()
    l_12_2:Lookup("Image_BgMR"):Show()
    l_12_2:Lookup("Image_BgBL"):Show()
    l_12_2:Lookup("Image_BgBC"):Show()
    l_12_2:Lookup("Image_BgBR"):Show()
    l_12_2:Lookup("Image_BgTC"):SetSize(l_12_6 - 341 - 50, 52)
    l_12_2:Lookup("Image_BgML"):SetSize(8, l_12_7 - 137)
    l_12_2:Lookup("Image_BgMC"):SetSize(l_12_6 - 16 - 50, l_12_7 - 137)
    l_12_2:Lookup("Image_BgMR"):SetSize(8, l_12_7 - 137)
    l_12_2:Lookup("Image_BgBC"):SetSize(l_12_6 - 132 - 50, 85)
  elseif l_12_0.BigFoot_6d5e7d83d8358745ae4dcf61d16bd1f3 == "NONE" then
    if l_12_4 then
      l_12_4:Hide()
    end
  end
  if _handle then
    l_12_2:Lookup("Image_BgTL"):Hide()
    l_12_2:Lookup("Image_BgTC"):Hide()
    l_12_2:Lookup("Image_BgTR"):Hide()
    l_12_2:Lookup("Image_BgML"):Hide()
    l_12_2:Lookup("Image_BgMC"):Hide()
    l_12_2:Lookup("Image_BgMR"):Hide()
    l_12_2:Lookup("Image_BgBL"):Hide()
    l_12_2:Lookup("Image_BgBC"):Hide()
    l_12_2:Lookup("Image_BgBR"):Hide()
  end
  if l_12_4 then
    l_12_4:SetSize(l_12_6 - 50, l_12_7)
  end
  if l_12_3 then
    l_12_3:SetRelPos(l_12_6 - 50 - 34, 14)
  end
  if l_12_5 then
    l_12_5:SetSize(200, 30)
    l_12_5:SetRelPos((l_12_6 - 50 - 200) / 2, 10)
  end
end


