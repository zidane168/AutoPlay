-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: UpdateManager.lua 

if not RaidGridEx then
  RaidGridEx = {}
end
RaidGridEx.tGroupList = {}
RaidGridEx.tForceList = {}
RaidGridEx.tCustomList = {}
RaidGridEx.tRoleIDList = {}
RaidGridEx.nMaxCol = 5
RaidGridEx.nMaxRow = 5
local l_0_0 = "Interface/BF_RaidGridEx/RaidGridEx.ini"
RaidGridEx.CreateAllRoleHandle = function()
  -- upvalues: l_0_0
  RaidGridEx.handleRoles:Clear()
  for l_1_3 = 0, RaidGridEx.nMaxCol - 1 do
    for l_1_7 = 1, RaidGridEx.nMaxRow do
      local l_1_8 = RaidGridEx.handleRoles:AppendItemFromIni(l_0_0, "Handle_RoleDummy", "Handle_Role_" .. l_1_3 .. "_" .. l_1_7)
      if RaidGridEx.fScale then
        l_1_8:SetRelPos((l_1_3 * RaidGridEx.nColLength + RaidGridEx.nLeftBound) * RaidGridEx.fScale, ((l_1_7 - 1) * RaidGridEx.nRowLength + RaidGridEx.nBottomBound) * RaidGridEx.fScale)
      end
      l_1_8:Show()
      l_1_8.nGroupIndex = l_1_3
      l_1_8.nSortIndex = l_1_7
      l_1_8.dwMemberID = nil
      RaidGridEx.HideRoleHandle(l_1_3, l_1_7)
      l_1_8:Scale(RaidGridEx.fScale, RaidGridEx.fScale)
    end
  end
  RaidGridEx.handleRoles:FormatAllItemPos()
end

RaidGridEx.ShowRoleHandle = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = nil
  if not l_2_2 then
    l_2_3 = RaidGridEx
    l_2_3 = l_2_3.handleRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_2_3 then
    return 
  end
  l_2_3:Show()
  l_2_3:SetAlpha(255)
  l_2_3:Lookup("Text_Name"):SetText("")
  l_2_3:Lookup("Image_LifeBG"):Show()
  l_2_3:Lookup("Image_LifeBG"):SetAlpha(48)
  l_2_3:Lookup("Image_BGBox_White"):Show()
  l_2_3:Lookup("Image_BGBox_White"):SetAlpha(16)
  RaidGridEx.HideAllLifeBar(l_2_3)
  l_2_3:Lookup("Text_LifeValue"):SetText("")
  l_2_3:Lookup("Image_ManaBG"):Show()
  l_2_3:Lookup("Image_ManaBG"):SetAlpha(64)
  l_2_3:Lookup("Image_Mana"):Show()
  l_2_3:Lookup("Image_Leader"):Hide()
  l_2_3:Lookup("Image_Looter"):Hide()
  l_2_3:Lookup("Image_Mark"):Hide()
  l_2_3:Lookup("Image_MarkImage"):Hide()
  l_2_3:Lookup("Image_Matrix"):Hide()
end

RaidGridEx.HideRoleHandle = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = nil
  if not l_3_2 then
    l_3_3 = RaidGridEx
    l_3_3 = l_3_3.handleRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_3_3 then
    return 
  end
  l_3_3:Show()
  l_3_3:SetAlpha(32)
  l_3_3:Lookup("Text_Name"):SetText("")
  l_3_3:Lookup("Image_LifeBG"):Hide()
  l_3_3:Lookup("Image_BGBox_White"):Show()
  l_3_3:Lookup("Image_BGBox_White"):SetAlpha(8)
  RaidGridEx.HideAllLifeBar(l_3_3)
  l_3_3:Lookup("Text_LifeValue"):SetText("")
  l_3_3:Lookup("Image_ManaBG"):Hide()
  l_3_3:Lookup("Image_Mana"):Hide()
  l_3_3:Lookup("Image_Leader"):Hide()
  l_3_3:Lookup("Image_Looter"):Hide()
  l_3_3:Lookup("Image_Mark"):Hide()
  l_3_3:Lookup("Image_MarkImage"):Hide()
  l_3_3:Lookup("Image_Matrix"):Hide()
end

RaidGridEx.EnterRoleHandle = function(l_4_0, l_4_1, l_4_2)
  if not l_4_2 then
    l_4_2 = RaidGridEx.handleRoles:Lookup("Handle_Role_" .. l_4_0 .. "_" .. l_4_1)
  end
  if not l_4_2 then
    return 
  end
  if not l_4_0 then
    l_4_0 = l_4_2.nGroupIndex
  end
  if not l_4_1 then
    l_4_1 = l_4_2.nSortIndex
  end
  if l_4_2:GetAlpha() == 32 then
    l_4_2:SetAlpha(128)
  else
    if l_4_2:GetAlpha() == 255 then
      if RaidGridEx.tGroupList[l_4_0] then
        local l_4_3, l_4_4 = RaidGridEx.tGroupList[l_4_0][l_4_1]
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if not l_4_3 then
        return 
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_4_5 = nil
      if not RaidGridEx.GetTeamMemberInfo(l_4_3) then
        return 
      end
      if IsCtrlKeyDown() then
        local l_4_6 = nil
      end
      local l_4_7 = nil
      local l_4_8 = math.floor(RaidGridEx.GetTeamMemberInfo(l_4_3).nCurrentLife / RaidGridEx.GetTeamMemberInfo(l_4_3).nMaxLife * 100) .. "%"
      local l_4_9, l_4_10 = l_4_2:Lookup("Text_LifeValue"), RaidGridEx.GetTeamMemberInfo(l_4_5)
      local l_4_11, l_4_12 = RaidGridEx.frameSelf:GetAbsPos()
      local l_4_13 = RaidGridEx.frameSelf:GetSize()
      local l_4_14 = nil
      local l_4_15 = OutputTeamMemberTip
      l_4_15(l_4_5, {l_4_11, l_4_12, l_4_13, l_4_14})
    end
  end
end

RaidGridEx.LeaveRoleHandle = function(l_5_0, l_5_1, l_5_2)
  local l_5_3 = nil
  if not l_5_2 then
    l_5_3 = RaidGridEx
    l_5_3 = l_5_3.handleRoles
     -- DECOMPILER ERROR: Overwrote pending register.

  end
  if not l_5_3 then
    return 
  end
  if not l_5_0 then
    l_5_0 = l_5_3.nGroupIndex
  end
  if not l_5_0 then
    l_5_1 = l_5_3.nSortIndex
  end
  if l_5_3:GetAlpha() == 128 then
    RaidGridEx.HideRoleHandle(l_5_0, l_5_1, l_5_3)
  else
    if l_5_3:GetAlpha() == 255 then
      if RaidGridEx.handleLastSelect ~= l_5_3 then
        if l_5_3 then
          l_5_3:Lookup("Animate_SelectRole"):Hide()
        end
        RaidGridEx.handleLastSelect = nil
      end
      local l_5_4 = l_5_3:Lookup("Text_LifeValue")
      if RaidGridEx.tGroupList[l_5_0] then
        local l_5_5, l_5_6 = RaidGridEx.tGroupList[l_5_0][l_5_1]
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      local l_5_7 = nil
      if not RaidGridEx.GetTeamMemberInfo(l_5_5) then
        return 
      end
      HideTip()
    end
  end
end

RaidGridEx.GetHandlePosByID = function(l_6_0)
  for l_6_4 = 0, RaidGridEx.nMaxCol - 1 do
    for l_6_8 = 1, RaidGridEx.nMaxRow do
      if RaidGridEx.tGroupList and RaidGridEx.tGroupList[l_6_4] and RaidGridEx.tGroupList[l_6_4][l_6_8] == l_6_0 then
        return l_6_4, l_6_8
      end
    end
  end
end

RaidGridEx.GetHandleNameByID = function(l_7_0)
  local l_7_1, l_7_2 = RaidGridEx.GetHandlePosByID(l_7_0)
  if l_7_1 and l_7_2 then
    return "Handle_Role_" .. l_7_1 .. "_" .. l_7_2
  end
end

RaidGridEx.GetRoleHandleByID = function(l_8_0)
  local l_8_1 = RaidGridEx.GetHandleNameByID(l_8_0)
  if l_8_1 then
    return RaidGridEx.handleRoles:Lookup(l_8_1)
  end
end

RaidGridEx.GetCampColor = function(l_9_0)
  local l_9_1 = (RaidGridEx.GetTeamMemberInfo(l_9_0))
  local l_9_2 = nil
  if l_9_1 then
    l_9_2 = l_9_1.nCamp
  end
  if l_9_2 == CAMP.GOOD then
    return 0, 255, 0
  else
    if l_9_2 == CAMP.EVIL then
      return 255, 0, 0
    end
  else
    return 255, 255, 255
  end
end

RaidGridEx.GetKungfuByID = function(l_10_0)
  local l_10_1 = (RaidGridEx.GetTeamMemberInfo(l_10_0))
  local l_10_2 = nil
  if l_10_1 then
    l_10_2 = l_10_1.dwMountKungfuID
  end
  if not l_10_2 then
    local l_10_3 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_3
  elseif l_10_2 == 10080 then
    local l_10_4 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_4
  elseif l_10_2 == 10081 then
    local l_10_5 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_5
  elseif l_10_2 == 10021 then
    local l_10_6 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_6
  elseif l_10_2 == 10028 then
    local l_10_7 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_7
  elseif l_10_2 == 10026 then
    local l_10_8 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_8
  elseif l_10_2 == 10062 then
    local l_10_9 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_9
  elseif l_10_2 == 10002 then
    local l_10_10 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_10
  elseif l_10_2 == 10003 then
    local l_10_11 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_11
  elseif l_10_2 == 10014 then
    local l_10_12 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_12
  elseif l_10_2 == 10015 then
    local l_10_13 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_13
  elseif l_10_2 == 10144 then
    local l_10_14 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_14
  elseif l_10_2 == 10145 then
    local l_10_15 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_15
  elseif l_10_2 == 10175 then
    local l_10_16 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_16
  elseif l_10_2 == 10176 then
    local l_10_17 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_17
  elseif l_10_2 == 10225 then
    local l_10_18 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_18
  elseif l_10_2 == 10224 then
    local l_10_19 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    return l_10_19
  end
   -- WARNING: undefined locals caused missing assignments!
end

RaidGridEx.RedrawMemberHandleHPnMP = function(l_11_0)
  local l_11_1 = RaidGridEx.GetRoleHandleByID(l_11_0)
  local l_11_2 = RaidGridEx.GetTeamMemberInfo(l_11_0)
  if not l_11_1 or not l_11_2 then
    return 
  end
  l_11_1:Show()
  RaidGridEx.HideAllLifeBar(l_11_1)
  local l_11_3 = l_11_1:Lookup("Text_LifeValue")
  if l_11_2.bIsOnLine then
    local l_11_4 = l_11_2.nCurrentLife / l_11_2.nMaxLife
    if RaidGridEx.bAutoDistColor then
      if not l_11_1.imageLifeF then
        l_11_1.imageLifeF = l_11_1:Lookup("Image_Life_Green")
    else
      end
    end
    if l_11_4 <= 0.3 then
      l_11_1.imageLifeF = l_11_1:Lookup("Image_Life_Red")
    elseif l_11_4 <= 0.6 then
      l_11_1.imageLifeF = l_11_1:Lookup("Image_Life_Orange")
    else
      l_11_1.imageLifeF = l_11_1:Lookup("Image_Life_Green")
    end
    l_11_1.imageLifeF:Show()
    l_11_1.imageLifeF:SetPercentage(l_11_4)
    l_11_1.imageLifeF:SetAlpha(230)
    l_11_3:SetText("")
    l_11_3:Hide()
    if l_11_2.nCurrentLife and RaidGridEx.bShowLifeValue then
      local l_11_5 = l_11_2.nCurrentLife
      local l_11_6 = l_11_2.nMaxLife - l_11_2.nCurrentLife
      if RaidGridEx.bShowLastLife then
        if not l_11_2.bDeathFlag then
          l_11_3:SetText(l_11_5)
          l_11_3:SetFontColor(255, 255, 255)
        else
          l_11_3:SetText("����")
          l_11_3:SetFontColor(255, 0, 0)
        end
        if RaidGridEx.fScale * 0.8 < 1 then
          l_11_3:SetFontScale(RaidGridEx.fScale * 0.8)
        else
          l_11_3:SetFontScale(1)
        end
        l_11_3:Show()
      end
    elseif l_11_6 > 0 and not l_11_2.bDeathFlag then
      l_11_3:SetText("-" .. l_11_6)
      if RaidGridEx.fScale * 0.8 < 1 then
        l_11_3:SetFontScale(RaidGridEx.fScale * 0.8)
      else
        l_11_3:SetFontScale(1)
      end
      l_11_3:SetFontColor(255, 255, 255)
      l_11_3:Show()
    end
  else
    l_11_3:SetText("����")
    if RaidGridEx.fScale * 0.8 < 1 then
      l_11_3:SetFontScale(RaidGridEx.fScale * 0.8)
    else
      l_11_3:SetFontScale(1)
    end
    l_11_3:SetFontColor(96, 96, 96)
    l_11_3:Show()
  end
  local l_11_7 = l_11_1:Lookup("Image_Mana")
  l_11_7:SetPercentage(l_11_2.nCurrentMana / l_11_2.nMaxMana)
  if l_11_2.bIsOnLine then
    l_11_7:Show()
  else
    l_11_7:Hide()
  end
end

do
  local l_0_1 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

end
 -- WARNING: undefined locals caused missing assignments!

