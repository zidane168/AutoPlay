-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Block.lua 

local l_0_0 = {}
l_0_0.bEnable = true
BF_Block = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BF_Block.bEnable")
l_0_0 = RegisterCustomData
l_0_0("BF_Block.Filter")
l_0_0 = BF_Block
l_0_0.CalTimes = function(l_1_0)
  local l_1_1 = 0
  for l_1_5 in string.gfind(l_1_0, "text=") do
    l_1_1 = l_1_1 + 1
  end
  for l_1_9 in string.gfind(l_1_0, "path=") do
    l_1_1 = l_1_1 + 1
  end
  return l_1_1
end

l_0_0 = BF_Block
l_0_0.DoBlock = function(l_2_0, l_2_1)
  handle = Station.Lookup("Lowest2/ChatPanel" .. l_2_1):Lookup("Wnd_Message", "Handle_Message")
  for l_2_5 = 0, l_2_0 do
    handle:RemoveItem(handle:GetItemCount() - 1)
  end
end

local l_0_1 = table.insert
local l_0_2 = l_0_0
local l_0_3 = {}
l_0_3.bDevide = true
l_0_1(l_0_2, l_0_3)
l_0_1 = table
l_0_1 = l_0_1.insert
l_0_2 = l_0_0
l_0_1(l_0_2, l_0_3)
l_0_3 = {szOption = "���ӵ��������", bCheck = false, fnAction = function()
  local l_3_0, l_3_1 = GetClientPlayer().GetTarget()
  table.insert(BF_Block.Filter, "[" .. GetPlayer(l_3_1).szName .. "]")
  BigFoot_Print("BF_Block", "[" .. GetPlayer(l_3_1).szName .. "] ����������ź�������")
  fnAutoClose = function()
    return true
  end
end
}
l_0_1 = Target_AppendAddonMenu
l_0_2 = l_0_0
l_0_1(l_0_2)
l_0_1 = BF_Block
l_0_2 = function()
  m = {}
  for l_4_3 = 1, #BF_Block.Filter do
    do
      local l_4_4 = table.insert
      local l_4_5 = m
      local l_4_6 = {}
      l_4_6.szOption = " [" .. BF_Block.Filter[l_4_3] .. "] ����ɾ��"
      l_4_6.bChecked = false
      l_4_6.fnAutoClose = function()
        return true
      end
      l_4_6.fnAction = function()
        -- upvalues: l_4_3
        table.remove(BF_Block.Filter, l_4_3)
      end
      l_4_4(l_4_5, l_4_6)
    end
  end
  PopupMenu(m)
end

l_0_1.GetList = l_0_2
l_0_1 = BF_Block
l_0_2 = function(l_5_0)
  for l_5_4 = 1, #BF_Block.Filter do
    if string.find(l_5_0, BF_Block.Filter[l_5_4]) then
      BF_Block.DoBlock(BF_Block.CalTimes(l_5_0) - 1, 1)
      do break end
    end
  end
end

l_0_1.MonitorMsg_1 = l_0_2
l_0_1 = BF_Block
l_0_2 = function(l_6_0)
  for l_6_4 = 1, #BF_Block.Filter do
    if string.find(l_6_0, BF_Block.Filter[l_6_4]) then
      BF_Block.DoBlock(BF_Block.CalTimes(l_6_0) - 1, 3)
      do break end
    end
  end
end

l_0_1.MonitorMsg_4 = l_0_2
l_0_1 = BF_Block
l_0_2 = function(l_7_0)
  if l_7_0 then
    local l_7_1 = RegisterMsgMonitor
    local l_7_2 = BF_Block.MonitorMsg_1
    do
      local l_7_3 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_7_1(l_7_2, l_7_3)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_7_1(l_7_2, l_7_3)
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_7_1(l_7_2, l_7_3)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    local l_7_4 = l_7_1
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_7_5 = l_7_2.MonitorMsg_1
    local l_7_6 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_7_4(l_7_5, l_7_6)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_4(l_7_5, l_7_6)
    l_7_6 = {"MSG_WORLD", "MSG_CAMP", "MSG_MAP", "MSG_NORMAL", "MSG_BATTLE_FILED", "MSG_SCHOOL", "MSG_WHISPER", "MSG_NPC_YELL"}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_7_6 = "�رճɹ���������������������"
    l_7_4(l_7_5, l_7_6)
  end
end

l_0_1.Switcher = l_0_2
l_0_1 = AppendCommand
l_0_2 = "block"
l_0_3 = function(l_8_0)
  table.insert(BF_Block.Filter, l_8_0)
end

l_0_1(l_0_2, l_0_3)
l_0_1 = AppendCommand
l_0_2 = "clearblock"
l_0_3 = function()
  BF_Block.Filter = {}
end

l_0_1(l_0_2, l_0_3)
l_0_1 = BigFoot_Print
l_0_2 = "BF_Block"
l_0_3 = "���سɹ���"
l_0_1(l_0_2, l_0_3)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_2 = "Block"
l_0_3 = "��������"
l_0_1(l_0_2, l_0_3, "\\ui\\image\\icon\\skill_wanhua12.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_2 = "Block"
l_0_3 = "y0n"
l_0_1(l_0_2, l_0_3, "������������", true, function(l_10_0, l_10_1)
  BF_Block.bEnable = l_10_0
  BF_Block.Switcher(l_10_0)
end
)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.Registerbutton
l_0_2 = "Block"
l_0_3 = "func_Add"
l_0_1(l_0_2, l_0_3, "��������", false, function()
  if _a then
    GetUserInput("���ӹؼ���", function(l_12_0)
    table.insert(BF_Block.Filter, l_12_0)
  end, function()
  end, function()
  end, false, "")
  end
  _a = true
end
, 2)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.Registerbutton
l_0_2 = "Block"
l_0_3 = "func_Del"
l_0_1(l_0_2, l_0_3, "�༭�б�", false, function()
  if _b then
    BF_Block.GetList()
  end
  _b = true
end
, 7)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.Registerbutton
l_0_2 = "Block"
l_0_3 = "func_Re"
l_0_1(l_0_2, l_0_3, "����б�", false, function()
  if _c then
    BF_Block.Filter = {}
  end
  _c = true
end
, 12)

