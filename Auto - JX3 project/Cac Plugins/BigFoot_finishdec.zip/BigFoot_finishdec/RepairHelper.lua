-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RepairHelper.lua 

BF_RepairHelper = {}
RegisterEvent("SHOP_OPENSHOP", function()
  BF_RepairHelper.OpenShop(arg0, arg1, arg2, arg3, arg4)
end
)
BF_RepairHelper.OpenShop = function(l_2_0, l_2_1, l_2_2, l_2_3, l_2_4, l_2_5, ...)
  if BF_RepairHelper.Enabled and l_2_3 and GetRepairAllItemsPrice(l_2_4, l_2_0) > 0 then
    local l_2_7 = nil
  end
  if GetClientPlayer() then
    local l_2_8 = nil
  end
  if l_2_7 < GetClientPlayer().GetMoney() then
    RepairAllItems(l_2_4, l_2_0)
  end
end

BFConfigPanel.RegisterMod("RepairHelper", "��������", "\\ui\\image\\icon\\tool02.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("RepairHelper", "AutoRepair", "�Զ��������ϵ�װ��", true, function(l_3_0)
  if l_3_0 then
    BF_RepairHelper.Enabled = true
  else
    BF_RepairHelper.Enabled = false
  end
end
)

