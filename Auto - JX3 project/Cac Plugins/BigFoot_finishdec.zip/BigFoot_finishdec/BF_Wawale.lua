-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Wawale.lua 

local l_0_0 = {}
l_0_0.tDoodadList = {}
l_0_0.Interval = 16
l_0_0.szMode = "M1"
l_0_0.bHerbs = true
l_0_0.bMineral = true
BF_Wawale = l_0_0
l_0_0 = BF_Wawale
local l_0_1 = {}
local l_0_2 = {}
l_0_2.szName = "�ʲ�"
l_0_2.bOn = false
l_0_1[1] = l_0_2
l_0_1[2], l_0_2 = l_0_2, {szName = "���", bOn = false}
l_0_1[3], l_0_2 = l_0_2, {szName = "��ҩ", bOn = false}
l_0_1[4], l_0_2 = l_0_2, {szName = "����", bOn = false}
l_0_1[5], l_0_2 = l_0_2, {szName = "��˼��", bOn = false}
l_0_1[6], l_0_2 = l_0_2, {szName = "��ǰ��", bOn = false}
l_0_1[7], l_0_2 = l_0_2, {szName = "������", bOn = false}
l_0_1[8], l_0_2 = l_0_2, {szName = "����", bOn = false}
l_0_1[9], l_0_2 = l_0_2, {szName = "��ζ��", bOn = false}
l_0_1[10], l_0_2 = l_0_2, {szName = "������", bOn = false}
l_0_1[11], l_0_2 = l_0_2, {szName = "��С��", bOn = false}
l_0_1[12], l_0_2 = l_0_2, {szName = "���", bOn = false}
l_0_1[13], l_0_2 = l_0_2, {szName = "ǧ����", bOn = false}
l_0_1[14], l_0_2 = l_0_2, {szName = "����", bOn = false}
l_0_1[15], l_0_2 = l_0_2, {szName = "����", bOn = false}
l_0_1[16], l_0_2 = l_0_2, {szName = "Զ־", bOn = false}
l_0_1[17], l_0_2 = l_0_2, {szName = "��é", bOn = false}
l_0_1[18], l_0_2 = l_0_2, {szName = "��", bOn = false}
l_0_1[19], l_0_2 = l_0_2, {szName = "����", bOn = false}
l_0_1[20], l_0_2 = l_0_2, {szName = "���", bOn = false}
l_0_0.tTableHerbs = l_0_1
l_0_0 = BF_Wawale
l_0_2 = {szName = "ͭ��", bOn = false}
l_0_2 = {szName = "����", bOn = false}
l_0_2 = {szName = "Ǧ��", bOn = false}
l_0_2 = {szName = "п��", bOn = false}
l_0_2 = {szName = "����", bOn = false}
l_0_2 = {szName = "����", bOn = false}
l_0_2 = {szName = "��ɰ��", bOn = false}
l_0_2 = {szName = "����", bOn = false}
l_0_2 = {szName = "����", bOn = false}
l_0_0.tTableMineral, l_0_1 = l_0_1, {[1] = l_0_2, [2] = l_0_2, [3] = l_0_2, [4] = l_0_2, [5] = l_0_2, [6] = l_0_2, [7] = l_0_2, [8] = l_0_2, [9] = l_0_2}
l_0_0 = RegisterCustomData
l_0_1 = "BF_Wawale.bHerbs"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_Wawale.bMineral"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_Wawale.tTableHerbs"
l_0_0(l_0_1)
l_0_0 = RegisterCustomData
l_0_1 = "BF_Wawale.tTableMineral"
l_0_0(l_0_1)
l_0_0 = RegisterEvent
l_0_1 = "DOODAD_ENTER_SCENE"
l_0_2 = function()
  BF_Wawale.SaveDooList(arg0)
end

l_0_0(l_0_1, l_0_2)
l_0_0 = RegisterEvent
l_0_1 = "DOODAD_LEAVE_SCENE"
l_0_2 = function()
  table.remove(BF_Wawale.tDoodadList, arg0)
end

l_0_0(l_0_1, l_0_2)
l_0_0 = BF_Wawale
l_0_1 = function()
  if not BF_Wawale.bEnable then
    return 
  end
  if GetLogicFrameCount() % BF_Wawale.Interval ~= 0 then
    return 
  end
  local l_3_0 = GetClientPlayer()
  if not l_3_0 then
    return 
  end
  if BF_Wawale.bFightoff and l_3_0.bFightState then
    return 
  end
  if l_3_0.nMoveState == 1 and l_3_0.GetOTActionState() == 0 then
    BF_Wawale.Pick()
  end
end

l_0_0.OnFrameBreathe = l_0_1
l_0_0 = BF_Wawale
l_0_1 = function(l_4_0)
  local l_4_1 = GetDoodad(l_4_0)
  if l_4_1 then
    table.insert(BF_Wawale.tDoodadList, l_4_0)
  end
end

l_0_0.SaveDooList = l_0_1
l_0_0 = BF_Wawale
l_0_1 = function()
  for l_5_3,l_5_4 in pairs(BF_Wawale.tDoodadList) do
    local l_5_5 = GetDoodad(l_5_4)
    local l_5_6 = GetClientPlayer()
    if l_5_5 and l_5_5.CanDialog(l_5_6) and l_5_5 then
      if BF_Wawale.bHerbs then
        for l_5_10,l_5_11 in pairs(BF_Wawale.tTableHerbs) do
          if l_5_5.szName == l_5_11.szName and l_5_11.bOn then
            InteractDoodad(l_5_4)
          end
        end
      end
      if BF_Wawale.bMineral then
        for l_5_15,l_5_16 in pairs(BF_Wawale.tTableMineral) do
          if l_5_5.szName == l_5_16.szName and l_5_16.bOn then
            InteractDoodad(l_5_4)
          end
        end
      end
    end
    if not BF_Wawale.bHerbs and not BF_Wawale.bMineral then
      InteractDoodad(l_5_4)
    end
  end
end

l_0_0.Pick = l_0_1
l_0_0 = BF_Wawale
l_0_1 = function()
  local l_6_0 = {}
  local l_6_1 = {}
  l_6_1.szOption = "��ҩ�б�"
  l_6_1.bCheck = true
  l_6_1.bChecked = BF_Wawale.bHerbs
  l_6_1.fnAction = function()
    BF_Wawale.bHerbs = not BF_Wawale.bHerbs
  end
  for l_6_5 = 1, #BF_Wawale.tTableHerbs do
    do
      local l_6_6 = {}
      do
        l_6_6.szOption = BF_Wawale.tTableHerbs[l_6_5].szName
        l_6_6.bCheck = true
        l_6_6.bChecked = BF_Wawale.tTableHerbs[l_6_5].bOn
        l_6_6.fnAction = function()
          -- upvalues: l_6_5
          BF_Wawale.tTableHerbs[l_6_5].bOn = not BF_Wawale.tTableHerbs[l_6_5].bOn
        end
        table.insert(l_6_1, l_6_6)
      end
    end
    table.insert(l_6_0, l_6_1)
    do
      local l_6_7 = {}
      l_6_7.szOption = "��ʯ�б�"
      l_6_7.bCheck = true
      l_6_7.bChecked = BF_Wawale.bMineral
      l_6_7.fnAction = function()
      BF_Wawale.bMineral = not BF_Wawale.bMineral
    end
      for l_6_11 = 1, #BF_Wawale.tTableMineral do
        local l_6_12 = {}
        l_6_12.szOption = BF_Wawale.tTableMineral[l_6_11].szName
        l_6_12.bCheck = true
        l_6_12.bChecked = BF_Wawale.tTableMineral[l_6_11].bOn
        l_6_12.fnAction = function()
        -- upvalues: l_6_6
        BF_Wawale.tTableMineral[l_6_6].bOn = not BF_Wawale.tTableMineral[l_6_6].bOn
      end
        table.insert(l_6_7, l_6_12)
      end
      table.insert(l_6_0, l_6_7)
      return l_6_0
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0.GetMenu = l_0_1
l_0_0 = BF_Wawale
l_0_1 = function(l_7_0)
  if l_7_0 == "M1" then
    BFSetModValue("Wawale", "EnableM1", true)
    BFSetModValue("Wawale", "EnableM2", false)
    BFSetModValue("Wawale", "EnableM3", false)
  elseif l_7_0 == "M2" then
    BFSetModValue("Wawale", "EnableM1", false)
    BFSetModValue("Wawale", "EnableM2", true)
    BFSetModValue("Wawale", "EnableM3", false)
  elseif l_7_0 == "M3" then
    BFSetModValue("Wawale", "EnableM1", false)
    BFSetModValue("Wawale", "EnableM2", false)
    BFSetModValue("Wawale", "EnableM3", true)
  end
  BFConfigPanel.ShowModPage("Wawale")
end

l_0_0.SetConfigModle = l_0_1
l_0_0 = Wnd
l_0_0 = l_0_0.OpenWindow
l_0_1 = "Interface/BF_Wawale/BF_Wawale.ini"
l_0_2 = "BF_Wawale"
l_0_0(l_0_1, l_0_2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "Wawale"
l_0_2 = "bEnable"
l_0_0(l_0_1, l_0_2, "�����Զ��ɼ�", true, function(l_8_0)
  BF_Wawale.bEnable = l_8_0
end
)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "Wawale"
l_0_2 = "bFightoff"
l_0_0(l_0_1, l_0_2, "ս���в��ɼ�", true, function(l_9_0)
  BF_Wawale.bFightoff = l_9_0
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "Wawale"
l_0_2 = "EnableM1"
l_0_0(l_0_1, l_0_2, "��������", false, function(l_10_0, l_10_1)
  if l_10_1 and not l_10_0 then
    return 
  end
  BF_Wawale.szMode = "M1"
  BF_Wawale.Interval = 1
  if not l_10_1 then
    BF_Wawale.SetConfigModle(BF_Wawale.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "Wawale"
l_0_2 = "EnableM2"
l_0_0(l_0_1, l_0_2, "��г����", false, function(l_11_0, l_11_1)
  if l_11_1 and not l_11_0 then
    return 
  end
  BF_Wawale.szMode = "M2"
  BF_Wawale.Interval = 8
  if not l_11_1 then
    BF_Wawale.SetConfigModle(BF_Wawale.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "Wawale"
l_0_2 = "EnableM3"
l_0_0(l_0_1, l_0_2, "��������", true, function(l_12_0, l_12_1)
  if l_12_1 and not l_12_0 then
    return 
  end
  BF_Wawale.szMode = "M3"
  BF_Wawale.Interval = 16
  if not l_12_1 then
    BF_Wawale.SetConfigModle(BF_Wawale.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.Registerbutton
l_0_1 = "Wawale"
l_0_2 = "btnSetting"
l_0_0(l_0_1, l_0_2, "��������", true, function(l_13_0)
  local l_13_1 = BF_Wawale.GetMenu()
  PopupMenu(l_13_1)
end
, 2)

