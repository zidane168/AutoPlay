-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Macro.lua 

if not BF_Macro then
  BF_Macro = {}
end
BF_Macro.bProtectChannelSkill = false
BF_Macro.bDoSkillCast = true
BF_Macro.bPuppetAttack = false
local l_0_0 = BF_Macro
local l_0_1 = {}
l_0_1.status = function(l_1_0)
  local l_1_1 = GetClientPlayer()
  local l_1_2 = BF_Macro.CheckStatus
  local l_1_3 = l_1_1
  local l_1_4 = l_1_0
  return l_1_2(l_1_3, l_1_4)
end

l_0_1.tstatus = function(l_2_0)
  local l_2_1 = GetClientPlayer()
  local l_2_2 = GetTargetHandle(l_2_1.GetTarget())
  local l_2_3 = BF_Macro.CheckStatus
  local l_2_4 = l_2_2
  local l_2_5 = l_2_0
  return l_2_3(l_2_4, l_2_5)
end

l_0_1.ttstatus = function(l_3_0)
  local l_3_1 = GetClientPlayer()
  local l_3_2 = GetTargetHandle(l_3_1.GetTarget())
  local l_3_3 = GetTargetHandle(l_3_2.GetTarget())
  local l_3_4 = BF_Macro.CheckStatus
  local l_3_5 = l_3_3
  local l_3_6 = l_3_0
  return l_3_4(l_3_5, l_3_6)
end

l_0_1.nostatus = function(l_4_0)
  local l_4_1 = GetClientPlayer()
  return not BF_Macro.CheckStatus(l_4_1, l_4_0)
end

l_0_1.tnostatus = function(l_5_0)
  do
    local l_5_1 = GetClientPlayer()
    return not BF_Macro.CheckStatus(l_5_1, l_5_0)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_1.ttnostatus = function(l_6_0)
  local l_6_1 = GetClientPlayer()
  local l_6_2 = GetTargetHandle(l_6_1.GetTarget())
  local l_6_3 = GetTargetHandle(l_6_2.GetTarget())
  return not BF_Macro.CheckStatus(l_6_3, l_6_0)
end

l_0_1.otaction = function(l_7_0)
  local l_7_1 = GetClientPlayer()
  if l_7_0 == nil then
    l_7_0 = ""
  end
  local l_7_2 = BF_Macro.CheckPrepare
  local l_7_3 = l_7_1
  local l_7_4 = l_7_0
  return l_7_2(l_7_3, l_7_4)
end

l_0_1.nootaction = function(l_8_0)
  local l_8_1 = GetClientPlayer()
  if l_8_0 == nil then
    l_8_0 = ""
  end
  return not BF_Macro.CheckPrepare(l_8_1, l_8_0)
end

l_0_1.broken = function(l_9_0)
  local l_9_1 = GetClientPlayer()
  local l_9_2 = GetTargetHandle(l_9_1.GetTarget())
  if l_9_0 == nil then
    l_9_0 = ""
  end
  if BF_Macro.CheckPrepare(l_9_2, l_9_0) then
    bPrePare = l_9_1.GetSkillPrepareState()
    if bPrePare then
      l_9_1.StopCurrentAction()
    end
    return true
  else
    return false
  end
end

l_0_1.prepare = function(l_10_0)
  local l_10_1 = GetClientPlayer()
  local l_10_2 = GetTargetHandle(l_10_1.GetTarget())
  if l_10_0 == nil then
    l_10_0 = ""
  end
  local l_10_3 = BF_Macro.CheckPrepare
  local l_10_4 = l_10_2
  local l_10_5 = l_10_0
  return l_10_3(l_10_4, l_10_5)
end

l_0_1.ttprepare = function(l_11_0)
  local l_11_1 = GetClientPlayer()
  local l_11_2 = GetTargetHandle(l_11_1.GetTarget())
  local l_11_3 = GetTargetHandle(l_11_2.GetTarget())
  if l_11_0 == nil then
    l_11_0 = ""
  end
  local l_11_4 = BF_Macro.CheckPrepare
  local l_11_5 = l_11_3
  local l_11_6 = l_11_0
  return l_11_4(l_11_5, l_11_6)
end

l_0_1.noprepare = function(l_12_0)
  local l_12_1 = GetClientPlayer()
  local l_12_2 = GetTargetHandle(l_12_1.GetTarget())
  if l_12_0 == nil then
    l_12_0 = ""
  end
  return not BF_Macro.CheckPrepare(l_12_2, l_12_0)
end

l_0_1.ttnoprepare = function(l_13_0)
  local l_13_1 = GetClientPlayer()
  local l_13_2 = GetTargetHandle(l_13_1.GetTarget())
  local l_13_3 = GetTargetHandle(l_13_2.GetTarget())
  if l_13_0 == nil then
    l_13_0 = ""
  end
  return not BF_Macro.CheckPrepare(l_13_3, l_13_0)
end

l_0_1.fight = function()
  return GetClientPlayer().bFightState
end

l_0_1.tfight = function()
  return GetTargetHandle(GetClientPlayer().GetTarget()).bFightState
end

l_0_1.ttfight = function()
  return GetTargetHandle(GetTargetHandle(GetClientPlayer().GetTarget()).GetTarget()).bFightState
end

l_0_1.combat = function()
  return GetClientPlayer().bFightState
end

l_0_1.nofight = function()
  return not GetClientPlayer().bFightState
end

l_0_1.tnofight = function()
  return not GetTargetHandle(GetClientPlayer().GetTarget()).bFightState
end

l_0_1.ttnofight = function()
  return not GetTargetHandle(GetTargetHandle(GetClientPlayer().GetTarget()).GetTarget()).bFightState
end

l_0_1.nocombat = function()
  return not GetClientPlayer().bFightState
end

l_0_1.mounted = function()
  return GetClientPlayer().bOnHorse
end

l_0_1.horse = function()
  return GetClientPlayer().bOnHorse
end

l_0_1.unmounted = function()
  return not GetClientPlayer().bOnHorse
end

l_0_1.nohorse = function()
  return not GetClientPlayer().bOnHorse
end

l_0_1.qidian = function(l_26_0, l_26_1)
  local l_26_2 = GetClientPlayer()
  local l_26_3 = l_26_2.nAccumulateValue
  local l_26_4 = BF_Macro.compare
  local l_26_5 = l_26_1
  local l_26_6 = l_26_3
  local l_26_7 = l_26_0
  return l_26_4(l_26_5, l_26_6, l_26_7)
end

l_0_1.rage = function(l_27_0, l_27_1)
  local l_27_2 = GetClientPlayer()
  local l_27_3 = l_27_2.nCurrentRage
  local l_27_4 = BF_Macro.compare
  local l_27_5 = l_27_1
  local l_27_6 = l_27_3
  local l_27_7 = l_27_0
  return l_27_4(l_27_5, l_27_6, l_27_7)
end

l_0_1.energy = function(l_28_0, l_28_1)
  local l_28_2 = GetClientPlayer()
  local l_28_3 = l_28_2.nCurrentEnergy
  local l_28_4 = BF_Macro.compare
  local l_28_5 = l_28_1
  local l_28_6 = l_28_3
  local l_28_7 = l_28_0
  return l_28_4(l_28_5, l_28_6, l_28_7)
end

l_0_1.tm = function(l_29_0, l_29_1)
  local l_29_2 = GetClientPlayer()
  local l_29_3 = l_29_2.nCurrentEnergy
  local l_29_4 = BF_Macro.compare
  local l_29_5 = l_29_1
  local l_29_6 = l_29_3
  local l_29_7 = l_29_0
  return l_29_4(l_29_5, l_29_6, l_29_7)
end

l_0_1.shenji = function(l_30_0, l_30_1)
  local l_30_2 = GetClientPlayer()
  local l_30_3 = l_30_2.nCurrentEnergy
  local l_30_4 = BF_Macro.compare
  local l_30_5 = l_30_1
  local l_30_6 = l_30_3
  local l_30_7 = l_30_0
  return l_30_4(l_30_5, l_30_6, l_30_7)
end

l_0_1.neutrality = function()
  local l_31_0 = GetClientPlayer()
  local l_31_1, l_31_2 = l_31_0.GetTarget()
  local l_31_3 = IsNeutrality
  local l_31_4 = l_31_0.dwID
  local l_31_5 = l_31_2
  return l_31_3(l_31_4, l_31_5)
end

l_0_1.ttneutrality = function()
  local l_32_0 = GetClientPlayer()
  local l_32_1 = GetTargetHandle(l_32_0.GetTarget())
  local l_32_2, l_32_3 = l_32_1.GetTarget()
  local l_32_4 = IsNeutrality
  local l_32_5 = l_32_0.dwID
  local l_32_6 = l_32_3
  return l_32_4(l_32_5, l_32_6)
end

l_0_1.ally = function()
  local l_33_0 = GetClientPlayer()
  local l_33_1, l_33_2 = l_33_0.GetTarget()
  local l_33_3 = IsAlly
  local l_33_4 = l_33_0.dwID
  local l_33_5 = l_33_2
  return l_33_3(l_33_4, l_33_5)
end

l_0_1.ttally = function()
  local l_34_0 = GetClientPlayer()
  local l_34_1 = GetTargetHandle(l_34_0.GetTarget())
  local l_34_2, l_34_3 = l_34_1.GetTarget()
  local l_34_4 = IsAlly
  local l_34_5 = l_34_0.dwID
  local l_34_6 = l_34_3
  return l_34_4(l_34_5, l_34_6)
end

l_0_1.enemy = function()
  local l_35_0 = GetClientPlayer()
  local l_35_1, l_35_2 = l_35_0.GetTarget()
  local l_35_3 = IsEnemy
  local l_35_4 = l_35_0.dwID
  local l_35_5 = l_35_2
  return l_35_3(l_35_4, l_35_5)
end

l_0_1.ttenemy = function()
  local l_36_0 = GetClientPlayer()
  local l_36_1 = GetTargetHandle(l_36_0.GetTarget())
  local l_36_2, l_36_3 = l_36_1.GetTarget()
  local l_36_4 = IsEnemy
  local l_36_5 = l_36_0.dwID
  local l_36_6 = l_36_3
  return l_36_4(l_36_5, l_36_6)
end

l_0_1.life = function(l_37_0, l_37_1)
  local l_37_2 = GetClientPlayer()
  local l_37_3 = l_37_2.nCurrentLife / l_37_2.nMaxLife
  local l_37_4 = BF_Macro.compare
  local l_37_5 = l_37_1
  local l_37_6 = l_37_3
  local l_37_7 = l_37_0
  return l_37_4(l_37_5, l_37_6, l_37_7)
end

l_0_1.tlife = function(l_38_0, l_38_1)
  local l_38_2 = GetClientPlayer()
  local l_38_3 = GetTargetHandle(l_38_2.GetTarget())
  local l_38_4 = l_38_3.nCurrentLife / l_38_3.nMaxLife
  local l_38_5 = BF_Macro.compare
  local l_38_6 = l_38_1
  local l_38_7 = l_38_4
  local l_38_8 = l_38_0
  return l_38_5(l_38_6, l_38_7, l_38_8)
end

l_0_1.ttlife = function(l_39_0, l_39_1)
  local l_39_2 = GetClientPlayer()
  local l_39_3 = GetTargetHandle(l_39_2.GetTarget())
  local l_39_4 = GetTargetHandle(l_39_3.GetTarget())
  local l_39_5 = l_39_4.nCurrentLife / l_39_4.nMaxLife
  local l_39_6 = BF_Macro.compare
  local l_39_7 = l_39_1
  local l_39_8 = l_39_5
  local l_39_9 = l_39_0
  return l_39_6(l_39_7, l_39_8, l_39_9)
end

l_0_1.mana = function(l_40_0, l_40_1)
  local l_40_2 = GetClientPlayer()
  local l_40_3 = l_40_2.nCurrentMana / l_40_2.nMaxMana
  local l_40_4 = BF_Macro.compare
  local l_40_5 = l_40_1
  local l_40_6 = l_40_3
  local l_40_7 = l_40_0
  return l_40_4(l_40_5, l_40_6, l_40_7)
end

l_0_1.tmana = function(l_41_0, l_41_1)
  local l_41_2 = GetClientPlayer()
  local l_41_3 = GetTargetHandle(l_41_2.GetTarget())
  local l_41_4 = l_41_3.nCurrentMana / l_41_3.nMaxMana
  local l_41_5 = BF_Macro.compare
  local l_41_6 = l_41_1
  local l_41_7 = l_41_4
  local l_41_8 = l_41_0
  return l_41_5(l_41_6, l_41_7, l_41_8)
end

l_0_1.ttmana = function(l_42_0, l_42_1)
  local l_42_2 = GetClientPlayer()
  local l_42_3 = GetTargetHandle(l_42_2.GetTarget())
  local l_42_4 = GetTargetHandle(l_42_3.GetTarget())
  local l_42_5 = l_42_4.nCurrentMana / l_42_4.nMaxMana
  local l_42_6 = BF_Macro.compare
  local l_42_7 = l_42_1
  local l_42_8 = l_42_5
  local l_42_9 = l_42_0
  return l_42_6(l_42_7, l_42_8, l_42_9)
end

l_0_1.target = function(l_43_0)
  local l_43_1 = GetClientPlayer()
  local l_43_2 = GetTargetHandle(l_43_1.GetTarget())
  local l_43_3 = BF_Macro.CheckTarget
  local l_43_4 = l_43_2
  local l_43_5 = l_43_0
  return l_43_3(l_43_4, l_43_5)
end

l_0_1.ttarget = function(l_44_0)
  local l_44_1 = GetClientPlayer()
  local l_44_2 = GetTargetHandle(l_44_1.GetTarget())
  local l_44_3 = GetTargetHandle(l_44_2.GetTarget())
  local l_44_4 = BF_Macro.CheckTarget
  local l_44_5 = l_44_3
  local l_44_6 = l_44_0
  return l_44_4(l_44_5, l_44_6)
end

l_0_1.exists = function()
  local l_45_0, l_45_1 = GetClientPlayer().GetTarget()
  return (l_45_0 == TARGET.PLAYER or l_45_0 == TARGET.NPC) and l_45_1 ~= 0
end

l_0_1.noexists = function()
  local l_46_0, l_46_1 = GetClientPlayer().GetTarget()
  return l_46_1 == 0 and l_46_0 ~= TARGET.PLAYER and l_46_0 ~= TARGET.NPC
end

l_0_1.tforce = function(l_47_0)
  local l_47_1 = GetClientPlayer()
  local l_47_2 = GetTargetHandle(l_47_1.GetTarget())
  local l_47_3 = BF_Macro.CheckForce
  local l_47_4 = l_47_2
  local l_47_5 = l_47_0
  return l_47_3(l_47_4, l_47_5)
end

l_0_1.ttforce = function(l_48_0)
  local l_48_1 = GetClientPlayer()
  local l_48_2 = GetTargetHandle(l_48_1.GetTarget())
  local l_48_3 = GetTargetHandle(l_48_2.GetTarget())
  local l_48_4 = BF_Macro.CheckForce
  local l_48_5 = l_48_3
  local l_48_6 = l_48_0
  return l_48_4(l_48_5, l_48_6)
end

l_0_1.tnoforce = function(l_49_0)
  local l_49_1 = GetClientPlayer()
  local l_49_2 = GetTargetHandle(l_49_1.GetTarget())
  return not BF_Macro.CheckForce(l_49_2, l_49_0)
end

l_0_1.ttnoforce = function(l_50_0)
  local l_50_1 = GetClientPlayer()
  local l_50_2 = GetTargetHandle(l_50_1.GetTarget())
  local l_50_3 = GetTargetHandle(l_50_2.GetTarget())
  return not BF_Macro.CheckForce(l_50_3, l_50_0)
end

l_0_1.tname = function(l_51_0)
  local l_51_1 = GetClientPlayer()
  local l_51_2 = GetTargetHandle(l_51_1.GetTarget())
  local l_51_3 = BF_Macro.CheckName
  local l_51_4 = l_51_2
  local l_51_5 = l_51_0
  return l_51_3(l_51_4, l_51_5)
end

l_0_1.ttname = function(l_52_0)
  local l_52_1 = GetClientPlayer()
  local l_52_2 = GetTargetHandle(l_52_1.GetTarget())
  local l_52_3 = GetTargetHandle(l_52_2.GetTarget())
  local l_52_4 = BF_Macro.CheckName
  local l_52_5 = l_52_3
  local l_52_6 = l_52_0
  return l_52_4(l_52_5, l_52_6)
end

l_0_1.tnoname = function(l_53_0)
  local l_53_1 = GetClientPlayer()
  local l_53_2 = GetTargetHandle(l_53_1.GetTarget())
  return not BF_Macro.CheckName(l_53_2, l_53_0)
end

l_0_1.ttnoname = function(l_54_0)
  local l_54_1 = GetClientPlayer()
  local l_54_2 = GetTargetHandle(l_54_1.GetTarget())
  local l_54_3 = GetTargetHandle(l_54_2.GetTarget())
  return not BF_Macro.CheckName(l_54_3, l_54_0)
end

l_0_1.mount = function(l_55_0)
  local l_55_1 = GetClientPlayer()
  local l_55_2 = BF_Macro.CheckMount
  local l_55_3 = l_55_1
  local l_55_4 = l_55_0
  return l_55_2(l_55_3, l_55_4)
end

l_0_1.tmount = function(l_56_0)
  local l_56_1 = GetClientPlayer()
  local l_56_2 = GetTargetHandle(l_56_1.GetTarget())
  local l_56_3 = BF_Macro.CheckMount
  local l_56_4 = l_56_2
  local l_56_5 = l_56_0
  return l_56_3(l_56_4, l_56_5)
end

l_0_1.ttmount = function(l_57_0)
  local l_57_1 = GetClientPlayer()
  local l_57_2 = GetTargetHandle(l_57_1.GetTarget())
  local l_57_3 = GetTargetHandle(l_57_2.GetTarget())
  local l_57_4 = BF_Macro.CheckMount
  local l_57_5 = l_57_3
  local l_57_6 = l_57_0
  return l_57_4(l_57_5, l_57_6)
end

l_0_1.nomount = function(l_58_0)
  local l_58_1 = GetClientPlayer()
  return not BF_Macro.CheckMount(l_58_1, l_58_0)
end

l_0_1.tnomount = function(l_59_0)
  local l_59_1 = GetClientPlayer()
  local l_59_2 = GetTargetHandle(l_59_1.GetTarget())
  return not BF_Macro.CheckMount(l_59_2, l_59_0)
end

l_0_1.ttnomount = function(l_60_0)
  local l_60_1 = GetClientPlayer()
  local l_60_2 = GetTargetHandle(l_60_1.GetTarget())
  local l_60_3 = GetTargetHandle(l_60_2.GetTarget())
  return not BF_Macro.CheckMount(l_60_3, l_60_0)
end

l_0_1.distance = function(l_61_0, l_61_1)
  local l_61_2 = GetClientPlayer()
  local l_61_3 = GetTargetHandle(l_61_2.GetTarget())
  if not l_61_3 then
    return false
  end
  local l_61_4 = math.ceil(GetCharacterDistance(l_61_2.dwID, l_61_3.dwID) / 64)
  local l_61_5 = BF_Macro.compare
  local l_61_6 = l_61_1
  local l_61_7 = l_61_4
  local l_61_8 = l_61_0
  return l_61_5(l_61_6, l_61_7, l_61_8)
end

l_0_1.ttdistance = function(l_62_0, l_62_1)
  local l_62_2 = GetClientPlayer()
  local l_62_3 = GetTargetHandle(l_62_2.GetTarget())
  local l_62_4 = GetTargetHandle(l_62_3.GetTarget())
  if not l_62_4 then
    return false
  end
  local l_62_5 = math.ceil(GetCharacterDistance(l_62_2.dwID, l_62_4.dwID) / 64)
  local l_62_6 = BF_Macro.compare
  local l_62_7 = l_62_1
  local l_62_8 = l_62_5
  local l_62_9 = l_62_0
  return l_62_6(l_62_7, l_62_8, l_62_9)
end

l_0_1.ttdistancet = function(l_63_0, l_63_1)
  local l_63_2 = GetClientPlayer()
  local l_63_3 = GetTargetHandle(l_63_2.GetTarget())
  local l_63_4 = GetTargetHandle(l_63_3.GetTarget())
  if not l_63_4 then
    return false
  end
  local l_63_5 = math.ceil(GetCharacterDistance(l_63_3.dwID, l_63_4.dwID) / 64)
  local l_63_6 = BF_Macro.compare
  local l_63_7 = l_63_1
  local l_63_8 = l_63_5
  local l_63_9 = l_63_0
  return l_63_6(l_63_7, l_63_8, l_63_9)
end

l_0_1.cd = function(l_64_0)
  local l_64_1 = GetClientPlayer()
  local l_64_2, l_64_3 = BF_Macro.GetUseSkillID(l_64_0)
  local l_64_4, l_64_5, l_64_6 = l_64_1.GetSkillCDProgress(l_64_2, l_64_3)
  return l_64_5 > 0
end

l_0_1.nocd = function(l_65_0)
  local l_65_1 = GetClientPlayer()
  local l_65_2, l_65_3 = BF_Macro.GetUseSkillID(l_65_0)
  local l_65_4, l_65_5, l_65_6 = l_65_1.GetSkillCDProgress(l_65_2, l_65_3)
  return l_65_5 <= 0
end

l_0_1.cdtime = function(l_66_0)
  local l_66_1 = GetClientPlayer()
  local l_66_2 = SplitString(l_66_0, "|")
  for l_66_6,l_66_7 in ipairs(l_66_2) do
    local l_66_8, l_66_9, l_66_10, l_66_11 = BF_Macro.SplitStr(l_66_7, "[><=]")
    local l_66_12, l_66_13 = BF_Macro.GetUseSkillID(l_66_9)
    local l_66_14, l_66_15, l_66_16 = l_66_1.GetSkillCDProgress(l_66_12, l_66_13)
    local l_66_17 = l_66_15 / GLOBAL.GAME_FPS
    if l_66_8 and BF_Macro.compare(l_66_10, l_66_17, l_66_11) then
      return true
    end
  end
  return false
end

l_0_1.dead = function()
  local l_67_0, l_67_1 = GetClientPlayer().GetTarget()
  if l_67_0 == TARGET.PLAYER then
    local l_67_2 = GetPlayer(l_67_1)
  end
  if l_67_2 and l_67_2.nMoveState == MOVE_STATE.ON_DEATH then
    return true
  end
  return false
end

l_0_1.nodead = function()
  local l_68_0, l_68_1 = GetClientPlayer().GetTarget()
  if l_68_0 == TARGET.PLAYER then
    local l_68_2 = GetPlayer(l_68_1)
    if l_68_2 and l_68_2.nMoveState ~= MOVE_STATE.ON_DEATH then
      return true
    end
  else
    if l_68_0 == TARGET.NPC then
      return true
    end
  end
  return false
end

l_0_1.ttdead = function()
  local l_69_0 = GetTargetHandle(GetClientPlayer().GetTarget())
  local l_69_1, l_69_2 = l_69_0.GetTarget()
  if l_69_1 == TARGET.PLAYER then
    local l_69_3 = GetPlayer(l_69_2)
  end
  if l_69_3 and l_69_3.nMoveState == MOVE_STATE.ON_DEATH then
    return true
  end
  return false
end

l_0_1.ttnodead = function()
  local l_70_0 = GetTargetHandle(GetClientPlayer().GetTarget())
  local l_70_1, l_70_2 = l_70_0.GetTarget()
  if l_70_1 == TARGET.PLAYER then
    local l_70_3 = GetPlayer(l_70_2)
    if l_70_3 and l_70_3.nMoveState ~= MOVE_STATE.ON_DEATH then
      return true
    end
  else
    if l_70_1 == TARGET.NPC then
      return true
    end
  end
  return false
end

l_0_1.bufftime = function(l_71_0)
  local l_71_1 = GetClientPlayer()
  local l_71_2 = BF_Macro.CheckBuff
  local l_71_3 = l_71_1
  local l_71_4 = l_71_0
  local l_71_5 = "t"
  local l_71_6 = false
  return l_71_2(l_71_3, l_71_4, l_71_5, l_71_6)
end

l_0_1.tbufftime = function(l_72_0)
  local l_72_1 = GetClientPlayer()
  local l_72_2 = GetTargetHandle(l_72_1.GetTarget())
  local l_72_3 = BF_Macro.CheckBuff
  local l_72_4 = l_72_2
  local l_72_5 = l_72_0
  local l_72_6 = "t"
  local l_72_7 = false
  return l_72_3(l_72_4, l_72_5, l_72_6, l_72_7)
end

l_0_1.ttbufftime = function(l_73_0)
  local l_73_1 = GetClientPlayer()
  local l_73_2 = GetTargetHandle(l_73_1.GetTarget())
  local l_73_3 = GetTargetHandle(l_73_2.GetTarget())
  local l_73_4 = BF_Macro.CheckBuff
  local l_73_5 = l_73_3
  local l_73_6 = l_73_0
  local l_73_7 = "t"
  local l_73_8 = false
  return l_73_4(l_73_5, l_73_6, l_73_7, l_73_8)
end

l_0_1.buff = function(l_74_0)
  local l_74_1 = GetClientPlayer()
  local l_74_2 = BF_Macro.CheckBuff
  local l_74_3 = l_74_1
  local l_74_4 = l_74_0
  local l_74_5 = "s"
  local l_74_6 = false
  return l_74_2(l_74_3, l_74_4, l_74_5, l_74_6)
end

l_0_1.tbuff = function(l_75_0)
  local l_75_1 = GetClientPlayer()
  local l_75_2 = GetTargetHandle(l_75_1.GetTarget())
  local l_75_3 = BF_Macro.CheckBuff
  local l_75_4 = l_75_2
  local l_75_5 = l_75_0
  local l_75_6 = "s"
  local l_75_7 = false
  return l_75_3(l_75_4, l_75_5, l_75_6, l_75_7)
end

l_0_1.ttbuff = function(l_76_0)
  local l_76_1 = GetClientPlayer()
  local l_76_2 = GetTargetHandle(l_76_1.GetTarget())
  local l_76_3 = GetTargetHandle(l_76_2.GetTarget())
  local l_76_4 = BF_Macro.CheckBuff
  local l_76_5 = l_76_3
  local l_76_6 = l_76_0
  local l_76_7 = "s"
  local l_76_8 = false
  return l_76_4(l_76_5, l_76_6, l_76_7, l_76_8)
end

l_0_1.nobuff = function(l_77_0)
  local l_77_1 = GetClientPlayer()
  return not BF_Macro.CheckBuff(l_77_1, l_77_0, "s", false)
end

l_0_1.tnobuff = function(l_78_0)
  local l_78_1 = GetClientPlayer()
  local l_78_2 = GetTargetHandle(l_78_1.GetTarget())
  return not BF_Macro.CheckBuff(l_78_2, l_78_0, "s", false)
end

l_0_1.ttnobuff = function(l_79_0)
  local l_79_1 = GetClientPlayer()
  local l_79_2 = GetTargetHandle(l_79_1.GetTarget())
  local l_79_3 = GetTargetHandle(l_79_2.GetTarget())
  return not BF_Macro.CheckBuff(l_79_3, l_79_0, "s", false)
end

l_0_1.mbuff = function(l_80_0)
  local l_80_1 = GetClientPlayer()
  local l_80_2 = GetTargetHandle(l_80_1.GetTarget())
  local l_80_3 = BF_Macro.CheckBuff
  local l_80_4 = l_80_2
  local l_80_5 = l_80_0
  local l_80_6 = "s"
  local l_80_7 = true
  return l_80_3(l_80_4, l_80_5, l_80_6, l_80_7)
end

l_0_1.nombuff = function(l_81_0)
  local l_81_1 = GetClientPlayer()
  local l_81_2 = GetTargetHandle(l_81_1.GetTarget())
  return not BF_Macro.CheckBuff(l_81_2, l_81_0, "s", true)
end

l_0_1.mbufftime = function(l_82_0)
  local l_82_1 = GetClientPlayer()
  local l_82_2 = GetTargetHandle(l_82_1.GetTarget())
  local l_82_3 = BF_Macro.CheckBuff
  local l_82_4 = l_82_2
  local l_82_5 = l_82_0
  local l_82_6 = "t"
  local l_82_7 = true
  return l_82_3(l_82_4, l_82_5, l_82_6, l_82_7)
end

l_0_1.btype = function(l_83_0)
  local l_83_1 = GetClientPlayer()
  local l_83_2 = BF_Macro.CheckBType
  local l_83_3 = l_83_1
  local l_83_4 = l_83_0
  local l_83_5 = true
  return l_83_2(l_83_3, l_83_4, l_83_5)
end

l_0_1.tbtype = function(l_84_0)
  local l_84_1 = GetClientPlayer()
  local l_84_2 = GetTargetHandle(l_84_1.GetTarget())
  local l_84_3 = BF_Macro.CheckBType
  local l_84_4 = l_84_2
  local l_84_5 = l_84_0
  local l_84_6 = true
  return l_84_3(l_84_4, l_84_5, l_84_6)
end

l_0_1.ttbtype = function(l_85_0)
  local l_85_1 = GetClientPlayer()
  local l_85_2 = GetTargetHandle(l_85_1.GetTarget())
  local l_85_3 = GetTargetHandle(l_85_2.GetTarget())
  local l_85_4 = BF_Macro.CheckBType
  local l_85_5 = l_85_3
  local l_85_6 = l_85_0
  local l_85_7 = true
  return l_85_4(l_85_5, l_85_6, l_85_7)
end

l_0_1.detype = function(l_86_0)
  local l_86_1 = GetClientPlayer()
  local l_86_2 = BF_Macro.CheckBType
  local l_86_3 = l_86_1
  local l_86_4 = l_86_0
  local l_86_5 = false
  return l_86_2(l_86_3, l_86_4, l_86_5)
end

l_0_1.tdetype = function(l_87_0)
  local l_87_1 = GetClientPlayer()
  local l_87_2 = GetTargetHandle(l_87_1.GetTarget())
  local l_87_3 = BF_Macro.CheckBType
  local l_87_4 = l_87_2
  local l_87_5 = l_87_0
  local l_87_6 = false
  return l_87_3(l_87_4, l_87_5, l_87_6)
end

l_0_1.ttdetype = function(l_88_0)
  local l_88_1 = GetClientPlayer()
  local l_88_2 = GetTargetHandle(l_88_1.GetTarget())
  local l_88_3 = GetTargetHandle(l_88_2.GetTarget())
  local l_88_4 = BF_Macro.CheckBType
  local l_88_5 = l_88_3
  local l_88_6 = l_88_0
  local l_88_7 = false
  return l_88_4(l_88_5, l_88_6, l_88_7)
end

l_0_1.pet = function(l_89_0)
  local l_89_1 = GetClientPlayer()
  local l_89_2 = l_89_1.GetPet()
  if not l_89_2 then
    return false
  end
  if l_89_0 == nil or l_89_0 == "" then
    return true
  else
    local l_89_3 = SplitString(l_89_0, "|")
    for l_89_7,l_89_8 in ipairs(l_89_3) do
      if l_89_8 == l_89_2.szName then
        return true
      end
    end
    return false
  end
end

l_0_1.nopet = function(l_90_0)
  return not BF_Macro.CheckConditions.pet(l_90_0)
end

l_0_1.plife = function(l_91_0, l_91_1)
  local l_91_2 = GetClientPlayer()
  local l_91_3 = l_91_2.GetPet()
  local l_91_4 = l_91_3.nCurrentLife / l_91_3.nMaxLife
  local l_91_5 = BF_Macro.compare
  local l_91_6 = l_91_1
  local l_91_7 = l_91_4
  local l_91_8 = l_91_0
  return l_91_5(l_91_6, l_91_7, l_91_8)
end

l_0_1.pdistance = function(l_92_0, l_92_1)
  local l_92_2 = GetClientPlayer()
  local l_92_3 = l_92_2.GetPet()
  local l_92_4 = GetTargetHandle(l_92_2.GetTarget())
  if not l_92_3 then
    return false
  end
  local l_92_5 = math.ceil(GetCharacterDistance(l_92_4.dwID, l_92_3.dwID) / 64)
  local l_92_6 = BF_Macro.compare
  local l_92_7 = l_92_1
  local l_92_8 = l_92_5
  local l_92_9 = l_92_0
  return l_92_6(l_92_7, l_92_8, l_92_9)
end

l_0_1.puppet = function(l_93_0)
  local l_93_1 = {}
  l_93_1[16174] = "ǧ����"
  l_93_1[16175] = "����"
  l_93_1[16176] = "����"
  l_93_1[16177] = "��ɲ"
  local l_93_2 = Station.Lookup("Normal/PuppetActionBar")
  if l_93_2 then
    local l_93_3, l_93_4, l_93_5, l_93_6 = GetClientPlayer().GetSkillPrepareState()
    if l_93_3 and l_93_4 == 3109 and l_93_2.dwNpcTemplateID == 16174 then
      GetClientPlayer().StopCurrentAction()
    end
    if l_93_0 == nil or l_93_0 == "" then
      return true
    else
      local l_93_7 = SplitString(l_93_0, "|")
      for l_93_11,l_93_12 in ipairs(l_93_7) do
        if l_93_12 == l_93_1[l_93_2.dwNpcTemplateID] then
          return true
        end
      end
      return false
    end
  else
    return false
  end
end

l_0_1.nopuppet = function(l_94_0)
  return not BF_Macro.CheckConditions.puppet(l_94_0)
end

l_0_1.puppetstatus = function(l_95_0)
  if l_95_0 == "attack" then
    return BF_Macro.bPuppetAttack
  elseif l_95_0 == "stop" then
    return not BF_Macro.bPuppetAttack
  end
  return false
end

l_0_0.CheckConditions = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_96_0, l_96_1)
  local l_96_2 = {}
  l_96_2.invalid = MOVE_STATE.INVALID
  l_96_2.stand = MOVE_STATE.ON_STAND
  l_96_2.walk = MOVE_STATE.ON_WALK
  l_96_2.run = MOVE_STATE.ON_RUN
  l_96_2.jump = MOVE_STATE.ON_JUMP
  l_96_2.swimjump = MOVE_STATE.ON_SWIM_JUMP
  l_96_2.swim = MOVE_STATE.ON_SWIM
  l_96_2.float = MOVE_STATE.ON_FLOAT
  l_96_2.sit = MOVE_STATE.ON_SIT
  l_96_2.down = MOVE_STATE.ON_KNOCKED_DOWN
  l_96_2.back = MOVE_STATE.ON_KNOCKED_BACK
  l_96_2.off = MOVE_STATE.ON_KNOCKED_OFF
  l_96_2.halt = MOVE_STATE.ON_HALT
  l_96_2.freeze = MOVE_STATE.ON_FREEZE
  l_96_2.entrap = MOVE_STATE.ON_ENTRAP
  l_96_2.autofly = MOVE_STATE.ON_AUTO_FLY
  l_96_2.death = MOVE_STATE.ON_DEATH
  l_96_2.dash = MOVE_STATE.ON_DASH
  l_96_2.pull = MOVE_STATE.ON_PULL
  l_96_2.repulsed = MOVE_STATE.ON_REPULSED
  l_96_2.rise = MOVE_STATE.ON_RISE
  l_96_2.skip = MOVE_STATE.ON_SKID
  if not l_96_0 then
    return false
  end
  local l_96_3 = l_96_0.nMoveState
  StateTypes = SplitString(l_96_1, "|")
  for l_96_7,l_96_8 in pairs(StateTypes) do
    if l_96_3 == l_96_2[l_96_8] then
      return true
    end
  end
  return false
end

l_0_0.CheckStatus = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_97_0, l_97_1)
  if not l_97_0 then
    return false
  end
  do
    local l_97_2, l_97_3, l_97_4, l_97_5 = l_97_0.GetSkillPrepareState()
    if l_97_2 then
      if l_97_1 == "" then
        return true
      end
      local l_97_6 = SplitString(l_97_1, "|")
      for l_97_10,l_97_11 in ipairs(l_97_6) do
        local l_97_12, l_97_13, l_97_14, l_97_15 = BF_Macro.SplitStr(l_97_11, "[><=]")
         -- DECOMPILER ERROR: unhandled construct in 'if'

        if not l_97_12 and Table_GetSkillName(l_97_3, l_97_4) == l_97_13 then
          return true
        end
        for l_97_10,l_97_11 in l_97_7 do
          if Table_GetSkillName(l_97_3, l_97_4) == l_97_13 and BF_Macro.compare(l_97_14, l_97_5, l_97_15) then
            return true
          end
        end
      end
      l_97_6 = false
      return l_97_6
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0.CheckPrepare = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_98_0, l_98_1)
  if not l_98_0 then
    return false
  end
  local l_98_2 = SplitString(l_98_1, "|")
  for l_98_6,l_98_7 in ipairs(l_98_2) do
    if l_98_7 == "player" then
      local l_98_8 = IsPlayer
      local l_98_9 = l_98_0.dwID
      return l_98_8(l_98_9)
    elseif l_98_7 == "npc" then
      return not IsPlayer(l_98_0.dwID)
    elseif l_98_7 == "boss" then
      return GetNpcIntensity(l_98_0) == 4
    end
  end
  return false
end

l_0_0.CheckTarget = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_99_0, l_99_1)
  if not l_99_0 then
    return false
  end
  local l_99_2 = SplitString(l_99_1, "|")
  for l_99_6,l_99_7 in ipairs(l_99_2) do
    if GetForceTitle(l_99_0.dwForceID) == l_99_7 then
      return true
    end
  end
  return false
end

l_0_0.CheckForce = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_100_0, l_100_1)
  if not l_100_0 then
    return false
  end
  local l_100_2 = SplitString(l_100_1, "|")
  for l_100_6,l_100_7 in ipairs(l_100_2) do
    if l_100_0.szName == l_100_7 then
      return true
    end
  end
  return false
end

l_0_0.CheckName = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_101_0, l_101_1)
  if not l_101_0 then
    return false
  end
  local l_101_2 = l_101_0.GetKungfuMount()
  if not l_101_2 then
    return false
  end
  local l_101_3 = SplitString(l_101_1, "|")
  for l_101_7,l_101_8 in ipairs(l_101_3) do
    if l_101_2.szSkillName == l_101_8 then
      return true
    end
  end
  return false
end

l_0_0.CheckMount = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_102_0, l_102_1, l_102_2, l_102_3)
  if not l_102_0 then
    return false
  end
  if not l_102_0.GetBuffList() then
    do break end
  end
  do
    local l_102_4, l_102_5, l_102_6, l_102_7, l_102_8 = pairs({})
    Buffstrs = SplitString(l_102_1, "|")
    for l_102_12,l_102_13 in ipairs(Buffstrs) do
      local l_102_14, l_102_15, l_102_16, l_102_17 = BF_Macro.SplitStr(l_102_13, "[><=]")
      if not l_102_3 or l_102_3 and l_102_8.dwSkillSrcID == GetClientPlayer().dwID then
        if l_102_2 == "t" then
          if l_102_14 then
            local l_102_18 = math.ceil((l_102_8.nEndFrame - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
          end
          if Table_GetBuffName(l_102_8.dwID, l_102_8.nLevel) == l_102_15 and BF_Macro.compare(l_102_16, l_102_18, l_102_17) then
            return true
          end
        else
          if Table_GetBuffName(l_102_8.dwID, l_102_8.nLevel) == l_102_15 then
            return true
          end
        elseif l_102_2 == "s" then
          if l_102_14 then
            local l_102_19 = l_102_8.nStackNum
          end
          if Table_GetBuffName(l_102_8.dwID, l_102_8.nLevel) == l_102_15 and BF_Macro.compare(l_102_16, l_102_19, l_102_17) then
            return true
          end
        else
          if Table_GetBuffName(l_102_8.dwID, l_102_8.nLevel) == l_102_15 then
            return true
          end
        end
      end
    end
  end
  return false
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.CheckBuff = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_103_0, l_103_1, l_103_2)
  local l_103_3 = {}
  l_103_3[1] = "�⹥"
  l_103_3[3] = "����"
  l_103_3[5] = "��Ԫ"
  l_103_3[7] = "����"
  l_103_3[11] = "����"
  l_103_3[13] = "��"
  local l_103_4 = {}
  l_103_4[2] = "�⹥"
  l_103_4[4] = "����"
  l_103_4[6] = "��Ԫ"
  l_103_4[8] = "����"
  l_103_4[10] = "��Ѩ"
  l_103_4[12] = "����"
  l_103_4[14] = "��"
  if not l_103_0 then
    return false
  end
  local l_103_5 = l_103_0.GetBuffList()
  if not l_103_5 then
    return false
  end
  local l_103_6 = false
  do break end
  do
    local l_103_7, l_103_8, l_103_9, l_103_10, l_103_11 = pairs(l_103_5)
    local l_103_12 = GetBuffInfo(l_103_11.dwID, l_103_11.nLevel, {}).nDetachType
    if l_103_12 ~= 0 then
      Bufftypes = SplitString(l_103_1, "|")
      for l_103_16,l_103_17 in pairs(Bufftypes) do
         -- DECOMPILER ERROR: unhandled construct in 'if'

        if l_103_2 and l_103_3[l_103_12] == l_103_17 then
          l_103_6 = true
        end
        for l_103_16,l_103_17 in l_103_13 do
          if l_103_4[l_103_12] == l_103_17 then
            l_103_6 = true
          end
        end
      end
    end
  end
  return l_103_6
end

l_0_0.CheckBType = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_104_0, l_104_1, l_104_2)
  local l_104_3 = false
  local l_104_4 = tonumber(l_104_1)
  local l_104_5 = tonumber(l_104_2)
  if l_104_5 >= l_104_4 then
    l_104_3 = l_104_0 ~= ">"
  end
  if l_104_4 >= l_104_5 then
    l_104_3 = l_104_0 ~= "<"
  end
  if l_104_4 ~= l_104_5 then
    l_104_3 = l_104_0 ~= "="
    return l_104_3
  end
end

l_0_0.compare = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_105_0, l_105_1)
  local l_105_2 = false
  local l_105_3 = l_105_0
  local l_105_4 = 0
  local l_105_5 = ""
  local l_105_6 = string.find(l_105_0, l_105_1)
  if l_105_6 then
    l_105_2 = true
    l_105_3 = string.sub(l_105_0, 1, l_105_6 - 1)
    l_105_4 = string.sub(l_105_0, l_105_6, l_105_6)
    l_105_5 = string.sub(l_105_0, l_105_6 + 1, -1)
  end
  return l_105_2, l_105_3, l_105_4, l_105_5
end

l_0_0.SplitStr = l_0_1
l_0_0 = BF_Macro
l_0_1 = function(l_106_0)
  l_106_0 = StringReplaceW(l_106_0, "-", "|")
  do
    local l_106_1 = SplitString(l_106_0, ",")
    for l_106_5,l_106_6 in pairs(l_106_1) do
      local l_106_7 = string.find(l_106_6, ";")
      if not l_106_7 then
        local l_106_8, l_106_9, l_106_10, l_106_11 = BF_Macro.SplitStr(l_106_6, "[><=:]")
         -- DECOMPILER ERROR: unhandled construct in 'if'

        if l_106_8 and l_106_10 == ":" and not BF_Macro.CheckConditions[l_106_9](l_106_11) then
          return false
        end
        for l_106_5,l_106_6 in l_106_2 do
          if not BF_Macro.CheckConditions[l_106_9](l_106_11, l_106_10) then
            return false
          end
          for l_106_5,l_106_6 in l_106_2 do
            if not BF_Macro.CheckConditions[l_106_6]() then
              return false
            end
          else
            local l_106_12 = false
            local l_106_13 = SplitString(l_106_6, ";")
            for l_106_17,l_106_18 in pairs(l_106_13) do
              local l_106_19, l_106_20, l_106_21, l_106_22 = BF_Macro.SplitStr(l_106_18, "[><=:]")
               -- DECOMPILER ERROR: unhandled construct in 'if'

              if l_106_19 and l_106_21 == ":" and BF_Macro.CheckConditions[l_106_20](l_106_22) then
                l_106_12 = true
              end
              for l_106_17,l_106_18 in l_106_14 do
                if BF_Macro.CheckConditions[l_106_20](l_106_22, l_106_21) then
                  l_106_12 = true
                end
                for l_106_17,l_106_18 in l_106_14 do
                  if BF_Macro.CheckConditions[l_106_6]() then
                    l_106_12 = true
                  end
                end
              end
              if not l_106_12 then
                return false
              end
            end
            return true
          end
           -- WARNING: missing end command somewhere! Added here
        end
         -- WARNING: missing end command somewhere! Added here
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_0.CheckOption = l_0_1
l_0_0 = function(l_107_0)
  l_107_0 = StringReplaceW(l_107_0, " ", "")
  if l_107_0 == "��������" then
    BF_Macro.bProtectChannelSkill = true
  elseif l_107_0 == "����������" then
    BF_Macro.bProtectChannelSkill = false
  end
end

l_0_1 = BF_Macro
l_0_1.GetUseSkillID = function(l_108_0)
  local l_108_1 = GetClientPlayer().GetKungfuMount()
  if l_108_0 == "��" or l_108_0 == "����" then
    return 9007, GetClientPlayer().GetSkillLevel(9007)
  end
  if l_108_0 == "�巽�о�" then
    return 2674, GetClientPlayer().GetSkillLevel(2674)
  end
  if l_108_0 == "��������" then
    return 2690, GetClientPlayer().GetSkillLevel(2690)
  end
  if l_108_1.dwSkillID == 10176 or l_108_1.dwSkillID == 10175 then
    if l_108_0 == "����" then
      return 2442, 1
    end
    if l_108_0 == "Ы��" then
      return 2475, 1
    end
    if l_108_0 == "���" then
      return 2476, 1
    end
    if l_108_0 == "�û�" then
      return 2477, 1
    end
    if l_108_0 == "Ӱ��" then
      return 2478, 1
    end
    if l_108_0 == "˿ǣ" then
      return 2479, 1
    end
  elseif l_108_1.dwSkillID == 10225 then
    if l_108_0 == "������̬" then
      return 3368, 1
    end
    if l_108_0 == "������̬" then
      return 3369, 1
    end
    if l_108_0 == "��ɲ��̬" then
      return 3370, 1
    end
    if l_108_0 == "����" then
      return 3360, 1
    end
  end
  if l_108_0 == "ֹͣ" then
    return 3382, 1
  end
  local l_108_2 = GetClientPlayer().GetAllSkillList()
  for l_108_6,l_108_7 in pairs(l_108_2) do
    local l_108_8 = Table_GetSkillName(l_108_6, l_108_7)
    if tostring(l_108_8) == tostring(l_108_0) then
      return l_108_6, l_108_7
    end
  end
end

l_0_1 = BF_Macro
l_0_1.CanUseSkill = function(l_109_0)
  local l_109_1, l_109_2 = BF_Macro.GetUseSkillID(l_109_0)
  if l_109_1 == 9007 then
    return true, false
  end
  if not GetClientPlayer().GetSkillCDProgress(l_109_1, l_109_2) or l_109_1 == 0 and l_109_2 == 0 and BF_Macro.UITestCast(l_109_1) then
    return true, GetSkill(l_109_1, l_109_2).bIsChannelSkill
  end
  return false, false
end

l_0_1 = BF_Macro
l_0_1.UITestCast = function(l_110_0)
  local l_110_1 = BF_Macro.GetSkillActionBarBox(l_110_0)
  if l_110_1:IsObjectEnable() and not l_110_1:IsObjectCoolDown() then
    return true
  end
  return false
end

l_0_1 = BF_Macro
l_0_1.GetSkillActionBarBox = function(l_111_0)
  local l_111_1 = nil
  for i = 1, 4 do
    if BF_Macro.IsActionBarOpened(i) then
      local l_111_6 = BF_Macro.GetActionBarFrame(i)
      local l_111_7 = 16
      for l_111_11 = 0, l_111_7 - 1 do
        local l_111_8 = l_111_6:Lookup("", "Handle_Box")
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_111_1 = l_111_8:Lookup(R12_PC24)
        if not l_111_1:IsEmpty() and l_111_1:GetObjectType() == UI_OBJECT_SKILL and l_111_1:GetObjectData() == l_111_0 then
          return l_111_1
        end
      end
    end
  end
  return nil
end

l_0_1 = BF_Macro
l_0_1.IsActionBarOpened = function(l_112_0)
  do
    if l_112_0 == 1 or l_112_0 == 2 then
      local l_112_1, l_112_2, l_112_3 = Station.Lookup("Lowest/ActionBar" .. l_112_0)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    if Station.Lookup("Lowest/ActionBar" .. l_112_0) and Station.Lookup("Lowest/ActionBar" .. l_112_0):IsVisible() then
      return true
    end
    return false
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 20 
end

l_0_1 = BF_Macro
l_0_1.GetActionBarFrame = function(l_113_0)
  if l_113_0 == 1 or l_113_0 == 2 then
    local l_113_1 = Station.Lookup
    local l_113_3 = "Lowest/ActionBar"
    l_113_3 = l_113_3 .. l_113_0
    local l_113_2 = nil
    return l_113_1(l_113_3)
  else
    local l_113_4 = Station.Lookup
    local l_113_6 = "Lowest/ActionBar"
    l_113_6 = l_113_6 .. l_113_0
    local l_113_5 = nil
    return l_113_4(l_113_6)
  end
end

l_0_1 = BF_Macro
l_0_1.UseSkill = function(l_114_0)
  local l_114_1 = GetClientPlayer()
  if (BF_Macro.bProtectChannelSkill and l_114_1.GetOTActionState() ~= 2) or not BF_Macro.bProtectChannelSkill then
    if l_114_0 == "��ִֹ��" or l_114_0 == "�ж϶���" then
      bPrePare = l_114_1.GetSkillPrepareState()
    end
    if bPrePare then
      l_114_1.StopCurrentAction()
    end
  elseif l_114_0 == "��" then
    Jump()
  else
    local l_114_2, l_114_3 = BF_Macro.CanUseSkill(R3_PC22), R3_PC22
  end
  if l_114_2 then
    R4_PC21 = BF_Macro
    R4_PC21 = R4_PC21.bDoSkillCast
  end
  if R4_PC21 then
    R4_PC21 = BF_Macro
    R4_PC21 = R4_PC21.GetUseSkillID
    R5_PC20 = l_114_0
    R4_PC21 = R4_PC21(R5_PC20)
    local l_114_4, l_114_5 = nil
    OnAddOnUseSkill(l_114_4, l_114_5)
  end
  if l_114_3 and l_114_1.nMoveState == 1 then
    BF_Macro.bDoSkillCast = false
  end
end

l_0_1 = function(l_115_0)
  if not BF_Macro.bEnable then
    return 
  end
  local l_115_1, l_115_2, l_115_3, l_115_4 = string.find(l_115_0, "[[](.+)[]]%s*(.+)")
  if not l_115_4 then
    local l_115_5 = SplitString(l_115_0, ",")
    for l_115_9 = 1, table.getn(l_115_5) do
      BF_Macro.UseSkill(l_115_5[l_115_9])
    end
  else
    local l_115_10 = BF_Macro.CheckOption(l_115_3)
  end
  if l_115_10 then
    BF_Macro.UseSkill(l_115_4)
  end
end

Skill = l_0_1
l_0_1 = RegisterEvent
l_0_1("DO_SKILL_CAST", function()
  local l_116_0 = GetClientPlayer()
  if arg0 == l_116_0.dwID then
    if arg1 == 3360 then
      BF_Macro.bPuppetAttack = true
    elseif arg1 == 3382 or arg1 == 3368 or arg1 == 3369 then
      BF_Macro.bPuppetAttack = false
    end
    BF_Macro.bDoSkillCast = true
  end
end
)
l_0_1 = UserSelect
l_0_1 = l_0_1.SelectPoint
UserSelect.SelectPoint = function(l_117_0, l_117_1, l_117_2, l_117_3)
  -- upvalues: l_0_1
  local l_117_9 = nil
  if not BF_Macro.bArea then
    local l_117_4 = l_0_1
    local l_117_5 = l_117_0
    local l_117_6 = l_117_1
    local l_117_7 = l_117_2
    local l_117_8 = l_117_3
    return l_117_4(l_117_5, l_117_6, l_117_7, l_117_8)
  end
  l_0_1(l_117_0, l_117_1, l_117_2, l_117_3)
  local l_117_10 = GetTargetHandle(GetClientPlayer().GetTarget())
  if l_117_10 then
    x = l_117_10.nX
    y = l_117_10.nY
    z = l_117_10.nZ
  else
    local l_117_11 = l_0_1
    local l_117_12 = l_117_0
    local l_117_13 = l_117_1
    local l_117_14 = l_117_2
    local l_117_15 = l_117_3
    return l_117_11(l_117_12, l_117_13, l_117_14, l_117_15)
  end
  UserSelect.DoSelectPoint(x, y, z)
end

AppendCommand("config", l_0_0)
AppendCommand("skill", Skill)
BFConfigPanel.RegisterMod("Macro", "��ź�", "\\ui\\image\\icon\\DropItemNew03.tga", "dajiaohong")
BFConfigPanel.RegisterCheckButton("Macro", "bEnable", "���ô�ź���չ���뽫�����ϵ��������У�", true, function(l_118_0)
  BF_Macro.bEnable = l_118_0
end
)
BFConfigPanel.RegisterCheckButton("Macro", "bArea", "���÷�Χ������ǿ", false, function(l_119_0)
  BF_Macro.bArea = l_119_0
end
)

