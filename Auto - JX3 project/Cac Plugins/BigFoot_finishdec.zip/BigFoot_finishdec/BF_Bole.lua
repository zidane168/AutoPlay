-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Bole.lua 

local l_0_0 = {}
l_0_0.bEnable = false
l_0_0.bDragable = false
l_0_0.bNeedHelp = false
l_0_0.bAutoSet = false
l_0_0.poxX = 800
l_0_0.poxY = 300
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1, function()
  local l_10_0 = GetNpc(arg0)
  for l_10_4 = 1, #BF_Bole.List do
    if l_10_0.dwTemplateID == BF_Bole.List[l_10_4] then
      BF_Bole.Target = l_10_0
    end
    if BF_Bole.bNeedHelp and BF_Bole.bEnable then
      PlaySound(SOUND.CHARACTER_SPEAK, "data\\sound\\����\\view\\nat_view2.wav")
    end
  end
end
)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

l_0_0(l_0_1, function()
  local l_11_0 = GetNpc(arg0)
  for l_11_4 = 1, #BF_Bole.List do
    if l_11_0.dwTemplateID == BF_Bole.List[l_11_4] then
      BF_Bole.Target = nil
    end
  end
end
)
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

do
  local l_0_2 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_0_0(l_0_1, l_0_2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2, "MSG_SYS", "MSG_NORMAL")
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2, "���ò���Ѱ��", false, function(l_13_0)
  BF_Bole.TimeRec = 0
  BF_Bole.bEnable = l_13_0
  BF_Bole.SwitchActive(l_13_0)
end
)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2, "��������", true, function(l_14_0)
  BF_Bole.bDragable = l_14_0
  Station.Lookup("Normal/BF_Bole"):EnableDrag(not l_14_0)
end
, 2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2, "������ʾ", true, function(l_15_0)
  BF_Bole.bNeedHelp = l_15_0
end
, 2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0(l_0_1, l_0_2, "�Զ�ѡ��", true, function(l_16_0)
  BF_Bole.bAutoSet = l_16_0
end
, 2)
end
 -- WARNING: undefined locals caused missing assignments!

