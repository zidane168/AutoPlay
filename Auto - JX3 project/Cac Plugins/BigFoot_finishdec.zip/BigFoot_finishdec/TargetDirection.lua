-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetDirection.lua 

if not TargetDirection then
  TargetDirection = {}
end
TargetDirection.bShowTargetDirection = true
TargetDirection.Anchor = {}
TargetDirection.bShowBg = true
TargetDirection.bShowForce = true
RegisterCustomData("TargetDirection.Anchor")
TargetDirection.OnFrameCreate = function()
  this:RegisterEvent("SYNC_ROLE_DATA_END")
  this:RegisterEvent("CURRENT_PLAYER_FORCE_CHANGED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("UI_SCALED")
  TargetDirection.UpdateAnchor(this)
  UpdateCustomModeWindow(this, "Ŀ�귽��")
end

TargetDirection.OnFrameDragEnd = function()
  this:CorrectPos()
  TargetDirection.Anchor = GetFrameAnchor(this)
end

TargetDirection.OnEvent = function(l_3_0)
  if l_3_0 == "SYNC_ROLE_DATA_END" or l_3_0 == "CURRENT_PLAYER_FORCE_CHANGED" then
    local l_3_1 = GetClientPlayer()
    if not l_3_1 then
      return 
    end
    local l_3_2, l_3_3 = GetForceImage(l_3_1.dwForceID)
    local l_3_4 = Station.Lookup("Topmost/TargetDirection")
    l_3_4:Lookup("", "Image_Force"):FromUITex(l_3_2, l_3_3)
    local l_3_5 = GetForceTitle(l_3_1.dwForceID)
    local l_3_6 = 4
    if l_3_5 ~= "" then
      if l_3_5 == "����" or l_3_5 == "���" then
        l_3_6 = 4
      end
    elseif l_3_5 == "�ؽ�" or l_3_5 == "����" then
      l_3_6 = 5
    elseif l_3_5 == "����" or l_3_5 == "�嶾" then
      l_3_6 = 6
    elseif l_3_5 == "����" then
      l_3_6 = 7
    elseif l_3_5 == "��" or l_3_5 == "����" then
      l_3_6 = 8
    end
    l_3_4:Lookup("", "Image_Direction"):SetFrame(l_3_6)
  elseif l_3_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_3_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this)
  elseif l_3_0 == "UI_SCALED" then
    TargetDirection.UpdateAnchor(this)
  end
end

TargetDirection.UpdateAnchor = function(l_4_0)
  if IsEmpty(TargetDirection.Anchor) then
    local l_4_1, l_4_2 = Station.GetClientSize()
    l_4_0:SetAbsPos(l_4_1 / 2, l_4_2 / 2)
  else
    l_4_0:SetPoint(TargetDirection.Anchor.s, 0, 0, TargetDirection.Anchor.r, TargetDirection.Anchor.x, TargetDirection.Anchor.y)
    l_4_0:CorrectPos()
  end
end

TargetDirection.OnFrameBreathe = function()
  if not TargetDirection.bShowTargetDirection then
    return 
  end
  local l_5_0 = GetClientPlayer()
  if not l_5_0 then
    return 
  end
  local l_5_1 = 4.7124
  local l_5_2 = GetTargetHandle(l_5_0.GetTarget())
  if l_5_2 and l_5_2.dwID ~= l_5_0.dwID then
    local l_5_3 = Station.Lookup("Topmost/TargetDirection")
    local l_5_4 = l_5_3:Lookup("", "")
    local l_5_5 = l_5_4:Lookup("Text_Distance")
    local l_5_6 = l_5_4:Lookup("Image_Direction")
    local l_5_7 = GetCharacterDistance(l_5_2.dwID, l_5_0.dwID) / 64
    local l_5_8 = string.format("%.1f", l_5_7)
    l_5_5:SetText(l_5_8)
    local l_5_9 = l_5_2.nX - l_5_0.nX
    local l_5_10 = l_5_2.nY - l_5_0.nY
    local l_5_11 = math.sqrt(l_5_9 ^ 2 + l_5_10 ^ 2)
    local l_5_12 = 0
    if l_5_10 < 0 then
      l_5_12 = math.acos(l_5_9 / l_5_11)
    else
      l_5_12 = 6.2832 - math.acos(l_5_9 / l_5_11)
    end
    local l_5_13 = (255 - l_5_0.nFaceDirection) * 6.2832 / 255
    local l_5_14 = l_5_12 - l_5_13
     -- DECOMPILER ERROR: Confused about usage of registers!

    if 4.7124 + l_5_14 > 6.2832 then
      local l_5_15, l_5_16, l_5_17 = 4.7124 + l_5_14 - 6.2832
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_5_6:SetRotate(l_5_15)
    TargetDirection.ShoworHide(true)
  else
    TargetDirection.ShoworHide(false)
  end
end

TargetDirection.ShoworHide = function(l_6_0)
  local l_6_1 = Station.Lookup("Topmost/TargetDirection")
  local l_6_2 = l_6_1:Lookup("", "")
  local l_6_3, l_6_4 = l_6_2:GetAbsPos()
  if l_6_0 then
    local l_6_5 = l_6_2:Lookup("Image_TextBg")
    local l_6_6 = l_6_2:Lookup("Image_Force")
    local l_6_7 = l_6_2:Lookup("Text_Distance")
    if TargetDirection.bShowBg then
      l_6_5:Show()
    else
      l_6_5:Hide()
    end
    if TargetDirection.bShowForce then
      l_6_6:Show()
      l_6_7:SetAbsPos(l_6_3 + 57, l_6_4 + 120)
    else
      l_6_6:Hide()
      l_6_7:SetAbsPos(l_6_3 + 57, l_6_4 + 94)
    end
    l_6_2:Show()
  else
    l_6_2:Hide()
  end
end

TargetDirection.Switch = function(l_7_0)
  local l_7_1 = Station.Lookup("Topmost/TargetDirection")
  if l_7_0 then
    l_7_1:Show()
  else
    l_7_1:Hide()
  end
end

Wnd.OpenWindow("Interface\\BF_TargetEx\\TargetDirection.ini", "TargetDirection")

