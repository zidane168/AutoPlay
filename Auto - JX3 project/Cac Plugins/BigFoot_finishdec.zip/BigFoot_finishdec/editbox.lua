-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: editbox.lua 

BFEditBox = classv2(BFWidget)
BFEditBox.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
end

BFEditBox.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = assert
  l_2_3(l_2_1 >= 0 and l_2_2 >= 0, "Invalid widget size.")
  l_2_3 = Wnd
  l_2_3 = l_2_3.OpenWindow
  l_2_3 = l_2_3("Interface\\BF_Base\\widget\\editbox.ini", l_2_0:GetName())
  local l_2_6 = l_2_3:Lookup("Wnd_Main")
  l_2_0:SetContainer(l_2_6)
  local l_2_7 = l_2_6:Lookup("Edit_Main")
  local l_2_8 = l_2_6:Lookup("", "")
  local l_2_9 = l_2_8:Lookup("Image_Border")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox = l_2_7
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_8
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border = l_2_9
  l_2_7.widget = l_2_0
  l_2_7.OnEditChanged = function()
    -- upvalues: l_2_0
    local l_3_0 = l_2_0:GetText()
    this.widget:_FireEvent("OnChanged", l_3_0)
  end
  l_2_0:SetSize(l_2_1, l_2_2)
  l_2_0:SetLimit(1024)
  l_2_0:SetBorder(true, true)
end

BFEditBox.SetText = function(l_3_0, l_3_1)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetText(l_3_1)
end

BFEditBox.GetText = function(l_4_0)
  local l_4_1, l_4_2 = l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:GetText, l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox
  return l_4_1(l_4_2)
end

BFEditBox.SetTextColor = function(l_5_0, l_5_1, l_5_2, l_5_3)
  local l_5_4 = l_5_1
  l_5_0.g = l_5_2
  l_5_0.r = l_5_4
  l_5_4 = l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28
  l_5_4 = l_5_4.editbox
  l_5_4 = l_5_4.SetFontColor
  l_5_4(l_5_1, l_5_2, l_5_3)
end

BFEditBox.SetLimit = function(l_6_0, l_6_1)
  l_6_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetLimit(l_6_1)
end

BFEditBox.Enable = function(l_7_0)
  l_7_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetFontColor(255, 255, 255)
  l_7_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:Enable(true)
end

BFEditBox.Disable = function(l_8_0)
  l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetFontColor(192, 192, 192)
  l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:Enable(false)
end

BFEditBox.GetLimit = function(l_9_0)
  local l_9_1, l_9_2 = l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:GetLimit, l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox
  return l_9_1(l_9_2)
end

BFEditBox.SelectAll = function(l_10_0)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SelectAll()
end

BFEditBox.SetBorder = function(l_11_0, l_11_1, l_11_2)
  if l_11_1 then
    l_11_0.BigFoot_fefa312ff9862f15d0d044cd56708b9d = true
  else
    l_11_0.BigFoot_fefa312ff9862f15d0d044cd56708b9d = false
  end
  if not l_11_2 then
    l_11_0:Update()
  end
end

BFEditBox._UpdateContent = function(l_12_0)
  local l_12_1 = l_12_0:GetWidth()
  local l_12_2 = l_12_0:GetHeight()
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetSize(l_12_1 - 16, l_12_2 - 10)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.editbox:SetRelPos(8, 5)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSize(l_12_1, l_12_2)
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:SetSize(l_12_1, l_12_2)
  if l_12_0.BigFoot_fefa312ff9862f15d0d044cd56708b9d then
    l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:Show()
  else
    l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.border:Hide()
  end
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:FormatAllItemPos()
  l_12_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSizeByAllItemSize()
end


