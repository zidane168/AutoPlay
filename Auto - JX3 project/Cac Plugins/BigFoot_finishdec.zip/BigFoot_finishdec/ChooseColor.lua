-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ChooseColor.lua 

BFChooseColor = classv2(BFWidget)
BFChooseColor.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  l_1_0:SetSize(l_1_2, l_1_3)
end

BFChooseColor.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\ChooseColor.ini", l_2_0:GetName())
  local l_2_4 = l_2_3:Lookup("Wnd_Main")
  local l_2_5 = l_2_4:Lookup("", "")
  local l_2_6 = l_2_5:Lookup("Text_Color_Name")
  local l_2_7 = l_2_5:Lookup("Shadow_Color_Channel")
  l_2_7.widget = l_2_0
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_5
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ColorName = l_2_6
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ShadowColor = l_2_7
  l_2_0:SetContainer(l_2_4)
  l_2_7.OnItemLButtonClick = function()
    -- upvalues: l_2_0
    OpenColorTablePanel(function(l_4_0, l_4_1, l_4_2)
      -- upvalues: l_2_0
      l_2_0:SetDefaultColor(l_4_0, l_4_1, l_4_2)
      arg0 = l_4_0
      arg1 = l_4_1
      arg2 = l_4_2
      l_2_0:_FireEvent("OnColorChanged")
    end)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

BFChooseColor.SetDefaultText = function(l_3_0, l_3_1)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ColorName:SetText(l_3_1)
  local l_3_2, l_3_3 = l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ColorName:GetAbsPos()
  local l_3_4 = string.len(l_3_1)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ShadowColor:SetAbsPos(l_3_2 + l_3_4 * 8, l_3_3)
end

BFChooseColor.GetDefaultText = function(l_4_0)
  local l_4_1, l_4_2 = l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ColorName:GetText, l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ColorName
  return l_4_1(l_4_2)
end

BFChooseColor.SetDefaultColor = function(l_5_0, l_5_1, l_5_2, l_5_3)
  l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ShadowColor:SetColorRGB(l_5_1, l_5_2, l_5_3)
end

BFChooseColor.GetDefaultColor = function(l_6_0)
  local l_6_1, l_6_2, l_6_3 = l_6_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.ShadowColor:GetColorRGB()
  return l_6_1, l_6_2, l_6_3
end

BFChooseColor.Enable = function(l_7_0)
end

test_ChooseColor = function()
  local l_8_0 = BFFrame.new(200, 200, "NONE")
  ChooseColor = BFChooseColor.new(l_8_0, 100, 25)
  l_8_0:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", 800, 500)
  ChooseColor:SetPoint("TOPLEFT", l_8_0, "TOPLEFT", 0, 0)
  ChooseColor:SetDefaultText("test_ChooseColor")
  ChooseColor:SetDefaultColor(255, 255, 255)
  local l_8_1, l_8_2, l_8_3 = ChooseColor:GetDefaultColor()
  local l_8_4 = ChooseColor:GetDefaultText()
  Output(l_8_4)
  Output(l_8_1, l_8_2, l_8_3)
  ChooseColor.OnColorChanged = function(l_9_0)
    Output(arg0, arg1, arg2)
  end
end


