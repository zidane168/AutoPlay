-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ~BF_Loot.lua 

if not BF_Loot then
  BF_Loot = {}
end
BF_Loot.LootList = {}
BF_Loot.bLootEnable = true
BF_Loot.bGrayFilter = true
BF_Loot.bRoolGreenItems = true
BF_Loot.OnFrameCreate = function()
  this:RegisterEvent("SYNC_LOOT_LIST")
  this:RegisterEvent("OPEN_DOODAD")
  this:RegisterEvent("DOODAD_LEAVE_SCENE")
  this:RegisterEvent("BEGIN_ROLL_ITEM")
end

BF_Loot.OnEvent = function(l_2_0)
  if l_2_0 == "DOODAD_LEAVE_SCENE" then
    BF_Loot.RemoveDoodad(arg0)
  elseif l_2_0 == "SYNC_LOOT_LIST" then
    BF_Loot.AppendDoodad(arg0)
  elseif l_2_0 == "BEGIN_ROLL_ITEM" then
    BF_Loot.RoolGreenItems(arg0, arg1)
  elseif l_2_0 == "OPEN_DOODAD" then
    BF_Loot.LootAllItems(arg0)
  end
end

BF_Loot.OnFrameBreathe = function()
  if not BF_Loot.bAutoEnable then
    return 
  end
  local l_3_0 = GetClientPlayer()
  if not l_3_0 then
    return 
  end
  if GetLogicFrameCount() % 16 == 0 then
    for l_3_4,l_3_5 in pairs(BF_Loot.LootList) do
      BF_Loot.LootItemsByQuality(l_3_5, true)
      BF_Loot.RemoveDoodad(l_3_5)
    end
  end
end

BF_Loot.AppendDoodad = function(l_4_0)
  local l_4_1 = GetClientPlayer()
  if not l_4_1 then
    return 
  end
  local l_4_2 = GetDoodad(l_4_0)
  if l_4_2 and l_4_2.nKind == DOODAD_KIND.CORPSE and l_4_2.CanLoot(l_4_1.dwID) then
    BF_Loot.LootList[l_4_0] = l_4_0
  end
end

BF_Loot.RemoveDoodad = function(l_5_0)
  if BF_Loot.LootList[l_5_0] then
    BF_Loot.LootList[l_5_0] = nil
  end
end

BF_Loot.LootItemsByQuality = function(l_6_0, l_6_1)
  local l_6_2 = GetDoodad(l_6_0)
  if l_6_2.nKind ~= DOODAD_KIND.CORPSE then
    return 
  end
  if l_6_1 then
    InteractDoodad(l_6_0)
  end
  BF_Loot.RemoveDoodad(l_6_0)
  local l_6_3 = Station.Lookup("Normal/LootList")
  if l_6_3 then
    l_6_3:Hide()
  else
    return 
  end
  local l_6_4 = l_6_3:Lookup("", "Handle_LootList")
  local l_6_5 = l_6_4:GetItemCount()
  for l_6_9 = 0, l_6_5 - 1 do
    local l_6_10 = l_6_4:Lookup(l_6_9)
    if l_6_10.bMoney then
      LootMoney(l_6_0)
    else
      local l_6_11 = GetItem(l_6_10.dwID)
    end
    if l_6_11 then
      local l_6_12 = l_6_11.nQuality
      Output(l_6_11.szName)
      if BF_Loot.tFilter[l_6_12] then
        return 
      end
      LootItem(l_6_0, l_6_11.dwID)
    end
  end
end

BF_Loot.RoolGreenItems = function(l_7_0, l_7_1)
  if not BF_Loot.bRoolGreenItems then
    return 
  end
  local l_7_2 = GetItem(l_7_1)
  if not l_7_2 then
    return 
  end
  local l_7_3 = l_7_2.nQuality
  local l_7_4 = 2
  if l_7_3 == l_7_4 and (l_7_2.nBindType ~= ITEM_BIND.BIND_ON_PICKED or l_7_2.nBindType ~= ITEM_BIND.BIND_ON_PICKED or tWitheList[l_7_2.szName]) then
    RollItem(l_7_0, l_7_1, 2)
    for l_7_8 = 1, 4 do
      do
        local l_7_9 = Station.Lookup("Normal/LootRoll" .. l_7_8)
        if l_7_9 and l_7_9.dwDoodadID == arg0 and l_7_9.dwItemID == arg1 then
          Wnd.CloseWindow(l_7_9:GetName())
        end
        do break end
      end
    end
    local l_7_10 = MakeItemLink("[" .. l_7_2.szName .. "]", " font=10 r=0 g=255 b=32 ", l_7_2.dwID)
    BigFoot_Print("ʰȡ����", "�Զ�ROLL��ɫ����" .. l_7_10)
  end
end

Wnd.OpenWindow("Interface\\BF_Loot\\BF_Loot.ini", "BF_Loot")
BFConfigPanel.RegisterMod("Loot", "ʰȡ����", "\\ui\\image\\icon\\coin05.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("Loot", "bAutoEnable", "�����Զ�ʰȡ", true, function(l_8_0)
  BF_Loot.bAutoEnable = l_8_0
end
)
BFConfigPanel.RegisterCheckButton("Loot", "tFilter[0]", "���˻�ɫ", true, function(l_9_0)
  BF_Loot.tFilter[0] = l_9_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Loot", "tFilter[1]", "���˰�ɫ", false, function(l_10_0)
  BF_Loot.tFilter[1] = l_10_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Loot", "tFilter[2]", "������ɫ", false, function(l_11_0)
  BF_Loot.tFilter[2] = l_11_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Loot", "tFilter[3]", "������ɫ", false, function(l_12_0)
  BF_Loot.tFilter[3] = l_12_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Loot", "bRoolGreenItems", "�����Զ�ROOL��ɫ��Ʒ", true, function(l_13_0)
  BF_Loot.bRoolGreenItems = l_13_0
end
)

