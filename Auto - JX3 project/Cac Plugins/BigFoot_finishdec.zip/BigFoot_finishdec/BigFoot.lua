-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BigFoot.lua 

BigFoot = {}
BigFoot_Config = {}
BigFoot_Config.FramePositions = {}
BigFoot_SavedFrames = {}
RegisterCustomData("BigFoot_Config")
BF_EscapeFrames = {}
BigFoot.TogglePanel = function(l_1_0)
  if l_1_0 == "OPTION" then
    local l_1_1, l_1_2 = nil, nil
    for l_1_6,l_1_7 in pairs(BF_EscapeFrames) do
      if l_1_7[1]() then
        l_1_7[2]()
        return 
      end
    end
  end
end

RegisterEvent("PLAYER_EXIT_GAME", function()
  BigFoot.OpenExitPanel()
end
)
BigFoot.RegisterEscapeFrame = function(l_3_0, l_3_1, l_3_2)
  local l_3_3 = assert
  l_3_3(type(l_3_0) == "string", "The key must be string.")
  l_3_3 = assert
  l_3_3(type(l_3_1) == "function" and type(l_3_2) == "function", "Invalid frame callback")
  l_3_3 = BF_EscapeFrames
  do
    local l_3_8 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  end
   -- WARNING: undefined locals caused missing assignments!
end

BigFoot.RegisterFrame = function(l_4_0, ...)
  if l_4_0 == "position" then
    local l_4_2, l_4_3 = ..., ...
    BigFoot_SavedFrames[l_4_2] = l_4_3
  end
end

BigFoot.IsWidget = function(l_5_0)
  if type(l_5_0) == "table" and l_5_0.IsWidget and type(l_5_0.IsWidget) == "function" and l_5_0:IsWidget() then
    return true
  end
end

BigFoot.OpenExitPanel = function(...)
  local l_6_1 = nil
  for l_6_5,i_2 in pairs(BigFoot_SavedFrames) do
    local l_6_2 = nil
    local l_6_8 = nil
    local l_6_9, l_6_10 = i_2:GetAbsPos()
    BigFoot_Config.FramePositions[l_6_6].cx = l_6_8:GetSize()
    BigFoot_Config.FramePositions[l_6_6].cy = l_6_8
    if BigFoot.IsWidget(l_6_8) then
      BigFoot_Config.FramePositions[l_6_6].show = l_6_8:IsShown()
    else
      BigFoot_Config.FramePositions[l_6_6].show = l_6_8:IsVisible()
    end
  end
end

RegisterEvent("LOGIN_GAME", function()
  local l_7_0, l_7_1 = nil, nil
  for i_1,i_2 in pairs(BigFoot_SavedFrames) do
    if BigFoot_Config.FramePositions[i_1] then
      local l_7_7, l_7_8, l_7_9 = i_2, nil, nil
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if BigFoot.IsWidget(l_7_7) then
        l_7_7:ClearAllPoints()
        l_7_7:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_7_8, l_7_9)
      else
        l_7_7:SetAbsPos(l_7_8, l_7_9)
      end
      if BigFoot_Config.FramePositions[l_7_5].show then
        l_7_7:Show()
      end
    else
      l_7_7:Hide()
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end
)

