-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_SexyCooldown.lua 

local l_0_0 = {}
l_0_0.nX = 5
l_0_0.nY = 570
BF_SexyCooldown = l_0_0
l_0_0 = RegisterCustomData
l_0_0("BF_SexyCooldown.nX")
l_0_0 = RegisterCustomData
l_0_0("BF_SexyCooldown.nY")
l_0_0 = function()
  local l_1_0 = Station.Lookup("Normal/BF_SexyCooldown")
  if l_1_0 then
    l_1_0:Show()
  else
    Wnd.OpenWindow("Interface\\BF_SexyCooldown\\BF_SexyCooldown.ini", "BF_SexyCooldown")
  end
end

BigFoot_6db5bfa3aa9d460be6c42c6950f4e34f = l_0_0
l_0_0 = BF_SexyCooldown
l_0_0.OnFrameCreate = function()
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  UpdateCustomModeWindow(this, "��̬����CD��λ������")
  BF_SexyCooldown.init()
end

l_0_0 = BF_SexyCooldown
l_0_0.init = function()
  local l_3_0 = Station.Lookup("Normal/BF_SexyCooldown")
  if not l_3_0 then
    return 
  end
  local l_3_1 = l_3_0:Lookup("", "")
  local l_3_2 = l_3_1:Lookup("Image_SexyCooldown")
  l_3_2:FromTextureFile("Interface\\BF_SexyCooldown\\jindutiao.tga")
  l_3_2:SetSize(600, 40)
  l_3_2:SetAlpha(150)
  local l_3_3 = l_3_1:Lookup("Text1"):SetText("0")
  l_3_1:Lookup("Text1"):SetFontColor(255, 255, 255)
  local l_3_4 = l_3_1:Lookup("Text2"):SetText("5s")
  l_3_1:Lookup("Text2"):SetFontColor(255, 255, 255)
  local l_3_5 = l_3_1:Lookup("Text3"):SetText("10s")
  l_3_1:Lookup("Text4"):SetText("30s")
  l_3_1:Lookup("Text4"):SetFontColor(255, 255, 255)
  l_3_1:Lookup("Text3"):SetFontColor(255, 255, 255)
  l_3_1:Lookup("Text5"):SetText("1m")
  l_3_1:Lookup("Text5"):SetFontColor(255, 255, 255)
end

l_0_0 = BF_SexyCooldown
l_0_0.OnFrameDragEnd = function()
  local l_4_0 = this:GetRoot()
  local l_4_1, l_4_2 = l_4_0:GetAbsPos()
  BF_SexyCooldown.nX = l_4_1
  BF_SexyCooldown.nY = l_4_2
end

l_0_0 = BF_SexyCooldown
l_0_0.OnFrameShow = function()
  local l_5_0 = this:GetRoot()
  l_5_0:SetAbsPos(BF_SexyCooldown.nX, BF_SexyCooldown.nY)
end

l_0_0 = BF_SexyCooldown
l_0_0.OnFrameBreathe = function()
  local l_6_0 = Station.Lookup("Normal/BF_SexyCooldown")
  local l_6_1 = l_6_0:Lookup("", "")
  local l_6_2 = l_6_1:Lookup("Handle_Box")
  local l_6_3 = l_6_1:Lookup("Handle_Box1")
  local l_6_4 = l_6_3:Lookup("BoxCD")
  local l_6_5 = GetClientPlayer()
  if not l_6_5 then
    return 
  end
  local l_6_6 = l_6_2:GetItemCount()
  for l_6_10 = 0, l_6_6 - 1 do
    local l_6_11 = l_6_2:Lookup(l_6_10)
    if not l_6_11 then
      return 
    end
    local l_6_12, l_6_13, l_6_14 = l_6_5.GetSkillCDProgress(l_6_11.skillID, l_6_11.skillLevel)
    local l_6_15 = Table_GetSkillName(l_6_11.skillID, l_6_11.skillLevel)
    local l_6_16 = BigFoot_189697579bf430ff2e0c9ee2f2bae909(l_6_13)
    local l_6_17, l_6_18 = l_6_0:GetAbsPos()
    l_6_11:SetOverText(1, l_6_16)
    local l_6_19 = math.ceil(l_6_13 / 16)
    if l_6_19 <= 60 then
      l_6_11:Show()
      if l_6_19 >= 10 then
        l_6_11:SetAbsPos(l_6_17 + 30 + 160 + 160 + (l_6_13 - 160) / 4, l_6_18 + 20)
      elseif l_6_19 >= 5 then
        l_6_11:SetAbsPos(l_6_17 + 30 + l_6_13 + 160, l_6_18 + 20)
      else
        l_6_11:SetAbsPos(l_6_17 + 30 + l_6_13 * 3, l_6_18 + 20)
      end
      if l_6_13 == 0 then
        l_6_11:Hide()
        l_6_4:SetObject(UI_OBJECT_NOT_NEED_KNOWN, l_6_11.skillID)
        l_6_4:SetObjectIcon(Table_GetSkillIconID(l_6_11.skillID, l_6_11.skillLevel))
        l_6_4:SetAbsPos(l_6_17, l_6_18)
        l_6_4.Alpha = 255
        l_6_2:RemoveItem(l_6_10)
      end
    else
      l_6_11:Hide()
    end
  end
  if not l_6_4.Alpha then
    return 
  end
  if l_6_4.Alpha > 0 then
    l_6_4:SetAlpha(l_6_4.Alpha)
    l_6_4.Alpha = l_6_4.Alpha - 8
  end
end

l_0_0 = function(l_7_0)
  local l_7_1 = math.ceil(l_7_0 / 16)
  if l_7_1 == 0 then
    return ""
  end
  if l_7_1 > 3200 then
    l_7_1 = math.ceil(l_7_1 / 3600) .. "h"
  elseif l_7_1 > 60 then
    l_7_1 = math.ceil(l_7_1 / 60) .. "m"
  else
    l_7_1 = math.ceil(l_7_0 / 16) .. "s"
  end
  return l_7_1
end

BigFoot_189697579bf430ff2e0c9ee2f2bae909 = l_0_0
l_0_0 = BF_SexyCooldown
l_0_0.useSkill = function()
  local l_8_0 = Station.Lookup("Normal/BF_SexyCooldown")
  if not l_8_0 then
    return 
  end
  local l_8_1 = l_8_0:Lookup("", "")
  local l_8_2 = l_8_1:Lookup("Handle_Box")
  local l_8_3 = GetClientPlayer()
  if arg0 == l_8_3.dwID then
    local l_8_4, l_8_5, l_8_6 = l_8_3.GetSkillCDProgress(arg1, arg2)
  end
  if l_8_5 >= 30 then
    local l_8_7 = Table_GetSkillName(arg1, arg2)
    do
      local l_8_8 = l_8_2:Lookup("b" .. arg1)
      if l_8_8 then
        l_8_8.skillID = arg1
        l_8_8.skillLevel = arg2
        l_8_8:SetObject(UI_OBJECT_NOT_NEED_KNOWN, arg1)
        l_8_8:SetObjectIcon(Table_GetSkillIconID(arg1, arg2))
        l_8_8.OnItemMouseEnter = function()
          -- upvalues: l_8_8
          this:SetObjectMouseOver(1)
          local l_9_0, l_9_1 = this:GetAbsPos()
          local l_9_2, l_9_3 = this:GetSize()
          local l_9_4 = OutputSkillTip
          local l_9_5 = l_8_8.skillID
          local l_9_6 = l_8_8.skillLevel
          do
            local l_9_7 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_9_4(l_9_5, l_9_6, l_9_7)
          end
           -- WARNING: undefined locals caused missing assignments!
        end
        l_8_8.OnItemMouseLeave = function()
          HideTip()
          this:SetObjectMouseOver(0)
        end
      else
        l_8_2:AppendItemFromString("<box>w=45 h=45 eventid=262912 postype=7</box>")
        l_8_8 = l_8_2:Lookup(l_8_2:GetItemCount() - 1)
        l_8_8.skillID = arg1
        l_8_8.skillLevel = arg2
        l_8_8:SetName("b" .. arg1)
        l_8_8:SetOverTextFontScheme(0, 15)
        l_8_8:SetObject(UI_OBJECT_NOT_NEED_KNOWN, arg1)
        l_8_8:SetObjectIcon(Table_GetSkillIconID(arg1, arg2))
        l_8_8.OnItemMouseEnter = function()
          -- upvalues: l_8_8
          this:SetObjectMouseOver(1)
          local l_11_0, l_11_1 = this:GetAbsPos()
          local l_11_2, l_11_3 = this:GetSize()
          local l_11_4 = OutputSkillTip
          local l_11_5 = l_8_8.skillID
          local l_11_6 = l_8_8.skillLevel
          do
            local l_11_7 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_11_4(l_11_5, l_11_6, l_11_7)
          end
           -- WARNING: undefined locals caused missing assignments!
        end
        l_8_8.OnItemMouseLeave = function()
          HideTip()
          this:SetObjectMouseOver(0)
        end
      end
      l_8_8:Hide()
    end
  end
end

l_0_0 = BF_SexyCooldown
l_0_0.OnEvent = function(l_9_0)
  if l_9_0 == "CUSTOM_DATA_LOADED" then
    local l_9_1 = this:GetRoot()
    l_9_1:SetAbsPos(BF_SexyCooldown.nX, BF_SexyCooldown.nY)
  end
  if l_9_0 == "ON_ENTER_CUSTOM_UI_MODE" then
    local l_9_2 = this:GetRoot()
    UpdateCustomModeWindow(this)
    l_9_2:SetMousePenetrable(false)
  elseif l_9_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    local l_9_3 = this:GetRoot()
    UpdateCustomModeWindow(this)
    l_9_3:SetMousePenetrable(true)
  end
end

l_0_0 = RegisterEvent
l_0_0("DO_SKILL_CAST", BF_SexyCooldown.useSkill)
l_0_0 = BigFoot_6db5bfa3aa9d460be6c42c6950f4e34f
l_0_0()
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterMod
l_0_0("SexyCooldown", "��̬��ʱ��", "\\ui\\image\\icon\\bagNew05a.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_0("SexyCooldown", "EnableSexyCooldown", "��̬���ܼ�ʱ��(�뵽�Զ�������޸�λ��)", false, function(l_10_0)
  if l_10_0 then
    BigFoot_6db5bfa3aa9d460be6c42c6950f4e34f()
  else
    local l_10_1 = Station.Lookup("Normal/BF_SexyCooldown")
  end
  if l_10_1 then
    l_10_1:Hide()
  end
end
)
l_0_0 = BigFoot
l_0_0 = l_0_0.RegisterMinimapButton
l_0_0("Interface\\BF_SexyCooldown\\SexyCooldown.tga", "<Text>text=\"��/�رն�̬��ʱ������\"</Text>", "SexyCooldown", "EnableSexyCooldown")

