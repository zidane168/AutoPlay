-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: progressbar.lua 

BFProgressBar = classv2(BFWidget)
BFProgressBar.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4, l_1_5, l_1_6)
  if l_1_5 and l_1_6 then
    l_1_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d = l_1_5
    l_1_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 = l_1_6
    l_1_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 = l_1_5
  else
    l_1_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d = 0
    l_1_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 = 100
    l_1_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 = 0
  end
  l_1_0:Create(l_1_2, l_1_3, l_1_4)
  l_1_0:SetParent(l_1_1)
end

BFProgressBar.Create = function(l_2_0, l_2_1, l_2_2, l_2_3)
  local l_2_4 = nil
  if not l_2_3 then
    l_2_4 = "THIN"
  end
  l_2_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e = l_2_4
  if l_2_4 == "MULTICOLOR" then
    local l_2_5 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\progressbar_multicolor.ini", l_2_0:GetName())
    local l_2_6 = l_2_5:Lookup("Wnd_Main")
    assert(l_2_6, "Failed to create ProgressBar widget.")
    l_2_0:SetContainer(l_2_6)
    local l_2_7 = l_2_6:Lookup("", "")
    l_2_0._elements = {}
    l_2_0._elements.handle = l_2_7
    l_2_0._elements.background = l_2_7:Lookup("Shadow_Background")
    l_2_0._elements.bar = {}
    l_2_0._elements.bar[1] = l_2_7:Lookup("Shadow_Bar1")
    l_2_0._elements.bar[2] = l_2_7:Lookup("Shadow_Bar2")
    l_2_0._elements.bar[3] = l_2_7:Lookup("Shadow_Highlight_L")
    l_2_0._elements.bar[4] = l_2_7:Lookup("Shadow_Highlight_C")
    l_2_0._elements.bar[5] = l_2_7:Lookup("Shadow_Highlight_R")
    l_2_0._elements.bar[1]:SetRelPos(2, 3)
    l_2_0._elements.bar[2]:SetRelPos(3, 2)
    l_2_0._elements.bar[3]:SetRelPos(0, 3)
    l_2_0._elements.bar[4]:SetRelPos(3, 2)
    l_2_0._elements.bar[5]:SetRelPos(3, 2)
    l_2_0._elements.bar[3]:SetColorRGB(255, 255, 255)
    l_2_0._elements.bar[4]:SetColorRGB(255, 255, 255)
    l_2_0._elements.bar[5]:SetColorRGB(255, 255, 255)
    l_2_0._elements.bar[3]:SetAlpha(55)
    l_2_0._elements.bar[4]:SetAlpha(55)
    l_2_0._elements.bar[5]:SetAlpha(55)
    l_2_0._elements.shadow = {}
    l_2_0._elements.shadow.tl = l_2_7:Lookup("Image_Shadow_TL")
    l_2_0._elements.shadow.tc = l_2_7:Lookup("Image_Shadow_TC")
    l_2_0._elements.shadow.tr = l_2_7:Lookup("Image_Shadow_TR")
    l_2_0._elements.shadow.cl = l_2_7:Lookup("Image_Shadow_CL")
    l_2_0._elements.shadow.cc = l_2_7:Lookup("Image_Shadow_CC")
    l_2_0._elements.shadow.cr = l_2_7:Lookup("Image_Shadow_CR")
    l_2_0._elements.shadow.bl = l_2_7:Lookup("Image_Shadow_BL")
    l_2_0._elements.shadow.bc = l_2_7:Lookup("Image_Shadow_BC")
    l_2_0._elements.shadow.br = l_2_7:Lookup("Image_Shadow_BR")
    l_2_0._elements.highlight = {}
    l_2_0._elements.highlight.tl = l_2_7:Lookup("Image_Highlight_TL")
    l_2_0._elements.highlight.tc = l_2_7:Lookup("Image_Highlight_TC")
    l_2_0._elements.highlight.tr = l_2_7:Lookup("Image_Highlight_TR")
    l_2_0._elements.highlight.cl = l_2_7:Lookup("Image_Highlight_CL")
    l_2_0._elements.highlight.cc = l_2_7:Lookup("Image_Highlight_CC")
    l_2_0._elements.highlight.cr = l_2_7:Lookup("Image_Highlight_CR")
    l_2_0._elements.highlight.bl = l_2_7:Lookup("Image_Highlight_BL")
    l_2_0._elements.highlight.bc = l_2_7:Lookup("Image_Highlight_BC")
    l_2_0._elements.highlight.br = l_2_7:Lookup("Image_Highlight_BR")
    l_2_0._border = true
    l_2_0:SetSize(l_2_1, l_2_2)
    l_2_0:SetColor(0, 0, 255)
  elseif l_2_4 == "THIN" then
    local l_2_8 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\progressbar_thin.ini", l_2_0:GetName())
    local l_2_9 = l_2_8:Lookup("Wnd_Main")
    assert(l_2_9, "Failed to create ProgressBar widget.")
    l_2_0:SetContainer(l_2_9)
    local l_2_10 = l_2_9:Lookup("", "")
    l_2_0._elements = {}
    l_2_0._elements.handle = l_2_10
    l_2_0._elements.tl = l_2_10:Lookup("Image_TL")
    l_2_0._elements.tc = l_2_10:Lookup("Image_TC")
    l_2_0._elements.tr = l_2_10:Lookup("Image_TR")
    l_2_0._elements.cl = l_2_10:Lookup("Image_CL")
    l_2_0._elements.cc = l_2_10:Lookup("Image_CC")
    l_2_0._elements.cr = l_2_10:Lookup("Image_CR")
    l_2_0._elements.bl = l_2_10:Lookup("Image_BL")
    l_2_0._elements.bc = l_2_10:Lookup("Image_BC")
    l_2_0._elements.br = l_2_10:Lookup("Image_BR")
    l_2_0._elements.background = l_2_10:Lookup("Image_Background")
    l_2_0._border = true
    l_2_0:SetSize(l_2_1, l_2_2)
  end
end

BFProgressBar.SetRange = function(l_3_0, l_3_1, l_3_2)
  l_3_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d = l_3_1
  l_3_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 = l_3_2
  l_3_0:Update()
end

BFProgressBar.SetPos = function(l_4_0, l_4_1)
  if l_4_1 <= l_4_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 and l_4_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d <= l_4_1 then
    l_4_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 = l_4_1
  elseif l_4_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 < l_4_1 then
    l_4_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 = l_4_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517
  else
    l_4_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 = l_4_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d
  end
  l_4_0:Update()
end

BFProgressBar.SetColor = function(l_5_0, l_5_1, l_5_2, l_5_3)
  if l_5_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "MULTICOLOR" then
    l_5_0._elements.bar[1]:SetColorRGB(l_5_1, l_5_2, l_5_3)
    l_5_0._elements.bar[2]:SetColorRGB(l_5_1, l_5_2, l_5_3)
  end
end

BFProgressBar.SetAlpha = function(l_6_0, l_6_1)
  if l_6_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "MULTICOLOR" then
    l_6_0._elements.bar[1]:SetAlpha(l_6_1)
    l_6_0._elements.bar[2]:SetAlpha(l_6_1)
  end
end

BFProgressBar._UpdateContent = function(l_7_0)
  local l_7_1 = l_7_0:GetWidth()
  local l_7_2 = l_7_0:GetHeight()
  local l_7_3 = (l_7_0.BigFoot_66fb91ae7efe85bf25d0a4760446c9c1 - l_7_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d) / (l_7_0.BigFoot_9226ee55ff8eed638d37ee13a4bdd517 - l_7_0.BigFoot_a22192947cbcf5f27a4eaf500379d03d)
  local l_7_4 = math.floor(l_7_1 * l_7_3)
  if l_7_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "MULTICOLOR" then
    l_7_0._elements.background:SetSize(l_7_1, l_7_2)
    l_7_0._elements.background:SetRelPos(0, 0)
    local l_7_5 = 9
    local l_7_6 = 9
    if l_7_4 < l_7_5 * 2 or l_7_2 < l_7_6 * 2 then
      local l_7_7 = l_7_4 / (l_7_5 * 2)
      local l_7_8 = l_7_2 / (l_7_6 * 2)
      local l_7_9 = math.min(l_7_7, l_7_8)
      local l_7_10 = l_7_5 * l_7_9
      local l_7_11 = l_7_6 * l_7_9
      l_7_0._elements.shadow.tl:SetSize(l_7_10, l_7_11)
      l_7_0._elements.shadow.tc:SetSize(l_7_4 - 2 * l_7_10, l_7_11)
      l_7_0._elements.shadow.tc:SetRelPos(l_7_10, 0)
      l_7_0._elements.shadow.tr:SetSize(l_7_10, l_7_11)
      l_7_0._elements.shadow.tr:SetRelPos(l_7_4 - l_7_10, 0)
      l_7_0._elements.shadow.cl:SetSize(l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.shadow.cl:SetRelPos(0, l_7_11)
      l_7_0._elements.shadow.cc:SetSize(l_7_4 - 2 * l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.shadow.cc:SetRelPos(l_7_10, l_7_11)
      l_7_0._elements.shadow.cr:SetSize(l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.shadow.cr:SetRelPos(l_7_4 - l_7_10, l_7_11)
      l_7_0._elements.shadow.bl:SetSize(l_7_10, l_7_11)
      l_7_0._elements.shadow.bl:SetRelPos(0, l_7_2 - l_7_11)
      l_7_0._elements.shadow.bc:SetSize(l_7_4 - 2 * l_7_10, l_7_11)
      l_7_0._elements.shadow.bc:SetRelPos(l_7_10, l_7_2 - l_7_11)
      l_7_0._elements.shadow.br:SetSize(l_7_10, l_7_11)
      l_7_0._elements.shadow.br:SetRelPos(l_7_4 - l_7_10, l_7_2 - l_7_11)
      l_7_0._elements.bar[1]:SetSize(l_7_4 - 6, l_7_2 - 4)
      l_7_0._elements.bar[1]:SetRelPos(3, 2)
      l_7_0._elements.bar[2]:SetSize(l_7_4 - 4, l_7_2 - 6)
      l_7_0._elements.bar[2]:SetRelPos(2, 3)
      l_7_0._elements.bar[3]:SetSize(1, l_7_2 / 2 - 3)
      l_7_0._elements.bar[3]:SetRelPos(2, 3)
      l_7_0._elements.bar[4]:SetSize(l_7_4 - 6, l_7_2 / 2 - 3)
      l_7_0._elements.bar[4]:SetRelPos(3, 2)
      l_7_0._elements.bar[5]:SetSize(1, l_7_2 / 2 - 3)
      l_7_0._elements.bar[5]:SetRelPos(l_7_4 - 2, 3)
      l_7_0._elements.highlight.tl:SetSize(l_7_10, l_7_11)
      l_7_0._elements.highlight.tc:SetSize(l_7_4 - 2 * l_7_10, l_7_11)
      l_7_0._elements.highlight.tc:SetRelPos(l_7_10, 0)
      l_7_0._elements.highlight.tr:SetSize(l_7_10, l_7_11)
      l_7_0._elements.highlight.tr:SetRelPos(l_7_4 - l_7_10, 0)
      l_7_0._elements.highlight.cl:SetSize(l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.highlight.cl:SetRelPos(0, l_7_11)
      l_7_0._elements.highlight.cc:SetSize(l_7_4 - 2 * l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.highlight.cc:SetRelPos(l_7_10, l_7_11)
      l_7_0._elements.highlight.cr:SetSize(l_7_10, l_7_2 - 2 * l_7_11)
      l_7_0._elements.highlight.cr:SetRelPos(l_7_4 - l_7_10, l_7_11)
      l_7_0._elements.highlight.bl:SetSize(l_7_10, l_7_11)
      l_7_0._elements.highlight.bl:SetRelPos(0, l_7_2 - l_7_11)
      l_7_0._elements.highlight.bc:SetSize(l_7_4 - 2 * l_7_10, l_7_11)
      l_7_0._elements.highlight.bc:SetRelPos(l_7_10, l_7_2 - l_7_11)
      l_7_0._elements.highlight.br:SetSize(l_7_10, l_7_11)
      l_7_0._elements.highlight.br:SetRelPos(l_7_4 - l_7_10, l_7_2 - l_7_11)
    else
      local l_7_12 = l_7_5
      local l_7_13 = l_7_6
      l_7_0._elements.shadow.tl:SetSize(l_7_12, l_7_13)
      l_7_0._elements.shadow.tc:SetSize(l_7_4 - 2 * l_7_12, l_7_13)
      l_7_0._elements.shadow.tc:SetRelPos(l_7_12, 0)
      l_7_0._elements.shadow.tr:SetSize(l_7_12, l_7_13)
      l_7_0._elements.shadow.tr:SetRelPos(l_7_4 - l_7_12, 0)
      l_7_0._elements.shadow.cl:SetSize(l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.shadow.cl:SetRelPos(0, l_7_13)
      l_7_0._elements.shadow.cc:SetSize(l_7_4 - 2 * l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.shadow.cc:SetRelPos(l_7_12, l_7_13)
      l_7_0._elements.shadow.cr:SetSize(l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.shadow.cr:SetRelPos(l_7_4 - l_7_12, l_7_13)
      l_7_0._elements.shadow.bl:SetSize(l_7_12, l_7_13)
      l_7_0._elements.shadow.bl:SetRelPos(0, l_7_2 - l_7_13)
      l_7_0._elements.shadow.bc:SetSize(l_7_4 - 2 * l_7_12, l_7_13)
      l_7_0._elements.shadow.bc:SetRelPos(l_7_12, l_7_2 - l_7_13)
      l_7_0._elements.shadow.br:SetSize(l_7_12, l_7_13)
      l_7_0._elements.shadow.br:SetRelPos(l_7_4 - l_7_12, l_7_2 - l_7_13)
      l_7_0._elements.bar[1]:SetSize(l_7_4 - 6, l_7_2 - 4)
      l_7_0._elements.bar[1]:SetRelPos(3, 2)
      l_7_0._elements.bar[2]:SetSize(l_7_4 - 4, l_7_2 - 6)
      l_7_0._elements.bar[2]:SetRelPos(2, 3)
      l_7_0._elements.bar[3]:SetSize(1, l_7_2 / 2 - 3)
      l_7_0._elements.bar[3]:SetRelPos(3, 3)
      l_7_0._elements.bar[4]:SetSize(l_7_4 - 6, l_7_2 / 2 - 3)
      l_7_0._elements.bar[4]:SetRelPos(3, 2)
      l_7_0._elements.bar[5]:SetSize(1, l_7_2 / 2 - 3)
      l_7_0._elements.bar[5]:SetRelPos(l_7_4 - 3, 3)
      l_7_0._elements.highlight.tl:SetSize(l_7_12, l_7_13)
      l_7_0._elements.highlight.tc:SetSize(l_7_4 - 2 * l_7_12, l_7_13)
      l_7_0._elements.highlight.tc:SetRelPos(l_7_12, 0)
      l_7_0._elements.highlight.tr:SetSize(l_7_12, l_7_13)
      l_7_0._elements.highlight.tr:SetRelPos(l_7_4 - l_7_12, 0)
      l_7_0._elements.highlight.cl:SetSize(l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.highlight.cl:SetRelPos(0, l_7_13)
      l_7_0._elements.highlight.cc:SetSize(l_7_4 - 2 * l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.highlight.cc:SetRelPos(l_7_12, l_7_13)
      l_7_0._elements.highlight.cr:SetSize(l_7_12, l_7_2 - 2 * l_7_13)
      l_7_0._elements.highlight.cr:SetRelPos(l_7_4 - l_7_12, l_7_13)
      l_7_0._elements.highlight.bl:SetSize(l_7_12, l_7_13)
      l_7_0._elements.highlight.bl:SetRelPos(0, l_7_2 - l_7_13)
      l_7_0._elements.highlight.bc:SetSize(l_7_4 - 2 * l_7_12, l_7_13)
      l_7_0._elements.highlight.bc:SetRelPos(l_7_12, l_7_2 - l_7_13)
      l_7_0._elements.highlight.br:SetSize(l_7_12, l_7_13)
      l_7_0._elements.highlight.br:SetRelPos(l_7_4 - l_7_12, l_7_2 - l_7_13)
    end
  elseif l_7_0.BigFoot_fe7e7fe432524db44e7e1c843fbc047e == "THIN" then
    l_7_0._elements.background:SetSize(l_7_1, l_7_2)
    l_7_0._elements.background:SetRelPos(0, 0)
    local l_7_14 = 2
    local l_7_15 = 7
    local l_7_16 = 7
    local l_7_17 = 2
    if l_7_4 < l_7_14 then
      l_7_0._elements.tl:SetSize(l_7_4, l_7_16)
      l_7_0._elements.tl:SetRelPos(0, 0)
      l_7_0._elements.tc:SetSize(0, 0)
      l_7_0._elements.tc:SetRelPos(0, 0)
      l_7_0._elements.tr:SetSize(0, 0)
      l_7_0._elements.tr:SetRelPos(0, 0)
      l_7_0._elements.cl:SetSize(l_7_4, l_7_2 - l_7_16 - l_7_17)
      l_7_0._elements.cl:SetRelPos(0, l_7_16)
      l_7_0._elements.cc:SetSize(0, 0)
      l_7_0._elements.cc:SetRelPos(0, 0)
      l_7_0._elements.cr:SetSize(0, 0)
      l_7_0._elements.cr:SetRelPos(0, 0)
      l_7_0._elements.bl:SetSize(l_7_4, l_7_17)
      l_7_0._elements.bl:SetRelPos(0, l_7_2 - l_7_17)
      l_7_0._elements.bc:SetSize(0, 0)
      l_7_0._elements.bc:SetRelPos(0, 0)
      l_7_0._elements.br:SetSize(0, 0)
      l_7_0._elements.br:SetRelPos(0, 0)
    end
  elseif l_7_4 < l_7_14 + l_7_15 then
    l_7_0._elements.tl:SetSize(l_7_14, l_7_16)
    l_7_0._elements.tl:SetRelPos(0, 0)
    l_7_0._elements.tc:SetSize(0, 0)
    l_7_0._elements.tc:SetRelPos(0, 0)
    l_7_0._elements.tr:SetSize(l_7_4 - l_7_14, l_7_16)
    l_7_0._elements.tr:SetRelPos(l_7_14, 0)
    l_7_0._elements.cl:SetSize(l_7_14, l_7_2 - l_7_16 - l_7_17)
    l_7_0._elements.cl:SetRelPos(0, l_7_16)
    l_7_0._elements.cc:SetSize(0, 0)
    l_7_0._elements.cc:SetRelPos(0, 0)
    l_7_0._elements.cr:SetSize(l_7_4 - l_7_14, l_7_2 - l_7_16 - l_7_17)
    l_7_0._elements.cr:SetRelPos(l_7_14, l_7_16)
    l_7_0._elements.bl:SetSize(l_7_14, l_7_17)
    l_7_0._elements.bl:SetRelPos(0, l_7_2 - l_7_17)
    l_7_0._elements.bc:SetSize(0, 0)
    l_7_0._elements.bc:SetRelPos(0, 0)
    l_7_0._elements.br:SetSize(l_7_4 - l_7_14, l_7_17)
    l_7_0._elements.br:SetRelPos(l_7_14, l_7_2 - l_7_17)
  else
    l_7_0._elements.tl:SetSize(l_7_14, l_7_16)
    l_7_0._elements.tl:SetRelPos(0, 0)
    l_7_0._elements.tc:SetSize(l_7_4 - l_7_14 - l_7_15, l_7_16)
    l_7_0._elements.tc:SetRelPos(l_7_14, 0)
    l_7_0._elements.tr:SetSize(l_7_15, l_7_16)
    l_7_0._elements.tr:SetRelPos(l_7_4 - l_7_15, 0)
    l_7_0._elements.cl:SetSize(l_7_14, l_7_2 - l_7_16 - l_7_17)
    l_7_0._elements.cl:SetRelPos(0, l_7_16)
    l_7_0._elements.cc:SetSize(l_7_4 - l_7_14 - l_7_15, l_7_2 - l_7_16 - l_7_17)
    l_7_0._elements.cc:SetRelPos(l_7_14, l_7_16)
    l_7_0._elements.cr:SetSize(l_7_15, l_7_2 - l_7_16 - l_7_17)
    l_7_0._elements.cr:SetRelPos(l_7_4 - l_7_15, l_7_16)
    l_7_0._elements.bl:SetSize(l_7_14, l_7_17)
    l_7_0._elements.bl:SetRelPos(0, l_7_2 - l_7_17)
    l_7_0._elements.bc:SetSize(l_7_4 - l_7_14 - l_7_15, l_7_17)
    l_7_0._elements.bc:SetRelPos(l_7_14, l_7_2 - l_7_17)
    l_7_0._elements.br:SetSize(l_7_15, l_7_17)
    l_7_0._elements.br:SetRelPos(l_7_4 - l_7_15, l_7_2 - l_7_17)
  end
  l_7_0._elements.handle:FormatAllItemPos()
  l_7_0._elements.handle:SetSizeByAllItemSize()
end


