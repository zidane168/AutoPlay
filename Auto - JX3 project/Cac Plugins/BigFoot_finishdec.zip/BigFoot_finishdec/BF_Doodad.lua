-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Doodad.lua 

if not BF_Doodad then
  BF_Doodad = {}
end
BF_Doodad.handleTotal = nil
BF_Doodad.nSteperCount = -1
BF_Doodad.frameSelf = nil
BF_Doodad.DoodadList = {}
BF_Doodad.bDoodadEnable = false
BF_Doodad.bDoodad1 = false
BF_Doodad.bDoodad2 = false
BF_Doodad.bDoodad3 = false
BF_Doodad.bDoodad4 = false
BF_Doodad.OnFrameCreate = function()
  this:RegisterEvent("DOODAD_ENTER_SCENE")
  this:RegisterEvent("DOODAD_LEAVE_SCENE")
  this:RegisterEvent("RENDER_FRAME_UPDATE")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  BF_Doodad.handleTotal = this:Lookup("", "")
  BF_Doodad.handleTotal:Clear()
end

BF_Doodad.OnEvent = function(l_2_0)
  if l_2_0 == "RENDER_FRAME_UPDATE" then
    if not BF_Doodad.bDoodadEnable then
      return 
    end
    BF_Doodad.DisplayDoodadHead()
  elseif l_2_0 == "DOODAD_ENTER_SCENE" then
    BF_Doodad.AppendDoodad(arg0)
  elseif l_2_0 == "DOODAD_LEAVE_SCENE" then
    BF_Doodad.RemoveDoodad(arg0)
  end
end

BF_Doodad.OnFrameBreathe = function()
  if not BF_Doodad.bDoodadEnable then
    return 
  end
  BF_Doodad.Steper()
  BF_Doodad.UpdateAllDoodadLable()
end

BF_Doodad.Steper = function()
  BF_Doodad.nSteperCount = BF_Doodad.nSteperCount + 1
  if BF_Doodad.nSteperCount >= 100000000 then
    BF_Doodad.nSteperCount = -1
  end
end

BF_Doodad.UpdateAllDoodadLable = function()
  for l_5_3,l_5_4 in pairs(BF_Doodad.DoodadList) do
    BF_Doodad.UpdateAnyDoodadLable(l_5_3)
  end
end

BF_Doodad.AppendDoodad = function(l_6_0)
  if not BF_Doodad.bDoodadEnable then
    return 
  end
  if not l_6_0 then
    return 
  end
  local l_6_1 = GetDoodad(l_6_0)
  if BF_Doodad.DoodadList[l_6_0] and not l_6_1 then
    BF_Doodad.RemoveDoodad(l_6_0)
  end
  return 
  if not l_6_1 or l_6_1.nKind == DOODAD_KIND.CORPSE then
    return 
  end
  local l_6_2 = BF_Doodad.DoodadList
  local l_6_3 = {}
  l_6_3.dwID = l_6_0
  l_6_3.szName = l_6_1.szName
  l_6_3.szTopHead = l_6_1.szName
  l_6_3.nDistance = 0
  l_6_3.nCameraDistance = 0
  l_6_2[l_6_0] = l_6_3
  l_6_2 = BF_Doodad
  l_6_2 = l_6_2.handleTotal
  l_6_2, l_6_3 = l_6_2:Lookup, l_6_2
  l_6_2 = l_6_2(l_6_3, "Handle_Label_" .. l_6_0)
  if not l_6_2 then
    l_6_3 = BF_Doodad
    l_6_3 = l_6_3.handleTotal
     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_2 = l_6_3
    l_6_2.dwDoodadID = l_6_0
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_2.textLable = l_6_3
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_3(l_6_3, 40)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_6_3.handleLabel = l_6_2
  end
end

BF_Doodad.RemoveDoodad = function(l_7_0)
  if not BF_Doodad.bDoodadEnable then
    return 
  end
  if not l_7_0 or not BF_Doodad.DoodadList[l_7_0] then
    return 
  end
  local l_7_1 = BF_Doodad.handleTotal:Lookup("Handle_Label_" .. l_7_0)
  if l_7_1 then
    BF_Doodad.handleTotal:RemoveItem(l_7_1)
  end
  BF_Doodad.DoodadList[l_7_0] = nil
end

BF_Doodad.DisplayDoodadHead = function()
  local l_8_0 = GetClientPlayer()
  if not l_8_0 then
    return 
  end
  for l_8_4,l_8_5 in pairs(BF_Doodad.DoodadList) do
    local l_8_6 = GetDoodad(l_8_4)
    if not l_8_6 then
      BF_Doodad.RemoveDoodad(l_8_4)
    end
    local l_8_7 = 196
    local l_8_8 = 64
    local l_8_9 = 255
    local l_8_10 = math.floor(l_8_0.nX - l_8_6.nX ^ 2 + l_8_0.nY - l_8_6.nY ^ 2 ^ 0.5)
    local l_8_11 = l_8_10 * -0.001
    local l_8_12 = 0
    local l_8_13, l_8_14, l_8_15 = Scene_GameWorldPositionToScenePosition(l_8_6.nX, l_8_6.nY, l_8_6.nZ, 0)
    local l_8_16 = 0
    local l_8_17 = 0
    local l_8_18 = false
    if l_8_13 and l_8_14 and l_8_15 then
      l_8_16 = Scene_ScenePointToScreenPoint(l_8_13, l_8_14 - l_8_12, l_8_15)
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_8_18 then
      l_8_16 = Station.AdjustToOriginalPos(l_8_16, l_8_17)
    elseif l_8_5.handleLabel then
      l_8_5.handleLabel:SetAbsPos(-4096, -4096)
    end
    if l_8_18 then
      if BF_Doodad.nSteperCount % 4 == 0 or BF_Doodad.DoodadList[l_8_4].nCameraDistance == 0 then
        BF_Doodad.DoodadList[l_8_4].nCameraDistance = math.floor(l_8_0.nX - l_8_6.nX ^ 2 + l_8_0.nY - l_8_6.nY ^ 2 + l_8_0.nZ / 8 - l_8_6.nZ / 8 ^ 2 ^ 0.5)
      end
      local l_8_19 = BF_Doodad.DoodadList[l_8_4].nCameraDistance
      local l_8_20 = l_8_5.handleLabel
      local l_8_21 = nil
      if l_8_20 then
        l_8_21 = l_8_20.textLable
        local l_8_22, l_8_23 = l_8_21:GetSize()
        local l_8_24 = math.ceil(l_8_16 - l_8_22 / 2) - 8
        local l_8_25 = math.floor(l_8_17 - l_8_23 / 2) - 80
        l_8_20:SetAbsPos(l_8_24, l_8_25)
        l_8_21:Show()
        l_8_20:SetUserData(-l_8_19)
      end
      local l_8_26 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_8_21 and 16.nSteperCount % 2 == 0 then
        if l_8_19 < 800 then
          l_8_21:SetFontScheme(40)
          l_8_21:SetFontScale(1)
        end
      elseif l_8_19 < 1600 then
        l_8_21:SetFontScheme(l_8_26[2])
        l_8_21:SetFontScale(1)
      elseif l_8_19 < 2400 then
        l_8_21:SetFontScheme(l_8_26[1])
        l_8_21:SetFontScale(1)
      else
        local l_8_27 = l_8_19 - 2400
        if 1 - l_8_27 / 4000 <= 0.7 then
          local l_8_28, l_8_29, l_8_30 = 0.7
        end
        l_8_21:SetFontScheme(l_8_26[1])
         -- DECOMPILER ERROR: Confused about usage of registers!

        l_8_21:SetFontScale(l_8_28)
      end
      local l_8_31 = true
      if l_8_31 and (l_8_19 - 900 > 0 or 210 - math.floor(0 / 50) <= 0) then
        local l_8_32, l_8_33, l_8_34, l_8_35 = 0
      end
    end
    if l_8_21 then
      l_8_21:SetAlpha(210)
      l_8_21:SetFontColor(l_8_7, l_8_8, l_8_9)
    end
  end
  if BF_Doodad.nSteperCount % 16 == 0 then
    BF_Doodad.handleTotal:Sort()
  end
end

BF_Doodad.UpdateAnyDoodadLable = function(l_9_0)
  local l_9_1 = BF_Doodad.DoodadList[l_9_0]
  local l_9_2 = GetDoodad(l_9_0)
  if not l_9_2 and l_9_1 then
    BF_Doodad.RemoveDoodad(l_9_0)
  end
  return 
  if not l_9_1 then
    BF_Doodad.AppendDoodad(l_9_0)
    return 
  end
  if not l_9_1.handleLabel then
    return 
  end
  l_9_1.szName = l_9_2.szName
  local l_9_3 = GetDoodadTemplate(l_9_2.dwTemplateID)
  l_9_1.szTopHead = ""
  if BF_Doodad.bDoodad1 and l_9_3.dwCraftID == 1 then
    l_9_1.szTopHead = l_9_1.szName
  else
    if BF_Doodad.bDoodad2 and l_9_3.dwCraftID == 2 then
      l_9_1.szTopHead = l_9_1.szName
    end
  else
    if BF_Doodad.bDoodad3 and l_9_3.dwCraftID == 12 then
      l_9_1.szTopHead = l_9_1.szName
    end
  else
    if BF_Doodad.bDoodad4 and l_9_3.dwCraftID ~= 1 and l_9_3.dwCraftID ~= 2 and l_9_3.dwCraftID ~= 12 then
      l_9_1.szTopHead = l_9_1.szName
    end
  end
  if not BF_Doodad.bDoodadEnable then
    l_9_1.szTopHead = ""
  end
  l_9_1.handleLabel.textLable:SetText(l_9_1.szTopHead)
end

Wnd.OpenWindow("Interface\\BF_Loot\\BF_Doodad.ini", "BF_Doodad")
BFConfigPanel.RegisterMod("Wawale", "�ɼ�����", "\\ui\\image\\icon\\medic07.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("Wawale", "bDoodadEnable", "���������������������ʾ", true, function(l_10_0, l_10_1)
  BF_Doodad.bDoodadEnable = l_10_0
end
)
BFConfigPanel.RegisterCheckButton("Wawale", "bDoodad1", "��ʾ��ʯ", false, function(l_11_0, l_11_1)
  BF_Doodad.bDoodad1 = l_11_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Wawale", "bDoodad2", "��ʾ��ҩ", false, function(l_12_0, l_12_1)
  BF_Doodad.bDoodad2 = l_12_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Wawale", "bDoodad3", "��ʾ����", false, function(l_13_0, l_13_1)
  BF_Doodad.bDoodad3 = l_13_0
end
, 2)
BFConfigPanel.RegisterCheckButton("Wawale", "bDoodad4", "��ʾ���������������·�ƣ�", false, function(l_14_0, l_14_1)
  BF_Doodad.bDoodad4 = l_14_0
end
, 2)

