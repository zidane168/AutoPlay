-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: label.lua 

BFLabel = classv2(BFWidget)
BFLabel.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4)
  local l_1_5 = assert
  l_1_5(l_1_2 >= 0 and l_1_3 >= 0, "Invalid widget size.")
  l_1_5(l_1_0, l_1_4, l_1_2, l_1_3)
   -- DECOMPILER ERROR: Overwrote pending register.

  l_1_5(l_1_0, l_1_1)
end

BFLabel.Create = function(l_2_0, l_2_1, l_2_2, l_2_3)
  local l_2_4 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\label.ini", l_2_0:GetName())
  local l_2_5 = l_2_4:Lookup("Wnd_Main")
  assert(l_2_5, "Failed to create label widget.")
  l_2_0:SetContainer(l_2_5)
  if l_2_1 then
    l_2_0:SetText(l_2_1)
  end
  l_2_0:SetSize(l_2_2, l_2_3)
end

BFLabel.SetText = function(l_3_0, l_3_1)
  local l_3_2 = l_3_0:GetContainer()
  local l_3_3 = l_3_2:Lookup("", "")
  local l_3_4 = l_3_3:Lookup("Text_Main")
  l_3_4:SetText(l_3_1)
end

BFLabel.SetTextColor = function(l_4_0, l_4_1, l_4_2, l_4_3)
  local l_4_4 = l_4_0:GetContainer()
  local l_4_5 = l_4_4:Lookup("", "")
  local l_4_6 = l_4_5:Lookup("Text_Main")
  l_4_0.BigFoot_3ae1f2c4b38d5f7c356b4cdb7c6e4027 = l_4_1
  l_4_0.BigFoot_0f402d7ba502a47a51c410aee99b1ff1 = l_4_2
  l_4_0.BigFoot_a0a053cacf1c8c43346fdc3adb684cb7 = l_4_3
  l_4_6:SetFontColor(l_4_1, l_4_2, l_4_3)
end

BFLabel.Enable = function(l_5_0)
  local l_5_1 = l_5_0:GetContainer()
  local l_5_2 = l_5_1:Lookup("", "")
  local l_5_3 = l_5_2:Lookup("Text_Main")
  if l_5_0.BigFoot_3ae1f2c4b38d5f7c356b4cdb7c6e4027 and l_5_0.BigFoot_0f402d7ba502a47a51c410aee99b1ff1 and l_5_0.BigFoot_a0a053cacf1c8c43346fdc3adb684cb7 then
    l_5_3:SetFontColor(l_5_0.BigFoot_3ae1f2c4b38d5f7c356b4cdb7c6e4027, l_5_0.BigFoot_0f402d7ba502a47a51c410aee99b1ff1, l_5_0.BigFoot_a0a053cacf1c8c43346fdc3adb684cb7)
  else
    l_5_3:SetFontColor(255, 255, 255)
  end
end

BFLabel.Disable = function(l_6_0)
  local l_6_1 = l_6_0:GetContainer()
  local l_6_2 = l_6_1:Lookup("", "")
  local l_6_3 = l_6_2:Lookup("Text_Main")
  l_6_3:SetFontColor(192, 192, 192)
end

BFLabel.SetFontScheme = function(l_7_0, l_7_1)
  local l_7_2 = l_7_0:GetContainer()
  local l_7_3 = l_7_2:Lookup("", "")
  local l_7_4 = l_7_3:Lookup("Text_Main")
  l_7_4:SetFontScheme(l_7_1)
end

BFLabel.SetFontBorder = function(l_8_0, l_8_1, l_8_2, l_8_3, l_8_4)
  local l_8_5 = l_8_0:GetContainer()
  local l_8_6 = l_8_5:Lookup("", "")
  local l_8_7 = l_8_6:Lookup("Text_Main")
  l_8_7:SetFontBorder(l_8_1, l_8_2, l_8_3, l_8_4)
end

BFLabel.SetFontScale = function(l_9_0, l_9_1)
  local l_9_2 = l_9_0:GetContainer()
  local l_9_3 = l_9_2:Lookup("", "")
  local l_9_4 = l_9_3:Lookup("Text_Main")
  l_9_4:SetFontScale(l_9_1)
end

BFLabel.SetHAlign = function(l_10_0, l_10_1)
  local l_10_2 = l_10_0:GetContainer()
  local l_10_3 = l_10_2:Lookup("", "")
  local l_10_4 = l_10_3:Lookup("Text_Main")
  if l_10_1 == "LEFT" then
    l_10_4:SetHAlign(0)
  elseif l_10_1 == "RIGHT" then
    l_10_4:SetHAlign(2)
  elseif l_10_1 == "CENTER" then
    l_10_4:SetHAlign(1)
  end
end

BFLabel.SetVAlign = function(l_11_0, l_11_1)
  local l_11_2 = l_11_0:GetContainer()
  local l_11_3 = l_11_2:Lookup("", "")
  local l_11_4 = l_11_3:Lookup("Text_Main")
  if l_11_1 == "TOP" then
    l_11_4:SetVAlign(0)
  elseif l_11_1 == "BOTTOM" then
    l_11_4:SetVAlign(2)
  elseif l_11_1 == "CENTER" then
    l_11_4:SetVAlign(1)
  end
end

BFLabel.GetTextExtent = function(l_12_0)
  local l_12_1 = l_12_0:GetContainer()
  local l_12_2 = l_12_1:Lookup("", "")
  local l_12_3 = l_12_2:Lookup("Text_Main")
  local l_12_4, l_12_5 = l_12_3:GetTextExtent, l_12_3
  return l_12_4(l_12_5)
end

BFLabel.GetText = function(l_13_0)
  local l_13_1 = l_13_0:GetContainer()
  local l_13_2 = l_13_1:Lookup("", "")
  local l_13_3 = l_13_2:Lookup("Text_Main")
  local l_13_4, l_13_5 = l_13_3:GetText, l_13_3
  local l_13_6 = BigFoot_e6955c64cf39bdb23dc86de1a9ec2117
  return l_13_4(l_13_5, l_13_6)
end

BFLabel._UpdateContent = function(l_14_0)
  local l_14_1 = l_14_0:GetContainer()
  local l_14_2 = l_14_1:Lookup("", "")
  local l_14_3 = l_14_2:Lookup("Text_Main")
  local l_14_4 = l_14_0:GetWidth()
  local l_14_5 = l_14_0:GetHeight()
  l_14_3:SetSize(l_14_4, l_14_5)
end


