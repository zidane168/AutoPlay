-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: SellerHelper.lua 

SellerHelper = {}
SellerHelper_Config = {}
SellerHelper.GetMoneyString = function(l_1_0)
  local l_1_1, l_1_2, l_1_3 = MoneyToGoldSilverAndCopper(l_1_0)
  local l_1_4 = ""
  if l_1_1 > 0 then
    l_1_4 = l_1_4 .. l_1_1 .. "��"
  end
  if l_1_2 > 0 then
    l_1_4 = l_1_4 .. l_1_2 .. "��"
  end
  if l_1_3 > 0 then
    l_1_4 = l_1_4 .. l_1_3 .. "ͭ"
  end
  return l_1_4
end

GetItemNameByItem = function(l_2_0)
  if l_2_0.nGenre == ITEM_GENRE.BOOK then
    local l_2_1, l_2_2 = GlobelRecipeID2BookID(l_2_0.nBookID)
    local l_2_6 = Table_GetSegmentName
    local l_2_7 = l_2_1
    l_2_6 = l_2_6(l_2_7, l_2_2)
    if not l_2_6 then
      l_2_6 = g_tStrings
      l_2_6 = l_2_6.BOOK
      local l_2_5 = nil
    end
    return l_2_6
  else
    local l_2_3 = Table_GetItemName
    local l_2_4 = l_2_0.nUiId
    return l_2_3(l_2_4)
  end
end

SellerHelper.SellAllGrayItems = function(l_3_0, l_3_1, l_3_2, l_3_3, l_3_4, l_3_5, ...)
  local l_3_7 = nil
  for l_3_11 = 1, 5 do
    local l_3_8, l_3_9 = nil, GetClientPlayer()
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_3_9.GetBoxSize(R13_PC7) and l_3_9.GetBoxSize(R13_PC7) > 0 then
      for l_3_16 = 0, l_3_9.GetBoxSize(R13_PC7) do
        local l_3_14 = nil
         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_3_9.GetItem(l_3_13, R18_PC19) and l_3_9.GetItem(l_3_13, R18_PC19).nQuality < 1 then
          local l_3_19 = nil
          local l_3_20 = GetItemNameByItem(l_3_9.GetItem(l_3_13, R18_PC19))
          SellItem(l_3_4, l_3_0, l_3_13, l_3_18, l_3_19.nStackNum)
        end
      end
    end
  end
   -- WARNING: undefined locals caused missing assignments!
end

RegisterEvent("SHOP_OPENSHOP", function()
  if SellerHelper_Config.BigFoot_0c345c7377bbb51d0103c6066140675a then
    SellerHelper.SellAllGrayItems(arg0, arg1, arg2, arg3, arg4)
  end
end
)
BFConfigPanel.RegisterMod("SellerHelper", "��������", "\\ui\\image\\icon\\coin01.tga", "BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
BFConfigPanel.RegisterCheckButton("SellerHelper", "SellGrayItems", "�Զ�������ɫ��Ʒ", true, function(l_5_0)
  if l_5_0 then
    SellerHelper_Config.BigFoot_0c345c7377bbb51d0103c6066140675a = true
  else
    SellerHelper_Config.BigFoot_0c345c7377bbb51d0103c6066140675a = false
  end
end
)

