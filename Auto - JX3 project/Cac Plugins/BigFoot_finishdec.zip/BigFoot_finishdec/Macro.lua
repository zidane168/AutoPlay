-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Macro.lua 

MacroFrame = {}
MacroFrame.bchange = false
MacroFrame.nDiLeiNumber = 0
MacroFrame.MacroTable = {}
MacroFrame.MacroNumber = 0
local l_0_0 = MacroFrame
local l_0_1 = {}
 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

local l_0_2 = {}
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

RegisterEvent("DO_SKILL_CAST", ":")
MacroFrame.IsSelfMarco = function(l_72_0)
  if string.find(l_72_0, "skill") then
    return true
  end
  return false
end

MacroFrame.SaveMacroFrame = function()
  local l_73_0 = Station.Lookup("Topmost/MacroSettingPanel")
  if l_73_0 then
    local l_73_1 = 1
    if GetMacroName(l_73_1) ~= "" then
      l_73_0.dwID = l_73_1
      MacroSettingPanel.UpdateSelect(l_73_0)
      local l_73_2 = l_73_0:Lookup("Edit_Content"):GetText()
      if MacroFrame.IsSelfMarco(l_73_2) then
        local l_73_3 = table.insert
        local l_73_4 = MacroFrame.MacroTable
        local l_73_5 = {}
        l_73_5.MacroNUmber = l_73_1
        l_73_5.szContent = l_73_2
        l_73_3(l_73_4, l_73_5)
      end
      l_73_1 = l_73_1 + 1
    end
  end
  MacroFrame.MacroNUmber = l_73_1 - 1
end
end

MacroFrame.SetMacroText = function()
  if #MacroFrame.MacroTable > 0 then
    local l_74_0 = Station.Lookup("Topmost/MacroSettingPanel")
    for l_74_4,l_74_5 in pairs(MacroFrame.MacroTable) do
      local l_74_6 = l_74_5.MacroNUmber
      local l_74_7 = l_74_5.szContent
      if l_74_6 and l_74_7 then
        local l_74_8 = MacroFrame.GetCurrentSkill(l_74_7)
      end
      if l_74_8 ~= "" then
        l_74_0.dwID = l_74_6
        MacroSettingPanel.UpdateSelect(l_74_0)
        l_74_0:Lookup("Edit_Content"):SetText("/cast " .. l_74_8)
        MacroSettingPanel.ChangeMacro(l_74_0)
      end
    end
  end
  l_74_0 = BigFoot_DelayCall
  l_74_0(MacroFrame.SetMacroText, 1000)
end

MacroFrame.GetCurrentSkill = function(l_75_0)
  local l_75_1 = ""
  string.gsub(l_75_0, "%/.+%s(.+)", function(l_76_0)
    -- upvalues: l_75_1
    l_75_1 = l_76_0
  end)
  return l_75_1
end

MacroFrame.Checkconditions = function(l_76_0)
  local l_76_1 = false
  l_76_0 = l_76_0 .. ";"
  for l_76_5 in string.gmatch(l_76_0, ".-;") do
    local l_76_6 = string.sub(l_76_5, 0, -2)
    local l_76_7 = true
    l_76_6 = l_76_6 .. ","
    for l_76_11 in string.gmatch(l_76_6, ".-,") do
      local l_76_12 = string.sub(l_76_11, 0, -2)
      if not MacroFrame.CheckSth(l_76_12) then
        l_76_7 = false
      end
    end
    if l_76_7 then
      l_76_1 = true
    end
  end
  return l_76_1
end

MacroFrame.CheckSth = function(l_77_0)
  local l_77_1, l_77_2, l_77_7, l_77_14 = nil, nil
  do
  end
  for l_77_6,i_2 in pairs(MacroFrame.symbols) do
    local l_77_3 = false
    if string.find(l_77_0, i_2) then
      l_77_1 = string.sub(l_77_0, 0, string.find(l_77_0, i_2) - 1)
      l_77_2 = string.sub(l_77_0, string.find(l_77_0, i_2), -1)
    end
  end
  if not l_77_1 then
    l_77_1 = l_77_0
  end
  for l_77_11,l_77_12 in pairs(MacroFrame.kindsList) do
    local l_77_8 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_77_12 == l_77_1 and type(i_2) == "function" then
      pcall(function()
      -- upvalues: l_77_3 , l_77_8 , l_77_2
      l_77_3 = l_77_8(l_77_2)
    end)
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  return l_77_8
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

MarcrSkillfun = function(l_78_0, l_78_1)
  -- upvalues: l_0_2
  local l_78_2, l_78_3, l_78_4, l_78_5 = string.find(l_78_0, "%s*[[](.+)[]]%s*(.+)")
  do
    local l_78_6 = false
    if l_78_4 and l_78_5 then
      l_78_6 = true
    else
      l_78_6 = false
    end
    if not l_78_5 then
      l_78_5 = l_78_0
    end
    if not l_78_4 then
      l_78_4 = ""
    end
    if l_0_2 ~= "" then
      if l_78_4 ~= "" then
        l_78_4 = l_0_2 .. "," .. l_78_4
      else
        l_78_4 = l_0_2
        l_78_6 = true
      end
      if l_78_6 and MacroFrame.Checkconditions(l_78_4) then
        local l_78_7 = BF_GetSkillIDByName(l_78_5)
      end
      if l_78_7 then
        local l_78_8 = BF_UseSkill
        local l_78_9 = l_78_7
        return l_78_8(l_78_9)
      end
      end
      return true
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- WARNING: missing end command somewhere! Added here
  end
end

ProtectChannelCasting = function(l_79_0)
  -- upvalues: l_0_1 , l_0_2
  do
    local l_79_1, l_79_2, l_79_3, l_79_4 = string.find(l_79_0, "%s*[[](.+)[]]%s*(.+)")
    if l_79_3 and l_79_4 then
      if MacroFrame.Checkconditions(l_79_3) and string.find(l_79_4, "��������") then
        l_0_1 = true
      else
        if MacroFrame.Checkconditions(l_79_3) and string.find(l_79_4, "����������") then
          l_0_1 = false
        end
      else
        if string.find(l_79_0, "��������") then
          l_0_1 = true
        end
      else
        if string.find(l_79_0, "����������") then
          l_0_1 = false
        end
      else
        l_79_1 = l_79_0:find("before:")
        local l_79_5 = ""
      end
      if l_79_1 then
        l_79_5 = l_79_0:sub(l_79_2 + 1, -1)
        if l_79_5 == "null" then
          l_0_2 = ""
        end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_79_1 = l_79_5:find("%[(.-)%]")
      end
      if l_79_1 then
        l_0_2 = l_79_3
      end
      return true
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

m_GetPureMacro = function(l_80_0)
  local l_80_1 = ""
  l_80_0 = "\n" .. l_80_0
  local l_80_2, l_80_3 = StringFindW(l_80_0, "\n#")
  if l_80_2 then
    l_80_1 = l_80_1 .. string.sub(l_80_0, 1, l_80_2 - 1)
    l_80_0 = string.sub(l_80_0, l_80_3, -1)
    l_80_2 = StringFindW(l_80_0, "\n#")
    local l_80_4 = StringFindW(l_80_0, "\n/")
     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_80_2 or l_80_4 and l_80_4 < l_80_2 then
      l_80_2 = l_80_4
    end
    if l_80_2 then
      l_80_0 = string.sub(l_80_0, l_80_2, -1)
    else
      l_80_0 = ""
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    l_80_2 = StringFindW(l_80_0, "\n#")
  end
end
l_80_1 = l_80_1 .. l_80_0
return l_80_1
end

m_GetCommand = function(l_81_0)
  local l_81_1, l_81_2 = nil, nil
  if StringFindW(l_81_0, "\n/") then
    l_81_1 = string.sub(l_81_0, 1, StringFindW(l_81_0, "\n/") - 1)
    l_81_2 = string.sub(l_81_0, R7_PC18, -1)
  else
    l_81_1 = l_81_0
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if string.sub(l_81_1, R7_PC18, -1) == "\n" then
    l_81_1 = string.sub(l_81_1, R7_PC18, -2)
  end
end
return l_81_1, l_81_2
end

Macro_Text = function(l_82_0)
  local l_82_1 = ""
  local l_82_2 = l_82_0
  while 1 do
    l_82_1 = GetCommand(l_82_2)
    if l_82_1 ~= "" or l_82_2 == "" then
      do break end
    end
    do return end
  end
end

m_ProcessCommand = function(l_83_0, l_83_1)
  local l_83_2, l_83_3 = nil, nil
  if StringFindW(l_83_0, " ") then
    i = StringFindW(l_83_0, " ")
  end
  if i then
    l_83_2 = string.sub(l_83_0, 1, i - 1)
    l_83_3 = string.sub(l_83_0, i + 1, -1)
    l_83_0 = l_83_2 .. l_83_3
    i = StringFindW(l_83_0, " ")
  end
end
l_83_2 = StringLowerW(l_83_0)
return l_83_0, l_83_3, l_83_1
end

AppendCommand("skill", MarcrSkillfun)
AppendCommand("config", ProtectChannelCasting)
GetCondition = function(l_84_0)
  local l_84_1 = ""
  local l_84_2 = ""
  local l_84_3 = StringFindW(l_84_0, "[")
  if l_84_3 then
    l_84_0 = string.sub(l_84_0, l_84_3 + 1, -1)
    l_84_3 = StringFindW(l_84_0, "]")
    if l_84_3 then
      l_84_1 = string.sub(l_84_0, l_84_3 + 1, -1)
      l_84_2 = string.sub(l_84_0, 1, l_84_3 - 1)
    end
  else
    l_84_1 = l_84_0
  end
  return l_84_2, l_84_1
end

BF_GetAllSkillName = function()
  local l_85_0 = GetClientPlayer()
  if not l_85_0 then
    return 
  end
  local l_85_1, l_85_2 = nil, nil
  ALLSkillTab = {}
  local l_85_3, l_85_4, l_85_5, l_85_6 = nil, nil, nil, nil
  for l_85_10 = 0, 10 do
    l_85_6 = g_tTable.SchoolSkill:Search(l_85_10)
    l_85_5 = nil
    l_85_2 = {}
    if l_85_6 and l_85_6.szSkill then
      local l_85_11 = l_85_6.szSkill
      for l_85_15 in string.gmatch(l_85_11, "%d+") do
        local l_85_16 = tonumber(l_85_15)
        l_85_2[l_85_16] = not l_85_16 or l_85_0.GetSkillLevel(l_85_16) or 0
      end
    end
    l_85_11 = l_85_0.GetKungfuList
    l_85_11 = l_85_11(l_85_10)
    l_85_4 = l_85_11
    if l_85_4 then
      l_85_11 = pairs
      l_85_11 = l_85_11(l_85_4)
      for l_85_20,l_85_21 in l_85_11 do
        local l_85_21 = nil
        l_85_2[l_85_19] = l_85_20
      end
    end
    do break end
    do
      local l_85_22, l_85_23, l_85_24, l_85_25, l_85_26 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_85_5 and l_85_26 then
        local l_85_27 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for l_85_31 in l_85_27 do
          local l_85_31 = nil
           -- DECOMPILER ERROR: Overwrote pending register.

          do
            local l_85_32 = nil
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

        end
        if l_85_31 and l_85_3 ~= "" then
          end
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_85_33 = nil
        if l_85_26 then
          for l_85_37,l_85_38 in pairs(l_85_33) do
            do
              local l_85_37, l_85_38 = l_85_32
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

          end
          if l_85_35 and l_85_37 == "number" and l_85_3 ~= "" then
            end
             -- DECOMPILER ERROR: Confused about usage of registers for local variables.

          end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 98 125 
end

BF_CheckSkillTab = function()
  local l_86_0 = 0
  for l_86_4,l_86_5 in pairs(ALLSkillTab) do
    l_86_0 = l_86_0 + 1
  end
  return l_86_0
end

BF_Macro_GetUseSkillID = function(l_87_0)
  local l_87_1 = GetClientPlayer().GetKungfuMount()
  if l_87_0 == "��" or l_87_0 == "����" then
    return 9007, GetClientPlayer().GetSkillLevel(9007)
  end
  if l_87_0 == "�巽�о�" then
    return 2674, GetClientPlayer().GetSkillLevel(2674)
  end
  if l_87_0 == "��������" then
    return 2690, GetClientPlayer().GetSkillLevel(2690)
  end
  if l_87_1.dwSkillID == 10176 or l_87_1.dwSkillID == 10175 then
    if l_87_0 == "����" then
      return 2442, 1
    end
    if l_87_0 == "Ы��" then
      return 2475, 1
    end
    if l_87_0 == "���" then
      return 2476, 1
    end
    if l_87_0 == "�û�" then
      return 2477, 1
    end
    if l_87_0 == "Ӱ��" then
      return 2478, 1
    end
    if l_87_0 == "˿ǣ" then
      return 2479, 1
    end
  elseif l_87_1.dwSkillID == 10225 then
    if l_87_0 == "����" then
      return 3368, 1
    end
    if l_87_0 == "����" then
      return 3369, 1
    end
    if l_87_0 == "��ɲ" then
      return 3370, 1
    end
    if l_87_0 == "����" then
      return 3360, 1
    end
  end
  if l_87_0 == "ֹͣ" then
    return 3382, 1
  end
  local l_87_2 = GetClientPlayer().GetAllSkillList()
  if l_87_2 then
    for l_87_6,l_87_7 in pairs(l_87_2) do
      local l_87_8 = Table_GetSkillName(l_87_6, l_87_7)
      if tostring(l_87_8) == tostring(l_87_0) then
        return l_87_6, l_87_7
      end
    end
  end
end

BF_GetSkillIDByName = function(l_88_0)
  local l_88_1 = nil
  l_88_0 = m_ProcessCommand(l_88_0)
  if l_88_0 then
    if tonumber(l_88_0) then
      l_88_1 = tonumber(l_88_0)
    end
  else
    if BF_CheckSkillTab() == 0 then
      BF_GetAllSkillName()
    end
    if ALLSkillTab[l_88_0] then
      l_88_1 = ALLSkillTab[l_88_0]
    else
      l_88_1 = BF_Macro_GetUseSkillID(l_88_0)
    end
  end
  if l_88_0 == "��" then
    l_88_1 = -1
  end
  return l_88_1
end

BF_UseSkill = function(l_89_0, l_89_1)
  -- upvalues: l_0_1 , l_0_0
  local l_89_2 = GetClientPlayer()
  local l_89_3, l_89_4, l_89_5 = l_89_2.GetSkillCDProgress(l_89_0, 1)
  if l_89_3 and l_89_5 > 0 then
    return true
  end
  if not BF_IsChannelCasting() or not l_0_1 then
    if not l_89_1 then
      l_89_1 = 1
    end
    local l_89_6, l_89_7 = l_89_2.GetTarget()
  if l_89_6 and l_89_6 == 4 then
    end
  elseif l_89_0 == -1 then
    Jump()
  else
    OnAddOnUseSkill(l_89_0, 1)
    if l_0_0[l_89_0] and l_0_1 then
      return false
    end
    return true
  end
  return true
end

BF_IsChannelCasting = function()
  if GetClientPlayer().GetOTActionState() == 2 then
    return true
  end
end

local l_0_3 = UserSelect.SelectPoint
UserSelect.SelectPoint = function(l_91_0, l_91_1, l_91_2, l_91_3)
  -- upvalues: l_0_3
  local l_91_9 = nil
  if not MacroFrame.bArea then
    local l_91_4 = l_0_3
    local l_91_5 = l_91_0
    local l_91_6 = l_91_1
    local l_91_7 = l_91_2
    local l_91_8 = l_91_3
    return l_91_4(l_91_5, l_91_6, l_91_7, l_91_8)
  end
  l_0_3(l_91_0, l_91_1, l_91_2, l_91_3)
  local l_91_10 = GetTargetHandle(GetClientPlayer().GetTarget())
  if l_91_10 then
    x = l_91_10.nX
    y = l_91_10.nY
    z = l_91_10.nZ
  else
    local l_91_11 = l_0_3
    local l_91_12 = l_91_0
    local l_91_13 = l_91_1
    local l_91_14 = l_91_2
    local l_91_15 = l_91_3
    return l_91_11(l_91_12, l_91_13, l_91_14, l_91_15)
  end
  UserSelect.DoSelectPoint(x, y, z)
end

BFConfigPanel.RegisterMod("Macro", "��ź�", "\\ui\\image\\icon\\DropItemNew03.tga", "dajiaohong")
BFConfigPanel.RegisterCheckButton("Macro", "EnableMacro", "���ô�ź���չ", true, function(l_92_0)
  MacroFrame.enabled = l_92_0
  BigFoot_DelayCall(BF_GetAllSkillName, 1500)
end
)
BFConfigPanel.RegisterCheckButton("Macro", "bArea", "���÷�Χ������ǿ", false, function(l_93_0)
  MacroFrame.bArea = l_93_0
end
)

