-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: RaidGrid_EventScrutiny.lua 

RaidGrid_Base = {}
RaidGrid_Base.version = 1
RegisterCustomData("RaidGrid_Base.version")
local l_0_0 = RaidGrid_Base
local l_0_1 = {}
l_0_1.NONE = 1
l_0_1.PREPARE = 2
l_0_1.DONE = 3
l_0_1.BREAK = 4
l_0_1.FADE = 5
l_0_0.lz_ACTION_STATE = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  if HideTip then
    HideTip()
  end
end

l_0_0.HideTip = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_2_0, l_2_1)
  if Station then
    if Station.AdjustToOriginalPos then
      local l_2_2 = Station.AdjustToOriginalPos
      local l_2_3 = l_2_0
      local l_2_4 = l_2_1
      return l_2_2(l_2_3, l_2_4)
    end
  else
    if Station.GetUIScale then
      local l_2_5 = Station.GetUIScale()
      return l_2_0 / l_2_5, l_2_1 / l_2_5
    end
  end
  return l_2_0, l_2_1
end

l_0_0.AdjustToOriginalPos = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_3_0)
  if GetNpcIntensity then
    local l_3_1 = GetNpcIntensity
    local l_3_2 = l_3_0
    return l_3_1(l_3_2)
  elseif not l_3_0 then
    return 1
  end
  local l_3_3 = l_3_0.nIntensity
  if not l_3_3 then
    return 4
  end
  if l_3_3 == 2 or l_3_3 == 6 then
    return 4
  elseif l_3_3 == 5 then
    return 3
  elseif l_3_3 == 4 then
    return 2
  end
  return 1
end

l_0_0.ToGetNpcIntensity = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_4_0)
  local l_4_1 = GetClientPlayer()
  if not l_4_1 then
    return 
  end
  local l_4_2 = TARGET.NPC
  if not l_4_0 or l_4_0 <= 0 then
    l_4_2 = TARGET.NO_TARGET
    l_4_0 = 0
  else
    if IsPlayer(l_4_0) then
      l_4_2 = TARGET.PLAYER
    end
  end
  if SetTarget then
    local l_4_3 = arg0
    local l_4_4 = arg1
    SetTarget(l_4_2, l_4_0)
    arg0 = l_4_3
  elseif SelectTarget then
    SelectTarget(l_4_2, l_4_0)
  end
end

l_0_0.SetTarget = l_0_1
l_0_0 = RaidGrid_Base
l_0_0.tSound, l_0_1 = l_0_1, {enemy = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\enemy.wav", reading = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\reading.wav", QILI = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\QILI.wav", self = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\self.wav", haha = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\haha.wav", ["ע��Ѫ��"] = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\checkhp.wav", ["����"] = "\\Interface\\RaidGrid_EventScrutiny\\Sound\\justrun.wav", ["���ҡ"] = "Interface//RaidGrid_EventScrutiny//Sound//KUAIFUYAO.wav", ["����ɢ"] = "Interface//RaidGrid_EventScrutiny//Sound//KUAIQUSAN.wav", ["���ʩ��"] = "Interface//RaidGrid_EventScrutiny//Sound//DADUANSHIFA.wav", ["������Ⱥ"] = "Interface//RaidGrid_EventScrutiny//Sound//PAOLIRENQUN.wav", ["ֹͣʩ��"] = "Interface//RaidGrid_EventScrutiny//Sound//TINGZISHIFA.wav", ["ֹͣ���"] = "Interface//RaidGrid_EventScrutiny//Sound//TINGZISHUC.wav", ["ע������"] = "Interface//RaidGrid_EventScrutiny//Sound//ZHUYIZHIL.wav"}
l_0_0 = RaidGrid_Base
l_0_1 = function(l_5_0)
  if not RaidGrid_EventScrutiny or not RaidGrid_EventCache then
    return 
  end
  if not l_5_0 and RaidGrid_Base.version == 2 then
    return 
  end
  if not RaidGrid_EventCache.tRecords.Buff.Hash2 then
    RaidGrid_EventCache.tRecords.Buff.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Debuff.Hash2 then
    RaidGrid_EventCache.tRecords.Debuff.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Npc.Hash2 then
    RaidGrid_EventCache.tRecords.Npc.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Casting.Hash2 then
    RaidGrid_EventCache.tRecords.Casting.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Buff.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Buff.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Debuff.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Debuff.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Npc.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Npc.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Casting.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Casting.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2 = {}
  end
  local l_5_1 = function(l_6_0)
    for l_6_4,l_6_5 in pairs(l_6_0) do
      if l_6_5.dwID and l_6_5.nLevel and l_6_0.Hash[l_6_5.dwID] then
        local l_6_6 = l_6_0.Hash2
        local l_6_7 = l_6_5.dwID
        if not l_6_0.Hash2[l_6_5.dwID] then
          l_6_6[l_6_7] = {}
        end
        l_6_6 = l_6_0.Hash2
        l_6_7 = l_6_5.dwID
        l_6_6 = l_6_6[l_6_7]
        l_6_7 = l_6_5.nLevel
        l_6_6[l_6_7] = true
      end
    end
  end
  l_5_1(RaidGrid_EventCache.tRecords.Buff)
  l_5_1(RaidGrid_EventCache.tRecords.Debuff)
  l_5_1(RaidGrid_EventCache.tRecords.Casting)
  l_5_1(RaidGrid_EventScrutiny.tRecords.Buff)
  l_5_1(RaidGrid_EventScrutiny.tRecords.Debuff)
  l_5_1(RaidGrid_EventScrutiny.tRecords.Casting)
  l_5_1(RaidGrid_EventScrutiny.tRecords.Scrutiny)
  RaidGrid_Base.version = 2
end

l_0_0.VersionUpdate = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_6_0 = RaidGrid_EventScrutiny.tRecords.Npc
  for l_6_4 = 1, #l_6_0 do
    l_6_0[l_6_4].bChatAlertCDEnd = nil
    l_6_0[l_6_4].bChatAlertCDEnd2 = nil
    l_6_0[l_6_4].bChatAlertCDEnd3 = nil
  end
  local l_6_5 = RaidGrid_EventScrutiny.tRecords.Casting
  for l_6_9 = 1, #l_6_5 do
    l_6_5[l_6_9].bChatAlertCDEnd = nil
    l_6_5[l_6_9].bChatAlertCDEnd2 = nil
    l_6_5[l_6_9].bChatAlertCDEnd3 = nil
  end
  local l_6_10 = RaidGrid_EventScrutiny.tRecords.Buff
  for l_6_14 = 1, #l_6_10 do
    l_6_10[l_6_14].bChatAlertCDEnd = nil
    l_6_10[l_6_14].bChatAlertCDEnd2 = nil
    l_6_10[l_6_14].bChatAlertCDEnd3 = nil
  end
  local l_6_15 = RaidGrid_EventScrutiny.tRecords.Debuff
  for l_6_19 = 1, #l_6_15 do
    l_6_15[l_6_19].bChatAlertCDEnd = nil
    l_6_15[l_6_19].bChatAlertCDEnd2 = nil
    l_6_15[l_6_19].bChatAlertCDEnd3 = nil
  end
end

l_0_0.ResetChatAlertCD = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  if not RaidGrid_EventScrutiny or not RaidGrid_EventCache then
    return 
  end
  RaidGrid_EventCache.tRecords.Buff.Hash = {}
  RaidGrid_EventCache.tRecords.Debuff.Hash = {}
  RaidGrid_EventCache.tRecords.Npc.Hash = {}
  RaidGrid_EventCache.tRecords.Casting.Hash = {}
  RaidGrid_EventScrutiny.tRecords.Buff.Hash = {}
  RaidGrid_EventScrutiny.tRecords.Debuff.Hash = {}
  RaidGrid_EventScrutiny.tRecords.Npc.Hash = {}
  RaidGrid_EventScrutiny.tRecords.Casting.Hash = {}
  RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash = {}
  RaidGrid_EventCache.tRecords.Buff.Hash2 = {}
  RaidGrid_EventCache.tRecords.Debuff.Hash2 = {}
  RaidGrid_EventCache.tRecords.Npc.Hash2 = {}
  RaidGrid_EventCache.tRecords.Casting.Hash2 = {}
  RaidGrid_EventScrutiny.tRecords.Buff.Hash2 = {}
  RaidGrid_EventScrutiny.tRecords.Debuff.Hash2 = {}
  RaidGrid_EventScrutiny.tRecords.Npc.Hash2 = {}
  RaidGrid_EventScrutiny.tRecords.Casting.Hash2 = {}
  RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2 = {}
  local l_7_0 = function(l_8_0)
    for l_8_4,l_8_5 in pairs(l_8_0) do
      if l_8_5.dwID then
        l_8_0.Hash[l_8_5.dwID] = true
      end
      if l_8_5.nLevel then
        local l_8_6 = l_8_0.Hash2
        local l_8_7 = l_8_5.dwID
        if not l_8_0.Hash2[l_8_5.dwID] then
          l_8_6[l_8_7] = {}
        end
        l_8_6 = l_8_0.Hash2
        l_8_7 = l_8_5.dwID
        l_8_6 = l_8_6[l_8_7]
        l_8_7 = l_8_5.nLevel
        l_8_6[l_8_7] = true
      end
    end
  end
  l_7_0(RaidGrid_EventCache.tRecords.Buff)
  l_7_0(RaidGrid_EventCache.tRecords.Debuff)
  l_7_0(RaidGrid_EventCache.tRecords.Npc)
  l_7_0(RaidGrid_EventCache.tRecords.Casting)
  l_7_0(RaidGrid_EventScrutiny.tRecords.Buff)
  l_7_0(RaidGrid_EventScrutiny.tRecords.Debuff)
  l_7_0(RaidGrid_EventScrutiny.tRecords.Casting)
  l_7_0(RaidGrid_EventScrutiny.tRecords.Npc)
  l_7_0(RaidGrid_EventScrutiny.tRecords.Scrutiny)
  RaidGrid_Base.Message("�ɹ��޸����ݵ��ڶ��棬��С���ؽ���Ϸ��")
end

l_0_0.tRecordsRepair = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_8_0)
  local l_8_1 = ""
  l_8_1 = l_8_1 .. "<Text>text=" .. EncodeComponentsString("������ȷ��Ҫ���ã�����գ�����ô��\n\n") .. " font=2 r=255 g=255 b=255</text>"
  l_8_1 = l_8_1 .. "<Text>text=" .. EncodeComponentsString("������ ����:��ʧȥ�����Լ����ӵ����ݣ�") .. " font=162 r=255 g=0 b=0</text>"
  local l_8_2 = {}
  l_8_2.szMessage = l_8_1
  l_8_2.bRichText = true
  l_8_2.szName = "RaidGrid_Base_tRecordsClear"
  local l_8_3 = {}
  l_8_3.szOption = g_tStrings.STR_HOTKEY_SURE
  l_8_3.fnAction = function()
    -- upvalues: l_8_0
    if l_8_0 then
      RaidGrid_Base.tRecordsClear(l_8_0)
    else
      RaidGrid_Base.tRecordsClear()
    end
  end
  local l_8_4 = {}
  l_8_4.szOption = g_tStrings.STR_HOTKEY_CANCEL
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_8_3 = MessageBox
  l_8_4 = l_8_2
  l_8_3(l_8_4)
end

l_0_0.tRecordsClearSure = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_9_0)
  if not RaidGrid_EventScrutiny or not RaidGrid_EventCache then
    return 
  end
  RaidGrid_EventCache.szListIndex = "Buff"
  local l_9_1 = RaidGrid_EventCache
  local l_9_2 = {}
  l_9_2.Buff = 1
  l_9_2.Debuff = 1
  l_9_2.Npc = 1
  l_9_2.Casting = 1
  l_9_1.tListPage = l_9_2
  l_9_1 = RaidGrid_EventCache
  local l_9_3 = {}
  l_9_3.Hash = {}
  l_9_3.Hash2 = {}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_1.tRecords, l_9_2 = l_9_2, {Buff = l_9_3, Debuff = l_9_3, Npc = l_9_3, Casting = l_9_3}
  l_9_1 = RaidGrid_EventScrutiny
  l_9_1.szListIndex = "Scrutiny"
  l_9_1 = RaidGrid_EventScrutiny
  l_9_1.tListPage, l_9_2 = l_9_2, {Buff = 1, Debuff = 1, Npc = 1, Casting = 1, Scrutiny = 1}
  l_9_1 = RaidGrid_EventScrutiny
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_3 = {
Hash = {}, 
Hash2 = {}}
  l_9_1.tRecords, l_9_2 = l_9_2, {Buff = l_9_3, Debuff = l_9_3, Npc = l_9_3, Casting = l_9_3, Scrutiny = l_9_3}
  l_9_1 = "���"
  if l_9_0 then
    l_9_2 = RaidGrid_EventScrutiny
    l_9_3 = RGES_Settings
    l_9_2.tRecords = l_9_3
    l_9_1 = "����"
  end
  l_9_2 = RaidGrid_EventScrutiny
  l_9_2 = l_9_2.SwitchPageType
  l_9_3 = "Scrutiny"
  l_9_2(l_9_3)
  l_9_2 = RaidGrid_EventCache
  l_9_2 = l_9_2.ClosePanel
  l_9_2()
  l_9_2 = RaidGrid_Base
  l_9_2 = l_9_2.Message
  l_9_3 = "���������"
  l_9_3 = l_9_3 .. l_9_1 .. "����С���ؽ���Ϸ��"
  l_9_2(l_9_3)
end

l_0_0.tRecordsClear = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_10_0 = ""
  l_10_0 = l_10_0 .. "<Text>text=" .. EncodeComponentsString("������ȷ��Ҫ���ò����������ô��\n\n") .. " font=2 r=255 g=255 b=255</text>"
  local l_10_1 = {}
  l_10_1.szMessage = l_10_0
  l_10_1.bRichText = true
  l_10_1.szName = "RaidGrid_Base_AllSettingsReset"
  local l_10_2 = {}
  l_10_2.szOption = g_tStrings.STR_HOTKEY_SURE
  l_10_2.fnAction = function()
    RaidGrid_Base.AllSettingsReset()
  end
  local l_10_3 = {}
  l_10_3.szOption = g_tStrings.STR_HOTKEY_CANCEL
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_10_2 = MessageBox
  l_10_3 = l_10_1
  l_10_2(l_10_3)
end

l_0_0.AllSettingsResetSure = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  RaidGrid_EventScrutiny.bEnable = true
  RaidGrid_EventScrutiny.bCacheEnable = false
  RaidGrid_EventScrutiny.bAddByNameEnable = true
  RaidGrid_EventScrutiny.bBuffCacheEnable = true
  RaidGrid_EventScrutiny.bBuffCacheVisibleOnly = false
  RaidGrid_EventScrutiny.bBuffCacheDungeonOnly = false
  RaidGrid_EventScrutiny.bBuffScrutinyEnable = true
  RaidGrid_EventScrutiny.bEnemyBuffScrutinyEnable = true
  RaidGrid_EventScrutiny.bEnemyOnlyBuffScrutiny = false
  RaidGrid_EventScrutiny.bPartyOnlyDebuffScrutiny = false
  RaidGrid_EventScrutiny.bBuffTeamScrutinyEnable = true
  RaidGrid_EventScrutiny.bBuffChatAlertEnable = false
  RaidGrid_EventScrutiny.bScreenHeadMonitor = true
  RaidGrid_EventScrutiny.bBuffShowIcon = true
  RaidGrid_EventScrutiny.bBuffShowTime = true
  RaidGrid_EventScrutiny.bBuffShowShadow = true
  RaidGrid_EventScrutiny.nBuffShowShadowAlpha = 0.6
  RaidGrid_EventScrutiny.nBuffAutoRemoveCachePage = 50
  RaidGrid_EventScrutiny.bCastingCacheEnable = true
  RaidGrid_EventScrutiny.bCastingScrutinyEnable = true
  RaidGrid_EventScrutiny.bCastingChatAlertEnable = false
  RaidGrid_EventScrutiny.bCastingEnemyEnable = true
  RaidGrid_EventScrutiny.bCastingNeutralEnable = true
  RaidGrid_EventScrutiny.bCastingAllyEnable = true
  RaidGrid_EventScrutiny.bCastingBossOnly = false
  RaidGrid_EventScrutiny.nCastingAutoRemoveCachePage = 50
  RaidGrid_EventScrutiny.bCastingReadingBar = true
  RaidGrid_EventScrutiny.bNpcCacheEnable = true
  RaidGrid_EventScrutiny.bNpcScrutinyEnable = true
  RaidGrid_EventScrutiny.bNpcLeaveScrutinyEnable = true
  RaidGrid_EventScrutiny.bNpcChatAlertEnable = false
  RaidGrid_EventScrutiny.bNpcEnemyEnable = true
  RaidGrid_EventScrutiny.bNpcNeutralEnable = true
  RaidGrid_EventScrutiny.bNpcAllyEnable = true
  RaidGrid_EventScrutiny.bNpcUnselectableOnly = false
  RaidGrid_EventScrutiny.nNpcAutoRemoveCachePage = 50
  RaidGrid_EventScrutiny.bBuffListExEnable = true
  RaidGrid_EventScrutiny.bSoundAlertEnable = true
  RaidGrid_EventScrutiny.bColorAlertEnable = true
  RaidGrid_EventScrutiny.bRedAlarmEnable = true
  RaidGrid_EventScrutiny.bCenterAlarmEnable = true
  RaidGrid_EventScrutiny.bAutoSelectEnable = true
  RaidGrid_EventScrutiny.bCtrlandAltMove = true
  RaidGrid_EventScrutiny.bAutoNewSkillTimer = true
  RaidGrid_EventScrutiny.bSkillTimerSay = false
  RaidGrid_EventScrutiny.nCenterAlarmTime = 2
  RaidGrid_EventScrutiny.nSkillTimerCountdown = 5
  RaidGrid_EventScrutiny.nSayChannel = PLAYER_TALK_CHANNEL.RAID
  RaidGrid_EventScrutiny.bNpcLifeCheckEnable = true
  RaidGrid_EventScrutiny.bLinkNpcFightState = true
  RaidGrid_EventScrutiny.nRemoveDelayTime = 10
  RaidGrid_EventScrutiny.bScrutinySelfBuff = true
  RaidGrid_EventScrutiny.bScrutinyFightState = true
  RaidGrid_EventScrutiny.bAddToHead = true
  RaidGrid_BossCallAlert.TalkMonitor = true
  RaidGrid_BossCallAlert.bWarningMessageMonitor = true
  RaidGrid_BossCallAlert.bDungeonOnly = false
  RaidGrid_BossCallAlert.bBossOnly = false
  RaidGrid_BossCallAlert.bPartyOnly = false
  RaidGrid_BossCallAlert.macthall = true
  RaidGrid_BossCallAlert.Flash = true
  RaidGrid_BossCallAlert.CenterAlarm = true
  RaidGrid_BossCallAlert.bChatAlertEnable = false
  local l_11_0 = RaidGrid_BossCallAlert
  do
    local l_11_1 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_0(l_11_1)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.AllSettingsReset = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  RaidGrid_EventScrutiny.bNotCheckLevel = true
  RaidGrid_EventScrutiny.bScrutinyFightState = true
  RaidGrid_EventScrutiny.bSelfStateOfDeathProcess = true
  RaidGrid_EventScrutiny.bLinkNpcFightStateInDun = true
  RaidGrid_EventScrutiny.bLinkNpcFightState = true
  RaidGrid_EventScrutiny.bSelfBuffScrutinyEnable = false
  RaidGrid_EventScrutiny.bCastingCacheDungeonOnly = true
  RaidGrid_EventScrutiny.bCastingScrutinyDungeonOnly = true
  RaidGrid_EventScrutiny.bCastingNPCOnly = true
  RaidGrid_EventScrutiny.bCastingBossOnly = false
  RaidGrid_EventScrutiny.bNpcCacheDungeonOnly = true
  RaidGrid_EventScrutiny.nSayChannel = PLAYER_TALK_CHANNEL.RAID
  RaidGrid_EventScrutiny.bAutoNewSkillTimer = true
  RaidGrid_EventScrutiny.bRedAlarmEnable = false
  RaidGrid_EventScrutiny.bCenterAlarmEnable = true
end

l_0_0.SimpleSettingsReset2 = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_13_0)
  OutputMessage("MSG_SYS", "[RaidGrid_EventScrutiny] " .. tostring(l_13_0) .. "\n")
end

l_0_0.Message = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(...)
  for l_14_4,l_14_5 in ipairs({...}) do
    local l_14_1 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_14_1[l_14_5] = tostring(R6_PC8)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  OutputMessage("MSG_SYS", table.concat(l_14_1, "\t") .. "\n")
end

l_0_0.print = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_15_0)
  local l_15_1 = GetClientPlayer()
  if not l_15_1 or not l_15_1.IsInParty() then
    return 
  end
  local l_15_2 = GetClientTeam()
  local l_15_3 = l_15_2.nGroupNum
  for l_15_7 = 0, l_15_3 - 1 do
    local l_15_8 = l_15_2.GetGroupInfo(l_15_7)
    if l_15_8 and l_15_8.MemberList then
      for l_15_12,l_15_13 in pairs(l_15_8.MemberList) do
        local l_15_14 = l_15_2.GetMemberInfo(l_15_13)
        if l_15_1.dwID ~= l_15_13 and l_15_14 then
          l_15_1.Talk(PLAYER_TALK_CHANNEL.WHISPER, l_15_14.szName, l_15_0)
        end
      end
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.WhisperToPartyMember = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_16_0)
  return next(l_16_0) == nil
end

l_0_0.isTableEmpty = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_17_0, l_17_1)
  if not l_17_0 or not l_17_1 then
    RaidGrid_EventScrutiny.frameSelf:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  else
    local l_17_2, l_17_3 = Station.GetClientSize(true)
    if l_17_0 < 0 then
      l_17_0 = 0
    end
    if l_17_2 - 100 < l_17_0 then
      l_17_0 = l_17_2 - 100
    end
    if l_17_1 < 0 then
      l_17_1 = 0
    end
    if l_17_3 - 110 < l_17_1 then
      l_17_1 = l_17_3 - 110
    end
    RaidGrid_EventScrutiny.frameSelf:SetRelPos(l_17_0, l_17_1)
  end
  local l_17_4 = RaidGrid_EventScrutiny.tLastLoc
  local l_17_5 = RaidGrid_EventScrutiny.tLastLoc
  local l_17_6 = RaidGrid_EventScrutiny.frameSelf:GetRelPos()
  l_17_5.nY = RaidGrid_EventScrutiny.frameSelf
  l_17_4.nX = l_17_6
end

l_0_0.SetPanelPos = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_18_0, l_18_1)
  local l_18_2 = GetNpcTemplate(l_18_0)
  if not l_18_2 then
    return 
  end
  local l_18_3 = ""
  l_18_3 = l_18_3 .. "<Text>text=" .. EncodeComponentsString(l_18_2.szName .. "\n") .. " font=80" .. " r=255 g=255 b=255 </text>"
  if l_18_2.nLevel - GetClientPlayer().nLevel > 10 then
    l_18_3 = l_18_3 .. "<Text>text=" .. EncodeComponentsString(g_tStrings.STR_PLAYER_H_UNKNOWN_LEVEL) .. " font=82 </text>"
  else
    l_18_3 = l_18_3 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.STR_NPC_H_WHAT_LEVEL, l_18_2.nLevel)) .. " font=0 </text>"
  end
  l_18_3 = l_18_3 .. "<Text>text=" .. EncodeComponentsString(FormatString(g_tStrings.TIP_TEMPLATE_ID_NPC_INTENSITY, l_18_2.dwTemplateID, l_18_2.nIntensity or 1)) .. " font=101 </text>"
  OutputTip(l_18_3, 345, l_18_1)
end

l_0_0.OutputNpcInfoTip = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_19_0 = function(l_20_0)
    if not l_20_0 or l_20_0 == "" then
      return 
    end
    RaidGrid_Base.OutputSettingsFile(l_20_0)
  end
  if io or iox then
    GetUserInput("������Ҫ������ļ����֣�", l_19_0, nil, function()
  end, nil, GetClientPlayer().szName, 31)
  else
    RaidGrid_Base.OutputSettingsFile(GetClientPlayer().szName)
  end
end

l_0_0.SaveSettings = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_20_0)
  if not l_20_0 then
    return 
  end
  do
    GetUserInput("�¼��������ӳ�ɾ��ʱ��(��)", function(l_21_0)
    -- upvalues: l_20_0
    if not l_21_0 or l_21_0 == "" then
      return 
    end
    local l_21_1 = tonumber(l_21_0)
    if not l_21_1 then
      return 
    end
    l_20_0.tRecord.nRemoveDelayTime = nil
    if l_21_1 >= 0 then
      l_20_0.tRecord.nRemoveDelayTime = l_21_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_20_0.tRecord.nRemoveDelayTime or "", 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventRemoveDelayTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_21_0)
  if not l_21_0 then
    return 
  end
  do
    GetUserInput("Ƶ����������ʱʱ��(��)", function(l_22_0)
    -- upvalues: l_21_0
    if not l_22_0 or l_22_0 == "" then
      return 
    end
    local l_22_1 = tonumber(l_22_0)
    if not l_22_1 then
      return 
    end
    l_21_0.tRecord.nEventCountdownTime = nil
    if l_22_1 >= 0 then
      l_21_0.tRecord.nEventCountdownTime = l_22_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_21_0.tRecord.nEventCountdownTime or "", 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventCountdownAlertTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_22_0)
  if not l_22_0 then
    return 
  end
  do
    GetUserInput("����������(�˲���������)", function(l_23_0)
    -- upvalues: l_22_0
    if not l_23_0 or l_23_0 == "" then
      return 
    end
    l_22_0.tRecord.szName = l_23_0
    l_22_0.text:SetText(l_23_0)
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_22_0.tRecord.szName or "????", 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventNewName = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_23_0)
  if not l_23_0 then
    return 
  end
  do
    GetUserInput("�¼����ʱ��(��)", function(l_24_0)
    -- upvalues: l_23_0
    if not l_24_0 or l_24_0 == "" then
      return 
    end
    local l_24_1 = tonumber(l_24_0)
    if not l_24_1 then
      return 
    end
    l_23_0.tRecord.nEventAlertTime = nil
    if l_24_1 > 0 then
      l_23_0.tRecord.nEventAlertTime = l_24_1
    end
    l_23_0.textEventAlertTime:SetText(RaidGrid_Base.Time2String(l_24_1))
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_23_0.tRecord.nEventAlertTime or "", 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventAlertTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_24_0)
  if not l_24_0 then
    return 
  end
  do
    GetUserInput("NPC �¼��������(��)", function(l_25_0)
    -- upvalues: l_24_0
    if not l_25_0 or l_25_0 == "" then
      return 
    end
    local l_25_1 = tonumber(l_25_0)
    if not l_25_1 then
      return 
    end
    l_24_0.tRecord.nEventAlertCount = nil
    if l_25_1 > 0 then
      l_24_0.tRecord.nEventAlertCount = l_25_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_24_0.tRecord.nEventAlertCount or 1, 5)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventAlertCount = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_25_0)
  if not l_25_0 then
    return 
  end
  do
    GetUserInput(l_25_0.tRecord.szName .. "���Ŷ�����Ƶ��������ʾ��Ϣ���ã�", function(l_26_0)
    -- upvalues: l_25_0
    l_25_0.tRecord.tAlarmAddInfo = nil
    if not l_26_0 or l_26_0 == "" or l_26_0 == " " then
      return 
    end
    l_25_0.tRecord.tAlarmAddInfo = l_26_0
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_25_0.tRecord.tAlarmAddInfo or "", 310)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventAlarmAddInfo = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_26_0)
  if not l_26_0 then
    return 
  end
  do
    GetUserInput("Buff/Debuff �¼���ز���", function(l_27_0)
    -- upvalues: l_26_0
    if not l_27_0 or l_27_0 == "" then
      return 
    end
    local l_27_1 = tonumber(l_27_0)
    if not l_27_1 then
      return 
    end
    l_26_0.tRecord.nEventAlertStackNum = nil
    if l_27_1 > 1 then
      l_26_0.tRecord.nEventAlertStackNum = l_27_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_26_0.tRecord.nEventAlertStackNum or 1, 5)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventAlertStackNum = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_27_0 = function(l_28_0)
    if not l_28_0 or l_28_0 == "" then
      return 
    end
    local l_28_1 = tonumber(l_28_0)
    if not l_28_1 then
      return 
    end
    if l_28_1 > 0 and l_28_1 ~= RaidGrid_SelfBuffAlert.nScaleXandY then
      RaidGrid_SelfBuffAlert.frameSelf:Scale(l_28_1 / RaidGrid_SelfBuffAlert.nScaleXandY, l_28_1 / RaidGrid_SelfBuffAlert.nScaleXandY)
      RaidGrid_SelfBuffAlert.nScaleXandY = l_28_1
    end
  end
  GetUserInput("����Ч��ͼ������ϵ������", l_27_0, nil, function()
  end, nil, RaidGrid_SelfBuffAlert.nScaleXandY, 5)
end

l_0_0.SetSelfBuffAlertScale = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_28_0 = function(l_29_0)
    if not l_29_0 or l_29_0 == "" then
      return 
    end
    local l_29_1 = tonumber(l_29_0)
    if not l_29_1 then
      return 
    end
    if l_29_1 > 0 then
      RaidGrid_EventScrutiny.nCenterAlarmTime = l_29_1
    end
  end
  GetUserInput("С�����ȫ�������������ʾʱ������", l_28_0, nil, function()
  end, nil, RaidGrid_EventScrutiny.nCenterAlarmTime, 5)
end

l_0_0.SetCenterAlarmTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_29_0 = function(l_30_0)
    if not l_30_0 or l_30_0 == "" then
      return 
    end
    local l_30_1 = tonumber(l_30_0)
    if not l_30_1 then
      return 
    end
    if l_30_1 >= 0 then
      RaidGrid_EventScrutiny.nSkillTimerCountdown = l_30_1
    end
  end
  GetUserInput("��Ļ���뵹��ʱģ��Ƶ����������ʱʱ��(��)", l_29_0, nil, function()
  end, nil, RaidGrid_EventScrutiny.nSkillTimerCountdown, 5)
end

l_0_0.SetSkillTimerCountdown = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_30_0)
  if not l_30_0 then
    return 
  end
  do
    GetUserInput(l_30_0.tRecord.szName .. "���ֶ�ʱ�����ã��ο���25,��ӿ;40,ɨ�䣩", function(l_31_0)
    -- upvalues: l_30_0
    l_30_0.tRecord.szTimerSet = nil
    l_30_0.tRecord.tTimerSet = nil
    if not l_31_0 or l_31_0 == "" then
      return 
    end
    l_31_0 = string.gsub(l_31_0, " ", "")
    l_31_0 = string.gsub(l_31_0, "��", ",")
    l_31_0 = string.gsub(l_31_0, ",,", ",")
    l_31_0 = string.gsub(l_31_0, "��", ";")
    l_31_0 = string.gsub(l_31_0, ";;", ";")
    if not l_31_0 or l_31_0 == "" or l_31_0 == "," or l_31_0 == ";" then
      return 
    end
    local l_31_1 = l_31_0
    local l_31_3 = 1
    local l_31_4 = ""
    repeat
      repeat
        repeat
          if l_31_3 and l_31_1 ~= "" and l_31_1 ~= ";" then
            l_31_3 = string.find(l_31_1, ";")
            local l_31_2 = {}
            if not l_31_3 then
              l_31_4 = l_31_1
            else
              l_31_4 = string.sub(l_31_1, 1, l_31_3 - 1)
              l_31_1 = string.sub(l_31_1, l_31_3 + 1)
            end
            local l_31_5 = string.find(l_31_4, ",")
          until l_31_5
          local l_31_6 = string.sub(l_31_4, 1, l_31_5 - 1)
          local l_31_7 = string.sub(l_31_4, l_31_5 + 1)
          local l_31_8 = tonumber(l_31_6)
        until l_31_8
      until l_31_7
      local l_31_9 = table.insert
      local l_31_10 = l_31_2
      local l_31_11 = {}
      l_31_11.nTime = l_31_8
      l_31_11.szTimerName = l_31_7
      l_31_9(l_31_10, l_31_11)
    end
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if #l_31_2 > 0 then
    table.sort(l_31_2, function(l_32_0, l_32_1)
    return l_32_0.nTime < l_32_1.nTime
  end)
    l_30_0.tRecord.szTimerSet = l_31_0
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_30_0.tRecord.tTimerSet = l_31_2
  end
  RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_30_0.tRecord.szTimerSet or "", 999)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetEventTimerSet = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_31_0)
  if not l_31_0 then
    return 
  end
  do
    GetUserInput(l_31_0.tRecord.szName .. "����С��ˢ������ʱ�������ã�", function(l_32_0)
    -- upvalues: l_31_0
    if not l_32_0 or l_32_0 == "" then
      return 
    end
    local l_32_1 = tonumber(l_32_0)
    if not l_32_1 then
      return 
    end
    l_31_0.tRecord.nMinChatAlertCD = nil
    if l_32_1 >= 0 then
      l_31_0.tRecord.nMinChatAlertCD = l_32_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_31_0.tRecord.nMinChatAlertCD or 7, 5)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetMinChatAlertCD = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_32_0)
  if not l_32_0 then
    return 
  end
  do
    GetUserInput(l_32_0.tRecord.szName .. "����С���뵹��ʱ����ʱ�������ã�", function(l_33_0)
    -- upvalues: l_32_0
    if not l_33_0 or l_33_0 == "" then
      return 
    end
    local l_33_1 = tonumber(l_33_0)
    if not l_33_1 then
      return 
    end
    l_32_0.tRecord.nMinEventCD = nil
    if l_33_1 >= 0 then
      l_32_0.tRecord.nMinEventCD = l_33_1
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  end, nil, function()
  end, nil, l_32_0.tRecord.nMinEventCD or 10, 5)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetMinEventCD = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_33_0)
  if not l_33_0 then
    return 
  end
  do
    local l_33_2 = function(l_34_0)
    -- upvalues: l_33_0
    if not l_34_0 or l_34_0 == "" then
      return 
    end
    l_34_0 = l_34_0:gsub("%s", "")
    l_34_0 = l_34_0:gsub("��", ",")
    l_34_0 = l_34_0:gsub("��", ",")
    local l_34_1, l_34_2, l_34_3 = nil, nil, nil
    if l_34_0:match("��") then
      l_34_1 = 255
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_34_0:match("��") then
        l_34_1 = 0
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_34_0:match("��") then
        l_34_1 = 0
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_34_0:match("��") then
        l_34_1 = 255
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_34_0:match("��") then
        l_34_1 = 255
      end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      if l_34_0:match("��") then
        l_34_1 = 255
      end
    else
      l_34_1 = l_34_0:match("^(%d+),")
      if not l_34_1 then
        return 
      end
       -- DECOMPILER ERROR: Overwrote pending register.

      if not l_34_2 then
        return 
      end
       -- DECOMPILER ERROR: Overwrote pending register.

    end
    if not l_34_3 then
      return 
    end
    local l_34_4 = l_33_0.tRecord
    do
      local l_34_5 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      l_34_4(l_34_5)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
    GetUserInput("������������ظ�����ɫ: ��,��,��,��,��,��\nҲ�������ָ�ʽ��: 255,128,0", l_33_2, nil, function()
  end, nil, (not l_33_0.tRecord.tRGBuffColor and l_33_0.tRecord.tRGBuffColor[1] or 0) .. "," .. (l_33_0.tRecord.tRGBuffColor[2] or 0) .. "," .. (l_33_0.tRecord.tRGBuffColor[3] or 0), 12)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.GetRGBuffColor = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_34_0)
  if not l_34_0 then
    l_34_0 = 0
  end
  local l_34_1 = math.min(math.floor(l_34_0 / 60), 59)
  local l_34_2 = math.floor(l_34_0 % 60)
  if l_34_0 / 60 > 59 then
    l_34_2 = 59
  end
  local l_34_3 = ""
  if l_34_1 == 0 and l_34_2 == 0 then
    l_34_3 = ""
  elseif l_34_1 == 0 then
    l_34_3 = l_34_2 .. "\""
  else
    l_34_3 = l_34_1 .. "'" .. l_34_2 .. "\""
  end
  return l_34_3
end

l_0_0.Time2String = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  return GetLogicFrameCount() / GLOBAL.GAME_FPS
end

l_0_0.GetLogicTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_36_0, l_36_1)
  if not l_36_1 then
    l_36_1 = 0
  end
  if not l_36_0.fEventTimeStart or not l_36_0.fEventTimeEnd then
    l_36_0.fEventTimeStart = nil
    l_36_0.fEventTimeEnd = nil
    return true
  end
  local l_36_2 = GetLogicFrameCount() / GLOBAL.GAME_FPS
  if l_36_2 < l_36_0.fEventTimeStart or l_36_0.fEventTimeEnd + l_36_1 < l_36_2 then
    return true
  end
  return false
end

l_0_0.IsOutOfEventTime = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_37_0)
  local l_37_1 = 0
  local l_37_2 = 0
  local l_37_3 = 0
  local l_37_4 = 0
  if l_37_0 then
    for l_37_8 = 1, #l_37_0 do
      if type(l_37_0[l_37_8]) == "number" then
        l_37_1 = l_37_1 + l_37_0[l_37_8]
        if l_37_2 < l_37_0[l_37_8] then
          l_37_4 = l_37_3
          l_37_3 = l_37_2
          l_37_2 = l_37_0[l_37_8]
        end
      elseif l_37_3 < l_37_0[l_37_8] then
        l_37_4 = l_37_3
        l_37_3 = l_37_0[l_37_8]
      elseif l_37_4 < l_37_0[l_37_8] then
        l_37_4 = l_37_0[l_37_8]
      end
    end
    if #l_37_0 >= 4 then
      l_37_1 = (l_37_1 - l_37_2 - l_37_3 - l_37_4) / (#l_37_0 - 3)
    end
  elseif #l_37_0 >= 1 then
    l_37_1 = l_37_1 / #l_37_0
  end
  return l_37_1
end

l_0_0.LowAverage = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_38_0 = GetClientPlayer()
  if not l_38_0 then
    return 
  end
  local l_38_1 = l_38_0.GetScene()
  if not l_38_1 then
    return 
  end
  if l_38_1.nType ~= 1 and l_38_1.nType ~= 4 then
    return 
  end
  return true
end

l_0_0.IsInDungeon = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function()
  local l_39_0 = GetClientPlayer()
  if not l_39_0 then
    return "�޷���ȡ"
  end
  local l_39_1 = l_39_0.GetScene()
  if not l_39_1 then
    return "�޷���ȡ"
  end
  local l_39_2 = l_39_1.dwMapID
  if not l_39_2 then
    return "�޷���ȡ"
  end
  local l_39_3 = Table_GetMapName(l_39_2)
  local l_39_4 = nil
  if not l_39_3 then
    l_39_4 = "�޷���ȡ"
  end
  return l_39_4
end

l_0_0.GetCurrentMapName = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_40_0)
  local l_40_1 = nil
  if l_40_0 <= 0 then
    return "�޷���ȡ", "δ֪"
  end
  if IsPlayer(l_40_0) then
    l_40_1 = GetPlayer(l_40_0)
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    if not l_40_1 then
      return "�޷���ȡ", "Player"
    end
    local l_40_2 = nil
    do
      local l_40_3 = nil
      if not l_40_1.szName then
        return "�޷���ȡ", l_40_2
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 23 
end

l_0_0.GetNameAndTypeFromId = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_41_0)
  l_41_0 = string.gsub(l_41_0, " ", "")
  l_41_0 = string.gsub(l_41_0, "��", ",")
  l_41_0 = string.gsub(l_41_0, ",,", ",")
  local l_41_2 = 1
  local l_41_3 = ""
  if l_41_2 and l_41_0 ~= "" and l_41_0 ~= "," then
    l_41_2 = string.find(l_41_0, ",")
    local l_41_1 = {}
    if not l_41_2 then
      l_41_3 = l_41_0
    else
      l_41_3 = string.sub(l_41_0, 1, l_41_2 - 1)
      l_41_0 = string.sub(l_41_0, l_41_2 + 1)
    end
    table.insert(l_41_1, l_41_3)
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers!

return l_41_1
end

l_0_0.getList = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_42_0, l_42_1)
  if not l_42_0 then
    return 
  end
  do
    GetUserInput("����Ҫ���ӵ����֣�" .. l_42_1 .. "��", function(l_43_0)
    -- upvalues: l_42_0 , l_42_1
    if not l_43_0 or l_43_0 == "" or l_43_0 == "," or l_43_0 == "��" then
      return 
    end
    l_42_0.szToAddNameList = l_43_0 .. "," .. l_42_0.szToAddNameList
    l_42_0[l_43_0] = true
    RaidGrid_Base.DoAddByNameTable(l_42_1)
    if RaidGrid_EventCache.szListIndex == l_42_1 then
      RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
    end
  end, nil, function()
  end, nil, "", 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.AddOneNameToTable = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_43_0, l_43_1)
  if not l_43_0 then
    return 
  end
  do
    GetUserInput("����Ҫ���ӵ����ִ����м��ö��Ÿ�����" .. l_43_1 .. "��", function(l_44_0)
    -- upvalues: l_43_0 , l_43_1
    for l_44_4,l_44_5 in pairs(l_43_0) do
      l_43_0[l_44_4] = nil
    end
    l_43_0.szToAddNameList = ""
    if not l_44_0 or l_44_0 == "" or l_44_0 == "," or l_44_0 == "��" then
      return 
    end
    l_43_0.szToAddNameList = l_44_0
    local l_44_6, l_44_12 = RaidGrid_Base.getList(l_43_0.szToAddNameList)
    l_44_12 = pairs
    l_44_12 = l_44_12(l_44_6)
    for l_44_10,l_44_11 in l_44_12 do
      local l_44_11 = nil
      l_44_11 = l_43_0
      l_44_11[l_44_10] = true
    end
    RaidGrid_Base.DoAddByNameTable(l_43_1)
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    if RaidGrid_EventCache.szListIndex == l_43_1 then
      RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
    end
  end, nil, function()
  end, nil, l_43_0.szToAddNameList or "", 310)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0.SetAddByNameTable = l_0_1
l_0_0 = RaidGrid_Base
l_0_1 = function(l_44_0)
  for l_44_4,l_44_5 in pairs(RaidGrid_EventCache.tRecords[l_44_0]) do
    if l_44_5.szName and RaidGrid_EventCache.tAddByName[l_44_0][l_44_5.szName] then
      RaidGrid_EventScrutiny.AddRecordToList(l_44_5, l_44_5.szType)
    end
  end
end

l_0_0.DoAddByNameTable = l_0_1
RaidGrid_Export, l_0_0 = l_0_0, {}
l_0_0 = RaidGrid_Export
l_0_1 = function()
  local l_45_0 = this:GetName()
  if l_45_0 == "Btn_Close" then
    RaidGrid_Export.SwitchActive()
  end
end

l_0_0.OnLButtonClick = l_0_1
l_0_0 = RaidGrid_Export
l_0_1 = function()
  local l_46_0 = Station.Lookup("Normal1/RaidGrid_Export")
  if l_46_0 then
    if l_46_0:IsVisible() then
      return 
    end
    do return end
    l_46_0:Show()
  else
    l_46_0 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_Export.ini", "RaidGrid_Export")
    l_46_0:Show()
  end
end

l_0_0.Active = l_0_1
l_0_0 = RaidGrid_Export
l_0_1 = function()
  local l_47_0 = Station.Lookup("Normal1/RaidGrid_Export")
  if l_47_0 then
    if l_47_0:IsVisible() then
      l_47_0:Hide()
    else
      l_47_0:Show()
    end
  else
    l_47_0 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_Export.ini", "RaidGrid_Export")
    l_47_0:Show()
  end
end

l_0_0.SwitchActive = l_0_1
l_0_0 = function()
  local l_48_0 = Station.Lookup("Normal1/RaidGrid_Export")
  if l_48_0 and l_48_0:IsVisible() then
    return true
  end
  return false
end

l_0_1 = RaidGrid_Base
l_0_1.OutputRecord = function(l_49_0)
  if not l_49_0 then
    return 
  end
  if IsAltKeyDown() then
    local l_49_1 = var2str(l_49_0.tRecord)
    RaidGrid_Export.Active()
    local l_49_2 = Station.Lookup("Normal1/RaidGrid_Export/Edit_String")
    l_49_2:SetText(l_49_1)
  else
    Output(l_49_0.tRecord)
  end
end

l_0_1 = RaidGrid_Base
l_0_1.SaveSettingsByType = function(l_50_0)
  if not l_50_0 then
    return 
  end
  local l_50_1 = var2str(l_50_0)
  RaidGrid_Export.Active()
  local l_50_2 = Station.Lookup("Normal1/RaidGrid_Export/Edit_String")
  l_50_2:SetText(l_50_1)
end

l_0_1 = RaidGrid_Base
l_0_1.OutputSettingsFile = function(l_51_0)
  local l_51_1 = GetClientPlayer()
  do
    local l_51_2, l_51_3 = io or iox
  end
  if not l_51_1 then
    return 
  end
  if not l_51_0 then
    l_51_0 = l_51_1.szName
  end
  local l_51_4 = nil
  if l_51_4 then
    local l_51_5 = var2str(RaidGrid_EventScrutiny.tRecords)
    local l_51_6, l_51_7 = , l_51_4.open("Interface\\RaidGrid_EventScrutiny\\RGES_Settings_" .. l_51_0 .. ".lua", "w+"):write
    local l_51_8 = l_51_4.open("Interface\\RaidGrid_EventScrutiny\\RGES_Settings_" .. l_51_0 .. ".lua", "w+")
    local l_51_9 = "RGES_Settings = "
    if not l_51_5 then
      l_51_9 = l_51_9 .. "{}"
      l_51_7(l_51_8, l_51_9)
    end
    l_51_7, l_51_8 = l_51_6:write, l_51_6
    l_51_9 = "\n"
    l_51_7(l_51_8, l_51_9)
    l_51_7, l_51_8 = l_51_6:write, l_51_6
    l_51_9 = "RaidGrid_Base.tSavedDataBak = RaidGrid_EventScrutiny.tRecords\n"
    l_51_7(l_51_8, l_51_9)
    l_51_7, l_51_8 = l_51_6:write, l_51_6
    l_51_9 = "RaidGrid_Base.bLoadDone = true\n"
    l_51_7(l_51_8, l_51_9)
    l_51_7, l_51_8 = l_51_6:close, l_51_6
    l_51_7(l_51_8)
    l_51_7 = RaidGrid_Base
    l_51_7 = l_51_7.Message
    l_51_8 = "�����ɹ���"
    l_51_9 = "Interface\\RaidGrid_EventScrutiny\\RGES_Settings_"
    l_51_8 = l_51_8 .. l_51_9 .. l_51_0 .. ".lua"
    l_51_7(l_51_8)
  else
    RaidGrid_Export.Active()
    local l_51_10 = nil
    local l_51_11 = Station.Lookup("Normal1/RaidGrid_Export/Edit_String")
    local l_51_12 = "\n"
    local l_51_13 = "function RGES_Settings_Load_default()\n"
    local l_51_14 = "RGES_Settings = "
    if not l_51_10 then
      l_51_12 = l_51_12 .. l_51_13 .. l_51_14 .. "{}" .. "\n" .. "RaidGrid_Base.tSavedDataBak = RaidGrid_EventScrutiny.tRecords\n" .. "RaidGrid_Base.bLoadDone = true\n" .. "end\n"
      l_51_13, l_51_14 = l_51_11:SetText, l_51_11
      l_51_13(l_51_14, l_51_12)
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 66 
end

l_0_1 = RaidGrid_Base
l_0_1.LoadSettingsFile = function(l_52_0)
  local l_52_1 = GetClientPlayer()
  if not dofile and _Gx and _Gx.dofile then
    local l_52_2, l_52_3, l_52_4 = _Gx.dofile
  end
  RaidGrid_Base.bLoadDone = nil
  do
    local l_52_5 = nil
    if not l_52_5 then
      RGES_Settings_Load_default()
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Confused about usage of registers!

    else
      if not "RGES_Settings_Load_default.lua" or "RGES_Settings_Load_default.lua" == "" then
        return 
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_52_5("RGES_Settings_Load_default.lua")
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    if RaidGrid_Base.bLoadDone then
      RaidGrid_Base.Message("�������óɹ���" .. "RGES_Settings_Load_default.lua")
    else
      RaidGrid_Base.Message("���������ļ������쳣�����ܵ������ݼ��ز���ȫ��������Ŀ¼�µ�RGES_Settings_Load_default.lua�ļ���")
      return 
    end
    RGES_Settings.Scrutiny = RaidGrid_EventScrutiny.tRecords.Scrutiny
    if l_52_0 then
      RaidGrid_EventScrutiny.tRecords = RGES_Settings
      RaidGrid_Base.VersionUpdate(true)
      RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
      return 
    end
    do break end
    do
      local l_52_6, l_52_7, l_52_8, l_52_9, l_52_10 = , pairs(RGES_Settings)
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_52_10 ~= "Scrutiny" then
        for l_52_14 = 1, #R8_PC77 do
          local l_52_11 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          if l_52_11[R12_PC80].dwID then
            RaidGrid_EventScrutiny.AddRecordToList(l_52_11[l_52_15], l_52_10)
          end
        end
      end
    end
  end
  RaidGrid_Base.VersionUpdate(true)
  RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_1 = ""
local l_0_2 = 1
local l_0_3 = "Interface/RaidGrid_EventScrutiny/RaidGrid_EventCache.ini"
RaidGrid_EventCache = {}
RaidGrid_EventCache.bCheckBoxRecall = true
RaidGrid_EventCache.nSetper = -1
RaidGrid_EventCache.frameSelf = nil
RaidGrid_EventCache.wnd = nil
RaidGrid_EventCache.handleMain = nil
RaidGrid_EventCache.handleRecords = nil
RaidGrid_EventCache.szCurrentMapName = ""
RaidGrid_EventCache.tSyncEnemyChar = {}
RaidGrid_EventCache.tSyncCharFightState = {}
RaidGrid_EventCache.szListIndex = "Buff"
RegisterCustomData("RaidGrid_EventCache.szListIndex")
local l_0_4 = RaidGrid_EventCache
local l_0_5 = {}
l_0_5.Buff = 1
l_0_5.Debuff = 1
l_0_5.Npc = 1
l_0_5.Casting = 1
l_0_4.tListPage = l_0_5
l_0_4 = RegisterCustomData
l_0_5 = "RaidGrid_EventCache.tListPage"
l_0_4(l_0_5)
l_0_4 = RaidGrid_EventCache
local l_0_6 = {}
l_0_6.Hash = {}
l_0_6.Hash2 = {}
l_0_6 = {
Hash = {}, 
Hash2 = {}}
l_0_6 = {
Hash = {}, 
Hash2 = {}}
l_0_6 = {
Hash = {}, 
Hash2 = {}}
l_0_4.tRecords, l_0_5 = l_0_5, {Buff = l_0_6, Debuff = l_0_6, Npc = l_0_6, Casting = l_0_6}
l_0_4 = RegisterCustomData
l_0_5 = "RaidGrid_EventCache.tRecords"
l_0_4(l_0_5)
l_0_4 = RaidGrid_EventCache
l_0_6 = {szToAddNameList = ""}
l_0_6 = {szToAddNameList = ""}
l_0_6 = {szToAddNameList = ""}
l_0_6 = {szToAddNameList = ""}
l_0_4.tAddByName, l_0_5 = l_0_5, {Buff = l_0_6, Debuff = l_0_6, Npc = l_0_6, Casting = l_0_6}
l_0_4 = RegisterCustomData
l_0_5 = "RaidGrid_EventCache.tAddByName"
l_0_4(l_0_5)
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  this:RegisterEvent("RENDER_FRAME_UPDATE")
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("PLAYER_ENTER_SCENE")
  if not RaidGrid_EventCache.tRecords.Buff.Hash2 then
    RaidGrid_EventCache.tRecords.Buff.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Debuff.Hash2 then
    RaidGrid_EventCache.tRecords.Debuff.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Npc.Hash2 then
    RaidGrid_EventCache.tRecords.Npc.Hash2 = {}
  end
  if not RaidGrid_EventCache.tRecords.Casting.Hash2 then
    RaidGrid_EventCache.tRecords.Casting.Hash2 = {}
  end
end

l_0_4.OnFrameCreate = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_54_0)
  local l_54_1 = GetClientPlayer()
  if not l_54_1 then
    return 
  end
  if l_54_0 == "RENDER_FRAME_UPDATE" and RaidGrid_EventScrutiny.frameSelf and RaidGrid_EventScrutiny.frameSelf:IsVisible() and RaidGrid_EventCache.frameSelf and RaidGrid_EventCache.frameSelf:IsVisible() then
    local l_54_2, l_54_3 = Station.GetClientSize(true)
    local l_54_4, l_54_5 = RaidGrid_EventScrutiny.frameSelf:GetRelPos()
    local l_54_6, l_54_7 = RaidGrid_EventCache.frameSelf:GetSize()
    local l_54_8, l_54_9 = RaidGrid_EventScrutiny.frameSelf:GetSize()
    if l_54_4 <= l_54_2 / 2 then
      RaidGrid_EventCache.frameSelf:SetRelPos(l_54_4 + l_54_8, l_54_5)
    end
  else
    RaidGrid_EventCache.frameSelf:SetRelPos(l_54_4 - l_54_6, l_54_5)
  end
  do return end
  if l_54_0 == "BUFF_UPDATE" then
    RaidGrid_EventCache.OnUpdateBuffData(arg0, arg1, arg2, arg4, arg5, arg6, arg8, arg9)
  elseif l_54_0 == "NPC_ENTER_SCENE" then
    local l_54_10 = GetNpc(arg0)
    if l_54_10 then
      RaidGrid_EventCache.tSyncEnemyChar[arg0] = l_54_10
      RaidGrid_EventCache.CheckEnemyNpcCreation(l_54_10)
      local l_54_11 = l_54_10.dwTemplateID
      if not RaidGrid_EventCache.tSyncCharFightState[l_54_11] then
        RaidGrid_EventCache.tSyncCharFightState[l_54_11] = {}
      end
      local l_54_12 = RaidGrid_EventCache.tSyncCharFightState[l_54_11]
      local l_54_13 = arg0
      l_54_12[l_54_13] = l_54_10.bFightState or false
      l_54_12 = RaidGrid_EventCache
      l_54_12 = l_54_12.tSyncCharFightState
      l_54_12 = l_54_12[l_54_11]
      l_54_13 = arg0
      l_54_12 = l_54_12[l_54_13]
    end
    if l_54_12 ~= true then
      l_54_12 = RaidGrid_EventCache
      l_54_12 = l_54_12.tSyncCharFightState
      l_54_12 = l_54_12[l_54_11]
      l_54_13 = arg0
      l_54_12 = l_54_12[l_54_13]
    end
    if l_54_12 ~= false then
      l_54_12 = RaidGrid_EventCache
      l_54_12 = l_54_12.tSyncCharFightState
      l_54_12 = l_54_12[l_54_11]
      l_54_13 = arg0
      l_54_12[l_54_13] = false
    end
  elseif l_54_0 == "NPC_LEAVE_SCENE" then
    RaidGrid_EventCache.tSyncEnemyChar[arg0] = nil
  elseif l_54_0 == "DO_SKILL_CAST" then
    RaidGrid_EventCache.OnSkillCasting(arg0, arg1, arg2)
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_54_0 == "SYS_MSG" and arg0 == "UI_OME_SKILL_CAST_LOG" then
    RaidGrid_EventCache.OnSkillCasting(arg1, arg2, arg3)
  end
  do return end
  if l_54_0 == "PLAYER_ENTER_SCENE" and arg0 == l_54_1.dwID then
    RaidGrid_EventCache.szCurrentMapName = RaidGrid_Base.GetCurrentMapName()
  end
end

l_0_4.OnEvent = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  RaidGrid_EventCache.nSetper = RaidGrid_EventCache.nSetper + 1
  if not GetClientPlayer() then
    return 
  end
end

l_0_4.OnFrameBreathe = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  if not RaidGrid_EventCache.bCheckBoxRecall then
    return 
  end
  local l_56_0 = this:GetName()
  if l_56_0:match("CheckBox_Page_") then
    local l_56_1 = l_56_0:sub(15)
    RaidGrid_EventCache.SwitchPageType(l_56_1)
  end
  if RaidGrid_EventScrutiny and RaidGrid_EventScrutiny.wnd then
    RaidGrid_EventScrutiny.SwitchPageType(l_56_1)
  end
end

l_0_4.OnCheckBoxCheck = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  -- upvalues: l_0_1 , l_0_2
  local l_57_0 = this:GetName()
  if l_57_0 == "Btn_PrePage" then
    if IsCtrlKeyDown() then
      RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] = 1
    else
      local l_57_1 = RaidGrid_EventCache.tListPage
      local l_57_2 = RaidGrid_EventCache.szListIndex
      l_57_1[l_57_2] = math.max(1, RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] - 1)
    end
    RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
  elseif l_57_0 == "Btn_NextPage" then
    if not RaidGrid_EventCache.tRecords[RaidGrid_EventCache.szListIndex] then
      local l_57_3 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_57_4 = nil
    local l_57_5 = nil
    if IsCtrlKeyDown() then
      do return end
    end
    RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] = math.min((RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] or 0) + 1, math.max(math.ceil(#l_57_3 / 14), 1))
    RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
  elseif l_57_0 == "Btn_Search" then
    local l_57_6 = RaidGrid_EventCache.wnd:Lookup("Edit_Search")
    local l_57_7 = l_57_6:GetText()
    if l_57_7 and l_57_7 ~= "" then
      if not RaidGrid_EventCache.tRecords[RaidGrid_EventCache.szListIndex] then
        local l_57_8, l_57_9 = {}
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_57_7 ~= l_0_1 or #l_57_8 <= l_0_2 then
        l_0_1 = l_57_7
        l_0_2 = 1
      end
      local l_57_10 = nil
      for l_57_14 = l_0_2, #l_57_10 do
        local l_57_11 = l_0_2
        l_57_11 = l_57_11 + 1
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        if l_57_10[R8_PC126].szName and tostring(l_57_10[R8_PC126].szName):match(l_57_7) then
          local l_57_16 = nil
          local l_57_17 = math.max(math.ceil(#l_57_10 / 14), 1)
          RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] = math.ceil(l_57_15 / 14)
          RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
          if l_57_15 % 14 == 0 then
            local l_57_18, l_57_19 = , 14
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          do
            local l_57_20 = nil
            RaidGrid_EventCache.handleRecords:Lookup("Handle_Record_" .. l_57_19):Lookup("Image_Search"):Show()
          end
          do break end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_0_2 = l_57_11
    end
  else
    if #l_57_10 <= l_0_2 then
      if l_57_0 == "Btn_DelPage" then
        if IsCtrlKeyDown() then
          if not RaidGrid_EventCache.tRecords[RaidGrid_EventCache.szListIndex] then
            local l_57_21 = {}
          end
          do
            local l_57_22 = nil
          end
          local l_57_23 = nil
          for l_57_27 = 0, 13 do
            local l_57_24, l_57_25 = , ((RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] or 1) - 1) * 14 + 1
            if l_57_23[l_57_25] and l_57_23[l_57_25].dwID then
              if l_57_23.Hash2[l_57_23[l_57_25].dwID] and l_57_23[l_57_25].nLevel then
                l_57_23.Hash2[l_57_23[l_57_25].dwID][l_57_23[l_57_25].nLevel] = nil
              end
              if not l_57_23.Hash2[l_57_23[l_57_25].dwID] or RaidGrid_Base.isTableEmpty(l_57_23.Hash2[l_57_23[l_57_25].dwID]) then
                l_57_23.Hash2[l_57_23[l_57_25].dwID] = nil
                l_57_23.Hash[l_57_23[l_57_25].dwID] = nil
              end
              table.remove(l_57_23, l_57_25)
            end
          end
          local l_57_28 = nil
          local l_57_29 = nil
          local l_57_30 = math.max(math.ceil(#l_57_23 / 14), 1)
          RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] = math.min(l_57_28, l_57_30)
          RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
        end
      end
    else
      if IsShiftKeyDown() then
        local l_57_31 = RaidGrid_EventCache.tRecords
        local l_57_32 = RaidGrid_EventCache.szListIndex
        local l_57_33 = {}
        l_57_33.Hash = {}
        l_57_33.Hash2 = {}
        l_57_31[l_57_32] = l_57_33
        l_57_31 = RaidGrid_EventCache
        l_57_31 = l_57_31.tListPage
        l_57_32 = RaidGrid_EventCache
        l_57_32 = l_57_32.szListIndex
        l_57_31[l_57_32] = 1
        l_57_31 = RaidGrid_EventCache
        l_57_31 = l_57_31.UpdateRecordList
        l_57_32 = RaidGrid_EventCache
        l_57_32 = l_57_32.szListIndex
        l_57_31(l_57_32)
      end
    end
  elseif l_57_0 == "Btn_Close" then
    RaidGrid_EventCache.ClosePanel()
  end
end

l_0_4.OnLButtonClick = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_58_0)
  if not RaidGrid_EventCache.tListPage[l_58_0] then
    return 
  end
  if not RaidGrid_EventCache.bCheckBoxRecall then
    return 
  end
  RaidGrid_EventCache.bCheckBoxRecall = false
  RaidGrid_EventCache.szListIndex = l_58_0
  for l_58_4,l_58_5 in pairs(RaidGrid_EventCache.tListPage) do
    local l_58_6 = RaidGrid_EventCache.wnd:Lookup("CheckBox_Page_" .. l_58_4)
    if l_58_0 == l_58_4 then
      l_58_6:Check(true)
      l_58_6:Enable(false)
    else
      l_58_6:Check(false)
      l_58_6:Enable(true)
    end
  end
  RaidGrid_EventCache.UpdateRecordList(l_58_0)
  RaidGrid_EventCache.bCheckBoxRecall = true
end

l_0_4.SwitchPageType = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_59_0, l_59_1, l_59_2)
  local l_59_3 = GetClientPlayer()
  if not l_59_3 then
    return 
  end
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bCacheEnable then
    return 
  end
  if RaidGrid_EventScrutiny.bCastingCacheDungeonOnly and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  local l_59_4 = false
  local l_59_5 = nil
  if not RaidGrid_EventScrutiny.bCastingNPCOnly and GetPlayer(l_59_0) then
    l_59_5 = GetPlayer(l_59_0)
  else
    if GetNpc(l_59_0) then
      l_59_5 = GetNpc(l_59_0)
    end
  else
    return 
  end
  if l_59_5 and (not RaidGrid_EventScrutiny.bCastingBossOnly or RaidGrid_Base.ToGetNpcIntensity(l_59_5) >= 4) and (not RaidGrid_EventCache.tRecords.Casting.Hash2[l_59_1] or not RaidGrid_EventCache.tRecords.Casting.Hash2[l_59_1][l_59_2]) then
    local l_59_6 = Table_GetSkillName(l_59_1, l_59_2)
    if not l_59_6 or l_59_6 == "" then
      l_59_6 = "����" .. tostring(l_59_1)
    end
  end
  if l_59_6 then
    local l_59_7 = {}
    l_59_7.szType = "Casting"
    l_59_7.dwID = l_59_1
    l_59_7.nLevel = l_59_2
    l_59_7.szName = l_59_6
    l_59_7.bIsVisible = true
    if not Table_GetSkillIconID(l_59_1, l_59_2) then
      l_59_7.nIconID = Table_GetSkillIconID(608, 1)
    end
    if l_59_7.nIconID <= 0 then
      l_59_7.nIconID = 332
    end
    l_59_7.szMapName = RaidGrid_EventCache.szCurrentMapName or "�޷���ȡ"
    l_59_7.szCasterName = l_59_5.szName or "�޷���ȡ"
    RaidGrid_EventCache.tRecords.Casting.Hash[l_59_1] = true
    if not RaidGrid_EventCache.tRecords.Casting.Hash2[l_59_1] then
      RaidGrid_EventCache.tRecords.Casting.Hash2[l_59_1] = {}
    end
    RaidGrid_EventCache.tRecords.Casting.Hash2[l_59_1][l_59_2] = true
    table.insert(RaidGrid_EventCache.tRecords.Casting, 1, l_59_7)
    if RaidGrid_EventScrutiny.nCastingAutoRemoveCachePage then
      local l_59_8 = 14 * RaidGrid_EventScrutiny.nCastingAutoRemoveCachePage + 1
      for l_59_12 = l_59_8, #RaidGrid_EventCache.tRecords.Casting do
        if RaidGrid_EventCache.tRecords.Casting.Hash2[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID] then
          RaidGrid_EventCache.tRecords.Casting.Hash2[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID][RaidGrid_EventCache.tRecords.Casting[l_59_12].nLevel] = nil
        end
        if not RaidGrid_EventCache.tRecords.Casting.Hash2[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID] or RaidGrid_Base.isTableEmpty(RaidGrid_EventCache.tRecords.Casting.Hash2[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID]) then
          RaidGrid_EventCache.tRecords.Casting.Hash2[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID] = nil
          RaidGrid_EventCache.tRecords.Casting.Hash[RaidGrid_EventCache.tRecords.Casting[l_59_12].dwID] = nil
        end
        RaidGrid_EventCache.tRecords.Casting[l_59_12] = nil
      end
    end
    l_59_4 = true
  end
  if RaidGrid_EventScrutiny.bAddByNameEnable and RaidGrid_EventCache.tAddByName[l_59_7.szType][l_59_7.szName] then
    RaidGrid_EventScrutiny.AddRecordToList(l_59_7, l_59_7.szType)
  end
  if RaidGrid_EventCache.szListIndex == "Casting" and l_59_4 then
    RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
  end
end

l_0_4.OnSkillCasting = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_60_0)
  local l_60_1 = GetClientPlayer()
  if not l_60_1 then
    return 
  end
  if not l_60_0 then
    return 
  end
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bCacheEnable then
    return 
  end
  if RaidGrid_EventScrutiny.bNpcCacheDungeonOnly and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  if RaidGrid_EventCache.tRecords.Npc.Hash[l_60_0.dwTemplateID] then
    return 
  end
  local l_60_2 = {}
  l_60_2.szType = "Npc"
  l_60_2.dwID = l_60_0.dwTemplateID
  l_60_2.szName = l_60_0.szName
  if not l_60_2.szName or l_60_2.szName == "" then
    l_60_2.szName = tostring(l_60_0.dwTemplateID)
  end
  l_60_2.bIsVisible = true
  if not NPC_GetHeadImageFile then
    NPC_GetHeadImageFile = function()
  end
  end
  local l_60_3 = NPC_GetHeadImageFile(l_60_0.dwModelID)
  if IsFileExist(l_60_3) then
    l_60_2.szIconPath = l_60_3
  else
    local l_60_4 = GetNpcHeadImage(l_60_0.dwID)
    l_60_2.nIconFrame = l_60_0.dwID
    l_60_2.szIconPath = l_60_4
  end
  if IsEnemy(l_60_1.dwID, l_60_0.dwID) then
    l_60_2.bEnemy = true
  else
    l_60_2.bEnemy = false
  end
  l_60_2.szMapName = RaidGrid_EventCache.szCurrentMapName or "�޷���ȡ"
  if RaidGrid_Base.ToGetNpcIntensity(l_60_0) >= 4 then
    l_60_2.bBossIntensity = true
  end
  RaidGrid_EventCache.tRecords.Npc.Hash[l_60_0.dwTemplateID] = true
  table.insert(RaidGrid_EventCache.tRecords.Npc, 1, l_60_2)
  if RaidGrid_EventScrutiny.nNpcAutoRemoveCachePage then
    local l_60_5 = 14 * RaidGrid_EventScrutiny.nNpcAutoRemoveCachePage + 1
    for l_60_9 = l_60_5, #RaidGrid_EventCache.tRecords.Npc do
      RaidGrid_EventCache.tRecords.Npc.Hash[RaidGrid_EventCache.tRecords.Npc[l_60_9].dwID] = nil
      RaidGrid_EventCache.tRecords.Npc[l_60_9] = nil
    end
  end
  if RaidGrid_EventScrutiny.bAddByNameEnable and RaidGrid_EventCache.tAddByName[l_60_2.szType][l_60_2.szName] then
    RaidGrid_EventScrutiny.AddRecordToList(l_60_2, l_60_2.szType)
  end
  if RaidGrid_EventCache.szListIndex == "Npc" then
    RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
  end
end

l_0_4.CheckEnemyNpcCreation = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_61_0, l_61_1, l_61_2, l_61_3, l_61_4, l_61_5, l_61_6, l_61_7)
  if not l_61_6 then
    l_61_6 = 1
  end
  local l_61_8 = GetClientPlayer()
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bCacheEnable then
    return 
  end
  if RaidGrid_EventScrutiny.bBuffCacheDungeonOnly and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  local l_61_9 = nil
  if IsPlayer(l_61_0) then
    l_61_9 = GetPlayer(l_61_0)
  else
    l_61_9 = GetNpc(l_61_0)
  end
  if l_61_1 or not l_61_8 or not l_61_9 then
    return 
  end
  if not l_61_3 or l_61_3 <= 0 then
    return 
  end
  if l_61_6 <= 0 then
    return 
  end
  local l_61_10 = Table_BuffIsVisible(l_61_3, l_61_6)
  if RaidGrid_EventScrutiny.bBuffCacheVisibleOnly and not l_61_10 then
    return 
  end
  local l_61_11 = Table_GetBuffName(l_61_3, l_61_6)
  if not l_61_11 or l_61_11 == "" then
    l_61_11 = "����" .. tostring(l_61_3)
  end
  local l_61_12 = {}
  if l_61_9 then
    l_61_12 = l_61_9.GetBuffList()
  else
    l_61_12 = l_61_8.GetBuffList()
  end
  if not l_61_12 then
    return 
  end
  local l_61_13 = {}
  for l_61_17,l_61_18 in ipairs(l_61_12) do
    if l_61_3 == l_61_18.dwID then
      l_61_13 = l_61_18
  else
    end
  end
  if not l_61_13.dwID then
    return 
  end
  local l_61_19, l_61_29 = not l_61_13.bCanCancel
  l_61_29 = RaidGrid_EventCache
  l_61_29 = l_61_29.tRecords
  l_61_29 = l_61_29.Buff
  local l_61_20, l_61_30 = nil
  if l_61_19 then
    l_61_20 = RaidGrid_EventCache
    l_61_20 = l_61_20.tRecords
    l_61_29 = l_61_20.Debuff
  end
  l_61_20 = l_61_29.Hash2
  l_61_20 = l_61_20[l_61_3]
  if l_61_20 then
    l_61_20 = l_61_29.Hash2
    l_61_20 = l_61_20[l_61_3]
    l_61_20 = l_61_20[l_61_6]
  end
  if l_61_20 then
    return 
  end
  local l_61_21, l_61_31 = nil
  if l_61_19 then
    l_61_30 = Table_GetBuffIconID
    l_61_21 = l_61_3
    l_61_31 = l_61_6
    l_61_30 = l_61_30(l_61_21, l_61_31)
    if not l_61_30 then
      l_61_30 = 1435
    end
    l_61_30, l_61_20 = l_61_20.nIconID, {szType = "Buff", szType = "Debuff", bIsDebuff = l_61_19, buff = l_61_13, dwID = l_61_3, nLevel = l_61_6, szName = l_61_11, bIsVisible = l_61_10, nIconID = l_61_30}
    if l_61_30 <= 0 then
      l_61_20.nIconID = 1435
    end
    l_61_30 = GetLogicFrameCount
    l_61_30 = l_61_30()
    local l_61_22, l_61_32 = nil
    if not l_61_5 then
      l_61_5 = l_61_30
    end
    l_61_21 = l_61_5 - l_61_30
    l_61_31 = GLOBAL
    l_61_31 = l_61_31.GAME_FPS
    l_61_21 = (l_61_21) / l_61_31
    if not l_61_21 then
      l_61_21 = 0
    end
    l_61_20.fKeepTime = l_61_21
    l_61_21 = RaidGrid_EventCache
    l_61_21 = l_61_21.szCurrentMapName
    if not l_61_21 then
      l_61_21 = "�޷���ȡ"
    end
    l_61_20.szMapName = l_61_21
    l_61_21 = l_61_13.dwSkillSrcID
    if l_61_21 then
      l_61_21 = l_61_13.dwSkillSrcID
    end
    if l_61_21 > 0 then
      l_61_21 = ""
      local l_61_23 = nil
      l_61_31 = RaidGrid_Base
      l_61_31 = l_61_31.GetNameAndTypeFromId
      l_61_22 = l_61_13.dwSkillSrcID
      l_61_31 = l_61_31(l_61_22)
      l_61_21 = 
      l_61_20.szCasterName = l_61_31
    end
    if l_61_21 == "Player" then
      l_61_31 = "����ң�"
      l_61_22 = l_61_20.szCasterName
      l_61_31 = l_61_31 .. l_61_22
      l_61_20.szCasterName = l_61_31
    end
    l_61_21 = l_61_29.Hash
    l_61_21[l_61_3] = true
    l_61_21 = l_61_29.Hash2
    l_61_31 = l_61_29.Hash2
    l_61_31 = l_61_31[l_61_3]
    if not l_61_31 then
      l_61_21[l_61_3], l_61_31 = l_61_31, {}
    end
    l_61_21 = l_61_29.Hash2
    l_61_21 = l_61_21[l_61_3]
    l_61_21[l_61_6] = true
    l_61_21 = table
    l_61_21 = l_61_21.insert
    l_61_31 = l_61_29
    l_61_22 = 1
    l_61_32 = l_61_20
    l_61_21(l_61_31, l_61_22, l_61_32)
    l_61_21 = RaidGrid_EventScrutiny
    l_61_21 = l_61_21.nBuffAutoRemoveCachePage
    if l_61_21 then
      l_61_21 = RaidGrid_EventScrutiny
      l_61_21 = l_61_21.nBuffAutoRemoveCachePage
      l_61_21 = 14 * l_61_21
      l_61_21 = l_61_21 + 1
      local l_61_24 = nil
      l_61_31 = l_61_21
      l_61_22 = #l_61_29
      l_61_32 = 1
      for l_61_24 = l_61_31, l_61_22, l_61_32 do
        do
          local l_61_25, l_61_26, l_61_27, l_61_28 = nil
          l_61_25 = l_61_29.Hash2
          l_61_26 = l_61_29[l_61_24]
          l_61_26 = l_61_26.dwID
          l_61_25 = l_61_25[l_61_26]
          if l_61_25 then
            l_61_25 = l_61_29.Hash2
            l_61_26 = l_61_29[l_61_24]
            l_61_26 = l_61_26.dwID
            l_61_25 = l_61_25[l_61_26]
            l_61_26 = l_61_29[l_61_24]
            l_61_26 = l_61_26.nLevel
            l_61_25[l_61_26] = nil
          end
          l_61_25 = l_61_29.Hash2
          l_61_26 = l_61_29[l_61_24]
          l_61_26 = l_61_26.dwID
          l_61_25 = l_61_25[l_61_26]
          if l_61_25 then
            l_61_25 = RaidGrid_Base
            l_61_25 = l_61_25.isTableEmpty
            l_61_26 = l_61_29.Hash2
            l_61_27 = l_61_29[l_61_24]
            l_61_27 = l_61_27.dwID
            l_61_26 = l_61_26[l_61_27]
            l_61_25 = l_61_25(l_61_26)
          if l_61_25 then
            end
          end
          l_61_25 = l_61_29.Hash2
          l_61_26 = l_61_29[l_61_24]
          l_61_26 = l_61_26.dwID
          l_61_25[l_61_26] = nil
          l_61_25 = l_61_29.Hash
          l_61_26 = l_61_29[l_61_24]
          l_61_26 = l_61_26.dwID
          l_61_25[l_61_26] = nil
          l_61_29[l_61_24] = nil
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
    l_61_21 = RaidGrid_EventScrutiny
    l_61_21 = l_61_21.bAddByNameEnable
    if l_61_21 then
      l_61_21 = RaidGrid_EventCache
      l_61_21 = l_61_21.tAddByName
      l_61_21 = l_61_21[l_61_20.szType]
      l_61_21 = l_61_21[l_61_20.szName]
    end
    if l_61_21 then
      l_61_21 = RaidGrid_EventScrutiny
      l_61_21 = l_61_21.AddRecordToList
      l_61_21(l_61_20, l_61_20.szType)
    end
    l_61_21 = RaidGrid_EventCache
    l_61_21 = l_61_21.szListIndex
    if l_61_21 == l_61_20.szType then
      l_61_21 = RaidGrid_EventCache
      l_61_21 = l_61_21.UpdateRecordList
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      l_61_21(RaidGrid_EventCache.szListIndex)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 134 
end

l_0_4.OnUpdateBuffData = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  -- upvalues: l_0_3
  local l_62_0 = RaidGrid_EventCache.handleRecords
  if not l_62_0 then
    return 
  end
  l_62_0:Clear()
  for l_62_4 = 1, 14 do
    local l_62_5 = l_62_0:AppendItemFromIni(l_0_3, "Handle_RecordDummy", "Handle_Record_" .. l_62_4)
    l_62_5:SetRelPos(0, (l_62_4 - 1) * 24.7 + 3)
    l_62_5.OnItemMouseEnter = function()
      this.imageCover:Show()
    end
    l_62_5.OnItemMouseLeave = function()
      this.imageCover:Hide()
    end
    l_62_5.OnItemLButtonClick = function()
    end
    l_62_5.OnItemRButtonClick = function()
      RaidGrid_EventCache.PopRBOptions(this)
    end
    l_62_5.box = l_62_5:Lookup("Box_Icon")
    l_62_5.box:Show()
    l_62_5.box:SetObject(1, 0)
    l_62_5.box:ClearObjectIcon()
    l_62_5.box:SetObjectIcon(1435)
    l_62_5.box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
    l_62_5.box:SetOverTextFontScheme(0, 15)
    l_62_5.box:SetOverText(0, "")
    l_62_5.box.handleParent = l_62_5
    l_62_5.box.OnItemMouseEnter = function()
      local l_67_0 = this.handleParent.tRecord
      if l_67_0 and l_67_0.dwID then
        local l_67_1, l_67_2 = this:GetAbsPos()
        local l_67_3, l_67_4 = this:GetSize()
        if l_67_0.szType == "Buff" or l_67_0.szType == "Debuff" then
          local l_67_5 = OutputBuffTip
          local l_67_6 = GetClientPlayer().dwID
          local l_67_7 = l_67_0.dwID
          do
            local l_67_8 = l_67_0.nLevel or 1
          end
          local l_67_9 = nil
          local l_67_10 = 1
          local l_67_11 = false
          local l_67_12 = 999
          l_67_5(l_67_6, l_67_7, l_67_9, l_67_10, l_67_11, l_67_12, {l_67_1, l_67_2, l_67_3, l_67_4})
        end
      elseif l_67_0.szType == "Npc" then
        local l_67_13 = RaidGrid_Base.OutputNpcInfoTip
        local l_67_14 = l_67_0.dwID
        local l_67_15 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_67_13(l_67_14, l_67_15)
      elseif l_67_0.szType == "Casting" then
        local l_67_16 = OutputSkillTip
        local l_67_17 = l_67_0.dwID
        do
          local l_67_18 = l_67_0.nLevel or 1
        end
        local l_67_19 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_67_16(l_67_17, l_67_19, {l_67_2, l_67_3, l_67_4, l_67_4})
      end
    end
    l_62_5.box.OnItemMouseLeave = function()
      RaidGrid_Base.HideTip()
    end
    l_62_5.imageBoxBG = l_62_5:Lookup("Image_BGBox")
    l_62_5.imageBoxBG.handleParent = l_62_5
    l_62_5.imageBoxBG.OnItemMouseEnter = l_62_5.box.OnItemMouseEnter
    l_62_5.imageBoxBG.OnItemMouseLeave = l_62_5.box.OnItemMouseLeave
    l_62_5.text = l_62_5:Lookup("Text_Name")
    l_62_5.text:SetText("")
    l_62_5.imageGrid = l_62_5:Lookup("Image_BGGrid")
    l_62_5.imageGrid.nFrame = 999
    l_62_5.imageCover = l_62_5:Lookup("Image_Cover")
    l_62_5:Hide()
  end
  l_62_0:FormatAllItemPos()
end

l_0_4.InitRecordHandles = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_63_0)
  if not l_63_0 then
    return 
  end
  l_63_0.box:SetObjectIcon(1435)
  l_63_0.dwID = nil
  l_63_0.tRecord = nil
  l_63_0:Hide()
end

l_0_4.ClearRecordHandle = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_64_0, l_64_1)
  if not l_64_0 or not l_64_1 then
    return 
  end
  l_64_0:Lookup("Image_Search"):Hide()
  l_64_0.dwID = l_64_1.dwID
  l_64_0.tRecord = l_64_1
  local l_64_2 = l_64_1.szName
  if not l_64_1.bIsVisible then
    l_64_2 = l_64_2 .. "����"
  end
  l_64_0.text:SetText(l_64_2)
  if RaidGrid_EventScrutiny.IsRecordInList(l_64_1, RaidGrid_EventCache.szListIndex) then
    l_64_0:Lookup("Image_Scrutiny"):Show()
  else
    l_64_0:Lookup("Image_Scrutiny"):Hide()
  end
  if l_64_1.bEnemy == true then
    l_64_0.text:SetFontColor(255, 128, 128)
  elseif l_64_1.bEnemy == false then
    l_64_0.text:SetFontColor(255, 255, 128)
  else
    l_64_0.text:SetFontColor(255, 255, 255)
  end
  if l_64_1.bIsDebuff == true and l_64_0.imageGrid.nFrame ~= 1 then
    l_64_0.imageGrid:SetFrame(1)
  elseif l_64_1.bIsDebuff == false and l_64_0.imageGrid.nFrame ~= 13 then
    l_64_0.imageGrid:SetFrame(13)
  else
    if l_64_0.imageGrid.nFrame ~= 14 then
      l_64_0.imageGrid:SetFrame(14)
    end
  end
  l_64_0.box:SetObjectIcon(l_64_1.nIconID or 1435)
  if l_64_1.szIconPath then
    l_64_0.box:Hide()
    if l_64_1.nIconFrame then
      l_64_0.imageBoxBG:FromUITex(l_64_1.szIconPath, l_64_1.nIconFrame)
    else
      l_64_0.imageBoxBG:FromTextureFile(l_64_1.szIconPath)
    end
  else
    l_64_0.box:Show()
  end
  l_64_0:Show()
end

l_0_4.ShowRecordHandle = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function(l_65_0)
  local l_65_1 = RaidGrid_EventCache.handleRecords
  if not l_65_1 then
    return 
  end
  local l_65_2 = RaidGrid_EventCache.tRecords[RaidGrid_EventCache.szListIndex]
  if not l_65_2 then
    return 
  end
  local l_65_3 = math.max(math.ceil(#l_65_2 / 14), 1)
  local l_65_4 = math.min(RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] or 1, l_65_3)
  RaidGrid_EventCache.tListPage[l_65_0] = l_65_4
  RaidGrid_EventCache.handleMain:Lookup("Text_PageCurrent"):SetText(l_65_4)
  local l_65_5 = 14 * (l_65_4 - 1) + 1
  for l_65_9 = 1, 14 do
    local l_65_10 = l_65_1:Lookup("Handle_Record_" .. l_65_9)
    if l_65_10 then
      local l_65_11 = l_65_2[l_65_5 + l_65_9 - 1]
      if l_65_11 then
        RaidGrid_EventCache.ShowRecordHandle(l_65_10, l_65_11)
      end
    else
      RaidGrid_EventCache.ClearRecordHandle(l_65_10)
    end
  end
end

l_0_4.UpdateRecordList = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  if not Station.Lookup("Normal/RaidGrid_EventCache") then
    local l_66_0, l_66_1, l_66_2, l_66_3, l_66_4, l_66_5, l_66_6, l_66_7, l_66_8, l_66_9, l_66_10, l_66_11 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_EventCache.ini", "RaidGrid_EventCache")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_66_0:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_66_0:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_EventCache.frameSelf = l_66_0
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_EventCache.wnd = l_66_0:Lookup("Wnd_Cache")
  RaidGrid_EventCache.handleMain = RaidGrid_EventCache.wnd:Lookup("", "")
  RaidGrid_EventCache.handleRecords = RaidGrid_EventCache.handleMain:Lookup("Handle_Caches")
  RaidGrid_EventCache.handleMain:Lookup("Handle_RecordDummy"):Hide()
  RaidGrid_EventCache.InitRecordHandles()
  RaidGrid_EventCache.SwitchPageType(RaidGrid_EventCache.szListIndex)
end

l_0_4.OpenPanel = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  local l_67_0 = Station.Lookup("Normal/RaidGrid_EventCache")
  if l_67_0 then
    local l_67_1, l_67_2 = l_67_0:IsVisible, l_67_0
    return l_67_1(l_67_2)
  end
end

l_0_4.IsOpened = l_0_5
l_0_4 = RaidGrid_EventCache
l_0_5 = function()
  local l_68_0 = Station.Lookup("Normal/RaidGrid_EventCache")
  if l_68_0 then
    l_68_0:Hide()
  end
end

l_0_4.ClosePanel = l_0_5
l_0_4 = "Interface/RaidGrid_EventScrutiny/RaidGrid_EventScrutiny.ini"
AUTO_EVENTTIME_MODE, l_0_5 = l_0_5, {NONE = 1, AVG = 2, MIN = 3}
RaidGrid_EventScrutiny, l_0_5 = l_0_5, {}
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bCheckBoxRecall = true
l_0_5 = RaidGrid_EventScrutiny
l_0_5.nSetper = -1
l_0_5 = RaidGrid_EventScrutiny
l_0_5.frameSelf = nil
l_0_5 = RaidGrid_EventScrutiny
l_0_5.wnd = nil
l_0_5 = RaidGrid_EventScrutiny
l_0_5.handleMain = nil
l_0_5 = RaidGrid_EventScrutiny
l_0_5.handleRecords = nil
l_0_5 = RaidGrid_EventScrutiny
l_0_5.tLastLoc, l_0_6 = l_0_6, {nX = -1, nY = -1}
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.tLastLoc"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bAddToHead = true
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.bAddToHead"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.szListIndex = "Scrutiny"
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.szListIndex"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.tListPage, l_0_6 = l_0_6, {Buff = 1, Debuff = 1, Npc = 1, Casting = 1, Scrutiny = 1}
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.tListPage"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
local l_0_7 = {}
l_0_7.Hash = {}
l_0_7.Hash2 = {}
l_0_7 = {
Hash = {}, 
Hash2 = {}}
l_0_7 = {
Hash = {}, 
Hash2 = {}}
l_0_7 = {
Hash = {}, 
Hash2 = {}}
l_0_7 = {
Hash = {}, 
Hash2 = {}}
l_0_5.tRecords, l_0_6 = l_0_6, {Buff = l_0_7, Debuff = l_0_7, Npc = l_0_7, Casting = l_0_7, Scrutiny = l_0_7}
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = RGES_Settings
l_0_5.tRecords = l_0_6
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.tRecords"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.nRemoveDelayTime = 10
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.nRemoveDelayTime"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bScrutinySelfBuff = true
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.bScrutinySelfBuff"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bScrutinyFightState = true
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.bScrutinyFightState"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bSelfStateOfDeathProcess = true
l_0_5 = RegisterCustomData
l_0_6 = "RaidGrid_EventScrutiny.bSelfStateOfDeathProcess"
l_0_5(l_0_6)
l_0_5 = RaidGrid_EventScrutiny
l_0_5.tFightStateTable = nil
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bLastFightState = false
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bDeathTimeEnd = 0
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bDeathTimeflag = 0
l_0_5 = RaidGrid_EventScrutiny
l_0_5.bSelfInFightState = false
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  this:RegisterEvent("BUFF_UPDATE")
  this:RegisterEvent("NPC_ENTER_SCENE")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("SYS_MSG")
  this:RegisterEvent("FIGHT_HINT")
  if not RaidGrid_EventScrutiny.tRecords.Buff.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Buff.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Debuff.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Debuff.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Npc.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Npc.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Casting.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Casting.Hash2 = {}
  end
  if not RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2 then
    RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2 = {}
  end
end

l_0_5.OnFrameCreate = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  RaidGrid_EventScrutiny.nSetper = RaidGrid_EventScrutiny.nSetper + 1
  local l_70_0 = GetClientPlayer()
  if not l_70_0 then
    return 
  end
  local l_70_1, l_70_2 = RaidGrid_EventScrutiny.frameSelf:GetRelPos()
  if RaidGrid_EventScrutiny.tLastLoc.nX ~= l_70_1 and RaidGrid_EventScrutiny.tLastLoc.nY ~= l_70_2 then
    RaidGrid_Base.SetPanelPos(l_70_1, l_70_2)
  end
  if RaidGrid_EventScrutiny.nSetper % 8 == 0 then
    RaidGrid_EventScrutiny.CheckNpcFightState()
  end
  if RaidGrid_EventScrutiny.nSetper % 4 == 0 then
    RaidGrid_EventScrutiny.RefreshEventHandle()
  end
  RaidGrid_EventScrutiny.CheckFightState()
  RaidGrid_BossCallAlert.GetWarningMessage()
end

l_0_5.OnFrameBreathe = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_71_0)
  local l_71_1 = GetClientPlayer()
  if not l_71_1 then
    return 
  end
  if l_71_0 == "BUFF_UPDATE" then
    RaidGrid_EventScrutiny.OnUpdateBuffData(arg0, arg1, arg2, arg4, arg5, arg6, arg8, arg9)
  elseif l_71_0 == "NPC_ENTER_SCENE" then
    local l_71_2 = GetNpc(arg0)
    if l_71_2 then
      local l_71_3 = l_71_2.dwTemplateID
      RaidGrid_EventScrutiny.OnNpcCreationEvent(l_71_3, l_71_2)
    end
  elseif l_71_0 == "UI_SCALED" then
    RaidGrid_SelfBuffAlert.RescaleBG()
  elseif l_71_0 == "DO_SKILL_CAST" then
    RaidGrid_EventScrutiny.OnSkillCasting(arg0, arg1, arg2)
   -- DECOMPILER ERROR: unhandled construct in 'if'

  elseif l_71_0 == "SYS_MSG" and arg0 == "UI_OME_SKILL_CAST_LOG" then
    RaidGrid_EventScrutiny.OnSkillCasting(arg1, arg2, arg3)
  end
  do return end
  if l_71_0 == "FIGHT_HINT" then
    RaidGrid_EventScrutiny.bSelfInFightState = arg0
  end
end

l_0_5.OnEvent = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_72_0 = this:GetName()
  local l_72_1 = this:GetParent()
  if l_72_0 == "Image_WBox" then
    l_72_1:Lookup("Text_WBox"):SetFontColor(255, 0, 255)
  elseif l_72_0 == "Image_TBox" then
    l_72_1:Lookup("Text_TBox"):SetFontColor(64, 128, 255)
  end
end

l_0_5.OnItemMouseEnter = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_73_0 = this:GetName()
  local l_73_1 = this:GetParent()
  if l_73_0 == "Image_WBox" then
    if l_73_1.tRecord.bChatAlertW then
      l_73_1:Lookup("Text_WBox"):SetFontColor(255, 0, 255)
    else
      l_73_1:Lookup("Text_WBox"):SetFontColor(100, 100, 100)
    end
  elseif l_73_0 == "Image_TBox" then
    if l_73_1.tRecord.bChatAlertT then
      l_73_1:Lookup("Text_TBox"):SetFontColor(64, 128, 255)
    end
  else
    l_73_1:Lookup("Text_TBox"):SetFontColor(100, 100, 100)
  end
end

l_0_5.OnItemMouseLeave = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_74_0 = this:GetName()
  local l_74_1 = this:GetParent()
  if l_74_0 == "Image_WBox" then
    if l_74_1.tRecord.bChatAlertW then
      l_74_1.tRecord.bChatAlertW = nil
      l_74_1:Lookup("Text_WBox"):SetFontColor(100, 100, 100)
    else
      l_74_1.tRecord.bChatAlertW = true
      l_74_1:Lookup("Text_WBox"):SetFontColor(255, 0, 255)
    end
  elseif l_74_0 == "Image_TBox" then
    if l_74_1.tRecord.bChatAlertT then
      l_74_1.tRecord.bChatAlertT = nil
      l_74_1:Lookup("Text_TBox"):SetFontColor(100, 100, 100)
    end
  else
    l_74_1.tRecord.bChatAlertT = true
    l_74_1:Lookup("Text_TBox"):SetFontColor(64, 128, 255)
  end
end

l_0_5.OnItemLButtonClick = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_75_0 = this:GetName()
  if l_75_0 == "Btn_PrePage" then
    if IsCtrlKeyDown() then
      RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] = 1
    else
      local l_75_1 = RaidGrid_EventScrutiny.tListPage
      local l_75_2 = RaidGrid_EventScrutiny.szListIndex
      l_75_1[l_75_2] = math.max(1, RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] - 1)
    end
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  elseif l_75_0 == "Btn_NextPage" then
    if not RaidGrid_EventScrutiny.tRecords[RaidGrid_EventScrutiny.szListIndex] then
      local l_75_3 = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_75_4 = nil
    local l_75_5 = nil
    if IsCtrlKeyDown() then
      do return end
    end
    RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] = math.min((RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] or 0) + 1, math.max(math.ceil(#l_75_3 / 8), 1))
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
  elseif l_75_0 == "Btn_DelPage" then
    if IsCtrlKeyDown() then
      if not RaidGrid_EventScrutiny.tRecords[RaidGrid_EventScrutiny.szListIndex] then
        local l_75_6 = {}
      end
      do
        local l_75_7 = nil
      end
      local l_75_8 = nil
      for l_75_12 = 0, 7 do
        local l_75_9, l_75_10 = , ((RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] or 1) - 1) * 8 + 1
        if l_75_8[l_75_10] and l_75_8[l_75_10].dwID then
          if l_75_8.Hash2[l_75_8[l_75_10].dwID] and l_75_8[l_75_10].nLevel then
            l_75_8.Hash2[l_75_8[l_75_10].dwID][l_75_8[l_75_10].nLevel] = nil
          end
          if not l_75_8.Hash2[l_75_8[l_75_10].dwID] or RaidGrid_Base.isTableEmpty(l_75_8.Hash2[l_75_8[l_75_10].dwID]) then
            l_75_8.Hash2[l_75_8[l_75_10].dwID] = nil
            l_75_8.Hash[l_75_8[l_75_10].dwID] = nil
          end
          table.remove(l_75_8, l_75_10)
        end
      end
      local l_75_13 = nil
      local l_75_14 = nil
      local l_75_15 = math.max(math.ceil(#l_75_8 / 8), 1)
      RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] = math.min(l_75_13, l_75_15)
      RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
    else
      if IsShiftKeyDown() then
        local l_75_16 = RaidGrid_EventScrutiny.tRecords
        local l_75_17 = RaidGrid_EventScrutiny.szListIndex
        local l_75_18 = {}
        l_75_18.Hash = {}
        l_75_18.Hash2 = {}
        l_75_16[l_75_17] = l_75_18
        l_75_16 = RaidGrid_EventScrutiny
        l_75_16 = l_75_16.tListPage
        l_75_17 = RaidGrid_EventScrutiny
        l_75_17 = l_75_17.szListIndex
        l_75_16[l_75_17] = 1
        l_75_16 = RaidGrid_EventScrutiny
        l_75_16 = l_75_16.UpdateRecordList
        l_75_17 = RaidGrid_EventScrutiny
        l_75_17 = l_75_17.szListIndex
        l_75_16(l_75_17)
      end
    end
  elseif l_75_0 == "Btn_Close" then
    RaidGrid_EventScrutiny.ClosePanel()
  elseif l_75_0 == "Btn_Options" then
    RaidGrid_EventScrutiny.PopMainOptions()
  end
end

l_0_5.OnLButtonClick = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  if not RaidGrid_EventScrutiny.bCheckBoxRecall then
    return 
  end
  local l_76_0 = this:GetName()
  if l_76_0:match("CheckBox_Page_") then
    local l_76_1 = l_76_0:sub(15)
    RaidGrid_EventScrutiny.SwitchPageType(l_76_1)
    if l_76_1 ~= "Scrutiny" then
      if not RaidGrid_EventCache.IsOpened() then
        RaidGrid_EventCache.OpenPanel()
      end
      RaidGrid_EventCache.SwitchPageType(l_76_1)
    else
      RaidGrid_EventCache.ClosePanel()
    end
  else
    if l_76_0:match("CheckBox_SelfBuff") then
      RaidGrid_EventScrutiny.bBuffChatAlertEnable = true
      RaidGrid_EventScrutiny.bCastingChatAlertEnable = true
      RaidGrid_EventScrutiny.bNpcChatAlertEnable = true
      RaidGrid_BossCallAlert.bChatAlertEnable = true
      RaidGrid_EventScrutiny.bSkillTimerSay = true
    end
  end
end

l_0_5.OnCheckBoxCheck = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  if not RaidGrid_EventScrutiny.bCheckBoxRecall then
    return 
  end
  local l_77_0 = this:GetName()
  if l_77_0:match("CheckBox_SelfBuff") then
    RaidGrid_EventScrutiny.bBuffChatAlertEnable = false
    RaidGrid_EventScrutiny.bCastingChatAlertEnable = false
    RaidGrid_EventScrutiny.bNpcChatAlertEnable = false
    RaidGrid_BossCallAlert.bChatAlertEnable = false
    RaidGrid_EventScrutiny.bSkillTimerSay = false
  end
end

l_0_5.OnCheckBoxUncheck = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_78_0, l_78_1)
  if not l_78_1 then
    l_78_0.bLinkNpcFightState = nil
    l_78_0.szLinkNpcName = nil
    l_78_0.dwLinkNpcTID = nil
    l_78_0.bNormalCountdownType = nil
    RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
    return 
  end
  local l_78_2 = GetClientPlayer()
  if not l_78_2 then
    return 
  end
  local l_78_3, l_78_4 = l_78_2.GetTarget()
   -- DECOMPILER ERROR: unhandled construct in 'if'

  if (not l_78_4 or l_78_4 <= 0 or IsPlayer(l_78_4)) and l_78_0.szType == "Npc" then
    local l_78_5 = ""
    l_78_5 = l_78_5 .. "<Text>text=" .. EncodeComponentsString(" ע�⣺��ǰĿ�겻��Npc������Ҫ������Npc�������ս����ʱ��\n\n") .. " font=2 r=255 g=255 b=255</text>"
    l_78_5 = l_78_5 .. "<Text>text=" .. EncodeComponentsString("���棺�ù�����Ҫ����Bossս����ʱ���������֪������ĺ����벻Ҫ��ȷ����") .. " font=162 r=255 g=0 b=0</text>"
    local l_78_6 = {}
    l_78_6.szMessage = l_78_5
    l_78_6.bRichText = true
    l_78_6.szName = "RaidGrid_EventScrutiny_BossTimer"
    local l_78_7 = {}
    l_78_7.szOption = g_tStrings.STR_HOTKEY_SURE
    l_78_7.fnAction = function()
      -- upvalues: l_78_0
      local l_79_0 = "����ʱ��"
      local l_79_1 = GetNpcTemplate(l_78_0.dwID)
      local l_79_2 = RaidGrid_Base.ToGetNpcIntensity(l_79_1)
      if l_79_2 >= 4 then
        l_79_0 = l_79_0 .. "��"
      end
      l_78_0.bLinkNpcFightState = true
      l_78_0.szLinkNpcName = l_79_0 .. l_78_0.szName
      l_78_0.dwLinkNpcTID = l_78_0.dwID
      l_78_0.bNormalCountdownType = true
      l_78_0.nEventAlertTime = 1200
      l_78_0.bNotAppearScrutiny = true
      RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
    end
    local l_78_8 = {}
    l_78_8.szOption = g_tStrings.STR_HOTKEY_CANCEL
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_78_7 = MessageBox
    l_78_8 = l_78_6
    l_78_7(l_78_8)
  end
  return 
  local l_78_9 = GetNpc(l_78_4)
  if not l_78_9 then
    return 
  end
  local l_78_10 = ""
  if l_78_9.dwTemplateID == l_78_0.dwID then
    l_78_10 = "����ʱ��"
    l_78_0.bNormalCountdownType = true
    l_78_0.nEventAlertTime = 1200
    l_78_0.bNotAppearScrutiny = true
  end
  if RaidGrid_Base.ToGetNpcIntensity(l_78_9) >= 4 then
    l_78_10 = l_78_10 .. "��"
  end
  l_78_0.bLinkNpcFightState = true
  l_78_0.szLinkNpcName = l_78_10 .. l_78_9.szName
  l_78_0.dwLinkNpcTID = l_78_9.dwTemplateID
  RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
end

l_0_5.LinkNpcFightState = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  if not RaidGrid_EventScrutiny.bBuffShowTime or not RaidGrid_CTM_Edition or not RaidGrid_Party or not RaidGrid_CTM_Edition.IsOpened() or not RaidGrid_EventScrutiny.bBuffTeamScrutinyEnable then
    return 
  end
  for l_79_3 = 0, 4 do
    for l_79_7 = 0, 4 do
      local l_79_8 = RaidGrid_Party.GetHandleRoleInGroup(l_79_7, l_79_3)
      if l_79_8 and l_79_8.dwMemberID then
        RaidGrid_EventScrutiny.RefreshCTMBuffHandle(l_79_8)
      end
    end
  end
end

l_0_5.RedrawAllBuffBox = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_80_0, l_80_1, l_80_2, l_80_3)
  local l_80_4 = -1
  if l_80_2 then
    l_80_4 = l_80_1
  end
  if not l_80_0 then
    return 
  end
  local l_80_5 = l_80_0:Lookup("Handle_Buff_Boxes")
  if not l_80_5 then
    return 
  end
  local l_80_6 = (GetLogicFrameCount())
  local l_80_7, l_80_8 = nil, nil
  for l_80_12 = 1, 4 do
    local l_80_13 = l_80_5:Lookup("Box_" .. l_80_12)
    local l_80_14 = l_80_5:Lookup("Shadow_BuffColor_" .. l_80_12)
    local l_80_15 = l_80_5:Lookup("Text_Time_" .. l_80_12)
    if not l_80_13.tInfo or not l_80_13.nEndFrame or l_80_13.nEndFrame <= l_80_6 or l_80_13.tInfo.dwID == l_80_4 then
      l_80_15:Hide()
      l_80_14:Hide()
      l_80_13:Hide()
      l_80_13.tInfo = nil
      l_80_13.nEndFrame = nil
    else
      l_80_15:SetText(RaidGrid_Base.Time2String(((l_80_13.nEndFrame or l_80_6) - l_80_6) / GLOBAL.GAME_FPS))
    end
    if not l_80_13.tInfo.nPriorityLevel then
      local l_80_16 = not l_80_13.tInfo or not l_80_3 or 1
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if not l_80_8 or (l_80_8.box.tInfo.nPriorityLevel or l_80_16 < l_80_16 >= l_80_3.nPriorityLevel or 1 or 1) then
      l_80_8 = {}
      l_80_8.box = l_80_13
      l_80_8.shadow = l_80_14
      l_80_8.text = l_80_15
    end
    if RaidGrid_EventScrutiny.bScreenHeadMonitor and l_80_13.tInfo and not l_80_3 and l_80_13.tInfo.bScreenHead then
      RaidGrid_ScreenHead.addAlarmFrame(l_80_0.dwMemberID, l_80_13.tInfo, true)
    end
    if (not l_80_7 and not l_80_13.tInfo) or l_80_13.tInfo and l_80_13.tInfo.dwID == l_80_1 then
      l_80_7 = {}
      l_80_7.box = l_80_13
      l_80_7.shadow = l_80_14
      l_80_7.text = l_80_15
    end
  end
  if not l_80_7 then
    l_80_7 = l_80_8
  end
  return l_80_7
end

l_0_5.RefreshCTMBuffHandle = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_81_0, l_81_1, l_81_2, l_81_3, l_81_4, l_81_5, l_81_6, l_81_7)
  if not l_81_0 or l_81_0.bNotAddToCTM or not RaidGrid_CTM_Edition or not RaidGrid_Party or not RaidGrid_CTM_Edition.IsOpened or not RaidGrid_CTM_Edition.IsOpened() then
    return 
  end
  local l_81_8, l_81_9 = RaidGrid_Party.GetMemberIndexInGroup(l_81_1)
  if not l_81_8 then
    return 
  end
  local l_81_10 = RaidGrid_Party.GetHandleRoleInGroup(l_81_8, l_81_9)
  local l_81_11 = RaidGrid_EventScrutiny.RefreshCTMBuffHandle(l_81_10, l_81_4, l_81_2, l_81_0)
  if not l_81_11 then
    return 
  end
  if l_81_2 then
    l_81_11.text:Hide()
    l_81_11.box:Hide()
    l_81_11.shadow:Hide()
    l_81_11.box.tInfo = nil
    l_81_11.box.nEndFrame = nil
  else
    if RaidGrid_EventScrutiny.bBuffShowTime then
      l_81_11.text:Show()
    else
      l_81_11.text:Hide()
    end
    if RaidGrid_EventScrutiny.bBuffShowIcon then
      local l_81_12 = 20 * RaidGrid_Party.fScaleIcon
      l_81_11.box:SetSize(l_81_12, l_81_12)
      l_81_11.box:Show()
    else
      l_81_11.box:Hide()
    end
    do
      if RaidGrid_EventScrutiny.bBuffShowShadow then
        local l_81_14 = nil
        local l_81_13 = 37 * RaidGrid_Party.fScaleShadowY
        l_81_11.shadow:SetSize(l_81_14, l_81_13)
        l_81_11.shadow:Show()
    end
     -- DECOMPILER ERROR: Overwrote pending register.

    else
      l_81_14:Hide()
    end
    l_81_11.box.tInfo = l_81_0
    l_81_11.box.nEndFrame = l_81_6
    l_81_11.box:SetObjectIcon(l_81_0.nIconID or 1435)
    if l_81_5 > 1 then
      l_81_11.box:SetOverText(0, tostring(l_81_5))
    else
      l_81_11.box:SetOverText(0, "")
    end
    if l_81_0.tRGBuffColor[3] or not l_81_0.tRGBuffColor[2] and not l_81_0.tRGBuffColor[1] and not l_81_0.tRGBuffColor or 0 > 64 or 0 > 64 or 0 <= 64 then
      l_81_11.shadow:Hide()
    end
  else
    l_81_11.shadow:SetColorRGB(l_81_0.tRGBuffColor[1] or 0, l_81_0.tRGBuffColor[2] or 0, l_81_0.tRGBuffColor[3] or 0)
    l_81_11.shadow:SetAlpha((RaidGrid_EventScrutiny.nBuffShowShadowAlpha or 0.6) * 255)
  end
end

l_0_5.UpdateCTMBuffAlert = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_82_0, l_82_1, l_82_2, l_82_3, l_82_4, l_82_5, l_82_6, l_82_7)
  if not l_82_0 or l_82_0.bNotAddToCTM or not RaidGridEx or not RaidGridEx.IsOpened or not RaidGridEx.IsOpened() then
    return 
  end
  if RaidGrid_EventScrutiny.bRaidGridExSelfDisable then
    RaidGridEx.OnUpdateBuffData = function()
  end
  end
  local l_82_8 = Table_GetBuffName(l_82_4, l_82_7)
  if not l_82_8 or l_82_8 == "" then
    return 
  end
  local l_82_9 = nil
  if RaidGridEx.GetRoleHandleByID then
    l_82_9 = RaidGridEx.GetRoleHandleByID(l_82_1)
  end
  if not l_82_9 and RaidGridEx.GetHandleByID then
    l_82_9 = RaidGridEx.GetHandleByID(l_82_1)
  end
  if not l_82_9 then
    return 
  end
  local l_82_10 = l_82_9.tBoxes
  if not l_82_9.tBoxes then
    RaidGridEx.UpdateMemberBuff(l_82_1)
    l_82_10 = l_82_9.tBoxes
  end
  if l_82_2 then
    for l_82_14 = 1, 4 do
      local l_82_15 = l_82_10[l_82_14]
      if l_82_15.szName == l_82_8 then
        l_82_15.szName = nil
        l_82_15.nIconID = -1
        l_82_15.bShow = false
        l_82_15.nEndFrame = 0
        l_82_15.nRate = 9999
        l_82_15.szColor = nil
        l_82_15.nAlpha = RaidGridEx.nBuffFlashAlpha
        l_82_15.nTrend = 1
        l_82_15:ClearObjectIcon()
        local l_82_16 = l_82_9:Lookup("Shadow_Color")
      end
      if l_82_14 == 1 then
        l_82_16.nEndFrame = 0
        l_82_16.nRate = 9999
        l_82_16:Hide()
      end
    end
    return 
  end
  local l_82_17 = 6 - (l_82_0.nPriorityLevel or 1)
  local l_82_18 = {}
  local l_82_19 = ""
  local l_82_20 = {}
  local l_82_21 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_82_20["��"], l_82_21 = l_82_21, {255, 0, 0}
  l_82_20["��"], l_82_21 = l_82_21, {0, 0, 255}
  l_82_20["��"], l_82_21 = l_82_21, {255, 255, 0}
  l_82_20["��"], l_82_21 = l_82_21, {255, 0, 255}
  l_82_20["��"], l_82_21 = l_82_21, {0, 255, 255}
  l_82_20["��"], l_82_21 = l_82_21, {255, 128, 0}
  l_82_20["��"], l_82_21 = l_82_21, {0, 0, 0}
  l_82_20["��"], l_82_21 = l_82_21, {255, 255, 255}
  l_82_21 = l_82_0.tRGBuffColor
  if l_82_21 then
    l_82_21 = l_82_0.tRGBuffColor
    l_82_21 = l_82_21[1]
    if not l_82_21 then
      l_82_21 = 0
    end
    l_82_18[1] = l_82_21
    l_82_21 = l_82_0.tRGBuffColor
    l_82_21 = l_82_21[2]
    if not l_82_21 then
      l_82_21 = 0
    end
    l_82_18[2] = l_82_21
    l_82_21 = l_82_0.tRGBuffColor
    l_82_21 = l_82_21[3]
    if not l_82_21 then
      l_82_21 = 0
    end
    l_82_18[3] = l_82_21
    l_82_21 = l_82_18[1]
    if l_82_21 == 0 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 0 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 0 then
      l_82_19 = ""
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 255 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 0 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 0 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 0 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 255 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 0 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 0 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 0 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 255 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 255 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 255 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 0 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 255 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 0 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 255 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 0 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 255 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 255 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
    if l_82_21 == 255 then
      l_82_21 = l_82_18[2]
    end
    if l_82_21 == 128 then
      l_82_21 = l_82_18[3]
    end
    if l_82_21 == 0 then
      l_82_19 = "��"
    end
  else
    l_82_21 = l_82_18[1]
  end
  if l_82_21 == 255 then
    l_82_21 = l_82_18[2]
  end
  if l_82_21 == 255 then
    l_82_21 = l_82_18[3]
  end
  if l_82_21 == 255 then
    l_82_19 = "��"
  end
  local l_82_22 = false
  for l_82_26 = 1, 4 do
    local l_82_27 = l_82_10[l_82_26]
    if not l_82_27.nRate then
      l_82_27.nRate = not l_82_27:IsVisible() or 9999
    end
    if l_82_17 <= l_82_27.nRate and not l_82_22 then
      local l_82_28 = Table_GetBuffIconID(l_82_4, l_82_7)
    end
    if l_82_28 then
      l_82_22 = true
      local l_82_29 = table.insert
      local l_82_30 = l_82_21
      local l_82_31 = {}
      l_82_31.szName = l_82_8
      l_82_31.nIconID = l_82_28
      l_82_31.bShow = true
      l_82_31.nEndFrame = l_82_6
      l_82_31.nRate = l_82_17
      l_82_31.szColor = l_82_19
      l_82_31.nAlpha = RaidGridEx.nBuffFlashAlpha
      l_82_31.nTrend = 1
      l_82_29(l_82_30, l_82_31)
    end
    if l_82_8 ~= l_82_27.szName then
      local l_82_32 = table.insert
      local l_82_33 = l_82_21
      local l_82_34 = {}
      l_82_34.szName = l_82_27.szName
      l_82_34.nIconID = l_82_27.nIconID
      l_82_34.bShow = l_82_27.bShow
      l_82_34.nEndFrame = l_82_27.nEndFrame
      l_82_34.nRate = l_82_27.nRate
      l_82_34.szColor = l_82_27.szColor
      l_82_34.nAlpha = l_82_27.nAlpha
      l_82_34.nTrend = l_82_27.nTrend
      l_82_32(l_82_33, l_82_34)
    end
  end
  if not l_82_22 then
    local l_82_35 = Table_GetBuffIconID(l_82_4, l_82_7)
  end
  if l_82_35 then
    local l_82_36 = table.insert
    local l_82_37 = l_82_21
    local l_82_38 = {}
    l_82_38.szName = l_82_8
    l_82_38.nIconID = l_82_35
    l_82_38.bShow = true
    l_82_38.nEndFrame = l_82_6
    l_82_38.nRate = l_82_17
    l_82_38.szColor = l_82_19
    l_82_38.nAlpha = RaidGridEx.nBuffFlashAlpha
    l_82_38.nTrend = 1
    l_82_36(l_82_37, l_82_38)
  end
  for l_82_42 = 4, 1, -1 do
    if l_82_21[l_82_42] then
      l_82_10[l_82_42].szName = l_82_21[l_82_42].szName
      l_82_10[l_82_42].nIconID = l_82_21[l_82_42].nIconID
      l_82_10[l_82_42].bShow = l_82_21[l_82_42].bShow
      l_82_10[l_82_42].nEndFrame = l_82_21[l_82_42].nEndFrame
      l_82_10[l_82_42].nRate = l_82_21[l_82_42].nRate
      l_82_10[l_82_42].szColor = l_82_21[l_82_42].szColor
      l_82_10[l_82_42].nAlpha = l_82_21[l_82_42].nAlpha
      l_82_10[l_82_42].nTrend = l_82_21[l_82_42].nTrend
      l_82_10[l_82_42]:ClearObjectIcon()
      l_82_10[l_82_42]:SetObjectIcon(l_82_10[l_82_42].nIconID)
      local l_82_43 = l_82_9:Lookup("Shadow_Color")
      if l_82_43 and (l_82_43.nEndFrame == 0 or l_82_10[l_82_42].nRate <= l_82_43.nRate) then
        local l_82_44 = l_82_20[l_82_10[l_82_42].szColor]
        local l_82_45 = 255
        local l_82_46 = 255
        local l_82_47 = 255
        local l_82_48 = 0
        if l_82_44 then
          l_82_45 = l_82_44[1]
        end
        l_82_43:SetTriangleFan(true)
        l_82_43:ClearTriangleFanPoint()
        l_82_43:AppendTriangleFanPoint(0, 0, l_82_45, l_82_46, l_82_47, l_82_48)
        l_82_43:AppendTriangleFanPoint(0, 34, l_82_45, l_82_46, l_82_47, l_82_48)
        l_82_43:AppendTriangleFanPoint(56, 34, l_82_45, l_82_46, l_82_47, l_82_48)
        l_82_43:AppendTriangleFanPoint(56, 0, l_82_45, l_82_46, l_82_47, l_82_48)
        l_82_43:Scale(RaidGridEx.fScale, RaidGridEx.fScale)
        l_82_43:Show()
        l_82_43.nEndFrame = l_82_10[l_82_42].nEndFrame or 0
        l_82_43.nRate = l_82_10[l_82_42].nRate
      end
    else
      l_82_10[l_82_42].szName = nil
      l_82_10[l_82_42].nIconID = -1
      l_82_10[l_82_42].bShow = false
      l_82_10[l_82_42].nEndFrame = 0
      l_82_10[l_82_42].nRate = 9999
      l_82_10[l_82_42].szColor = nil
      l_82_10[l_82_42].nAlpha = RaidGridEx.nBuffFlashAlpha
      l_82_10[l_82_42].nTrend = 1
      l_82_10[l_82_42]:ClearObjectIcon()
    end
  end
end

l_0_5.UpdateExBuffAlert = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_83_0, l_83_1, l_83_2, l_83_3)
  if not l_83_1 then
    return 
  end
  if not l_83_3 and RaidGrid_EventScrutiny.bAutoSelectEnable and l_83_1.tRGAutoSelect then
    RaidGrid_Base.SetTarget(l_83_0)
  end
  if RaidGrid_EventScrutiny.bRedAlarmEnable or RaidGrid_EventScrutiny.bCenterAlarmEnable then
    local l_83_4 = GetClientPlayer()
    local l_83_5 = false
    if l_83_4.dwID ~= l_83_0 and IsPlayer(l_83_0) and l_83_4.IsPlayerInMyParty(l_83_0) then
      l_83_5 = true
    end
    local l_83_6 = 255
    local l_83_7 = 0
    local l_83_8 = 0
    local l_83_9 = false
    local l_83_10 = false
    if RaidGrid_EventScrutiny.bRedAlarmEnable and l_83_1.tRGRedAlarm then
      l_83_6 = l_83_1.tRGRedAlarm[1]
      l_83_9 = true
    end
    if RaidGrid_EventScrutiny.bCenterAlarmEnable and l_83_1.tRGCenterAlarm then
      l_83_10 = true
    end
    if l_83_1.tRGRedAlarmSelf and l_83_5 then
      l_83_9 = false
    end
    if l_83_1.tRGCenterAlarmSelf and l_83_5 then
      l_83_10 = false
    end
  if not l_83_9 then
    end
  if not l_83_9 then
    end
  end
  RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, l_83_2, l_83_9, l_83_10, l_83_6, l_83_7, l_83_8)
end

l_0_5.UpdateAlarmAndSelect = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6, l_84_7)
  if not l_84_6 then
    l_84_6 = 1
  end
  local l_84_8 = GetClientPlayer()
  if not l_84_8 then
    return 
  end
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bBuffScrutinyEnable then
    return 
  end
  local l_84_9 = nil
  if IsPlayer(l_84_0) then
    l_84_9 = GetPlayer(l_84_0)
  else
    l_84_9 = GetNpc(l_84_0)
  end
  if not l_84_9 then
    return 
  end
  if not l_84_3 or l_84_3 <= 0 then
    return 
  end
  if l_84_6 <= 0 then
    return 
  end
  local l_84_10 = ""
  local l_84_11 = RaidGrid_EventScrutiny.IsRecordInList
  local l_84_12 = {}
  l_84_12.dwID = l_84_3
  l_84_12.nLevel = l_84_6
  l_84_11 = l_84_11(l_84_12, "Buff")
  if l_84_11 then
    l_84_10 = "Buff"
  else
    l_84_11 = RaidGrid_EventScrutiny
    l_84_11 = l_84_11.IsRecordInList
    l_84_11, l_84_12 = l_84_11(l_84_12, "Debuff"), {dwID = l_84_3, nLevel = l_84_6}
  end
  if l_84_11 then
    l_84_10 = "Debuff"
  end
  if l_84_10 == "" then
    l_84_11 = RaidGrid_EventScrutiny
    l_84_11 = l_84_11.IsRecordInList
    l_84_11, l_84_12 = l_84_11(l_84_12, "Scrutiny"), {dwID = l_84_3, nLevel = l_84_6}
    if l_84_11 and l_84_1 then
      l_84_11 = RaidGrid_EventScrutiny
      l_84_11 = l_84_11.tRecords
      l_84_11 = l_84_11.Scrutiny
      l_84_12 = 1
      for i = l_84_12, #l_84_11 do
        if l_84_11[l_84_15].dwID == l_84_3 and (RaidGrid_EventScrutiny.bNotCheckLevel or l_84_11[l_84_15].nLevel == l_84_6) then
          l_84_11[l_84_15].fEventTimeEnd = RaidGrid_Base.GetLogicTime()
        end
      end
    end
    return 
  end
  l_84_11 = GetLogicFrameCount
  l_84_11 = l_84_11()
  if not l_84_5 then
    l_84_5 = l_84_11
  end
  local l_84_16 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if not l_84_1 then
    local l_84_17 = nil
    for l_84_21 = l_84_17, #(l_84_16) do
      local l_84_21 = nil
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_84_21 == l_84_3 and (l_84_21 or l_84_21 == l_84_6) then
        local l_84_22 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if (l_84_21 and l_84_21 ~= "") or -1 <= 0 then
          if l_84_22 == l_84_0 then
            l_84_22(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
          end
           -- DECOMPILER ERROR: Overwrote pending register.

          l_84_22.fEventTimeEnd = RaidGrid_Base.GetLogicTime()
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if not l_84_22 or l_84_7 == l_84_22 then
            l_84_22(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

          end
           -- DECOMPILER ERROR: Overwrote pending register.

           -- DECOMPILER ERROR: Overwrote pending register.

          if l_84_22 then
            l_84_22(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
          end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        else
          if not l_84_22 or l_84_22 <= l_84_4 then
            l_84_22.fEventTimeStart = RaidGrid_Base.GetLogicTime()
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Confused about usage of registers!

            l_84_22.nEventAlertTime = -1
             -- DECOMPILER ERROR: Overwrote pending register.

            l_84_22.fEventTimeEnd = l_84_16[l_84_20].fEventTimeStart + l_84_16[l_84_20].nEventAlertTime
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_84_22 and l_84_22 == l_84_0 then
              l_84_22(l_84_16[l_84_20], "Scrutiny")
            end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_84_22 == l_84_0 then
              l_84_22(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              l_84_22(l_84_16[l_84_20])
            end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_84_9 and (not l_84_22 or (l_84_22 or l_84_22 <= l_84_16[l_84_20].fEventTimeStart)) then
              local l_84_23 = nil
              l_84_23 = l_84_16[l_84_20]
              l_84_23 = l_84_23.bManyMembers
              if l_84_23 then
                l_84_23 = l_84_16[l_84_20]
                l_84_23.bChatAlertCDEnd = l_84_16[l_84_20].fEventTimeStart + tonumber(l_84_16[l_84_20].nMinChatAlertCD or 7)
                 -- DECOMPILER ERROR: Overwrote pending register.

              end
              l_84_23 = RaidGrid_EventScrutiny
              l_84_23 = l_84_23.bBuffChatAlertEnable
            end
            if l_84_23 then
              l_84_23 = l_84_16[l_84_20]
              l_84_23 = l_84_23.bChatAlertW
              if not l_84_23 then
                l_84_23 = l_84_16[l_84_20]
                l_84_23 = l_84_23.bChatAlertT
              end
            if l_84_23 then
              end
            end
            local l_84_24 = nil
            local l_84_25 = nil
            l_84_25 = "�� ["
            l_84_25 = l_84_25 .. l_84_9.szName .. "]" .. l_84_22 .. "���Ч��: " .. l_84_21 .. " x" .. l_84_4 .. "��" .. (l_84_16[l_84_20].tAlarmAddInfo or "")
            l_84_24 = {type = "text", text = l_84_25}
            l_84_24 = l_84_16[l_84_20]
            l_84_24 = l_84_24.bChatAlertW
            if l_84_24 then
              l_84_24 = l_84_8.dwID
              if l_84_24 ~= l_84_0 then
                l_84_24 = IsPlayer
                l_84_25 = l_84_0
                l_84_24 = l_84_24(l_84_25)
                if l_84_24 then
                  l_84_24 = l_84_8.IsPlayerInMyParty
                  l_84_25 = l_84_0
                  l_84_24 = l_84_24(l_84_25)
                end
              if l_84_24 then
                end
              end
              local l_84_26 = nil
              l_84_26 = "�������Ч��: "
              l_84_26 = l_84_26 .. l_84_21 .. " x" .. l_84_4 .. "��" .. (l_84_16[l_84_20].tAlarmAddInfo or "")
              l_84_25 = {type = "text", text = l_84_26}
              l_84_25 = l_84_8.Talk
              l_84_26 = PLAYER_TALK_CHANNEL
              l_84_26 = l_84_26.WHISPER
              l_84_25(l_84_26, l_84_9.szName, l_84_24)
            end
            do return end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_84_25, l_84_23 = l_84_23, {l_84_24}
            l_84_24(l_84_25)
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_84_24 and l_84_24 then
              l_84_25 = RaidGrid_EventScrutiny
              l_84_25 = l_84_25.nSayChannel
              l_84_24(l_84_25, "", l_84_23)
            end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            if l_84_22 or l_84_22 <= l_84_16[l_84_20].fEventTimeStart then
              if l_84_22 and l_84_22 and l_84_22 > 0 then
                if l_84_16[l_84_20].szSkillName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
                  l_84_22(l_84_16[l_84_20].szName, l_84_24, 1, l_84_16[l_84_20].nSkillTimer2 * 16, l_84_16[l_84_20].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
                end
                 -- DECOMPILER ERROR: Overwrote pending register.

                l_84_22.bChatAlertCDEnd2 = l_84_16[l_84_20].fEventTimeStart + tonumber(l_84_16[l_84_20].nMinEventCD or 10)
              end
               -- DECOMPILER ERROR: Overwrote pending register.

               -- DECOMPILER ERROR: Overwrote pending register.

              local l_84_27 = nil
              l_84_27 = l_84_8.dwID
               -- DECOMPILER ERROR: Overwrote pending register.

              if l_84_27 == l_84_0 then
                l_84_27 = l_84_22
              end
              l_84_27 = l_84_27 .. l_84_21 .. " x" .. l_84_4 .. "��" .. (l_84_16[l_84_20].tAlarmAddInfo or "")
              local l_84_28 = nil
              l_84_28 = RaidGrid_EventScrutiny
              l_84_28 = l_84_28.UpdateAlarmAndSelect
              l_84_28(l_84_0, l_84_16[l_84_20], l_84_27)
              l_84_28 = l_84_16[l_84_20]
              l_84_28 = l_84_28.bOnlySelfSrcAddCTM
              if l_84_28 then
                l_84_28 = l_84_8.dwID
              if l_84_7 == l_84_28 then
                end
              end
              l_84_28 = RaidGrid_EventScrutiny
              l_84_28 = l_84_28.bBuffTeamScrutinyEnable
              if l_84_28 then
                l_84_28 = RaidGrid_EventScrutiny
                l_84_28 = l_84_28.UpdateCTMBuffAlert
                l_84_28(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
              end
              l_84_28 = RaidGrid_EventScrutiny
              l_84_28 = l_84_28.bBuffTeamExScrutinyEnable
              if l_84_28 then
                l_84_28 = RaidGrid_EventScrutiny
                l_84_28 = l_84_28.UpdateExBuffAlert
                l_84_28(l_84_16[l_84_20], l_84_0, l_84_1, l_84_2, l_84_3, l_84_4, l_84_5, l_84_6)
              end
              l_84_28 = RaidGrid_EventScrutiny
              l_84_28 = l_84_28.bScreenHeadMonitor
            end
          end
          if l_84_28 then
            l_84_28 = l_84_16[l_84_20]
            l_84_28 = l_84_28.bScreenHead
          end
          if l_84_28 then
            l_84_28 = RaidGrid_ScreenHead
            l_84_28 = l_84_28.addAlarmFrame
            l_84_28(l_84_0, l_84_16[l_84_20])
          end
          return 
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 118 420 
end

l_0_5.OnUpdateBuffData = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_85_0, l_85_1)
  local l_85_2 = GetClientPlayer()
  if not l_85_1 or not l_85_2 then
    return 
  end
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bNpcScrutinyEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bNpcEnemyEnable and IsEnemy(l_85_2.dwID, l_85_1.dwID) then
    return 
  end
  if not RaidGrid_EventScrutiny.bNpcNeutralEnable and IsNeutrality(l_85_2.dwID, l_85_1.dwID) then
    return 
  end
  if not RaidGrid_EventScrutiny.bNpcAllyEnable and IsAlly(l_85_2.dwID, l_85_1.dwID) then
    return 
  end
  if RaidGrid_EventScrutiny.bNpcUnselectableOnly and l_85_1.IsSelectable() then
    return 
  end
  local l_85_3 = RaidGrid_EventScrutiny.IsRecordInList
  do
    local l_85_4 = {}
    l_85_4.dwID = l_85_0
    l_85_3 = l_85_3(l_85_4, "Npc")
    if not l_85_3 then
      return 
    end
    l_85_3 = RaidGrid_Base
    l_85_3 = l_85_3.GetLogicTime
    l_85_3 = l_85_3()
    l_85_4 = RaidGrid_EventScrutiny
    l_85_4 = l_85_4.tRecords
    l_85_4 = l_85_4.Npc
    for l_85_8 = 1, #l_85_4 do
      if l_85_4[l_85_8].dwID == l_85_0 and not l_85_4[l_85_8].bNotAppearScrutiny then
        local l_85_9 = true
        if tonumber(not l_85_4[l_85_8].fLastEventCountTime and l_85_4[l_85_8].nMinChatAlertCD or 7) < math.abs(RaidGrid_Base.GetLogicTime() - (not l_85_4[l_85_8].nEventAlertCount or l_85_4[l_85_8].nEventAlertCount <= 1 or 0)) then
          l_85_4[l_85_8].nEventCount = nil
        end
        l_85_4[l_85_8].fLastEventCountTime = RaidGrid_Base.GetLogicTime()
        l_85_4[l_85_8].nEventCount = (l_85_4[l_85_8].nEventCount or 0) + 1
        if l_85_4[l_85_8].nEventCount == l_85_4[l_85_8].nEventAlertCount then
          l_85_4[l_85_8].nEventCount = nil
          l_85_9 = true
        else
          l_85_9 = false
        end
        if l_85_0 and l_85_4[l_85_8].fEventTimeStart and (l_85_4[l_85_8].nMinChatAlertCD or tonumber(not l_85_9 or not l_85_4[l_85_8].nEventAlertTime or l_85_4[l_85_8].nEventAlertTime <= 0 or 7) + l_85_4[l_85_8].fEventTimeStart <= l_85_3) and l_85_3 <= 1200 + l_85_4[l_85_8].fEventTimeStart then
          local l_85_10 = GetNpcTemplate(l_85_0)
        end
        if l_85_10 then
          local l_85_11 = l_85_3 - l_85_4[l_85_8].fEventTimeStart
          if not l_85_4[l_85_8].tEventTimeCache then
            l_85_4[l_85_8].tEventTimeCache = {}
          end
          table.insert(l_85_4[l_85_8].tEventTimeCache, 1, l_85_11)
          l_85_4[l_85_8].tEventTimeCache[11] = nil
          if l_85_11 < l_85_4[l_85_8].fMinTime or 999999 then
            l_85_4[l_85_8].fMinTime = l_85_11
          end
        if l_85_4[l_85_8].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.MIN then
          end
          if l_85_4[l_85_8].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.MIN and l_85_4[l_85_8].fMinTime > 0 then
            l_85_4[l_85_8].nEventAlertTime = math.floor(l_85_4[l_85_8].fMinTime)
          end
        else
          if l_85_4[l_85_8].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.AVG then
            if not l_85_4[l_85_8].tEventTimeCache then
              local l_85_12 = RaidGrid_Base.LowAverage({})
            end
          end
        end
        if l_85_12 and l_85_12 > 0 then
          l_85_4[l_85_8].nEventAlertTime = math.floor(l_85_12)
        end
        l_85_4[l_85_8].fEventTimeStart = l_85_3
        l_85_4[l_85_8].fEventTimeEnd = l_85_4[l_85_8].fEventTimeStart + l_85_4[l_85_8].nEventAlertTime
        if not l_85_4[l_85_8].bNotAddToScrutiny then
          RaidGrid_EventScrutiny.AddRecordToList(l_85_4[l_85_8], "Scrutiny")
        end
        RaidGrid_SelfBuffAlert.UpdateAlertColornSound(l_85_4[l_85_8])
        local l_85_13 = l_85_1.szName
        if not l_85_13 or l_85_13 == "" then
          l_85_13 = l_85_4[l_85_8].szName
        end
        if l_85_13 == "" then
          l_85_13 = tostring(l_85_0)
        end
        if l_85_4[l_85_8].bChatAlertCDEnd2 or 0 <= l_85_3 then
          if RaidGrid_EventScrutiny.bAutoNewSkillTimer and l_85_4[l_85_8].bAddToSkillTimer then
            if RaidGrid_EventScrutiny.bSkillTimerSay then
              RaidGrid_SkillTimer.StartNewSkillTimer(l_85_13, 237, 1, l_85_4[l_85_8].nEventAlertTime * 16, l_85_4[l_85_8].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
            end
            if l_85_4[l_85_8].bSkillTimer2Enable and l_85_4[l_85_8].nSkillTimer2 and l_85_4[l_85_8].nSkillTimer2 > 0 then
              if l_85_4[l_85_8].szSkillName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
                RaidGrid_SkillTimer.StartNewSkillTimer(l_85_4[l_85_8].szName, 254, 1, l_85_4[l_85_8].nSkillTimer2 * 16, l_85_4[l_85_8].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
              end
              l_85_4[l_85_8].bChatAlertCDEnd2 = l_85_3 + tonumber(l_85_4[l_85_8].nMinEventCD or 10)
            end
            if l_85_4[l_85_8].bChatAlertCDEnd or 0 <= l_85_3 then
              if l_85_2.IsInParty() and RaidGrid_EventScrutiny.bNpcChatAlertEnable and (l_85_4[l_85_8].bChatAlertW or l_85_4[l_85_8].bChatAlertT) then
                local l_85_14 = {}
                local l_85_15 = {}
                l_85_15.type = "text"
                l_85_15.text = "�� [" .. l_85_13 .. "]���֣�" .. (l_85_4[l_85_8].tAlarmAddInfo or "")
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                l_85_15 = l_85_4[l_85_8]
                l_85_15 = l_85_15.bChatAlertW
                if l_85_15 then
                  l_85_15 = RaidGrid_Base
                  l_85_15 = l_85_15.WhisperToPartyMember
                  l_85_15(l_85_14)
                end
                l_85_15 = l_85_4[l_85_8]
                l_85_15 = l_85_15.bChatAlertT
              end
              if l_85_15 then
                l_85_15 = l_85_2.Talk
                l_85_15(RaidGrid_EventScrutiny.nSayChannel, "", l_85_14)
              end
              local l_85_16 = "[" .. l_85_13 .. "]���֣�" .. (l_85_4[l_85_8].tAlarmAddInfo or "")
              RaidGrid_EventScrutiny.UpdateAlarmAndSelect(l_85_1.dwID, l_85_4[l_85_8], l_85_16)
              l_85_4[l_85_8].bChatAlertCDEnd = l_85_3 + tonumber(l_85_4[l_85_8].nMinChatAlertCD or 7)
            end
            return 
          end
        end
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 320 355 
end

l_0_5.OnNpcCreationEvent = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_86_0, l_86_1, l_86_2)
  local l_86_3 = GetClientPlayer()
  if not l_86_3 then
    return 
  end
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_EventScrutiny.bCastingScrutinyEnable then
    return 
  end
  if RaidGrid_EventScrutiny.bCastingScrutinyDungeonOnly and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  local l_86_4 = RaidGrid_Base.GetLogicTime()
  local l_86_5 = RaidGrid_EventScrutiny.tRecords.Casting
  local l_86_6 = nil
  if not RaidGrid_EventScrutiny.bCastingNPCOnly and GetPlayer(l_86_0) then
    l_86_6 = GetPlayer(l_86_0)
  else
    if GetNpc(l_86_0) then
      l_86_6 = GetNpc(l_86_0)
    end
  else
    return 
  end
  local l_86_7 = arg0
  if l_86_6 and (not RaidGrid_EventScrutiny.bCastingBossOnly or RaidGrid_Base.ToGetNpcIntensity(l_86_6) >= 4) then
    local l_86_8 = RaidGrid_EventScrutiny.IsRecordInList
    local l_86_9 = {}
    l_86_9.dwID = l_86_1
    l_86_9.nLevel = l_86_2
    l_86_8 = l_86_8(l_86_9, "Casting")
  end
  if l_86_8 then
    l_86_8 = 1
    l_86_9 = #l_86_5
    for i = l_86_8, l_86_9 do
      do
        if l_86_5[l_86_11].dwID == l_86_1 and (RaidGrid_EventScrutiny.bNotCheckLevel or l_86_5[l_86_11].nLevel == l_86_2) then
          if l_86_5[l_86_11].bTargetSkillOnly then
            local l_86_12, l_86_13 = l_86_3.GetTarget()
          if l_86_13 then
            end
          if l_86_13 then
            end
            return 
          end
        end
        local l_86_14 = Table_GetSkillName(l_86_1, l_86_2)
        l_86_14 = (l_86_14 and l_86_14 ~= "") or l_86_5[l_86_11].szName or "????"
        if l_86_1 and l_86_5[l_86_11].fEventTimeStart and (l_86_5[l_86_11].nMinChatAlertCD or tonumber(not l_86_5[l_86_11].nEventAlertTime or l_86_5[l_86_11].nEventAlertTime <= 0 or 7) + l_86_5[l_86_11].fEventTimeStart <= l_86_4) and l_86_4 <= 1200 + l_86_5[l_86_11].fEventTimeStart then
          local l_86_15 = l_86_4 - l_86_5[l_86_11].fEventTimeStart
          if not l_86_5[l_86_11].tEventTimeCache then
            l_86_5[l_86_11].tEventTimeCache = {}
          end
          table.insert(l_86_5[l_86_11].tEventTimeCache, 1, l_86_15)
          l_86_5[l_86_11].tEventTimeCache[11] = nil
          if l_86_15 < l_86_5[l_86_11].fMinTime or 999999 then
            l_86_5[l_86_11].fMinTime = l_86_15
          end
        if l_86_5[l_86_11].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.MIN then
          end
          if l_86_5[l_86_11].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.MIN and l_86_5[l_86_11].fMinTime > 0 then
            l_86_5[l_86_11].nEventAlertTime = math.floor(l_86_5[l_86_11].fMinTime)
          end
        else
          if l_86_5[l_86_11].nAutoEventTimeMode == AUTO_EVENTTIME_MODE.AVG then
            if not l_86_5[l_86_11].tEventTimeCache then
              local l_86_16 = RaidGrid_Base.LowAverage({})
            end
          end
        end
        if l_86_16 and l_86_16 > 0 then
          l_86_5[l_86_11].nEventAlertTime = math.floor(l_86_16)
        end
        if l_86_5[l_86_11].bChatAlertCDEnd2 or 0 <= l_86_4 then
          if RaidGrid_EventScrutiny.bAutoNewSkillTimer and l_86_5[l_86_11].bAddToSkillTimer then
            if RaidGrid_EventScrutiny.bSkillTimerSay then
              RaidGrid_SkillTimer.StartNewSkillTimer(l_86_14, l_86_1, l_86_2, l_86_5[l_86_11].nEventAlertTime * 16, l_86_5[l_86_11].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
            end
            if l_86_5[l_86_11].bSkillTimer2Enable and l_86_5[l_86_11].nSkillTimer2 and l_86_5[l_86_11].nSkillTimer2 > 0 then
              if l_86_5[l_86_11].szSkillName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
                RaidGrid_SkillTimer.StartNewSkillTimer(l_86_5[l_86_11].szName, 254, 1, l_86_5[l_86_11].nSkillTimer2 * 16, l_86_5[l_86_11].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
              end
              l_86_5[l_86_11].bChatAlertCDEnd2 = l_86_4 + tonumber(l_86_5[l_86_11].nMinEventCD or 10)
            end
            if l_86_5[l_86_11].bChatAlertCDEnd or 0 <= l_86_4 then
              l_86_5[l_86_11].fEventTimeStart = l_86_4
              l_86_5[l_86_11].fEventTimeEnd = l_86_5[l_86_11].fEventTimeStart + l_86_5[l_86_11].nEventAlertTime
              if not l_86_5[l_86_11].bNotAddToScrutiny then
                RaidGrid_EventScrutiny.AddRecordToList(l_86_5[l_86_11], "Scrutiny")
              end
              RaidGrid_SelfBuffAlert.UpdateAlertColornSound(l_86_5[l_86_11])
              if l_86_3.IsInParty() and RaidGrid_EventScrutiny.bCastingChatAlertEnable and (l_86_5[l_86_11].bChatAlertW or l_86_5[l_86_11].bChatAlertT) then
                local l_86_17 = {}
                local l_86_18 = {}
                l_86_18.type = "text"
                l_86_18.text = "�� [" .. l_86_6.szName .. "]�����ͷ�: " .. (l_86_14) .. "��" .. (l_86_5[l_86_11].tAlarmAddInfo or "")
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                l_86_18 = l_86_5[l_86_11]
                l_86_18 = l_86_18.bChatAlertW
                if l_86_18 then
                  l_86_18 = RaidGrid_Base
                  l_86_18 = l_86_18.WhisperToPartyMember
                  l_86_18(l_86_17)
                end
                l_86_18 = l_86_5[l_86_11]
                l_86_18 = l_86_18.bChatAlertT
              end
              if l_86_18 then
                l_86_18 = l_86_3.Talk
                l_86_18(RaidGrid_EventScrutiny.nSayChannel, "", l_86_17)
              end
              local l_86_19 = "[" .. l_86_6.szName .. "]�����ͷ�: " .. (l_86_14) .. "��" .. (l_86_5[l_86_11].tAlarmAddInfo or "")
              RaidGrid_EventScrutiny.UpdateAlarmAndSelect(l_86_0, l_86_5[l_86_11], l_86_19)
              l_86_5[l_86_11].bChatAlertCDEnd = l_86_4 + tonumber(l_86_5[l_86_11].nMinChatAlertCD or 7)
            end
          end
          if RaidGrid_EventScrutiny.bCastingReadingBar and l_86_7 == "UI_OME_SKILL_CAST_LOG" and not l_86_5[l_86_11].bNotReadingBar then
            RaidGrid_ReadingBar.put(l_86_6)
          end
          do break end
        end
      end
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 255 290 
end

l_0_5.OnSkillCasting = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  if not RaidGrid_EventScrutiny.bLinkNpcFightState then
    return 
  end
  if RaidGrid_EventScrutiny.bLinkNpcFightStateInDun and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  for l_87_3,l_87_4 in pairs(RaidGrid_EventCache.tSyncCharFightState) do
    local l_87_5 = GetNpcTemplate(l_87_3)
    local l_87_6 = (RaidGrid_Base.ToGetNpcIntensity(l_87_5))
    local l_87_7 = nil
    if not RaidGrid_EventScrutiny.bLinkBOSSFightState or l_87_6 >= 4 then
      for l_87_11,l_87_12 in pairs(l_87_4) do
        local l_87_13 = GetNpc(l_87_11)
        local l_87_14 = false
        if l_87_13 then
          l_87_14 = l_87_13.bFightState
        end
        if l_87_14 ~= true and l_87_14 ~= false then
          l_87_14 = RaidGrid_EventScrutiny.bLastFightState
        end
        if l_87_4[l_87_11] ~= l_87_14 then
          if l_87_7 ~= true then
            l_87_7 = l_87_14
          end
          if l_87_13 then
            l_87_4[l_87_11] = l_87_14
          end
        else
          l_87_4[l_87_11] = nil
        end
      end
    end
    do
      if l_87_7 == true then
        local l_87_15 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        for l_87_19 = "Casting", "Npc" do
          local l_87_20 = RaidGrid_EventScrutiny.tRecords[l_87_15[l_87_19]]
          if l_87_20 then
            for l_87_24 = 1, #l_87_20 do
              local l_87_25 = l_87_20[l_87_24]
              if l_87_25.bLinkNpcFightState and l_87_25.szLinkNpcName and l_87_25.dwLinkNpcTID and l_87_25.dwLinkNpcTID == l_87_3 then
                RaidGrid_Base.Message("��" .. l_87_25.szLinkNpcName .. "����" .. l_87_3 .. "������ս��״̬��")
                l_87_25.fEventTimeStart = RaidGrid_Base.GetLogicTime()
                l_87_25.fEventTimeEnd = l_87_25.fEventTimeStart + (l_87_25.nEventAlertTime or 1200)
                if not l_87_20[l_87_24].bNotAddToScrutiny then
                  RaidGrid_EventScrutiny.AddRecordToList(l_87_25, "Scrutiny")
                end
              end
              if l_87_20[l_87_24].bSkillTimer2Enable and l_87_20[l_87_24].nSkillTimer2 and l_87_20[l_87_24].nSkillTimer2 > 0 then
                if l_87_20[l_87_24].szSkillName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
                  RaidGrid_SkillTimer.StartNewSkillTimer(l_87_20[l_87_24].szName, 254, 1, l_87_20[l_87_24].nSkillTimer2 * 16, l_87_20[l_87_24].bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
                end
              end
            end
          end
        end
        do break end
      end
      if l_87_7 == false then
        local l_87_26 = RaidGrid_EventScrutiny.tRecords.Scrutiny
      end
      if l_87_26 then
        for l_87_30 = 1, #l_87_26 do
          local l_87_31 = l_87_26[l_87_30]
          if l_87_31.bLinkNpcFightState and l_87_31.szLinkNpcName and l_87_31.dwLinkNpcTID and l_87_31.dwLinkNpcTID == l_87_3 then
            RaidGrid_Base.Message("��" .. l_87_31.szLinkNpcName .. "����" .. l_87_3 .. "������ս����")
            l_87_31.fEventTimeEnd = 0
          end
        end
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 158 
end

l_0_5.CheckNpcFightState = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_88_0 = GetClientPlayer()
  if l_88_0.bFightState == true then
    RaidGrid_EventScrutiny.bSelfInFightState = true
  end
  if RaidGrid_EventScrutiny.bSelfInFightState ~= RaidGrid_EventScrutiny.bLastFightState then
    local l_88_1 = RaidGrid_Base.GetLogicTime()
    if not RaidGrid_EventScrutiny.bSelfInFightState and RaidGrid_EventScrutiny.bSelfStateOfDeathProcess then
      if l_88_0.nMoveState == MOVE_STATE.ON_DEATH then
        RaidGrid_EventScrutiny.bDeathTimeEnd = l_88_1
        return 
      end
    else
      if l_88_1 < RaidGrid_EventScrutiny.bDeathTimeEnd + 5 then
        return 
      end
    end
    RaidGrid_EventScrutiny.bLastFightState = RaidGrid_EventScrutiny.bSelfInFightState
    if RaidGrid_EventScrutiny.bLastFightState then
      local l_88_2 = {}
      l_88_2.szType = "Casting"
      l_88_2.dwID = 1000001
      l_88_2.nLevel = 1
      l_88_2.szName = "ս��״̬"
      l_88_2.bIsVisible = true
      l_88_2.nIconID = 2043
      l_88_2.fEventTimeStart = l_88_1
      l_88_2.fEventTimeEnd = l_88_2.fEventTimeStart + 99999999
      l_88_2.tEventTimeCache = {}
      if RaidGrid_EventScrutiny.tFightStateTable then
        if not RaidGrid_EventScrutiny.tFightStateTable.tEventTimeCache then
          l_88_2.tEventTimeCache = {}
        end
        RaidGrid_EventScrutiny.tFightStateTable.fEventTimeEnd = 0
      end
      if RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2[l_88_2.dwID] then
        RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2[l_88_2.dwID][l_88_2.nLevel] = nil
      end
      if not RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2[l_88_2.dwID] or RaidGrid_Base.isTableEmpty(RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2[l_88_2.dwID]) then
        RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash2[l_88_2.dwID] = nil
        RaidGrid_EventScrutiny.tRecords.Scrutiny.Hash[l_88_2.dwID] = nil
      end
      RaidGrid_EventScrutiny.RefreshEventHandle()
      RaidGrid_EventScrutiny.AddRecordToList(l_88_2, "Scrutiny")
      RaidGrid_EventScrutiny.tFightStateTable = l_88_2
      RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
    end
  else
    if RaidGrid_EventScrutiny.tFightStateTable then
      RaidGrid_EventScrutiny.tFightStateTable.nIconID = 2129
      RaidGrid_EventScrutiny.tFightStateTable.szName = "��ս��״̬"
      if not RaidGrid_EventScrutiny.tFightStateTable.tEventTimeCache then
        RaidGrid_EventScrutiny.tFightStateTable.tEventTimeCache = {}
      end
    end
  end
  if RaidGrid_EventScrutiny.tFightStateTable and RaidGrid_EventScrutiny.tFightStateTable.fEventTimeStart then
    table.insert(RaidGrid_EventScrutiny.tFightStateTable.tEventTimeCache, 1, l_88_1 - RaidGrid_EventScrutiny.tFightStateTable.fEventTimeStart)
  end
end

l_0_5.CheckFightState = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_89_0 = GetClientPlayer()
  if not l_89_0 then
    return 
  end
  local l_89_1 = RaidGrid_EventScrutiny.handleRecords
  if not l_89_1 then
    return 
  end
  local l_89_2 = RaidGrid_EventScrutiny.tRecords.Scrutiny
  local l_89_3 = RaidGrid_Base.GetLogicTime()
  do
    local l_89_4 = {}
    for l_89_8 = 1, #l_89_2 do
      local l_89_9 = l_89_2[l_89_8]
      local l_89_10 = l_89_9.szType
      if (l_89_10 == "Npc" or l_89_10 == "Casting") and (l_89_9.nRemoveDelayTime or RaidGrid_Base.IsOutOfEventTime(l_89_9, RaidGrid_EventScrutiny.nRemoveDelayTime)) then
        l_89_9.fEventTimeStart = nil
        l_89_9.fEventTimeEnd = nil
        if l_89_2.Hash2[l_89_9.dwID] and l_89_9.nLevel then
          l_89_2.Hash2[l_89_9.dwID][l_89_9.nLevel] = nil
        end
        if not l_89_2.Hash2[l_89_9.dwID] or RaidGrid_Base.isTableEmpty(l_89_2.Hash2[l_89_9.dwID]) then
          l_89_2.Hash2[l_89_9.dwID] = nil
          l_89_2.Hash[l_89_9.dwID] = nil
        end
        table.insert(l_89_4, 1, l_89_8)
      end
      do return end
      if l_89_9.nRemoveDelayTime or RaidGrid_Base.IsOutOfEventTime(l_89_9, l_89_10 ~= "Buff" and l_89_10 ~= "Debuff" or 0) then
        l_89_9.fEventTimeStart = nil
        l_89_9.fEventTimeEnd = nil
        if l_89_2.Hash2[l_89_9.dwID] and l_89_9.nLevel then
          l_89_2.Hash2[l_89_9.dwID][l_89_9.nLevel] = nil
        end
        if not l_89_2.Hash2[l_89_9.dwID] or RaidGrid_Base.isTableEmpty(l_89_2.Hash2[l_89_9.dwID]) then
          l_89_2.Hash2[l_89_9.dwID] = nil
          l_89_2.Hash[l_89_9.dwID] = nil
        end
        table.insert(l_89_4, 1, l_89_8)
      end
    end
    for l_89_14 = 1, #l_89_4 do
      table.remove(l_89_2, l_89_4[l_89_14])
    end
    if RaidGrid_EventScrutiny.szListIndex == "Scrutiny" then
      RaidGrid_EventScrutiny.UpdateRecordList("Scrutiny")
    end
    for l_89_18 = 1, 8 do
      local l_89_19 = l_89_1:Lookup("Handle_Record_" .. l_89_18)
      if l_89_19 and l_89_19.tRecord and (l_89_19.tRecord.szType == "Npc" or l_89_19.tRecord.szType == "Casting" or l_89_19.tRecord.szType == "Buff" or l_89_19.tRecord.szType == "Debuff") then
        if RaidGrid_EventScrutiny.szListIndex == "Scrutiny" and l_89_19.tRecord.nEventAlertTime and l_89_19.tRecord.nEventAlertTime > 0 then
          local l_89_20 = l_89_19.tRecord.fEventTimeEnd - l_89_3
          local l_89_21 = 1
          local l_89_22 = 32
          if l_89_20 >= 0 then
            if l_89_19.tRecord.szType == "Buff" then
              l_89_21 = l_89_20 / l_89_19.tRecord.nEventAlertTime
              l_89_22 = 32
              do break end
            end
            if l_89_19.tRecord.szType == "Debuff" then
              l_89_21 = l_89_20 / l_89_19.tRecord.nEventAlertTime
              l_89_22 = 30
              do break end
            end
            l_89_21 = 1 - l_89_20 / l_89_19.tRecord.nEventAlertTime
            if l_89_21 >= 0.975 or l_89_20 < 5 then
              l_89_22 = 30
            elseif l_89_21 >= 0.5 then
              l_89_22 = 31
            end
            do
              local l_89_23, l_89_24, l_89_28 = l_89_19.tRecord.nEventCountdownTime or 10
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

             -- DECOMPILER ERROR: Confused about usage of registers!

            if (l_89_19.tRecord.szType == "Npc" and RaidGrid_EventScrutiny.bNpcChatAlertEnable and l_89_19.tRecord.bChatAlertT) or l_89_19.tRecord.szType == "Casting" and RaidGrid_EventScrutiny.bCastingChatAlertEnable and l_89_19.tRecord.bChatAlertT then
              local l_89_25 = nil
              if l_89_19.tRecord.nLastSecond and math.floor(l_89_20) < l_89_19.tRecord.nLastSecond then
                local l_89_26 = nil
                local l_89_27 = {}
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                 -- DECOMPILER ERROR: Overwrote pending register.

                {type = "text", text = "�� [" .. (l_89_19.tRecord.szName or "????") .. "]�������֣�" .. l_89_26 .. "�롣"}(RaidGrid_EventScrutiny.nSayChannel, "", l_89_27)
              end
               -- DECOMPILER ERROR: Confused about usage of registers!

              l_89_19.tRecord.nLastSecond = l_89_26
            end
            if l_89_19.tRecord.bChatAlertCDEnd3 or not l_89_19.tRecord.tTimerSet or 0 <= l_89_3 then
              local l_89_29 = nil
              for l_89_33 = 1, #l_89_19.tRecord.tTimerSet do
                local l_89_30 = nil
                local l_89_35 = nil
                 -- DECOMPILER ERROR: Confused about usage of registers!

                if (l_89_34 == 1 and l_89_35 < 4) or l_89_34 ~= 1 and l_89_30[l_89_34 - 1].nTime < l_89_35 and l_89_35 < l_89_30[l_89_34 - 1].nTime + 4 then
                  if RaidGrid_EventScrutiny.bSkillTimerSay then
                    RaidGrid_SkillTimer.StartNewSkillTimer(l_89_30[l_89_34].szTimerName, 254, 1, (l_89_30[l_89_34].nTime - (l_89_3 - l_89_19.tRecord.fEventTimeStart)) * 16, l_89_19.tRecord.bChatAlertT, RaidGrid_EventScrutiny.nSayChannel, false)
                    l_89_19.tRecord.bChatAlertCDEnd3 = l_89_3 + 5
                  end
                end
              end
            else
              l_89_20 = math.abs(l_89_20)
              l_89_22 = 30
            end
            if not l_89_19.imageTimeBar.nFrame or l_89_19.imageTimeBar.nFrame ~= l_89_22 then
              l_89_19.imageTimeBar.nFrame = l_89_22
              l_89_19.imageTimeBar:SetFrame(l_89_22)
            end
            if not l_89_19.tRecord.bNormalCountdownType then
              l_89_19:Lookup("Image_TimeBar"):SetSize(125 * (l_89_21), 17)
              l_89_19.textEventTime:SetText(RaidGrid_Base.Time2String(l_89_20))
            end
          else
            l_89_19:Lookup("Image_TimeBar"):SetSize(125 * (l_89_21), 17)
            l_89_19.textEventTime:SetText(RaidGrid_Base.Time2String(l_89_3 - l_89_19.tRecord.fEventTimeStart))
          end
        else
          if RaidGrid_EventScrutiny.szListIndex == "Scrutiny" and l_89_19.tRecord.dwID == 1000001 and l_89_19.tRecord.szName == "ս��״̬" then
            l_89_19:Lookup("Image_TimeBar"):SetSize(0, 17)
            l_89_19.textEventTime:SetText(RaidGrid_Base.Time2String(l_89_3 - l_89_19.tRecord.fEventTimeStart))
          end
        else
          l_89_19:Lookup("Image_TimeBar"):SetSize(0, 17)
          local l_89_36 = "��:10 \""
          if l_89_19.tRecord.nEventCountdownTime then
            if l_89_19.tRecord.nEventCountdownTime == 0 then
              l_89_36 = ""
            else
              l_89_36 = "��:" .. RaidGrid_Base.Time2String(l_89_19.tRecord.nEventCountdownTime .. " ")
            end
          else
            if (l_89_19.tRecord.szType ~= "Casting" and l_89_19.tRecord.szType ~= "Npc") or l_89_19.tRecord.dwID == 1000001 then
              l_89_36 = ""
            end
          end
          local l_89_37 = ""
          if l_89_19.tRecord.nRemoveDelayTime then
            if l_89_19.tRecord.nRemoveDelayTime == 0 then
              l_89_37 = ""
            else
              l_89_37 = "��:" .. RaidGrid_Base.Time2String(l_89_19.tRecord.nRemoveDelayTime)
            end
          else
            if l_89_19.tRecord.szType == "Buff" or l_89_19.tRecord.szType == "Debuff" then
              l_89_37 = "��:0\""
            end
          else
            if (l_89_19.tRecord.szType == "Casting" or l_89_19.tRecord.szType == "Npc") and l_89_19.tRecord.dwID ~= 1000001 then
              l_89_37 = "��:10\""
            end
          end
          if not l_89_19.tRecord.bNotAddToScrutiny then
            l_89_19.textEventTime:SetText(l_89_36 .. l_89_37)
          end
        else
          if l_89_19.tRecord.bAddToSkillTimer then
            l_89_19.textEventTime:SetText("���뵹��ʱ")
          end
        else
          l_89_19.textEventTime:SetText("�޵���ʱ")
        end
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 360 
end

l_0_5.RefreshEventHandle = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_90_0)
  if not RaidGrid_EventScrutiny.tListPage[l_90_0] then
    return 
  end
  if not RaidGrid_EventScrutiny.bCheckBoxRecall then
    return 
  end
  RaidGrid_EventScrutiny.bCheckBoxRecall = false
  RaidGrid_EventScrutiny.szListIndex = l_90_0
  for l_90_4,l_90_5 in pairs(RaidGrid_EventScrutiny.tListPage) do
    local l_90_6 = RaidGrid_EventScrutiny.wnd:Lookup("CheckBox_Page_" .. l_90_4)
    if l_90_0 == l_90_4 then
      l_90_6:Check(true)
      l_90_6:Enable(false)
    else
      l_90_6:Check(false)
      l_90_6:Enable(true)
    end
  end
  local l_90_7, l_90_9 = {}
  l_90_7.Buff = "Buff�������"
  l_90_7.Debuff = "Debuff�������"
  l_90_7.Casting = "���ܼ������"
  l_90_7.Npc = "Npc�������"
  l_90_7.Scrutiny = "�¼�����С���"
  l_90_9 = RaidGrid_EventScrutiny
  l_90_9 = l_90_9.handleMain
   -- DECOMPILER ERROR: Overwrote pending register.

  do
    local l_90_8, l_90_10 = nil
    l_90_8, l_90_10 = l_90_9:SetText, l_90_9
    l_90_8(l_90_10, l_90_7[l_90_0] or "�¼����")
    l_90_8 = RaidGrid_EventScrutiny
    l_90_8 = l_90_8.UpdateRecordList
    l_90_10 = l_90_0
    l_90_8(l_90_10)
    l_90_8 = RaidGrid_EventScrutiny
    l_90_8 = l_90_8.RefreshEventHandle
    l_90_8()
    if l_90_0 == "Scrutiny" then
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_TL")
      l_90_8, l_90_10 = l_90_8:SetAlpha, l_90_8
      l_90_8(l_90_10, 64)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_TR")
      l_90_8, l_90_10 = l_90_8:SetAlpha, l_90_8
      l_90_8(l_90_10, 64)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_L")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_M")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_R")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_BL")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_B")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_BR")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_List")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "CheckBox_SelfBuff")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_PrePage")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_NextPage")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_DelPage")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Text_PageCurrent")
      l_90_8, l_90_10 = l_90_8:Hide, l_90_8
      l_90_8(l_90_10)
    else
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_TL")
      l_90_8, l_90_10 = l_90_8:SetAlpha, l_90_8
      l_90_8(l_90_10, 255)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_TR")
      l_90_8, l_90_10 = l_90_8:SetAlpha, l_90_8
      l_90_8(l_90_10, 255)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_L")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_M")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_R")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_BL")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_B")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_BR")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Handle_BG")
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Image_BG_List")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "CheckBox_SelfBuff")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_PrePage")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_NextPage")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.wnd
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Btn_DelPage")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
      l_90_8 = RaidGrid_EventScrutiny
      l_90_8 = l_90_8.handleMain
      l_90_8, l_90_10 = l_90_8:Lookup, l_90_8
      l_90_8 = l_90_8(l_90_10, "Text_PageCurrent")
      l_90_8, l_90_10 = l_90_8:Show, l_90_8
      l_90_8(l_90_10)
    end
    l_90_8 = RaidGrid_EventScrutiny
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_90_8.bCheckBoxRecall = true
end

l_0_5.SwitchPageType = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_91_0, l_91_1)
  if not l_91_0 or not l_91_1 then
    return 
  end
  local l_91_2 = RaidGrid_EventScrutiny.tRecords[l_91_1]
  if not l_91_2 or not l_91_2.Hash2 then
    return 
  end
  if (l_91_2.Hash[l_91_0.dwID] or l_91_2.Hash2[l_91_0.dwID]) and (not l_91_0.nLevel or not l_91_2.Hash2[l_91_0.dwID] or l_91_2.Hash2[l_91_0.dwID][l_91_0.nLevel]) then
    return 
  end
  if not l_91_0.nEventAlertTime and not l_91_0.fKeepTime then
    l_91_0.nEventAlertTime = math.floor(l_91_0.dwID == 1000001 or 1200)
    if RaidGrid_EventScrutiny.bAddToHead or l_91_1 ~= "Scrutiny" then
      if l_91_2[1] and l_91_2[1].dwID == 1000001 then
        table.insert(l_91_2, 2, l_91_0)
      else
        table.insert(l_91_2, 1, l_91_0)
      end
    else
      table.insert(l_91_2, l_91_0)
    end
    l_91_2.Hash[l_91_0.dwID] = true
    if l_91_0.nLevel then
      local l_91_3 = l_91_2.Hash2
      local l_91_4 = l_91_0.dwID
      if not l_91_2.Hash2[l_91_0.dwID] then
        l_91_3[l_91_4] = {}
      end
      l_91_3 = l_91_2.Hash2
      l_91_4 = l_91_0.dwID
      l_91_3 = l_91_3[l_91_4]
      l_91_4 = l_91_0.nLevel
      l_91_3[l_91_4] = true
    end
    if RaidGrid_EventScrutiny.szListIndex == l_91_1 then
      RaidGrid_EventScrutiny.UpdateRecordList(l_91_1)
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 53 
end

l_0_5.AddRecordToList = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_92_0, l_92_1)
  if not l_92_0 or not l_92_1 then
    return 
  end
  local l_92_2 = RaidGrid_EventScrutiny.tRecords[l_92_1]
  if not l_92_2 or not l_92_2.Hash or not l_92_2.Hash[l_92_0.dwID] then
    return 
  end
  if not RaidGrid_EventScrutiny.bNotCheckLevel and l_92_0.nLevel and (not l_92_2.Hash2[l_92_0.dwID] or not l_92_2.Hash2[l_92_0.dwID][l_92_0.nLevel]) then
    return 
  end
  return true
end

l_0_5.IsRecordInList = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_93_0)
  local l_93_1 = RaidGrid_EventScrutiny.handleRecords
  if not l_93_1 then
    return 
  end
  if not l_93_0 then
    l_93_0 = RaidGrid_EventScrutiny.szListIndex
  end
  local l_93_2 = RaidGrid_EventScrutiny.tRecords[l_93_0]
  if not l_93_2 then
    return 
  end
  local l_93_3 = math.max(math.ceil(#l_93_2 / 8), 1)
  local l_93_4 = math.min(RaidGrid_EventScrutiny.tListPage[l_93_0] or 1, l_93_3)
  RaidGrid_EventScrutiny.tListPage[l_93_0] = l_93_4
  RaidGrid_EventScrutiny.handleMain:Lookup("Text_PageCurrent"):SetText(l_93_4)
  local l_93_5 = 8 * (l_93_4 - 1) + 1
  local l_93_6 = 0
  for l_93_10 = 1, 8 do
    local l_93_11 = l_93_1:Lookup("Handle_Record_" .. l_93_10)
    if l_93_11 then
      local l_93_12 = l_93_2[l_93_5 + l_93_10 - 1]
      if l_93_12 then
        l_93_6 = l_93_6 + 1
        RaidGrid_EventScrutiny.ShowRecordHandle(l_93_11, l_93_12)
      end
    else
      RaidGrid_EventScrutiny.ClearRecordHandle(l_93_11)
    end
  end
  if l_93_0 == "Scrutiny" then
    RaidGrid_EventScrutiny.frameSelf:SetSize(235, 50 + 48 * (l_93_6))
  else
    RaidGrid_EventScrutiny.frameSelf:SetSize(235, 455)
  end
end

l_0_5.UpdateRecordList = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  -- upvalues: l_0_4
  local l_94_0 = RaidGrid_EventScrutiny.handleRecords
  if not l_94_0 then
    return 
  end
  l_94_0:Clear()
  for l_94_4 = 1, 8 do
    local l_94_5 = l_94_0:AppendItemFromIni(l_0_4, "Handle_RecordDummy", "Handle_Record_" .. l_94_4)
    l_94_5:SetRelPos(0, (l_94_4 - 1) * 46 + 1)
    l_94_5.OnItemMouseEnter = function()
      this.imageCover:Show()
    end
    l_94_5.OnItemMouseLeave = function()
      this.imageCover:Hide()
    end
    l_94_5.OnItemLButtonClick = function()
    end
    l_94_5.OnItemRButtonClick = function()
      RaidGrid_EventScrutiny.PopRBOptions(this)
    end
    l_94_5.box = l_94_5:Lookup("Box_Icon")
    l_94_5.box:Show()
    l_94_5.box:SetObject(1, 0)
    l_94_5.box:ClearObjectIcon()
    l_94_5.box:SetObjectIcon(1435)
    l_94_5.box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
    l_94_5.box:SetOverTextFontScheme(0, 15)
    l_94_5.box:SetOverText(0, "")
    l_94_5.box.handleParent = l_94_5
    l_94_5.box.OnItemMouseEnter = function()
      local l_99_0 = this.handleParent.tRecord
      if l_99_0 and l_99_0.dwID then
        local l_99_1, l_99_2 = this:GetAbsPos()
        local l_99_3, l_99_4 = this:GetSize()
        if l_99_0.szType == "Buff" or l_99_0.szType == "Debuff" then
          local l_99_5 = OutputBuffTip
          local l_99_6 = GetClientPlayer().dwID
          local l_99_7 = l_99_0.dwID
          do
            local l_99_8 = l_99_0.nLevel or 1
          end
          local l_99_9 = nil
          local l_99_10 = 1
          local l_99_11 = false
          local l_99_12 = 999
          l_99_5(l_99_6, l_99_7, l_99_9, l_99_10, l_99_11, l_99_12, {l_99_1, l_99_2, l_99_3, l_99_4})
        end
      elseif l_99_0.szType == "Npc" then
        local l_99_13 = RaidGrid_Base.OutputNpcInfoTip
        local l_99_14 = l_99_0.dwID
        local l_99_15 = {}
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_99_13(l_99_14, l_99_15)
      elseif l_99_0.szType == "Casting" and l_99_0.dwID ~= 1000001 then
        local l_99_16 = OutputSkillTip
        local l_99_17 = l_99_0.dwID
        do
          local l_99_18 = l_99_0.nLevel or 1
        end
        local l_99_19 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_99_16(l_99_17, l_99_19, {l_99_2, l_99_3, l_99_4, l_99_4})
      end
    end
    l_94_5.box.OnItemMouseLeave = function()
      RaidGrid_Base.HideTip()
    end
    l_94_5.imageBoxBG = l_94_5:Lookup("Image_BGBox")
    l_94_5.imageBoxBG.handleParent = l_94_5
    l_94_5.imageBoxBG.OnItemMouseEnter = l_94_5.box.OnItemMouseEnter
    l_94_5.imageBoxBG.OnItemMouseLeave = l_94_5.box.OnItemMouseLeave
    l_94_5.text = l_94_5:Lookup("Text_Name")
    l_94_5.text:SetText("")
    l_94_5.imageGrid = l_94_5:Lookup("Image_BGGrid")
    l_94_5.imageGrid.nFrame = 999
    l_94_5.textTime = l_94_5:Lookup("Text_Time")
    l_94_5.textTime:SetFontScale(0.8)
    l_94_5.textTime:SetText("")
    l_94_5.textEventTime = l_94_5:Lookup("Text_EventTime")
    l_94_5.textEventTime:SetFontScale(0.9)
    l_94_5.textEventTime:SetText("")
    l_94_5.textEventAlertTime = l_94_5:Lookup("Text_EventAlertTime")
    l_94_5.textEventAlertTime:SetFontScale(0.9)
    l_94_5.textEventAlertTime:SetText("")
    l_94_5.textEventAlertCount = l_94_5:Lookup("Text_Count")
    l_94_5.textEventAlertCount:SetFontScale(0.9)
    l_94_5.textEventAlertCount:SetText("")
    l_94_5.imageCover = l_94_5:Lookup("Image_Cover")
    l_94_5.imageTimeBar = l_94_5:Lookup("Image_TimeBar")
    l_94_5.imageTimeAlertBG = l_94_5:Lookup("Image_TimeAlertBG")
    l_94_5.shadowBuffColor = l_94_5:Lookup("Shadow_BuffColor")
    l_94_5.imageFSLink = l_94_5:Lookup("Image_FSLink")
    l_94_5:Hide()
  end
  l_94_0:FormatAllItemPos()
end

l_0_5.InitRecordHandles = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_95_0)
  if not l_95_0 then
    return 
  end
  l_95_0.box:SetObjectIcon(1435)
  l_95_0.dwID = nil
  l_95_0.tRecord = nil
  l_95_0:Hide()
end

l_0_5.ClearRecordHandle = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function(l_96_0, l_96_1)
  if not l_96_0 or not l_96_1 then
    return 
  end
  l_96_0.dwID = l_96_1.dwID
  l_96_0.tRecord = l_96_1
  if l_96_1.bIsVisible then
    l_96_0.text:SetText(l_96_1.szName)
  else
    l_96_0.text:SetText(l_96_1.szName .. "(��)")
  end
  if l_96_1.bEnemy == true then
    l_96_0.text:SetFontColor(255, 128, 128)
  elseif l_96_1.bEnemy == false then
    l_96_0.text:SetFontColor(255, 255, 128)
  else
    l_96_0.text:SetFontColor(255, 255, 255)
  end
  if l_96_1.bIsDebuff == true and l_96_0.imageGrid.nFrame ~= 1 then
    l_96_0.imageGrid:SetFrame(1)
  elseif l_96_1.bIsDebuff == false and l_96_0.imageGrid.nFrame ~= 13 then
    l_96_0.imageGrid:SetFrame(13)
  else
    if l_96_0.imageGrid.nFrame ~= 14 then
      l_96_0.imageGrid:SetFrame(14)
    end
  end
  l_96_0.box:SetObjectIcon(l_96_1.nIconID or 1435)
  if l_96_1.szIconPath then
    l_96_0.box:Hide()
    if l_96_1.nIconFrame then
      l_96_0.imageBoxBG:FromUITex(l_96_1.szIconPath, l_96_1.nIconFrame)
    else
      l_96_0.imageBoxBG:FromTextureFile(l_96_1.szIconPath)
    end
  else
    l_96_0.box:Show()
  end
  if l_96_0.tRecord.nEventAlertTime then
    l_96_0.textEventAlertTime:SetText(RaidGrid_Base.Time2String(l_96_0.tRecord.nEventAlertTime))
  else
    l_96_0.textEventAlertTime:SetText("")
  end
  if l_96_0.tRecord.nEventAlertCount and l_96_0.tRecord.nEventAlertCount > 1 then
    l_96_0.textEventAlertCount:SetText(l_96_0.tRecord.nEventAlertCount)
  else
    if l_96_0.tRecord.nEventAlertStackNum and l_96_0.tRecord.nEventAlertStackNum > 1 then
      l_96_0.textEventAlertCount:SetText(l_96_0.tRecord.nEventAlertStackNum)
    end
  else
    l_96_0.textEventAlertCount:SetText("")
  end
  if not l_96_0.tRecord.nAutoEventTimeMode then
    l_96_0.tRecord.nAutoEventTimeMode = AUTO_EVENTTIME_MODE.AVG
  end
  if l_96_0.tRecord.nAutoEventTimeMode == AUTO_EVENTTIME_MODE.AVG then
    l_96_0.imageTimeAlertBG:SetFrame(23)
  else
    if l_96_0.tRecord.nAutoEventTimeMode == AUTO_EVENTTIME_MODE.MIN then
      l_96_0.imageTimeAlertBG:SetFrame(22)
    end
  else
    l_96_0.imageTimeAlertBG:SetFrame(21)
  end
  l_96_0.shadowBuffColor:SetColorRGB(not l_96_0.tRecord.tRGBuffColor or 0, not l_96_0.tRecord.tRGBuffColor[1] and l_96_0.tRecord.tRGBuffColor[2] or 0, l_96_0.tRecord.tRGBuffColor[3] or 0)
  do return end
  l_96_0.shadowBuffColor:SetColorRGB(0, 0, 0)
  if l_96_0.tRecord.bChatAlertW then
    l_96_0:Lookup("Text_WBox"):SetFontColor(255, 0, 255)
  else
    l_96_0:Lookup("Text_WBox"):SetFontColor(100, 100, 100)
  end
  if l_96_0.tRecord.bChatAlertT then
    l_96_0:Lookup("Text_TBox"):SetFontColor(64, 128, 255)
  else
    l_96_0:Lookup("Text_TBox"):SetFontColor(100, 100, 100)
  end
  if l_96_0.tRecord.bLinkNpcFightState then
    l_96_0.imageFSLink:Show()
  else
    l_96_0.imageFSLink:Hide()
  end
  l_96_0:Show()
end

l_0_5.ShowRecordHandle = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  if not Station.Lookup("Normal/RaidGrid_EventScrutiny") then
    local l_97_0, l_97_1, l_97_2, l_97_3, l_97_4, l_97_5, l_97_6, l_97_7, l_97_8 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_EventScrutiny.ini", "RaidGrid_EventScrutiny")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_97_0:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_EventScrutiny.frameSelf = l_97_0
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_EventScrutiny.wnd = l_97_0:Lookup("Wnd_Scrutiny")
  RaidGrid_EventScrutiny.handleMain = RaidGrid_EventScrutiny.wnd:Lookup("", "")
  RaidGrid_EventScrutiny.handleRecords = RaidGrid_EventScrutiny.handleMain:Lookup("Handle_Records")
  RaidGrid_EventScrutiny.handleMain:Lookup("Handle_RecordDummy"):Hide()
  RaidGrid_EventScrutiny.InitRecordHandles()
end

l_0_5.OpenPanel = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_98_0 = Station.Lookup("Normal/RaidGrid_EventScrutiny")
  if l_98_0 then
    local l_98_1, l_98_2 = l_98_0:IsVisible, l_98_0
    return l_98_1(l_98_2)
  end
end

l_0_5.IsOpened = l_0_6
l_0_5 = RaidGrid_EventScrutiny
l_0_6 = function()
  local l_99_0 = Station.Lookup("Normal/RaidGrid_EventScrutiny")
  if l_99_0 then
    l_99_0:Hide()
  end
end

l_0_5.ClosePanel = l_0_6
l_0_5 = "Interface/RaidGrid_EventScrutiny/RaidGrid_SelfBuffAlert.ini"
l_0_6 = RaidGrid_SelfBuffAlert
if not l_0_6 then
  RaidGrid_SelfBuffAlert, l_0_6 = l_0_6, {}
end
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.frameSelf = nil
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.handleMain = nil
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.nSetper = -1
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.tLastLoc, l_0_7 = l_0_7, {nX = -1, nY = -1}
l_0_6 = RegisterCustomData
l_0_7 = "RaidGrid_SelfBuffAlert.tLastLoc"
l_0_6(l_0_7)
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.nScaleXandY = 2
l_0_6 = RegisterCustomData
l_0_7 = "RaidGrid_SelfBuffAlert.nScaleXandY"
l_0_6(l_0_7)
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.bShowBuffName = true
l_0_6 = RegisterCustomData
l_0_7 = "RaidGrid_SelfBuffAlert.bShowBuffName"
l_0_6(l_0_7)
l_0_6 = RaidGrid_SelfBuffAlert
l_0_6.nBoxMax = 8
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function()
  RaidGrid_SelfBuffAlert.nSetper = RaidGrid_SelfBuffAlert.nSetper + 1
  local l_100_0 = GetClientPlayer()
  if not l_100_0 then
    return 
  end
  RaidGrid_SelfBuffAlert.RefreshSelfBuffHandle()
  RaidGrid_SelfBuffAlert.RefreshAlertColornSound()
  if RaidGrid_EventScrutiny.bCtrlandAltMove and IsCtrlKeyDown() and IsAltKeyDown() then
    for l_100_4 = 1, 8 do
      RaidGrid_SelfBuffAlert.handleMain:Lookup("Image_DragBG_" .. l_100_4):Show()
    end
    RaidGrid_SelfBuffAlert.frameSelf:SetSize(376 * RaidGrid_SelfBuffAlert.nScaleXandY, 46 * RaidGrid_SelfBuffAlert.nScaleXandY)
    Station.Lookup("Normal/RaidGrid_SkillTimerAnchor"):Show()
  else
    for l_100_8 = 1, 8 do
      RaidGrid_SelfBuffAlert.handleMain:Lookup("Image_DragBG_" .. l_100_8):Hide()
    end
    RaidGrid_SelfBuffAlert.frameSelf:SetSize(0, 0)
    Station.Lookup("Normal/RaidGrid_SkillTimerAnchor"):Hide()
  end
  local l_100_9, l_100_10 = RaidGrid_SelfBuffAlert.frameSelf:GetRelPos()
  if RaidGrid_SelfBuffAlert.tLastLoc.nX ~= l_100_9 and RaidGrid_SelfBuffAlert.tLastLoc.nY ~= l_100_10 then
    RaidGrid_SelfBuffAlert.SetPanelPos(l_100_9, l_100_10)
  end
end

l_0_6.OnFrameBreathe = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function()
  local l_101_0 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertBG")
  l_101_0:SetAlpha(math.max(0, l_101_0:GetAlpha() - 3))
  local l_101_1 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertGrid")
  if RaidGrid_EventScrutiny.bColorAlertEnable then
    local l_101_2 = -1
    for l_101_6 = 1, RaidGrid_SelfBuffAlert.nBoxMax do
      do
        local l_101_7 = RaidGrid_SelfBuffAlert.handleMain:Lookup("Handle_Box_" .. l_101_6)
        l_101_2 = not l_101_7.tInfo or not l_101_7.tInfo.tRGAlertColor or l_101_7.tInfo.tRGAlertColor[4] or 4
      end
      do break end
    end
    if l_101_2 and l_101_2 >= 0 then
      l_101_1:SetFrame(l_101_2)
      l_101_1:SetAlpha(200)
    else
      l_101_1:SetAlpha(0)
    end
  else
    l_101_1:SetAlpha(0)
  end
end

l_0_6.RefreshAlertColornSound = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function(l_102_0)
  if not l_102_0 then
    return 
  end
  local l_102_1 = l_102_0.szSoundFile
  local l_102_2 = l_102_0.tRGAlertColor
  local l_102_3 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertBG")
  local l_102_4 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertGrid")
  local l_102_5, l_102_6 = Station.GetClientSize(true)
  l_102_3:SetSize(l_102_5, l_102_6)
  l_102_4:SetSize(l_102_5, l_102_6)
  if not l_102_2[4] then
    local l_102_7, l_102_8, l_102_9, l_102_10 = not l_102_2 or not RaidGrid_EventScrutiny.bColorAlertEnable or 4
  end
  if RaidGrid_EventScrutiny.bDebuffColorAlertAuto and l_102_0.bIsDebuff then
    l_102_3:SetFrame(3)
    l_102_3:SetAlpha(128)
    do return end
    if RaidGrid_EventScrutiny.bDebuffColorAlertAuto and l_102_0.bIsDebuff then
      local l_102_11 = 3
      l_102_3:SetFrame(l_102_11)
      l_102_3:SetAlpha(128)
    end
    if l_102_1 and l_102_1 ~= "" and RaidGrid_EventScrutiny.bSoundAlertEnable then
      PlaySound(SOUND.UI_SOUND, l_102_1)
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 46 
end

l_0_6.UpdateAlertColornSound = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function(l_103_0, l_103_1)
  if not l_103_0 then
    l_103_0 = -1
  end
  local l_103_2 = -1
  if l_103_1 then
    l_103_2 = l_103_0
  end
  local l_103_3 = (GetLogicFrameCount())
  local l_103_4 = nil
  for l_103_8 = 1, RaidGrid_SelfBuffAlert.nBoxMax do
    local l_103_9 = RaidGrid_SelfBuffAlert.handleMain:Lookup("Handle_Box_" .. l_103_8)
    if not l_103_9.tInfo or not l_103_9.nEndFrame or l_103_9.nEndFrame <= l_103_3 or l_103_9.tInfo.dwID == l_103_2 then
      l_103_9:SetAlpha(math.max(0, l_103_9:GetAlpha() - 26))
      l_103_9.ani:SetAlpha(0)
      l_103_9.box:SetOverText(0, "")
      l_103_9.textBuffName:SetText("")
      l_103_9.tInfo = nil
      l_103_9.nEndFrame = nil
    else
      l_103_9.text:SetText(RaidGrid_Base.Time2String(((l_103_9.nEndFrame or l_103_3) - l_103_3) / GLOBAL.GAME_FPS))
      l_103_9.ani:SetAlpha(math.max(0, l_103_9.ani:GetAlpha() - 8))
    end
    if (not l_103_4 and not l_103_9.tInfo) or l_103_9.tInfo and l_103_9.tInfo.dwID == l_103_0 then
      l_103_4 = l_103_9
    end
  end
  return l_103_4
end

l_0_6.RefreshSelfBuffHandle = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function(l_104_0, l_104_1, l_104_2, l_104_3, l_104_4, l_104_5, l_104_6, l_104_7)
  if not l_104_0 or not RaidGrid_EventScrutiny.bBuffListExEnable then
    return 
  end
  local l_104_8 = RaidGrid_SelfBuffAlert.RefreshSelfBuffHandle(l_104_4, l_104_2)
  if not l_104_8 then
    return 
  end
  if l_104_2 then
    l_104_8.tInfo = nil
    l_104_8.nEndFrame = nil
    return 
  end
  l_104_8.tInfo = l_104_0
  l_104_8.nEndFrame = l_104_6
  l_104_8:SetAlpha(215)
  l_104_8.ani:SetAlpha(215)
  l_104_8.box:SetObjectSparking(true)
  l_104_8.box:SetObjectIcon(l_104_0.nIconID or 1435)
  if RaidGrid_SelfBuffAlert.bShowBuffName then
    l_104_8.textBuffName:SetText(l_104_0.szName)
  end
  if l_104_0.bIsDebuff then
    l_104_8.textBuffName:SetFontColor(255, 64, 64)
    l_104_8.text:SetFontColor(255, 64, 64)
  else
    l_104_8.textBuffName:SetFontColor(64, 255, 64)
    l_104_8.text:SetFontColor(64, 255, 64)
  end
  if l_104_5 > 1 then
    l_104_8.box:SetOverText(0, " x" .. tostring(l_104_5))
  else
    l_104_8.box:SetOverText(0, "")
  end
end

l_0_6.UpdateSelfBuffAlert = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function()
  local l_105_0, l_105_1 = Station.GetClientSize(true)
  local l_105_2 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertBG")
  local l_105_3 = RaidGrid_SelfBuffAlert.handleMainBG:Lookup("Image_AlertGrid")
  l_105_2:SetSize(l_105_0, l_105_1)
  l_105_3:SetSize(l_105_0, l_105_1)
end

l_0_6.RescaleBG = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function()
  -- upvalues: l_0_5
  for l_106_3 = 1, RaidGrid_SelfBuffAlert.nBoxMax do
    local l_106_4 = RaidGrid_SelfBuffAlert.handleMain:AppendItemFromIni(l_0_5, "Handle_BuffBoxDummy", "Handle_Box_" .. l_106_3)
    l_106_4:SetRelPos((l_106_3 - 1) * 47, 0)
    local l_106_5 = l_106_4:Lookup("Box_Icon")
    local l_106_6 = l_106_4:Lookup("Text_BuffName")
    local l_106_7 = l_106_4:Lookup("Text_Time")
    local l_106_8 = l_106_4:Lookup("Animate_Update")
    l_106_4.box = l_106_5
    l_106_4.textBuffName = l_106_6
    l_106_4.text = l_106_7
    l_106_4.ani = l_106_8
    l_106_4.ani:SetAlpha(0)
    l_106_6:SetText("")
    l_106_7:SetText("")
    l_106_5:SetObject(1, 0)
    l_106_5:ClearObjectIcon()
    l_106_5:SetOverTextPosition(0, ITEM_POSITION.LEFT_BOTTOM)
    l_106_5:SetOverTextFontScheme(0, 15)
    l_106_5:SetOverText(0, "")
    l_106_4.box.handleParent = l_106_4
    l_106_4.box.OnItemMouseEnter = function()
      local l_107_0 = this.handleParent.tInfo
      if l_107_0 and l_107_0.dwID then
        local l_107_1, l_107_2 = this:GetAbsPos()
        local l_107_3, l_107_4 = this:GetSize()
      if l_107_0.szType ~= "Buff" then
        end
      if l_107_0.szType ~= "Buff" then
        end
      end
      local l_107_5 = OutputBuffTip
      local l_107_6 = GetClientPlayer().dwID
      local l_107_7 = l_107_0.dwID
      do
        local l_107_8 = l_107_0.nLevel or 1
      end
      local l_107_9 = nil
      local l_107_10 = 1
      local l_107_11 = false
      local l_107_12 = 999
      l_107_5(l_107_6, l_107_7, l_107_9, l_107_10, l_107_11, l_107_12, {l_107_1, l_107_2, l_107_3, l_107_4})
    end
    l_106_4.box.OnItemMouseLeave = function()
      RaidGrid_Base.HideTip()
    end
    l_106_4.box.OnItemRButtonClick = function()
      local l_109_0 = this.handleParent.tInfo
      if l_109_0 and l_109_0.dwID then
        local l_109_1 = GetClientPlayer()
        local l_109_2 = {}
        if l_109_1 then
          l_109_2 = l_109_1.GetBuffList()
        end
        if not l_109_2 then
          return 
        end
        for l_109_6,l_109_7 in ipairs(l_109_2) do
          if l_109_0.dwID == l_109_7.dwID and (RaidGrid_EventScrutiny.bNotCheckLevel or l_109_0.nLevel == l_109_7.nLevel) and l_109_7.bCanCancel then
            l_109_1.CancelBuff(l_109_7.nIndex)
          end
        end
      end
    end
    l_106_4:Show()
  end
  RaidGrid_SelfBuffAlert.handleMain:FormatAllItemPos()
end

l_0_6.InitBuffBoxes = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function(l_107_0, l_107_1)
  if not l_107_0 or not l_107_1 then
    RaidGrid_SelfBuffAlert.frameSelf:SetPoint("CENTER", -188, -200, "CENTER", 0, 0)
  else
    local l_107_2, l_107_3 = Station.GetClientSize(true)
    if l_107_0 < 0 then
      l_107_0 = 0
    end
    if l_107_2 - 100 < l_107_0 then
      l_107_0 = l_107_2 - 100
    end
    if l_107_1 < 0 then
      l_107_1 = 0
    end
    if l_107_3 - 110 < l_107_1 then
      l_107_1 = l_107_3 - 110
    end
    RaidGrid_SelfBuffAlert.frameSelf:SetRelPos(l_107_0, l_107_1)
  end
  local l_107_4 = RaidGrid_SelfBuffAlert.tLastLoc
  local l_107_5 = RaidGrid_SelfBuffAlert.tLastLoc
  local l_107_6 = RaidGrid_SelfBuffAlert.frameSelf:GetRelPos()
  l_107_5.nY = RaidGrid_SelfBuffAlert.frameSelf
  l_107_4.nX = l_107_6
end

l_0_6.SetPanelPos = l_0_7
l_0_6 = RaidGrid_SelfBuffAlert
l_0_7 = function()
  if not Station.Lookup("Topmost2/RaidGrid_SelfBuffAlert") then
    local l_108_0, l_108_1, l_108_2, l_108_3, l_108_4, l_108_5, l_108_6, l_108_8, l_108_10, l_108_12, l_108_14, l_108_16, l_108_18, l_108_20, l_108_21 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_SelfBuffAlert.ini", "RaidGrid_SelfBuffAlert")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_108_0:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_SelfBuffAlert.frameSelf = l_108_0
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_SelfBuffAlert.handleMain = l_108_0:Lookup("", "")
  RaidGrid_SelfBuffAlert.handleMain:Lookup("Handle_BuffBoxDummy"):Hide()
  if not Station.Lookup("Topmost2/RaidGrid_SelfBuffAlertBG") then
    local l_108_7, l_108_9, l_108_11, l_108_13, l_108_15, l_108_17, l_108_19, l_108_22 = , Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_SelfBuffAlertBG.ini", "RaidGrid_SelfBuffAlertBG")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_108_9:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_SelfBuffAlert.frameBG = l_108_9
   -- DECOMPILER ERROR: Confused about usage of registers!

  RaidGrid_SelfBuffAlert.handleMainBG = l_108_9:Lookup("", "")
  RaidGrid_SelfBuffAlert.InitBuffBoxes()
  RaidGrid_SelfBuffAlert.RescaleBG()
   -- DECOMPILER ERROR: Confused about usage of registers!

  if RaidGrid_SelfBuffAlert.nScaleXandY > 0 and RaidGrid_SelfBuffAlert.nScaleXandY ~= 1 then
    l_108_7:Scale(RaidGrid_SelfBuffAlert.nScaleXandY, RaidGrid_SelfBuffAlert.nScaleXandY)
  end
end

l_0_6.OpenPanel = l_0_7
l_0_7 = {s = "CENTER", r = "CENTER", x = 0, y = -150}
l_0_7 = {s = "CENTER", r = "CENTER", x = 0, y = -150}
RaidGrid_CenterAlarm, l_0_6 = l_0_6, {DefaultAnchor = l_0_7, Anchor = l_0_7}
l_0_6 = RaidGrid_CenterAlarm
l_0_7 = function()
  this:RegisterEvent("UI_SCALED")
  RaidGrid_CenterAlarm.UpdateAnchor(this)
  RaidGrid_CenterAlarm.UpdateAlpha(0)
end

l_0_6.OnFrameCreate = l_0_7
l_0_6 = RaidGrid_CenterAlarm
l_0_7 = function(l_110_0)
  if l_110_0 == "UI_SCALED" then
    RaidGrid_CenterAlarm.UpdateAnchor(this)
  end
end

l_0_6.OnEvent = l_0_7
l_0_6 = RaidGrid_CenterAlarm
l_0_7 = function(l_111_0)
  Station.Lookup("Topmost1/RaidGrid_CenterAlarm"):Lookup("", ""):Lookup("Text_CampText"):SetText(l_111_0)
end

l_0_6.UpdateText = l_0_7
l_0_6 = RaidGrid_CenterAlarm
l_0_7 = function(l_112_0)
  Station.Lookup("Topmost1/RaidGrid_CenterAlarm"):Lookup("", ""):SetAlpha(l_112_0)
end

l_0_6.UpdateAlpha = l_0_7
l_0_6 = RaidGrid_CenterAlarm
l_0_7 = function(l_113_0)
  l_113_0:SetPoint(RaidGrid_CenterAlarm.Anchor.s, 0, 0, RaidGrid_CenterAlarm.Anchor.r, RaidGrid_CenterAlarm.Anchor.x, RaidGrid_CenterAlarm.Anchor.y)
  l_113_0:CorrectPos()
end

l_0_6.UpdateAnchor = l_0_7
l_0_6 = Wnd
l_0_6 = l_0_6.OpenWindow
l_0_7 = "interface\\RaidGrid_EventScrutiny\\RaidGrid_CenterAlarm.ini"
l_0_6(l_0_7, "RaidGrid_CenterAlarm")
RaidGrid_RedAlarm, l_0_6 = l_0_6, {bRedAlarm = true, bCenterAlarm = true, r = 255, g = 0, b = 0, pRed = nil, bUp = true, nMaxAlpha = 128, nAlpha = 0, nTime = 0, nSpeed = 16}
l_0_6 = RaidGrid_RedAlarm
l_0_7 = function()
  local l_114_0 = Station.Lookup("Topmost/RaidGrid_RedAlarm")
  local l_114_1 = l_114_0:Lookup("", "")
  RaidGrid_RedAlarm.pRed = l_114_1:Lookup("Shadow_Info")
end

l_0_6.OnFrameCreate = l_0_7
l_0_6 = RaidGrid_RedAlarm
l_0_7 = function()
  local l_115_0 = GetFPS()
  local l_115_1 = 1000 / l_115_0
  if RaidGrid_RedAlarm.nTime > 0 then
    if RaidGrid_RedAlarm.bUp then
      RaidGrid_RedAlarm.nAlpha = RaidGrid_RedAlarm.nAlpha + RaidGrid_RedAlarm.nSpeed * l_115_1 / 67
    else
      RaidGrid_RedAlarm.nAlpha = RaidGrid_RedAlarm.nAlpha - RaidGrid_RedAlarm.nSpeed * l_115_1 / 67
    end
    if RaidGrid_RedAlarm.nMaxAlpha < RaidGrid_RedAlarm.nAlpha then
      RaidGrid_RedAlarm.nAlpha = RaidGrid_RedAlarm.nMaxAlpha
      RaidGrid_RedAlarm.bUp = false
    end
    if RaidGrid_RedAlarm.nAlpha < 0 then
      RaidGrid_RedAlarm.nAlpha = 0
      RaidGrid_RedAlarm.bUp = true
      RaidGrid_RedAlarm.nTime = RaidGrid_RedAlarm.nTime - 1
    end
    local l_115_2 = RaidGrid_RedAlarm.nAlpha
    local l_115_3 = RaidGrid_RedAlarm.nAlpha + 128
    if not RaidGrid_RedAlarm.bRedAlarm then
      l_115_2 = 0
    end
    if not RaidGrid_RedAlarm.bCenterAlarm then
      l_115_3 = 0
    end
    RaidGrid_RedAlarm.Draw(l_115_2)
    RaidGrid_CenterAlarm.UpdateAlpha(l_115_3)
  else
    RaidGrid_RedAlarm.Draw(0)
    RaidGrid_CenterAlarm.UpdateAlpha(0)
  end
end

l_0_6.OnFrameRender = l_0_7
l_0_6 = RaidGrid_RedAlarm
l_0_7 = function(l_116_0, l_116_1, l_116_2, l_116_3, l_116_4, l_116_5, l_116_6)
  RaidGrid_RedAlarm.r = l_116_4
  RaidGrid_RedAlarm.g = l_116_5
  RaidGrid_RedAlarm.b = l_116_6
  RaidGrid_RedAlarm.bRedAlarm = l_116_2
  RaidGrid_RedAlarm.bCenterAlarm = l_116_3
  RaidGrid_RedAlarm.nTime = l_116_0
  RaidGrid_RedAlarm.bUp = true
  RaidGrid_RedAlarm.nAlpha = 0
  RaidGrid_CenterAlarm.UpdateText(l_116_1)
end

l_0_6.Flash = l_0_7
l_0_6 = RaidGrid_RedAlarm
l_0_7 = function(l_117_0)
  local l_117_1, l_117_2 = Station.GetClientSize()
  local l_117_3 = RaidGrid_RedAlarm.r
  local l_117_4 = RaidGrid_RedAlarm.g
  local l_117_5 = RaidGrid_RedAlarm.b
  RaidGrid_RedAlarm.pRed:SetTriangleFan(true)
  RaidGrid_RedAlarm.pRed:ClearTriangleFanPoint()
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(l_117_1 / 2, l_117_2 / 2, l_117_3, l_117_4, l_117_5, 0)
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(0, 0, l_117_3, l_117_4, l_117_5, l_117_0)
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(0, l_117_2, l_117_3, l_117_4, l_117_5, l_117_0)
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(l_117_1, l_117_2, l_117_3, l_117_4, l_117_5, l_117_0)
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(l_117_1, 0, l_117_3, l_117_4, l_117_5, l_117_0)
  RaidGrid_RedAlarm.pRed:AppendTriangleFanPoint(0, 0, l_117_3, l_117_4, l_117_5, l_117_0)
end

l_0_6.Draw = l_0_7
l_0_6 = Wnd
l_0_6 = l_0_6.OpenWindow
l_0_7 = "interface\\RaidGrid_EventScrutiny\\RaidGrid_RedAlarm.ini"
l_0_6(l_0_7, "RaidGrid_RedAlarm")
l_0_7 = {s = "CENTER", r = "CENTER", x = 0, y = -300}
RaidGrid_SkillTimerAnchor, l_0_6 = l_0_6, {bDragable = false, Anchor = l_0_7}
l_0_6 = RegisterCustomData
l_0_7 = "RaidGrid_SkillTimerAnchor.Anchor"
l_0_6(l_0_7)
l_0_6 = RegisterCustomData
l_0_7 = "RaidGrid_SkillTimerAnchor.bDragable"
l_0_6(l_0_7)
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("RaidGridNewSkillTimer")
  RaidGrid_SkillTimerAnchor.UpdateAnchor(this)
end

l_0_6.OnFrameCreate = l_0_7
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function(l_119_0)
  if l_119_0 == "UI_SCALED" then
    RaidGrid_SkillTimerAnchor.UpdateAnchor(this)
  elseif l_119_0 == "RaidGridNewSkillTimer" then
    RaidGrid_SkillTimer.StartNewSkillTimer(xarg0, xarg1, xarg2, xarg3, xarg4, xarg5, xarg6)
  end
end

l_0_6.OnEvent = l_0_7
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function()
  if RaidGrid_SkillTimerAnchor.bDragable then
    Station.Lookup("Normal/RaidGrid_SkillTimerAnchor"):Show()
  else
    Station.Lookup("Normal/RaidGrid_SkillTimerAnchor"):Hide()
  end
end

l_0_6.UpdateDrag = l_0_7
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function()
  this:CorrectPos()
  RaidGrid_SkillTimerAnchor.Anchor = GetFrameAnchor(this)
end

l_0_6.OnFrameDragSetPosEnd = l_0_7
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function()
  this:CorrectPos()
  RaidGrid_SkillTimerAnchor.Anchor = GetFrameAnchor(this)
end

l_0_6.OnFrameDragEnd = l_0_7
l_0_6 = RaidGrid_SkillTimerAnchor
l_0_7 = function(l_123_0)
  local l_123_1 = RaidGrid_SkillTimerAnchor.Anchor
  l_123_0:SetPoint(l_123_1.s, 0, 0, l_123_1.r, l_123_1.x, l_123_1.y)
  l_123_0:CorrectPos()
end

l_0_6.UpdateAnchor = l_0_7
l_0_6 = Wnd
l_0_6 = l_0_6.OpenWindow
l_0_7 = "interface\\RaidGrid_EventScrutiny\\RaidGrid_SkillTimerAnchor.ini"
l_0_6(l_0_7, "RaidGrid_SkillTimerAnchor")
l_0_6 = Station
l_0_6 = l_0_6.Lookup
l_0_7 = "Normal/RaidGrid_SkillTimerAnchor"
l_0_6 = l_0_6(l_0_7)
l_0_6, l_0_7 = l_0_6:Hide, l_0_6
l_0_6(l_0_7)
l_0_6 = "interface\\RaidGrid_EventScrutiny\\RaidGrid_SkillTimer.ini"
l_0_7 = 300
local l_0_8 = {}
l_0_8.BOUNDARY = 64
l_0_8.nCount = 0
RaidGrid_SkillTimer = l_0_8
l_0_8 = RaidGrid_SkillTimer
local l_0_9 = "init"
l_0_8[l_0_9] = function(l_124_0)
  l_124_0:SetAlpha(255)
  local l_124_1 = l_124_0:Lookup("", ""):Lookup("Image")
  l_124_1:SetFrame(15)
  local l_124_2 = l_124_0:Lookup("", ""):Lookup("SkillName")
  l_124_2:SetFontColor(255, 255, 0)
  l_124_2 = l_124_0:Lookup("", ""):Lookup("TimeLeft")
  l_124_2:SetFontColor(255, 255, 0)
  RaidGrid_SkillTimer.FreshBox(l_124_0)
  RaidGrid_SkillTimer.FreshPos(l_124_0)
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "FlashFrame"
l_0_8[l_0_9] = function(l_125_0, l_125_1)
  local l_125_2 = l_125_0:Lookup("", ""):Lookup("TimeLeft")
  local l_125_3 = l_125_0:Lookup("", ""):Lookup("Image")
  l_125_3:SetFrame(12)
  l_125_2:SetFontColor(255, 0, 0)
  l_125_2 = l_125_0:Lookup("", ""):Lookup("SkillName")
  l_125_2:SetFontColor(255, 0, 0)
  l_125_0:SetAlpha(l_125_1)
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = function()
  RaidGrid_SkillTimer.FreshPos(this)
  local l_126_0 = GetClientPlayer()
  if not l_126_0 then
    return 
  end
  local l_126_1 = GetLogicFrameCount()
  local l_126_2 = this.nEndFrameCount - l_126_1
  local l_126_3 = l_126_2 / (this.nEndFrameCount - this.nStartFrameCount)
  local l_126_4 = 255 * (math.abs(math.mod(l_126_2 + 8, 32) - 7) + 4) / 12
  if l_126_3 > 0 then
    local l_126_5 = this:Lookup("", ""):Lookup("Image")
    local l_126_6, l_126_7 = l_126_5:GetSize()
    l_126_5:SetPercentage(l_126_3)
    local l_126_8 = this:Lookup("", ""):Lookup("TimeLeft")
    local l_126_9, l_126_10, l_126_11 = GetTimeToHourMinuteSecond(l_126_2, true)
    if l_126_9 > 0 then
      l_126_8:SetText("" .. l_126_9 .. "h " .. l_126_10 .. "m " .. l_126_11 .. "s")
    elseif l_126_10 > 0 then
      l_126_8:SetText("" .. l_126_10 .. "m " .. l_126_11 .. "s")
    else
      l_126_8:SetText("" .. l_126_11 .. "s")
      if l_126_11 < RaidGrid_EventScrutiny.nSkillTimerCountdown then
        if this.nLS and l_126_11 < this.nLS and this.bSayTimer then
          local l_126_12 = l_126_0.Talk
          local l_126_13 = this.nChannel
          local l_126_14 = ""
          local l_126_15 = {}
          local l_126_16 = {}
          l_126_16.type = "text"
          l_126_16.text = "��[" .. this.szSkillName .. "]ʣ�� " .. this.nLS .. "�룡 "
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_126_12(l_126_13, l_126_14, l_126_15)
        end
        RaidGrid_SkillTimer.FlashFrame(this, l_126_4)
      end
      this.nLS = l_126_11
    end
  else
    RaidGrid_SkillTimer.RemoveTimer(this.nID)
  end
end

l_0_8.OnFrameRender = l_0_9
l_0_8 = RaidGrid_SkillTimer
l_0_9 = "CopyFrame"
l_0_8[l_0_9] = function(l_127_0, l_127_1)
  l_127_0.szSkillName = l_127_1.szSkillName
  l_127_0.nSkillID = l_127_1.nSkillID
  l_127_0.nSkillLV = l_127_1.nSkillLV
  l_127_0.bSayTimer = l_127_1.bSayTimer
  l_127_0.nChannel = l_127_1.nChannel
  l_127_0.bBuff = l_127_1.bBuff
  l_127_0.nStartFrameCount = l_127_1.nStartFrameCount
  l_127_0.nEndFrameCount = l_127_1.nEndFrameCount
  RaidGrid_SkillTimer.init(l_127_0)
  l_127_0:Show()
  l_127_0:SetAlpha(l_127_1:GetAlpha())
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "RemoveTimer"
l_0_8[l_0_9] = function(l_128_0)
  local l_128_1, l_128_2 = nil, nil
  for i = l_128_0, RaidGrid_SkillTimer.nCount - 1 do
    l_128_1 = RaidGrid_SkillTimer.GetFrame(i)
    l_128_2 = RaidGrid_SkillTimer.GetFrame(i + 1)
    RaidGrid_SkillTimer.CopyFrame(l_128_1, l_128_2)
  end
  l_128_2 = RaidGrid_SkillTimer.GetFrame(RaidGrid_SkillTimer.nCount)
  l_128_2:Hide()
  l_128_2.szSkillName = ""
  l_128_2.nSkillID = 0
  l_128_2.nSkillLV = 0
  l_128_2.bSayTimer = false
  l_128_2.nChannel = nil
  l_128_2.bBuff = false
  RaidGrid_SkillTimer.nCount = RaidGrid_SkillTimer.nCount - 1
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "RemoveAllTimer"
l_0_8[l_0_9] = function()
  local l_129_0 = nil
  for l_129_4 = 1, RaidGrid_SkillTimer.nCount do
    local l_129_1 = nil
    l_129_0 = RaidGrid_SkillTimer.GetFrame(RaidGrid_SkillTimer.nCount)
    l_129_0:Hide()
    l_129_0.szSkillName = ""
    l_129_0.nSkillID = 0
    l_129_0.nSkillLV = 0
    l_129_0.bSayTimer = false
    l_129_0.nChannel = nil
    l_129_0.bBuff = false
    RaidGrid_SkillTimer.nCount = RaidGrid_SkillTimer.nCount - 1
  end
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "FreshBox"
l_0_8[l_0_9] = function(l_130_0)
  local l_130_1 = l_130_0.szSkillName
  local l_130_2 = l_130_0.nSkillID
  local l_130_3 = l_130_0.nSkillLV
  local l_130_4 = l_130_0:Lookup("", ""):Lookup("Box")
  l_130_4:SetObject(UI_OBJECT_SKILL, l_130_2, l_130_3)
  if not l_130_0.bBuff then
    l_130_4:SetObjectIcon(Table_GetSkillIconID(l_130_2, l_130_3))
  else
    l_130_4:SetObjectIcon(Table_GetBuffIconID(l_130_2, l_130_3))
  end
  local l_130_5 = l_130_0:Lookup("", ""):Lookup("SkillName")
  l_130_5:SetText(l_130_1)
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "FreshPos"
l_0_8[l_0_9] = function(l_131_0)
  local l_131_1 = RaidGrid_SkillTimerAnchor.Anchor.y + l_131_0.nID * 33
  l_131_0:SetPoint(RaidGrid_SkillTimerAnchor.Anchor.s, 0, 0, RaidGrid_SkillTimerAnchor.Anchor.r, RaidGrid_SkillTimerAnchor.Anchor.x, l_131_1)
  l_131_0:CorrectPos()
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "GetFrame"
l_0_8[l_0_9] = function(l_132_0)
  return Station.Lookup("Normal/RaidGrid_SkillTimer_" .. l_132_0)
end

l_0_8 = RaidGrid_SkillTimer
l_0_9 = "StartNewSkillTimer"
l_0_8[l_0_9] = function(l_133_0, l_133_1, l_133_2, l_133_3, l_133_4, l_133_5, l_133_6)
  -- upvalues: l_0_6
  local l_133_7 = GetLogicFrameCount()
  local l_133_8 = l_133_7 + l_133_3
  RaidGrid_SkillTimer.nCount = RaidGrid_SkillTimer.nCount + 1
  if not Station.Lookup("Normal/RaidGrid_SkillTimer_" .. RaidGrid_SkillTimer.nCount) then
    local l_133_9, l_133_10 = Wnd.OpenWindow(l_0_6, "RaidGrid_SkillTimer_" .. RaidGrid_SkillTimer.nCount)
    l_133_10 = RaidGrid_SkillTimer
    l_133_10 = l_133_10.nCount
    l_133_9.nID = l_133_10
    l_133_10 = RaidGrid_SkillTimer
    l_133_10 = l_133_10.OnFrameRender
    l_133_9.OnFrameRender = l_133_10
  end
  local l_133_11 = nil
  for l_133_15 = 1, RaidGrid_SkillTimer.nCount - 1 do
    local l_133_12 = 1
     -- DECOMPILER ERROR: Confused about usage of registers!

    if l_133_8 < RaidGrid_SkillTimer.GetFrame(R14_PC42).nEndFrameCount then
      do break end
    end
    l_133_12 = R14_PC42 + 1
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  for l_133_19 = RaidGrid_SkillTimer.nCount, l_133_12 + 1, -1 do
    local l_133_16 = nil
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_133_21 = RaidGrid_SkillTimer.GetFrame(R14_PC42)
    RaidGrid_SkillTimer.CopyFrame(l_133_21, RaidGrid_SkillTimer.GetFrame(l_133_20 - 1))
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_133_11 = RaidGrid_SkillTimer.GetFrame(l_133_16)
  l_133_11.szSkillName = l_133_0
  l_133_11.nSkillID = l_133_1
  l_133_11.nSkillLV = l_133_2
  l_133_11.nStartFrameCount = l_133_7
  l_133_11.nEndFrameCount = l_133_8
  l_133_11.bSayTimer = l_133_4
  l_133_11.nChannel = l_133_5
  l_133_11.bBuff = l_133_6
  RaidGrid_SkillTimer.init(l_133_11)
  l_133_11:Show()
end

l_0_9 = "target"
l_0_9 = "TOTAL"
RaidGrid_ReadingBar, l_0_8 = l_0_8, {
[l_0_9] = {}, [l_0_9] = 8}
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "loc"
local l_0_10 = {}
l_0_10.x = 150
l_0_10.y = 250
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_ReadingBar.loc"
l_0_8(l_0_9)
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "show"
l_0_10 = function()
  local l_134_0 = Station.Lookup("Normal/RaidGrid_ReadingBar")
  if l_134_0 and not l_134_0:IsVisible() then
    l_134_0:Show()
  end
  do return end
  l_134_0 = Wnd.OpenWindow("Interface\\RaidGrid_EventScrutiny\\RaidGrid_ReadingBar.ini", "RaidGrid_ReadingBar")
  l_134_0:Show()
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "hide"
l_0_10 = function()
  local l_135_0 = Station.Lookup("Normal/RaidGrid_ReadingBar")
  if l_135_0 and l_135_0:IsVisible() then
    l_135_0:Hide()
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "put"
l_0_10 = function(l_136_0)
  if RaidGrid_ReadingBar.TOTAL <= table.getn(RaidGrid_ReadingBar.target) then
    return 
  end
  do return end
  for l_136_4,l_136_5 in ipairs(RaidGrid_ReadingBar.target) do
    if l_136_0.dwID == l_136_5.caster.dwID then
      return 
    end
  end
  do
    local l_136_6, l_136_9 = table.insert
    l_136_9 = RaidGrid_ReadingBar
    l_136_9 = l_136_9.target
    local l_136_7 = nil
    local l_136_8 = nil
    l_136_6(l_136_9, l_136_7)
    l_136_7 = {caster = l_136_0, shown = true}
    l_136_6 = RaidGrid_ReadingBar
    l_136_6 = l_136_6.show
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_136_6()
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ReadingBar
l_0_9 = function()
  if not GetClientPlayer() then
    return 
  end
  local l_137_0 = Station.Lookup("Normal/RaidGrid_ReadingBar")
  local l_137_1, l_137_2 = GetClientPlayer().GetTarget()
  local l_137_3 = 1
  for l_137_7,l_137_8 in ipairs(RaidGrid_ReadingBar.target) do
    l_137_3 = l_137_7
    if l_137_8 then
      local l_137_9 = l_137_8.caster
      local l_137_10 = l_137_0:Lookup("", "Handle_Bar_" .. tostring(l_137_7))
      if not l_137_7 or not l_137_9 then
        l_137_10:Hide()
      end
    else
      if not GetPlayer(l_137_8.caster.dwID) and not GetNpc(l_137_8.caster.dwID) then
        l_137_10:Hide()
        table.remove(RaidGrid_ReadingBar.target, l_137_7)
      end
    else
      local l_137_11, l_137_12, l_137_13, l_137_14 = l_137_9.GetSkillPrepareState()
      if l_137_11 and l_137_10.nActionState ~= RaidGrid_Base.lz_ACTION_STATE.PREPARE then
        l_137_10:SetAlpha(255)
        l_137_10:Show()
        l_137_10:Lookup("Image_Progress_" .. l_137_7):Show()
        l_137_10:Lookup("Image_FlashS_" .. l_137_7):Hide()
        l_137_10:Lookup("Image_FlashF_" .. l_137_7):Hide()
        l_137_10:Lookup("Text_Name_" .. l_137_7):SetText(Table_GetSkillName(l_137_12, l_137_13))
        l_137_10:Lookup("Text_Caster_" .. l_137_7):SetText(l_137_9.szName)
        if l_137_2 == l_137_8.caster.dwID then
          l_137_10:Lookup("Text_Caster_" .. l_137_7):SetFontColor(255, 255, 0)
        else
          l_137_10:Lookup("Text_Caster_" .. l_137_7):SetFontColor(255, 255, 255)
        end
        l_137_10.nActionState = RaidGrid_Base.lz_ACTION_STATE.PREPARE
      elseif not l_137_11 and l_137_10.nActionState == RaidGrid_Base.lz_ACTION_STATE.PREPARE then
        l_137_10.nActionState = RaidGrid_Base.lz_ACTION_STATE.DONE
      end
      if l_137_10.nActionState == RaidGrid_Base.lz_ACTION_STATE.PREPARE then
        l_137_10:Lookup("Image_Progress_" .. l_137_7):SetPercentage(l_137_14)
      end
    else
      if l_137_10.nActionState == RaidGrid_Base.lz_ACTION_STATE.DONE then
        l_137_10:Lookup("Image_FlashS_" .. l_137_7):Show()
        l_137_10.nActionState = RaidGrid_Base.lz_ACTION_STATE.FADE
      end
    else
      if l_137_10.nActionState == RaidGrid_Base.lz_ACTION_STATE.BREAK then
        l_137_10:Lookup("Image_FlashF_" .. l_137_7):Show()
        l_137_10.nActionState = RaidGrid_Base.lz_ACTION_STATE.FADE
      end
    else
      if l_137_10.nActionState == RaidGrid_Base.lz_ACTION_STATE.FADE then
        local l_137_15 = l_137_10:GetAlpha() - 10
        if l_137_15 > 0 then
          l_137_10:SetAlpha(l_137_15)
        end
      else
        l_137_10:SetAlpha(0)
        l_137_10.nActionState = RaidGrid_Base.lz_ACTION_STATE.NONE
        l_137_10:Hide()
        table.remove(RaidGrid_ReadingBar.target, l_137_7)
      end
    else
      l_137_10:Hide()
      l_137_8.shown = false
    end
  end
  for l_137_19,l_137_20 in ipairs(RaidGrid_ReadingBar.target) do
    if l_137_20.shown == false then
      l_137_0:Lookup("", "Handle_Bar_" .. tostring(l_137_19)):Hide()
      table.remove(RaidGrid_ReadingBar.target, l_137_19)
    end
  end
  if l_137_3 < 8 then
    for l_137_24 = l_137_3 + 1, 8 do
      Station.Lookup("Normal/RaidGrid_ReadingBar"):Lookup("", "Handle_Bar_" .. tostring(l_137_24)):Hide()
    end
  end
  do
    local l_137_25, l_137_26 = table.getn(RaidGrid_ReadingBar.target)
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_137_25 > 0 then
    l_137_26(l_137_0, 300, l_137_25 * 30)
  end
end

l_0_8.OnFrameBreathe = l_0_9
l_0_8 = RaidGrid_ReadingBar
l_0_9 = function()
  this:SetRelPos(RaidGrid_ReadingBar.loc.x, RaidGrid_ReadingBar.loc.y)
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("NPC_LEAVE_SCENE")
  this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
  this:RegisterEvent("PLAYER_LEAVE_SCENE")
end

l_0_8.OnFrameCreate = l_0_9
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "OnActionBreak"
l_0_10 = function(l_139_0, l_139_1)
  l_139_0:Lookup("", "Handle_Bar_" .. l_139_1).nActionState = RaidGrid_Base.lz_ACTION_STATE.BREAK
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ReadingBar
l_0_9 = function(l_140_0)
  if l_140_0 == "OT_ACTION_PROGRESS_BREAK" then
    for l_140_4,l_140_5 in ipairs(RaidGrid_ReadingBar.target) do
      if arg0 == l_140_5.caster.dwID then
        local l_140_6 = Station.Lookup("Normal/RaidGrid_ReadingBar")
        RaidGrid_ReadingBar.OnActionBreak(l_140_6, l_140_4)
      end
    end
    do break end
  end
  do
    if l_140_0 == "PLAYER_LEAVE_SCENE" then
      local l_140_7 = GetClientPlayer()
      for l_140_11,l_140_12 in ipairs(RaidGrid_ReadingBar.target) do
        if l_140_12.caster.dwType == TARGET.PLAYER and l_140_12.caster.dwID == arg0 then
          Station.Lookup("Normal/RaidGrid_ReadingBar"):Lookup("", "Handle_Bar_" .. tostring(l_140_11)):Hide()
          table.remove(RaidGrid_ReadingBar.target, l_140_11)
          return 
        end
      end
    end
    do break end
  end
  if l_140_0 == "NPC_LEAVE_SCENE" then
    for l_140_16,l_140_17 in ipairs(RaidGrid_ReadingBar.target) do
      if l_140_17.caster.dwType == TARGET.NPC and l_140_17.caster.dwID == arg0 then
        Station.Lookup("Normal/RaidGrid_ReadingBar"):Lookup("", "Handle_Bar_" .. tostring(R11_PC95)):Hide()
        table.remove(RaidGrid_ReadingBar.target, R8_PC105)
        return 
      end
    end
  elseif l_140_0 == "UI_SCALED" then
    this:SetRelPos(RaidGrid_ReadingBar.loc.x, RaidGrid_ReadingBar.loc.y)
  elseif l_140_0 == "CUSTOM_DATA_LOADED" then
    this:SetRelPos(RaidGrid_ReadingBar.loc.x, RaidGrid_ReadingBar.loc.y)
  end
end

l_0_8.OnEvent = l_0_9
l_0_8 = RaidGrid_ReadingBar
l_0_9 = "OnLButtonUp"
l_0_10 = function()
  local l_141_0 = RaidGrid_ReadingBar.loc
  local l_141_1 = RaidGrid_ReadingBar.loc
  local l_141_2 = Station.Lookup("Normal/RaidGrid_ReadingBar"):GetRelPos()
  l_141_1.y = Station.Lookup("Normal/RaidGrid_ReadingBar")
  l_141_0.x = l_141_2
end

l_0_8[l_0_9] = l_0_10
RaidGrid_ScreenHead, l_0_8 = l_0_8, {}
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "nRenderCount"
l_0_10 = -1
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "firstCreate"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "arrow"
local l_0_11 = "color"
local l_0_12 = {}
l_0_12.r = 56
l_0_12.g = 81
l_0_12.b = 94
l_0_11 = "pointCenter"
local l_0_13 = "a"
l_0_12 = {x = 25, y = 25, [l_0_13] = 255}
l_0_11 = "point"
local l_0_14 = "a"
local l_0_15 = "a"
local l_0_16 = "a"
local l_0_17 = "a"
local l_0_18 = "a"
local l_0_19 = "a"
local l_0_20 = "a"
l_0_19, l_0_18, l_0_17, l_0_16, l_0_15, l_0_14, l_0_13 = {x = 15, y = 25, [l_0_20] = 180}, {x = 7, y = 25, [l_0_19] = 255}, {x = 25, y = 50, [l_0_18] = 180}, {x = 43, y = 25, [l_0_17] = 255}, {x = 35, y = 25, [l_0_16] = 180}, {x = 35, y = 0, [l_0_15] = 100}, {x = 15, y = 0, [l_0_14] = 100}
l_0_12 = {l_0_13, l_0_14, l_0_15, l_0_16, l_0_17, l_0_18, l_0_19}
l_0_8[l_0_9], l_0_10 = l_0_10, {[l_0_11] = l_0_12, [l_0_11] = l_0_12, [l_0_11] = l_0_12}
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateAllFrameInfo"
l_0_10 = function()
  local l_142_0 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
  local l_142_1 = l_142_0:GetItemCount()
  for l_142_5 = 0, l_142_1 - 1 do
    local l_142_6 = l_142_0:Lookup(l_142_5)
    local l_142_7 = GetPlayer(l_142_6.dwID)
    if not l_142_7 or l_142_7.nMoveState == MOVE_STATE.ON_DEATH then
      l_142_0:RemoveItem(l_142_5)
    else
      local l_142_8 = ""
      if l_142_6.aType == "Buff" or l_142_6.aType == "Debuff" then
        if not l_142_7.GetBuffList() then
          local l_142_9, l_142_10 = {}
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

        for l_142_14,l_142_15 in pairs(l_142_9) do
          local l_142_11 = nil
           -- DECOMPILER ERROR: Confused about usage of registers!

          if not l_142_16.nEndFrame then
            local l_142_17 = nil
            if (RaidGrid_Base.Time2String(((R14_PC44.dwID ~= l_142_6.dwBuffID or GetLogicFrameCount()) - GetLogicFrameCount()) / GLOBAL.GAME_FPS) == "" or l_142_16.bCanCancel) and l_142_6.aType == "Buff" then
              if l_142_16.nStackNum > 1 then
                l_142_8 = l_142_6.aText .. "(" .. l_142_16.nStackNum .. ")" .. "_" .. RaidGrid_Base.Time2String(((R14_PC44.dwID ~= l_142_6.dwBuffID or GetLogicFrameCount()) - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
                l_142_6:Lookup("Text_Alarm"):SetText(l_142_8)
               -- DECOMPILER ERROR: Confused about usage of registers!

              else
                l_142_8 = l_142_6.aText .. "_" .. RaidGrid_Base.Time2String(((R14_PC44.dwID ~= l_142_6.dwBuffID or GetLogicFrameCount()) - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
                l_142_6:Lookup("Text_Alarm"):SetText(l_142_8)
              end
             -- DECOMPILER ERROR: Confused about usage of registers!

            elseif not l_142_16.bCanCancel and l_142_6.aType == "Debuff" then
              if l_142_16.nStackNum > 1 then
                l_142_8 = l_142_6.aText .. "(" .. l_142_16.nStackNum .. ")" .. "_" .. RaidGrid_Base.Time2String(((R14_PC44.dwID ~= l_142_6.dwBuffID or GetLogicFrameCount()) - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
                l_142_6:Lookup("Text_Alarm"):SetText(l_142_8)
              end
             -- DECOMPILER ERROR: Confused about usage of registers!

            else
              l_142_8 = l_142_6.aText .. "_" .. RaidGrid_Base.Time2String(((R14_PC44.dwID ~= l_142_6.dwBuffID or GetLogicFrameCount()) - GetLogicFrameCount()) / GLOBAL.GAME_FPS)
              l_142_6:Lookup("Text_Alarm"):SetText(l_142_8)
            end
          end
        end
        if l_142_8 == "" and l_142_7.GetBuffList() then
          l_142_0:RemoveItem(l_142_5)
        end
      do
        else
          local l_142_18 = GetCharacterDistance(GetClientPlayer().dwID, l_142_7.dwID)
        end
        l_142_6:Lookup("Text_Distance"):SetText(string.format("%.1f", l_142_18 / 64) .. "��")
      end
    end
    if RaidGrid_ScreenHead.nRenderCount % 16 == 0 then
      l_142_0:Sort()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 57 
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "addAlarmFrame"
l_0_10 = function(l_143_0, l_143_1, l_143_2)
  local l_143_3 = GetPlayer(l_143_0)
  if not l_143_3 or l_143_3.nMoveState == MOVE_STATE.ON_DEATH then
    return 
  end
  local l_143_4 = l_143_1.szName
  local l_143_5 = l_143_1.dwID
  local l_143_6 = l_143_1.szType
  local l_143_7 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
  local l_143_8 = l_143_7:Lookup(l_143_0 .. "")
  if (l_143_1.nPriorityLevel or not l_143_8 or 1 <= l_143_8.nPriorityLevel) and l_143_2 then
    return 
  end
  if not l_143_8 then
    l_143_8 = l_143_7:AppendItemFromIni("Interface/RaidGrid_EventScrutiny/RaidGrid_ScreenHead.ini", "Handle_Label", l_143_0 .. "")
    l_143_8.dwID = l_143_0
    l_143_8.aType = l_143_6
    l_143_8.nPriorityLevel = l_143_1.nPriorityLevel or 1
    l_143_8.aText = l_143_4
    l_143_8.dwBuffID = l_143_5
    l_143_8.s = 1
    l_143_8:Lookup("Shadow_Arrow"):SetTriangleFan(true)
  elseif l_143_8.dwBuffID == l_143_5 then
    return 
  end
  if l_143_1.nPriorityLevel or 1 < l_143_8.nPriorityLevel then
    return 
  end
  l_143_8.aType = l_143_6
  l_143_8.aText = l_143_4
  l_143_8.dwBuffID = l_143_5
  l_143_8.nPriorityLevel = l_143_1.nPriorityLevel or 1
  local l_143_9 = l_143_8:Lookup("Text_Name")
  local l_143_10 = l_143_8:Lookup("Text_Alarm")
  local l_143_11 = l_143_8:Lookup("Text_Distance")
  local l_143_12 = {}
  if l_143_6 == "Buff" then
    local l_143_13 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_12.bgColor, l_143_13 = l_143_13, {255, 128, 0}
    l_143_13 = l_143_1.tRGBuffColor
    if l_143_13 then
      l_143_13 = l_143_1.tRGBuffColor
      l_143_13 = l_143_13[1]
      if l_143_13 == 0 then
        l_143_13 = l_143_1.tRGBuffColor
        l_143_13 = l_143_13[2]
      end
      if l_143_13 == 0 then
        l_143_13 = l_143_1.tRGBuffColor
        l_143_13 = l_143_13[3]
      end
    if l_143_13 ~= 0 then
      end
    end
    l_143_13 = l_143_12.bgColor
    l_143_13[1] = l_143_1.tRGBuffColor[1]
    l_143_13 = l_143_12.bgColor
    l_143_13[2] = l_143_1.tRGBuffColor[2]
    l_143_13 = l_143_12.bgColor
    l_143_13[3] = l_143_1.tRGBuffColor[3]
    l_143_13 = RaidGrid_ScreenHead
    l_143_13 = l_143_13.arrow
    l_143_13 = l_143_13.color
    l_143_13.r = l_143_12.bgColor[1]
    l_143_13 = RaidGrid_ScreenHead
    l_143_13 = l_143_13.arrow
    l_143_13 = l_143_13.color
    l_143_13.g = l_143_12.bgColor[2]
    l_143_13 = RaidGrid_ScreenHead
    l_143_13 = l_143_13.arrow
    l_143_13 = l_143_13.color
    l_143_13.b = l_143_12.bgColor[3]
    l_143_13(l_143_9, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_13(l_143_10, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_13(l_143_11, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
  elseif l_143_6 == "Debuff" then
    local l_143_14 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_12.bgColor, l_143_14 = l_143_14, {255, 0, 255}
    l_143_14 = l_143_1.tRGBuffColor
    if l_143_14 then
      l_143_14 = l_143_1.tRGBuffColor
      l_143_14 = l_143_14[1]
      if l_143_14 == 0 then
        l_143_14 = l_143_1.tRGBuffColor
        l_143_14 = l_143_14[2]
      end
      if l_143_14 == 0 then
        l_143_14 = l_143_1.tRGBuffColor
        l_143_14 = l_143_14[3]
      end
    if l_143_14 ~= 0 then
      end
    end
    l_143_14 = l_143_12.bgColor
    l_143_14[1] = l_143_1.tRGBuffColor[1]
    l_143_14 = l_143_12.bgColor
    l_143_14[2] = l_143_1.tRGBuffColor[2]
    l_143_14 = l_143_12.bgColor
    l_143_14[3] = l_143_1.tRGBuffColor[3]
    l_143_14 = RaidGrid_ScreenHead
    l_143_14 = l_143_14.arrow
    l_143_14 = l_143_14.color
    l_143_14.r = l_143_12.bgColor[1]
    l_143_14 = RaidGrid_ScreenHead
    l_143_14 = l_143_14.arrow
    l_143_14 = l_143_14.color
    l_143_14.g = l_143_12.bgColor[2]
    l_143_14 = RaidGrid_ScreenHead
    l_143_14 = l_143_14.arrow
    l_143_14 = l_143_14.color
    l_143_14.b = l_143_12.bgColor[3]
    l_143_14(l_143_9, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_14(l_143_10, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
     -- DECOMPILER ERROR: Overwrote pending register.

    l_143_14(l_143_11, l_143_12.fontColor[1], l_143_12.fontColor[2], l_143_12.fontColor[3])
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  l_143_14(l_143_9, l_143_3.szName)
  l_143_10:SetText(l_143_4 .. "")
  local l_143_15 = GetCharacterDistance(GetClientPlayer().dwID, l_143_0)
  l_143_11:SetText(string.format("%.1f", l_143_15 / 64) .. "��")
  if l_143_3.nCurrentLife / l_143_3.nMaxLife <= 1 or 1 < 0 then
    local l_143_16, l_143_18, l_143_20, l_143_22, l_143_24, l_143_26 = 0, l_143_3.nCurrentMana / l_143_3.nMaxMana
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if l_143_18 <= 1 or 1 < 0 then
    local l_143_17, l_143_19, l_143_21, l_143_23, l_143_25, l_143_27 = , 0
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_143_8:Lookup("Shadow_Life"):SetSize(math.floor(l_143_17 * 100), 6)
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_143_8:Lookup("Shadow_Mana"):SetSize(math.floor(l_143_19 * 100), 6)
  l_143_8:Show()
  RaidGrid_ScreenHead.updateFramePos(l_143_8)
  RaidGrid_ScreenHead.createArrow(l_143_8)
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "createArrow"
l_0_10 = function(l_144_0)
  local l_144_1 = l_144_0:Lookup("Shadow_Arrow")
  l_144_1:ClearTriangleFanPoint()
  l_144_1:AppendTriangleFanPoint(RaidGrid_ScreenHead.arrow.pointCenter.x, RaidGrid_ScreenHead.arrow.pointCenter.y, RaidGrid_ScreenHead.arrow.color.r, RaidGrid_ScreenHead.arrow.color.g, RaidGrid_ScreenHead.arrow.color.b, RaidGrid_ScreenHead.arrow.pointCenter.a)
  for l_144_5,l_144_6 in ipairs(RaidGrid_ScreenHead.arrow.point) do
    l_144_1:AppendTriangleFanPoint(l_144_6.x, l_144_6.y, RaidGrid_ScreenHead.arrow.color.r, RaidGrid_ScreenHead.arrow.color.g, RaidGrid_ScreenHead.arrow.color.b, l_144_6.a)
  end
  l_144_1:AppendTriangleFanPoint(RaidGrid_ScreenHead.arrow.point[1].x, RaidGrid_ScreenHead.arrow.point[1].y, RaidGrid_ScreenHead.arrow.color.r, RaidGrid_ScreenHead.arrow.color.g, RaidGrid_ScreenHead.arrow.color.b, RaidGrid_ScreenHead.arrow.point[1].a)
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateAllFrameData"
l_0_10 = function()
  local l_145_0 = GetClientPlayer()
  if not l_145_0 then
    return 
  end
  local l_145_1 = l_145_0.GetScene()
  if not l_145_1 then
    return 
  end
  local l_145_2 = KG3DEngine.GetScene(l_145_1.dwID)
  if not l_145_2 then
    return 
  end
  local l_145_3 = l_145_2:GetCamera()
  if not l_145_3 then
    return 
  end
  local l_145_4, l_145_5, l_145_6 = l_145_3:GetPosition()
  local l_145_7, l_145_8, l_145_9 = Scene_ScenePositionToGameWorldPosition(l_145_4, l_145_5, l_145_6)
  local l_145_10 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
  for l_145_14 = 0, l_145_10:GetItemCount() - 1 do
    local l_145_15 = (l_145_10:Lookup(l_145_14))
    local l_145_16 = nil
    if l_145_15 then
      l_145_16 = GetPlayer(l_145_15.dwID)
    end
    if l_145_16 then
      local l_145_17, l_145_18, l_145_19 = l_145_16.GetAbsoluteCoordinate()
      local l_145_20 = GetDistanceSq(l_145_7, l_145_8, l_145_9, l_145_17, l_145_18, l_145_19)
      l_145_15:SetUserData(-l_145_20)
    else
      l_145_10:RemoveItem(l_145_14)
    end
  end
  if RaidGrid_ScreenHead.nRenderCount % 16 == 0 then
    l_145_10:Sort()
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateAllFramePos"
l_0_10 = function()
  local l_146_0 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
  for l_146_4 = 0, l_146_0:GetItemCount() - 1 do
    local l_146_5 = l_146_0:Lookup(l_146_4)
    if l_146_5 then
      RaidGrid_ScreenHead.updateFramePos(l_146_5)
    end
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateFramePos"
l_0_10 = function(l_147_0)
  local l_147_1 = (GetPlayer(l_147_0.dwID))
  local l_147_2, l_147_3 = nil, nil
  local l_147_4 = false
  local l_147_5, l_147_6, l_147_7 = nil, nil, nil
  if l_147_1 then
    l_147_5 = Scene_GetCharacterTop(l_147_0.dwID)
  end
  if l_147_5 and l_147_6 and l_147_7 then
    l_147_2 = Scene_ScenePointToScreenPoint(l_147_5, l_147_6, l_147_7)
     -- DECOMPILER ERROR: Overwrote pending register.

    if l_147_4 then
      l_147_2 = RaidGrid_Base.AdjustToOriginalPos(l_147_2, l_147_3)
    end
  else
    l_147_0:SetAbsPos(-4096, -4096)
    return 
  end
  if l_147_4 then
    local l_147_8 = 100
    local l_147_9 = 130
    l_147_2 = l_147_2 - l_147_8 * 0.5
     -- DECOMPILER ERROR: Overwrote pending register.

    l_147_0:SetAbsPos(l_147_2, l_147_3)
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateAllFrameRelPos"
l_0_10 = function()
  local l_148_0 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
  for l_148_4 = 0, l_148_0:GetItemCount() - 1 do
    local l_148_5 = l_148_0:Lookup(l_148_4)
    if l_148_5 then
      RaidGrid_ScreenHead.updateFrameRelPos(l_148_5)
    end
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "updateFrameRelPos"
l_0_10 = function(l_149_0)
  local l_149_1 = l_149_0:Lookup("Shadow_Arrow")
  local l_149_2 = l_149_1:GetRelPos()
  do
    if l_149_0.s == 1 then
      local l_149_3 = l_149_1 + 2
      l_149_1:SetRelPos(l_149_2, l_149_3)
      if l_149_3 >= 80 then
        l_149_0.s = 0
      end
      l_149_0:FormatAllItemPos()
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  else
    local l_149_4 = l_149_3 - 2
    l_149_1:SetRelPos(l_149_2, l_149_4)
    if l_149_4 <= 70 then
      l_149_0.s = 1
    end
    l_149_0:FormatAllItemPos()
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = function()
  if RaidGrid_ScreenHead.firstCreate then
    RaidGrid_ScreenHead.firstCreate = false
    this:RegisterEvent("BUFF_UPDATE")
    this:RegisterEvent("RENDER_FRAME_UPDATE")
    this:RegisterEvent("PARTY_UPDATE_MEMBER_LMR")
    this:RegisterEvent("SYS_MSG")
    local l_150_0 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
    l_150_0:Clear()
  end
end

l_0_8.OnFrameCreate = l_0_9
l_0_8 = RaidGrid_ScreenHead
l_0_9 = function()
  RaidGrid_ScreenHead.nRenderCount = RaidGrid_ScreenHead.nRenderCount + 1
  if RaidGrid_ScreenHead.nRenderCount > 1000000 then
    RaidGrid_ScreenHead.nRenderCount = 1
  end
  if RaidGrid_EventScrutiny.bScreenHeadMonitor then
    RaidGrid_ScreenHead.updateAllFrameRelPos()
    if RaidGrid_ScreenHead.nRenderCount % 8 == 0 then
      RaidGrid_ScreenHead.updateAllFrameInfo()
    end
  else
    if RaidGrid_ScreenHead.nRenderCount % 8 == 0 then
      local l_151_0 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
      l_151_0:Clear()
    end
  end
end

l_0_8.OnFrameBreathe = l_0_9
l_0_8 = RaidGrid_ScreenHead
l_0_9 = function(l_152_0)
  if l_152_0 == "RENDER_FRAME_UPDATE" then
    RaidGrid_ScreenHead.updateAllFramePos()
  elseif l_152_0 == "PARTY_UPDATE_MEMBER_LMR" then
    local l_152_1 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
    local l_152_2 = l_152_1:Lookup(arg1 .. "")
    if l_152_2 then
      local l_152_3 = GetClientTeam()
      local l_152_4 = l_152_3.GetMemberInfo(l_152_2.dwID)
      if not l_152_4 or l_152_4.bDeathFlag then
        l_152_1:RemoveItem(arg1 .. "")
        return 
      end
      if l_152_4.nCurrentLife / l_152_4.nMaxLife <= 1 or 1 < 0 then
        local l_152_5, l_152_7, l_152_9 = 0, l_152_4.nCurrentMana / l_152_4.nMaxMana
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_152_7 <= 1 or 1 < 0 then
        local l_152_6, l_152_8, l_152_10 = , 0
      end
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_152_2:Lookup("Shadow_Life"):SetSize(math.floor(l_152_6 * 100), 6)
       -- DECOMPILER ERROR: Confused about usage of registers!

      l_152_2:Lookup("Shadow_Mana"):SetSize(math.floor(l_152_8 * 100), 6)
    end
  elseif l_152_0 == "BUFF_UPDATE" then
    local l_152_11 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
    local l_152_12 = l_152_11:Lookup(arg0 .. "")
    if l_152_12 then
      local l_152_13 = GetPlayer(l_152_12.dwID)
      if not l_152_13 or l_152_13.nMoveState == MOVE_STATE.ON_DEATH then
        l_152_11:RemoveItem(arg0 .. "")
        return 
      end
      if l_152_12.aType ~= "Buff" and l_152_12.aType ~= "Debuff" then
        return 
      end
      if arg7 then
        if not l_152_13.GetBuffList() then
          local l_152_14, l_152_15 = {}
        end
        local l_152_16 = nil
        for l_152_20,l_152_21 in pairs(l_152_16) do
          local l_152_17 = -1
           -- DECOMPILER ERROR: Confused about usage of registers!

          if 6.dwID == l_152_12.dwBuffID then
            l_152_17 = 1
          end
        end
         -- DECOMPILER ERROR: Confused about usage of registers!

      end
      if l_152_17 < 0 then
        l_152_11:RemoveItem(arg0 .. "")
        return 
      end
    elseif arg1 and arg4 == l_152_12.dwBuffID then
      l_152_11:RemoveItem(arg0 .. "")
      return 
    end
  elseif arg0 == "UI_OME_DEATH_NOTIFY" then
    local l_152_22 = Station.Lookup("Lowest/RaidGrid_ScreenHead", "")
    local l_152_23 = l_152_22:Lookup(arg1 .. "")
  end
  if l_152_23 then
    l_152_22:RemoveItem(arg1 .. "")
    return 
  end
end

l_0_8.OnEvent = l_0_9
l_0_8 = RaidGrid_ScreenHead
l_0_9 = function()
  if Station.Lookup("Lowest/RaidGrid_ScreenHead") then
    return true
  end
  return false
end

l_0_8.IsOpened = l_0_9
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "Close"
l_0_10 = function()
  if not RaidGrid_ScreenHead.IsOpened() then
    return 
  end
  Wnd.CloseWindow("RaidGrid_ScreenHead")
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "Open"
l_0_10 = function()
  if RaidGrid_ScreenHead.IsOpened() then
    return 
  end
  RaidGrid_ScreenHead.firstCreate = true
  Wnd.OpenWindow("interface\\RaidGrid_EventScrutiny\\RaidGrid_ScreenHead.ini", "RaidGrid_ScreenHead")
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_ScreenHead
l_0_9 = "Control"
l_0_10 = function()
  if RaidGrid_EventScrutiny.bScreenHeadMonitor then
    RaidGrid_ScreenHead.Open()
  else
    RaidGrid_ScreenHead.Close()
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
if not l_0_8 then
  RaidGrid_BossCallAlert, l_0_8 = l_0_8, {}
end
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "TalkMonitor"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bWarningMessageMonitor"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bDungeonOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bBossOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bPartyOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "macthall"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "WHISPER"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "RAID"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = true
l_0_8.Flash = l_0_9
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "CenterAlarm"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bAutoSelect"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "bChatAlertEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "tRGRedAlarm"
l_0_11 = 0
l_0_12 = 255
l_0_13 = 0
l_0_14 = 1
l_0_8[l_0_9], l_0_10 = l_0_10, {l_0_11, l_0_12, l_0_13, l_0_14}
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.TalkMonitor"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bWarningMessageMonitor"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bDungeonOnly"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bBossOnly"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bPartyOnly"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.macthall"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.WHISPER"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.RAID"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.Flash"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.CenterAlarm"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.tRGRedAlarm"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bAutoSelect"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.bChatAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "ChannelSay"
l_0_10 = function(l_157_0, l_157_1)
  local l_157_2 = GetClientPlayer()
  local l_157_3 = RaidGrid_BossCallAlert.tRGRedAlarm[1]
  local l_157_4 = RaidGrid_BossCallAlert.tRGRedAlarm[2]
  local l_157_5 = RaidGrid_BossCallAlert.tRGRedAlarm[3]
  if l_157_2.szName == l_157_0 and (RaidGrid_BossCallAlert.Flash or RaidGrid_BossCallAlert.CenterAlarm) then
    RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, l_157_1 .. "�㡾�㡿���ˣ�����", RaidGrid_BossCallAlert.Flash, RaidGrid_BossCallAlert.CenterAlarm, l_157_3, l_157_4, l_157_5)
  end
  do return end
  if RaidGrid_BossCallAlert.CenterAlarm then
    RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, l_157_1 .. "�㡾" .. l_157_0 .. "�����ˣ�����", false, true, l_157_3, l_157_4, l_157_5)
  end
  if RaidGrid_BossCallAlert.bChatAlertEnable and RaidGrid_BossCallAlert.WHISPER then
    local l_157_6 = l_157_2.Talk
    local l_157_7 = PLAYER_TALK_CHANNEL.WHISPER
    local l_157_8 = l_157_0
    local l_157_9 = {}
    local l_157_10 = {}
    l_157_10.type = "text"
    l_157_10.text = l_157_1 .. "�㡾�㡿���ˣ�����"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_157_6(l_157_7, l_157_8, l_157_9)
  end
  if RaidGrid_BossCallAlert.bChatAlertEnable and RaidGrid_BossCallAlert.RAID then
    local l_157_11 = l_157_2.Talk
    local l_157_12 = RaidGrid_EventScrutiny.nSayChannel
    local l_157_13 = ""
    local l_157_14 = {}
    local l_157_15 = {}
    l_157_15.type = "text"
    l_157_15.text = l_157_1 .. "�㡾" .. l_157_0 .. "�����ˣ�����"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_157_11(l_157_12, l_157_13, l_157_14)
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "CallProcess"
l_0_10 = function(l_158_0, l_158_1)
  local l_158_2 = GetClientPlayer()
  if not l_158_2 then
    return 
  end
  if not l_158_2.IsInParty() and RaidGrid_BossCallAlert.bPartyOnly then
    return 
  end
  if string.find(l_158_1, l_158_2.szName) then
    RaidGrid_BossCallAlert.ChannelSay(l_158_2.szName, l_158_0)
  end
  if RaidGrid_BossCallAlert.bAutoSelect then
    RaidGrid_Base.SetTarget(l_158_2.dwID)
  end
  if l_158_2.IsInParty() and RaidGrid_BossCallAlert.macthall then
    local l_158_3 = GetClientTeam()
    local l_158_4 = l_158_3.nGroupNum
    for l_158_8 = 0, l_158_4 - 1 do
      local l_158_9 = l_158_3.GetGroupInfo(l_158_8)
      if l_158_9 and l_158_9.MemberList then
        for l_158_13,l_158_14 in pairs(l_158_9.MemberList) do
          local l_158_15 = l_158_3.GetMemberInfo(l_158_14)
          if l_158_15 and string.find(l_158_1, l_158_15.szName) and l_158_15.szName ~= l_158_2.szName then
            RaidGrid_BossCallAlert.ChannelSay(l_158_15.szName, l_158_0)
          end
          if RaidGrid_BossCallAlert.bAutoSelect then
            RaidGrid_Base.SetTarget(l_158_14)
          end
        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "ProcessBossCallSet"
l_0_10 = function(l_159_0, l_159_1)
  do
    local l_159_2 = GetClientPlayer()
    if not l_159_2 or not RaidGrid_BossCallAlert.tRecords or not RaidGrid_BossCallAlert.tRecords.tBossCall then
      return 
    end
    for l_159_6 = 1, #RaidGrid_BossCallAlert.tRecords.tBossCall do
      local l_159_7 = RaidGrid_BossCallAlert.tRecords.tBossCall[l_159_6]
      if l_159_7.bOn and l_159_7.szText and l_159_7.szText ~= "" and string.find(l_159_1, l_159_7.szText) and (not l_159_7.szBossName or l_159_7.szBossName == "" or l_159_7.szBossName == l_159_0) then
        local l_159_8 = RaidGrid_BossCallAlert.tRGRedAlarm[1]
        local l_159_9 = RaidGrid_BossCallAlert.tRGRedAlarm[2]
        local l_159_10 = RaidGrid_BossCallAlert.tRGRedAlarm[3]
        RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, l_159_7.szName or l_159_1, l_159_7.bFlash, l_159_7.bCenterAlarm, l_159_8, l_159_9, l_159_10)
        local l_159_11 = {}
        local l_159_12 = {}
        l_159_12.type = "text"
        l_159_12.text = l_159_7.szName or l_159_1
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_159_12 = RaidGrid_BossCallAlert
        l_159_12 = l_159_12.bChatAlertEnable
        if l_159_12 then
          l_159_12 = l_159_7.bRAID
        end
        if l_159_12 then
          l_159_12 = l_159_2.Talk
          l_159_12(RaidGrid_EventScrutiny.nSayChannel, "", l_159_11)
        end
        l_159_12 = RaidGrid_BossCallAlert
        l_159_12 = l_159_12.bChatAlertEnable
        if l_159_12 then
          l_159_12 = l_159_7.bWHISPER
        end
        if l_159_12 then
          l_159_12 = RaidGrid_Base
          l_159_12 = l_159_12.WhisperToPartyMember
          l_159_12(l_159_11)
        end
        l_159_12 = l_159_7.nTime1
        if l_159_12 then
          l_159_12 = l_159_7.nTime1
        end
        if l_159_12 > 0 then
          l_159_12 = RaidGrid_SkillTimer
          l_159_12 = l_159_12.StartNewSkillTimer
          if l_159_7.szName or RaidGrid_EventScrutiny.bSkillTimerSay then
            l_159_12(l_159_7.szText, 2000, 1, l_159_7.nTime1 * 16, l_159_7.bRAID, RaidGrid_EventScrutiny.nSayChannel, false)
          end
          l_159_12 = l_159_7.nTime2
          if l_159_12 then
            l_159_12 = l_159_7.nTime2
          end
          if l_159_12 > 0 then
            l_159_12 = RaidGrid_SkillTimer
            l_159_12 = l_159_12.StartNewSkillTimer
            if l_159_7.szName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
              l_159_12(l_159_7.szText, 2000, 1, l_159_7.nTime2 * 16, l_159_7.bRAID, RaidGrid_EventScrutiny.nSayChannel, false)
            end
            return 
          end
        end
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 128 153 
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "BossCall"
l_0_10 = function(l_160_0)
  if l_160_0 == "PLAYER_SAY" and RaidGrid_EventScrutiny.bEnable and RaidGrid_BossCallAlert.TalkMonitor then
    local l_160_1 = GetNpc(arg1)
    if not l_160_1 then
      return 
    end
    if RaidGrid_BossCallAlert.bDungeonOnly and not RaidGrid_Base.IsInDungeon() then
      return 
    end
    if RaidGrid_BossCallAlert.bBossOnly and RaidGrid_Base.ToGetNpcIntensity(l_160_1) < 4 then
      return 
    end
    if not l_160_1.szName then
      local l_160_2, l_160_3 = tostring(arg3)
    end
    local l_160_4 = nil
    RaidGrid_BossCallAlert.ProcessBossCallSet(l_160_4, arg0)
     -- DECOMPILER ERROR: Confused about usage of registers!

    RaidGrid_BossCallAlert.CallProcess(l_160_4, arg0)
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterEvent
l_0_9 = "PLAYER_SAY"
l_0_10 = RaidGrid_BossCallAlert
l_0_11 = "BossCall"
l_0_10 = l_0_10[l_0_11]
l_0_8(l_0_9, l_0_10)
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "szGetMessageText1"
l_0_8[l_0_9] = ""
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "szGetMessageTimeEnd1"
l_0_10 = 0
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "szGetMessageText2"
l_0_8[l_0_9] = ""
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "szGetMessageTimeEnd2"
l_0_10 = 0
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "nGetMessageTimeCD"
l_0_10 = 5
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "GetWarningMessage"
l_0_10 = function()
  if not RaidGrid_EventScrutiny.bEnable then
    return 
  end
  if not RaidGrid_BossCallAlert.bWarningMessageMonitor then
    return 
  end
  local l_161_0 = ""
  local l_161_1 = RaidGrid_Base.GetLogicTime()
  local l_161_2 = Station.Lookup("Topmost/WarningTipPanel1")
  if l_161_2 then
    local l_161_3 = l_161_2:Lookup("", "Text_Tip")
  end
  if l_161_3 then
    l_161_0 = l_161_3:GetText()
  end
  if l_161_0 and l_161_0 ~= "" and (l_161_0 ~= RaidGrid_BossCallAlert.szGetMessageText1 or RaidGrid_BossCallAlert.szGetMessageTimeEnd1 <= l_161_1) then
    RaidGrid_BossCallAlert.szGetMessageText1 = l_161_0
    RaidGrid_BossCallAlert.szGetMessageTimeEnd1 = l_161_1 + RaidGrid_BossCallAlert.nGetMessageTimeCD
    RaidGrid_BossCallAlert.OutputWarningMessageAdd(l_161_0)
  end
  local l_161_4 = ""
  local l_161_5 = Station.Lookup("Topmost/WarningTipPanel2")
  if l_161_5 then
    local l_161_6 = l_161_5:Lookup("", "Text_Tip")
  end
  if l_161_6 then
    l_161_4 = l_161_6:GetText()
  end
  if l_161_4 and l_161_4 ~= "" and (l_161_4 ~= RaidGrid_BossCallAlert.szGetMessageText2 or RaidGrid_BossCallAlert.szGetMessageTimeEnd2 <= l_161_1) then
    RaidGrid_BossCallAlert.szGetMessageText2 = l_161_4
    RaidGrid_BossCallAlert.szGetMessageTimeEnd2 = l_161_1 + RaidGrid_BossCallAlert.nGetMessageTimeCD
    RaidGrid_BossCallAlert.OutputWarningMessageAdd(l_161_4)
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "tWarningMessages"
l_0_11 = 1
l_0_12 = "��������ʩչ��ػ�"
l_0_11 = 2
l_0_12 = "���Ѷ�����ʩչ��ɨ�˻ģ�"
l_0_11 = 3
l_0_12 = "½Ѱ˫�۷ų����⣡"
l_0_11 = 4
l_0_12 = "��֮��������̧��˫�ۣ�"
l_0_8[l_0_9], l_0_10 = l_0_10, {[l_0_11] = l_0_12, [l_0_11] = l_0_12, [l_0_11] = l_0_12, [l_0_11] = l_0_12}
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "ProcessWarningMessagesSet"
l_0_10 = function(l_162_0)
  do
    local l_162_1 = GetClientPlayer()
    if not l_162_1 or not RaidGrid_BossCallAlert.tRecords or not RaidGrid_BossCallAlert.tRecords.tWarningMessages then
      return 
    end
    for l_162_5 = 1, #RaidGrid_BossCallAlert.tRecords.tWarningMessages do
      local l_162_6 = RaidGrid_BossCallAlert.tRecords.tWarningMessages[l_162_5]
      if l_162_6.bOn and l_162_6.szText and l_162_6.szText ~= "" and string.find(l_162_0, l_162_6.szText) then
        local l_162_7 = RaidGrid_BossCallAlert.tRGRedAlarm[1]
        local l_162_8 = RaidGrid_BossCallAlert.tRGRedAlarm[2]
        local l_162_9 = RaidGrid_BossCallAlert.tRGRedAlarm[3]
        RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, l_162_6.szName or l_162_0, l_162_6.bFlash, l_162_6.bCenterAlarm, l_162_7, l_162_8, l_162_9)
        local l_162_10 = {}
        local l_162_11 = {}
        l_162_11.type = "text"
        l_162_11.text = l_162_6.szName or l_162_0
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_162_11 = RaidGrid_BossCallAlert
        l_162_11 = l_162_11.bChatAlertEnable
        if l_162_11 then
          l_162_11 = l_162_6.bRAID
        end
        if l_162_11 then
          l_162_11 = l_162_1.Talk
          l_162_11(RaidGrid_EventScrutiny.nSayChannel, "", l_162_10)
        end
        l_162_11 = RaidGrid_BossCallAlert
        l_162_11 = l_162_11.bChatAlertEnable
        if l_162_11 then
          l_162_11 = l_162_6.bWHISPER
        end
        if l_162_11 then
          l_162_11 = RaidGrid_Base
          l_162_11 = l_162_11.WhisperToPartyMember
          l_162_11(l_162_10)
        end
        l_162_11 = l_162_6.nTime1
        if l_162_11 then
          l_162_11 = l_162_6.nTime1
        end
        if l_162_11 > 0 then
          l_162_11 = RaidGrid_SkillTimer
          l_162_11 = l_162_11.StartNewSkillTimer
          if l_162_6.szName or RaidGrid_EventScrutiny.bSkillTimerSay then
            l_162_11(l_162_6.szText, 2000, 1, l_162_6.nTime1 * 16, l_162_6.bRAID, RaidGrid_EventScrutiny.nSayChannel, false)
          end
          l_162_11 = l_162_6.nTime2
          if l_162_11 then
            l_162_11 = l_162_6.nTime2
          end
          if l_162_11 > 0 then
            l_162_11 = RaidGrid_SkillTimer
            l_162_11 = l_162_11.StartNewSkillTimer
            if l_162_6.szName2 or RaidGrid_EventScrutiny.bSkillTimerSay then
              l_162_11(l_162_6.szText, 2000, 1, l_162_6.nTime2 * 16, l_162_6.bRAID, RaidGrid_EventScrutiny.nSayChannel, false)
            end
            return 
          end
        end
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 119 144 
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "OutputWarningMessageAdd"
l_0_10 = function(l_163_0)
  local l_163_1 = GetClientPlayer()
  if not l_163_1 then
    return 
  end
  if RaidGrid_BossCallAlert.bDungeonOnly and not RaidGrid_Base.IsInDungeon() then
    return 
  end
  if RaidGrid_BossCallAlert.bPartyOnly and not l_163_1.IsInParty() then
    return 
  end
  if not l_163_0 then
    return 
  end
  local l_163_2 = tostring(l_163_0)
  RaidGrid_BossCallAlert.ProcessWarningMessagesSet(l_163_2)
  if string.find(l_163_2, l_163_1.szName) then
    RaidGrid_BossCallAlert.WarningMessageAlarm(l_163_1.szName, l_163_2)
  end
  if RaidGrid_BossCallAlert.bAutoSelect then
    RaidGrid_Base.SetTarget(l_163_1.dwID)
  end
  if l_163_1.IsInParty() and RaidGrid_BossCallAlert.macthall then
    local l_163_3 = GetClientTeam()
    local l_163_4 = l_163_3.nGroupNum
    for l_163_8 = 0, l_163_4 - 1 do
      local l_163_9 = l_163_3.GetGroupInfo(l_163_8)
      if l_163_9 and l_163_9.MemberList then
        for l_163_13,l_163_14 in pairs(l_163_9.MemberList) do
          local l_163_15 = l_163_3.GetMemberInfo(l_163_14)
          if l_163_15 and string.find(l_163_2, l_163_15.szName) and l_163_15.szName ~= l_163_1.szName then
            RaidGrid_BossCallAlert.WarningMessageAlarm(l_163_15.szName, l_163_2)
          end
          if RaidGrid_BossCallAlert.bAutoSelect then
            RaidGrid_Base.SetTarget(l_163_14)
          end
        end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "WarningMessageAlarm"
l_0_10 = function(l_164_0, l_164_1)
  local l_164_2 = GetClientPlayer()
  local l_164_3 = RaidGrid_BossCallAlert.tRGRedAlarm[1]
  local l_164_4 = RaidGrid_BossCallAlert.tRGRedAlarm[2]
  local l_164_5 = RaidGrid_BossCallAlert.tRGRedAlarm[3]
  if l_164_2.szName == l_164_0 and (RaidGrid_BossCallAlert.Flash or RaidGrid_BossCallAlert.CenterAlarm) then
    RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, "���㡿�������ˣ�����", RaidGrid_BossCallAlert.Flash, RaidGrid_BossCallAlert.CenterAlarm, l_164_3, l_164_4, l_164_5)
  end
  do return end
  if RaidGrid_BossCallAlert.CenterAlarm then
    RaidGrid_RedAlarm.Flash(RaidGrid_EventScrutiny.nCenterAlarmTime, "��" .. l_164_0 .. "���������ˣ�����", false, true, l_164_3, l_164_4, l_164_5)
  end
  if RaidGrid_BossCallAlert.bChatAlertEnable and RaidGrid_BossCallAlert.WHISPER then
    local l_164_6 = l_164_2.Talk
    local l_164_7 = PLAYER_TALK_CHANNEL.WHISPER
    local l_164_8 = l_164_0
    local l_164_9 = {}
    local l_164_10 = {}
    l_164_10.type = "text"
    l_164_10.text = "���㡿�������ˣ�����"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_164_6(l_164_7, l_164_8, l_164_9)
  end
  if RaidGrid_BossCallAlert.bChatAlertEnable and RaidGrid_BossCallAlert.RAID then
    local l_164_11 = l_164_2.Talk
    local l_164_12 = RaidGrid_EventScrutiny.nSayChannel
    local l_164_13 = ""
    local l_164_14 = {}
    local l_164_15 = {}
    l_164_15.type = "text"
    l_164_15.text = "��" .. l_164_0 .. "���������ˣ�����"
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_164_11(l_164_12, l_164_13, l_164_14)
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_10 = "tWarningMessages"
l_0_12 = 1
l_0_14 = "szType"
l_0_15 = "tWarningMessages"
l_0_14 = "szName"
l_0_15 = "��������ʩչ��ػ�"
l_0_14 = "szText"
l_0_15 = "��������ʩչ��ػ�"
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_12 = 2
l_0_14 = "szType"
l_0_15 = "tWarningMessages"
l_0_14 = "szName"
l_0_15 = "���Ѷ�����ʩչ��ɨ�˻ģ�"
l_0_14 = "szText"
l_0_15 = "���Ѷ�����ʩչ��ɨ�˻ģ�"
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_12 = 3
l_0_14 = "szType"
l_0_15 = "tWarningMessages"
l_0_14 = "szName"
l_0_15 = "½Ѱ˫�۷ų����⣡"
l_0_14 = "szText"
l_0_15 = "½Ѱ˫�۷ų����⣡"
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_12 = 4
l_0_14 = "szType"
l_0_15 = "tWarningMessages"
l_0_14 = "szName"
l_0_15 = "��֮��������̧��˫�ۣ�"
l_0_14 = "szText"
l_0_15 = "��֮��������̧��˫�ۣ�"
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_11 = {[l_0_12] = l_0_13, [l_0_12] = l_0_13, [l_0_12] = l_0_13, [l_0_12] = l_0_13}
l_0_10 = "tBossCall"
l_0_12 = 1
l_0_14 = "szType"
l_0_15 = "tBossCall"
l_0_14 = "szName"
l_0_15 = "��������������"
l_0_14 = "szBossName"
l_0_15 = "������"
l_0_14 = "szText"
l_0_15 = "��ҫ�Ĺ�����"
l_0_14 = "nTime1"
l_0_15 = 50
l_0_14 = "szName2"
l_0_15 = "���˵���ʱ"
l_0_14 = "nTime2"
l_0_15 = 20
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_12 = 2
l_0_14 = "szType"
l_0_15 = "tBossCall"
l_0_14 = "szName"
l_0_15 = "ɳ���ǽ�������״̬"
l_0_14 = "szBossName"
l_0_15 = "ɳ����"
l_0_14 = "szText"
l_0_15 = "������"
l_0_14 = "nTime1"
l_0_15 = 61
l_0_14 = "szName2"
l_0_15 = "��������ʣ��ʱ��"
l_0_14 = "nTime2"
l_0_15 = 28
l_0_14 = "bRAID"
l_0_15 = false
l_0_14 = "bWHISPER"
l_0_15 = false
l_0_14 = "bFlash"
l_0_15 = true
l_0_14 = true
l_0_14 = "bOn"
l_0_15 = true
l_0_13 = {[l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, [l_0_14] = l_0_15, bCenterAlarm = l_0_14, [l_0_14] = l_0_15}
l_0_11 = {[l_0_12] = l_0_13, [l_0_12] = l_0_13}
l_0_8.tRecords, l_0_9 = l_0_9, {[l_0_10] = l_0_11, [l_0_10] = l_0_11}
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_BossCallAlert.tRecords"
l_0_8(l_0_9)
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "tDefaultSetForAdd"
l_0_11 = "bRAID"
l_0_12 = false
l_0_11 = "bWHISPER"
l_0_12 = false
l_0_11 = "bFlash"
l_0_12 = true
l_0_11 = true
l_0_11 = "bOn"
l_0_12 = true
l_0_8[l_0_9], l_0_10 = l_0_10, {[l_0_11] = l_0_12, [l_0_11] = l_0_12, [l_0_11] = l_0_12, bCenterAlarm = l_0_11, [l_0_11] = l_0_12}
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewName"
l_0_10 = function(l_165_0)
  if not l_165_0 then
    return 
  end
  do
    GetUserInput("���������֣�", function(l_166_0)
    -- upvalues: l_165_0
    if not l_166_0 or l_166_0 == "" then
      return 
    end
    l_165_0.szName = l_166_0
  end, nil, function()
  end, nil, l_165_0.szName, 310)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewName2"
l_0_10 = function(l_166_0)
  if not l_166_0 then
    return 
  end
  do
    GetUserInput("���뵹��ʱ����2��", function(l_167_0)
    -- upvalues: l_166_0
    if not l_167_0 or l_167_0 == "" then
      return 
    end
    l_166_0.szName2 = l_167_0
  end, nil, function()
  end, nil, l_166_0.szName2, 310)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewBossName"
l_0_10 = function(l_167_0)
  if not l_167_0 then
    return 
  end
  do
    GetUserInput("������Boss���֣�", function(l_168_0)
    -- upvalues: l_167_0
    l_167_0.szBossName = l_168_0
  end, nil, function()
  end, nil, l_167_0.szBossName, 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewText"
l_0_10 = function(l_168_0)
  if not l_168_0 then
    return 
  end
  do
    GetUserInput("�����º������ݣ�", function(l_169_0)
    -- upvalues: l_168_0
    if not l_169_0 or l_169_0 == "" then
      return 
    end
    l_168_0.szText = l_169_0
  end, nil, function()
  end, nil, l_168_0.szText, 310)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewTime1"
l_0_10 = function(l_169_0)
  if not l_169_0 then
    return 
  end
  do
    GetUserInput("�����µ���ʱ1��", function(l_170_0)
    -- upvalues: l_169_0
    if not l_170_0 or l_170_0 == "" then
      return 
    end
    local l_170_1 = tonumber(l_170_0)
    if not l_170_1 then
      return 
    end
    if l_170_1 >= 0 then
      l_169_0.nTime1 = l_170_1
    end
  end, nil, function()
  end, nil, l_169_0.nTime1, 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "SetNewTime2"
l_0_10 = function(l_170_0)
  if not l_170_0 then
    return 
  end
  do
    GetUserInput("�����µ���ʱ2��", function(l_171_0)
    -- upvalues: l_170_0
    if not l_171_0 or l_171_0 == "" then
      return 
    end
    local l_171_1 = tonumber(l_171_0)
    if not l_171_1 then
      return 
    end
    if l_171_1 >= 0 then
      l_170_0.nTime2 = l_171_1
    end
  end, nil, function()
  end, nil, l_170_0.nTime2, 31)
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "AddList"
l_0_10 = function(l_171_0, l_171_1)
  if not l_171_1 or l_171_1 == "" then
    return 
  end
  local l_171_2 = clone(RaidGrid_BossCallAlert.tDefaultSetForAdd)
  l_171_2.szName = l_171_1
  l_171_2.szText = l_171_1
  l_171_2.szType = l_171_0
  table.insert(RaidGrid_BossCallAlert.tRecords[l_171_0], l_171_2)
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "tRecordsNames"
l_0_11 = "tWarningMessages"
l_0_12 = "���ٷ��Դ���ʾ������������ã�"
l_0_11 = "tBossCall"
l_0_12 = "��������NPC����������ã�"
l_0_8[l_0_9], l_0_10 = l_0_10, {[l_0_11] = l_0_12, [l_0_11] = l_0_12}
l_0_8 = RaidGrid_BossCallAlert
l_0_9 = "tPopOptions"
l_0_10 = function(l_172_0)
  local l_172_1 = {}
  l_172_1.szOption = RaidGrid_BossCallAlert.tRecordsNames[l_172_0]
  for l_172_5 = 1, #RaidGrid_BossCallAlert.tRecords[l_172_0] do
    do
      local l_172_6 = RaidGrid_BossCallAlert.tRecords[l_172_0][l_172_5]
      do
        local l_172_7 = {}
        l_172_7.szOption = l_172_6.szName
        l_172_7.bCheck = true
        l_172_7.bChecked = l_172_6.bOn
        l_172_7.fnAction = function()
          -- upvalues: l_172_6
          l_172_6.bOn = not l_172_6.bOn
        end
        l_172_7.fnAutoClose = function()
          return true
        end
        local l_172_8 = {}
        l_172_8.szOption = "�������֣�" .. l_172_6.szName
        l_172_8.bCheck = false
        l_172_8.bChecked = false
        l_172_8.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewName(l_172_6)
        end
        l_172_8.fnAutoClose = function()
          return true
        end
        local l_172_9 = {}
        l_172_9.szOption = "NPC���֣�" .. (l_172_6.szBossName or "δ����")
        l_172_9.bCheck = false
        l_172_9.bChecked = false
        l_172_9.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewBossName(l_172_6)
        end
        l_172_9.fnAutoClose = function()
          return true
        end
        local l_172_10 = {}
        l_172_10.szOption = "�������ݣ�" .. (l_172_6.szText or "δ����")
        l_172_10.bCheck = false
        l_172_10.bChecked = false
        l_172_10.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewText(l_172_6)
        end
        l_172_10.fnAutoClose = function()
          return true
        end
        local l_172_11 = {}
        l_172_11.szOption = "����ʱ1��" .. tostring(l_172_6.nTime1 or 0) .. "��"
        l_172_11.bCheck = false
        l_172_11.bChecked = false
        l_172_11.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewTime1(l_172_6)
        end
        l_172_11.fnAutoClose = function()
          return true
        end
        local l_172_12 = {}
        l_172_12.szOption = "����ʱ����2��" .. (l_172_6.szName2 or "δ����")
        l_172_12.bCheck = false
        l_172_12.bChecked = false
        l_172_12.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewName2(l_172_6)
        end
        l_172_12.fnAutoClose = function()
          return true
        end
        local l_172_13 = {}
        l_172_13.szOption = "����ʱ2��" .. tostring(l_172_6.nTime2 or 0) .. "��"
        l_172_13.bCheck = false
        l_172_13.bChecked = false
        l_172_13.fnAction = function()
          -- upvalues: l_172_6
          RaidGrid_BossCallAlert.SetNewTime2(l_172_6)
        end
        l_172_13.fnAutoClose = function()
          return true
        end
        local l_172_14 = {}
        l_172_14.szOption = "�����Ŷ�Ƶ��ͨ��"
        l_172_14.bCheck = true
        l_172_14.bChecked = l_172_6.bRAID
        l_172_14.fnAction = function(l_187_0, l_187_1)
          -- upvalues: l_172_6
          l_172_6.bRAID = l_187_1
        end
        local l_172_15 = {}
        l_172_15.szOption = "��������Ƶ��ͨ��"
        l_172_15.bCheck = true
        l_172_15.bChecked = l_172_6.bWHISPER
        l_172_15.fnAction = function(l_188_0, l_188_1)
          -- upvalues: l_172_6
          l_172_6.bWHISPER = l_188_1
        end
        local l_172_16 = {}
        l_172_16.szOption = "����ȫ��������ʾ"
        l_172_16.bCheck = true
        l_172_16.bChecked = l_172_6.bFlash
        l_172_16.fnAction = function(l_189_0, l_189_1)
          -- upvalues: l_172_6
          l_172_6.bFlash = l_189_1
        end
        local l_172_17 = {}
        l_172_17.szOption = "��������������ʾ"
        l_172_17.bCheck = true
        l_172_17.bChecked = l_172_6.bCenterAlarm
        l_172_17.fnAction = function(l_190_0, l_190_1)
          -- upvalues: l_172_6
          l_172_6.bCenterAlarm = l_190_1
        end
        local l_172_18 = {}
        l_172_18.szOption = "ɾ������"
        l_172_18.fnAction = function()
          -- upvalues: l_172_0 , l_172_5
          table.remove(RaidGrid_BossCallAlert.tRecords[l_172_0], l_172_5)
        end
        table.insert(l_172_7, l_172_8)
        local l_172_19 = table.insert
        local l_172_20 = l_172_7
        local l_172_21 = {}
        l_172_21.bDevide = true
        l_172_19(l_172_20, l_172_21)
        if l_172_0 == "tBossCall" then
          l_172_19 = table
          l_172_19 = l_172_19.insert
          l_172_20 = l_172_7
          l_172_21 = l_172_9
          l_172_19(l_172_20, l_172_21)
        end
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_10
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_19(l_172_20, l_172_21)
        l_172_21 = {bDevide = true}
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_11
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_19(l_172_20, l_172_21)
        l_172_21 = {bDevide = true}
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_12
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_13
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_19(l_172_20, l_172_21)
        l_172_21 = {bDevide = true}
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_14
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_15
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_19(l_172_20, l_172_21)
        l_172_21 = {bDevide = true}
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_16
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_17
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_19(l_172_20, l_172_21)
        l_172_21 = {bDevide = true}
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_7
        l_172_21 = l_172_18
        l_172_19(l_172_20, l_172_21)
        l_172_19 = table
        l_172_19 = l_172_19.insert
        l_172_20 = l_172_1
        l_172_21 = l_172_7
        l_172_19(l_172_20, l_172_21)
      end
    end
    local l_172_22 = table.insert
    local l_172_23 = l_172_1
    do
      local l_172_24 = {}
      l_172_24.bDevide = true
      l_172_22(l_172_23, l_172_24)
      l_172_23 = function()
      -- upvalues: l_172_0
      local l_192_0 = GetUserInput
      l_192_0("�������֣�", function(l_193_0)
        -- upvalues: l_172_0
        RaidGrid_BossCallAlert.AddList(l_172_0, l_193_0)
      end, nil, nil, nil, nil)
    end
      l_172_23 = table
      l_172_23 = l_172_23.insert
      l_172_24 = l_172_1
      l_172_23(l_172_24, l_172_22)
      return l_172_1
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCacheEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCacheEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bAddByNameEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bAddByNameEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNotCheckLevel"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNotCheckLevel"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffCacheEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffCacheEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffCacheVisibleOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffCacheVisibleOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffCacheDungeonOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffCacheDungeonOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bSelfBuffScrutinyEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bSelfBuffScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bEnemyBuffScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bEnemyBuffScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bEnemyOnlyBuffScrutiny"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bEnemyOnlyBuffScrutiny"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bPartyOnlyDebuffScrutiny"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bPartyOnlyDebuffScrutiny"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffTeamScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffTeamScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffTeamExScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffTeamExScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bRaidGridExSelfDisable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bRaidGridExSelfDisable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffChatAlertEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffChatAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bScreenHeadMonitor"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bScreenHeadMonitor"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffShowIcon"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffShowIcon"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffShowTime"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffShowTime"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffShowShadow"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffShowShadow"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nBuffShowShadowAlpha"
l_0_10 = 0.6
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nBuffShowShadowAlpha"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nBuffAutoRemoveCachePage"
l_0_10 = 50
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nBuffAutoRemoveCachePage"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingCacheEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingCacheEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingCacheDungeonOnly"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingCacheDungeonOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingScrutinyDungeonOnly"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingScrutinyDungeonOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingChatAlertEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingChatAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingEnemyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingEnemyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingNeutralEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingNeutralEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingAllyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingAllyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingNPCOnly"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingNPCOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingBossOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingBossOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCastingReadingBar"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCastingReadingBar"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nCastingAutoRemoveCachePage"
l_0_10 = 50
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nCastingAutoRemoveCachePage"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcCacheEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcCacheEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcCacheDungeonOnly"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcCacheDungeonOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcLeaveScrutinyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcLeaveScrutinyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcChatAlertEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcChatAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcEnemyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcEnemyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcForceChangeEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcForceChangeEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcNeutralEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcNeutralEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcAllyEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcAllyEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcUnselectableOnly"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcUnselectableOnly"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nNpcAutoRemoveCachePage"
l_0_10 = 50
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nNpcAutoRemoveCachePage"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bBuffListExEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bBuffListExEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bSoundAlertEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bSoundAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bColorAlertEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bColorAlertEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bDebuffColorAlertAuto"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bDebuffColorAlertAuto"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bRedAlarmEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bRedAlarmEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCenterAlarmEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCenterAlarmEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bAutoSelectEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bAutoSelectEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bCtrlandAltMove"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bCtrlandAltMove"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bAutoNewSkillTimer"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bAutoNewSkillTimer"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bSkillTimerSay"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bSkillTimerSay"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nCenterAlarmTime"
l_0_10 = 2
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nSkillTimerCountdown"
l_0_10 = 5
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "nSayChannel"
l_0_10 = PLAYER_TALK_CHANNEL
l_0_11 = "RAID"
l_0_10 = l_0_10[l_0_11]
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nCenterAlarmTime"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nSkillTimerCountdown"
l_0_8(l_0_9)
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.nSayChannel"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bNpcLifeCheckEnable"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bNpcLifeCheckEnable"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bLinkNpcFightStateInDun"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bLinkNpcFightStateInDun"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bLinkNpcFightState"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bLinkNpcFightState"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bLinkBOSSFightState"
l_0_10 = true
l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterCustomData
l_0_9 = "RaidGrid_EventScrutiny.bLinkBOSSFightState"
l_0_8(l_0_9)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "bMegeEnable"
l_0_10 = false
l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "PopMainOptions"
l_0_10 = function()
  local l_173_0 = ""
  if not io and not iox then
    l_173_0 = "�����ã�����̫��ʱ�ܿ���"
  end
  local l_173_1 = {}
  local l_173_2 = {}
  l_173_2.szOption = "������/�رղ���ļ�¼�ͼ�ع��ܣ�V4.01����棩"
  l_173_2.bCheck = true
  l_173_2.bChecked = RaidGrid_EventScrutiny.bEnable
  l_173_2.fnAction = function(l_174_0, l_174_1)
    RaidGrid_EventScrutiny.bEnable = l_174_1
  end
  local l_173_3 = {}
  l_173_3.szOption = "��������/�رս����¼���¼"
  l_173_3.bCheck = true
  l_173_3.bChecked = RaidGrid_EventScrutiny.bCacheEnable
  l_173_3.fnAction = function(l_175_0, l_175_1)
    RaidGrid_EventScrutiny.bCacheEnable = l_175_1
  end
  local l_173_4 = {}
  l_173_4.bDevide = true
  local l_173_5 = {}
  l_173_5.szOption = "��������/��������أ�"
  local l_173_6 = {}
  l_173_6.szOption = "������ǰ�������" .. l_173_0
  l_173_6.bCheck = false
  l_173_6.bChecked = false
  l_173_6.fnAction = function(l_176_0, l_176_1)
    GetPopupMenu():Hide()
    RaidGrid_Base.ResetChatAlertCD()
    RaidGrid_Base.SaveSettings()
  end
  local l_173_7 = {}
  l_173_7.szOption = "���ർ��������û��ô����"
  local l_173_8 = {}
  do
    l_173_8.szOption = "����Buff�������"
    l_173_8.bCheck = false
    l_173_8.bChecked = false
    l_173_8.fnAction = function(l_177_0, l_177_1)
      GetPopupMenu():Hide()
      RaidGrid_Base.ResetChatAlertCD()
      RaidGrid_Base.SaveSettingsByType(RaidGrid_EventScrutiny.tRecords.Buff)
    end
    local l_173_9 = {}
    do
      l_173_9.szOption = "����Debuff�������"
      l_173_9.bCheck = false
      l_173_9.bChecked = false
      l_173_9.fnAction = function(l_178_0, l_178_1)
        GetPopupMenu():Hide()
        RaidGrid_Base.ResetChatAlertCD()
        RaidGrid_Base.SaveSettingsByType(RaidGrid_EventScrutiny.tRecords.Debuff)
      end
      local l_173_10 = {}
      do
        l_173_10.szOption = "�������ܼ������"
        l_173_10.bCheck = false
        l_173_10.bChecked = false
        l_173_10.fnAction = function(l_179_0, l_179_1)
          GetPopupMenu():Hide()
          RaidGrid_Base.ResetChatAlertCD()
          RaidGrid_Base.SaveSettingsByType(RaidGrid_EventScrutiny.tRecords.Casting)
        end
        local l_173_11 = {}
        do
          l_173_11.szOption = "����Npc�������"
          l_173_11.bCheck = false
          l_173_11.bChecked = false
          l_173_11.fnAction = function(l_180_0, l_180_1)
            GetPopupMenu():Hide()
            RaidGrid_Base.ResetChatAlertCD()
            RaidGrid_Base.SaveSettingsByType(RaidGrid_EventScrutiny.tRecords.Npc)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_173_10 = function(l_181_0, l_181_1)
            GetPopupMenu():Hide()
            RaidGrid_Base.LoadSettingsFile(true)
          end
          l_173_11 = function(l_182_0, l_182_1)
            GetPopupMenu():Hide()
            RaidGrid_Base.LoadSettingsFile()
          end
          local l_173_12 = {}
          l_173_12.szOption = "�ظ����һ�μ���ǰ������"
          l_173_12.bCheck = false
          l_173_12.bChecked = false
          l_173_12.bDisable = not RaidGrid_Base.tSavedDataBak
          l_173_12.fnAction = function(l_183_0, l_183_1)
            GetPopupMenu():Hide()
            RaidGrid_EventScrutiny.tRecords = RaidGrid_Base.tSavedDataBak
            RaidGrid_Base.tSavedDataBak = nil
            RaidGrid_Base.VersionUpdate(true)
            RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventCache.szListIndex)
          end
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

           -- DECOMPILER ERROR: Overwrote pending register.

          l_173_8 = {bDevide = true}
           -- DECOMPILER ERROR: Overwrote pending register.

          l_173_10 = {szOption = "���������ļ����ϲ���ǰ��", bCheck = false, bChecked = false, fnAction = l_173_11}
          l_173_12 = function(l_186_0, l_186_1)
            GetPopupMenu():Hide()
            RaidGrid_SkillTimer.RemoveAllTimer()
          end
          l_173_11, l_173_10, l_173_9, l_173_8, l_173_7 = {szOption = "�����Ļ���뵹��ʱ��", bCheck = false, bChecked = false, fnAction = l_173_12}, {bDevide = true}, {szOption = "���ò���������ã�������������ݣ�", bCheck = false, bChecked = false, fnAction = l_173_10}, {bDevide = true}, {szOption = "���ó�ʼ���ݣ��ָ�Ϊ���Ĭ�ϼ�����ݣ����ã�", bCheck = false, bChecked = false, fnAction = l_173_8}
          l_173_10 = RaidGrid_BossCallAlert
          l_173_10 = l_173_10.TalkMonitor
          l_173_10 = function(l_187_0, l_187_1)
            RaidGrid_BossCallAlert.TalkMonitor = l_187_1
          end
          l_173_12 = RaidGrid_BossCallAlert
          l_173_12 = l_173_12.bWarningMessageMonitor
          l_173_12 = function(l_188_0, l_188_1)
            RaidGrid_BossCallAlert.bWarningMessageMonitor = l_188_1
          end
          local l_173_13 = {}
          l_173_13.szOption = "��������ʱ�Ŷ�Ƶ��ͨ��"
          l_173_13.bCheck = true
          l_173_13.bChecked = RaidGrid_BossCallAlert.RAID
          l_173_13.fnAction = function(l_189_0, l_189_1)
            RaidGrid_BossCallAlert.RAID = l_189_1
          end
          local l_173_14 = {}
          l_173_14.szOption = "��������ʱ��������ͨ��"
          l_173_14.bCheck = true
          l_173_14.bChecked = RaidGrid_BossCallAlert.WHISPER
          l_173_14.fnAction = function(l_190_0, l_190_1)
            RaidGrid_BossCallAlert.WHISPER = l_190_1
          end
          local l_173_15 = {}
          l_173_15.bDevide = true
          local l_173_16 = {}
          l_173_16.szOption = "����[�Զ�ѡ�񱻵�������ΪĿ��]����"
          l_173_16.bCheck = true
          l_173_16.bChecked = RaidGrid_BossCallAlert.bAutoSelect
          l_173_16.fnAction = function(l_191_0, l_191_1)
            RaidGrid_BossCallAlert.bAutoSelect = l_191_1
          end
          local l_173_17 = {}
          l_173_17.bDevide = true
          local l_173_18 = {}
          l_173_18.szOption = "�������Լ���ʱȫ��������ʾ"
          l_173_18.bCheck = true
          l_173_18.bChecked = RaidGrid_BossCallAlert.Flash
          l_173_18.fnAction = function(l_192_0, l_192_1)
            RaidGrid_BossCallAlert.Flash = l_192_1
          end
          local l_173_19 = {}
          l_173_19.szOption = "��ȫ��������ɫѡ��"
          l_173_19.r = RaidGrid_BossCallAlert.tRGRedAlarm[1]
          l_173_19.g = RaidGrid_BossCallAlert.tRGRedAlarm[2]
          l_173_19.b = RaidGrid_BossCallAlert.tRGRedAlarm[3]
          local l_173_20 = {}
          l_173_20.szOption = "�� ��"
          l_173_20.bCheck = false
          l_173_20.bChecked = false
          l_173_20.r = 255
          l_173_20.g = 0
          l_173_20.b = 0
          l_173_20.fnAction = function()
            local l_193_0 = RaidGrid_BossCallAlert
            do
              local l_193_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
          local l_173_21 = {}
          l_173_21.szOption = "�� ��"
          l_173_21.bCheck = false
          l_173_21.bChecked = false
          l_173_21.r = 0
          l_173_21.g = 255
          l_173_21.b = 0
          l_173_21.fnAction = function()
            local l_194_0 = RaidGrid_BossCallAlert
            do
              local l_194_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
          local l_173_22 = {}
          l_173_22.szOption = "�� ��"
          l_173_22.bCheck = false
          l_173_22.bChecked = false
          l_173_22.r = 0
          l_173_22.g = 0
          l_173_22.b = 255
          l_173_22.fnAction = function()
            local l_195_0 = RaidGrid_BossCallAlert
            do
              local l_195_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
          local l_173_23 = {}
          l_173_23.szOption = "�� ��"
          l_173_23.bCheck = false
          l_173_23.bChecked = false
          l_173_23.r = 255
          l_173_23.g = 255
          l_173_23.b = 0
          l_173_23.fnAction = function()
            local l_196_0 = RaidGrid_BossCallAlert
            do
              local l_196_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
          local l_173_24 = {}
          l_173_24.szOption = "�� ��"
          l_173_24.bCheck = false
          l_173_24.bChecked = false
          l_173_24.r = 255
          l_173_24.g = 0
          l_173_24.b = 255
          l_173_24.fnAction = function()
            local l_197_0 = RaidGrid_BossCallAlert
            do
              local l_197_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
          do
            local l_173_25 = {}
            l_173_25.szOption = "�� ��"
            l_173_25.bCheck = false
            l_173_25.bChecked = false
            l_173_25.r = 255
            l_173_25.g = 255
            l_173_25.b = 255
            l_173_25.fnAction = function()
            local l_198_0 = RaidGrid_BossCallAlert
            do
              local l_198_1 = {}
               -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            end
             -- WARNING: undefined locals caused missing assignments!
          end
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_173_21 = RaidGrid_BossCallAlert
            l_173_21 = l_173_21.CenterAlarm
            l_173_21 = function(l_199_0, l_199_1)
            RaidGrid_BossCallAlert.CenterAlarm = l_199_1
          end
            l_173_20, l_173_12, l_173_11, l_173_10, l_173_9 = {szOption = "��������ʱ����������ʾ", bCheck = true, bChecked = l_173_21, fnAction = l_173_21}, {bDevide = true}, {szOption = "�����ٷ��Դ���ʾ���������", bCheck = true, bChecked = l_173_12, fnAction = l_173_12}, {bDevide = true}, {szOption = "����NPC����/�������Ѽ��", bCheck = true, bChecked = l_173_10, fnAction = l_173_10}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

            l_173_4 = RaidGrid_EventScrutiny
            l_173_4 = l_173_4.bBuffListExEnable
            l_173_4 = function(l_200_0, l_200_1)
            RaidGrid_EventScrutiny.bBuffListExEnable = l_200_1
          end
            l_173_5 = RaidGrid_SelfBuffAlert
            l_173_5 = l_173_5.bShowBuffName
            l_173_5 = function(l_201_0, l_201_1)
            RaidGrid_SelfBuffAlert.bShowBuffName = l_201_1
          end
             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

             -- DECOMPILER ERROR: Overwrote pending register.

            l_173_8 = {l_173_9, l_173_10, l_173_11, l_173_12, l_173_13, l_173_14, l_173_15, l_173_16, l_173_17, l_173_18, l_173_19, l_173_20; szOption = "��������/������ء����ܿ��أ�ģ��ƥ�䣩��"}
             -- DECOMPILER ERROR: Overwrote pending register.

            l_173_7 = {bDevide = true}
            l_173_8 = "����"
             -- DECOMPILER ERROR: Overwrote pending register.

            l_173_6 = {l_173_7, l_173_8, l_173_9, l_173_10, l_173_11; szOption = "��������/��ա���أ�"}
            l_173_6 = function(l_202_0, l_202_1)
            GetPopupMenu():Hide()
            RaidGrid_Base.SetSelfBuffAlertScale()
          end
            l_173_8 = RaidGrid_EventScrutiny
            l_173_8 = l_173_8.bScreenHeadMonitor
            l_173_8 = function(l_203_0, l_203_1)
            RaidGrid_EventScrutiny.bScreenHeadMonitor = l_203_1
            RaidGrid_ScreenHead.Control()
          end
            l_173_10 = RaidGrid_EventScrutiny
            l_173_10 = l_173_10.bBuffTeamExScrutinyEnable
            l_173_10 = function(l_204_0, l_204_1)
            RaidGrid_EventScrutiny.bBuffTeamExScrutinyEnable = l_204_1
          end
            l_173_11 = RaidGrid_EventScrutiny
            l_173_11 = l_173_11.bRaidGridExSelfDisable
            l_173_11 = function(l_205_0, l_205_1)
            RaidGrid_EventScrutiny.bRaidGridExSelfDisable = l_205_1
            if l_205_1 and RaidGridEx and RaidGridEx.OnUpdateBuffData then
              RaidGridEx.OnUpdateBuffData = function()
            end
            end
            RaidGrid_Base.Message("ע�⣺����RaidGridEx�Դ������������Ч�����ָ�����ʵʱ��Ч��ȡ�����ú���С���ؽ���Ϸ���ָܻ���")
          end
            l_173_13 = RaidGrid_EventScrutiny
            l_173_13 = l_173_13.bBuffTeamScrutinyEnable
            l_173_13 = function(l_206_0, l_206_1)
            RaidGrid_EventScrutiny.bBuffTeamScrutinyEnable = l_206_1
          end
            l_173_15 = RaidGrid_EventScrutiny
            l_173_15 = l_173_15.bCastingReadingBar
            l_173_15 = function(l_207_0, l_207_1)
            RaidGrid_EventScrutiny.bCastingReadingBar = l_207_1
          end
            l_173_17 = RaidGrid_EventScrutiny
            l_173_17 = l_173_17.bSoundAlertEnable
            l_173_17 = function(l_208_0, l_208_1)
            RaidGrid_EventScrutiny.bSoundAlertEnable = l_208_1
          end
            l_173_18 = RaidGrid_EventScrutiny
            l_173_18 = l_173_18.bColorAlertEnable
            l_173_18 = function(l_209_0, l_209_1)
            RaidGrid_EventScrutiny.bColorAlertEnable = l_209_1
          end
            l_173_19 = RaidGrid_EventScrutiny
            l_173_19 = l_173_19.bAutoSelectEnable
            l_173_19 = function(l_210_0, l_210_1)
            RaidGrid_EventScrutiny.bAutoSelectEnable = l_210_1
          end
            l_173_21 = RaidGrid_EventScrutiny
            l_173_21 = l_173_21.bAddByNameEnable
            l_173_21 = function(l_211_0, l_211_1)
            RaidGrid_EventScrutiny.bAddByNameEnable = l_211_1
          end
            l_173_20, l_173_19, l_173_18, l_173_17, l_173_16, l_173_15, l_173_14, l_173_13, l_173_12, l_173_11, l_173_10, l_173_9, l_173_8, l_173_7, l_173_6, l_173_5, l_173_4, l_173_3 = {szOption = "����ͨ���������Ӹ����ع���", bCheck = true, bChecked = l_173_21, fnAction = l_173_21}, {bDevide = true}, {szOption = "���������¼����Զ�ѡ��Ŀ�깦��", bCheck = true, bChecked = l_173_19, fnAction = l_173_19}, {szOption = "���������¼���ȫ����ɫ����", bCheck = true, bChecked = l_173_18, fnAction = l_173_18}, {szOption = "���������¼�����Ч����", bCheck = true, bChecked = l_173_17, fnAction = l_173_17}, {bDevide = true}, {szOption = "��������������ض��⶯����", bCheck = true, bChecked = l_173_15, fnAction = l_173_15}, {bDevide = true}, {szOption = "����CTM����Ŷ����BUFF/DEBUFF����", bCheck = true, bChecked = l_173_13, fnAction = l_173_13}, {bDevide = true}, {szOption = "������RaidGridEx�Դ����", bCheck = true, bChecked = l_173_11, fnAction = l_173_11}, {szOption = "����RaidGridEx����", bCheck = true, bChecked = l_173_10, fnAction = l_173_10}, {bDevide = true}, {szOption = "����BUFF/DEBUFF��Ļ��Чͷ������ģ��", bCheck = true, bChecked = l_173_8, fnAction = l_173_8}, {bDevide = true}, {szOption = l_173_6, bCheck = false, bChecked = false, fnAction = l_173_6}, {szOption = "����������Ч��������ʾ����һ����õ�Ч����ʼ��Ч��", bCheck = true, bChecked = l_173_5, fnAction = l_173_5}, {szOption = "��������Ч����BUFF/DEBUFF������б�", bCheck = true, bChecked = l_173_4, fnAction = l_173_4}
            l_173_5 = RaidGrid_EventCache
            l_173_5 = l_173_5.tAddByName
            l_173_5 = l_173_5.Buff
            l_173_5 = l_173_5.szToAddNameList
            l_173_5 = l_173_5 ~= ""
            l_173_5 = function(l_212_0, l_212_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Buff, "Buff")
          end
            l_173_5 = table
            l_173_5 = l_173_5.insert
            l_173_6, l_173_4 = l_173_4, {szOption = "Buff", bCheck = true, bChecked = l_173_5, fnAction = l_173_5}
            l_173_8 = function(l_213_0, l_213_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Buff, "Buff")
          end
            l_173_5(l_173_6, l_173_7)
            l_173_7 = {szOption = "������Buff���ִ�", bCheck = false, bChecked = false, fnAction = l_173_8}
            l_173_5 = pairs
            l_173_6 = RaidGrid_EventCache
            l_173_6 = l_173_6.tAddByName
            l_173_6 = l_173_6.Buff
            l_173_5 = l_173_5(l_173_6)
            for l_173_8,l_173_9 in l_173_5 do
              if l_173_8 ~= "szToAddNameList" then
                l_173_10 = table
                l_173_10 = l_173_10.insert
                l_173_11 = l_173_4
                l_173_13 = RaidGrid_EventCache
                l_173_13 = l_173_13.tAddByName
                l_173_13 = l_173_13.Buff
                l_173_13 = l_173_13[l_173_8]
                l_173_13 = function(l_214_0, l_214_1)
                -- upvalues: l_173_8
                RaidGrid_EventCache.tAddByName.Buff[l_173_8] = l_214_1
              end
                l_173_10(l_173_11, l_173_12)
                l_173_12 = {szOption = l_173_8, bCheck = true, bChecked = l_173_13, fnAction = l_173_13}
              end
            end
            table.insert(l_173_4, {szOption = "�����ӵ�������", bCheck = false, bChecked = false, fnAction = function(l_215_0, l_215_1)
            RaidGrid_Base.AddOneNameToTable(RaidGrid_EventCache.tAddByName.Buff, "Buff")
          end})
            table.insert({szOption = "Debuff", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Debuff.szToAddNameList ~= "", fnAction = function(l_216_0, l_216_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end}, {szOption = "������Debuff���ִ�", bCheck = false, bChecked = false, fnAction = function(l_217_0, l_217_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end})
            for i_1,l_173_10 in pairs(RaidGrid_EventCache.tAddByName.Debuff) do
              if i_1 ~= "szToAddNameList" then
                l_173_11 = table
                l_173_11 = l_173_11.insert
                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_173_12 = {szOption = "Debuff", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Debuff.szToAddNameList ~= "", fnAction = function(l_216_0, l_216_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end}
                l_173_14 = RaidGrid_EventCache
                l_173_14 = l_173_14.tAddByName
                l_173_14 = l_173_14.Debuff
                l_173_14 = l_173_14[i_1]
                l_173_14 = function(l_218_0, l_218_1)
                -- upvalues: l_173_9
                RaidGrid_EventCache.tAddByName.Debuff[l_173_9] = l_218_1
              end
                l_173_11(l_173_12, l_173_13)
                l_173_13 = {szOption = i_1, bCheck = true, bChecked = l_173_14, fnAction = l_173_14}
              end
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert({szOption = "Debuff", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Debuff.szToAddNameList ~= "", fnAction = function(l_216_0, l_216_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end}, {szOption = "�����ӵ�������", bCheck = false, bChecked = false, fnAction = function(l_219_0, l_219_1)
            RaidGrid_Base.AddOneNameToTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end})
            table.insert({szOption = "����", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Casting.szToAddNameList ~= "", fnAction = function(l_220_0, l_220_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end}, {szOption = "�����ü������ִ�", bCheck = false, bChecked = false, fnAction = function(l_221_0, l_221_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end})
            for i_1,l_173_11 in pairs(RaidGrid_EventCache.tAddByName.Casting) do
              if i_1 ~= "szToAddNameList" then
                l_173_12 = table
                l_173_12 = l_173_12.insert
                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_173_13 = {szOption = "����", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Casting.szToAddNameList ~= "", fnAction = function(l_220_0, l_220_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end}
                l_173_15 = RaidGrid_EventCache
                l_173_15 = l_173_15.tAddByName
                l_173_15 = l_173_15.Casting
                l_173_15 = l_173_15[i_1]
                l_173_15 = function(l_222_0, l_222_1)
                -- upvalues: l_173_10
                RaidGrid_EventCache.tAddByName.Casting[l_173_10] = l_222_1
              end
                l_173_12(l_173_13, l_173_14)
                l_173_14 = {szOption = i_1, bCheck = true, bChecked = l_173_15, fnAction = l_173_15}
              end
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert({szOption = "����", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Casting.szToAddNameList ~= "", fnAction = function(l_220_0, l_220_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end}, {szOption = "�����ӵ�������", bCheck = false, bChecked = false, fnAction = function(l_223_0, l_223_1)
            RaidGrid_Base.AddOneNameToTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end})
            table.insert({szOption = "Npc", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Npc.szToAddNameList ~= "", fnAction = function(l_224_0, l_224_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end}, {szOption = "������Npc���ִ�", bCheck = false, bChecked = false, fnAction = function(l_225_0, l_225_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end})
            for i_1,l_173_12 in pairs(RaidGrid_EventCache.tAddByName.Npc) do
              if i_1 ~= "szToAddNameList" then
                l_173_13 = table
                l_173_13 = l_173_13.insert
                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_173_14 = {szOption = "Npc", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Npc.szToAddNameList ~= "", fnAction = function(l_224_0, l_224_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end}
                l_173_16 = RaidGrid_EventCache
                l_173_16 = l_173_16.tAddByName
                l_173_16 = l_173_16.Npc
                l_173_16 = l_173_16[i_1]
                l_173_16 = function(l_226_0, l_226_1)
                -- upvalues: l_173_11
                RaidGrid_EventCache.tAddByName.Npc[l_173_11] = l_226_1
              end
                l_173_13(l_173_14, l_173_15)
                l_173_15 = {szOption = i_1, bCheck = true, bChecked = l_173_16, fnAction = l_173_16}
              end
            end
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert({szOption = "Npc", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Npc.szToAddNameList ~= "", fnAction = function(l_224_0, l_224_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end}, {szOption = "�����ӵ�������", bCheck = false, bChecked = false, fnAction = function(l_227_0, l_227_1)
            RaidGrid_Base.AddOneNameToTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end})
            table.insert(l_173_3, l_173_4)
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert(l_173_3, {szOption = "Debuff", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Debuff.szToAddNameList ~= "", fnAction = function(l_216_0, l_216_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Debuff, "Debuff")
          end})
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert(l_173_3, {szOption = "����", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Casting.szToAddNameList ~= "", fnAction = function(l_220_0, l_220_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Casting, "Casting")
          end})
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert(l_173_3, {szOption = "Npc", bCheck = true, bChecked = RaidGrid_EventCache.tAddByName.Npc.szToAddNameList ~= "", fnAction = function(l_224_0, l_224_1)
            RaidGrid_Base.SetAddByNameTable(RaidGrid_EventCache.tAddByName.Npc, "Npc")
          end})
            table.insert(l_173_1, RaidGrid_BossCallAlert.tPopOptions("tBossCall"))
            table.insert(l_173_1, RaidGrid_BossCallAlert.tPopOptions("tWarningMessages"))
            table.insert(l_173_1, {bDevide = true})
            table.insert(l_173_1, {szOption = "��ͬʱ��סCTRL��ALT���϶�Ч���б�/�����ʱ������", bCheck = true, bChecked = RaidGrid_EventScrutiny.bCtrlandAltMove, fnAction = function(l_228_0, l_228_1)
            RaidGrid_EventScrutiny.bCtrlandAltMove = l_228_1
          end})
            table.insert(l_173_1, l_173_2)
            if RaidGrid_EventScrutiny.bAddByNameEnable then
              table.insert(l_173_1, l_173_3)
            end
            l_173_1.x = Cursor.GetPos(true) + 15
            PopupMenu(l_173_1)
          end
           -- DECOMPILER ERROR: Confused about usage of registers for local variables.

        end
         -- WARNING: missing end command somewhere! Added here
      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventCache
l_0_9 = "PopRBOptions"
l_0_10 = function(l_174_0)
  if not l_174_0 then
    return 
  end
  if not RaidGrid_EventCache.tRecords[RaidGrid_EventCache.szListIndex] then
    local l_174_1 = {}
  end
  do
    local l_174_2 = nil
  end
  local l_174_3 = nil
  local l_174_4 = nil
  if not l_174_3[((RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] or 1) - 1) * 14 + tonumber(l_174_0:GetName():sub(15))] then
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_174_5 = nil
  if not l_174_3[((RaidGrid_EventCache.tListPage[RaidGrid_EventCache.szListIndex] or 1) - 1) * 14 + tonumber(l_174_0:GetName():sub(15))].dwID then
    return 
  end
  local l_174_6 = nil
  local l_174_7 = nil
  local l_174_8 = {}
  local l_174_9 = {szOption = "����" .. (l_174_0.tRecord.szName or "") .. "��", bCheck = false, bChecked = false, bDisable = true}
  local l_174_10 = {bDevide = true}
  local l_174_11 = {szOption = "�����ӵ������б�", bCheck = false, bChecked = false, bDisable = RaidGrid_EventScrutiny.IsRecordInList(l_174_0.tRecord, RaidGrid_EventCache.szListIndex), fnAction = function(l_175_0, l_175_1)
    -- upvalues: l_174_0
    GetPopupMenu():Hide()
    l_174_0.tRecord.nEventAlertTime = math.floor(l_174_0.tRecord.nEventAlertTime or l_174_0.tRecord.fKeepTime or 1200)
    RaidGrid_EventScrutiny.AddRecordToList(l_174_0.tRecord, RaidGrid_EventCache.szListIndex)
    RaidGrid_EventCache.UpdateRecordList(RaidGrid_EventCache.szListIndex)
  end}
  local l_174_12 = {bDevide = true}
  local l_174_13 = {szOption = "����ͼ:" .. (l_174_0.tRecord.szMapName or "��δ֪��"), bCheck = false, bChecked = false, bDisable = true}
  local l_174_14 = {szOption = "���ͷ���:" .. (l_174_0.tRecord.szCasterName or "�����޴��"), bCheck = false, bChecked = false, bDisable = true}
  local l_174_15 = {szOption = "����������ӡ������Ϣ����סAlt�ɵ�����", bCheck = false, bChecked = false, fnAction = function(l_176_0, l_176_1)
    -- upvalues: l_174_0
    GetPopupMenu():Hide()
    RaidGrid_Base.OutputRecord(l_174_0)
  end}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_174_9 = Cursor
  l_174_9 = l_174_9.GetPos
  l_174_10 = true
  l_174_9 = l_174_9(l_174_10)
  l_174_11 = l_174_9 + 15
  l_174_12 = l_174_10 + 15
  l_174_8.y = l_174_12
  l_174_8.x = l_174_11
  l_174_11 = PopupMenu
  l_174_12 = l_174_8
  l_174_11(l_174_12)
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "PopRBOptions"
l_0_10 = function(l_175_0)
  if not l_175_0 then
    return 
  end
  if not RaidGrid_EventScrutiny.tRecords[RaidGrid_EventScrutiny.szListIndex] then
    local l_175_1 = {}
  end
  do
    local l_175_2 = nil
  end
  local l_175_3 = nil
  local l_175_4 = nil
  if not l_175_3[((RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] or 1) - 1) * 8 + tonumber(l_175_0:GetName():sub(15))] then
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  local l_175_5 = nil
  if not l_175_3[((RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] or 1) - 1) * 8 + tonumber(l_175_0:GetName():sub(15))].dwID then
    return 
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  if not l_175_3[((RaidGrid_EventScrutiny.tListPage[RaidGrid_EventScrutiny.szListIndex] or 1) - 1) * 8 + tonumber(l_175_0:GetName():sub(15))].tEventTimeCache then
    local l_175_6 = nil
  end
  local l_175_7 = nil
   -- DECOMPILER ERROR: Overwrote pending register.

  if RaidGrid_Base.LowAverage({}) ~= 0 then
    local l_175_8 = nil
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  if l_175_3[l_175_6].tEventTimeCache and #l_175_3[l_175_6].tEventTimeCache > 0 then
    local l_175_9 = ""
  end
  if l_175_3[l_175_6].tEventTimeCache then
    for l_175_13 = 1, #l_175_3[l_175_6].tEventTimeCache do
      local l_175_10, l_175_11 = "", {"�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼", "�޼�¼"}
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if type(l_175_3[l_175_6].tEventTimeCache["�޼�¼"]) == "number" then
        l_175_11["�޼�¼"] = RaidGrid_Base.Time2String(l_175_3[l_175_6].tEventTimeCache["�޼�¼"])
      end
    end
  end
  local l_175_14 = nil
  local l_175_15 = nil
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_175_3[l_175_6].nEventAlertCount and l_175_3[l_175_6].nEventAlertCount > 1 then
    local l_175_17 = nil
    local l_175_18 = "1"
    local l_175_19 = function(l_176_0)
    -- upvalues: l_175_1 , l_175_4
    return function(l_177_0, l_177_1)
      -- upvalues: l_175_1 , l_175_4 , l_1_0
      if not l_175_1[l_175_4] or not l_175_1[l_175_4].tEventTimeCache or not l_175_1[l_175_4].tEventTimeCache[l_1_0] or type(l_175_1[l_175_4].tEventTimeCache[l_1_0]) ~= "number" then
        return 
      end
      l_175_1[l_175_4].nEventAlertTime = math.floor(l_175_1[l_175_4].tEventTimeCache[l_1_0])
      l_175_1[l_175_4].nAutoEventTimeMode = AUTO_EVENTTIME_MODE.NONE
      RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
    end
  end
    do
      local l_175_20 = nil
      do
        table.insert({}, {szOption = "����" .. (l_175_0.tRecord.szName or "") .. "��", bCheck = false, bChecked = false, bDisable = true})
        if IsCtrlKeyDown() then
          table.insert(l_175_20, {szOption = "���޸����ƣ��˲��������棩", bCheck = false, bChecked = false, fnAction = function(l_177_0, l_177_1)
        -- upvalues: l_175_0
        GetPopupMenu():Hide()
        RaidGrid_Base.GetEventNewName(l_175_0)
      end})
        end
        table.insert(l_175_20, {bDevide = true})
         -- DECOMPILER ERROR: Overwrote pending register.

        if not l_175_3[l_175_6].szSoundFile or l_175_3[l_175_6].szSoundFile == "" then
          do
            for l_175_24,l_175_25 in pairs(g_sound) do
              local l_175_21, l_175_22, l_175_23 = , {szOption = "��" .. "��Чѡ�񣨵����������סCTRL���ѡ�񣩣�"}, 0
              if l_175_23 % 10 == 0 then
                local l_175_29 = math.floor(l_175_23 / 10) + 1
                table.insert(l_175_22, {szOption = "�ڡ�" .. l_175_29 .. "������Ч��"})
              end
              l_175_23 = l_175_23 + 1
              local l_175_30 = nil
               -- DECOMPILER ERROR: Confused about usage of registers!

               -- DECOMPILER ERROR: Confused about usage of registers!

              table.insert(l_175_22[l_175_29], {szOption = l_175_30, bCheck = true, bChecked = l_175_3[l_175_6].szSoundFile == l_175_28, fnAction = function(l_178_0, l_178_1)
              -- upvalues: l_175_21 , l_175_1 , l_175_4
              PlaySound(SOUND.UI_SOUND, l_175_21)
              if IsCtrlKeyDown() then
                l_175_1[l_175_4].szSoundFile = l_175_21
                GetPopupMenu():Hide()
              end
            end})
            end
          end
          local l_175_33, l_175_80 = nil
          for l_175_37,l_175_38 in pairs(RaidGrid_Base.tSound) do
            local l_175_34, l_175_35 = , {szOption = "�Զ�����Ч��"}
             -- DECOMPILER ERROR: Confused about usage of registers!

            table.insert(l_175_35, {szOption = l_175_39, bCheck = true, bChecked = l_175_3[l_175_6].szSoundFile == l_175_29, fnAction = function(l_179_0, l_179_1)
            -- upvalues: l_175_22 , l_175_1 , l_175_4
            PlaySound(SOUND.UI_SOUND, l_175_22)
            if IsCtrlKeyDown() then
              l_175_1[l_175_4].szSoundFile = l_175_22
              GetPopupMenu():Hide()
            end
          end})
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          table.insert(l_175_80, l_175_35)
          local l_175_42, l_175_81 = nil
          local l_175_43, l_175_82 = table.insert, l_175_80
          local l_175_44, l_175_83 = {}
          l_175_44.szOption = "ɾ����ѡ��Ч��"
          l_175_44.r = 255
          l_175_44.g = 100
          l_175_44.b = 100
          l_175_83 = function(l_180_0, l_180_1)
          -- upvalues: l_175_1 , l_175_4
          l_175_1[l_175_4].szSoundFile = nil
          GetPopupMenu():Hide()
        end
          l_175_44.fnAction = l_175_83
          l_175_43(l_175_82, l_175_44)
          l_175_43 = IsCtrlKeyDown
          l_175_43 = l_175_43()
          if l_175_43 then
            l_175_43 = table
            l_175_43 = l_175_43.insert
            l_175_82 = l_175_20
            l_175_44 = l_175_80
            l_175_43(l_175_82, l_175_44)
          end
          l_175_43 = 210
          l_175_82 = 210
          l_175_44 = 210
          l_175_83 = l_175_3[l_175_6]
          l_175_83 = l_175_83.tRGAlertColor
          if l_175_83 then
            l_175_83 = l_175_3[l_175_6]
            l_175_83 = l_175_83.tRGAlertColor
            l_175_83 = l_175_83[1]
            l_175_82 = l_175_3[l_175_6].tRGAlertColor[2]
            l_175_43 = l_175_83
          end
          l_175_83 = table
          l_175_83 = l_175_83.insert
          local l_175_45, l_175_84 = nil
          l_175_45 = l_175_20
          local l_175_46, l_175_85 = nil
          do
            local l_175_47, l_175_86 = nil
            local l_175_48 = nil
            l_175_85 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_181_0 = l_175_1[l_175_4]
          do
            local l_181_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_49 = nil
            l_175_47 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_182_0 = l_175_1[l_175_4]
          do
            local l_182_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_50 = nil
            l_175_86 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_183_0 = l_175_1[l_175_4]
          do
            local l_183_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_51 = nil
            l_175_48 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_184_0 = l_175_1[l_175_4]
          do
            local l_184_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_52 = nil
            l_175_49 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_185_0 = l_175_1[l_175_4]
          do
            local l_185_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_53 = nil
            l_175_50 = function()
          -- upvalues: l_175_1 , l_175_4
          local l_186_0 = l_175_1[l_175_4]
          do
            local l_186_1 = {}
             -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          end
           -- WARNING: undefined locals caused missing assignments!
        end
            local l_175_54 = nil
            l_175_51 = function()
          -- upvalues: l_175_1 , l_175_4
          l_175_1[l_175_4].tRGAlertColor = nil
        end
            l_175_50, l_175_49, l_175_48, l_175_86, l_175_47, l_175_85, l_175_46 = {szOption = "�� ��", bCheck = false, bChecked = false, r = 210, g = 210, b = 210, fnAction = l_175_51}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 255, b = 255, fnAction = l_175_50}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 0, b = 255, fnAction = l_175_49}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 255, b = 0, fnAction = l_175_48}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 0, g = 0, b = 255, fnAction = l_175_86}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 0, g = 255, b = 0, fnAction = l_175_47}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 0, b = 0, fnAction = l_175_85}
            l_175_83(l_175_45, l_175_84)
            l_175_84 = {l_175_46, l_175_85, l_175_47, l_175_86, l_175_48, l_175_49, l_175_50; szOption = "��ȫ����ɫ��ʾѡ��", r = l_175_43, g = l_175_82, b = l_175_44}
            l_175_83 = table
            l_175_83 = l_175_83.insert
            l_175_45 = l_175_20
            l_175_83(l_175_45, l_175_84)
            l_175_84 = {bDevide = true}
            l_175_83 = IsCtrlKeyDown
            l_175_83 = l_175_83()
            if l_175_83 then
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = l_175_3[l_175_6]
              l_175_46 = l_175_46.tRGAutoSelect
              if not l_175_46 then
                l_175_46 = false
              end
              l_175_46 = function(l_188_0, l_188_1)
            -- upvalues: l_175_1 , l_175_4
            local l_188_2 = l_175_1[l_175_4]
            local l_188_3 = nil
            if not l_188_1 then
              l_188_3 = nil
            end
            l_188_2.tRGAutoSelect = l_188_3
          end
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = "���¼�����ʱ�Զ�ѡ��Ŀ��", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
            end
            l_175_83 = table
            l_175_83 = l_175_83.insert
            l_175_45 = l_175_20
            l_175_46 = l_175_3[l_175_6]
            l_175_46 = l_175_46.tRGCenterAlarm
            if not l_175_46 then
              l_175_46 = false
            end
            l_175_46 = function(l_189_0, l_189_1)
          -- upvalues: l_175_1 , l_175_4
          local l_189_2 = l_175_1[l_175_4]
          local l_189_3 = nil
          if not l_189_1 then
            l_189_3 = nil
          end
          l_189_2.tRGCenterAlarm = l_189_3
        end
            l_175_83(l_175_45, l_175_84)
            l_175_84 = {szOption = "��������ʾ����", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
            l_175_83 = l_175_3[l_175_6]
            l_175_83 = l_175_83.szType
            if l_175_83 ~= "Buff" then
              l_175_83 = l_175_3[l_175_6]
              l_175_83 = l_175_83.szType
            end
            if l_175_83 ~= "Debuff" then
              l_175_83 = l_175_3[l_175_6]
              l_175_83 = l_175_83.dwID
            end
            if l_175_83 ~= 1000001 then
              l_175_83 = IsCtrlKeyDown
              l_175_83 = l_175_83()
              if l_175_83 then
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {bDevide = true}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = l_175_3[l_175_6]
                l_175_46 = l_175_46.bNotAddToScrutiny
                if not l_175_46 then
                  l_175_46 = false
                end
                l_175_46 = function(l_190_0, l_190_1)
              -- upvalues: l_175_1 , l_175_4
              local l_190_2 = l_175_1[l_175_4]
              local l_190_3 = nil
              if not l_190_1 then
                l_190_3 = nil
              end
              l_190_2.bNotAddToScrutiny = l_190_3
            end
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = "����������¼���ص���ʱ����", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = l_175_3[l_175_6]
                l_175_46 = l_175_46.bAddToSkillTimer
                if not l_175_46 then
                  l_175_46 = false
                end
                l_175_46 = function(l_191_0, l_191_1)
              -- upvalues: l_175_1 , l_175_4
              local l_191_2 = l_175_1[l_175_4]
              local l_191_3 = nil
              if not l_191_1 then
                l_191_3 = nil
              end
              l_191_2.bAddToSkillTimer = l_191_3
            end
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = "����������Ļ���뵹��ʱ����", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {bDevide = true}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = function(l_192_0, l_192_1)
              -- upvalues: l_175_0
              RaidGrid_Base.GetEventCountdownAlertTime(l_175_0)
            end
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = "������Ƶ����������ʱʱ��", bCheck = false, bChecked = false, fnAction = l_175_46}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {bDevide = true}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = l_175_3[l_175_6]
                l_175_46 = l_175_46.nAutoEventTimeMode
                l_175_85 = AUTO_EVENTTIME_MODE
                l_175_85 = l_175_85.AVG
                l_175_46 = l_175_46 == l_175_85
                l_175_46 = function(l_193_0, l_193_1)
              -- upvalues: l_175_1 , l_175_4
              GetPopupMenu():Hide()
              if l_193_1 then
                l_175_1[l_175_4].nAutoEventTimeMode = AUTO_EVENTTIME_MODE.AVG
              else
                l_175_1[l_175_4].nAutoEventTimeMode = AUTO_EVENTTIME_MODE.NONE
              end
              RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
            end
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = "���Զ�����Ϊƽ�����", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = "��֮ǰʮ�μ����¼��"
                l_175_85 = l_175_9
                l_175_46 = l_175_46 .. l_175_85
                l_175_85 = l_175_15[1]
                l_175_85 = l_175_15[1]
                l_175_85 = l_175_85 == "�޼�¼"
                l_175_85 = l_175_19
                l_175_47 = 1
                l_175_85 = l_175_85(l_175_47)
                l_175_47 = l_175_15[2]
                l_175_47 = l_175_15[2]
                l_175_47 = l_175_47 == "�޼�¼"
                l_175_47 = l_175_19
                l_175_86 = 2
                l_175_47 = l_175_47(l_175_86)
                l_175_86 = l_175_15[3]
                l_175_86 = l_175_15[3]
                l_175_86 = l_175_86 == "�޼�¼"
                l_175_86 = l_175_19
                l_175_48 = 3
                l_175_86 = l_175_86(l_175_48)
                l_175_48 = l_175_15[4]
                l_175_48 = l_175_15[4]
                l_175_48 = l_175_48 == "�޼�¼"
                l_175_48 = l_175_19
                l_175_49 = 4
                l_175_48 = l_175_48(l_175_49)
                l_175_49 = l_175_15[5]
                l_175_49 = l_175_15[5]
                l_175_49 = l_175_49 == "�޼�¼"
                l_175_49 = l_175_19
                l_175_50 = 5
                l_175_49 = l_175_49(l_175_50)
                l_175_50 = l_175_15[6]
                l_175_50 = l_175_15[6]
                l_175_50 = l_175_50 == "�޼�¼"
                l_175_50 = l_175_19
                l_175_51 = 6
                l_175_50 = l_175_50(l_175_51)
                l_175_51 = l_175_15[7]
                l_175_51 = l_175_15[7]
                l_175_51 = l_175_51 == "�޼�¼"
                l_175_51 = l_175_19
                l_175_52 = 7
                l_175_51 = l_175_51(l_175_52)
                local l_175_57 = nil
                l_175_52 = l_175_15[8]
                l_175_52 = l_175_15[8]
                l_175_52 = l_175_52 == "�޼�¼"
                l_175_52 = l_175_19
                l_175_53 = 8
                l_175_52 = l_175_52(l_175_53)
                local l_175_60 = nil
                l_175_53 = l_175_15[9]
                l_175_53 = l_175_15[9]
                l_175_53 = l_175_53 == "�޼�¼"
                l_175_53 = l_175_19
                l_175_54 = 9
                l_175_53 = l_175_53(l_175_54)
                local l_175_63 = nil
                l_175_54 = l_175_15[10]
                l_175_54 = l_175_15[10]
                l_175_54 = l_175_54 == "�޼�¼"
                l_175_54 = l_175_19
                l_175_57 = 10
                l_175_54 = l_175_54(l_175_57)
                l_175_53, l_175_52, l_175_51, l_175_50, l_175_49, l_175_48, l_175_86, l_175_47, l_175_85, l_175_46 = {szOption = l_175_54, bCheck = false, bChecked = false, bDisable = l_175_54, fnAction = l_175_54}, {szOption = l_175_53, bCheck = false, bChecked = false, bDisable = l_175_53, fnAction = l_175_53}, {szOption = l_175_52, bCheck = false, bChecked = false, bDisable = l_175_52, fnAction = l_175_52}, {szOption = l_175_51, bCheck = false, bChecked = false, bDisable = l_175_51, fnAction = l_175_51}, {szOption = l_175_50, bCheck = false, bChecked = false, bDisable = l_175_50, fnAction = l_175_50}, {szOption = l_175_49, bCheck = false, bChecked = false, bDisable = l_175_49, fnAction = l_175_49}, {szOption = l_175_48, bCheck = false, bChecked = false, bDisable = l_175_48, fnAction = l_175_48}, {szOption = l_175_86, bCheck = false, bChecked = false, bDisable = l_175_86, fnAction = l_175_86}, {szOption = l_175_47, bCheck = false, bChecked = false, bDisable = l_175_47, fnAction = l_175_47}, {szOption = l_175_85, bCheck = false, bChecked = false, bDisable = l_175_85, fnAction = l_175_85}
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {l_175_46, l_175_85, l_175_47, l_175_86, l_175_48, l_175_49, l_175_50, l_175_51, l_175_52, l_175_53; szOption = l_175_46}
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = function(l_194_0, l_194_1)
              -- upvalues: l_175_1 , l_175_4 , l_175_0
              GetPopupMenu():Hide()
              l_175_1[l_175_4].nAutoEventTimeMode = AUTO_EVENTTIME_MODE.NONE
              RaidGrid_Base.GetEventAlertTime(l_175_0)
              RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
            end
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = "���ֶ����ü��ƽ��ʱ�䣨ȡ���Զ����ã�", bCheck = false, bChecked = false, fnAction = l_175_46}
              end
            else
              l_175_83 = l_175_3[l_175_6]
              l_175_83 = l_175_83.szType
              if l_175_83 ~= "Buff" then
                l_175_83 = l_175_3[l_175_6]
                l_175_83 = l_175_83.szType
              end
              if l_175_83 ~= "Debuff" then
                l_175_83 = l_175_3[l_175_6]
                l_175_83 = l_175_83.dwID
              end
              if l_175_83 == 1000001 then
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = "��֮ǰʮ��ս��ʱ���¼��"
                l_175_85 = l_175_14
                l_175_46 = l_175_46 .. l_175_85
                l_175_85 = l_175_15[1]
                l_175_85 = l_175_15[1]
                l_175_85 = l_175_85 == "�޼�¼"
                l_175_85 = l_175_19
                l_175_47 = 1
                l_175_85 = l_175_85(l_175_47)
                l_175_47 = l_175_15[2]
                l_175_47 = l_175_15[2]
                l_175_47 = l_175_47 == "�޼�¼"
                l_175_47 = l_175_19
                l_175_86 = 2
                l_175_47 = l_175_47(l_175_86)
                l_175_86 = l_175_15[3]
                l_175_86 = l_175_15[3]
                l_175_86 = l_175_86 == "�޼�¼"
                l_175_86 = l_175_19
                l_175_48 = 3
                l_175_86 = l_175_86(l_175_48)
                l_175_48 = l_175_15[4]
                l_175_48 = l_175_15[4]
                l_175_48 = l_175_48 == "�޼�¼"
                l_175_48 = l_175_19
                l_175_49 = 4
                l_175_48 = l_175_48(l_175_49)
                l_175_49 = l_175_15[5]
                l_175_49 = l_175_15[5]
                l_175_49 = l_175_49 == "�޼�¼"
                l_175_49 = l_175_19
                l_175_50 = 5
                l_175_49 = l_175_49(l_175_50)
                l_175_50 = l_175_15[6]
                l_175_50 = l_175_15[6]
                l_175_50 = l_175_50 == "�޼�¼"
                l_175_50 = l_175_19
                l_175_51 = 6
                l_175_50 = l_175_50(l_175_51)
                l_175_51 = l_175_15[7]
                l_175_51 = l_175_15[7]
                l_175_51 = l_175_51 == "�޼�¼"
                l_175_51 = l_175_19
                l_175_52 = 7
                l_175_51 = l_175_51(l_175_52)
                local l_175_68 = nil
                l_175_52 = l_175_15[8]
                l_175_52 = l_175_15[8]
                l_175_52 = l_175_52 == "�޼�¼"
                l_175_52 = l_175_19
                l_175_53 = 8
                l_175_52 = l_175_52(l_175_53)
                local l_175_71 = nil
                l_175_53 = l_175_15[9]
                l_175_53 = l_175_15[9]
                l_175_53 = l_175_53 == "�޼�¼"
                l_175_53 = l_175_19
                l_175_54 = 9
                l_175_53 = l_175_53(l_175_54)
                local l_175_74 = nil
                l_175_54 = l_175_15[10]
                l_175_54 = l_175_15[10]
                l_175_54 = l_175_54 == "�޼�¼"
                l_175_54 = l_175_19
                l_175_68 = 10
                l_175_54 = l_175_54(l_175_68)
                l_175_53, l_175_52, l_175_51, l_175_50, l_175_49, l_175_48, l_175_86, l_175_47, l_175_85, l_175_46 = {szOption = l_175_54, bCheck = false, bChecked = false, bDisable = l_175_54, fnAction = l_175_54}, {szOption = l_175_53, bCheck = false, bChecked = false, bDisable = l_175_53, fnAction = l_175_53}, {szOption = l_175_52, bCheck = false, bChecked = false, bDisable = l_175_52, fnAction = l_175_52}, {szOption = l_175_51, bCheck = false, bChecked = false, bDisable = l_175_51, fnAction = l_175_51}, {szOption = l_175_50, bCheck = false, bChecked = false, bDisable = l_175_50, fnAction = l_175_50}, {szOption = l_175_49, bCheck = false, bChecked = false, bDisable = l_175_49, fnAction = l_175_49}, {szOption = l_175_48, bCheck = false, bChecked = false, bDisable = l_175_48, fnAction = l_175_48}, {szOption = l_175_86, bCheck = false, bChecked = false, bDisable = l_175_86, fnAction = l_175_86}, {szOption = l_175_47, bCheck = false, bChecked = false, bDisable = l_175_47, fnAction = l_175_47}, {szOption = l_175_85, bCheck = false, bChecked = false, bDisable = l_175_85, fnAction = l_175_85}
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {l_175_46, l_175_85, l_175_47, l_175_86, l_175_48, l_175_49, l_175_50, l_175_51, l_175_52, l_175_53; szOption = l_175_46}
              end
            else
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {bDevide = true}
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = l_175_3[l_175_6]
              l_175_46 = l_175_46.bScreenHead
              if not l_175_46 then
                l_175_46 = false
              end
              l_175_46 = function(l_195_0, l_195_1)
            -- upvalues: l_175_1 , l_175_4
            local l_195_2 = l_175_1[l_175_4]
            local l_195_3 = nil
            if not l_195_1 then
              l_195_3 = nil
            end
            l_195_2.bScreenHead = l_195_3
          end
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = "�����Ч������[ͷ������]��ʾ", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
              l_175_83 = IsCtrlKeyDown
              l_175_83 = l_175_83()
            end
            if l_175_83 then
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {bDevide = true}
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = l_175_3[l_175_6]
              l_175_46 = l_175_46.bNotAddToCTM
              if not l_175_46 then
                l_175_46 = false
              end
              l_175_46 = function(l_196_0, l_196_1)
            -- upvalues: l_175_1 , l_175_4
            local l_196_2 = l_175_1[l_175_4]
            local l_196_3 = nil
            if not l_196_1 then
              l_196_3 = nil
            end
            l_196_2.bNotAddToCTM = l_196_3
          end
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = "�����Ч�����ڸ��Ŷ��������ʾͼ��", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = l_175_3[l_175_6]
              l_175_46 = l_175_46.bOnlySelfSrcAddCTM
              if not l_175_46 then
                l_175_46 = false
              end
              l_175_46 = function(l_197_0, l_197_1)
            -- upvalues: l_175_1 , l_175_4
            local l_197_2 = l_175_1[l_175_4]
            local l_197_3 = nil
            if not l_197_1 then
              l_197_3 = nil
            end
            l_197_2.bOnlySelfSrcAddCTM = l_197_3
          end
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = "�������������ʾ��Դ���Լ���Ч��", bCheck = true, bChecked = l_175_46, fnAction = l_175_46}
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {bDevide = true}
              l_175_83 = function(l_198_0, l_198_1, l_198_2)
            -- upvalues: l_175_1 , l_175_4
            return function()
              -- upvalues: l_175_1 , l_175_4 , l_23_0 , l_23_1 , l_23_2
              local l_199_0 = l_175_1[l_175_4]
              do
                local l_199_1 = {}
                 -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                 -- DECOMPILER ERROR: Overwrote pending register.

                 -- DECOMPILER ERROR: Overwrote pending register.

                l_199_0(l_199_1)
              end
               -- WARNING: undefined locals caused missing assignments!
            end
          end
              l_175_45 = 210
              l_175_84 = 210
              l_175_46 = 210
              l_175_85 = l_175_3[l_175_6]
              l_175_85 = l_175_85.tRGBuffColor
              if l_175_85 then
                l_175_85 = l_175_3[l_175_6]
                l_175_85 = l_175_85.tRGBuffColor
                l_175_85 = l_175_85[1]
                l_175_47 = l_175_3[l_175_6]
                l_175_47 = l_175_47.tRGBuffColor
                l_175_47 = l_175_47[2]
                l_175_86 = l_175_3[l_175_6]
                l_175_86 = l_175_86.tRGBuffColor
                l_175_46 = l_175_86[3]
                l_175_84 = l_175_47
                l_175_45 = l_175_85
              end
              l_175_85 = table
              l_175_85 = l_175_85.insert
              l_175_47 = l_175_20
              l_175_48 = "��"
              l_175_49 = l_175_3[l_175_6]
              l_175_49 = l_175_49.szType
              l_175_50 = " �����ɫ (CTM�����ͼ�걳��ɫ)��"
              l_175_48 = l_175_48 .. l_175_49 .. l_175_50
              l_175_49 = l_175_83
              l_175_50 = 255
              l_175_51 = 0
              l_175_52 = 0
              l_175_49 = l_175_49(l_175_50, l_175_51, l_175_52)
              l_175_50 = l_175_83
              l_175_51 = 0
              l_175_52 = 255
              l_175_53 = 0
              l_175_50 = l_175_50(l_175_51, l_175_52, l_175_53)
              l_175_51 = l_175_83
              l_175_52 = 0
              l_175_53 = 0
              l_175_54 = 255
              l_175_51 = l_175_51(l_175_52, l_175_53, l_175_54)
              local l_175_77 = nil
              l_175_52 = l_175_83
              l_175_53 = 255
              l_175_54 = 255
              l_175_77 = 0
              l_175_52 = l_175_52(l_175_53, l_175_54, l_175_77)
              local l_175_78 = nil
              l_175_53 = l_175_83
              l_175_54 = 255
              l_175_77 = 0
              l_175_78 = 255
              l_175_53 = l_175_53(l_175_54, l_175_77, l_175_78)
              local l_175_79 = nil
              l_175_54 = l_175_83
              l_175_77 = 255
              l_175_78 = 255
              l_175_79 = 255
              l_175_54 = l_175_54(l_175_77, l_175_78, l_175_79)
              l_175_53, l_175_52, l_175_51, l_175_50, l_175_49, l_175_48 = {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 255, b = 255, fnAction = l_175_54}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 0, b = 255, fnAction = l_175_53}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 255, b = 0, fnAction = l_175_52}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 0, g = 0, b = 255, fnAction = l_175_51}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 0, g = 255, b = 0, fnAction = l_175_50}, {szOption = "�� ��", bCheck = false, bChecked = false, r = 255, g = 0, b = 0, fnAction = l_175_49}
              l_175_85(l_175_47, l_175_86)
              l_175_86 = {l_175_48, l_175_49, l_175_50, l_175_51, l_175_52, l_175_53; szOption = l_175_48, r = l_175_45, g = l_175_84, b = l_175_46}
              l_175_85 = table
              l_175_85 = l_175_85.insert
              l_175_47 = l_175_20
              l_175_48 = "��"
              l_175_49 = l_175_3[l_175_6]
              l_175_49 = l_175_49.szType
              l_175_50 = " �����ɫ (CTM�����ͼ�걳��ɫ)"
              l_175_48 = l_175_48 .. l_175_49 .. l_175_50
              l_175_48 = function(l_199_0, l_199_1)
            -- upvalues: l_175_1 , l_175_4
            l_175_1[l_175_4].tRGBuffColor = nil
            RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
          end
              l_175_85(l_175_47, l_175_86)
              l_175_86 = {szOption = l_175_48, bCheck = false, bChecked = false, bDisable = false, fnAction = l_175_48}
              l_175_85 = table
              l_175_85 = l_175_85.insert
              l_175_47 = l_175_20
              l_175_85(l_175_47, l_175_86)
              l_175_86 = {bDevide = true}
              l_175_85 = table
              l_175_85 = l_175_85.insert
              l_175_47 = l_175_20
              l_175_48 = l_175_3[l_175_6]
              l_175_48 = l_175_48.bManyMembers
              if not l_175_48 then
                l_175_48 = false
              end
              l_175_48 = function(l_200_0, l_200_1)
            -- upvalues: l_175_1 , l_175_4
            local l_200_2 = l_175_1[l_175_4]
            local l_200_3 = nil
            if not l_200_1 then
              l_200_3 = nil
            end
            l_200_2.bManyMembers = l_200_3
          end
              l_175_85(l_175_47, l_175_86)
              l_175_86 = {szOption = "��������ˢ�����ܣ���ʱ����˻�������ø�Ч����", bCheck = true, bChecked = l_175_48, fnAction = l_175_48}
            end
            l_175_83 = IsCtrlKeyDown
            l_175_83 = l_175_83()
            if l_175_83 then
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {bDevide = true}
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = "����Դ��ͼ:"
              l_175_85 = l_175_3[l_175_6]
              l_175_85 = l_175_85.szMapName
              if not l_175_85 then
                l_175_85 = "��δ֪��"
              end
              l_175_46 = l_175_46 .. l_175_85
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = l_175_46, bCheck = false, bChecked = false, bDisable = true}
              l_175_83 = l_175_3[l_175_6]
              l_175_83 = l_175_83.szCasterName
              if l_175_83 then
                l_175_83 = table
                l_175_83 = l_175_83.insert
                l_175_45 = l_175_20
                l_175_46 = "�������ͷ���:"
                l_175_85 = l_175_3[l_175_6]
                l_175_85 = l_175_85.szCasterName
                if not l_175_85 then
                  l_175_85 = "�����޴��"
                end
                l_175_46 = l_175_46 .. l_175_85
                l_175_83(l_175_45, l_175_84)
                l_175_84 = {szOption = l_175_46, bCheck = false, bChecked = false, bDisable = true}
              end
              l_175_83 = table
              l_175_83 = l_175_83.insert
              l_175_45 = l_175_20
              l_175_46 = function(l_201_0, l_201_1)
            -- upvalues: l_175_0
            GetPopupMenu():Hide()
            RaidGrid_Base.OutputRecord(l_175_0)
          end
              l_175_83(l_175_45, l_175_84)
              l_175_84 = {szOption = "����������ӡ������Ϣ����סAlt�ɵ�����", bCheck = false, bChecked = false, fnAction = l_175_46}
            end
            l_175_83 = table
            l_175_83 = l_175_83.insert
            l_175_45 = l_175_20
            l_175_83(l_175_45, l_175_84)
            l_175_84 = {bDevide = true}
            l_175_83 = table
            l_175_83 = l_175_83.insert
            l_175_45 = l_175_20
            l_175_46 = function(l_202_0, l_202_1)
          -- upvalues: l_175_1 , l_175_5 , l_175_4
          GetPopupMenu():Hide()
          if l_175_1.Hash2[l_175_5] and l_175_1[l_175_4].nLevel then
            l_175_1.Hash2[l_175_5][l_175_1[l_175_4].nLevel] = nil
          end
          if not l_175_1.Hash2[l_175_5] or RaidGrid_Base.isTableEmpty(l_175_1.Hash2[l_175_5]) then
            l_175_1.Hash2[l_175_5] = nil
            l_175_1.Hash[l_175_5] = nil
          end
          table.remove(l_175_1, l_175_4)
          RaidGrid_EventScrutiny.UpdateRecordList(RaidGrid_EventScrutiny.szListIndex)
        end
            l_175_83(l_175_45, l_175_84)
            l_175_84 = {szOption = "��ɾ������Ŀ", bCheck = false, bChecked = false, fnAction = l_175_46}
            l_175_83 = Cursor
            l_175_83 = l_175_83.GetPos
            l_175_45 = true
            l_175_83 = l_175_83(l_175_45)
            l_175_84 = l_175_83 + 15
            l_175_46 = l_175_45 + 15
            l_175_20.y = l_175_46
            l_175_20.x = l_175_84
            l_175_84 = PopupMenu
          end
           -- DECOMPILER ERROR: Confused about usage of registers!

          l_175_84(l_175_20)
        end
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
       -- WARNING: missing end command somewhere! Added here
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 121 173 
end

l_0_8[l_0_9] = l_0_10
l_0_8 = Hotkey
l_0_9 = "AddBinding"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "RaidGrid_ES_Switch"
l_0_10 = "����/�رռ�����"
l_0_11 = "�Ŷ��¼����"
l_0_12 = function()
  RaidGrid_EventScrutiny.ToggleWindow()
end

l_0_13 = nil
l_0_8(l_0_9, l_0_10, l_0_11, l_0_12, l_0_13)
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "ToggleWindow"
l_0_10 = function()
  if not RaidGrid_EventScrutiny.wnd then
    RaidGrid_EventScrutiny.OnNotCustomDataLoaded()
  else
    if RaidGrid_EventScrutiny.IsOpened() then
      RaidGrid_EventScrutiny.ClosePanel()
    end
  else
    RaidGrid_EventScrutiny.OpenPanel()
  end
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "OnCustomDataLoaded"
l_0_10 = function()
  if arg0 ~= "Role" then
    return 
  end
  RaidGrid_Base.VersionUpdate()
  RaidGrid_Base.ResetChatAlertCD()
  RaidGrid_Base.SimpleSettingsReset2()
  local l_178_0 = RaidGrid_EventScrutiny.tRecords
  local l_178_1 = {}
  l_178_1.Hash = {}
  l_178_1.Hash2 = {}
  l_178_0.Scrutiny = l_178_1
  l_178_0 = RaidGrid_EventCache
  l_178_0 = l_178_0.OpenPanel
  l_178_0()
  l_178_0 = RaidGrid_EventScrutiny
  l_178_0 = l_178_0.OpenPanel
  l_178_0()
  l_178_0 = RaidGrid_EventCache
  l_178_0 = l_178_0.ClosePanel
  l_178_0()
  l_178_0 = RaidGrid_SelfBuffAlert
  l_178_0 = l_178_0.OpenPanel
  l_178_0()
  l_178_0 = RaidGrid_EventScrutiny
  l_178_0 = l_178_0.SwitchPageType
  l_178_1 = "Scrutiny"
  l_178_0(l_178_1)
  l_178_0 = RaidGrid_EventScrutiny
  l_178_0.bCheckBoxRecall = false
  l_178_0 = RaidGrid_EventScrutiny
  l_178_0 = l_178_0.wnd
  l_178_0, l_178_1 = l_178_0:Lookup, l_178_0
  l_178_0 = l_178_0(l_178_1, "CheckBox_SelfBuff")
  if l_178_0 then
    l_178_1 = RaidGrid_EventScrutiny
    l_178_1 = l_178_1.bBuffChatAlertEnable
  end
  if l_178_1 then
    l_178_1 = RaidGrid_EventScrutiny
    l_178_1 = l_178_1.bCastingChatAlertEnable
  end
  if l_178_1 then
    l_178_1 = RaidGrid_EventScrutiny
    l_178_1 = l_178_1.bNpcChatAlertEnable
  end
  if l_178_1 then
    l_178_1 = RaidGrid_BossCallAlert
  end
  if l_178_1 then
    l_178_1 = RaidGrid_BossCallAlert
    l_178_1 = l_178_1.bChatAlertEnable
  end
  if l_178_1 then
    l_178_1(l_178_0, true)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  l_178_1.bCheckBoxRecall = true
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_178_1(RaidGrid_EventScrutiny.tLastLoc.nX, RaidGrid_EventScrutiny.tLastLoc.nY)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_178_1 <= 0 and l_178_1 <= 0 then
    l_178_1()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_178_1(RaidGrid_SelfBuffAlert.tLastLoc.nX, RaidGrid_SelfBuffAlert.tLastLoc.nY)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_178_1()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_178_1("�Ŷ��¼���� V4.01����� ������� by ����@˭������")
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RaidGrid_EventScrutiny
l_0_9 = "OnNotCustomDataLoaded"
l_0_10 = function()
  if RaidGrid_EventScrutiny.wnd then
    return 
  end
  RaidGrid_Base.VersionUpdate()
  RaidGrid_Base.ResetChatAlertCD()
  RaidGrid_Base.SimpleSettingsReset2()
  local l_179_0 = RaidGrid_EventScrutiny.tRecords
  local l_179_1 = {}
  l_179_1.Hash = {}
  l_179_1.Hash2 = {}
  l_179_0.Scrutiny = l_179_1
  l_179_0 = RaidGrid_EventCache
  l_179_0 = l_179_0.OpenPanel
  l_179_0()
  l_179_0 = RaidGrid_EventScrutiny
  l_179_0 = l_179_0.OpenPanel
  l_179_0()
  l_179_0 = RaidGrid_EventCache
  l_179_0 = l_179_0.ClosePanel
  l_179_0()
  l_179_0 = RaidGrid_SelfBuffAlert
  l_179_0 = l_179_0.OpenPanel
  l_179_0()
  l_179_0 = RaidGrid_EventScrutiny
  l_179_0 = l_179_0.SwitchPageType
  l_179_1 = "Scrutiny"
  l_179_0(l_179_1)
  l_179_0 = RaidGrid_EventScrutiny
  l_179_0.bCheckBoxRecall = false
  l_179_0 = RaidGrid_EventScrutiny
  l_179_0 = l_179_0.wnd
  l_179_0, l_179_1 = l_179_0:Lookup, l_179_0
  l_179_0 = l_179_0(l_179_1, "CheckBox_SelfBuff")
  if l_179_0 then
    l_179_1 = RaidGrid_EventScrutiny
    l_179_1 = l_179_1.bBuffChatAlertEnable
  end
  if l_179_1 then
    l_179_1 = RaidGrid_EventScrutiny
    l_179_1 = l_179_1.bCastingChatAlertEnable
  end
  if l_179_1 then
    l_179_1 = RaidGrid_EventScrutiny
    l_179_1 = l_179_1.bNpcChatAlertEnable
  end
  if l_179_1 then
    l_179_1 = RaidGrid_BossCallAlert
  end
  if l_179_1 then
    l_179_1 = RaidGrid_BossCallAlert
    l_179_1 = l_179_1.bChatAlertEnable
  end
  if l_179_1 then
    l_179_1(l_179_0, true)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  l_179_1.bCheckBoxRecall = true
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_179_1(RaidGrid_EventScrutiny.tLastLoc.nX, RaidGrid_EventScrutiny.tLastLoc.nY)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  if l_179_1 <= 0 and l_179_1 <= 0 then
    l_179_1()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_179_1(RaidGrid_SelfBuffAlert.tLastLoc.nX, RaidGrid_SelfBuffAlert.tLastLoc.nY)
  end
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_179_1()
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_179_1("�Ŷ��¼���� V4.01����� �ֶ�������� by ����@˭�����档")
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_179_1("���棺����㿴���˴���Ϣ��˵����InterfaceĿ¼�¿��ܴ�����һ�����߶��������Ĳ������Ȼ��һ����Ӱ���Ŷ��¼���ز����ʹ�ã�������Ȼ�������ҳ���ɾ����Щ������Ĳ����")
end

l_0_8[l_0_9] = l_0_10
l_0_8 = RegisterEvent
l_0_9 = "CUSTOM_DATA_LOADED"
l_0_10 = RaidGrid_EventScrutiny
l_0_11 = "OnCustomDataLoaded"
l_0_10 = l_0_10[l_0_11]
l_0_8(l_0_9, l_0_10)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterMod"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "RaidGrid_EventScrutiny"
l_0_10 = "�ŶӼ��"
l_0_11 = "\\ui\\image\\icon\\skill_wanhua_hot.tga"
l_0_12 = "BigFoot_24b10f70baf6f2b2677ce68025899b86"
l_0_8(l_0_9, l_0_10, l_0_11, l_0_12)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "RaidGrid_EventScrutiny"
l_0_10 = "bEnable"
l_0_11 = "�����ŶӼ��"
l_0_12 = true
l_0_13 = function(l_180_0)
  RaidGrid_EventScrutiny.bEnable = l_180_0
end

l_0_8(l_0_9, l_0_10, l_0_11, l_0_12, l_0_13)
l_0_8 = BFConfigPanel
l_0_9 = "RegisterCheckButton"
l_0_8 = l_0_8[l_0_9]
l_0_9 = "RaidGrid_EventScrutiny"
l_0_10 = "bCacheEnable"
l_0_11 = "���������¼���¼����Ӱ����Ϸ��FPS��"
l_0_12 = false
l_0_13 = function(l_181_0)
  RaidGrid_EventScrutiny.bCacheEnable = l_181_0
end

l_0_8(l_0_9, l_0_10, l_0_11, l_0_12, l_0_13)

