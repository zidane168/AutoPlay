-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_SkillMonitor.lua 

if not BF_SkillMonitor then
  BF_SkillMonitor = {}
end
local l_0_0 = BF_SkillMonitor
local l_0_1 = {}
local l_0_2 = {}
l_0_2.s = "LEFT"
l_0_2.r = "LEFT"
l_0_2.x = 500
l_0_2.y = 300
l_0_1.Anchor = l_0_2
l_0_1.nFrame = 0
l_0_1.bOn = false
l_0_1.bNotEnemy = false
l_0_0.Settings = l_0_1
l_0_0 = BF_SkillMonitor
l_0_2 = {["��������"] = 25, ["������ʤ"] = 20, ["��̨����"] = 20, ["ӭ�����"] = 20, ["��ҡֱ��"] = 30}
l_0_2 = {["��"] = 15, ["ͻ"] = 17, ["��"] = 25, ["�ϻ��"] = 23, ["�����"] = 60, ["�γ۳�"] = 40}
l_0_2 = {["����"] = 20, ["���໤��"] = 36, ["����ָ"] = 10, ["��¥��Ӱ"] = 24, ["��ʯ���"] = 20, ["ܽ�ز���"] = 25, ["̫��ָ"] = 25}
l_0_2 = {["תǬ��"] = 120, ["�˽���һ"] = 14, ["���Ż���"] = 20, ["��ת��һ"] = 15, ["���ɾ���"] = 20, ["���Զ���"] = 25, ["�������"] = 20, ["ƾ������"] = 30, ["�巽�о�"] = 15, ["��ɽ��"] = 300}
l_0_2 = {["��Ū��"] = 90, ["ȵ̤֦"] = 60, ["����ͨ��"] = 30, ["��������"] = 40, ["��صͰ�"] = 90, ["������"] = 400, ["��ĸ����"] = 15, ["����Ͱ�"] = 45}
l_0_2 = {["׽Ӱʽ"] = 17, ["����ʽ"] = 30, ["�͹Ǿ�"] = 45, ["���̽Կ�"] = 14, ["�����"] = 90, ["Ħڭ����"] = 25}
l_0_2 = {["����"] = 12, ["ժ��"] = 20, ["������"] = 15, ["����ƾ�"] = 15, ["Х��"] = 10.5, ["����"] = 14, ["��Ȫ����"] = 30, ["�׹��ɽ"] = 20}
l_0_2 = {["�Ƴ��׼�"] = 27, ["Ů洲���"] = 54, ["�Ƴ��"] = 120, ["�ٻ�����"] = 30, ["ǧ������"] = 180}
l_0_2 = {["������"] = 25, ["����"] = 20, ["÷����"] = 15, ["������צ"] = 30, ["��������"] = 70, ["��������"] = 120, ["������Ӱ"] = 120}
l_0_0.tMonitorData, l_0_1 = l_0_1, {["����"] = l_0_2, ["���"] = l_0_2, ["��"] = l_0_2, ["����"] = l_0_2, ["����"] = l_0_2, ["����"] = l_0_2, ["�ؽ�"] = l_0_2, ["�嶾"] = l_0_2, ["����"] = l_0_2}
l_0_0 = "interface/BF_SkillMonitor/progressbar.UiTex"
local l_0_3 = {}
local l_0_4 = {}
l_0_4["��صͰ�"] = 557
l_0_4["ȵ̤֦"] = 550
l_0_4["��Ū��"] = 574
l_0_4["������"] = 548
l_0_3["������"] = l_0_4
l_0_3["����ͻ"], l_0_4 = l_0_4, {["�ϻ��"] = 428, ["�γ۳�"] = 433, ["�Ƽ���"] = 426, ["�Ѳ��"] = 479}
l_0_3["������"], l_0_4 = l_0_4, {["��������"] = 9003}
l_0_3["�������"], l_0_4 = l_0_4, {["��ʯ���"] = 182}
l_0_3["תǬ��"], l_0_4 = l_0_4, {["��̫��"] = 358, ["������"] = 357, ["������"] = 363}
l_0_3["�ϳ�"], l_0_4 = l_0_4, {["�Ʒ����"] = 1593}
l_0_3["����������"], l_0_4 = l_0_4, {["����ɽ"] = 413, ["躹�����"] = 313, ["������ɽ"] = 1645, ["��������"] = 3114}
l_0_3["����������"], l_0_4 = l_0_4, {["��ˮ����"] = 131, ["����Ͱ�"] = 555, ["ǧ������"] = 2235}
l_0_3["����������"], l_0_4 = l_0_4, {["��ɽ��"] = 371, ["������"] = 573, ["ˮ���޼�"] = 136, ["�͹Ǿ�"] = 257, ["��������"] = 3004, ["�ٻ�����"] = 999999}
l_0_3["���໤��"], l_0_4 = l_0_4, {["̫��ָ"] = 228}
l_0_3["�Ƴ��׼�"], l_0_4 = l_0_4, {["�ٻ�����"] = 999999}
local l_0_5 = {}
l_0_5["2221"] = 999999
l_0_5["2222"] = 999999
l_0_5["2223"] = 999999
l_0_5["2224"] = 999999
l_0_5["2225"] = 999999
RegisterCustomData("BF_SkillMonitor.Settings")
RegisterCustomData("BF_SkillMonitor.tMonitorData")
local l_0_6 = function(l_1_0)
  local l_1_1 = GetMsgFontString("MSG_SYS")
  OutputMessage("MSG_SYS", FormatString("<text>text=\"<Ŀ��CD����> \" font=0 r=0 g=196 b=196</text><text>text=\"<D0> \"font=0 r=255 g=255 b=255</text><D1><text>text=\"\n\" font=<D1></text>", l_1_0, l_1_1), true)
end

BF_SkillMonitor.GetMenu = function()
  local l_2_0 = {}
  l_2_0.szOption = "Ŀ�꼼��CD"
  local l_2_1 = {}
  l_2_1.szOption = "�Զ��弼��"
  for l_2_5,l_2_6 in pairs(BF_SkillMonitor.tMonitorData) do
    do
      local l_2_7 = {}
      l_2_7.szOption = l_2_5
      for l_2_11,l_2_12 in pairs(BF_SkillMonitor.tMonitorData[l_2_5]) do
        do
          local l_2_13 = {}
          l_2_13.szOption = l_2_11
          local l_2_14 = {}
          l_2_14.szOption = "�޸�[" .. l_2_12 .. "]��"
          l_2_14.fnAction = function()
            -- upvalues: l_2_5 , l_2_11 , l_2_12
            local l_3_0 = GetUserInput
            l_3_0("���뼼����ȴʱ�䣺", function(l_4_0)
              -- upvalues: l_2_5 , l_2_11
              BF_SkillMonitor.tMonitorData[l_2_5][l_2_11] = l_4_0
            end, nil, nil, nil, l_2_12)
          end
          local l_2_15 = {}
          l_2_15.szOption = "ɾ������"
          l_2_15.fnAction = function()
            -- upvalues: l_2_5 , l_2_11
            BF_SkillMonitor.tMonitorData[l_2_5][l_2_11] = nil
            BigFoot_Print("Ŀ��CD����", "[ " .. l_2_11 .. " ]�Ѵ��б�ɾ��")
          end
          table.insert(l_2_13, l_2_14)
          local l_2_16 = table.insert
          local l_2_17 = l_2_13
          local l_2_18 = {}
          l_2_18.bDevide = true
          l_2_16(l_2_17, l_2_18)
          l_2_16 = table
          l_2_16 = l_2_16.insert
          l_2_17 = l_2_13
          l_2_18 = l_2_15
          l_2_16(l_2_17, l_2_18)
          l_2_16 = table
          l_2_16 = l_2_16.insert
          l_2_17 = l_2_7
          l_2_18 = l_2_13
          l_2_16(l_2_17, l_2_18)
        end
      end
      local l_2_19 = table.insert
      local l_2_20 = l_2_7
      local l_2_21 = {}
      l_2_21.bDevide = true
      l_2_19(l_2_20, l_2_21)
      l_2_20 = function()
        -- upvalues: l_2_5
        local l_5_0 = GetUserInput
        l_5_0("���뼼�����ƣ�", function(l_6_0)
          -- upvalues: l_2_5
          local l_6_1 = BF_SkillMonitor.GetSkillCDByName(l_6_0)
          BF_SkillMonitor.tMonitorData[l_2_5][l_6_0] = l_6_1
        end, nil, nil, nil, nil)
      end
      l_2_20 = table
      l_2_20 = l_2_20.insert
      l_2_21 = l_2_7
      l_2_20(l_2_21, l_2_19)
      l_2_20 = table
      l_2_20 = l_2_20.insert
      l_2_21 = l_2_1
      l_2_20(l_2_21, l_2_7)
    end
  end
  table.insert(l_2_0, l_2_1)
  return l_2_0
end

BF_SkillMonitor.OnFrameCreate = function()
  local l_3_0 = this:Lookup("", "")
  l_3_0:Lookup("Handle_List"):Clear()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("DO_SKILL_CAST")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_SWITCH_MAP")
end

BF_SkillMonitor.OnEvent = function(l_4_0)
  -- upvalues: l_0_2
  if l_4_0 == "UI_SCALED" or l_4_0 == "CUSTOM_DATA_LOADED" and arg0 == "Role" then
    BF_SkillMonitor.UpdateAnchor(this)
  elseif l_4_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_4_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this, "Ŀ�꼼��CD")
  elseif l_4_0 == "DO_SKILL_CAST" then
    if not BF_SkillMonitor.Settings.bOn then
      return 
    end
    BF_SkillMonitor.OnSkillCast(arg0, arg1, arg2)
  elseif l_4_0 == "ON_SWITCH_MAP" then
    l_0_2 = {}
  end
end

BF_SkillMonitor.OnFrameDragEnd = function()
  this:CorrectPos()
  BF_SkillMonitor.Settings.Anchor = GetFrameAnchor(this)
end

BF_SkillMonitor.UpdateAnchor = function(l_6_0)
  local l_6_1 = BF_SkillMonitor.Settings.Anchor
  l_6_0:SetPoint(l_6_1.s, 0, 0, l_6_1.r, l_6_1.x, l_6_1.y)
  l_6_0:CorrectPos()
end

BF_SkillMonitor.OnFrameBreathe = function()
  -- upvalues: l_0_2 , l_0_1
  if not BF_SkillMonitor.Settings.bOn then
    return 
  end
  local l_7_0 = this:Lookup("", "Handle_List")
  local l_7_1 = GetClientPlayer()
  if not l_7_1 then
    return 
  end
  local l_7_2 = GetTargetHandle(l_7_1.GetTarget())
  if not l_7_2 or not IsPlayer(l_7_2.dwID) or not l_0_2[l_7_2.dwID] or IsEmpty(l_0_2[l_7_2.dwID]) then
    l_7_0:Clear()
    return 
  end
  if not this.dwID or this.dwID and this.dwID ~= l_7_2.dwID then
    this.dwID = l_7_2.dwID
    l_7_0:Clear()
  end
  local l_7_3 = GetForceTitle(l_7_2.dwForceID)
  for l_7_7,l_7_8 in pairs(l_0_2[l_7_2.dwID]) do
    do
      local l_7_9 = l_7_0:Lookup(tostring(l_7_7))
      local l_7_10 = GetLogicFrameCount()
      local l_7_11 = (l_7_10 - l_7_8.time) / 16
      local l_7_12 = nil
      for l_7_16,l_7_17 in pairs(BF_SkillMonitor.tMonitorData["����"]) do
        if l_7_8.name == l_7_16 then
          l_7_12 = l_7_17
          do return end
        else
          l_7_12 = BF_SkillMonitor.tMonitorData[l_7_3][l_7_8.name]
        end
      end
      for l_7_21,l_7_22 in pairs(l_0_1) do
        if l_7_2.dwID == l_7_22.dwCasterID then
          l_7_0:RemoveItem(tostring(l_7_22.dwSkillID))
          table.remove(l_0_1, l_7_21)
        end
      end
      do
        local l_7_23, l_7_29 = 1 - l_7_11 / l_7_12
        if l_7_23 <= 0 then
          l_7_29 = l_0_2
          l_7_29 = l_7_29[l_7_2.dwID]
          l_7_29[l_7_7] = nil
          if l_7_9 then
            l_7_29(l_7_0, tostring(l_7_7))
          end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        elseif not l_7_9 then
          l_7_9 = l_7_29
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_29(l_7_29, BF_SkillMonitor.Settings.nFrame)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_29(l_7_29, l_7_23)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_29(l_7_29, l_7_23 * 230 + 24, 0)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        l_7_29(l_7_29, l_7_8.name)
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        local l_7_24, l_7_25, l_7_26 = nil
         -- DECOMPILER ERROR: Overwrote pending register.

        local l_7_27 = nil
        if l_7_29 > 0 then
          l_7_27(l_7_26, "" .. l_7_29 .. "h " .. l_7_24)
         -- DECOMPILER ERROR: Overwrote pending register.

        elseif l_7_24 > 0 then
          l_7_27(l_7_26, "" .. l_7_24 .. "m " .. l_7_25)
         -- DECOMPILER ERROR: Overwrote pending register.

        else
          l_7_27(l_7_26, "" .. l_7_25)
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        do
          local l_7_28 = nil
          l_7_28(l_7_27, UI_OBJECT_SKILL, l_7_7, l_7_8.level)
           -- DECOMPILER ERROR: Overwrote pending register.

          l_7_28(l_7_27, Table_GetSkillIconID(l_7_7, l_7_8.level))
           -- DECOMPILER ERROR: Overwrote pending register.

          l_7_27.OnItemMouseEnter = l_7_28
           -- DECOMPILER ERROR: Overwrote pending register.

          l_7_27.OnItemMouseHover = l_7_28
           -- DECOMPILER ERROR: Overwrote pending register.

          l_7_27.OnItemMouseLeave = l_7_28
        end
         -- DECOMPILER ERROR: Overwrote pending register.

      end
      l_7_29(l_7_9)
    end
  end
  l_7_0:FormatAllItemPos()
end

BF_SkillMonitor.GetSkillCDByName = function(l_8_0)
  local l_8_1 = 0
  local l_8_2 = {}
  local l_8_3 = KG_Table.Load
  local l_8_4 = "\\settings\\CoolDownList.tab"
  local l_8_5 = {}
  local l_8_6 = {}
  l_8_6.f = "i"
  l_8_6.t = "ID"
  local l_8_7 = {}
  l_8_7.f = "i"
  l_8_7.t = "Duration"
  local l_8_8 = {}
  l_8_8.f = "s"
  l_8_8.t = "note"
  local l_8_9 = {}
  l_8_9.f = "i"
  l_8_9.t = "Usage"
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_8_6 = FILE_OPEN_MODE
  l_8_6 = l_8_6.NORMAL
  l_8_3 = l_8_3(l_8_4, l_8_5, l_8_6)
  if l_8_3 then
    l_8_5, l_8_6 = l_8_3:GetRowCount, l_8_3
    l_8_5 = l_8_5(l_8_6)
    l_8_6 = 2
    l_8_7 = l_8_5
    l_8_8 = 1
    for l_8_9 = l_8_6, l_8_7, l_8_8 do
      local l_8_10 = l_8_3:GetRow(l_8_9)
      local l_8_11 = l_8_10.ID
      local l_8_12 = l_8_10.Duration
      local l_8_13 = l_8_10.note
      local l_8_14 = l_8_10.Usage
      local l_8_15 = table.insert
      local l_8_16 = l_8_4
      local l_8_17 = {}
      l_8_17.n = l_8_11
      l_8_17.cd = l_8_12
      l_8_17.name = l_8_13
      l_8_17.level = l_8_14
      l_8_15(l_8_16, l_8_17)
    end
    l_8_2 = l_8_4
  end
   -- DECOMPILER ERROR: Overwrote pending register.

  l_8_5 = l_8_2
   -- DECOMPILER ERROR: Overwrote pending register.

  for i_1,i_2 in l_8_4 do
    local l_8_18, l_8_19, l_8_20 = nil
    if string.find(l_8_18, l_8_19) then
      l_8_1 = i_2.cd
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      BigFoot_Print(l_8_18, l_8_19)
      do break end
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    else
      BigFoot_Print(l_8_18, l_8_19)
      do break end
    end
  end
  return l_8_1
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

BF_SkillMonitor.OnSkillCast = function(l_9_0, l_9_1, l_9_2)
  -- upvalues: l_0_3 , l_0_2 , l_0_5 , l_0_1 , l_0_4
  if not IsPlayer(arg0) then
    return 
  end
  if not BF_SkillMonitor.Settings.bNotEnemy and not IsEnemy(GetClientPlayer().dwID, l_9_0) then
    return 
  end
  local l_9_3 = Table_GetSkillName(l_9_1, l_9_2)
  local l_9_4 = Table_GetSkillIconID(l_9_1, l_9_2)
  if not Table_IsSkillShow(l_9_1, l_9_2) or l_9_4 == -1 or l_9_4 == 13 or l_9_4 == 624 or l_9_4 == 615 then
    return 
  end
  local l_9_5 = GetPlayer(l_9_0)
  local l_9_6 = GetForceTitle(l_9_5.dwForceID)
  if not BF_SkillMonitor.tMonitorData[l_9_6] then
    return 
  end
  do
    local l_9_7 = 0
    if not l_0_3[l_9_3] then
      do break end
    end
    do
      local l_9_8, l_9_9, l_9_10, l_9_11, l_9_12 = pairs({})
      if not l_0_2[l_9_0] then
        for l_9_16,l_9_17 in pairs({}) do
        end
        if l_0_5[tostring(l_9_16)] then
          l_9_7 = l_9_16
          l_9_16 = l_0_5[tostring(l_9_16)]
        end
        if l_9_16 == l_9_12 then
          if l_9_16 == 999999 then
            l_9_16 = l_9_7
          end
          l_0_2[l_9_0][l_9_16] = nil
          local l_9_18 = table.insert
          local l_9_19 = l_0_1
          local l_9_20 = {}
          l_9_20.dwCasterID = l_9_0
          l_9_20.dwSkillID = l_9_16
          l_9_18(l_9_19, l_9_20)
        end
      end
    end
  end
  if l_0_4[l_9_3] then
    l_9_3 = l_0_4[l_9_3]
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

   -- DECOMPILER ERROR: Confused about usage of registers!

  if BF_SkillMonitor.tMonitorData[l_9_6][l_9_3] or BF_SkillMonitor.tMonitorData["����"][l_9_3] then
    if not l_0_2[l_9_0] then
      l_0_2[l_9_0] = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

     -- DECOMPILER ERROR: Confused about usage of registers!

    if not l_0_2[l_9_0][l_9_1] then
      l_0_2[l_9_0][l_9_1] = {}
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_9_21, l_9_23, l_9_25 = l_0_2[l_9_0]
    do
      local l_9_22, l_9_24, l_9_26 = nil
      l_9_25 = GetLogicFrameCount
      l_9_25 = l_9_25()
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    l_9_21[l_9_1] = {name = l_9_3, id = l_9_1, level = l_9_2, time = l_9_25}
  end
   -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end
end

Wnd.OpenWindow("Interface\\BF_SkillMonitor\\BF_SkillMonitor.ini", "BF_SkillMonitor")
BFConfigPanel.RegisterMod("SkillMonitor", "����CD", "\\ui\\image\\icon\\skill_wanhua10.tga", "BigFoot_24b10f70baf6f2b2677ce68025899b86")
BFConfigPanel.RegisterCheckButton("SkillMonitor", "Settings.bOn", "����Ŀ�꼼��CD��ʾ", false, function(l_10_0)
  BF_SkillMonitor.Settings.bOn = l_10_0
end
)
BFConfigPanel.RegisterCheckButton("SkillMonitor", "Settings.bNotEnemy", "�����ѷ�����CD", false, function(l_11_0)
  BF_SkillMonitor.Settings.bNotEnemy = l_11_0
end
, 2)
BFConfigPanel.RegisterEditBox("SkillMonitor", "Settings.nFrame", "���ı������ʣ���0-7����ʽ��", BF_SkillMonitor.Settings.nFrame, function(l_12_0, l_12_1)
  if tonumber(l_12_0) then
    if tonumber(l_12_0) > 7 then
      BigFoot_Print("Ŀ��CD����", "��ǰ����ֵ̫������������")
      BF_SkillMonitor.Settings.nFrame = 0
      return 
    end
    if tonumber(l_12_0) < 0 then
      BigFoot_Print("Ŀ��CD����", "��ǰ����ֵ̫С������������")
      BF_SkillMonitor.Settings.nFrame = 0
      return 
    end
    BF_SkillMonitor.Settings.nFrame = tonumber(l_12_0)
  elseif not l_12_1 then
    BF_SkillMonitor.Settings.nFrame = 0
  end
end
, 2)
BFConfigPanel.Registerbutton("SkillMonitor", "btnSetting", "�������", true, function(l_13_0)
  local l_13_1 = BF_SkillMonitor.GetMenu()
  PopupMenu(l_13_1)
end
, 2)

