-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetState.lua 

local l_0_0 = {}
local l_0_1 = {}
l_0_1.s = "TOPLEFT"
l_0_1.r = "TOPLEFT"
l_0_1.x = 500
l_0_1.y = 300
l_0_0.Anchor = l_0_1
l_0_0.bShowTargetState = true
TargetState = l_0_0
l_0_0 = RegisterCustomData
l_0_1 = "TargetState.Anchor"
l_0_0(l_0_1)
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_KNOCKED_DOWN
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_RISE
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_KNOCKED_BACK
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_KNOCKED_OFF
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_HALT
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_FREEZE
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_ENTRAP
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_DASH
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_PULL
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_REPULSED
l_0_1 = MOVE_STATE
l_0_1 = l_0_1.ON_SKID
TargetState.OnFrameCreate = function()
  this:RegisterEvent("UI_SCALED")
  this:RegisterEvent("CUSTOM_DATA_LOADED")
  this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
  this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
  TargetState.UpdateAnchor(this)
  UpdateCustomModeWindow(this, "Ŀ��״̬")
end

TargetState.OnEvent = function(l_2_0)
  if l_2_0 == "UI_SCALED" then
    TargetState.UpdateAnchor(this)
  elseif l_2_0 == "CUSTOM_DATA_LOADED" then
    TargetState.UpdateAnchor(this)
  elseif l_2_0 == "ON_ENTER_CUSTOM_UI_MODE" or l_2_0 == "ON_LEAVE_CUSTOM_UI_MODE" then
    UpdateCustomModeWindow(this)
  end
end

TargetState.OnFrameDragEnd = function()
  this:CorrectPos()
  TargetState.Anchor = GetFrameAnchor(this, "TOPLEFT")
end

TargetState.UpdateAnchor = function(l_4_0)
  l_4_0:SetPoint(TargetState.Anchor.s, 0, 0, TargetState.Anchor.r, TargetState.Anchor.x, TargetState.Anchor.y)
  l_4_0:CorrectPos()
end

TargetState.OnFrameBreathe = function()
  if not TargetState.bShowTargetState then
    return 
  end
  TargetState.UpdateMoveState(this)
end

TargetState.TargetUnctrl = function()
  -- upvalues: l_0_1
  local l_6_0 = GetClientPlayer()
  local l_6_1, l_6_2 = l_6_0.GetTarget()
  if l_6_1 ~= TARGET.PLAYER then
    return false, -1
  end
  local l_6_3 = GetPlayer(l_6_2)
  if not l_6_3 then
    return false, -1
  end
  if not l_6_3.GetBuffList() then
    local l_6_4, l_6_5 = {}
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  do break end
  do
    local l_6_6, l_6_7, l_6_8, l_6_9, l_6_10 = , pairs(l_6_4)
     -- DECOMPILER ERROR: Confused about usage of registers!

    local l_6_11 = nil
    for l_6_15,l_6_16 in pairs(l_0_1) do
      local l_6_12 = R9_PC28.dwID
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_6_12 == R15_PC33 then
        return true, l_6_12
      end
    end
  end
end
return false, -1
end

TargetState.UpdateMoveState = function(l_7_0)
  -- upvalues: l_0_0
  local l_7_1 = l_7_0:Lookup("", "")
  local l_7_2 = l_7_1:Lookup("Image_Icon")
  local l_7_3 = l_7_1:Lookup("Text_State")
  local l_7_4 = GetClientPlayer()
  if not l_7_4 then
    return 
  end
  local l_7_5, l_7_6 = l_7_4.GetTarget()
  if l_7_6 == 0 then
    l_7_1:Hide()
    return 
  end
  local l_7_7 = GetTargetHandle(l_7_5, l_7_6)
  local l_7_8 = l_7_7.nMoveState
  local l_7_9 = l_0_0[l_7_8]
  if l_7_8 == 9 or l_7_8 == 20 then
    l_7_2:FromIconID(2027)
    l_7_3:SetText(l_7_9)
    l_7_3:SetFontScheme(199)
  elseif l_7_8 == 10 or l_7_8 == 11 or l_7_8 == 17 or l_7_8 == 18 or l_7_8 == 19 or l_7_8 == 21 then
    l_7_2:FromIconID(80)
    l_7_3:SetText(l_7_9)
    l_7_3:SetFontScheme(200)
  elseif l_7_8 == 12 then
    l_7_2:FromIconID(2019)
    l_7_3:SetText(l_7_9)
    l_7_3:SetFontScheme(199)
  elseif l_7_8 == 13 then
    l_7_2:FromIconID(2038)
    l_7_3:SetText(l_7_9)
    l_7_3:SetFontScheme(199)
  elseif l_7_8 == 14 then
    l_7_2:FromIconID(2020)
    l_7_3:SetText(l_7_9)
    l_7_3:SetFontScheme(199)
  else
    local l_7_10, l_7_11 = TargetState.TargetUnctrl()
    if l_7_10 then
      l_7_2:FromIconID(Table_GetBuffIconID(l_7_11, 1))
      local l_7_12 = Table_GetBuffName(l_7_11, 1)
      l_7_3:SetText(l_7_12)
      l_7_3:SetFontScheme(200)
    end
  else
    l_7_1:Hide()
    return 
  end
  l_7_1:Show()
end

TargetState.Switch = function(l_8_0)
  local l_8_1 = Station.Lookup("Topmost/TargetState")
  if l_8_0 then
    l_8_1:Show()
  else
    l_8_1:Hide()
  end
end

Wnd.OpenWindow("Interface\\BF_TargetEx\\TargetState.ini", "TargetState")

