-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: Options.lua 

if not ThreatScrutiny then
  ThreatScrutiny = {}
end
ThreatScrutiny.tOptions = {}
ThreatScrutiny.bLockPanel = false
RegisterCustomData("ThreatScrutiny.bLockPanel")
ThreatScrutiny.nBGAlpha = 40
RegisterCustomData("ThreatScrutiny.nBGAlpha")
ThreatScrutiny.szThreatPercentAccuracy = "%.0f%%"
RegisterCustomData("ThreatScrutiny.szThreatPercentAccuracy")
ThreatScrutiny.bShowThreatPercent = false
RegisterCustomData("ThreatScrutiny.bShowThreatPercent")
ThreatScrutiny.bShowThreatbalancePercent = true
RegisterCustomData("ThreatScrutiny.bShowThreatbalancePercent")
ThreatScrutiny.bShowThreatAnykindPercent = false
RegisterCustomData("ThreatScrutiny.bShowThreatAnykindPercent")
ThreatScrutiny.bHideThreatPercent = false
RegisterCustomData("ThreatScrutiny.bHideThreatPercent")
ThreatScrutiny.nMaxBarCount = 5
RegisterCustomData("ThreatScrutiny.nMaxBarCount")
ThreatScrutiny.bForceColor = true
RegisterCustomData("ThreatScrutiny.bForceColor")
ThreatScrutiny.bShowScrutinyDist = true
RegisterCustomData("ThreatScrutiny.bShowScrutinyDist")
ThreatScrutiny.bShowHPPercent = true
RegisterCustomData("ThreatScrutiny.bShowHPPercent")
ThreatScrutiny.bFoucsPartyTarget = true
RegisterCustomData("ThreatScrutiny.bFoucsPartyTarget")
ThreatScrutiny.szCastAlertRelation = "Enemy"
RegisterCustomData("ThreatScrutiny.szCastAlertRelation")
ThreatScrutiny.szCastAlertCharType = "All"
RegisterCustomData("ThreatScrutiny.szCastAlertCharType")
ThreatScrutiny.nCastAlertIntensity = 5
RegisterCustomData("ThreatScrutiny.nCastAlertIntensity")
ThreatScrutiny.nCastAlertChannel = -1
RegisterCustomData("ThreatScrutiny.nCastAlertChannel")
ThreatScrutiny.nOTAlertLevel = 1
RegisterCustomData("ThreatScrutiny.nCastAlertChannel")
ThreatScrutiny.bOTAlertSound = true
RegisterCustomData("ThreatScrutiny.bOTAlertSound")
ThreatScrutiny.PopOptions = function()
  local l_1_0 = ThreatScrutiny
  local l_1_1 = {}
  local l_1_2 = {}
  l_1_2.szOption = "������޲�����λ��"
  l_1_2.bCheck = true
  l_1_2.bChecked = ThreatScrutiny.bLockPanel
  l_1_2.fnAction = function(l_2_0, l_2_1)
    ThreatScrutiny.bLockPanel = l_2_1
    if ThreatScrutiny.bLockPanel then
      ThreatScrutiny.frameSelf:EnableDrag(false)
    else
      ThreatScrutiny.frameSelf:EnableDrag(true)
    end
  end
  local l_1_3 = {}
  l_1_3.bDevide = true
  local l_1_4 = {}
  l_1_4.szOption = "��ʾ��Ŀ��ľ���"
  l_1_4.bCheck = true
  l_1_4.bChecked = ThreatScrutiny.bShowScrutinyDist
  l_1_4.fnAction = function(l_3_0, l_3_1)
    ThreatScrutiny.bShowScrutinyDist = l_3_1
  end
  local l_1_5 = {}
  l_1_5.szOption = "��ʾĿ��Ѫ���ٷֱ�"
  l_1_5.bCheck = true
  l_1_5.bChecked = ThreatScrutiny.bShowHPPercent
  l_1_5.fnAction = function(l_4_0, l_4_1)
    ThreatScrutiny.bShowHPPercent = l_4_1
  end
  local l_1_6 = {}
  l_1_6.bDevide = true
  local l_1_7 = {}
  l_1_7.szOption = "��޲��������ɫ��ȣ�"
  local l_1_8 = {}
  l_1_8.szOption = "����"
  l_1_8.bMCheck = true
  l_1_8.bChecked = ThreatScrutiny.nBGAlpha == 0
  l_1_8.fnAction = function()
    ThreatScrutiny.nBGAlpha = 0
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_11 = {}
  l_1_11.szOption = "������"
  l_1_11.bMCheck = true
  l_1_11.bChecked = ThreatScrutiny.nBGAlpha == 10
  l_1_11.fnAction = function()
    ThreatScrutiny.nBGAlpha = 10
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_14 = {}
  l_1_14.szOption = "������"
  l_1_14.bMCheck = true
  l_1_14.bChecked = ThreatScrutiny.nBGAlpha == 20
  l_1_14.fnAction = function()
    ThreatScrutiny.nBGAlpha = 20
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_17 = {}
  l_1_17.szOption = "������"
  l_1_17.bMCheck = true
  l_1_17.bChecked = ThreatScrutiny.nBGAlpha == 30
  l_1_17.fnAction = function()
    ThreatScrutiny.nBGAlpha = 30
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_20 = {}
  l_1_20.szOption = "������"
  l_1_20.bMCheck = true
  l_1_20.bChecked = ThreatScrutiny.nBGAlpha == 40
  l_1_20.fnAction = function()
    ThreatScrutiny.nBGAlpha = 40
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_23 = {}
  l_1_23.szOption = "������"
  l_1_23.bMCheck = true
  l_1_23.bChecked = ThreatScrutiny.nBGAlpha == 50
  l_1_23.fnAction = function()
    ThreatScrutiny.nBGAlpha = 50
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_26 = {}
  l_1_26.szOption = "������"
  l_1_26.bMCheck = true
  l_1_26.bChecked = ThreatScrutiny.nBGAlpha == 60
  l_1_26.fnAction = function()
    ThreatScrutiny.nBGAlpha = 60
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_29 = {}
  l_1_29.szOption = "������"
  l_1_29.bMCheck = true
  l_1_29.bChecked = ThreatScrutiny.nBGAlpha == 70
  l_1_29.fnAction = function()
    ThreatScrutiny.nBGAlpha = 70
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_32 = {}
  l_1_32.szOption = "������"
  l_1_32.bMCheck = true
  l_1_32.bChecked = ThreatScrutiny.nBGAlpha == 80
  l_1_32.fnAction = function()
    ThreatScrutiny.nBGAlpha = 80
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_35 = {}
  l_1_35.szOption = "������"
  l_1_35.bMCheck = true
  l_1_35.bChecked = ThreatScrutiny.nBGAlpha == 90
  l_1_35.fnAction = function()
    ThreatScrutiny.nBGAlpha = 90
    ThreatScrutiny.SetBGAlpha()
  end
  local l_1_38 = {}
  l_1_38.szOption = "��������"
  l_1_38.bMCheck = true
  l_1_38.bChecked = ThreatScrutiny.nBGAlpha == 100
  l_1_38.fnAction = function()
    ThreatScrutiny.nBGAlpha = 100
    ThreatScrutiny.SetBGAlpha()
  end
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_1_17 = ThreatScrutiny
  l_1_17 = l_1_17.szThreatPercentAccuracy
  l_1_17 = l_1_17 == "%.0f%%"
  l_1_17 = function()
    ThreatScrutiny.szThreatPercentAccuracy = "%.0f%%"
  end
  l_1_20 = ThreatScrutiny
  l_1_20 = l_1_20.szThreatPercentAccuracy
  l_1_20 = l_1_20 == "%.1f%%"
  l_1_20 = function()
    ThreatScrutiny.szThreatPercentAccuracy = "%.1f%%"
  end
  l_1_23 = ThreatScrutiny
  l_1_23 = l_1_23.szThreatPercentAccuracy
  l_1_23 = l_1_23 == "%.2f%%"
  l_1_23 = function()
    ThreatScrutiny.szThreatPercentAccuracy = "%.2f%%"
  end
  l_1_20, l_1_17, l_1_14 = {szOption = "��.����", bMCheck = true, bChecked = l_1_23, fnAction = l_1_23}, {szOption = "��.��", bMCheck = true, bChecked = l_1_20, fnAction = l_1_20}, {szOption = "��", bMCheck = true, bChecked = l_1_17, fnAction = l_1_17}
  l_1_17 = ThreatScrutiny
  l_1_17 = l_1_17.bShowThreatPercent
  l_1_17 = function(l_19_0, l_19_1)
    ThreatScrutiny.bShowThreatPercent = l_19_1
    if l_19_1 then
      ThreatScrutiny.bShowThreatbalancePercent = false
      ThreatScrutiny.bShowThreatAnykindPercent = false
      ThreatScrutiny.bHideThreatPercent = false
    end
  end
  l_1_20 = ThreatScrutiny
  l_1_20 = l_1_20.bShowThreatbalancePercent
  l_1_20 = function(l_20_0, l_20_1)
    ThreatScrutiny.bShowThreatbalancePercent = l_20_1
    if l_20_1 then
      ThreatScrutiny.bShowThreatPercent = false
      ThreatScrutiny.bShowThreatAnykindPercent = false
      ThreatScrutiny.bHideThreatPercent = false
    end
  end
  l_1_23 = ThreatScrutiny
  l_1_23 = l_1_23.bShowThreatAnykindPercent
  l_1_23 = function(l_21_0, l_21_1)
    ThreatScrutiny.bShowThreatAnykindPercent = l_21_1
    if l_21_1 then
      ThreatScrutiny.bShowThreatPercent = false
      ThreatScrutiny.bShowThreatbalancePercent = false
      ThreatScrutiny.bHideThreatPercent = false
    end
  end
  l_1_26 = ThreatScrutiny
  l_1_26 = l_1_26.bHideThreatPercent
  l_1_26 = function(l_22_0, l_22_1)
    ThreatScrutiny.bHideThreatPercent = l_22_1
    if l_22_1 then
      ThreatScrutiny.bShowThreatPercent = false
      ThreatScrutiny.bShowThreatbalancePercent = false
      ThreatScrutiny.bShowThreatAnykindPercent = false
    end
  end
  l_1_35 = ThreatScrutiny
  l_1_35 = l_1_35.nMaxBarCount
  l_1_35 = l_1_35 == 0
  l_1_35 = function()
    ThreatScrutiny.nMaxBarCount = 0
  end
  l_1_38 = ThreatScrutiny
  l_1_38 = l_1_38.nMaxBarCount
  l_1_38 = l_1_38 == 1
  l_1_38 = function()
    ThreatScrutiny.nMaxBarCount = 1
  end
  local l_1_43 = {}
  l_1_43.szOption = "��"
  l_1_43.bMCheck = true
  l_1_43.bChecked = ThreatScrutiny.nMaxBarCount == 3
  l_1_43.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 3
  end
  local l_1_46 = {}
  l_1_46.szOption = "��"
  l_1_46.bMCheck = true
  l_1_46.bChecked = ThreatScrutiny.nMaxBarCount == 4
  l_1_46.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 4
  end
  local l_1_49 = {}
  l_1_49.szOption = "��"
  l_1_49.bMCheck = true
  l_1_49.bChecked = ThreatScrutiny.nMaxBarCount == 5
  l_1_49.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 5
  end
  local l_1_52 = {}
  l_1_52.szOption = "����"
  l_1_52.bMCheck = true
  l_1_52.bChecked = ThreatScrutiny.nMaxBarCount == 10
  l_1_52.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 10
  end
  local l_1_55 = {}
  l_1_55.szOption = "����"
  l_1_55.bMCheck = true
  l_1_55.bChecked = ThreatScrutiny.nMaxBarCount == 15
  l_1_55.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 15
  end
  local l_1_58 = {}
  l_1_58.szOption = "����"
  l_1_58.bMCheck = true
  l_1_58.bChecked = ThreatScrutiny.nMaxBarCount == 20
  l_1_58.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 20
  end
  local l_1_61 = {}
  l_1_61.szOption = "����"
  l_1_61.bMCheck = true
  l_1_61.bChecked = ThreatScrutiny.nMaxBarCount == 25
  l_1_61.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 25
  end
  local l_1_64 = {}
  l_1_64.szOption = "����"
  l_1_64.bMCheck = true
  l_1_64.bChecked = ThreatScrutiny.nMaxBarCount == 30
  l_1_64.fnAction = function()
    ThreatScrutiny.nMaxBarCount = 30
  end
  l_1_38, l_1_35, l_1_32 = {szOption = "��", bMCheck = true, bChecked = ThreatScrutiny.nMaxBarCount == 2, fnAction = function()
    ThreatScrutiny.nMaxBarCount = 2
  end}, {szOption = "��", bMCheck = true, bChecked = l_1_38, fnAction = l_1_38}, {szOption = "��", bMCheck = true, bChecked = l_1_35, fnAction = l_1_35}
  l_1_35 = ThreatScrutiny
  l_1_35 = l_1_35.bForceColor
  l_1_35 = function(l_34_0, l_34_1)
    ThreatScrutiny.bForceColor = l_34_1
  end
  l_1_43 = ThreatScrutiny
  l_1_43 = l_1_43.bFocusTargetLocked
  l_1_43 = function(l_35_0, l_35_1)
    local l_35_2, l_35_3 = GetClientPlayer().GetTarget()
    if l_35_1 and l_35_2 > 1 then
      ThreatScrutiny.dwFocusTargetID = l_35_3
      ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(true)
    else
      ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(false)
    end
  end
  l_1_46 = ThreatScrutiny
  l_1_46 = l_1_46.bFoucsPartyTarget
  l_1_46 = function(l_36_0, l_36_1)
    ThreatScrutiny.bFoucsPartyTarget = l_36_1
  end
  l_1_55 = ThreatScrutiny
  l_1_55 = l_1_55.szCastAlertRelation
  l_1_55 = l_1_55 == "Enemy"
  l_1_55 = function()
    ThreatScrutiny.szCastAlertRelation = "Enemy"
  end
  l_1_58 = ThreatScrutiny
  l_1_58 = l_1_58.szCastAlertRelation
  l_1_58 = l_1_58 == "Friendly"
  l_1_58 = function()
    ThreatScrutiny.szCastAlertRelation = "Friendly"
  end
  l_1_61 = ThreatScrutiny
  l_1_61 = l_1_61.szCastAlertRelation
  l_1_61 = l_1_61 == "All"
  l_1_61 = function()
    ThreatScrutiny.szCastAlertRelation = "All"
  end
  l_1_58, l_1_55, l_1_52 = {szOption = "�����ϵ������", bMCheck = true, bChecked = l_1_61, fnAction = l_1_61}, {szOption = "����Ŀ��ű���", bMCheck = true, bChecked = l_1_58, fnAction = l_1_58}, {szOption = "�ж�Ŀ��ű���", bMCheck = true, bChecked = l_1_55, fnAction = l_1_55}
  l_1_58 = ThreatScrutiny
  l_1_58 = l_1_58.szCastAlertCharType
  l_1_58 = l_1_58 == "Npc"
  l_1_58 = function()
    ThreatScrutiny.szCastAlertCharType = "Npc"
  end
  l_1_61 = ThreatScrutiny
  l_1_61 = l_1_61.szCastAlertCharType
  l_1_61 = l_1_61 == "Player"
  l_1_61 = function()
    ThreatScrutiny.szCastAlertCharType = "Player"
  end
  l_1_64 = ThreatScrutiny
  l_1_64 = l_1_64.szCastAlertCharType
  l_1_64 = l_1_64 == "All"
  l_1_64 = function()
    ThreatScrutiny.szCastAlertCharType = "All"
  end
  l_1_61, l_1_58, l_1_55 = {szOption = "�κ����Ͷ�����", bMCheck = true, bChecked = l_1_64, fnAction = l_1_64}, {szOption = "��Ҳű���", bMCheck = true, bChecked = l_1_61, fnAction = l_1_61}, {szOption = "�ΣУòű���", bMCheck = true, bChecked = l_1_58, fnAction = l_1_58}
  l_1_61 = ThreatScrutiny
  l_1_61 = l_1_61.nCastAlertIntensity
  l_1_61 = l_1_61 == 2
  l_1_61 = function()
    ThreatScrutiny.nCastAlertIntensity = 2
  end
  l_1_64 = ThreatScrutiny
  l_1_64 = l_1_64.nCastAlertIntensity
  l_1_64 = l_1_64 == 3
  l_1_64 = function()
    ThreatScrutiny.nCastAlertIntensity = 3
  end
  local l_1_69 = {}
  l_1_69.szOption = "����ǿ��(BOSS)�ű���"
  l_1_69.bMCheck = true
  l_1_69.bChecked = ThreatScrutiny.nCastAlertIntensity == 5
  l_1_69.fnAction = function()
    ThreatScrutiny.nCastAlertIntensity = 5
  end
  local l_1_72 = {}
  l_1_72.szOption = "����ǿ�ȶ�����"
  l_1_72.bMCheck = true
  l_1_72.bChecked = ThreatScrutiny.nCastAlertIntensity == 1
  l_1_72.fnAction = function()
    ThreatScrutiny.nCastAlertIntensity = 1
  end
  l_1_64, l_1_61, l_1_58 = {szOption = "ͷĿǿ�Ȳű���", bMCheck = true, bChecked = ThreatScrutiny.nCastAlertIntensity == 4, fnAction = function()
    ThreatScrutiny.nCastAlertIntensity = 4
  end}, {szOption = "����ǿ�Ȳű���", bMCheck = true, bChecked = l_1_64, fnAction = l_1_64}, {szOption = "��ͨǿ�Ȳű���", bMCheck = true, bChecked = l_1_61, fnAction = l_1_61}
  l_1_64 = ThreatScrutiny
  l_1_64 = l_1_64.nCastAlertChannel
  l_1_64 = l_1_64 == -1
  l_1_64 = function()
    ThreatScrutiny.nCastAlertChannel = -1
  end
  l_1_69 = ThreatScrutiny
  l_1_69 = l_1_69.nCastAlertChannel
  l_1_72 = PLAYER_TALK_CHANNEL
  l_1_72 = l_1_72.NEARBY
  l_1_69 = l_1_69 == l_1_72
  l_1_69 = function()
    ThreatScrutiny.nCastAlertChannel = PLAYER_TALK_CHANNEL.NEARBY
  end
  l_1_72 = ThreatScrutiny
  l_1_72 = l_1_72.nCastAlertChannel
  l_1_72 = l_1_72 == PLAYER_TALK_CHANNEL.TEAM
  l_1_72 = function()
    ThreatScrutiny.nCastAlertChannel = PLAYER_TALK_CHANNEL.TEAM
  end
  l_1_72, l_1_69, l_1_64, l_1_61 = {szOption = "�Ŷ�Ƶ��", bMCheck = true, bChecked = ThreatScrutiny.nCastAlertChannel == PLAYER_TALK_CHANNEL.RAID, fnAction = function()
    ThreatScrutiny.nCastAlertChannel = PLAYER_TALK_CHANNEL.RAID
  end}, {szOption = "С��Ƶ��", bMCheck = true, bChecked = l_1_72, fnAction = l_1_72}, {szOption = "����Ƶ��", bMCheck = true, bChecked = l_1_69, fnAction = l_1_69}, {szOption = "������", bMCheck = true, bChecked = l_1_64, fnAction = l_1_64}
  l_1_72 = ThreatScrutiny
  l_1_72 = l_1_72.nOTAlertLevel
  l_1_72 = l_1_72 == 0.7
  l_1_72 = function()
    ThreatScrutiny.nOTAlertLevel = 0.7
  end
  local l_1_79 = {}
  l_1_79.szOption = "���������ʾ"
  l_1_79.bMCheck = true
  l_1_79.bChecked = ThreatScrutiny.nOTAlertLevel == 0.9
  l_1_79.fnAction = function()
    ThreatScrutiny.nOTAlertLevel = 0.9
  end
  local l_1_82 = {}
  l_1_82.szOption = "�����������ʾ"
  l_1_82.bMCheck = true
  l_1_82.bChecked = ThreatScrutiny.nOTAlertLevel == 1
  l_1_82.fnAction = function()
    ThreatScrutiny.nOTAlertLevel = 1
  end
  local l_1_85 = {}
  l_1_85.szOption = "�����������ʾ"
  l_1_85.bMCheck = true
  l_1_85.bChecked = ThreatScrutiny.nOTAlertLevel == 1.1
  l_1_85.fnAction = function()
    ThreatScrutiny.nOTAlertLevel = 1.1
  end
  local l_1_88 = {}
  l_1_88.szOption = "�����������ʾ"
  l_1_88.bMCheck = true
  l_1_88.bChecked = ThreatScrutiny.nOTAlertLevel == 1.2
  l_1_88.fnAction = function()
    ThreatScrutiny.nOTAlertLevel = 1.2
  end
  local l_1_91 = {}
  l_1_91.szOption = "������ʾ"
  l_1_91.bMCheck = true
  l_1_91.bChecked = ThreatScrutiny.nOTAlertLevel == -1
  l_1_91.fnAction = function()
    ThreatScrutiny.nOTAlertLevel = -1
  end
  l_1_72, l_1_69 = {szOption = "���������ʾ", bMCheck = true, bChecked = ThreatScrutiny.nOTAlertLevel == 0.8, fnAction = function()
    ThreatScrutiny.nOTAlertLevel = 0.8
  end}, {szOption = "���������ʾ", bMCheck = true, bChecked = l_1_72, fnAction = l_1_72}
  l_1_72 = ThreatScrutiny
  l_1_72 = l_1_72.bOTAlertSound
  l_1_72 = function(l_59_0, l_59_1)
    ThreatScrutiny.bOTAlertSound = l_59_1
  end
  l_1_72 = function(l_60_0, l_60_1)
  end
  l_1_1.fnAction = l_1_72
  l_1_72 = function(l_61_0, l_61_1, l_61_2, l_61_3)
  end
  l_1_1.fnChangeColor = l_1_72
  l_1_72 = function()
  end
  l_1_1.fnCancelAction = l_1_72
  l_1_72 = function()
    return false
  end
  l_1_1.fnAutoClose = l_1_72
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

  l_1_0.tOptions = l_1_1
  l_1_0 = Cursor
  l_1_0 = l_1_0.GetPos
  l_1_1 = true
  l_1_0 = l_1_0(l_1_1)
  l_1_2 = ThreatScrutiny
  l_1_2 = l_1_2.tOptions
  l_1_3 = ThreatScrutiny
  l_1_3 = l_1_3.tOptions
  l_1_4 = l_1_0 - 215
  l_1_5 = l_1_1 + 15
  l_1_3.y = l_1_5
  l_1_2.x = l_1_4
  l_1_2 = PopupMenu
  l_1_3 = ThreatScrutiny
  l_1_3 = l_1_3.tOptions
  l_1_2(l_1_3)
end

ThreatScrutiny.SetBGAlpha = function()
  ThreatScrutiny.handleImages:Lookup("Image_Background"):SetAlpha(ThreatScrutiny.nBGAlpha * 2.55)
end


