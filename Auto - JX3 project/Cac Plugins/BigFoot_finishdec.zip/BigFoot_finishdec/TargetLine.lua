-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: TargetLine.lua 

if not TargetLine then
  TargetLine = {}
end
TargetLine.nLineAlpha = 80
TargetLine.nStartWidth = 2
TargetLine.nEndWidth = 0
TargetLine.btargetline = true
TargetLine.bPoint = true
TargetLine.bttargetline = true
TargetLine.OnFrameCreate = function()
  local l_1_0 = Station.Lookup("Lowest/TargetLine")
  local l_1_1 = l_1_0:Lookup("", "")
  l_1_1:Lookup("Animate_Selection_Green"):Hide()
  l_1_1:Lookup("Animate_Selection_Yellow"):Hide()
  l_1_1:Lookup("Animate_Selection_Red"):Hide()
  local l_1_2 = l_1_1:Lookup("Shadow_Info")
  l_1_1:RemoveItem(l_1_2:GetIndex())
  local l_1_3 = l_1_1:AppendItemFromIni("Interface/BF_TargetEx/TargetLine.ini", "Shadow_Info", "Shadow_Target")
  local l_1_4 = l_1_1:AppendItemFromIni("Interface/BF_TargetEx/TargetLine.ini", "Shadow_Info", "Shadow_TTarget")
  l_1_3:Hide()
  l_1_3:SetTriangleFan(true)
  l_1_4:Hide()
  l_1_4:SetTriangleFan(true)
  l_1_1:FormatAllItemPos()
  l_1_0:RegisterEvent("RENDER_FRAME_UPDATE")
end

TargetLine.PointHide = function()
  local l_2_0 = Station.Lookup("Lowest/TargetLine")
  local l_2_1 = l_2_0:Lookup("", "")
  l_2_1:Lookup("Animate_Selection_Green"):Hide()
  l_2_1:Lookup("Animate_Selection_Yellow"):Hide()
  l_2_1:Lookup("Animate_Selection_Red"):Hide()
end

TargetLine.LineHide = function(l_3_0)
  local l_3_1 = Station.Lookup("Lowest/TargetLine")
  local l_3_2 = (l_3_1:Lookup("", ""))
  local l_3_3 = nil
  if l_3_0 == "target" then
    l_3_3 = l_3_2:Lookup("Shadow_Target")
  elseif l_3_0 == "ttarget" then
    l_3_3 = l_3_2:Lookup("Shadow_TTarget")
  end
  l_3_3:Hide()
end

TargetLine.OnEvent = function(l_4_0)
  if l_4_0 == "RENDER_FRAME_UPDATE" then
    TargetLine.update_line()
  end
end

TargetLine.AdjustAniPos = function(l_5_0)
  local l_5_1, l_5_2, l_5_3 = Scene_GetCharacterTop(l_5_0.id)
  local l_5_4, l_5_5, l_5_6 = Scene_ScenePointToScreenPoint(l_5_1, l_5_2, l_5_3)
  if l_5_6 then
    l_5_4 = Station.AdjustToOriginalPos(l_5_4, l_5_5)
    local l_5_7, l_5_8 = l_5_0:GetSize()
    local l_5_9 = math.ceil(l_5_4 - l_5_7 / 2)
    local l_5_10 = math.floor(l_5_5 - l_5_8 / 2) - 3
    l_5_0:SetAbsPos(l_5_9, l_5_10)
    l_5_0:Show()
  else
    l_5_0:SetAbsPos(-4096, -4096)
    l_5_0:Hide()
  end
end

TargetLine.update_line = function()
  local l_6_0 = GetClientPlayer()
  if not l_6_0 then
    return 
  end
  local l_6_1 = GetTargetHandle(l_6_0.GetTarget())
  local l_6_2 = Station.Lookup("Lowest/TargetLine")
  local l_6_3 = l_6_2:Lookup("", "")
  local l_6_4 = l_6_3:Lookup("Animate_Selection_Red")
  local l_6_5 = l_6_3:Lookup("Animate_Selection_Green")
  local l_6_6 = l_6_3:Lookup("Animate_Selection_Yellow")
  local l_6_7 = l_6_3:Lookup("Shadow_Target")
  local l_6_8 = l_6_3:Lookup("Shadow_TTarget")
  if l_6_1 then
    local l_6_9, l_6_10, l_6_11 = GetHeadTextForceFontColor(l_6_1.dwID, l_6_0.dwID)
    local l_6_12 = "green"
    if l_6_9 >= 255 and l_6_10 >= 255 and l_6_11 == 0 then
      l_6_12 = "yellow"
    elseif l_6_9 >= 255 and l_6_10 == 0 and l_6_11 == 0 then
      l_6_12 = "red"
    end
    local l_6_13 = {}
    local l_6_14 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_6_15 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    local l_6_16 = {}
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if l_6_14 then
      for i_1,i_2 in l_6_15 do
        if l_6_12 ~= l_6_19[1] then
          l_6_19[2]:Hide()
         -- DECOMPILER ERROR: Overwrote pending register.

      else
        end
         -- DECOMPILER ERROR: Overwrote pending register.

         -- DECOMPILER ERROR: Overwrote pending register.

        if l_6_14 then
          TargetLine.AdjustAniPos(l_6_16)
        end
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_6_14(l_6_4)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_6_14(l_6_5)
         -- DECOMPILER ERROR: Overwrote pending register.

        l_6_14(l_6_6)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_6_14 ~= l_6_1.dwID and l_6_14 then
        l_6_14(l_6_7, l_6_0.dwID, l_6_1.dwID)
       -- DECOMPILER ERROR: Overwrote pending register.

      else
        l_6_14(l_6_7)
      end
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      if l_6_14 and TargetLine.bttargetline then
        TargetLine.UpdateLine(l_6_8, l_6_1.dwID, l_6_14.dwID)
      else
        l_6_8:Hide()
         -- DECOMPILER ERROR: Confused about usage of registers for local variables.

      end
    else
      l_6_9, l_6_10 = l_6_4:Hide, l_6_4
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_5:Hide, l_6_5
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_6:Hide, l_6_6
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_7:Hide, l_6_7
      l_6_9(l_6_10)
      l_6_9, l_6_10 = l_6_8:Hide, l_6_8
      l_6_9(l_6_10)
       -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 86 
end

TargetLine.GetRole = function(l_7_0)
  if IsPlayer(l_7_0) then
    local l_7_1 = GetPlayer
    local l_7_2 = l_7_0
    return l_7_1(l_7_2)
  else
    local l_7_3 = GetNpc
    local l_7_4 = l_7_0
    return l_7_3(l_7_4)
  end
end

TargetLine.GetScreenPoint = function(l_8_0)
  local l_8_1, l_8_2, l_8_3 = Scene_GetCharacterTop(l_8_0)
  local l_8_4 = 0
  local l_8_5 = 0
  local l_8_6 = false
  if l_8_1 and l_8_2 and l_8_3 then
    l_8_4 = Scene_ScenePointToScreenPoint(l_8_1, l_8_2, l_8_3)
  end
  return l_8_4, l_8_5, l_8_6
end

TargetLine.GetCharacterColor = function(l_9_0)
  local l_9_1 = GetClientPlayer()
  if not l_9_1 then
    return 128, 128, 128
  end
  if not IsPlayer(l_9_0) then
    return 168, 168, 168
  end
  local l_9_2 = TargetLine.GetRole(l_9_0)
  if not l_9_2 then
    return 128, 128, 128
  end
  local l_9_3 = l_9_2.dwForceID
  if not l_9_3 then
    return 168, 168, 168
  end
  local l_9_4 = {}
  local l_9_5 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_9_4["���"], l_9_5 = l_9_5, {255, 255, 255}
  l_9_4["��"], l_9_5 = l_9_5, {196, 152, 255}
  l_9_4["����"], l_9_5 = l_9_5, {89, 224, 232}
  l_9_4["����"], l_9_5 = l_9_5, {255, 129, 176}
  l_9_4["����"], l_9_5 = l_9_5, {255, 178, 95}
  l_9_4["�ؽ�"], l_9_5 = l_9_5, {214, 249, 93}
  l_9_4["�嶾"], l_9_5 = l_9_5, {55, 147, 255}
  l_9_4["����"], l_9_5 = l_9_5, {121, 183, 54}
  l_9_5 = GetForceTitle
  l_9_5 = l_9_5(l_9_3)
  if l_9_4[l_9_5] then
    return l_9_4[l_9_5][1], l_9_4[l_9_5][2], l_9_4[l_9_5][3]
  end
  return 168, 168, 168
end

TargetLine.UpdateLine = function(l_10_0, l_10_1, l_10_2)
  if not l_10_1 or not l_10_2 or l_10_1 == 0 or l_10_2 == 0 then
    return 
  end
  local l_10_3 = TargetLine.GetRole(l_10_1)
  local l_10_4 = TargetLine.GetRole(l_10_2)
  if not l_10_3 or not l_10_4 or not l_10_3.nX or not l_10_4.nX then
    return 
  end
  local l_10_5, l_10_6, l_10_7 = TargetLine.GetCharacterColor(l_10_1)
  local l_10_8, l_10_9, l_10_10 = TargetLine.GetCharacterColor(l_10_2)
  local l_10_11, l_10_12, l_10_13 = TargetLine.GetScreenPoint(l_10_1)
  local l_10_14, l_10_15, l_10_16 = TargetLine.GetScreenPoint(l_10_2)
  if not l_10_13 or not l_10_16 then
    l_10_0:Hide()
    return 
  end
  l_10_11 = Station.AdjustToOriginalPos(l_10_11, l_10_12)
  l_10_14 = Station.AdjustToOriginalPos(l_10_14, l_10_15)
  local l_10_17 = TargetLine.nStartWidth
  local l_10_18 = TargetLine.nEndWidth
  local l_10_19 = l_10_14 - l_10_11
  local l_10_20 = l_10_15 - l_10_12
  local l_10_21 = 0
  local l_10_22 = 0
  local l_10_23 = 0
  local l_10_24 = 0
  local l_10_25 = 0
  local l_10_26 = 0
  local l_10_27 = 0
  local l_10_28 = 0
  if (l_10_19 >= 0 and l_10_20 >= 0) or l_10_19 < 0 and l_10_20 < 0 then
    l_10_21 = l_10_11 + l_10_17
    l_10_23 = l_10_11 - l_10_17
    l_10_25 = l_10_14 + l_10_18
    l_10_27 = l_10_14 - l_10_18
   -- DECOMPILER ERROR: Overwrote pending register.

  else
    l_10_21 = l_10_11 - l_10_17
     -- DECOMPILER ERROR: Overwrote pending register.

    l_10_23 = l_10_11 + l_10_17
     -- DECOMPILER ERROR: Overwrote pending register.

    l_10_25 = l_10_14 - l_10_18
     -- DECOMPILER ERROR: Overwrote pending register.

    l_10_27 = l_10_14 + l_10_18
  end
  if not l_10_0:IsVisible() then
    l_10_0:Show()
  end
  l_10_0:ClearTriangleFanPoint()
  local l_10_29 = 0
  local l_10_30 = TargetLine.nLineAlpha
  l_10_0:AppendTriangleFanPoint(l_10_21, l_10_22 - l_10_29, l_10_5, l_10_6, l_10_7, l_10_30 * 2.55)
  l_10_0:AppendTriangleFanPoint(l_10_23, l_10_24 - l_10_29, l_10_5, l_10_6, l_10_7, l_10_30 * 2.55)
  l_10_0:AppendTriangleFanPoint(l_10_25, l_10_26 - l_10_29, l_10_8, l_10_9, l_10_10, l_10_30 * 2.55)
  l_10_0:AppendTriangleFanPoint(l_10_27, l_10_28 - l_10_29, l_10_8, l_10_9, l_10_10, l_10_30 * 2.55)
end

Wnd.OpenWindow("Interface\\BF_TargetEx\\TargetLine.ini", "TargetLine")

