-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_ZhenPaiSkill.lua 

if not BF_ZhenPaiSkill then
  BF_ZhenPaiSkill = {}
end
BF_ZhenPaiSkill.tSkillData = {}
BF_ZhenPaiSkill.bEnabled = true
local l_0_0 = 24
local l_0_1 = 4
local l_0_2 = 6
RegisterCustomData("BF_ZhenPaiSkill.tSkillData")
BF_ZhenPaiSkill.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a = BFFrame.new(0, 0, "NONE")
BF_ZhenPaiSkill.Init = ZhenPaiSkill.Init
ZhenPaiSkill.Init = function(l_1_0)
  BF_ZhenPaiSkill.Init(l_1_0)
  local l_1_1 = GetClientPlayer()
  if BF_ZhenPaiSkill.bEnabled and ZhenPaiSkill.dwForceID == l_1_1.dwForceID then
    BF_ZhenPaiSkill.CreatButton()
  end
end

BF_ZhenPaiSkill.CreatButton = function()
  local l_2_0 = Station.Lookup("Normal/ZhenPaiSkill")
  if not l_2_0 then
    return true
  end
  local l_2_1 = "ui\\Image\\uicommon\\commonpanel.UITex"
  local l_2_2, l_2_3 = l_2_0:GetAbsPos()
  BF_ZhenPaiSkill.ButtonSave = BFButton.new(l_2_0, 91, 26, "����")
  BF_ZhenPaiSkill.ButtonSave:SetStyle("TRANSPARENT")
  BF_ZhenPaiSkill.ButtonSave:SetNormalImage(l_2_1, 38)
  BF_ZhenPaiSkill.ButtonSave:SetHotImage(l_2_1, 39)
  BF_ZhenPaiSkill.ButtonSave:SetPressedImage(l_2_1, 40)
  BF_ZhenPaiSkill.ButtonSave:SetDisabledImage(l_2_1, 41)
  BF_ZhenPaiSkill.ButtonSave:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_2_2 + 229, l_2_3 + 478)
  BF_ZhenPaiSkill.ButtonSave.OnClick = function(l_3_0)
    GetUserInput("�����Զ��巽������", function(l_4_0)
      BF_ZhenPaiSkill.Save(l_4_0)
    end, nil, nil, nil, nil)
  end
  BF_ZhenPaiSkill.ButtonLoad = BFButton.new(l_2_0, 91, 26, "����")
  BF_ZhenPaiSkill.ButtonLoad:SetStyle("TRANSPARENT")
  BF_ZhenPaiSkill.ButtonLoad:SetNormalImage(l_2_1, 38)
  BF_ZhenPaiSkill.ButtonLoad:SetHotImage(l_2_1, 39)
  BF_ZhenPaiSkill.ButtonLoad:SetPressedImage(l_2_1, 40)
  BF_ZhenPaiSkill.ButtonLoad:SetDisabledImage(l_2_1, 41)
  BF_ZhenPaiSkill.ButtonLoad:SetPoint("TOPLEFT", BFScreen, "TOPLEFT", l_2_2 + 335, l_2_3 + 478)
  BF_ZhenPaiSkill.ButtonLoad.OnClick = function(l_4_0)
    if IsTableEmpty(BF_ZhenPaiSkill.tSkillData) then
      BigFoot_Print("��������", "û���ҵ����ɼ��ܷ���")
      return 
    end
    local l_4_1 = {}
    for l_4_5,l_4_6 in pairs(BF_ZhenPaiSkill.tSkillData) do
      do
        local l_4_7 = {}
        l_4_7.szOption = l_4_5
        local l_4_8 = {}
        l_4_8.szOption = "����"
        l_4_8.fnAction = function()
          -- upvalues: l_2_5
          BF_ZhenPaiSkill.LoadTalentData(l_2_5)
        end
        local l_4_9 = {}
        l_4_9.szOption = "ɾ��"
        l_4_9.fnAction = function()
          -- upvalues: l_2_5
          local l_6_0 = {}
          l_6_0.szMessage = "��ȷ��Ҫɾ��\"" .. l_2_5 .. "\"�����ļ�ô��"
          l_6_0.szName = "DeleteWarning"
          local l_6_1 = {}
          l_6_1.szOption = g_tStrings.STR_HOTKEY_SURE
          l_6_1.fnAction = function()
            -- upvalues: l_2_5
            BF_ZhenPaiSkill.tSkillData[l_2_5] = nil
            BigFoot_Print("��������", "���ɼ��ܷ��� [" .. l_2_5 .. "]ɾ���ɹ�")
          end
          local l_6_2 = {}
          l_6_2.szOption = g_tStrings.STR_HOTKEY_CANCEL
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_6_1 = MessageBox
          l_6_2 = l_6_0
          l_6_1(l_6_2)
        end
         -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

        l_4_8 = table
        l_4_8 = l_4_8.insert
        l_4_9 = l_4_1
        l_4_8(l_4_9, l_4_7)
      end
    end
    PopupMenu(l_4_1)
  end
end

BF_ZhenPaiSkill.SaveTalentData = function(l_3_0)
  -- upvalues: l_0_0
  local l_3_1 = Station.Lookup("Normal/ZhenPaiSkill")
  if not l_3_1 then
    return 
  end
  local l_3_2 = l_3_1:Lookup("PageSet_Total")
  local l_3_3 = l_3_2:Lookup("Page_ZhenPai")
  local l_3_4 = l_3_3:Lookup("Wnd_LeftSkill")
  local l_3_5 = l_3_3:Lookup("Wnd_RightSkill")
  if not BF_ZhenPaiSkill.tSkillData[l_3_0] then
    local l_3_6 = BF_ZhenPaiSkill.tSkillData
    local l_3_7 = {}
    l_3_7.LeftSkill = {}
    l_3_7.RightSkill = {}
    l_3_7.LeftTotal = 0
    l_3_7.RightTotal = 0
    l_3_6[l_3_0] = l_3_7
  end
  for l_3_11 = 1, l_0_0 do
    local l_3_12 = l_3_4:Lookup("", ""):Lookup(l_3_11 - 1)
    local l_3_13 = l_3_12:Lookup("Text_Left")
    local l_3_14 = tonumber(l_3_13:GetText())
    local l_3_15 = BF_ZhenPaiSkill.tSkillData[l_3_0].LeftSkill
    local l_3_16 = {}
    l_3_16.dwLevel = l_3_14
    l_3_15[l_3_11] = l_3_16
  end
  local l_3_17 = l_3_1:Lookup("", "Handle_All1"):Lookup("Text_UsePoint"):GetText()
  BF_ZhenPaiSkill.tSkillData[l_3_0].LeftTotal = tonumber(l_3_17)
  for l_3_21 = 1, l_0_0 do
    local l_3_22 = l_3_5:Lookup("", ""):Lookup(l_3_21 - 1)
    local l_3_23 = l_3_22:Lookup("Text_Right")
    local l_3_24 = tonumber(l_3_23:GetText())
    local l_3_25 = BF_ZhenPaiSkill.tSkillData[l_3_0].RightSkill
    local l_3_26 = {}
    l_3_26.dwLevel = l_3_24
    l_3_25[l_3_21] = l_3_26
  end
  local l_3_27 = l_3_1:Lookup("", "Handle_All2"):Lookup("Text_UsePoint1"):GetText()
  BF_ZhenPaiSkill.tSkillData[l_3_0].RightTotal = tonumber(l_3_27)
end

BF_ZhenPaiSkill.LoadTalentData = function(l_4_0)
  local l_4_1 = Station.Lookup("Normal/ZhenPaiSkill")
  if not l_4_1 then
    return 
  end
  local l_4_2 = l_4_1:Lookup("PageSet_Total")
  local l_4_3 = l_4_2:Lookup("Page_ZhenPai")
  local l_4_4 = l_4_3:Lookup("Wnd_LeftSkill")
  local l_4_5 = l_4_3:Lookup("Wnd_RightSkill")
  if BF_ZhenPaiSkill.tSkillData[l_4_0].RightTotal < BF_ZhenPaiSkill.tSkillData[l_4_0].LeftTotal then
    BF_ZhenPaiSkill.ClickItem("Left", l_4_0)
    BF_ZhenPaiSkill.ClickItem("Right", l_4_0)
  else
    BF_ZhenPaiSkill.ClickItem("Right", l_4_0)
    BF_ZhenPaiSkill.ClickItem("Left", l_4_0)
  end
  BigFoot_Print("��������", "���ɼ��ܷ��� [" .. l_4_0 .. "]���سɹ������ѧϰ��ťѧϰ")
end

BF_ZhenPaiSkill.ClickItem = function(l_5_0, l_5_1)
  -- upvalues: l_0_0
  local l_5_2 = Station.Lookup("Normal/ZhenPaiSkill")
  if not l_5_2 then
    return 
  end
  local l_5_3 = l_5_2:Lookup("PageSet_Total")
  local l_5_4 = l_5_3:Lookup("Page_ZhenPai")
  local l_5_5 = l_5_4:Lookup("Wnd_" .. l_5_0 .. "Skill")
  for l_5_9 = 1, l_0_0 do
    local l_5_10 = BF_ZhenPaiSkill.tSkillData[l_5_1][l_5_0 .. "Skill"][l_5_9]
    if not IsTableEmpty(l_5_10) and l_5_10.dwLevel then
      local l_5_11 = l_5_5:Lookup("", ""):Lookup(l_5_9 - 1)
      local l_5_12 = l_5_11:Lookup("Box_" .. l_5_0)
      local l_5_13 = l_5_10.dwLevel
      for l_5_17 = 1, l_5_13 do
        local l_5_18 = this
        this = l_5_12
        ZhenPaiSkill.OnItemLButtonClick()
        this = l_5_18
      end
    end
  end
end

BF_ZhenPaiSkill.Save = function(l_6_0)
  local l_6_1 = Station.Lookup("Normal/ZhenPaiSkill")
  if not l_6_1 then
    return 
  end
  local l_6_2 = l_6_1:Lookup("", "Handle_All1"):Lookup("Text_UsePoint"):GetText()
  local l_6_3 = l_6_1:Lookup("", "Handle_All2"):Lookup("Text_UsePoint1"):GetText()
  local l_6_4 = ""
  if tonumber(l_6_3) < tonumber(l_6_2) then
    l_6_4 = l_6_0 .. " (" .. l_6_2 .. "/" .. l_6_3 .. ")"
  else
    l_6_4 = l_6_0 .. " (" .. l_6_2 .. "/" .. l_6_3 .. ")"
  end
  BF_ZhenPaiSkill.SaveTalentData(l_6_4)
  BigFoot_Print("��������", "���ɼ��ܷ��� [" .. l_6_4 .. "]����ɹ�")
end

BFConfigPanel.RegisterMod("xZhenPaiSkill", "���ɾ���", "\\ui\\image\\icon\\skill_venation04.tga", "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
BFConfigPanel.RegisterCheckButton("xZhenPaiSkill", "EnablexZhenPaiSkill", "�������ɾ�������", true, function(l_7_0)
  BF_ZhenPaiSkill.bEnabled = l_7_0
end
)

