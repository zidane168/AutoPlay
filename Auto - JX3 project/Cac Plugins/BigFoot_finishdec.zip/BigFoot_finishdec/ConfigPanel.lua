-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ConfigPanel.lua 

local l_0_0 = {}
l_0_0.MinibuttonPos = math.pi * math.pi * -0.958
BFConfigPanel = l_0_0
BFMods, l_0_0 = l_0_0, {}
BigFoot_ModOptions, l_0_0 = l_0_0, {}
l_0_0 = BFConfigPanel
l_0_0.MAX_COUNT_PER_PAGE = 14
l_0_0 = RegisterCustomData
l_0_0("BigFoot_ModOptions")
l_0_0 = RegisterCustomData
l_0_0("BFConfigPanel.MinibuttonPos")
l_0_0 = function(l_1_0, l_1_1)
  if BigFoot_ModOptions[l_1_0] and BigFoot_ModOptions[l_1_0][l_1_1] ~= nil then
    return BigFoot_ModOptions[l_1_0][l_1_1]
  end
  if BFMods[l_1_0] then
    local l_1_2, l_1_3 = nil, nil
    for l_1_7,l_1_8 in ipairs(BFMods[l_1_0]) do
      if l_1_8.tag == l_1_1 then
        return l_1_8.default
      end
    end
  end
end

BFGetModValue = l_0_0
l_0_0 = function(l_2_0, l_2_1, l_2_2)
  if not BigFoot_ModOptions[l_2_0] then
    BigFoot_ModOptions[l_2_0] = {}
  end
  BigFoot_ModOptions[l_2_0][l_2_1] = l_2_2
end

BFSetModValue = l_0_0
l_0_0 = BFConfigPanel
l_0_0.Create = function()
  local l_3_0 = BFFrame.new(850, 530, "PANEL", 50)
  l_3_0:SetPoint("CENTER", BFScreen, "CENTER", 0, 0)
  l_3_0:SetFrameLevel("Topmost")
  l_3_0:SetTitle("�������")
  local l_3_1 = BFButton.new(l_3_0, 750, 30)
  l_3_1:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 0, 0)
  l_3_1:SetStyle("TRANSPARENT")
  local l_3_2 = l_3_1.BigFoot_411b8aa6d5954c6020f0b9c9e80e847a
  l_3_1.OnMouseDown = function()
    -- upvalues: l_3_0
    l_3_0:StartMoving()
  end
  l_3_1.OnMouseUp = function()
    -- upvalues: l_3_0
    l_3_0:EndMoving()
  end
  local l_3_3 = nil
  local l_3_4 = {}
  l_3_4.OnClick = function(l_6_0, l_6_1, l_6_2)
    local l_6_3 = l_6_1.root.mod
    if BFConfigPanel.last_button then
      BFConfigPanel.last_button:SetStatus("NORMAL")
    end
    BFConfigPanel.last_button = l_6_1.root
    l_6_1.root:SetStatus("HIGHLIGHT")
    BFConfigPanel.ShowModPage(l_6_1.root.mod)
  end
  local l_3_5 = BFWindow.new(l_3_0, 315, 440)
  l_3_5:SetBorder("THIN")
  l_3_5:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 15, 60)
  local l_3_6 = BFWindow.new(l_3_0, 440, 440)
  l_3_6:SetBorder("THIN")
  l_3_6:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 340, 60)
  BFConfigPanel.modButtons = {}
  local l_3_7 = 27
  local l_3_8 = 70
  for l_3_12 = 1, BFConfigPanel.MAX_COUNT_PER_PAGE do
    BFConfigPanel.modButtons[l_3_12] = BFModButton.new(l_3_0)
    BFConfigPanel.modButtons[l_3_12]:SetTitle("ģ��")
    BFConfigPanel.modButtons[l_3_12].label:SetHAlign("LEFT")
    BFConfigPanel.modButtons[l_3_12]:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", l_3_7, l_3_8)
    BFConfigPanel.modButtons[l_3_12].button:AddListener(l_3_4)
    l_3_7 = l_3_7 + 150
    if l_3_7 > 177 then
      l_3_7 = 27
      l_3_8 = l_3_8 + 55
    end
  end
  BFConfigPanel.prevButton = BFButton.new(l_3_0, 28, 28)
  BFConfigPanel.prevButton.OnClick = function(l_7_0, l_7_1, l_7_2)
    BFConfigPanel.page = BFConfigPanel.page - 1
    BFConfigPanel.ShowMods()
  end
  BFConfigPanel.prevButton:SetStyle("TRANSPARENT")
  BFConfigPanel.prevButton:SetNormalImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 6)
  BFConfigPanel.prevButton:SetHotImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 5)
  BFConfigPanel.prevButton:SetPressedImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 7)
  BFConfigPanel.prevButton:SetDisabledImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 4)
  BFConfigPanel.prevButton:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 24, 460)
  BFConfigPanel.prevLabel = BFLabel.new(l_3_0, 50, 24)
  BFConfigPanel.prevLabel:SetHAlign("LEFT")
  BFConfigPanel.prevLabel:SetText("��һҳ")
  BFConfigPanel.prevLabel:SetPoint("TOPLEFT", BFConfigPanel.prevButton, "TOPRIGHT", 10, 0)
  BFConfigPanel.nextButton = BFButton.new(l_3_0, 28, 28)
  BFConfigPanel.nextButton.OnClick = function(l_8_0, l_8_1, l_8_2)
    BFConfigPanel.page = BFConfigPanel.page + 1
    BFConfigPanel.ShowMods()
  end
  BFConfigPanel.nextButton:SetStyle("TRANSPARENT")
  BFConfigPanel.nextButton:SetNormalImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 2)
  BFConfigPanel.nextButton:SetHotImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 1)
  BFConfigPanel.nextButton:SetPressedImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 3)
  BFConfigPanel.nextButton:SetDisabledImage("Interface\\BF_Base\\artwork\\pagebuttons.UITex", 0)
  BFConfigPanel.nextButton:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 288, 460)
  BFConfigPanel.nextLabel = BFLabel.new(l_3_0, 50, 24)
  BFConfigPanel.nextLabel:SetHAlign("RIGHT")
  BFConfigPanel.nextLabel:SetText("��һҳ")
  BFConfigPanel.nextLabel:SetPoint("TOPRIGHT", BFConfigPanel.nextButton, "TOPLEFT", -4, 0)
  BFConfigPanel.pageTitle = BFLabel.new(l_3_0, 48, 24)
  BFConfigPanel.pageTitle:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 147, 460)
  BFConfigPanel.frame = l_3_0
  BFConfigPanel.page = 1
  BFConfigPanel.sortButton = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton.OnClick = function(l_9_0, l_9_1, l_9_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowMods()
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 1)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton.OnMouseEnter = function(l_10_0, l_10_1, l_10_2)
    local l_10_3, l_10_4 = Cursor.GetPos()
    local l_10_5 = OutputTip
    local l_10_6 = "<text>text=\"���й���\"</text>"
    local l_10_7 = 200
    do
      local l_10_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_10_5(l_10_6, l_10_7, l_10_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton.OnMouseLeave = function(l_11_0, l_11_1, l_11_2)
    HideTip()
  end
  BFConfigPanel.sortButton:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 1)
  BFConfigPanel.sortButton:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 1)
  BFConfigPanel.sortButton:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 2)
  BFConfigPanel.sortButton:SetDisabledImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 1)
  BFConfigPanel.sortButton:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 73)
  BFConfigPanel.sortButton1 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton1.OnClick = function(l_12_0, l_12_1, l_12_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_24b10f70baf6f2b2677ce68025899b86")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 4)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton1.OnMouseEnter = function(l_13_0, l_13_1, l_13_2)
    local l_13_3, l_13_4 = Cursor.GetPos()
    local l_13_5 = OutputTip
    local l_13_6 = "<text>text=\"ս����ǿ\"</text>"
    local l_13_7 = 200
    do
      local l_13_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_13_5(l_13_6, l_13_7, l_13_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton1.OnMouseLeave = function(l_14_0, l_14_1, l_14_2)
    HideTip()
  end
  BFConfigPanel.sortButton1:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
  BFConfigPanel.sortButton1:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 4)
  BFConfigPanel.sortButton1:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 5)
  BFConfigPanel.sortButton1:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 126)
  BFConfigPanel.sortButton2 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton2.OnClick = function(l_15_0, l_15_1, l_15_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_7a0f6e31f67a4d080d11408e38d3bdbf")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 7)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton2.OnMouseEnter = function(l_16_0, l_16_1, l_16_2)
    local l_16_3, l_16_4 = Cursor.GetPos()
    local l_16_5 = OutputTip
    local l_16_6 = "<text>text=\"������ǿ\"</text>"
    local l_16_7 = 200
    do
      local l_16_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_16_5(l_16_6, l_16_7, l_16_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton2.OnMouseLeave = function(l_17_0, l_17_1, l_17_2)
    HideTip()
  end
  BFConfigPanel.sortButton2:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
  BFConfigPanel.sortButton2:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 7)
  BFConfigPanel.sortButton2:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 8)
  BFConfigPanel.sortButton2:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 179)
  BFConfigPanel.sortButton3 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton3.OnClick = function(l_18_0, l_18_1, l_18_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_b6b85020006c3110eba073d7eb8da75f")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 10)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton3.OnMouseEnter = function(l_19_0, l_19_1, l_19_2)
    local l_19_3, l_19_4 = Cursor.GetPos()
    local l_19_5 = OutputTip
    local l_19_6 = "<text>text=\"����Ŷ�\"</text>"
    local l_19_7 = 200
    do
      local l_19_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_19_5(l_19_6, l_19_7, l_19_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton3.OnMouseLeave = function(l_20_0, l_20_1, l_20_2)
    HideTip()
  end
  BFConfigPanel.sortButton3:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
  BFConfigPanel.sortButton3:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 10)
  BFConfigPanel.sortButton3:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 11)
  BFConfigPanel.sortButton3:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 232)
  BFConfigPanel.sortButton4 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton4.OnClick = function(l_21_0, l_21_1, l_21_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_068afb0a26bcdc61cf1756b35dc6cf4e")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 13)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton4.OnMouseEnter = function(l_22_0, l_22_1, l_22_2)
    local l_22_3, l_22_4 = Cursor.GetPos()
    local l_22_5 = OutputTip
    local l_22_6 = "<text>text=\"��ҵ��Ʒ\"</text>"
    local l_22_7 = 200
    do
      local l_22_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_22_5(l_22_6, l_22_7, l_22_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton4.OnMouseLeave = function(l_23_0, l_23_1, l_23_2)
    HideTip()
  end
  BFConfigPanel.sortButton4:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
  BFConfigPanel.sortButton4:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 13)
  BFConfigPanel.sortButton4:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 14)
  BFConfigPanel.sortButton4:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 285)
  BFConfigPanel.sortButton5 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton5.OnClick = function(l_24_0, l_24_1, l_24_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_b5bf3f74df31441c3b407d9c0cd21177")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 16)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  end
  BFConfigPanel.sortButton5.OnMouseEnter = function(l_25_0, l_25_1, l_25_2)
    local l_25_3, l_25_4 = Cursor.GetPos()
    local l_25_5 = OutputTip
    local l_25_6 = "<text>text=\"��ͼ����\"</text>"
    local l_25_7 = 200
    do
      local l_25_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_25_5(l_25_6, l_25_7, l_25_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton5.OnMouseLeave = function(l_26_0, l_26_1, l_26_2)
    HideTip()
  end
  BFConfigPanel.sortButton5:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
  BFConfigPanel.sortButton5:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 16)
  BFConfigPanel.sortButton5:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 17)
  BFConfigPanel.sortButton5:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 338)
  BFConfigPanel.sortButton6 = BFButton.new(l_3_0, 46, 53)
  BFConfigPanel.sortButton6.OnClick = function(l_27_0, l_27_1, l_27_2)
    BFConfigPanel.page = 1
    BFConfigPanel.ShowSortMods("BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
    BFConfigPanel.sortButton:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 0)
    BFConfigPanel.sortButton1:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 3)
    BFConfigPanel.sortButton2:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 6)
    BFConfigPanel.sortButton3:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 9)
    BFConfigPanel.sortButton4:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 12)
    BFConfigPanel.sortButton5:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 15)
    BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 19)
  end
  BFConfigPanel.sortButton6.OnMouseEnter = function(l_28_0, l_28_1, l_28_2)
    local l_28_3, l_28_4 = Cursor.GetPos()
    local l_28_5 = OutputTip
    local l_28_6 = "<text>text=\"��������\"</text>"
    local l_28_7 = 200
    do
      local l_28_8 = {}
       -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

      l_28_5(l_28_6, l_28_7, l_28_8)
    end
     -- WARNING: undefined locals caused missing assignments!
  end
  BFConfigPanel.sortButton6.OnMouseLeave = function(l_29_0, l_29_1, l_29_2)
    HideTip()
  end
  BFConfigPanel.sortButton6:SetStyle("TRANSPARENT")
  BFConfigPanel.sortButton6:SetNormalImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 18)
  BFConfigPanel.sortButton6:SetHotImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 19)
  BFConfigPanel.sortButton6:SetPressedImage("Interface\\BF_Base\\artwork\\sortbutton.UITex", 20)
  BFConfigPanel.sortButton6:SetPoint("TOPLEFT", l_3_0, "TOPLEFT", 798, 391)
  BFConfigPanel.checkbuttons = {}
  BFConfigPanel.radiobuttons = {}
  BFConfigPanel.commandbuttons = {}
  BFConfigPanel.editboxes = {}
  BFConfigPanel.labels = {}
  BFConfigPanel.Dropdown = {}
  BFConfigPanel.downeditbox = {}
  BFConfigPanel.ChooseColor = {}
  BFConfigPanel.Smalleditboxes = {}
  l_3_0:Hide()
  l_3_0.OnUpdate = function()
  end
  l_3_0.OnShow = function()
    BFConfigPanel.page = 1
    BFConfigPanel.ShowMods()
  end
  BigFoot.RegisterEscapeFrame("BigFootConfigPanel", function()
    -- upvalues: l_3_0
    local l_32_0, l_32_1 = l_3_0:IsShown, l_3_0
    return l_32_0(l_32_1)
  end, function()
    -- upvalues: l_3_0
    l_3_0:Hide()
  end)
end

l_0_0 = BFConfigPanel
l_0_0.OnOptionCheck = function(l_4_0, l_4_1, l_4_2)
  local l_4_3 = l_4_1.mod
  local l_4_4 = l_4_1.tag
  local l_4_5, l_4_6 = nil, nil
  if BFMods[l_4_3] then
    for l_4_10,l_4_11 in ipairs(BFMods[l_4_3]) do
      if l_4_11.tag == l_4_4 then
        local l_4_12 = BFGetModValue(l_4_3, l_4_4)
        if l_4_12 ~= l_4_2 then
          BFSetModValue(l_4_3, l_4_4, l_4_2)
          l_4_11.callback(l_4_2)
        end
        BFConfigPanel.UpdateChildWidgetStatus(l_4_1)
        return 
      end
    end
  end
end

l_0_0 = BFConfigPanel
l_0_0.OnChanged = function(l_5_0, l_5_1, l_5_2)
  local l_5_3 = l_5_1:GetParent()
  local l_5_4 = l_5_3.mod
  local l_5_5 = l_5_3.tag
  local l_5_6, l_5_7 = nil, nil
  if BFMods[l_5_4] then
    for l_5_11,l_5_12 in ipairs(BFMods[l_5_4]) do
      if l_5_12.tag == l_5_5 then
        BFSetModValue(l_5_4, l_5_5, l_5_2)
        l_5_12.callback(l_5_2)
        return 
      end
    end
  end
end

l_0_0 = BFConfigPanel
l_0_0.OnColorChanged = function(l_6_0, l_6_1, l_6_2, l_6_3, l_6_4)
  local l_6_5 = l_6_1.mod
  local l_6_6 = l_6_1.tag
  local l_6_7, l_6_8 = nil, nil
  if BFMods[l_6_5] then
    for l_6_12,l_6_13 in ipairs(BFMods[l_6_5]) do
      if l_6_13.tag == l_6_6 then
        BFSetModValue(l_6_5, l_6_6, BigFoot_e6955c64cf39bdb23dc86de1a9ec2117)
        l_6_13.callback(l_6_2, l_6_3, l_6_4)
        return 
      end
    end
  end
end

l_0_0 = BFConfigPanel
l_0_0.GetElement = function(l_7_0)
  local l_7_1 = 1
  local l_7_2 = nil
  if l_7_0 == "checkbutton" and BFConfigPanel.checkbuttons[l_7_1] then
    if not BFConfigPanel.checkbuttons[l_7_1].active then
      l_7_2 = BFConfigPanel.checkbuttons[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "radiobutton" and BFConfigPanel.radiobuttons[l_7_1] then
    if not BFConfigPanel.radiobuttons[l_7_1].active then
      l_7_2 = BFConfigPanel.radiobuttons[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "editbox" and BFConfigPanel.editboxes[l_7_1] then
    if not BFConfigPanel.editboxes[l_7_1].active then
      l_7_2 = BFConfigPanel.editboxes[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "Smalleditbox" and BFConfigPanel.Smalleditboxes[l_7_1] then
    if not BFConfigPanel.Smalleditboxes[l_7_1].active then
      l_7_2 = BFConfigPanel.Smalleditboxes[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "commandbutton" and BFConfigPanel.commandbuttons[l_7_1] then
    if not BFConfigPanel.commandbuttons[l_7_1].active then
      l_7_2 = BFConfigPanel.commandbuttons[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "label" and BFConfigPanel.labels[l_7_1] then
    if not BFConfigPanel.labels[l_7_1].active then
      l_7_2 = BFConfigPanel.labels[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "Dropdown" and BFConfigPanel.Dropdown[l_7_1] then
    if not BFConfigPanel.Dropdown[l_7_1].active then
      l_7_2 = BFConfigPanel.Dropdown[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "downeditbox" and BFConfigPanel.downeditbox[l_7_1] then
    if not BFConfigPanel.downeditbox[l_7_1].active then
      l_7_2 = BFConfigPanel.downeditbox[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
  do return end
  do break end
  if l_7_0 == "ChooseColor" and BFConfigPanel.ChooseColor[l_7_1] then
    if not BFConfigPanel.ChooseColor[l_7_1].active then
      l_7_2 = BFConfigPanel.ChooseColor[l_7_1]
    end
    do break end
  end
  l_7_1 = l_7_1 + 1
end
if not l_7_2 then
  if l_7_0 == "checkbutton" then
    l_7_2 = BFCheckButton.new(BFConfigPanel.frame, 400, 24)
    l_7_2.OnCheck = BFConfigPanel.OnOptionCheck
    table.insert(BFConfigPanel.checkbuttons, l_7_2)
  end
elseif l_7_0 == "radiobutton" then
  l_7_2 = BFRadioButton.new(BFConfigPanel.frame, 400, 24)
  table.insert(BFConfigPanel.radiobuttons, l_7_2)
elseif l_7_0 == "editbox" then
  l_7_2 = BFWindow.new(BFConfigPanel.frame, 360, 28)
  l_7_2.title = BFLabel.new(l_7_2, 60, 28)
  l_7_2.title:SetPoint("TOPLEFT", l_7_2, "TOPLEFT", 5, 0)
  l_7_2.title:SetHAlign("LEFT")
  l_7_2.title:SetVAlign("CNETER")
  l_7_2.editbox = BFEditBox.new(l_7_2, 280, 28)
  l_7_2.editbox:SetPoint("TOPLEFT", l_7_2.title, "TOPRIGHT", 10, 0)
  l_7_2.editbox:SetPoint("RIGHT", l_7_2, "RIGHT", 0, 0)
  l_7_2.editbox.OnChanged = BFConfigPanel.OnChanged
  table.insert(BFConfigPanel.editboxes, l_7_2)
elseif l_7_0 == "Smalleditbox" then
  l_7_2 = BFWindow.new(BFConfigPanel.frame, 200, 28)
  l_7_2.title = BFLabel.new(l_7_2, 40, 28)
  l_7_2.title:SetPoint("TOPLEFT", l_7_2, "TOPLEFT", 5, 0)
  l_7_2.title:SetHAlign("LEFT")
  l_7_2.title:SetVAlign("CNETER")
  l_7_2.editbox = BFEditBox.new(l_7_2, 100, 28)
  l_7_2.editbox:SetPoint("TOPLEFT", l_7_2.title, "TOPRIGHT", 10, 0)
  l_7_2.editbox:SetPoint("RIGHT", l_7_2, "RIGHT", 0, 0)
  l_7_2.editbox.OnChanged = BFConfigPanel.OnChanged
  table.insert(BFConfigPanel.Smalleditboxes, l_7_2)
elseif l_7_0 == "downeditbox" then
  l_7_2 = BFWindow.new(BFConfigPanel.frame, 200, 28)
  l_7_2.title = BFLabel.new(l_7_2, 40, 28)
  l_7_2.title:SetPoint("TOPLEFT", l_7_2, "TOPLEFT", 5, 0)
  l_7_2.title:SetHAlign("LEFT")
  l_7_2.title:SetVAlign("CNETER")
  l_7_2.editbox = BFEditBox.new(l_7_2, 150, 28)
  l_7_2.editbox:SetPoint("TOPLEFT", l_7_2.title, "TOPRIGHT", 10, 0)
  l_7_2.editbox:SetPoint("RIGHT", l_7_2, "RIGHT", 0, 0)
  l_7_2.editbox.OnChanged = BFConfigPanel.OnChanged
  l_7_2.BigFoot_0ff4e26aedb2def1531f2d812314268e = BFImage.new(l_7_2, 20, 20, "ui\\Image\\UICommon\\CommonPanel.UITex", 73)
  l_7_2.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 = BFButton.new(BFConfigPanel.frame, 20, 20)
  l_7_2.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetTextHAlign("LEFT")
  l_7_2.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetStyle("TRANSPARENT")
  table.insert(BFConfigPanel.downeditbox, l_7_2)
elseif l_7_0 == "commandbutton" then
  l_7_2 = BFButton.new(BFConfigPanel.frame, 100, 28)
  l_7_2:SetStyle("TRANSPARENT")
  l_7_2:SetNormalImage("ui\\Image\\uicommon\\commonpanel.UITex", 38)
  l_7_2:SetHotImage("ui\\Image\\uicommon\\commonpanel.UITex", 39)
  l_7_2:SetPressedImage("ui\\Image\\uicommon\\commonpanel.UITex", 40)
  l_7_2:SetDisabledImage("ui\\Image\\uicommon\\commonpanel.UITex", 41)
  table.insert(BFConfigPanel.commandbuttons, l_7_2)
elseif l_7_0 == "label" then
  l_7_2 = BFLabel.new(BFConfigPanel.frame, 200, 24)
  table.insert(BFConfigPanel.labels, l_7_2)
elseif l_7_0 == "Dropdown" then
  l_7_2 = BFDropdown.new(BFConfigPanel.frame, 200, 25)
  table.insert(BFConfigPanel.Dropdown, l_7_2)
elseif l_7_0 == "ChooseColor" then
  l_7_2 = BFChooseColor.new(BFConfigPanel.frame, 100, 25)
  table.insert(BFConfigPanel.ChooseColor, l_7_2)
end
l_7_2.active = true
l_7_2:Show()
if l_7_0 ~= "Dropdown" and l_7_0 ~= "downeditbox" then
  l_7_2:Enable()
end
return l_7_2
end

l_0_0 = BFConfigPanel
l_0_0.ReleaseElement = function(l_8_0)
  l_8_0.active = false
  l_8_0.mod = nil
  l_8_0.tag = nil
  l_8_0:Hide()
end

l_0_0 = BFConfigPanel
l_0_0.ReleaseAllElements = function()
  local l_9_0, l_9_1 = nil, nil
  for i_1,i_2 in pairs(BFConfigPanel.checkbuttons) do
    BFConfigPanel.ReleaseElement(i_2)
  end
  for l_9_8,l_9_9 in pairs(BFConfigPanel.radiobuttons) do
    BFConfigPanel.ReleaseElement(l_9_9)
  end
  for l_9_13,l_9_14 in pairs(BFConfigPanel.commandbuttons) do
    BFConfigPanel.ReleaseElement(l_9_14)
  end
  for l_9_18,l_9_19 in pairs(BFConfigPanel.ChooseColor) do
    BFConfigPanel.ReleaseElement(l_9_19)
  end
  for l_9_23,l_9_24 in pairs(BFConfigPanel.editboxes) do
    BFConfigPanel.ReleaseElement(l_9_24)
  end
  for l_9_28,l_9_29 in pairs(BFConfigPanel.Smalleditboxes) do
    BFConfigPanel.ReleaseElement(l_9_29)
  end
  for l_9_33,l_9_34 in pairs(BFConfigPanel.labels) do
    BFConfigPanel.ReleaseElement(l_9_34)
  end
  do break end
  do
    local l_9_35, l_9_36, l_9_37, l_9_38, l_9_39 = pairs(BFConfigPanel.Dropdown)
    for l_9_43,l_9_44 in pairs(l_9_39) do
      l_9_44:Hide()
      l_9_44.bUse = false
    end
  end
end
 -- DECOMPILER ERROR: Confused about usage of registers for local variables.

end

l_0_0 = BFConfigPanel
l_0_0.RegisterMod = function(l_10_0, l_10_1, l_10_2, l_10_3)
  local l_10_4 = assert
  l_10_4(type(l_10_0) == "string", "The mod name must be string.")
  l_10_4 = BFMods
  l_10_4[l_10_0] = {}
  l_10_4 = BFMods
  l_10_4 = l_10_4[l_10_0]
  l_10_4.mod = l_10_0
  l_10_4 = BFMods
  l_10_4 = l_10_4[l_10_0]
  l_10_4.icon = l_10_2
  l_10_4 = BFMods
  l_10_4 = l_10_4[l_10_0]
  l_10_4.title = l_10_1
  l_10_4 = BFMods
  l_10_4 = l_10_4[l_10_0]
  l_10_4.sort = l_10_3
end

l_0_0 = BFConfigPanel
l_0_0.RegisterCheckButton = function(l_11_0, l_11_1, l_11_2, l_11_3, l_11_4, l_11_5, l_11_6, l_11_7)
  if BFMods[l_11_0] then
    local l_11_8 = {}
    l_11_8.mod = l_11_0
    l_11_8.tag = l_11_1
    l_11_8.type = "checkbutton"
    l_11_8.text = l_11_2
    l_11_8.default = l_11_3
    l_11_8.callback = l_11_4
    if not l_11_5 then
      l_11_5 = 1
    end
    l_11_8.level = l_11_5
    if not l_11_6 or l_11_6 ~= "list" and l_11_6 ~= "flow" then
      l_11_6 = "list"
    end
    l_11_8.layout = l_11_6
    local l_11_9 = nil
    if not l_11_7 then
      l_11_9 = 200
    end
    l_11_8.width = l_11_9
    l_11_9 = table
    l_11_9 = l_11_9.insert
    l_11_9(BFMods[l_11_0], l_11_8)
  end
end

l_0_0 = BFConfigPanel
l_0_0.RegisterEditBox = function(l_12_0, l_12_1, l_12_2, l_12_3, l_12_4, l_12_5)
  if BFMods[l_12_0] then
    local l_12_6 = {}
    l_12_6.mod = l_12_0
    l_12_6.tag = l_12_1
    l_12_6.type = "editbox"
    l_12_6.title = l_12_2
    l_12_6.default = l_12_3
    l_12_6.callback = l_12_4
    if not l_12_5 then
      l_12_5 = 1
    end
    l_12_6.level = l_12_5
    table.insert(BFMods[l_12_0], l_12_6)
  end
end

l_0_0 = BFConfigPanel
l_0_0.Registerbutton = function(l_13_0, l_13_1, l_13_2, l_13_3, l_13_4, l_13_5)
  if BFMods[l_13_0] then
    local l_13_6 = {}
    l_13_6.mod = l_13_0
    l_13_6.tag = l_13_1
    l_13_6.type = "commandbutton"
    l_13_6.title = l_13_2
    l_13_6.default = l_13_3
    l_13_6.callback = l_13_4
    if not l_13_5 then
      l_13_5 = 1
    end
    l_13_6.level = l_13_5
    table.insert(BFMods[l_13_0], l_13_6)
  end
end

l_0_0 = BFConfigPanel
l_0_0.RegisterSmallEditBox = function(l_14_0, l_14_1, l_14_2, l_14_3, l_14_4, l_14_5)
  if BFMods[l_14_0] then
    local l_14_6 = {}
    l_14_6.mod = l_14_0
    l_14_6.tag = l_14_1
    l_14_6.type = "Smalleditbox"
    l_14_6.title = l_14_2
    l_14_6.default = l_14_3
    l_14_6.callback = l_14_4
    if not l_14_5 then
      l_14_5 = 1
    end
    l_14_6.level = l_14_5
    table.insert(BFMods[l_14_0], l_14_6)
  end
end

l_0_0 = BFConfigPanel
l_0_0.RegisterDownEditBox = function(l_15_0, l_15_1, l_15_2, l_15_3, l_15_4, l_15_5)
  if BFMods[l_15_0] then
    local l_15_6 = {}
    l_15_6.mod = l_15_0
    l_15_6.tag = l_15_1
    l_15_6.type = "downeditbox"
    l_15_6.title = l_15_2
    l_15_6.default = l_15_3
    l_15_6.callback = l_15_4
    if not l_15_5 then
      l_15_5 = 1
    end
    l_15_6.level = l_15_5
    table.insert(BFMods[l_15_0], l_15_6)
  end
end

l_0_0 = BFConfigPanel
l_0_0.RegisterDropdown = function(l_16_0, l_16_1, l_16_2, l_16_3, l_16_4, l_16_5, l_16_6, l_16_7, l_16_8)
  if BFMods[l_16_0] then
    local l_16_9 = {}
    l_16_9.mod = l_16_0
    l_16_9.tag = l_16_1
    l_16_9.type = "Dropdown"
    l_16_9.title = l_16_2
    l_16_9.default = l_16_3
    l_16_9.Long = l_16_6
    l_16_9.Wide = l_16_7
    l_16_9.menu = l_16_8
    l_16_9.callback = l_16_4
    if not l_16_5 then
      l_16_5 = 1
    end
    l_16_9.level = l_16_5
    table.insert(BFMods[l_16_0], l_16_9)
  end
end

l_0_0 = BFConfigPanel
l_0_0.RegisterChooseColor = function(l_17_0, l_17_1, l_17_2, l_17_3, l_17_4, l_17_5, l_17_6, l_17_7, l_17_8, l_17_9, l_17_10)
  if BFMods[l_17_0] then
    local l_17_11 = {}
    l_17_11.mod = l_17_0
    l_17_11.tag = l_17_1
    l_17_11.type = "ChooseColor"
    l_17_11.title = l_17_2
    local l_17_12 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    if not l_17_7 then
      l_17_12(l_17_3[l_17_0], l_17_4)
    end
     -- WARNING: undefined locals caused missing assignments!
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 26 
end

l_0_0 = BFConfigPanel
l_0_0.ShowMods = function(l_18_0)
  local l_18_1, l_18_2 = nil, nil
  local l_18_3 = 1
  local l_18_4 = nil
  local l_18_5 = nil
  local l_18_6 = 1
  if not l_18_0 then
    for l_18_10,l_18_11 in pairs(BFMods) do
      local l_18_7, l_18_8 = nil, {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      table.insert(l_18_8, R13_PC26)
      BigFoot_3f50417fb16be9b1078eb68d24fa9c26 = BigFoot_3f50417fb16be9b1078eb68d24fa9c26 + 1
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    table.sort(l_18_8, function(l_19_0, l_19_1)
      return l_19_0.sort < l_19_1.sort
    end)
    BFConfigPanel.maxPage = math.floor(BigFoot_3f50417fb16be9b1078eb68d24fa9c26 / BFConfigPanel.MAX_COUNT_PER_PAGE)
    if math.fmod(BigFoot_3f50417fb16be9b1078eb68d24fa9c26, BFConfigPanel.MAX_COUNT_PER_PAGE) > 0 then
      BFConfigPanel.maxPage = BFConfigPanel.maxPage + 1
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_18_15,l_18_16 in ipairs(l_18_8) do
      local l_18_12, l_18_13 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      if l_18_4 <= l_18_3 and l_18_3 < l_18_5 then
        BFConfigPanel.modButtons[l_18_6].mod = R13_PC26.mod
         -- DECOMPILER ERROR: Confused about usage of registers!

        BFConfigPanel.modButtons[l_18_6]:SetTitle(R13_PC26.title)
         -- DECOMPILER ERROR: Confused about usage of registers!

         -- DECOMPILER ERROR: Confused about usage of registers!

        BFConfigPanel.modButtons[l_18_6]:SetImage(R13_PC26.icon, R13_PC26.frame)
        BFConfigPanel.modButtons[l_18_6]:Show()
        l_18_6 = l_18_6 + 1
      end
      l_18_3 = l_18_3 + 1
    end
    for l_18_20 = l_18_6, BFConfigPanel.MAX_COUNT_PER_PAGE do
      local l_18_17, l_18_18 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      BFConfigPanel.modButtons[BFConfigPanel.MAX_COUNT_PER_PAGE]:Hide()
    end
    BFConfigPanel.pageTitle:SetText(l_18_0 .. "/" .. BFConfigPanel.maxPage)
    if l_18_0 == 1 then
      BFConfigPanel.prevButton:Disable()
    else
      BFConfigPanel.prevButton:Enable()
    end
    if l_18_0 == BFConfigPanel.maxPage then
      BFConfigPanel.nextButton:Disable()
    else
      BFConfigPanel.nextButton:Enable()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 12 
end

l_0_0 = BFConfigPanel
l_0_0.ShowSortMods = function(l_19_0, l_19_1)
  local l_19_2, l_19_3 = nil, nil
  local l_19_4 = 1
  local l_19_5 = nil
  local l_19_6 = nil
  local l_19_7 = 1
  if not l_19_1 then
    for l_19_11,l_19_12 in pairs(BFMods) do
      local l_19_8, l_19_9 = nil, {}
       -- DECOMPILER ERROR: Confused about usage of registers!

      table.insert(l_19_9, R14_PC26)
    end
     -- DECOMPILER ERROR: Confused about usage of registers!

    table.sort(l_19_9, function(l_20_0, l_20_1)
      return l_20_0.sort < l_20_1.sort
    end)
     -- DECOMPILER ERROR: Confused about usage of registers!

    for l_19_16,l_19_17 in ipairs(l_19_9) do
      local l_19_13, l_19_14 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

       -- DECOMPILER ERROR: Confused about usage of registers!

      if R14_PC26.sort == l_19_0 then
        if l_19_5 <= l_19_4 and l_19_4 < l_19_6 then
          BFConfigPanel.modButtons[l_19_7].mod = R14_PC26.mod
           -- DECOMPILER ERROR: Confused about usage of registers!

          BFConfigPanel.modButtons[l_19_7]:SetTitle(R14_PC26.title)
           -- DECOMPILER ERROR: Confused about usage of registers!

           -- DECOMPILER ERROR: Confused about usage of registers!

          BFConfigPanel.modButtons[l_19_7]:SetImage(R14_PC26.icon, R14_PC26.frame)
          BFConfigPanel.modButtons[l_19_7]:Show()
          l_19_7 = l_19_7 + 1
          BigFoot_efd2e9678650f4427012daecc599a25a = BigFoot_efd2e9678650f4427012daecc599a25a + 1
        end
        l_19_4 = l_19_4 + 1
      end
    end
    BFConfigPanel.maxSortPage = math.floor(BigFoot_efd2e9678650f4427012daecc599a25a / BFConfigPanel.MAX_COUNT_PER_PAGE)
    if math.fmod(BigFoot_efd2e9678650f4427012daecc599a25a, BFConfigPanel.MAX_COUNT_PER_PAGE) > 0 then
      BFConfigPanel.maxSortPage = BFConfigPanel.maxSortPage + 1
    end
    for l_19_21 = l_19_7, BFConfigPanel.MAX_COUNT_PER_PAGE do
      local l_19_18, l_19_19 = nil
       -- DECOMPILER ERROR: Confused about usage of registers!

      BFConfigPanel.modButtons[BFConfigPanel.MAX_COUNT_PER_PAGE]:Hide()
    end
    BFConfigPanel.pageTitle:SetText(l_19_1 .. "/" .. BFConfigPanel.maxSortPage)
    if l_19_1 == 1 then
      BFConfigPanel.prevButton:Disable()
    else
      BFConfigPanel.prevButton:Enable()
    end
    if l_19_1 == BFConfigPanel.maxSortPage then
      BFConfigPanel.nextButton:Disable()
    else
      BFConfigPanel.nextButton:Enable()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 12 
end

l_0_0 = BFConfigPanel
l_0_0.UpdateParentWidgetStatus = function(l_20_0)
  local l_20_1 = l_20_0.level
  local l_20_2 = l_20_0
  l_20_0 = l_20_0.last_widget
  if l_20_0 then
    if l_20_0.level < l_20_1 then
      if l_20_0.type == "checkbutton" then
        if l_20_0:IsChecked() and l_20_0:IsEnabled() then
          l_20_2:Enable()
        end
        do break end
      end
      l_20_2:Disable()
      do break end
    end
    l_20_2:Enable()
    do break end
  end
  l_20_0 = l_20_0.last_widget
end
end

l_0_0 = BFConfigPanel
l_0_0.UpdateChildWidgetStatus = function(l_21_0)
  local l_21_1 = l_21_0.level
  local l_21_2 = l_21_0
  local l_21_3 = l_21_0:IsChecked()
  local l_21_4 = l_21_0:IsEnabled()
  l_21_0 = l_21_0.next_widget
  if l_21_0 and l_21_1 < l_21_0.level then
    if l_21_3 and l_21_4 then
      l_21_0:Enable()
    else
      l_21_0:Disable()
    end
  else
    do break end
  end
  l_21_0 = l_21_0.next_widget
end
end

l_0_0 = BFConfigPanel
l_0_0.ShowModPage = function(l_22_0, l_22_1)
  if l_22_0 and BFMods[l_22_0] then
    local l_22_2 = BFMods[l_22_0]
    do
      local l_22_3 = nil
      local l_22_4 = 0
      local l_22_5 = nil
      BFConfigPanel.ReleaseAllElements()
      for l_22_9 = 1, table.maxn(l_22_2) do
        do
          if l_22_2[l_22_9] then
            if l_22_2[l_22_9].type == "checkbutton" then
              local l_22_10 = BFConfigPanel.GetElement("checkbutton")
              do
                l_22_10:SetText(l_22_2[l_22_9].text)
                if not l_22_5 then
                  l_22_10:ClearAllPoints()
                  l_22_10:SetPoint("TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 350, 70)
                  l_22_10.last_widget = nil
                  l_22_10.next_widget = nil
                  l_22_10.level = l_22_2[l_22_9].level
                  l_22_10.type = l_22_2[l_22_9].type
                else
                  l_22_10:ClearAllPoints()
                  if l_22_2[l_22_9].layout == "list" then
                    l_22_10:SetPoint("TOP", l_22_5, "BOTTOM", 0, 7)
                    l_22_10:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
                  else
                    if l_22_2[l_22_9].layout == "flow" then
                      l_22_10:SetSize(l_22_2[l_22_9].width, l_22_10:GetHeight())
                      local l_22_11 = l_22_5:GetAbsPos()
                      local l_22_12 = BFConfigPanel.frame:GetAbsPos()
                      if l_22_5.level ~= l_22_2[l_22_9].level or l_22_12 + BFConfigPanel.frame:GetWidth() < l_22_11 + l_22_5:GetWidth() + l_22_10:GetWidth() + 7 then
                        l_22_10:SetPoint("TOP", l_22_5, "BOTTOM", 0, 7)
                        l_22_10:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
                      end
                    end
                  else
                    l_22_10:SetPoint("TOPLEFT", l_22_5, "TOPRIGHT", 7, 0)
                  end
                  l_22_10.last_widget = l_22_5
                  l_22_10.next_widget = nil
                  l_22_5.next_widget = l_22_10
                  l_22_10.level = l_22_2[l_22_9].level
                  l_22_10.type = l_22_2[l_22_9].type
                end
                l_22_10.mod = l_22_2[l_22_9].mod
                l_22_10.tag = l_22_2[l_22_9].tag
                if BFGetModValue(l_22_2[l_22_9].mod, l_22_2[l_22_9].tag) then
                  l_22_10:SetChecked(true)
                else
                  l_22_10:SetChecked(false)
                end
                l_22_5 = l_22_10
                BFConfigPanel.UpdateParentWidgetStatus(l_22_10)
              end
            end
          else
            if l_22_2[l_22_9].type == "editbox" then
              local l_22_13 = BFConfigPanel.GetElement("editbox")
              l_22_13.title:SetText(l_22_2[l_22_9].title)
              local l_22_14, l_22_15 = l_22_13.title:GetTextExtent()
              l_22_13.title:SetSize(l_22_14 - 5, 28)
              if not l_22_5 then
                l_22_13:ClearAllPoints()
                l_22_13:SetPoint("TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 350, 70)
                l_22_13.last_widget = nil
                l_22_13.next_widget = nil
                l_22_13.level = l_22_2[l_22_9].level
                l_22_13.type = l_22_2[l_22_9].type
              else
                l_22_13:ClearAllPoints()
                l_22_13:SetPoint("TOP", l_22_5, "BOTTOM", 0, 7)
                l_22_13:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
                l_22_13.last_widget = l_22_5
                l_22_13.next_widget = nil
                l_22_5.next_widget = l_22_13
                l_22_13.level = l_22_2[l_22_9].level
                l_22_13.type = l_22_2[l_22_9].type
              end
              l_22_13.mod = l_22_2[l_22_9].mod
              l_22_13.tag = l_22_2[l_22_9].tag
              local l_22_16 = BFGetModValue(l_22_2[l_22_9].mod, l_22_2[l_22_9].tag)
              if l_22_16 then
                l_22_13.editbox:SetText(l_22_16)
              else
                l_22_13.editbox:SetText("")
              end
              l_22_5 = l_22_13
              BFConfigPanel.UpdateParentWidgetStatus(l_22_13)
            end
          else
            if l_22_2[l_22_9].type == "Smalleditbox" then
              local l_22_17 = BFConfigPanel.GetElement("Smalleditbox")
              l_22_17.title:SetText(l_22_2[l_22_9].title)
              local l_22_18, l_22_19 = l_22_17.title:GetTextExtent()
              l_22_17.title:SetSize(l_22_18 - 5, 28)
              if not l_22_5 then
                l_22_17:ClearAllPoints()
                l_22_17:SetPoint("TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 350, 70)
                l_22_17.last_widget = nil
                l_22_17.next_widget = nil
                l_22_17.level = l_22_2[l_22_9].level
                l_22_17.type = l_22_2[l_22_9].type
              else
                l_22_17:ClearAllPoints()
                l_22_17:SetPoint("TOP", l_22_5, "BOTTOM", 0, 7)
                l_22_17:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
                l_22_17.last_widget = l_22_5
                l_22_17.next_widget = nil
                l_22_5.next_widget = l_22_17
                l_22_17.level = l_22_2[l_22_9].level
                l_22_17.type = l_22_2[l_22_9].type
              end
              l_22_17.mod = l_22_2[l_22_9].mod
              l_22_17.tag = l_22_2[l_22_9].tag
              local l_22_20 = BFGetModValue(l_22_2[l_22_9].mod, l_22_2[l_22_9].tag)
              if l_22_20 then
                l_22_17.editbox:SetText(l_22_20)
              else
                l_22_17.editbox:SetText("")
              end
              l_22_5 = l_22_17
              BFConfigPanel.UpdateParentWidgetStatus(l_22_17)
            end
          else
            if l_22_2[l_22_9].type == "downeditbox" then
              local l_22_21 = BFConfigPanel.GetElement("downeditbox")
              Output("downeditbox11111111111")
              local l_22_22 = l_22_2[l_22_9].Long
              local l_22_23 = l_22_2[l_22_9].Wide
              Output("downeditbox")
              l_22_21.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetSize(l_22_22 - 30, l_22_23)
              Output("downeditbox11111")
              l_22_21.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5:SetPoint("TOPLEFT", l_22_21, "TOPLEFT", 30, 0)
              Output("downeditbox22222")
              l_22_21.BigFoot_0ff4e26aedb2def1531f2d812314268e:SetPoint("TOPLEFT", l_22_21, "TOPLEFT", l_22_22 - 20, 0)
              Output("downeditbox3333333")
              l_22_21.title:SetText(l_22_2[l_22_9].title)
              Output("downeditbox4444444")
              l_22_21:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
              Output("downeditbox55555555555")
            end
          else
            if l_22_2[l_22_9].type == "commandbutton" then
              local l_22_24 = BFConfigPanel.GetElement("commandbutton")
              l_22_24:Show()
              l_22_24:SetText(l_22_2[l_22_9].title)
              l_22_24.mod = l_22_2[l_22_9].mod
              l_22_24.tag = l_22_2[l_22_9].tag
              if not l_22_5 then
                l_22_24:ClearAllPoints()
                l_22_24:SetPoint("TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 350, 70)
              else
                l_22_24:ClearAllPoints()
                l_22_24:SetPoint("TOP", l_22_5, "BOTTOM", 0, 7)
                l_22_24:SetPoint("LEFT", BFConfigPanel.frame, "LEFT", 350 + (l_22_2[l_22_9].level - 1) * 25, 0)
              end
              l_22_24.OnClick = function(l_23_0)
                -- upvalues: l_22_2 , l_22_9
                l_22_2[l_22_9].callback()
              end
            end
          else
            if l_22_2[l_22_9].type == "ChooseColor" then
              local l_22_25 = BFConfigPanel.GetElement("ChooseColor")
              l_22_25:Show()
              l_22_25:SetDefaultText(l_22_2[l_22_9].title)
              l_22_25.mod = l_22_2[l_22_9].mod
              l_22_25.tag = l_22_2[l_22_9].tag
              local l_22_26 = BFGetModValue(l_22_25.mod, l_22_25.tag)
              if type(l_22_26) == "table" then
                l_22_25:SetDefaultColor(unpack(l_22_26))
              else
                l_22_25:SetDefaultColor(255, 255, 255)
              end
              if l_22_2[l_22_9].level then
                if math.mod(l_22_2[l_22_9].level, 4) ~= 0 then
                  l_22_4 = math.floor(l_22_2[l_22_9].level / 4)
                end
              else
                l_22_4 = l_22_2[l_22_9].level / 4 - 1
              end
              local l_22_27 = 380 + (l_22_2[l_22_9].level - 1 - 4 * (l_22_4)) * 95
              local l_22_28 = l_22_2[l_22_9].tempheight + 30 * (l_22_4)
              l_22_25:SetPoint("TOPLEFT", BFConfigPanel.frame, "TOPLEFT", l_22_27, l_22_28)
              l_22_25.OnColorChanged = function(l_24_0)
                -- upvalues: l_22_2 , l_22_9
                l_22_2[l_22_9].callback(arg0, arg1, arg2)
                local l_24_1 = BFSetModValue
                local l_24_2 = l_24_0.mod
                local l_24_3 = l_24_0.tag
                do
                  local l_24_4 = {}
                   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

                  l_24_1(l_24_2, l_24_3, l_24_4)
                end
                 -- WARNING: undefined locals caused missing assignments!
              end
            end
          else
            if l_22_2[l_22_9].type == "Dropdown" then
              if not BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b then
                BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b = {}
              end
              if not BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e then
                BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e = {}
              end
              if not BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 then
                BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5 = {}
              end
              local l_22_29 = 1
              local l_22_30, l_22_31, l_22_32 = nil, nil, nil
              if BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b[l_22_29] then
                if BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b[l_22_29] and not BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b[l_22_29].bUse then
                  BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b[l_22_29].bUse = true
                  l_22_30 = BFConfigPanel.Dropdown.BigFoot_c56784577f9c1590bb81071ee435206b[l_22_29]
                end
                l_22_29 = l_22_29 + 1
              else
                if BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e[l_22_29] then
                  if BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e[l_22_29] and not BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e[l_22_29].bUse then
                    BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e[l_22_29].bUse = true
                    l_22_31 = BFConfigPanel.Dropdown.BigFoot_0ff4e26aedb2def1531f2d812314268e[l_22_29]
                  end
                  l_22_29 = l_22_29 + 1
                else
                  if BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5[l_22_29] then
                    if BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5[l_22_29] and not BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5[l_22_29].bUse then
                      BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5[l_22_29].bUse = true
                      l_22_32 = BFConfigPanel.Dropdown.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5[l_22_29]
                    end
                    l_22_29 = l_22_29 + 1
                  end
                end
                if not l_22_30 then
                  l_22_30 = BFImage.new(BFConfigPanel.frame, 8, 8, "ui\\Image\\UICommon\\CommonPanel.UITex", 48)
                end
                if not l_22_31 then
                  l_22_31 = BFImage.new(BFConfigPanel.frame, 20, 20, "ui\\Image\\UICommon\\CommonPanel.UITex", 73)
                end
                if not l_22_32 then
                  l_22_32 = BFButton.new(BFConfigPanel.frame, 8, 8)
                end
                l_22_30:Show()
                l_22_31:Show()
                l_22_32:Show()
                local l_22_33, l_22_35 = l_22_2[l_22_9].Long
                l_22_35 = l_22_2[l_22_9]
                l_22_35 = l_22_35.Wide
                do
                  local l_22_34, l_22_36 = nil
                  l_22_34, l_22_36 = l_22_30:SetSize, l_22_30
                  l_22_34(l_22_36, l_22_33, l_22_35)
                  l_22_34, l_22_36 = l_22_32:SetSize, l_22_32
                  l_22_34(l_22_36, l_22_33 - 8, l_22_35)
                  l_22_34, l_22_36 = l_22_30:SetImageType, l_22_30
                  l_22_34(l_22_36, "NINE_PART")
                  l_22_34, l_22_36 = l_22_32:SetTextHAlign, l_22_32
                  l_22_34(l_22_36, "LEFT")
                  l_22_34, l_22_36 = l_22_32:SetStyle, l_22_32
                  l_22_34(l_22_36, "TRANSPARENT")
                  l_22_30.bUse = true
                  l_22_31.bUse = true
                  l_22_32.bUse = true
                  l_22_34 = table
                  l_22_34 = l_22_34.insert
                  l_22_36 = BFConfigPanel
                  l_22_36 = l_22_36.Dropdown
                  l_22_36 = l_22_36.BigFoot_c56784577f9c1590bb81071ee435206b
                  l_22_34(l_22_36, l_22_30)
                  l_22_34 = table
                  l_22_34 = l_22_34.insert
                  l_22_36 = BFConfigPanel
                  l_22_36 = l_22_36.Dropdown
                  l_22_36 = l_22_36.BigFoot_0ff4e26aedb2def1531f2d812314268e
                  l_22_34(l_22_36, l_22_31)
                  l_22_34 = table
                  l_22_34 = l_22_34.insert
                  l_22_36 = BFConfigPanel
                  l_22_36 = l_22_36.Dropdown
                  l_22_36 = l_22_36.BigFoot_99f3cf2c6f1fdfadb0fd4ab6e0843bf5
                  l_22_34(l_22_36, l_22_32)
                  l_22_34 = function(l_25_0)
                  -- upvalues: l_22_12
                  l_22_12:SetImage("ui\\Image\\UICommon\\CommonPanel.UITex", 74)
                end
                  l_22_32.OnMouseEnter = l_22_34
                  l_22_34, l_22_36 = l_22_30:SetPoint, l_22_30
                  l_22_34(l_22_36, "TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 375 + (l_22_2[l_22_9].level - 1) * (l_22_33 + 25), 150)
                  l_22_34, l_22_36 = l_22_32:SetPoint, l_22_32
                  l_22_34(l_22_36, "TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 380 + (l_22_2[l_22_9].level - 1) * (l_22_33 + 25), 150)
                  l_22_34, l_22_36 = l_22_31:SetPoint, l_22_31
                  l_22_34(l_22_36, "TOPLEFT", BFConfigPanel.frame, "TOPLEFT", 375 + l_22_2[l_22_9].Long - 20 - 5 + (l_22_2[l_22_9].level - 1) * (l_22_33 + 25), 155)
                  if l_22_0 == "NewExpBar" then
                    l_22_34 = l_22_2[l_22_9]
                    l_22_34 = l_22_34.menu
                    l_22_34 = l_22_34[2]
                  end
                  if l_22_34 ~= "BF_NewExpBarMenu" then
                    l_22_34 = BF_NewExpBar
                    l_22_34 = l_22_34.MastChose
                    if l_22_34 == 1 then
                      l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                      l_22_34(l_22_36, l_22_2[l_22_9].title)
                    else
                      l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                      l_22_34(l_22_36, BF_NewExpBar.MastChose)
                    end
                  elseif l_22_0 == "NewExpBar" then
                    l_22_34 = l_22_2[l_22_9]
                    l_22_34 = l_22_34.menu
                    l_22_34 = l_22_34[2]
                  end
                  if l_22_34 == "BF_NewExpBarMenu" then
                    if l_22_1 then
                      l_22_34 = BF_NewExpBar
                      l_22_34 = l_22_34.BigFoot_35e9d47443686b697f37a98453440906
                      l_22_34 = l_22_34[1]
                    end
                    if l_22_34 then
                      l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                      l_22_34(l_22_36, BF_NewExpBar.BigFoot_35e9d47443686b697f37a98453440906[1])
                      l_22_34 = l_22_2[l_22_9]
                      l_22_34 = l_22_34.callback
                      l_22_36 = BF_NewExpBar
                      l_22_36 = l_22_36.BigFoot_35e9d47443686b697f37a98453440906
                      l_22_36 = l_22_36[1]
                      l_22_34(l_22_36)
                    else
                      l_22_34 = BF_NewExpBar
                      l_22_34 = l_22_34.MinChose
                      if l_22_34 == 1 then
                        l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                        l_22_34(l_22_36, l_22_2[l_22_9].title)
                      end
                    else
                      l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                      l_22_34(l_22_36, BF_NewExpBar.MinChose)
                    end
                  else
                    l_22_34, l_22_36 = l_22_32:SetText, l_22_32
                    l_22_34(l_22_36, l_22_2[l_22_9].title)
                  end
                  l_22_34 = function(l_26_0)
                  -- upvalues: l_22_12
                  l_22_12:SetImage("ui\\Image\\UICommon\\CommonPanel.UITex", 73)
                end
                  l_22_32.OnMouseLeave = l_22_34
                  l_22_34 = function(l_27_0)
                  -- upvalues: l_22_13 , l_22_2 , l_22_9 , l_22_0
                  local l_27_1, l_27_2 = l_22_13:GetAbsPos()
                  local l_27_3, l_27_4 = l_22_13:GetSize()
                  local l_27_5 = {}
                  l_27_5.nMiniWidth = l_27_3
                  l_27_5.x = l_27_1
                  l_27_5.y = l_27_2 + l_27_4
                  l_27_5.fnAction = function(l_28_0)
                    -- upvalues: l_22_13 , l_22_2 , l_22_9 , l_22_0
                    l_22_13:SetText(l_28_0)
                    l_22_2[l_22_9].callback(l_28_0)
                    if l_22_0 == "NewExpBar" and l_22_2[l_22_9].menu[2] ~= "BF_NewExpBarMenu" then
                      BFConfigPanel.ShowModPage(l_22_0, true)
                    end
                  end
                  local l_27_6 = false
                  for l_27_10,l_27_11 in pairs(l_22_2[l_22_9].menu) do
                    if l_27_11 == false then
                      l_27_6 = true
                    end
                  end
                  if not l_27_6 then
                    for l_27_15,l_27_16 in pairs(l_22_2[l_22_9].menu) do
                      local l_27_17 = table.insert
                      local l_27_18 = l_27_5
                      local l_27_19 = {}
                      l_27_19.szOption = l_27_16
                      l_27_19.UserData = l_27_16
                      l_27_17(l_27_18, l_27_19)
                    end
                    do break end
                  end
                  if l_27_6 and l_22_2[l_22_9].menu[2] == "BF_NewExpBarMenu" then
                    for l_27_23,l_27_24 in pairs(BF_NewExpBar.BigFoot_35e9d47443686b697f37a98453440906) do
                      local l_27_25 = table.insert
                      local l_27_26 = l_27_5
                      local l_27_27 = {}
                      l_27_27.szOption = l_27_24
                      l_27_27.UserData = l_27_24
                      l_27_25(l_27_26, l_27_27)
                    end
                  end
                  PopupMenu(l_27_5)
                end
                end
                 -- DECOMPILER ERROR: Confused about usage of registers!

                l_22_32.OnClick = l_22_34
              end
            end
          end
        end
      end
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 636 666 
end

l_0_0 = classv2
l_0_0 = l_0_0()
BFModButton = l_0_0
l_0_0 = BFModButton
l_0_0.ctor = function(l_23_0, l_23_1)
  l_23_0:Create(l_23_1)
end

l_0_0 = BFModButton
l_0_0.Create = function(l_24_0, l_24_1)
  local l_24_2 = BFWindow.new(l_24_1, 140, 50)
  local l_24_3 = BFImage.new(l_24_2, 140, 50)
  local l_24_4 = BFImage.new(l_24_2, 36, 36)
  local l_24_5 = BFLabel.new(l_24_2, 90, 50)
  local l_24_6 = BFButton.new(l_24_2, 130, 50)
  l_24_3:SetPoint("TOPLEFT", l_24_2, "TOPLEFT", 0, 0)
  l_24_4:SetPoint("LEFT", l_24_2, "LEFT", 8, 0)
  l_24_5:SetPoint("LEFT", l_24_2, "LEFT", 48, 0)
  l_24_6:SetPoint("TOPLEFT", l_24_2, "TOPLEFT", 0, 0)
  l_24_6:SetStyle("TRANSPARENT")
  l_24_0.icon = l_24_4
  l_24_0.button = l_24_6
  l_24_0.label = l_24_5
  l_24_0.border = l_24_3
  l_24_0.container = l_24_2
  l_24_6.root = l_24_0
  l_24_0:SetStatus("NORMAL")
end

l_0_0 = BFModButton
l_0_0.SetStatus = function(l_25_0, l_25_1)
  if l_25_1 == "NORMAL" then
    l_25_0.border:SetImage("Interface\\BF_Base\\artwork.UITex", 4)
    l_25_0.border:Show()
  elseif l_25_1 == "HIGHLIGHT" then
    l_25_0.border:SetImage("Interface\\BF_Base\\artwork.UITex", 5)
    l_25_0.border:Show()
  end
end

l_0_0 = BFModButton
l_0_0.SetImage = function(l_26_0, l_26_1, l_26_2)
  l_26_0.icon:SetImage(l_26_1, l_26_2)
end

l_0_0 = BFModButton
l_0_0.SetTitle = function(l_27_0, l_27_1)
  l_27_0.label:SetText(l_27_1)
end

l_0_0 = BFModButton
l_0_0.SetPoint = function(l_28_0, ...)
  l_28_0.container:SetPoint(...)
end

l_0_0 = BFModButton
l_0_0.Show = function(l_29_0)
  l_29_0.container:Show()
end

l_0_0 = BFModButton
l_0_0.Hide = function(l_30_0)
  l_30_0.container:Hide()
end

l_0_0 = BFConfigPanel
l_0_0 = l_0_0.Create
l_0_0()
l_0_0 = BigFoot
l_0_0 = l_0_0.RegisterMinimapButton
l_0_0("Interface\\BF_Base\\artwork\\setting.tga", "<Text>text=\"��/�رմ�ſ������\"</Text>", function()
  if BFConfigPanel.frame:IsShown() then
    BFConfigPanel.frame:Hide()
  else
    BFConfigPanel.frame:Show()
  end
end
)
l_0_0 = RegisterEvent
l_0_0("CUSTOM_DATA_LOADED", function()
  if arg0 ~= "Role" then
    return 
  end
  do break end
  do
    local l_32_0, l_32_1, l_32_2, l_32_3, l_32_4 = pairs(BFMods)
    local l_32_5, l_32_6 = nil, nil
    for l_32_10,l_32_11 in pairs(l_32_4) do
      if l_32_11.callback and type(l_32_11.callback) == "function" then
        local l_32_12 = l_32_11.mod
        local l_32_13 = l_32_11.tag
        local l_32_14 = BFGetModValue(l_32_12, l_32_13)
        if type(l_32_14) ~= "table" then
          m_mod1 = l_32_11.mod
          m_tag1 = l_32_11.tag
          l_32_11.callback(l_32_14, true)
        end
      else
        if type(l_32_14) == "table" then
          local l_32_15, l_32_16, l_32_17 = unpack(l_32_14)
          l_32_11.callback(l_32_15, l_32_16, l_32_17, true)
        end
      end
    end
  end
end
 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

 -- DECOMPILER ERROR: Overwrote pending register.

if tostring(l_32_1) == l_32_1 then
  BFConfigPanel.MinibuttonPos = l_32_1
end
end
)
l_0_0 = RegisterEvent
l_0_0("ACCOUNT_LOGOUT", function()
  SaveCustomData("BigFoot_ModOptions")
end
)

