-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ThreatScrutiny.lua 

if not ThreatScrutiny then
  ThreatScrutiny = {}
end
ThreatScrutiny.nSteper = -1
ThreatScrutiny.frameSelf = nil
ThreatScrutiny.handleMain = nil
ThreatScrutiny.handleImages = nil
ThreatScrutiny.handleThreatBar = nil
ThreatScrutiny.handleTargetInfo = nil
ThreatScrutiny.handleCombatTarget = nil
local l_0_0 = ThreatScrutiny
local l_0_1 = {}
l_0_1.nX = 0
l_0_1.nY = 0
l_0_0.LastLoc = l_0_1
l_0_0 = RegisterCustomData
l_0_1 = "ThreatScrutiny.LastLoc"
l_0_0(l_0_1)
l_0_0 = ThreatScrutiny
l_0_0.bFocusTargetLocked = false
l_0_0 = ThreatScrutiny
l_0_0.dwFocusTargetID = 0
l_0_0 = ThreatScrutiny
l_0_0.dwLastFocusTargetID = 0
l_0_0 = ThreatScrutiny
l_0_0.bCastAlertFlag = false
l_0_0 = ThreatScrutiny
l_0_0.bSelfTreatRank = 0
l_0_0 = ThreatScrutiny
l_0_1 = function()
  if not BF_EnableThreat then
    return 
  end
  if arg0 ~= "Role" then
    return 
  end
  ThreatScrutiny:SetPanelPos(ThreatScrutiny.LastLoc.nX, ThreatScrutiny.LastLoc.nY)
  ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(false)
  ThreatScrutiny.SetBGAlpha()
  if ThreatScrutiny.bLockPanel then
    ThreatScrutiny.frameSelf:EnableDrag(false)
  else
    ThreatScrutiny.frameSelf:EnableDrag(true)
  end
end

l_0_0.OnCustomDataLoaded = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_2_0 = Station.Lookup("Normal/ThreatScrutiny")
  l_2_0:RegisterEvent("CHARACTER_THREAT_RANKLIST")
  ThreatScrutiny:Message("��޼��ӵ���� V1.21 By Danexx [24713503] ����...")
end

l_0_0.OnFrameCreate = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  ThreatScrutiny.nSteper = ThreatScrutiny.nSteper + 1
  if ApplyCharacterThreatRankList and ThreatScrutiny.dwFocusTargetID and ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID) and ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID).nX then
    ApplyCharacterThreatRankList(ThreatScrutiny.dwFocusTargetID)
  else
    ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  end
  ThreatScrutiny.UpdateTargetInfo()
  if ThreatScrutiny.dwLastFocusTargetID ~= ThreatScrutiny.dwFocusTargetID then
    ThreatScrutiny.bSelfTreatRank = 0
  end
  ThreatScrutiny.dwLastFocusTargetID = ThreatScrutiny.dwFocusTargetID
  if ThreatScrutiny.frameSelf then
    local l_3_0 = ThreatScrutiny.LastLoc
    local l_3_1 = ThreatScrutiny.LastLoc
    local l_3_2 = ThreatScrutiny.frameSelf:GetRelPos()
    l_3_1.nY = ThreatScrutiny.frameSelf
    l_3_0.nX = l_3_2
  end
end

l_0_0.OnFrameBreathe = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function(l_4_0)
  if l_4_0 == "CHARACTER_THREAT_RANKLIST" then
    local l_4_1 = GetClientPlayer()
    if not l_4_1 then
      return 
    end
    ThreatScrutiny.UpdateThreatBars(arg0, arg1)
  end
end

l_0_0.OnEvent = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_5_0 = this:GetName()
  if l_5_0 == "Image_Options" then
    this:SetAlpha(255)
    local l_5_1, l_5_2 = Cursor.GetPos()
    local l_5_3 = "����޲��������ˬ�桿" .. "\n" .. "* ����������˴������ò����" .. "\n" .. "* ���κ�����ͽ�������ϵ Danexx [QQ: 24713503]��" .. "\n"
    local l_5_4 = OutputTip
    local l_5_5 = "<Text>text=" .. EncodeComponentsString(l_5_3) .. " font=100 </text>"
    local l_5_6 = 1000
    local l_5_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

    l_5_4(l_5_5, l_5_6, l_5_7)
  end
   -- WARNING: undefined locals caused missing assignments!
end

l_0_0.OnItemMouseEnter = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  local l_6_0 = this:GetName()
  if l_6_0 == "Image_Options" then
    this:SetAlpha(100)
    HideTip()
  end
end

l_0_0.OnItemMouseLeave = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  ThreatScrutiny.bFocusTargetLocked = true
  ThreatScrutiny.handleImages:Lookup("Image_ScrutinyLock"):Show()
end

l_0_0.OnCheckBoxCheck = l_0_1
l_0_0 = ThreatScrutiny
l_0_1 = function()
  ThreatScrutiny.bFocusTargetLocked = false
  ThreatScrutiny.handleImages:Lookup("Image_ScrutinyLock"):Hide()
end

l_0_0.OnCheckBoxUncheck = l_0_1
l_0_0 = 0
l_0_1 = ThreatScrutiny
l_0_1.OnItemLButtonDown = function()
  -- upvalues: l_0_0
  l_0_0 = ThreatScrutiny.nSteper
end

l_0_1 = ThreatScrutiny
l_0_1.OnItemLButtonClick = function()
  -- upvalues: l_0_0
  local l_10_0 = this:GetName()
  if l_10_0 == "Image_Options" then
    ThreatScrutiny.PopOptions()
  elseif l_10_0 == "Handle_TargetInfo" and ThreatScrutiny.nSteper - l_0_0 < 4 and ThreatScrutiny.dwFocusTargetID and ThreatScrutiny.dwFocusTargetID > 0 then
    local l_10_1 = TARGET.NPC
    if IsPlayer(ThreatScrutiny.dwFocusTargetID) then
      l_10_1 = TARGET.PLAYER
    end
    SelectTarget(l_10_1, ThreatScrutiny.dwFocusTargetID)
  end
end

l_0_1 = ThreatScrutiny
l_0_1.InitThreatBars = function(l_11_0, l_11_1)
  if not l_11_0 then
    l_11_0 = 30
  end
  if not l_11_1 then
    l_11_1 = 35
  end
  ThreatScrutiny.tForceIconList = {}
  ThreatScrutiny.handleThreatBar:Clear()
  local l_11_2 = "Interface/ThreatScrutiny/ThreatScrutiny.ini"
  for l_11_6 = 1, l_11_0 do
    local l_11_7 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Image_Treat_Pad_A", "Image_Treat_Pad_A_" .. l_11_6):Hide()
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    l_11_7[1]:SetRelPos(ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Image_Treat_Bar_White", "Image_Treat_Bar_White_" .. l_11_6), ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Image_Treat_Bar_Green", "Image_Treat_Bar_Green_" .. l_11_6) * 24)
    l_11_7[2]:Hide()
    l_11_7[2]:SetRelPos(160, (l_11_6 - 1) * 24 + 3)
    l_11_7[3]:Hide()
    l_11_7[3]:SetRelPos(3, (l_11_6 - 1) * 24 + 3)
    l_11_7[4]:Hide()
    l_11_7[4]:SetRelPos(3, (l_11_6 - 1) * 24 + 3)
    l_11_7[5]:Hide()
    l_11_7[5]:SetRelPos(3, (l_11_6 - 1) * 24 + 3)
    l_11_7[6]:Hide()
    l_11_7[6]:SetRelPos(3, (l_11_6 - 1) * 24 + 3)
     -- DECOMPILER ERROR: Overwrote pending register.

     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_8 = ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Text_ThreatName", ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Image_Treat_Bar_Yellow", "Image_Treat_Bar_Yellow_" .. l_11_6) .. ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Image_Treat_Bar_Red", "Image_Treat_Bar_Red_" .. l_11_6))
    l_11_8:SetAlpha(200)
    l_11_8:Hide()
    l_11_8:SetRelPos(20, (l_11_6 - 1) * 24 + 3)
    l_11_8:SetText("û��Ŀ��")
     -- DECOMPILER ERROR: Overwrote pending register.

    local l_11_9 = ThreatScrutiny.handleThreatBar:AppendItemFromIni(l_11_2, "Text_ThreatValue", "Text_ThreatValue_" .. .end)
    l_11_9:SetAlpha(200)
    l_11_9:Hide()
    l_11_9:SetRelPos(115, (l_11_6 - 1) * 24 + 3)
    l_11_9:SetText("100%")
  end
  ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  ThreatScrutiny.handleImages:Lookup("Image_Background"):SetSize(208, 90)
  ThreatScrutiny.handleThreatBar:FormatAllItemPos()
end

l_0_1 = ThreatScrutiny
l_0_1.UpdateThreatBars = function(l_12_0, l_12_1)
  local l_12_2 = ThreatScrutiny.GetCharacter(l_12_0)
  local l_12_3 = 0
  if l_12_2 and l_12_2.nX then
    _ = l_12_2.GetTarget()
  end
  local l_12_4 = {}
  for l_12_8,l_12_9 in pairs(l_12_1) do
    if l_12_3 == l_12_8 then
      local l_12_10 = table.insert
      local l_12_11 = l_12_4
      local l_12_12 = 1
      local l_12_13 = {}
      l_12_13.key = l_12_8
      l_12_13.value = l_12_9
      l_12_10(l_12_11, l_12_12, l_12_13)
    else
      local l_12_14 = table.insert
      local l_12_15 = l_12_4
      local l_12_16 = {}
      l_12_16.key = l_12_8
      l_12_16.value = l_12_9
      l_12_14(l_12_15, l_12_16)
    end
  end
  local l_12_17 = false
  if l_12_4[1] then
    local l_12_18 = 1
    l_12_17 = l_12_3 == l_12_4[1].key
    if l_12_17 then
      ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Show()
      l_12_18 = 2
    else
      ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
    end
    for l_12_22 = l_12_18, #l_12_4 do
      for l_12_26 = l_12_22 + 1, #l_12_4 do
        if l_12_4[l_12_22].value < l_12_4[l_12_26].value then
          local l_12_27 = l_12_4[l_12_26]
          l_12_4[l_12_26] = l_12_4[l_12_22]
          l_12_4[l_12_22] = l_12_27
        end
      end
    end
  else
    ThreatScrutiny.handleCombatTarget:Lookup("Image_CombatTarget"):Hide()
  end
  ThreatScrutiny.handleImages:Lookup("Image_Background"):SetSize(208, 90 + 24 * math.min(#l_12_4, ThreatScrutiny.nMaxBarCount))
  for l_12_31 = 1, 30 do
    local l_12_32 = ThreatScrutiny.handleThreatBar:Lookup("Text_ThreatName_" .. l_12_31)
    local l_12_33 = ThreatScrutiny.handleThreatBar:Lookup("Text_ThreatValue_" .. l_12_31)
    local l_12_34 = {}
     -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

     -- DECOMPILER ERROR: Overwrote pending register.

    if ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Pad_A_" .. l_12_31) and l_12_31 <= ThreatScrutiny.nMaxBarCount then
      local l_12_35 = l_12_4[l_12_31].key
       -- DECOMPILER ERROR: Overwrote pending register.

      local l_12_36 = ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Pad_B_" .. l_12_31).value
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_12_37 = ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_White_" .. l_12_31).GetCharacter(ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Green_" .. l_12_31))
       -- DECOMPILER ERROR: Overwrote pending register.

       -- DECOMPILER ERROR: Overwrote pending register.

      local l_12_38 = "[" .. ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Yellow_" .. l_12_31) .. ThreatScrutiny.handleThreatBar:Lookup("Image_Treat_Bar_Red_" .. l_12_31)
      local l_12_39 = ""
      local l_12_40 = 6
       -- DECOMPILER ERROR: Overwrote pending register.

      if (not l_12_37 or l_12_36 > 0.01) and .end and l_12_4[1].value and l_12_4[1].value > 0.01 then
        if ThreatScrutiny.bShowThreatbalancePercent then
          l_12_39 = ThreatScrutiny.szThreatPercentAccuracy:format(100 * l_12_36 / l_12_4[1].value)
        end
      else
        if ThreatScrutiny.bShowThreatPercent then
          l_12_39 = ThreatScrutiny.szThreatPercentAccuracy:format(l_12_36 / 655.35)
        end
      else
        if ThreatScrutiny.bShowThreatAnykindPercent then
          l_12_39 = ThreatScrutiny.szThreatPercentAccuracy:format(l_12_36 / 655.35) .. " / " .. ThreatScrutiny.szThreatPercentAccuracy:format(100 * l_12_36 / l_12_4[1].value)
        end
      end
      local l_12_41 = 255
      local l_12_42 = 255
      local l_12_43 = 0
      if ThreatScrutiny.bForceColor then
        l_12_41 = ThreatScrutiny.GetCharacterColor(l_12_35)
      end
      l_12_34[1]:Show()
      l_12_34[2]:Show()
      l_12_32:SetText(l_12_38)
      l_12_32:SetFontColor(l_12_41, l_12_42, l_12_43)
      l_12_32:Show()
      l_12_33:SetText(l_12_39)
      l_12_33:SetFontColor(l_12_41, l_12_42, l_12_43)
      l_12_33:Show()
      local l_12_44 = l_12_36 / l_12_4[1].value
      local l_12_45 = l_12_44 * 0.80645161290323
      if GetClientPlayer().dwID == l_12_35 then
        if ThreatScrutiny.nOTAlertLevel >= 0 and l_12_17 and l_12_3 ~= GetClientPlayer().dwID and ThreatScrutiny.bSelfTreatRank < ThreatScrutiny.nOTAlertLevel and ThreatScrutiny.nOTAlertLevel <= l_12_44 then
          OutputMessage("MSG_ANNOUNCE_YELLOW", "**��%s������ĳ�޳����� %.1f��, �ﵽ 120�� ��ϣԣ�**":format(l_12_2.szName, ThreatScrutiny.nOTAlertLevel * 100))
        end
        if ThreatScrutiny.bOTAlertSound then
          PlaySound(1, "data\\sound\\����\\view\\nat_view2.wav")
        end
        ThreatScrutiny.bSelfTreatRank = l_12_44
      end
      l_12_34[3]:Hide()
      l_12_34[4]:Hide()
      l_12_34[5]:Hide()
      l_12_34[6]:Hide()
      if l_12_45 >= 0.83 then
        l_12_34[6]:Show()
        l_12_34[6]:SetPercentage(l_12_45)
      elseif l_12_45 >= 0.54 then
        l_12_34[5]:Show()
        l_12_34[5]:SetPercentage(l_12_45)
      elseif l_12_45 >= 0.3 then
        l_12_34[4]:Show()
        l_12_34[4]:SetPercentage(l_12_45)
      elseif l_12_45 >= 0.01 then
        l_12_34[3]:Show()
        l_12_34[3]:SetPercentage(l_12_45)
      end
    else
      l_12_32:Hide()
      l_12_33:Hide()
      l_12_34[1]:Hide()
      l_12_34[2]:Hide()
      l_12_34[3]:Hide()
      l_12_34[4]:Hide()
      l_12_34[5]:Hide()
      l_12_34[6]:Hide()
    end
    ThreatScrutiny.handleImages:FormatAllItemPos()
  end
end

l_0_1 = ThreatScrutiny
l_0_1.UpdateTargetInfo = function()
  local l_13_0 = GetClientPlayer()
  if not l_13_0 then
    return 
  end
  local l_13_1, l_13_2 = l_13_0.GetTarget()
  if l_13_1 > 1 and not ThreatScrutiny.bFocusTargetLocked then
    ThreatScrutiny.dwFocusTargetID = l_13_2
  end
  local l_13_3 = ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID)
  if ThreatScrutiny.bFoucsPartyTarget and l_13_0.IsPlayerInMyParty(ThreatScrutiny.dwFocusTargetID) and l_13_3 and l_13_3.nX then
    local l_13_4, l_13_5 = l_13_3.GetTarget()
  end
  if l_13_4 > 1 then
    ThreatScrutiny.dwFocusTargetID = l_13_5
    l_13_3 = ThreatScrutiny.GetCharacter(ThreatScrutiny.dwFocusTargetID)
  end
  local l_13_6 = "???? (??��)"
  local l_13_7 = "???? / ???? (?? %)"
  local l_13_8 = "???? / ????"
  local l_13_9 = 1
  local l_13_10 = 1
  local l_13_11 = ""
  local l_13_12 = false
  local l_13_13 = 0
  local l_13_14 = 1
  local l_13_15 = 0
  local l_13_16 = 0
  local l_13_17 = 255
  local l_13_18 = 0
  if not ThreatScrutiny.bShowScrutinyDist then
    l_13_6 = "????"
  end
  if not ThreatScrutiny.bShowHPPercent then
    l_13_7 = "???? / ????"
  end
  if l_13_3 then
    l_13_9 = l_13_3.nCurrentLife / l_13_3.nMaxLife
    l_13_6 = l_13_3.szName
    if IsCtrlKeyDown() then
      l_13_6 = l_13_6 .. " (" .. l_13_3.dwID .. ")"
    else
      if ThreatScrutiny.bShowScrutinyDist then
        if (not l_13_3.nX and l_13_3.nY) or not l_13_3.nZ then
          l_13_6 = l_13_6 .. " (%.1f��)":format(math.floor(l_13_0.nX - l_13_3.nPosX ^ 2 + l_13_0.nY - l_13_3.nPosY ^ 2 + l_13_0.nZ / 8 - l_13_3.nPosZ / 8 ^ 2 ^ 0.5) / 64)
        end
      end
      if ThreatScrutiny.bShowHPPercent then
        l_13_7 = "%d / %d (%.1f%%)":format(l_13_3.nCurrentLife, l_13_3.nMaxLife, l_13_9 * 100)
      else
        l_13_7 = "%d / %d":format(l_13_3.nCurrentLife, l_13_3.nMaxLife)
      end
      if l_13_0.IsPlayerInMyParty(l_13_3.dwID) or ThreatScrutiny.dwFocusTargetID == l_13_2 then
        l_13_10 = l_13_3.nCurrentMana / l_13_3.nMaxMana
        l_13_8 = "%d / %d":format(l_13_3.nCurrentMana, l_13_3.nMaxMana)
      else
        l_13_8 = "???? / %d":format(l_13_3.nMaxMana)
      end
      if l_13_3.nX then
        l_13_16 = GetHeadTextForceFontColor(l_13_0.dwID, l_13_3.dwID)
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_13_16, l_13_17, l_13_18)
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_13_16, l_13_17, l_13_18)
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
        l_13_12 = l_13_3.GetSkillPrepareState()
        l_13_11 = Table_GetSkillName(l_13_13, l_13_14)
        if not ThreatScrutiny.bCastAlertFlag and l_13_12 and ThreatScrutiny.nCastAlertChannel >= 0 and l_13_11 and l_13_11 ~= "" then
          local l_13_19 = {}
          local l_13_20 = {}
          l_13_20.type = "text"
          l_13_20.text = "�� [" .. l_13_3.szName .. "]��ʼ����: " .. l_13_11 .. "��"
           -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

          l_13_20 = l_13_0.IsInParty
          l_13_20 = l_13_20()
        end
        if l_13_20 then
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.szCastAlertRelation
          if l_13_20 ~= "All" then
            l_13_20 = ThreatScrutiny
            l_13_20 = l_13_20.szCastAlertRelation
            if l_13_20 == "Enemy" then
              l_13_20 = IsEnemy
              l_13_20 = l_13_20(l_13_0.dwID, l_13_3.dwID)
            end
          if not l_13_20 then
            end
          end
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.szCastAlertRelation
        end
        if l_13_20 == "Friendly" then
          l_13_20 = IsEnemy
          l_13_20 = l_13_20(l_13_0.dwID, l_13_3.dwID)
        end
        if not l_13_20 then
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.szCastAlertCharType
          if l_13_20 ~= "All" then
            l_13_20 = ThreatScrutiny
            l_13_20 = l_13_20.szCastAlertCharType
            if l_13_20 == "Player" then
              l_13_20 = IsPlayer
              l_13_20 = l_13_20(l_13_3.dwID)
            end
          if not l_13_20 then
            end
          end
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.szCastAlertCharType
        end
        if l_13_20 == "Npc" then
          l_13_20 = IsPlayer
          l_13_20 = l_13_20(l_13_3.dwID)
        end
        if not l_13_20 then
          l_13_20 = IsPlayer
          l_13_20 = l_13_20(l_13_3.dwID)
          if not l_13_20 then
            l_13_20 = ThreatScrutiny
            l_13_20 = l_13_20.nCastAlertIntensity
          end
          if l_13_20 ~= 1 then
            l_13_20 = ThreatScrutiny
            l_13_20 = l_13_20.nCastAlertIntensity
            if l_13_20 == 2 then
              l_13_20 = l_13_3.nIntensity
            end
            if l_13_20 ~= 1 then
              l_13_20 = l_13_3.nIntensity
            end
            if l_13_20 ~= 3 then
              l_13_20 = l_13_3.nIntensity
            end
          if l_13_20 <= 6 then
            end
          end
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.nCastAlertIntensity
          if l_13_20 == 3 then
            l_13_20 = l_13_3.nIntensity
          if l_13_20 ~= 4 then
            end
          end
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.nCastAlertIntensity
          if l_13_20 == 4 then
            l_13_20 = l_13_3.nIntensity
          if l_13_20 ~= 5 then
            end
          end
          l_13_20 = ThreatScrutiny
          l_13_20 = l_13_20.nCastAlertIntensity
        end
        if l_13_20 == 5 then
          l_13_20 = l_13_3.nIntensity
          if l_13_20 ~= 2 then
            l_13_20 = l_13_3.nIntensity
          end
        if l_13_20 == 6 then
          end
        end
        l_13_20 = l_13_0.Talk
        l_13_20(ThreatScrutiny.nCastAlertChannel, "", l_13_19)
      else
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_13_16, l_13_17, l_13_18)
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_13_16, l_13_17, l_13_18)
        ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
      end
    else
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetFontColor(l_13_16, l_13_17, l_13_18)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetFontColor(l_13_16, l_13_17, l_13_18)
      ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetFontColor(96, 164, 200)
      ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(false)
    end
    if l_13_16 == 0 and l_13_17 >= 255 and l_13_18 == 0 then
      ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Show()
    elseif l_13_16 == 0 and l_13_17 == 200 and l_13_18 == 72 then
      ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Show()
    elseif l_13_16 >= 255 and l_13_17 == 0 and l_13_18 == 0 then
      ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Show()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Hide()
    else
      ThreatScrutiny.handleImages:Lookup("Image_Title_Red"):Hide()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Yellow"):Show()
      ThreatScrutiny.handleImages:Lookup("Image_Title_Blue"):Hide()
    end
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetName"):SetText(l_13_6)
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetLife"):SetText(l_13_7)
    ThreatScrutiny.handleImages:Lookup("Image_Life_Bar"):SetPercentage(l_13_9)
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetMana"):SetText(l_13_8)
    ThreatScrutiny.handleImages:Lookup("Image_Mana_Bar"):SetPercentage(l_13_10)
    ThreatScrutiny.handleTargetInfo:Lookup("Text_TargetCast"):SetText(l_13_11)
    ThreatScrutiny.handleImages:Lookup("Image_Cast_Bar"):SetPercentage(l_13_15)
    ThreatScrutiny.bCastAlertFlag = l_13_12
    if ThreatScrutiny.bCastAlertFlag then
      ThreatScrutiny.handleImages:Lookup("Animate_Cast_Flash"):Show()
    else
      ThreatScrutiny.handleImages:Lookup("Animate_Cast_Flash"):Hide()
    end
     -- WARNING: missing end command somewhere! Added here
  end
  -- WARNING: F->nextEndif is not empty. Unhandled nextEndif->addr = 114 
end

l_0_1 = ThreatScrutiny
l_0_1.GetCharacterColor = function(l_14_0)
  local l_14_1 = GetClientPlayer()
  if not l_14_1 then
    return 128, 128, 128
  end
  if not IsPlayer(l_14_0) then
    return 220, 220, 220
  end
  local l_14_2 = ThreatScrutiny.GetCharacter(l_14_0)
  if not l_14_2 then
    return 128, 128, 128
  end
  local l_14_3 = l_14_2.dwForceID
  if not l_14_3 then
    local l_14_6 = 220
    return l_14_6, 220, 220
  end
  if BF_GetClassColor and BF_GetClassColor(l_14_3) then
    local l_14_4 = BF_GetClassColor
    local l_14_5 = l_14_3
    return l_14_4(l_14_5)
  end
  return 220, 220, 220
end

l_0_1 = ThreatScrutiny
l_0_1.GetCharacter = function(l_15_0)
  if IsPlayer(l_15_0) then
    local l_15_1 = GetPlayer(l_15_0)
    if not l_15_1 then
      local l_15_2 = GetClientPlayer()
      if not l_15_2 then
        return 
      end
      local l_15_3, l_15_13 = GetClientTeam()
    end
    if l_15_3 then
      l_15_13 = l_15_3.GetMemberGroupIndex
      l_15_13 = l_15_13(l_15_2.dwID)
      local l_15_4, l_15_14 = nil
    end
    if l_15_13 and l_15_13 >= 0 then
      l_15_4 = l_15_3.GetGroupInfo
      l_15_14 = l_15_13
      l_15_4 = l_15_4(l_15_14)
      local l_15_5, l_15_15 = nil
      l_15_14 = pairs
      l_15_5 = l_15_4.MemberList
      l_15_14 = l_15_14(l_15_5)
      for l_15_9,l_15_10 in l_15_14 do
        local l_15_8, l_15_9, l_15_10 = nil
        do
          if l_15_0 == l_15_7 then
            local l_15_16, l_15_17, l_15_18, l_15_19, l_15_20 = nil
          end
          l_15_8 = l_15_3.GetMemberInfo
          l_15_9 = l_15_0
          local l_15_22 = nil
          l_15_8 = l_15_8(l_15_9)
          local l_15_21 = nil
          l_15_1 = l_15_8
        end
        do break end
      end
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

    return l_15_1
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  else
    l_15_1 = GetNpc
    local l_15_11 = nil
    l_15_2 = l_15_0
    do
      local l_15_12 = nil
      return l_15_1(l_15_2)
    end
     -- DECOMPILER ERROR: Confused about usage of registers for local variables.

  end
end

l_0_1 = ThreatScrutiny
l_0_1.Message = function(l_16_0, l_16_1)
  OutputMessage("MSG_SYS", "[ThreatScrutiny] " .. tostring(l_16_1) .. "\n")
end

l_0_1 = ThreatScrutiny
l_0_1.SetPanelPos = function(l_17_0, l_17_1, l_17_2)
  if not l_17_1 or not l_17_2 then
    ThreatScrutiny.frameSelf:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
  else
    local l_17_3, l_17_4 = Station.GetClientSize(true)
    if l_17_1 < 0 then
      l_17_1 = 0
    end
    if l_17_3 - 30 < l_17_1 then
      l_17_1 = l_17_3 - 30
    end
    if l_17_2 < 0 then
      l_17_2 = 0
    end
    if l_17_4 - 120 < l_17_2 then
      l_17_2 = l_17_4 - 120
    end
    ThreatScrutiny.frameSelf:SetRelPos(l_17_1, l_17_2)
  end
  local l_17_5 = ThreatScrutiny.LastLoc
  local l_17_6 = ThreatScrutiny.LastLoc
  local l_17_7 = ThreatScrutiny.frameSelf:GetRelPos()
  l_17_6.nY = ThreatScrutiny.frameSelf
  l_17_5.nX = l_17_7
end

l_0_1 = ThreatScrutiny
l_0_1.OpenPanel = function()
  if not Station.Lookup("Normal/ThreatScrutiny") then
    local l_18_0, l_18_1, l_18_2, l_18_3, l_18_4, l_18_5, l_18_6, l_18_7, l_18_8, l_18_9, l_18_10, l_18_11, l_18_12, l_18_13, l_18_14, l_18_15 = Wnd.OpenWindow("Interface\\ThreatScrutiny\\ThreatScrutiny.ini", "ThreatScrutiny")
  end
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_18_0:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
   -- DECOMPILER ERROR: Confused about usage of registers!

  l_18_0:Show()
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.frameSelf = l_18_0
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleMain = l_18_0:Lookup("", "")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleImages = l_18_0:Lookup("", "Handle_Images")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleThreatBar = l_18_0:Lookup("", "Handle_ThreatBar")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleTargetInfo = l_18_0:Lookup("", "Handle_TargetInfo")
   -- DECOMPILER ERROR: Confused about usage of registers!

  ThreatScrutiny.handleCombatTarget = l_18_0:Lookup("", "Handle_CombatTarget")
  ThreatScrutiny.InitThreatBars()
end

l_0_1 = ThreatScrutiny
l_0_1.ClosePanel = function()
  local l_19_0 = Station.Lookup("Normal/ThreatScrutiny")
  if l_19_0 then
    Wnd.CloseWindow("ThreatScrutiny")
  end
end

l_0_1 = RegisterEvent
l_0_1("CUSTOM_DATA_LOADED", ThreatScrutiny.OnCustomDataLoaded)
l_0_1 = Hotkey
l_0_1 = l_0_1.AddBinding
l_0_1("ThreatScrutiny_SetFocusTarget", "ֱ�����ý���Ŀ��", "��޼��ӵ����", function()
  if not BF_EnableThreat then
    return 
  end
  local l_20_0, l_20_1 = GetClientPlayer().GetTarget()
  if l_20_0 > 1 then
    ThreatScrutiny.dwFocusTargetID = l_20_1
    ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(true)
  end
end
, nil)
l_0_1 = Hotkey
l_0_1 = l_0_1.AddBinding
l_0_1("ThreatScrutiny_CancelTarget", "ȡ������Ŀ��", "", function()
  if not BF_EnableThreat then
    return 
  end
  ThreatScrutiny.frameSelf:Lookup("CheckBox_ScrutinyLock"):Check(false)
end
, nil)
l_0_1 = Hotkey
l_0_1 = l_0_1.AddBinding
l_0_1("ThreatScrutiny_ResetPanelPos", "���ò��λ��", "", function()
  if not BF_EnableThreat then
    return 
  end
  ThreatScrutiny:SetPanelPos()
end
, nil)
l_0_1 = Hotkey
l_0_1 = l_0_1.AddBinding
l_0_1("ThreatScrutiny_PartyTarget", "ѡ�ж���ʱ���Ӷ���Ŀ��", "", function()
  if not BF_EnableThreat then
    return 
  end
  if ThreatScrutiny.bFoucsPartyTarget then
    ThreatScrutiny.bFoucsPartyTarget = false
    ThreatScrutiny:Message("ѡ�ж��Ѽ��Ӷ���Ŀ�깦�ܣ��رգ�")
  else
    ThreatScrutiny.bFoucsPartyTarget = true
    ThreatScrutiny:Message("ѡ�ж��Ѽ��Ӷ���Ŀ�깦�ܣ�������")
  end
end
, nil)
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterMod
l_0_1("Threat", "���ͳ��", "ui\\image\\icon\\skill_jianghu_quanzhanggongji.tga", "BigFoot_b6b85020006c3110eba073d7eb8da75f")
l_0_1 = BFConfigPanel
l_0_1 = l_0_1.RegisterCheckButton
l_0_1("Threat", "EnableThreat", "�������ͳ��", true, function(l_24_0, l_24_1)
  BF_EnableThreat = l_24_0
  if l_24_0 then
    local l_24_2, l_24_3 = nil, nil
    if ThreatScrutiny.LastLoc.nX ~= 0 or ThreatScrutiny.LastLoc.nY ~= 0 then
      l_24_2 = ThreatScrutiny.LastLoc.nX
    end
    ThreatScrutiny.OpenPanel()
    if l_24_2 and l_24_3 then
      ThreatScrutiny:SetPanelPos(l_24_2, l_24_3)
    end
  else
    ThreatScrutiny.ClosePanel()
  end
end
)

