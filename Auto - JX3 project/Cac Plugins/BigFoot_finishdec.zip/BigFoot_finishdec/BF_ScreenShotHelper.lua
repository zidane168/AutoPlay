-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_ScreenShotHelper.lua 

if not BF_ScreenShotHelper then
  BF_ScreenShotHelper = {}
end
BF_ScreenShotHelper.nQuality = 100
BF_ScreenShotHelper.szMode = "bmp"
BF_ScreenShotHelper.SetConfigModle = function(l_1_0)
  if l_1_0 == "bmp" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", true)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", false)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", false)
  elseif l_1_0 == "jpg" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", false)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", false)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", true)
  elseif l_1_0 == "tga" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", false)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", true)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", false)
  end
  BFConfigPanel.ShowModPage("ScreenShot")
end

BF_ScreenShotHelper.TakeScreenshot = function(l_2_0, l_2_1)
  if not BF_ScreenShotHelper.enabled then
    return 
  end
  local l_2_2 = ScreenShot(l_2_0, l_2_1)
  if BF_ScreenShotHelper.BShowSound then
    PlaySound(SOUND.UI_SOUND, "Interface\\BF_ScreenShotHelper\\ScreenShotHelper.wav")
  end
  if l_2_2 and BF_ScreenShotHelper.BShowMessage then
    OutputMessage("MSG_ANNOUNCE_YELLOW", g_tStrings.SCREENSHOT)
    OutputMessage("MSG_SYS", g_tStrings.SCREENSHOT_MSG .. l_2_2 .. "\n")
  end
end

Hotkey.AddBinding("BF_ScreenShotHelper_ShowUI", "��ȡ��ͼ", "��ͼ����", function()
  BF_ScreenShotHelper.TakeScreenshot(BF_ScreenShotHelper.szMode, BF_ScreenShotHelper.nQuality)
end
, nil)
BFConfigPanel.RegisterMod("ScreenShot", "��ͼ����", "\\ui\\image\\icon\\m5yangzhou10.tga", "BigFoot_7a0f6e31f67a4d080d11408e38d3bdbf")
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShot", "������ͼ����(���ڿ�ݼ����������ý�ͼ����)", true, function(l_4_0)
  BF_ScreenShotHelper.enabled = l_4_0
end
)
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShotBMP", "BMP��ʽ��ͼ", true, function(l_5_0, l_5_1)
  if l_5_1 and not l_5_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "bmp"
  if not l_5_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShotTGA", "TGA��ʽ��ͼ", false, function(l_6_0, l_6_1)
  if l_6_1 and not l_6_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "tga"
  if not l_6_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShotJPG", "JPG��ʽ��ͼ", false, function(l_7_0, l_7_1)
  if l_7_1 and not l_7_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "jpg"
  if not l_7_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShotInfo", "��ͼ��Ϣ", true, function(l_8_0)
  BF_ScreenShotHelper.BShowMessage = l_8_0
end
, 2)
BFConfigPanel.RegisterCheckButton("ScreenShot", "EnableScreenShotSound", "������ͼ������ʾ", true, function(l_9_0)
  BF_ScreenShotHelper.BShowSound = l_9_0
end
, 2)

