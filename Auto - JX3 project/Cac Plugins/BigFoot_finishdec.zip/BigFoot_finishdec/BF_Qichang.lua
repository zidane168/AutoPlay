-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: BF_Qichang.lua 

BF_Qichang = {}
BF_Qichangturn = false
skilltimetemp = 0
doodletimetemp = 0
skilldwPlayertemp = nil
skillradiustemp = 0
BFqichang_dwPlayer = {}
BF_qichangCount = {}
BF_qichangTempleID = {}
BF_qichangAlpha = 100
do
  local l_0_0 = {}
   -- DECOMPILER ERROR: Unhandled construct in list (SETLIST)

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Interface\\BF_Qichang\\BF_Qichang.ini", "BF_Qichang")
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "������ʾ", "\\ui\\image\\icon\\huodong_wabao_08.tga", "BigFoot_bc6765bad4840288fd9c2f6fa911ff5d")
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "EnableQichang", "��������������Χ��ʾ", false, function(l_9_0)
  BF_Qichangturn = l_9_0
end
)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "EnableQichangPK", "��������������ʾ", false, function(l_10_0, l_10_1)
  if l_10_1 and not l_10_0 then
    return 
  end
  Qichangtype = "pk"
  if not l_10_1 then
    BF_Qichang.SetConfigModle(Qichangtype)
  end
end
, 2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "EnableQichangOnlymine", "ֻ��ʾ�Լ�������Χ", false, function(l_11_0, l_11_1)
  if l_11_1 and not l_11_0 then
    return 
  end
  Qichangtype = "mine"
  if not l_11_1 then
    BF_Qichang.SetConfigModle(Qichangtype)
  end
end
, 2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "EnableQichangAll", "��ʾ��Χ�����������", true, function(l_12_0, l_12_1)
  if l_12_1 and not l_12_0 then
    return 
  end
  Qichangtype = "all"
  if not l_12_1 then
    BF_Qichang.SetConfigModle(Qichangtype)
  end
end
, 2)
   -- DECOMPILER ERROR: Overwrote pending register.

   -- DECOMPILER ERROR: Overwrote pending register.

  l_0_0("Qichangtip", "EnableQichangzhenshan", "ֻ��ʾ��ɽ��", false, function(l_13_0)
  Qichangzhenshan = l_13_0
end
, 3)
end
 -- WARNING: undefined locals caused missing assignments!

