-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: checkbutton.lua 

BFCheckButton = classv2(BFWidget)
BFCheckButton.ctor = function(l_1_0, l_1_1, l_1_2, l_1_3, l_1_4)
  l_1_0:Create(l_1_2, l_1_3)
  l_1_0:SetParent(l_1_1)
  l_1_0:SetText(l_1_4)
end

BFCheckButton.Create = function(l_2_0, l_2_1, l_2_2)
  local l_2_3 = Wnd.OpenWindow("Interface\\BF_Base\\widget\\checkbutton.ini", l_2_0:GetName())
  local l_2_4 = l_2_3:Lookup("Wnd_Main")
  assert(l_2_4, "Failed to create CheckButton widget.")
  l_2_0:SetContainer(l_2_4)
  local l_2_5 = l_2_4:Lookup("CheckBox_Main")
  local l_2_6 = l_2_5:Lookup("", "")
  local l_2_7 = l_2_6:Lookup("Text_Main")
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28 = {}
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button = l_2_5
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle = l_2_6
  l_2_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text = l_2_7
  l_2_0:SetSize(l_2_1, l_2_2)
  l_2_5.widget = l_2_0
  l_2_5.OnCheckBoxCheck = function()
    this.widget:_FireEvent("OnCheck", true)
  end
  l_2_5.OnCheckBoxUncheck = function()
    this.widget:_FireEvent("OnCheck", false)
  end
  l_2_5.OnMouseEnter = function()
    this.widget:_FireEvent("OnMouseEnter")
  end
  l_2_5.OnMouseLeave = function()
    this.widget:_FireEvent("OnMouseLeave")
  end
end

BFCheckButton.SetChecked = function(l_3_0, l_3_1)
  l_3_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Check(l_3_1)
end

BFCheckButton.IsChecked = function(l_4_0)
  local l_4_1, l_4_2 = l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:IsCheckBoxChecked, l_4_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button
  return l_4_1(l_4_2)
end

BFCheckButton.Enable = function(l_5_0)
  l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(true)
  l_5_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(255, 255, 255)
end

BFCheckButton.Disable = function(l_6_0)
  l_6_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:Enable(false)
  l_6_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetFontColor(192, 192, 192)
end

BFCheckButton.SetText = function(l_7_0, l_7_1)
  l_7_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetText(l_7_1)
end

BFCheckButton.GetText = function(l_8_0)
  local l_8_1, l_8_2 = l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:GetText, l_8_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text
  return l_8_1(l_8_2)
end

BFCheckButton.IsEnabled = function(l_9_0)
  local l_9_1, l_9_2 = l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:IsCheckBoxActive, l_9_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button
  return l_9_1(l_9_2)
end

BFCheckButton._UpdateContent = function(l_10_0)
  local l_10_1 = l_10_0:GetWidth()
  local l_10_2 = l_10_0:GetHeight()
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetSize(28, 28)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.button:SetRelPos(0, (l_10_2 - 28) / 2)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetRelPos(0, 0)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSize(l_10_1, 28)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetRelPos(30, 1)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.text:SetSize(l_10_1 - 28, 28)
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:FormatAllItemPos()
  l_10_0.BigFoot_3114845209994c70609a5b5a5c9a1c28.handle:SetSizeByAllItemSize()
end

BFCheckButton.OnCheckBoxCheck = function(l_11_0)
  l_11_0.elements.background:SetFrame(2)
end


