-- Decompiled using luadec 2.1 r80 from http://code.google.com/p/luadec
-- Command line: ~BF_ScreenShotHelper.lua 

if not BF_ScreenShotHelper then
  BF_ScreenShotHelper = {}
end
BF_ScreenShotHelper.nSteperCount = -1
BF_ScreenShotHelper.frameSelf = nil
BF_ScreenShotHelper.windowCheckBoxes = nil
BF_ScreenShotHelper.nOrgHeight = 0
BF_ScreenShotHelper.nOrgWidth = 0
BF_ScreenShotHelper.bIsOnDrag = false
BF_ScreenShotHelper.nDragAbsX = 0
BF_ScreenShotHelper.nDragAbsY = 0
BF_ScreenShotHelper.nDragTime = 0
BF_ScreenShotHelper.DelayCap = 0
BF_ScreenShotHelper.nQualityDefault = 100
BF_ScreenShotHelper.szMode = "bmp"
BF_ScreenShotHelper.BShowMessage = true
BF_ScreenShotHelper.bBmpModle = true
BF_ScreenShotHelper.bTgaModle = false
BF_ScreenShotHelper.bJpgModle = false
local l_0_0 = BF_ScreenShotHelper
local l_0_1 = {}
local l_0_2 = {}
l_0_2.bOn = true
l_0_2.szModle = "bmp"
l_0_1[1] = l_0_2
l_0_1[2], l_0_2 = l_0_2, {bOn = false, szModle = "tga"}
l_0_1[3], l_0_2 = l_0_2, {bOn = false, szModle = "jpg"}
l_0_0.tModleList = l_0_1
l_0_0 = BF_ScreenShotHelper
l_0_1 = function(l_1_0)
  if Modle == "bmp" then
    BF_ScreenShotHelper[1].bOn = true
    BF_ScreenShotHelper[2].bOn = false
    BF_ScreenShotHelper[3].bOn = false
  elseif Modle == "jpg" then
    BF_ScreenShotHelper[1].bOn = false
    BF_ScreenShotHelper[2].bOn = false
    BF_ScreenShotHelper[3].bOn = true
  elseif Modle == "tga" then
    BF_ScreenShotHelper[1].bOn = false
    BF_ScreenShotHelper[2].bOn = true
    BF_ScreenShotHelper[3].bOn = false
  end
end

l_0_0.SelectMode = l_0_1
l_0_0 = BF_ScreenShotHelper
l_0_1 = function(l_2_0, l_2_1)
  if not BF_ScreenShotHelper.enabled then
    return 
  end
  local l_2_2 = ScreenShot(l_2_0, l_2_1)
  PlaySound(SOUND.UI_SOUND, "Interface\\BF_ScreenShotHelper\\ScreenShotHelper.wav")
  if l_2_2 then
    OutputMessage("MSG_ANNOUNCE_YELLOW", g_tStrings.SCREENSHOT)
    OutputMessage("MSG_SYS", g_tStrings.SCREENSHOT_MSG .. l_2_2 .. "\n")
  end
end

l_0_0.TakeScreenshot = l_0_1
l_0_0 = Hotkey
l_0_0 = l_0_0.AddBinding
l_0_1 = "BF_ScreenShotHelper_ShowUI"
l_0_2 = "��ȡ��ͼ"
l_0_0(l_0_1, l_0_2, "��ͼ����", function()
  BF_ScreenShotHelper.TakeScreenshot(szMode, nQuality)
end
, nil)
l_0_0 = BF_ScreenShotHelper
l_0_1 = function(l_4_0)
  if l_4_0 == "bmp" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", true)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", false)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", false)
  elseif l_4_0 == "jpg" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", false)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", false)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", true)
  elseif l_4_0 == "tga" then
    BFSetModValue("ScreenShot", "EnableScreenShotBMP", false)
    BFSetModValue("ScreenShot", "EnableScreenShotTGA", true)
    BFSetModValue("ScreenShot", "EnableScreenShotJPG", false)
  end
  BFConfigPanel.ShowModPage("ScreenShot")
end

l_0_0.SetConfigModle = l_0_1
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterMod
l_0_1 = "ScreenShot"
l_0_2 = "��ͼ����"
l_0_0(l_0_1, l_0_2, "\\ui\\image\\icon\\m5yangzhou10.tga", "BigFoot_7a0f6e31f67a4d080d11408e38d3bdbf")
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShot"
l_0_0(l_0_1, l_0_2, "������ͼ����(���ڿ�ݼ����������ý�ͼ����)", true, function(l_5_0)
  BF_ScreenShotHelper.enabled = l_5_0
  if not l_5_0 then
    local l_5_1 = Station.Lookup("Normal/BF_ScreenShotHelper")
    if l_5_1 then
      l_5_1:Hide()
    end
  else
    local l_5_2 = Station.Lookup("Normal/BF_ScreenShotHelper")
  end
  if l_5_2 then
    l_5_2:Show()
    l_5_2:Hide()
  end
end
)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShotBMP"
l_0_0(l_0_1, l_0_2, "BMP��ʽ��ͼ", true, function(l_6_0, l_6_1)
  if l_6_1 and not l_6_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "bmp"
  if not l_6_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShotTGA"
l_0_0(l_0_1, l_0_2, "TGA��ʽ��ͼ", false, function(l_7_0, l_7_1)
  if l_7_1 and not l_7_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "tga"
  if not l_7_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShotJPG"
l_0_0(l_0_1, l_0_2, "JPG��ʽ��ͼ", false, function(l_8_0, l_8_1)
  if l_8_1 and not l_8_0 then
    return 
  end
  BF_ScreenShotHelper.szMode = "jpg"
  if not l_8_1 then
    BF_ScreenShotHelper.SetConfigModle(BF_ScreenShotHelper.szMode)
  end
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShotInfo"
l_0_0(l_0_1, l_0_2, "��ͼ��Ϣ", true, function(l_9_0)
  BF_ScreenShotHelper.BShowMessage = l_9_0
end
, 2)
l_0_0 = BFConfigPanel
l_0_0 = l_0_0.RegisterCheckButton
l_0_1 = "ScreenShot"
l_0_2 = "EnableScreenShotSound"
l_0_0(l_0_1, l_0_2, "������ͼ������ʾ", true, function(l_10_0)
  BF_ScreenShotHelper.BShowSound = l_10_0
end
, 2)

