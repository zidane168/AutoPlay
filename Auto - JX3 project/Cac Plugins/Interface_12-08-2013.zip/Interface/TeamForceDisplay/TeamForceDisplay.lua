TeamForceDisplay = TeamForceDisplay or {}

function TeamForceDisplay.OnFrameCreate()
	this:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
	this:RegisterEvent("PARTY_ADD_MEMBER")
	this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
	this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
	this:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
	this:RegisterEvent("SYNC_ROLE_DATA_END")
	this:RegisterEvent("TEAM_CHANGE_MEMBER_GROUP")
	this:RegisterEvent("PARTY_UPDATE_BASE_INFO")
	this:RegisterEvent("PLAYER_STATE_UPDATE")
	this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
	this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
	this:RegisterEvent("PARTY_SET_FORMATION_LEADER")
end

function TeamForceDisplay.OnEvent(event)
	local frame = Station.Lookup("Normal/Teammate")
	if not frame then return end
	if event == "UPDATE_PLAYER_SCHOOL_ID" or event == "PLAYER_STATE_UPDATE" then
		if not TeamForceDisplay.IsInMyGroup(arg0) then
			return
		end
		local hMember = TeamForceDisplay.GetMemberHandle(frame, arg0)
		if hMember then
			TeamForceDisplay.UpdateForceInfo(hMember)
		end
	elseif event == "PARTY_UPDATE_MEMBER_INFO" or event == "PARTY_SYNC_MEMBER_DATA" or event == "PARTY_ADD_MEMBER" or event == "PARTY_SET_MEMBER_ONLINE_FLAG" then
		if not TeamForceDisplay.IsInMyGroup(arg1) then
			return
		end
		local hMember = TeamForceDisplay.GetMemberHandle(frame, arg1)
		if hMember then
			TeamForceDisplay.UpdateForceInfo(hMember)
		end
	elseif event == "SYNC_ROLE_DATA_END" or event == "PARTY_UPDATE_BASE_INFO" then
		TeamForceDisplay.UptadePartyList(frame)
	elseif event == "TEAM_CHANGE_MEMBER_GROUP" then
		local hPlayer = GetClientPlayer()
		local hTeam = GetClientTeam()
		local nGroup = hTeam.GetMemberGroupIndex(hPlayer.dwID)
		if nGroup == arg1 or nGroup == arg2 then
			TeamForceDisplay.UptadePartyList(frame)
		end
	elseif event == "TEAM_AUTHORITY_CHANGED" then
		local dwID = nil
		if TeamForceDisplay.IsInMyGroup(arg2) then
			dwID = arg2
		elseif TeamForceDisplay.IsInMyGroup(arg3) then
			dwID = arg3
		end
		local hMember = TeamForceDisplay.GetMemberHandle(frame, dwID)
		if hMember then
			TeamForceDisplay.UpdateForceInfo(hMember)
		end
	elseif event == "PARTY_SET_FORMATION_LEADER" then
		if not TeamForceDisplay.IsInMyGroup(arg0) then
			return
		end
		local hMemberList = frame:Lookup("", "")
		local nCount = hMemberList:GetItemCount()
		for i = 0, nCount - 1 do
			local hMember = hMemberList:Lookup(i)
			if hMember.bFormationLeader or hMember.dwID == arg0 then
				TeamForceDisplay.UpdateForceInfo(hMember)
			end
		end
	end
end

function TeamForceDisplay.GetMemberHandle(hFrame, dwMemberID)
	local hMemberList = hFrame:Lookup("", "")
	local nCount = hMemberList:GetItemCount()
	for i = 0, nCount - 1 do
		local hMember = hMemberList:Lookup(i)
		if hMember.dwID == dwMemberID then
			return hMember
		end
	end
end

function TeamForceDisplay.UpdateForceInfo(hMember)
	if not hMember then
		return
	end

	local hTeam = GetClientTeam()
	local tMemberInfo = hTeam.GetMemberInfo(hMember.dwID)
	if tMemberInfo then
		dwKungfuID = tMemberInfo.dwMountKungfuID
	end
	local nIconID = Table_GetSkillIconID(dwKungfuID, 0)
	if nIconID and dwKungfuID ~= 10000 then
		hMember:Lookup("Image_School"):FromIconID(nIconID)
	end
end

function TeamForceDisplay.UptadePartyList(hFrame)
	local hMemberList = hFrame:Lookup("", "")
	local hPlayer = GetClientPlayer()
	if not hPlayer or not hPlayer.IsInParty() then
		return
	end

	local hTeam = GetClientTeam()
	local nGroupID = hTeam.GetMemberGroupIndex(hPlayer.dwID)
	local tGroupInfo = hTeam.GetGroupInfo(nGroupID)
	for _, dwID in pairs(tGroupInfo.MemberList) do
		local hMember = TeamForceDisplay.GetMemberHandle(hMemberList:GetRoot(), dwID)
		TeamForceDisplay.UpdateForceInfo(hMember)
	end
end

function TeamForceDisplay.IsInMyGroup(dwMemberID)
	local hPlayer = GetClientPlayer()
	if not hPlayer or not hPlayer.IsInParty() then
		return
	end

	if not hPlayer.IsPlayerInMyParty(dwMemberID) then
		return
	end

	local hTeam = GetClientTeam()
	local nMyGroup = hTeam.GetMemberGroupIndex(hPlayer.dwID)
	local nMemberGroup = hTeam.GetMemberGroupIndex(dwMemberID)
	if hTeam.IsPlayerInTeam(dwMemberID) and nMyGroup == nMemberGroup then
		return true
	end
end

Wnd.OpenWindow("Interface\\TeamForceDisplay\\TeamForceDisplay.ini", "TeamForceDisplay")
