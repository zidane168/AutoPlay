﻿xRemoteBag={

}
function xRemoteBag.m(str)
	OutputMessage("MSG_SYS", str .. "\n")
end
function xRemoteBag.OnFrameCreate()
	this:RegisterEvent("UI_SCALED")
end
function xRemoteBag.BankClick()
	local f=Station.Lookup("Normal/xRemoteBank")
	if not f then
		Wnd.OpenWindow("Interface\\xRemoteBank\\xRemoteBank.ini", "xRemoteBank")
		f=Station.Lookup("Normal/xRemoteBank")
		f:Show()
		f:BringToTop()
		xRemoteBank.InitBank(f)
	else
		Wnd.CloseWindow("xRemoteBank")
	end
	
end
function xRemoteBag.AddBankButton() --在背包界面上添加一个按钮
	local f = Station.Lookup("Normal/BigBagPanel")
	if f and f:IsVisible() then
		local btn=f:Lookup( "Btn_OpenBank")
		if not btn then --木有才添加
			local szFile="Interface\\xRemoteBank\\btn.ini"
			local fx=Wnd.OpenWindow(szFile,"xRemoteBag_BankTemp")
			if fx then
				fx:Show()
				fx:BringToTop()
				local itm=fx:Lookup("WndButton")
				if itm then
					itm:ChangeRelation(f,true,true)
					itm:SetName("Btn_OpenBank")
					itm:SetRelPos(80,6)
					itm.OnMouseEnter = function()
					local nX, nY = this:GetAbsPos()
					local nW, nH = this:GetSize()
					local szTip = GetFormatText("Mở rương từ xa\n", 101) .. GetFormatText("Nhấn vào đây để mở rương từ xa", 106)
					OutputTip(szTip, 400, {nX, nY, nW, nH})
					end
					itm.OnLButtonClick=xRemoteBag.BankClick
					itm.OnRButtonClick=xRemoteBag.BankClick
				end
			end
			Wnd.CloseWindow(fx)
		end
	end
end
function xRemoteBag.OnFrameBreathe()
	if GetLogicFrameCount() % 4 == 0 then
		xRemoteBag.AddBankButton()
	end
end
function xRemoteBag.tip(itm,str)
	local frame = Station.Lookup("Normal/BigBagPanel")
	if not itm then itm=this end
	local x, y = itm:GetAbsPos()
	local w, h = itm:GetSize()
	local szTip= "<text>text=" ..EncodeComponentsString(str).." font=101 </text>" 
	OutputTip(szTip, 400, {x, y, w, h})
end

function xRemoteBag.OnEvent(event)
	if event=="UI_SCALED" then
 	end
end

local f=Station.Lookup("Normal/xRemoteBag")
if not f then
	Wnd.OpenWindow("Interface\\xRemoteBank\\xRemoteBag.ini", "xRemoteBag")
	f=Station.Lookup("Normal/xRemoteBag")
	f:Show()
end

-----------------------------