﻿xRemoteBank={
BagMaxCount=5, --背包最大数.4个可扩充，加成自带一共5个
BankMaxCount=6,--仓库最大数，5个可扩充，加成自带一共6个
INVENTORY_INDEX_EQUIP=0,
EQUIPMENT_INVENTORY_BANK_PACKAGE1=17,
}

function xRemoteBank.OnFrameCreate()
	this:RegisterEvent("UI_SCALED")
 end
  
function xRemoteBank.OnFrameBreathe()
	if GetLogicFrameCount() % 4 == 0 then
 		local f = Station.Lookup("Normal/BigBankPanel")
 		if f and f:IsVisible() then --真正的仓库出现。。。你这个假的。。当然要消失了
 			Wnd.CloseWindow("xRemoteBank")
 		end
	end
end 
function xRemoteBank.OnEvent(event)
	if event=="UI_SCALED" then
	end
 end

-----------------------------
function xRemoteBank.BagIndexToInventoryIndex(nIndex)
	return xRemoteBank.BankMaxCount + nIndex - 1
end

function xRemoteBank.InventoryIndexToBagIndex(nIndex)
	return nIndex - xRemoteBank.BankMaxCount + 1
end
function xRemoteBank.GetBankSize()
	local dwSize = 0
	local player = GetClientPlayer()
	for i = 1, 6, 1 do
		local dwSizeT = player.GetBoxSize(xRemoteBank.BagIndexToInventoryIndex(i))--背包最大一共5个。装备4人。自带1个。SO。仓库是从第6个开始。
		dwSize = dwSize + dwSizeT
	end
	return dwSize
end

function xRemoteBank.UpdateBagCount(box)
		local player = GetClientPlayer()
		local dwSize = player.GetBoxSize(box.nInventoryIndex)
		local dwSizeFree = player.GetBoxFreeRoomSize(box.nInventoryIndex)
		if true then--if xRemoteBank.bCompact then  --能省点事省点事~
			if not dwSize or dwSize == 0 then
				box:SetOverText(0, "")
			else
				box:SetOverText(0, (dwSize - dwSizeFree).."/"..dwSize)
			end
		end
end
function xRemoteBank.UpdateItem(box)
	local player = GetClientPlayer()
	local item = GetPlayerItem(player, box.dwBox, box.dwX)
	UpdataItemBoxObject(box, box.dwBox, box.dwX, item)
	if box:IsObjectMouseOver() then
		local thisSave = this
		this = box
		xRemoteBank.m("debug??1")
	--	xRemoteBank.OnItemMouseEnter()
		this = thisSave
	end	
end
function xRemoteBank.UpdateBag(box)
	local player = GetClientPlayer()
	if box.nBagIndex == 1 then
		box:SetObject(UI_OBJECT_NOT_NEED_KNOWN, box.nBagIndex)
		box:SetObjectIcon(374)
	else
		local item = GetPlayerItem(player, box.dwBox, box.dwX)
		UpdataItemBoxObject(box, box.dwBox, box.dwX, item)
	end
		box:SetObjectSelected(true)--xRemoteBank.aOpen[box.nBagIndex] 通通展开~
		xRemoteBank.UpdateBagCount(box)
end
function xRemoteBank.UpdateTotalBagCount(frame)
	local text = frame:Lookup("", "Text_Title")
	if true then
		local dwSize, dwFreeSize = 0, 0
		local player = GetClientPlayer()
		for i = 1, xRemoteBank.BankMaxCount, 1 do
			local nIndex = xRemoteBank.BagIndexToInventoryIndex(i)
			local dw1 = player.GetBoxSize(nIndex)
			if dw1 and dw1 ~= 0 then
				dwSize = dwSize + dw1
				local dw2 = player.GetBoxFreeRoomSize(nIndex)
				dwFreeSize = dwFreeSize + dw2
			end
		end
		if dwSize == 0 then
			text:SetText("Kho")
		else
			text:SetText("Kho từ xa" .. "("..(dwSize - dwFreeSize).."/"..dwSize..")")
		end
 	end
end

function xRemoteBank.InitBank(frame)
	frame.bDisable = true
	
	local player = GetClientPlayer()
	local aOpen = {true, true, true, true, true, true}
	
	local wB, wS = 42, 1 --格子背景宽度，格子跟背景的缩进缩进
	local nW = 10	--一行拥有的格子数量
	local nSize = xRemoteBank.GetBankSize()
	local nLine = math.ceil(nSize / nW)
	if nLine > 12 then
		nW = math.ceil(nSize / 12)
	end
		
	local wBox = wB - 2 * wS --格子宽度
	local wAll = wB * nW
	if wAll < 313 then
		wAll = 313
	end
	
	local wBB = 42
	local nBagCount = player.GetBankPackageCount()
	local btnBuy = frame:Lookup("Btn_Buy")
	if nBagCount >=xRemoteBank.BankMaxCount then
		btnBuy:Hide()
	else
		btnBuy:Show()
		btnBuy:SetSize(wBB, wBB)
		btnBuy:SetRelPos(13 + (nBagCount + 1) * wBB, 58)
	end
	local handle = frame:Lookup("", "")
	for i = 1, xRemoteBank.BankMaxCount, 1 do
		local img = handle:Lookup("Image_BagBox"..i)
		local box = handle:Lookup("Box_Bag"..i)
		
		local x = 13 + (i - 1) * wBB
		local y = 58
		img:SetSize(wBB + 2, wBB + 2)
		img:SetRelPos(x, y)
		box:SetSize(wBB - 2 * wS, wBB - 2 * wS)
		box:SetRelPos(x + wS, y + wS)
		
		box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
		box:SetOverTextFontScheme(0, 15)
		box.bBag = true
		box.nBagIndex = i
		box.nInventoryIndex = xRemoteBank.BagIndexToInventoryIndex(i)
		if i ~= 1 then
			box.dwBox = xRemoteBank.INVENTORY_INDEX_EQUIP
			box.dwX = xRemoteBank.EQUIPMENT_INVENTORY_BANK_PACKAGE1 + i - 2
			if i <= nBagCount + 1 then
				box:Show()
				img:Show()
			else
				box:Hide()
				img:Hide()
			end
		end
		xRemoteBank.UpdateBag(box)
	end
	
	local hBg = handle:Lookup("Handle_BG")
	local hBox = handle:Lookup("Handle_Box")
	local bAdd = false
	local nIndex = 0
	local x, y = 16, 66 + wBB
	for i = 1, xRemoteBank.BankMaxCount, 1 do
		local dwBox = xRemoteBank.BagIndexToInventoryIndex(i)
		local dwSize = player.GetBoxSize(dwBox)
		
		local img = handle:Lookup("Image_Bg"..i)
		local imgB = handle:Lookup("Image_BgB"..i)
		local textB = handle:Lookup("Text_Bag"..i)
		local check = frame:Lookup("CheckBox_C"..i)
		img:SetSize(0,0)
		img:SetRelPos(0,0)
		img:Hide()
		imgB:SetSize(0,0)
		imgB:SetRelPos(0,0)
		imgB:Hide()
		textB:SetSize(0,0)
		textB:SetRelPos(0,0)
		textB:Hide()
		check:Hide()
		
		
		local aFrame = {29, 28, 13, 27}
		local nBT =0--- GetBagContainType(dwBox) 别多事。。就这样吧。
		local nFrame = aFrame[nBT] or 13
		dwSize = dwSize - 1
		for dwX = 0, dwSize, 1 do
			local img = hBg:Lookup(nIndex)
			if not img then
				hBg:AppendItemFromString("<image>w=48 h=48 path=\"ui/Image/LootPanel/LootPanel.UITex\" frame=13 lockshowhide=1 </image>")
				img = hBg:Lookup(nIndex)
			end
			local box = hBox:Lookup(nIndex)
			if not box then
				hBox:AppendItemFromString("<box>w=44 h=44 eventid=524607 lockshowhide=1 </box>")
				box = hBox:Lookup(nIndex)
			end
			img:SetFrame(nFrame)
			img:Show()
			box:Show()
			box:SetName(dwBox.."_"..dwX)
			img:SetSize(wB, wB)
			img:SetRelPos(x, y)
			box:SetSize(wBox, wBox)
			box:SetRelPos(x + wS - 1, y + wS - 1)

			box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
			box:SetOverTextFontScheme(0, 15)
			box.dwBox = dwBox
			box.dwX = dwX
			
			xRemoteBank.UpdateItem(box)
			
			if nIndex % nW == nW - 1 then
				x, y = 16, y + wB + 2
				bAdd = false
			else
				x = x + wB
				bAdd = true
			end
			
			nIndex = nIndex + 1
		end
	end
	
	if bAdd then
		x, y = 16, y + wB + 2
	end	
		
	hBox.nCount = nIndex
	local nCount = hBox:GetItemCount() - 1
	for i = nIndex, nCount, 1 do
		local img = hBg:Lookup(i)
		local box = hBox:Lookup(i)
		img:Hide()
		img:SetRelPos(0, 0)
		img:SetSize(0, 0)
		box:Hide()
		box:SetRelPos(0, 0)
		box:SetSize(0, 0)
	end
	hBg:FormatAllItemPos()
	hBg:SetSizeByAllItemSize()
	hBox:FormatAllItemPos()
	hBox:SetSizeByAllItemSize()
	
	frame:Lookup("Btn_CU"):SetRelPos(15, y + 8)
	frame:Lookup("Btn_Close"):SetRelPos(wAll - 10, 8)
	
	local xM, yM = wAll - 150, y + 10
	handle:Lookup("Image_Gold"):SetRelPos(xM + 66, yM)
	handle:Lookup("Image_Silver"):SetRelPos(xM + 106, yM)
	handle:Lookup("Image_Copper"):SetRelPos(xM + 144, yM)
	handle:Lookup("Text_Gold"):SetRelPos(xM, yM)
	handle:Lookup("Text_Silver"):SetRelPos(xM + 86, yM)
	handle:Lookup("Text_Copper"):SetRelPos(xM + 124, yM)
	
	handle:Lookup("Text_Title"):SetRelPos(wAll / 2 - 20, 6)
	
	handle:Lookup("Image_Bg1C"):SetSize(wAll - 311, 52)
	handle:Lookup("Image_Bg2L"):SetSize(8, y - 88)
	handle:Lookup("Image_Bg2C"):SetSize(wAll + 14, y - 88)
	handle:Lookup("Image_Bg2R"):SetSize(8, y - 88)
	handle:Lookup("Image_Bg3C"):SetSize(wAll - 102, 85)
	
	handle:FormatAllItemPos()
	handle:SetSizeByAllItemSize()
	local w, h = handle:GetSize()
	frame:SetSize(w, h)
	--CorrectAutoPosFrameAfterClientResize()
	xRemoteBank.UpdateTotalBagCount(frame)
	frame:Lookup("CheckBox_Compact"):Check(true)
	frame.bDisable = false
end


function xRemoteBank.OnItemLButtonDown()
	local szName = this:GetName()
	if szName == "Image_Bg1" then
		return
	elseif szName == "Image_Bg2" then
		return
	elseif szName == "Image_Bg3" then
		return
	elseif szName == "Image_Bg4" then
		return
	elseif szName == "Image_Bg5" then
		return
	elseif szName == "Image_Bg6" then
		return
	elseif szName == "Image_Bg7" then
		return
	end
	this.bIgnoreClick = nil
	if IsCtrlKeyDown() and not this:IsEmpty() and this.dwBox and this.dwX then
			EditBox_AppendLinkItem(this.dwBox, this.dwX)
		this.bIgnoreClick = true
	end
	this:SetObjectStaring(false)
	this:SetObjectPressed(1)
end
function xRemoteBank.OnItemLButtonUp()
	this:SetObjectPressed(0)
end


function xRemoteBank.OnItemMouseEnter()
	this:SetObjectMouseOver(1)
	if not this:IsEmpty() then
		local x, y = this:GetAbsPos()
		local w, h = this:GetSize()
		if this.bBag and this.nBagIndex == 1 then
			local player = GetClientPlayer()
			local szTip = "<text>text="..EncodeComponentsString(g_tStrings.BANK).." font=60 "..GetItemFontColorByQuality(1, true)..
				" </text><text>text="..EncodeComponentsString(g_tStrings.BANK_FIXED1).." font=106 </text><text>text="
				..EncodeComponentsString(FormatString(g_tStrings.STR_ITEM_H_BAG_SIZE, player.GetBoxSize(this.nInventoryIndex))).."font=106</text>"
			OutputTip(szTip, 335, {x, y, w, h})
		else
			local _, dwBox, dwX = this:GetObjectData()
			OutputItemTip(UI_OBJECT_ITEM, dwBox, dwX, nil, {x, y, w, h})
		end		
	end
---只处理鼠标悬停。。。。
end

 
function xRemoteBank.OnItemMouseLeave()
	this:SetObjectMouseOver(0)
	HideTip()
	
	if UserSelect.IsSelectItem() then
		UserSelect.SatisfySelectItem(-1, -1, true)
		return
	end
	
	if Cursor.GetCurrentIndex() == CURSOR.UNABLESPLIT then
		Cursor.Switch(CURSOR.SPLIT)
	elseif Cursor.GetCurrentIndex() == CURSOR.UNABLEREPAIRE then
		Cursor.Switch(CURSOR.REPAIRE)
	elseif not IsCursorInExclusiveMode() then
		Cursor.Switch(CURSOR.NORMAL)
	end
end

function xRemoteBank.OnLButtonClick()
	local szName = this:GetName()
	if szName == "Btn_Close" then
		Wnd.CloseWindow("xRemoteBank")
	end
end