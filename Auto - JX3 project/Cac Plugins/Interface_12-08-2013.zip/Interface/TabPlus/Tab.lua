﻿------------------------------------------------
-- TabPlus原作者 	:  南宫临风、星岩
-- 修改人    			:  风千与
-- 修改时间  			:  2013-5-09
-- 用途(模块)			:  Tab增强
-- 版本       		： 0.80
------------------------------------------------

local playerlist = {}
local npclist = {}

TabPlus={time=0,index=0}
function GetNestId(OptData)
	local player=GetClientPlayer()
	local PnX=player.nX
	local PnY=player.nY
	local tX
	local tY
	local nFace=player.nFaceDirection
	local list={}
	local PtX
	local PtY
	local haveBUFF=0
	local haveEnemyPlayer=0
	local isnoname=0
	for v,_ in pairs(playerlist) do
		local tplayer=GetPlayer(v)
		if IsEnemy(player.dwID,v) and tplayer.nCurrentLife>0 then
			haveEnemyPlayer=haveEnemyPlayer+1
			if haveEnemyPlayer~=0 then
		    PtX=tplayer.nX
			 	PtY=tplayer.nY
				local PnTwoA =TarAngle(PnX,PnY,PtX,PtY)
				if TabOpt.OptData.ChkNFace then
					if PTangle(nFace,PnTwoA)<=TabOpt.OptData.TxtJD/2 then
						local ndistance=GetCharacterDistance(v,player.dwID)
						local nLife=tplayer.nCurrentLife/tplayer.nMaxLife
						if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
						if TabOpt.OptData.ChkXGJL~=true then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
					end
				else
					local ndistance=GetCharacterDistance(v,player.dwID)
					local nLife=tplayer.nCurrentLife/tplayer.nMaxLife
					if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
						list[#list+1]={id=v,distance=ndistance,life=nLife}
					end
					if TabOpt.OptData.ChkXGJL~=true then
						list[#list+1]={id=v,distance=ndistance,life=nLife}
					end
				end
			end
		end
	end
	if TabOpt.OptData.ChkPlayer and haveEnemyPlayer~=0 then
		for v,_ in pairs(npclist) do
			isnoname=0
			local npc=GetNpc(v)
			if TabOpt.OptData.ChkNONAME and TabOpt.OptData.TxtNONAME~="" then
				local nonamelist=split(TabOpt.OptData.TxtNONAME, ";",1)
				for _,b in pairs(nonamelist) do
					if npc.szName==b then
						isnoname=isnoname+1
					end
				end
			end	
			if IsEnemy(player.dwID,v) and GetNpcIntensity(npc)>2 then
				tX=npc.nX
				tY=npc.nY
				local nTwoA=TarAngle(PnX,PnY,tX,tY)
				if TabOpt.OptData.ChkNFace then
					if PTangle(nFace,nTwoA)<=TabOpt.OptData.TxtJD/2 then
						local ndistance=GetCharacterDistance(v,player.dwID)
						local nLife=npc.nCurrentLife/npc.nMaxLife
						if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
							if TabOpt.OptData.ChkNONAME and isnoname==0 then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
							if TabOpt.OptData.ChkNONAME~=true then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end	
						end									
						if TabOpt.OptData.ChkXGJL~=true then
							if TabOpt.OptData.ChkNONAME and isnoname==0 then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
							if TabOpt.OptData.ChkNONAME~=true then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
						end
					end			
				else
					local ndistance=GetCharacterDistance(v,player.dwID)
					local nLife=npc.nCurrentLife/npc.nMaxLife
					if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
						if TabOpt.OptData.ChkNONAME and isnoname==0 then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
						if TabOpt.OptData.ChkNONAME~=true then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
					end
					if TabOpt.OptData.ChkXGJL~=true then
						if TabOpt.OptData.ChkNONAME and isnoname==0 then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
						if TabOpt.OptData.ChkNONAME~=true then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
					end
				end
			end
		end
	else
		for v,_ in pairs(npclist) do
			isnoname=0
			local npc=GetNpc(v)
			if TabOpt.OptData.ChkNONAME and TabOpt.OptData.TxtNONAME~="" then
				local nonamelist=split(TabOpt.OptData.TxtNONAME, ";",1)
				for _,b in pairs(nonamelist) do
					if npc.szName==b then
						isnoname=isnoname+1
					end
				end
			end	
			if IsEnemy(player.dwID,v) then
				tX=npc.nX
				tY=npc.nY
				local nTwoA=TarAngle(PnX,PnY,tX,tY)
				if TabOpt.OptData.ChkNFace then
					if PTangle(nFace,nTwoA)<=TabOpt.OptData.TxtJD/2 then
						local ndistance=GetCharacterDistance(v,player.dwID)
						local nLife=npc.nCurrentLife/npc.nMaxLife
						if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
							if TabOpt.OptData.ChkNONAME and isnoname==0 then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
							if TabOpt.OptData.ChkNONAME~=true then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end	
						end									
						if TabOpt.OptData.ChkXGJL~=true then
							if TabOpt.OptData.ChkNONAME and isnoname==0 then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
							if TabOpt.OptData.ChkNONAME~=true then
								list[#list+1]={id=v,distance=ndistance,life=nLife}
							end
						end	
					end
				else
					local ndistance=GetCharacterDistance(v,player.dwID)
					local nLife=npc.nCurrentLife/npc.nMaxLife
					if TabOpt.OptData.ChkXGJL and ndistance<=TabOpt.OptData.TxtXGJL*64 then
						if TabOpt.OptData.ChkNONAME and isnoname==0 then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
						if TabOpt.OptData.ChkNONAME~=true then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
					end
					if TabOpt.OptData.ChkXGJL~=true then
						if TabOpt.OptData.ChkNONAME and isnoname==0 then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
						if TabOpt.OptData.ChkNONAME~=true then
							list[#list+1]={id=v,distance=ndistance,life=nLife}
						end
					end
				end
			end	
		end
	end

	if IsEmpty(list) then
		return
	end
	if TabOpt.OptData.ChkLife then
		table.sort(list,function(left,right) return left.life<right.life end)
	else
		table.sort(list,function(left,right) return left.distance<right.distance end)
  end
	local tabtime
--	local nRunSpeed = KeepOneByteFloat(player.nRunSpeed * 16 / 64)
--	OutputMessage("MSG_SYS","跑速："..nRunSpeed.."nRunSpeed:"..player.nRunSpeed.."\n")
	if player.nRunSpeed>26 then
		tabtime=300
	else
		tabtime=700
	end

	if TabPlus.time~=0 and GetTime()-TabPlus.time<tabtime then
	    local tabplusID=TabPlus.index
		TabPlus.index=TabPlus.index+1
	else
		TabPlus.index=1
		TabPlus.time=GetTime()
	end
--	Moon_SetTarget(list[TabPlus.index].id)
	if IsPlayer(list[TabPlus.index].id) then
		SetTarget(TARGET.PLAYER, list[TabPlus.index].id)
	else
		SetTarget(TARGET.NPC, list[TabPlus.index].id)
	end
end

function TarAngle(nOX, nOY, nX, nY)
	local fPI = math.pi
	local fTwoPi = math.pi * 2
  local NnOX=0
	local NnOY=0
	local NnX=nX-nOX
	local NnY=nY-nOY
	local nDist = (NnX ^ 2 + NnY ^ 2) ^ 0.5
	if nDist == 0 then
		return -1
	end
	local nAngle = math.asin(math.abs(NnY) / nDist)
	if NnX>=0 and NnY>=0 then
	nAngle =nAngle
	elseif NnX<0 and NnY>=0 then
	nAngle =fPI-nAngle
	elseif NnX<0 and NnY<0 then
	nAngle =fPI+nAngle
	elseif NnX>=0 and NnY<0 then
	nAngle =fTwoPi-nAngle
	end
	return nAngle*180/fPI
end
function PTangle (PnFace,Tangle)
	local PTA=math.abs(Tangle-PnFace/256*360)
	if PTA>=180 then
		PTA=360-PTA
	end
		return PTA
end
function split(szFullString, szSeparator,nindex)
    nindex=nindex or 1
    local nFindStartIndex = 1
    local nSplitIndex = 1
    local nSplitArray = {}
    while true do
        local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
        if not nFindLastIndex then
            nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
            break
        end
        nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
        nFindStartIndex = nFindLastIndex + nindex
        nSplitIndex = nSplitIndex + 1
    end
    return nSplitArray
end

RegisterEvent("PLAYER_ENTER_SCENE", function() playerlist[arg0]=0 end)
RegisterEvent("PLAYER_LEAVE_SCENE",function() playerlist[arg0]=nil end)
RegisterEvent("NPC_ENTER_SCENE",function() npclist[arg0]=0 end)
RegisterEvent("NPC_LEAVE_SCENE",function() npclist[arg0]=nil end)




