﻿------------------------------------------------
-- ui原作者  :  insou、星岩
-- 修改人    :  风千与
-- 修改时间  :  2013-05-10
-- 用途(模块):  窗口创建及控制
--版本       ：	0.80
------------------------------------------------

TabOpt={}

TabOpt.OptData={
ChkNFace=true;
ChkLife=false;
ChkPlayer=false;
ChkXGJL=false;
ChkNONAME=false;
TxtXGJL="30";
TxtJD="180";
TxtNONAME="";
--ChkYXWJ=true;
}

RegisterCustomData("TabOpt.OptData")

function TabOpt.InitTab() --设置界面初始化
	local frame=Station.Lookup("Normal/TabOpt")
	frame:Lookup("", "Text_Title"):SetText("TabPlus_0.80")
	frame:Lookup("", "Text_CopyRightRemark"):SetText("fb.com/bunhin")
	frame:Lookup("", "Text_CopyRight"):SetText("Tác giả : Tàu")
	frame:Lookup("", "Text_CopyRightTwo"):SetText("Dịch giả : VN")
	local handle = frame:Lookup("PageSet_Main/Page_TabSet")
	handle:Lookup("CheckBox_NFace", "Text_NFace"):SetText("Xa")
	handle:Lookup("Edit_JD"):SetText(TabOpt.OptData.TxtJD or "180")
	handle:Lookup("CheckBox_Life", "Text_Life"):SetText("Ưu tiên máu thấp")
    handle:Lookup("CheckBox_Player", "Text_Player"):SetText("Ưu tiên người(PVP)")
	handle:Lookup("CheckBox_XGJL", "Text_XGJL"):SetText("Gần")
	handle:Lookup("CheckBox_NONAME", "Text_NONAME"):SetText("Không chọn :")
--  	handle:Lookup("CheckBox_YXWJ", "Text_YXWJ"):SetText("Cái đệt")
	handle:Lookup("CheckBox_XGJL"):Check(TabOpt.OptData.ChkXGJL or false)
	handle:Lookup("CheckBox_NFace"):Check(TabOpt.OptData.ChkNFace or false)
	handle:Lookup("CheckBox_Life"):Check(TabOpt.OptData.ChkLife or false)
	handle:Lookup("CheckBox_Player"):Check(TabOpt.OptData.ChkPlayer or false)
	handle:Lookup("CheckBox_NONAME"):Check(TabOpt.OptData.ChkNONAME or false)
	handle:Lookup("Edit_XGJL"):SetText(TabOpt.OptData.TxtXGJL or "35")
	handle:Lookup("Edit_NONAME"):SetText(TabOpt.OptData.TxtNONAME or "")
--	handle:Lookup("CheckBox_YXWJ"):Check(TabOpt.OptData.ChkYXWJ or false)
end

function TabOpt.InitNONE() --设置界面初始化无
end

function TabOpt.OnFrameCreate()
		TabOpt.InitTab()
	InitFrameAutoPosInfo(this, 0.5, nil, nil, function() TabOpt.CloseSetWnd() end)
end

function TabOpt.OnFrameBreathe()
end

function TabOpt.OnLButtonClick()
end

function TabOpt.OnCheckBoxCheck()
	local szName = this:GetName()
	if szName=="CheckBox_NFace" then
		TabOpt.OptData.ChkNFace=true
	elseif szName=="CheckBox_Life" then
		TabOpt.OptData.ChkLife=true
	elseif szName=="CheckBox_Player" then
		TabOpt.OptData.ChkPlayer=true
	elseif szName=="CheckBox_XGJL" then
		TabOpt.OptData.ChkXGJL=true
	elseif szName=="CheckBox_NONAME" then
		TabOpt.OptData.ChkNONAME=true
--	elseif szName=="CheckBox_YXWJ" then
--		TabOpt.OptData.ChkYXWJ=true
		end

end


function TabOpt.OnCheckBoxUncheck()
	local szName = this:GetName()
	if szName=="CheckBox_NFace" then
		TabOpt.OptData.ChkNFace=false
	elseif szName=="CheckBox_Life" then
		TabOpt.OptData.ChkLife=false
	elseif szName=="CheckBox_Player" then
		TabOpt.OptData.ChkPlayer=false
	elseif szName=="CheckBox_XGJL" then
		TabOpt.OptData.ChkXGJL=false
	elseif szName=="CheckBox_NONAME" then
		TabOpt.OptData.ChkNONAME=false
--	elseif szName=="CheckBox_YXWJ" then
--		TabOpt.OptData.ChkYXWJ=false
		end
end

function TabOpt.OnEditChanged()
local frame=Station.Lookup("Normal/TabOpt")
local handle = frame:Lookup("PageSet_Main/Page_TabSet")
local szName = this:GetName()
	if szName=="Edit_XGJL" then
		TabOpt.OptData.TxtXGJL=handle:Lookup("Edit_XGJL"):GetText()
	elseif szName=="Edit_JD" then
	    TabOpt.OptData.TxtJD=handle:Lookup("Edit_JD"):GetText()
	elseif szName=="Edit_NONAME" then
	    TabOpt.OptData.TxtNONAME=handle:Lookup("Edit_NONAME"):GetText()
	end
end

function TabOpt.OpenSetWnd()
	 local frame = Station.Lookup("Normal/TabOpt")
	   if not frame then
			   frame = Wnd.OpenWindow("Interface\\TabPlus\\Tab_Options.ini", "TabOpt")
	  end
	frame:Show()
end

function TabOpt.CloseSetWnd()
	local frame = Station.Lookup("Normal/TabOpt")
	if frame and frame:IsVisible() then
		Wnd.CloseWindow("TabOpt")
	end
end

function IsTabOptOpened()
	local frame = Station.Lookup("Normal/TabOpt")
	if frame and frame:IsVisible() then
		return true
	end
	return false
end

function OpenOrClose()
if not IsTabOptOpened() then
	TabOpt.OpenSetWnd()
else
	TabOpt.CloseSetWnd()
end
end
function TabOpt.OnLButtonClick()
	local szName = this:GetName()
	if szName == "Btn_Close" then
		TabOpt.CloseSetWnd()
	end
end
function CastTab()
	GetNestId(TabOpt.OptData)
end



Hotkey.AddBinding("TabPlus","TabPlus cài đặt nâng cao","TabPlus",OpenOrClose,nil)
Hotkey.AddBinding("CastTab", "TabPlus", "",CastTab,nil)

OutputMessage("MSG_SYS","=====TabPlus_V0.80=====\n")
OutputMessage("MSG_SYS",">May.09,2013\n")
OutputMessage("MSG_SYS",">By Tàu khựa\n")
OutputMessage("MSG_SYS","★Dịch giả việt nam★\n")
OutputMessage("MSG_SYS","(http://facebook.com/bunhin/)\n")
OutputMessage("MSG_SYS","=======================\n")
