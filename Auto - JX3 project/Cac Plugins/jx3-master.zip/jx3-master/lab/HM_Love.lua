--
-- �������������������ȱ��Ե
--
HM_Love = {
	bQuiet = false		-- �����
}
HM.RegisterCustomData("HM_Love")

---------------------------------------------------------------------
-- ���غ����ͱ���
---------------------------------------------------------------------
local _HM_Love = {
	dwAvatar = 0,	-- ��Եͷ��
	dwLover = 0,	-- ��Ե ID
	szLover = "<--��-->",		-- ��Ե����
	nRoleType = 0,	-- ��Ե���ͣ������ڣ�
	nPrivacy = 2,		-- ��Ե��ʾģʽ��0�����ܣ�1�����ѿɼ���2��ȫ���ɼ���
	szSign = "",		-- ����ǩ��
	tOther = {},		-- �����˵����ݣ�����lover��avatar��sign, roletype��
}

-- ����ͷ������
_HM_Love.tForceAvatar = {
	[0] = "jianghu",
	[1] = "shaolin",
	[2] = "wanhua",
	[3] = "tiance",
	[4] = "chunyang",
	[5] = "qixiu",
	[6] = "wudu",
	[7] = "tangmen",
	[8] = "cangjian",
	[9] = "gaibang",
	[10] = "mingjiao",
}

-- ���ͷ���ļ���֡�ε�
_HM_Love.GetAvatarInfo = function(dwAvatar, nRoleType)
	local avatar = g_tTable.RoleAvatar:Search(dwAvatar)
	if avatar then
		if nRoleType == ROLE_TYPE.STANDARD_MALE then
			return avatar.szM2Image, avatar.nM2ImgFrame, avatar.bAnimate
		elseif nRoleType == ROLE_TYPE.STANDARD_FEMALE then
			return avatar.szF2Image, avatar.nF2ImgFrame, avatar.bAnimate
		elseif nRoleType == ROLE_TYPE.STRONG_MALE then
			return avatar.szM3Image, avatar.nM3ImgFrame, avatar.bAnimate
		elseif nRoleType == ROLE_TYPE.SEXY_FEMALE then
			return avatar.szF3Image, avatar.nF3ImgFrame, avatar.bAnimate
		elseif nRoleType == ROLE_TYPE.LITTLE_BOY then
			return avatar.szM1Image, avatar.nM1ImgFrame, avatar.bAnimate
		elseif nRoleType == ROLE_TYPE.LITTLE_GIRL then
			return avatar.szF1Image, avatar.nF1ImgFrame, avatar.bAnimate
		end
	end
end

-- �����������
_HM_Love.SaveFellowRemark = function(id, remark)
	Wnd.CloseWindow("PartyPanel")
	local frame = Wnd.OpenWindow("PartyPanel")
	local page = frame:Lookup("Wnd_FriendInfo")
	if not page then return end
	local edit = page:Lookup("Edit_Name")
	if not edit then return end
	page.dwID = id
	Station.SetFocusWindow(edit)
	edit:SetLimit(128)
	edit:SetText(remark)
	Station.SetFocusWindow(frame)
	Wnd.CloseWindow("PartyPanel")
end

-- �ж� ID �Ƿ�Ϊ�ҵĺ���
_HM_Love.IsMyFellow = function(id)
	local me = GetClientPlayer()
	local aGroup = me.GetFellowshipGroupInfo() or {}
	table.insert(aGroup, 1, {id = 0, name = g_tStrings.STR_FRIEND_GOOF_FRIEND})
	for _, v in ipairs(aGroup) do
		local aFriend = me.GetFellowshipInfo(v.id) or {}
		for _, vv in ipairs(aFriend) do
			if vv.id == id then
				return true
			end
		end
	end
	return false
end

-- ����ֵ�������ݵ����ѱ�ע���ɹ� true��ʧ�� false��
-- FIXME��ͨ�� ID ��������ʱ���ܻḲ������������������ݣ�����
_HM_Love.SetFellowDataByKey = function(szKey, szData, dwID)
	local szKey, me, slot = "#HM#" .. szKey .. "#", GetClientPlayer(), nil
	local aGroup = me.GetFellowshipGroupInfo() or {}
	table.insert(aGroup, 1, { id = 0, name = g_tStrings.STR_FRIEND_GOOF_FRIEND })
	for _, v in ipairs(aGroup) do
		local aFriend = me.GetFellowshipInfo(v.id) or {}
		for i = #aFriend, 1, -1 do
			local info = aFriend[i]
			local bMatch = string.sub(info.remark, 1, string.len(szKey)) == szKey
			if not szData then
				-- fetch data
				if bMatch then
					return string.sub(info.remark, string.len(szKey) + 1), info
				end
			elseif not dwID then
				-- set by Key
				if bMatch then
					_HM_Love.SaveFellowRemark(info.id, szKey .. szData)
					return true, info
				end
				-- find slot
				if not slot and info.attraction < 800 and string.sub(info.remark, 1, 4) ~= "#HM#" then
					slot = info
				end
			else
				-- set by ID (unique key)
				if dwID == info.id then
					slot = info
				elseif bMatch then
					_HM_Love.SaveFellowRemark(info.id, " ")
				end
			end
		end
	end
	-- last result
	if szData then
		if slot then
			_HM_Love.SaveFellowRemark(slot.id, szKey .. szData)
			return true, slot
		else
			return false, nil
		end
	end
end

-- ����ֵ�Ӻ��ѱ�ע����ȡ���ݣ��ɹ��������� + rawInfo��ʧ�� nil��
_HM_Love.GetFellowDataByKey = function(szKey)
	return _HM_Love.SetFellowDataByKey(szKey, nil, nil)
end

-- ������Ե��Ϣ������
_HM_Love.ToLocalLover = function(aInfo)
	_HM_Love.dwAvatar = aInfo.miniavatar
	_HM_Love.dwLover = aInfo.id
	_HM_Love.szLover = aInfo.name
	_HM_Love.nRoleType = aInfo.roletype
	if aInfo.miniavatar == 0 then
		_HM_Love.dwAvatar = 0 - aInfo.forceid
	end
end

-- ����Ϊ��Ե
_HM_Love.SetLover = function(dwID, szName)
	if _HM_Love.dwLover ~= dwID then
		if dwID == 0 then
			_HM_Love.SaveFellowRemark(_HM_Love.dwLover, " ")
			_HM_Love.dwLover = dwID
			_HM_Love.szLover = szName
			_HM_Love.nRoleType = 0
		else
			local _, info = _HM_Love.SetFellowDataByKey("LOVER", tostring(_HM_Love.nPrivacy), dwID)
			_HM_Love.ToLocalLover(info)
			if _HM_Love.nPrivacy ~= 0 then
				HM.Talk(PLAYER_TALK_CHANNEL.TONG, "#õ�� �������ҵ��Ķ���Ե�� [" .. szName .. "] #�ƻ�")
			end
		end
		if _HM_Love.ui then
			_HM_Love.ui:Fetch("Combo_Lover"):Text(szName)
		end
	end
end

-- ��ȡ����Ե�����б�
_HM_Love.GetLoverMenu = function()
	local m0 = {{
		szOption = "<--��-->", bCheck = true, bMCheck = true, bChecked = _HM_Love.dwLover == 0,
		fnAction = function(d, b)
			_HM_Love.SetLover(0, "<--��-->")
		end
	}}
	local me = GetClientPlayer()
	local aGroup = me.GetFellowshipGroupInfo() or {}
	table.insert(aGroup, 1, {id = 0, name = g_tStrings.STR_FRIEND_GOOF_FRIEND})
	for _, v in ipairs(aGroup) do
		local aFriend = me.GetFellowshipInfo(v.id) or {}
		for _, vv in ipairs(aFriend) do
			if vv.attraction >= 800 then
				table.insert(m0, {
					szOption = vv.name, bCheck = true, bMCheck = true, bChecked = _HM_Love.dwLover == vv.id,
					fnAction = function(d, b)
						_HM_Love.SetLover(vv.id, vv.name)
					end
				})
			end
		end
	end
	return m0
end

-- ������˽����
_HM_Love.SetPrivacy = function(nPrivacy)
	if nPrivacy ~= _HM_Love.nPrivacy and _HM_Love.dwLover ~= 0 then
		_HM_Love.nPrivacy = nPrivacy
		_HM_Love.SetFellowDataByKey("LOVER", tostring(nPrivacy), _HM_Love.dwLover)
	end
end

-- �����������
_HM_Love.LoadData = function()
	if _HM_Love.bLoaded then return end
	_HM_Love.bLoaded = true
	-- �Ķ���Ե
	local szData, aInfo = _HM_Love.GetFellowDataByKey("LOVER")
	if szData then
		_HM_Love.nPrivacy = tonumber(szData) or 0
		_HM_Love.ToLocalLover(aInfo)
		if aInfo.mapid ~= 0 then
			local szMsg = "���ѣ������Ķ���Ե <link 0> Ŀǰ���� [" .. Table_GetMapName(aInfo.mapid) .. "] ��ͼ���ء�\n"
			_HM_Love.OnLoverMsg(szMsg)
		end
	end
	-- ����ǩ��1
	local szData, _ = _HM_Love.GetFellowDataByKey("S1")
	if szData then
		_HM_Love.szSign = szData
		-- ����ǩ��2
		local szData, _ = _HM_Love.GetFellowDataByKey("S2")
		if szData then
			_HM_Love.szSign = _HM_Love.szSign .. szData
		end
	end
end

-- ����ǩ��
_HM_Love.SetSign = function(szSign)
	szSign = HM.Trim(szSign)
	_HM_Love.szSign = szSign
	HM.DelayCall(3000, function()
		if szSign == _HM_Love.szSign then
			local szPart1, szPart2 = "", ""
			if string.len(szSign) > 22 then
				-- �ָ�
				local i = 1
				while i < 21 do
					if string.byte(szSign, i) < 128 then
						i = i + 1
					else
						i = i + 2
					end
				end
				szPart1 = string.sub(szSign, 1 - 1, i)
				szPart2 = string.sub(szSign, i)
			else
				szPart1, szPart2 = szSign, " "
			end
			if not _HM_Love.SetFellowDataByKey("S1", szPart1) then
				return HM.Alert("����ǩ��ʧ�ܣ���Ҫ��һ��6�����µĺ��ѡ�")
			end
			_HM_Love.SetFellowDataByKey("S2", szPart2)
		end
	end)
end

-- ������Ե�����Ϣ
_HM_Love.UpdatePage = function(p)
	p = p or Station.Lookup("Normal/PlayerView/Page_Main/Page_Love")
	if not p then
		return
	end
	local tar = GetPlayer(p:GetParent().dwPlayer)
	if not tar then
		return p:GetRoot():Hide()
	end
	local h, t = p:Lookup("", ""), _HM_Love.tOther
	-- title
	p:Lookup("", "Text_LTitle"):SetText(tar.szName .. "����Ե")
	-- lover
	local txt = h:Lookup("Text_Lover")
	local szLover = t[1] or "�������С�"
	txt:SetText(szLover)
	-- avatar
	local dwAvatar = tonumber(t[2]) or 0
	local img, ani = h:Lookup("Image_Lover"), h:Lookup("Animate_Lover")
	if dwAvatar == 0 then
		txt:SetRelPos(42, 125)
		img:Hide()
		ani:Hide()
	else
		local szAvatar = "ui\\Image\\PlayerAvatar\\jianghu.tga"
		img:SetImageType(IMAGE.NORMAL)
		if dwAvatar <= 0 then
			local tAvatar = _HM_Love.tForceAvatar
			dwAvatar = 0 - dwAvatar
			if tAvatar[dwAvatar] then
				szAvatar = "ui\\Image\\PlayerAvatar\\" .. tAvatar[dwAvatar] .. ".tga"
			end
		else
			local szFile, nFrame, bAnimate = _HM_Love.GetAvatarInfo(dwAvatar, tonumber(t[4]) or 1)
			if szFile then
				szAvatar = nil
				img:SetImageType(IMAGE.FLIP_HORIZONTAL)
				if bAnimate then
					ani:SetAnimate(szFile, nFrame)
					--ani:SetAnimateType(ANIMATE.FLIP_HORIZONTAL)
					ani:Show()
					img:Hide()
				elseif nFrame < 0 then
					szAvatar = szFile
				else
					img:FromUITex(szFile, nFrame)
					img:Show()
					ani:Hide()
				end
			end
		end
		if szAvatar then
			img:FromTextureFile(szAvatar)
			img:Show()
			ani:Hide()
		end
		txt:SetRelPos(42, 155)
	end
	txt.szPlayer = t[1]
	img.szPlayer = t[1]
	ani.szPlayer = t[1]
	-- sign title
	h:Lookup("Text_SignTTL"):SetText(tar.szName .. "����Ե���ԣ�")
	-- sign content
	local szSign = t[3]
	if not szSign or szSign == "" then
		szSign = "����һ������ʲôҲû���£�"
	end
	h:Lookup("Text_Sign"):SetText(szSign)
	-- btn title
	local txt = p:Lookup("Btn_LoveYou"):Lookup("", "Text_LoveYou")
	if tar.nGender == 2 then
		txt:SetText("������")
	else
		txt:SetText("������")
	end
	h:FormatAllItemPos()
end

-- ��̨������˵���Ե����
_HM_Love.AskOtherData = function(dwID)
	local tar = GetPlayer(dwID)
	if not tar then
		return
	end
	_HM_Love.tOther = {}
	_HM_Love.UpdatePage()
	if tar.bFightState and not HM.IsParty(tar.dwID) then
		_HM_Love.bActiveLove = false
		return HM.Sysmsg("[" .. tar.szName .. "] ����ս���У���Ͼ������")
	end
	HM.BgTalk(tar.szName, "HM_LOVE", "REQUEST")
end

-------------------------------------
-- �¼�����
-------------------------------------
_HM_Love.OnPeekOtherPlayer = function()
	if arg0 ~= 1 then return end
	local mPage = Station.Lookup("Normal/PlayerView/Page_Main")
	if not mPage then
		return
	end
	-- attach page
	if not mPage.bLoved then
		local frame = Wnd.OpenWindow("interface\\HM\\ui\\HM_Love.ini", "HM_Love")
		local pageset = frame:Lookup("Page_Main")
		local checkbox = pageset:Lookup("CheckBox_Love")
		local page = pageset:Lookup("Page_Love")
		checkbox:ChangeRelation(mPage, true, true)
		page:ChangeRelation(mPage, true, true)
		Wnd.CloseWindow(frame)
		checkbox:SetRelPos(270, 510)
		page:SetRelPos(0, 0)
		mPage:AddPage(page, checkbox)
		checkbox:Show()
		mPage.bLoved = true
		-- events
		mPage.OnActivePage = function()
			PlaySound(SOUND.UI_SOUND, g_sound.OpenFrame)
			if this:GetActivePage():GetName() == "Page_Love" then
				_HM_Love.AskOtherData(this.dwPlayer)
			end
		end
		page:Lookup("Btn_LoveYou").OnLButtonClick = function()
			local mp = this:GetParent():GetParent()
			local tar = GetPlayer(mp.dwPlayer)
			if tar then
				HM.Talk(tar.szName, "�ˣ��Һ������ļ����㰡��#��ϲ")
			end
		end
		page:Lookup("Btn_LoveYou").OnRButtonClick = function()
			local mp = this:GetParent():GetParent()
			local tar = GetPlayer(mp.dwPlayer)
			if tar then
				local m0, me = {}, GetClientPlayer()
				if me.IsInParty() and me.dwID == GetClientTeam().GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
					InsertMarkMenu(m0, tar.dwID)
				end
				if me.IsInParty() and me.IsPlayerInMyParty(tar.dwID) then
					InsertTeammateLeaderMenu(m0, tar.dwID)
				end
				if #m0 > 0 then
					table.insert(m0, {bDevide = true})
				end
				InsertPlayerCommonMenu(m0, tar.dwID, tar.szName)
				PopupMenu(m0)
			end
		end
		page:Lookup("", "Image_Lover").OnItemRButtonDown = function()
			if this.szPlayer then
				local m0 = {}
				InsertPlayerCommonMenu(m0, 0, this.szPlayer)
				PopupMenu(m0)
			end
		end
		page:Lookup("", "Text_Lover").OnItemRButtonDown = page:Lookup("", "Image_Lover").OnItemRButtonDown
		page:Lookup("", "Animate_Lover").OnItemRButtonDown = page:Lookup("", "Image_Lover").OnItemRButtonDown
		page:Lookup("", "Text_LTitle"):SetText("��Ե")
		checkbox:Lookup("", "Text_LoveCaptical"):SetText("��Ե")
	end
	-- update page
	mPage.dwPlayer = arg1
	-- active page
	if _HM_Love.bActiveLove then
		_HM_Love.bActiveLove = false
		mPage:ActivePage("Page_Love")
	end
end

-- �ظ���Ե��Ϣ
_HM_Love.ReplyLove = function(dwTarget, szTarget, bCancel)
	local szLover = _HM_Love.szLover
	if bCancel or _HM_Love.nPrivacy == 0
		or (_HM_Love.nPrivacy == 1 and not _HM_Love.IsMyFellow(dwTarget))
	then
		szLover = "~�Ҳ�������~"
	end
	HM.BgTalk(szTarget, "HM_LOVE", szLover, _HM_Love.dwAvatar, _HM_Love.szSign, _HM_Love.nRoleType)
end

-- ��̨ͬ��
_HM_Love.OnBgTalk = function()
	local data = HM.BgHear("HM_LOVE")
	if data then
		if data[1] == "REQUEST" then
			local dwTarget, szTarget = arg0, arg3
			if HM.IsParty(dwTarget) then
				_HM_Love.ReplyLove(dwTarget, szTarget)
			elseif not GetClientPlayer().bFightState and not HM_Love.bQuiet then
				HM.Confirm(
					"[" .. szTarget .. "] ��鿴������Ե��Ϣ��",
					function() _HM_Love.ReplyLove(dwTarget, szTarget) end,
					function() _HM_Love.ReplyLove(dwTarget, szTarget, true) end
				)
			end
		else
			_HM_Love.tOther = data
			_HM_Love.UpdatePage()
		end
	end
end

-- ��Ե��������֪ͨ
_HM_Love.OnLoverMsg = function(szMsg)
	local szChannel = "MSG_SYS"
	local szFont = GetMsgFontString(szChannel)
	szMsg = FormatLinkString(szMsg, szFont, MakeNameLink("[" .. _HM_Love.szLover .. "]", szFont))
	OutputMessage(szChannel, szMsg, true)
end

-- ���ߣ�����֪ͨ��bOnLine, szName, bFoe
_HM_Love.OnFriendLogin = function()
	if not  arg2 and arg1 == _HM_Love.szLover then
		local szMsg = "���ѣ�����Ķ���Ե<link 0>"
		if arg0 then
			szMsg = szMsg .. "���������ø���Ͻ����\n"
		else
			szMsg = szMsg .. "�����֣������Ͻ����\n"
		end
		_HM_Love.OnLoverMsg(szMsg)
	end
end

-------------------------------------
-- ���ý���
-------------------------------------
_HM_Love.PS = {}

-- init
_HM_Love.PS.OnPanelActive = function(frame)
	local ui, nX = HM.UI(frame), 0
	ui:Append("Text", { txt = "�Ķ���Ե", x = 0, y = 0, font = 27 })
	nX = ui:Append("Text", { txt = "�ɽ����غ�����Ϊ��Ե��", x = 10, y = 28 }):Pos_()
	ui:Append("WndComboBox", "Combo_Lover", { x = nX + 5, y = 28, w = 200, h = 25 })
	:Text(_HM_Love.szLover):Menu(_HM_Love.GetLoverMenu)
	nX = ui:Append("Text", { txt = "˭�ܿ���������Ե���֣�", x = 10 , y = 56 }):Pos_()
	nX = ui:Append("WndRadioBox", { x = nX + 5, y = 60, checked = _HM_Love.nPrivacy == 0, group = "pri" })
	:Text("����"):Click(function(bChecked)
		if bChecked then
			_HM_Love.SetPrivacy(0)
		end
	end):Pos_()
	nX = ui:Append("WndRadioBox", { x = nX + 5, y = 60, checked = _HM_Love.nPrivacy == 1, group = "pri" })
	:Text("������"):Click(function(bChecked)
		if bChecked then
			_HM_Love.SetPrivacy(1)
		end
	end):Pos_()
	nX = ui:Append("WndRadioBox", { x = nX + 5, y = 60, checked = _HM_Love.nPrivacy == 2, group = "pri" })
	:Text("������"):Click(function(bChecked)
		if bChecked then
			_HM_Love.SetPrivacy(2)
		end
	end):Pos_()
	ui:Append("WndCheckBox", { x = nX + 10, y = 56, checked = HM_Love.bQuiet, txt = "�����" })
	:Click(function(bChecked) HM_Love.bQuiet = bChecked end)
	ui:Append("Text", { txt = "��Ե���ԣ����42�ַ���21���֣�", x = 0, y = 92, font = 27 })
	ui:Append("WndEdit", { x = 10, y = 120, multi = true, limit = 42, w = 420, h = 60 })
	:Text(_HM_Love.szSign):Change(_HM_Love.SetSign)
	ui:Append("Text", { txt = "С��ʾ", x = 0, y = 188, font = 27 })
	ui:Append("Text", { txt = "1. ֻ��ͬ��װ�˱��������Ҳ��ܻ��࿴�����á�", x = 10, y = 213 })
	ui:Append("Text", { txt = "2. ͨ��Ŀ���Ҽ��˵����鿴��Ե����δ���ʱ�뾭�Է�ͬ�⡣", x = 10, y = 238 })
	_HM_Love.ui = ui
end

-- deinit
_HM_Love.PS.OnPanelDeactive = function()
	_HM_Love.ui = nil
end

---------------------------------------------------------------------
-- ע���¼�����ʼ��
---------------------------------------------------------------------
HM.RegisterEvent("ON_BG_CHANNEL_MSG", _HM_Love.OnBgTalk)
HM.RegisterEvent("PEEK_OTHER_PLAYER", _HM_Love.OnPeekOtherPlayer)
HM.RegisterEvent("PLAYER_FELLOWSHIP_LOGIN", _HM_Love.OnFriendLogin)
HM.RegisterEvent("PLAYER_FELLOWSHIP_UPDATE", _HM_Love.LoadData)

-- add to HM collector
HM.RegisterPanel("��Ե����3", 329, _L["Others"], _HM_Love.PS)

-- view other lover by dwID
function HM_Love.PeekOther(dwID)
	ViewInviteToPlayer(dwID)
	_HM_Love.bActiveLove = true
	if not HM.IsParty(dwID) then
		_HM_Love.AskOtherData(dwID)
	end
end

-- add target menu
Target_AppendAddonMenu({ function(dwID)
	return {{
		szOption = "�鿴��Ե��Ϣ",
		fnDisable = function() return dwID == GetClientPlayer().dwID end,
		fnAction = function() HM_Love.PeekOther(dwID) end
	}}
end })

