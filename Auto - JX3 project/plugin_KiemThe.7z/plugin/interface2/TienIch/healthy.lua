﻿--nhắc nhở--
local tbHealthy = Ui.tbLogic.tbHealthy or {};
Ui.tbLogic.tbHealthy = tbHealthy;
tbHealthy.TIME_NOTIFY	= 1600 * Env.GAME_FPS;

function tbHealthy:Init()
	if (self.nTimerRegId) then
		return;
	end
	self.nTimerRegId = 0;
end

function tbHealthy:OnTimer()
	Ui(Ui.UI_TASKTIPS):Begin("<pic=98>Mệt chưa nào! Hãy nghỉ ngơi 1 tí đi! Không thì chém à! <pic=98>");
end

function tbHealthy:OnEnterGame()
	assert(self.nTimerRegId == 0);
	self.nTimerRegId = Timer:Register(self.TIME_NOTIFY, self.OnTimer, self);
end

function tbHealthy:OnLeaveGame()
	if (self.nTimerRegId ~= 0) then
		Timer:Close(self.nTimerRegId);
		self.nTimerRegId	= 0;
	end
end
