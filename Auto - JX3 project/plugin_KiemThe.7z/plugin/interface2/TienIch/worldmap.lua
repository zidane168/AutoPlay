--Wordmap--
local uiWorldMap_Sub	= Ui(Ui.UI_WORLDMAP_SUB);
local tbMapBar			= Ui.tbLogic.tbMapBar;
local tbMap				= Ui.tbLogic.tbMap;
local tbTimer 			= Ui.tbLogic.tbTimer;

uiWorldMap_Sub.POINTSPRPATH	= "\\image\\ui\\001a\\minimap\\"
local szString = "<[%s]> đang ở đây (%d, %d), AE đến gấp (%d, %d, %d)."
local OnOpen_Bak = uiWorldMap_Sub.OnOpen

uiWorldMap_Sub.OnOpen = function(self, nMapId, nX, nY)
	OnOpen_Bak(self, nMapId, nX, nY)
	self.tbTreaMapInfo		= {};
	self.tbTreaCanvasId		= {};
	self.tbWantedInfo		= {};
	self.tbWantedCanvas	  	= {};
	self.CurShowMapId = nMapId;
	local bReadTreaPos	= self:ReadTreaMapInfo();
	if bReadTreaPos then
		if self.tbTreaMapInfo[nMapId] then
			for i = 1, #self.tbTreaMapInfo[nMapId] do
				local szText 				= self.tbTreaMapInfo[nMapId][i][3];
				local nMapPosX 				= self.tbTreaMapInfo[nMapId][i][1];
				local nMapPosY 				= self.tbTreaMapInfo[nMapId][i][2];
				local nTextPosX, nTextPosY	= tbMap:WorldPosToImgPos(self.nMapControlId, nMapPosX, nMapPosY);
				local nImageId = Canvas_CreateImage(self.UIGROUP, self.IMAGE_SUBMAP, nTextPosX, nTextPosY, self.POINTSPRPATH.."yellowpoint.spr", 1);
				local absTxtPosX = nTextPosX - ((12 / 2) * (string.len(szText) / 2));
				local absTxtPosY = nTextPosY + (12 / 2) + 5;
				local nTextId = Canvas_CreateText(self.UIGROUP, self.IMAGE_SUBMAP, 12, szText, "green", absTxtPosX, absTxtPosY);
				if not self.tbTreaCanvasId[nMapId] then
					self.tbTreaCanvasId[nMapId] = {};
				end;
				table.insert(self.tbTreaCanvasId[nMapId],	{nImageId, nTextId});
			end
		end
	end
	local bReadWantedPos = self:ReadWantedInfo();
	if bReadWantedPos then
		if self.tbWantedInfo[nMapId] then
			for i = 1, #self.tbWantedInfo[nMapId] do
				local szText 				= self.tbWantedInfo[nMapId][i][3];
				local nMapPosX 				= self.tbWantedInfo[nMapId][i][1];
				local nMapPosY 				= self.tbWantedInfo[nMapId][i][2];
				local nTextPosX, nTextPosY	= tbMap:WorldPosToImgPos(self.nMapControlId, nMapPosX, nMapPosY);
				local nImageId = Canvas_CreateImage(self.UIGROUP, self.IMAGE_SUBMAP, nTextPosX, nTextPosY, self.POINTSPRPATH.."yellowpoint.spr", 1);
				local absTxtPosX = nTextPosX - ((12 / 2) * (string.len(szText) / 2));
				local absTxtPosY = nTextPosY + (12 / 2) + 5;
				local nTextId = Canvas_CreateText(self.UIGROUP, self.IMAGE_SUBMAP, 12, szText, self.tbWantedInfo[nMapId][i][4], absTxtPosX, absTxtPosY);
				if not self.tbWantedCanvas[nMapId] then
					self.tbWantedCanvas[nMapId] = {};
				end
				table.insert(self.tbWantedCanvas[nMapId],	{nImageId, nTextId});
			end
		end
	end
end

uiWorldMap_Sub.ReadTreaMapInfo = function(self)
	local pTabFile = KIo.OpenTabFile("\\setting\\task\\treasuremap\\treasuremap_pos.txt");
	if (not pTabFile) then
		return 0;
	end
	local nHeight = pTabFile.GetHeight();
	for i = 2, nHeight do
		local nTreaMapId 	= pTabFile.GetInt(i, 4);
		local nTreaPosX 	= pTabFile.GetInt(i, 5);
		local nTreaPosY		= pTabFile.GetInt(i, 6);
		local szTextPos		= pTabFile.GetStr(i, 7);
		if not self.tbTreaMapInfo[nTreaMapId] then
			self.tbTreaMapInfo[nTreaMapId] = {};
		end;
		table.insert(self.tbTreaMapInfo[nTreaMapId], {nTreaPosX, nTreaPosY, szTextPos});
	end
	KIo.CloseTabFile(pTabFile);
	return 1;
end

uiWorldMap_Sub.ReadWantedInfo = function(self)
	local pTabFile = KIo.OpenTabFile("\\setting\\map\\worldmap.txt");
	if (not pTabFile) then
		return 0;
	end
	local nHeight = pTabFile.GetHeight();
	for i = 3, nHeight do
		local nTreaMapId 	= pTabFile.GetInt(i, 4);
		local nTreaPosX 	= pTabFile.GetInt(i, 5);
		local nTreaPosY		= pTabFile.GetInt(i, 6);
		local szTextPos		= pTabFile.GetStr(i, 2);
		local szColor	    = pTabFile.GetStr(i, 11);
		if not self.tbWantedInfo[nTreaMapId] then
			self.tbWantedInfo[nTreaMapId] = {};
		end;
		table.insert(self.tbWantedInfo[nTreaMapId], {nTreaPosX, nTreaPosY, szTextPos,szColor});
	end
	KIo.CloseTabFile(pTabFile);
	return 1;
end

local _Fn_BackUp = uiWorldMap_Sub.OnClose;

uiWorldMap_Sub.OnClose = function(self)
	_Fn_BackUp(self)
	for i, tbTreaCon in pairs(self.tbTreaCanvasId) do
		for j=1, #tbTreaCon do
			Canvas_DestroyImage(self.UIGROUP, self.IMAGE_SUBMAP, tbTreaCon[j][1]);
			Canvas_DestroyText(self.UIGROUP, self.IMAGE_SUBMAP, tbTreaCon[j][2]);
		end;
	end
	for i, tbTreaCon2 in pairs(self.tbWantedCanvas) do
		for j=1, #tbTreaCon2 do
			Canvas_DestroyImage(self.UIGROUP, self.IMAGE_SUBMAP, tbTreaCon2[j][1]);
			Canvas_DestroyText(self.UIGROUP, self.IMAGE_SUBMAP, tbTreaCon2[j][2]);
		end;
	end
end