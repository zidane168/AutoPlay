--- điểu khiển hiển thị khi vào game ---
local tbMgr = UiManager;
local tbMgrkg = 0;

function tbMgr:OnPressESC()
	if (self:WindowVisible(Ui.UI_CAPTURE_SCREEN) == 1) then
		self:CloseWindow(Ui.UI_CAPTURE_SCREEN);
		return;
	elseif (self:WindowVisible(Ui.UI_EQUIPENHANCE) == 1) then
		if self:GetUiState(self.UIS_EQUIP_RECAST) == 1 then
			if Ui(Ui.UI_EQUIPENHANCE).pTempItem and Ui(Ui.UI_EQUIPENHANCE).pEquip then
				local tbMsg = {};
				tbMsg.szMsg = "<color=red>Sau khi hủy, trang bị mới đúc sẽ biến mất, giữ lại trang bị ban đầu.<color>";
				tbMsg.szMsg = tbMsg.szMsg.." Tiếp tục không?"
				tbMsg.nOptCount = 2;
				function tbMsg:Callback(nOptIndex,tbFun,szUiGroup)
					if (nOptIndex == 2) then
						me.CallServerScript(tbFun);
						UiManager:CloseWindow(szUiGroup);
					end
				end
				local tbFun = {"ConfirmRecast",0,Ui(Ui.UI_EQUIPENHANCE).pEquip.dwId,1};
				self:OpenWindow(Ui.UI_MSGBOX,tbMsg,tbFun,Ui.UI_EQUIPENHANCE);
				return;
			end
		end
	elseif (self:WindowVisible(Ui.UI_WORLDMAP_SUB) == 1) then
		self:CloseWindow(Ui.UI_WORLDMAP_SUB)
		return;
	elseif (self:WindowVisible(Ui.UI_WORLDMAP_AREA) == 1) then
		self:CloseWindow(Ui.UI_WORLDMAP_AREA)
		return;
	elseif (self:WindowVisible(Ui.UI_WORLDMAP_GLOBAL) == 1) then
		self:CloseWindow(Ui.UI_WORLDMAP_GLOBAL)
		return;
	end
	if (self:WindowVisible(Ui.UI_SCHOOLDEMO) == 1) then
		self:CloseWindow(Ui.UI_SCHOOLDEMO)
		return;
	end
	if (self:WindowVisible(Ui.UI_WORLDMAP_DOMAIN) == 1) then
		self:CloseWindow(Ui.UI_WORLDMAP_DOMAIN)
		return;
	end
	if (self:WindowVisible(Ui.UI_TEXTINPUT) == 1) then
		self:CloseWindow(Ui.UI_TEXTINPUT)
		return
	end
	if (self:WindowVisible(Ui.UI_JBEXCHANGE) == 1) then
		self:CloseWindow(Ui.UI_JBEXCHANGE)
		return
	end
	if (self:WindowVisible(Ui.UI_IBSHOPCART) == 1) then
		self:CloseWindow(Ui.UI_IBSHOPCART)
		return
	end
	if (self:WindowVisible(Ui.UI_IBSHOP) == 1) then
		self:CloseWindow(Ui.UI_IBSHOP)
		return
	end
	if (CloseWndsInGame() == 0 and self:WindowVisible(Ui.UI_ITEMBOX) == 0) then
		if (self:WindowVisible(Ui.UI_SKILLPROGRESS) == 0) then
			if UiVersion == Ui.Version001 then
				self:SwitchWindow(Ui.UI_SYSTEM);
			else
				self:SwitchWindow(Ui.UI_SYSTEMEX);
			end
		else
			me.BreakProcess();
		end
	end
	if (self:WindowVisible(Ui.UI_ITEMBOX) == 1) then
		self:CloseWindow(Ui.UI_ITEMBOX);
		return;
	end
end

function tbMgr:OnReadyEsc()
	local UI_WINDOW = Ui.UI_SYSTEMEX;
	if UiVersion == Ui.Version001 then
		UI_WINDOW = Ui.UI_SYSTEM;
	else
		
	end
	if (self:WindowVisible(UI_WINDOW) ~= 0) then
		self:CloseWindow(UI_WINDOW);
		return;
	end
	CloseWndsInGame();
	me.BreakProcess();
	self:SwitchWindow(UI_WINDOW);
end

function tbMgr:OnEnterGame()     
	SendChannelMsg("NearBy", "<pic=82><pic=82><enter><color=green>Chúc các bạn chơi game vui vẻ!!");
	UiManager:OpenWindow("UI_INFOBOARD","<pic=99><bclr=pink><color=yellow>Bạn đang dùng Plugins fix bởi Mr.DUY cho tộc TInhHuynhDe! <pic=99>");	
	--self:SwitchWindow(Ui.UI_TOOL); -- luôn hiện thanh hỗ trợ quân doanh khi vao game (BVD, ghép HT)
	self:SwitchWindow(Ui.UI_TOOLS); --luôn hiện thanh Home (di chuyển nhanh) khi vào game
	self:SwitchWindow(Ui.UI_tools2); --luôn hiện thanh ToolTuDong khi vào game
	Map.tbNangDong:State();
	self:SwitchUiModel(0);
	Player.tbGlobalFriends:Init();
	ForbitGameSpace(0);
	self:OpenWindow(Ui.UI_NEWSMSG);
	self:OpenWindow(Ui.UI_SERVERSPEED);
	self:OpenWindow(Ui.UI_GLOBALCHAT);
	self:OpenWindow(Ui.UI_GLOBALCHATBUY);
	self.nEnterTime	= GetTime();
	self.Unlock_Lock=1;
	if  self.Unlock_Lock==1 then 
		self:OpenWindow(Ui.UI_UNLOCK);
	end
	Ui.tbLogic.tbPassPodTime:OnStart();
	Ladder:ClearLadder();
	Player.tbOnlineExp:OnStartCheckOnlineExpState();
	Ui(Ui.UI_SYSTEM)._no_name_or_life = 1;
	Ui(Ui.UI_SYSTEM):Update();
	Ui(Ui.UI_SKILLBAR)._disable_switch_skill = nil;
	Ui.tbLogic.tbMsgChannel:LoadChannelSetting();
	Sns:OnEnterGame();
	AutoTeam:OnEnterGame();
	ChatFilter:Init();
	--if	self.Unlock_Lock==1 then 
		--self:OpenWindow(Ui.UI_LOCKACCOUNT);
	--end
end

function tbMgr:OnNoOperation()
	if (Player.tbOffline:CanSleep() == 1) then
		ExitGame();
	end
end
