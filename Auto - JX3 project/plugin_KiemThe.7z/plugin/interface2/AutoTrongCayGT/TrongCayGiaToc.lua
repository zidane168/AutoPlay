------edit by chow82 KHPT
Ui.UI_AUTOFUBEN		       = "UI_AUTOFUBEN";
local uiAutoFuBen            = Ui.tbWnd[Ui.UI_AUTOFUBEN] or {};
uiAutoFuBen.UIGROUP	       = Ui.UI_AUTOFUBEN;
Ui.tbWnd[Ui.UI_AUTOFUBEN]      = uiAutoFuBen;

local tbSaveData 			 = Ui.tbLogic.tbSaveData;
local self = uiAutoFuBen;

self.DATA_KEY        = "FuBen";
self.tbSetting        = {};

self.BTN_CLOSE        = "BtnClose";
self.BTN_START        = "BtnStart";
self.BTN_MYREPUTE			= "BtnMyRepute";
self.BTN_SAVE8        = "BtnSave8";


local tbMyRepute			= {"Hạt giống bắp","Giống cây táo","Hạt giống hoa đỗ quyên"}

function uiAutoFuBen:OnOpen()
	PgSet_ActivePage(self.UIGROUP, self.PAGESET_MAIN, self.PAGE_ONE);
	self:LoadSetting();
	self:SetAwardLabel();
	--self:SaveData();
end

function uiAutoFuBen:LoadSetting()
	self.tbSetting	= self:Load(self.DATA_KEY) or {};
	if not self.tbSetting.nMyRepute then
		self.tbSetting.nMyRepute = 3;
	end
end

function uiAutoFuBen:OnButtonClick(szWnd, nParam)
	if (szWnd == uiAutoFuBen.BTN_CLOSE) then
		UiManager:CloseWindow(self.UIGROUP);
		--self:SaveData();
	elseif (szWnd == uiAutoFuBen.BTN_START) then
		Map.tbKinZhongZhi:Switch();
		UiManager:CloseWindow(self.UIGROUP);
		--self:SaveData();
	elseif szWnd == self.BTN_MYREPUTE then
		DisplayPopupMenu(
		self.UIGROUP,szWnd,3,0,
		tbMyRepute[1],1,
		tbMyRepute[2],2,
		tbMyRepute[3],3
		);
	elseif (szWnd == uiAutoFuBen.BTN_SAVE8) then
		self:SaveData();
	end
end


function uiAutoFuBen:OnMenuItemSelected(szWnd, nItemId, nParam)
	if szWnd == self.BTN_MYREPUTE then
		self.tbSetting.nMyRepute = nItemId
	end
	self:SetAwardLabel();
	--self:SaveData();
end

function uiAutoFuBen:SetAwardLabel()
	Btn_SetTxt(self.UIGROUP,self.BTN_MYREPUTE,tbMyRepute[self.tbSetting.nMyRepute]);
end

function uiAutoFuBen:SaveData()
	self:Save(self.DATA_KEY, self.tbSetting);
end

function uiAutoFuBen:Save(szKey, tbData)
	self.m_szFilePath="\\user\\plant\\"..me.szName.."_giongcay.txt";
	self.m_tbData = {};
	self.m_tbData[szKey] = tbData;
	print(tbData);
	local szData = Lib:Val2Str(self.m_tbData);
	assert(self.m_szFilePath);
	if self:CheckErrorData(szData) == 1 then
		KFile.WriteFile(self.m_szFilePath, szData);
		me.Msg("<color=orange>Lưu dữ liệu thành công");
	else
		local szSaveData = Lib:Val2Str(tbData);
	end
end

function uiAutoFuBen:Load(key)
	self.m_szFilePath="\\user\\plant\\"..me.szName.."_giongcay.txt";
	self.m_tbData = {};
	print(key);
	local szData = KIo.ReadTxtFile(self.m_szFilePath);
	if (szData) then
		if self:CheckErrorData(szData) == 1 then
			self.m_tbData = Lib:Str2Val(szData);
		else
			KFile.WriteFile(self.m_szFilePath, "");
		end
	end
	local tbData = self.m_tbData[key];
	print(self.m_tbData);
	return tbData;
end

function uiAutoFuBen:CheckErrorData(szDate)
	if szDate ~= "" then
		if string.find(szDate, "Ptr:") and string.find(szDate, "ClassName:") then
			return 0;
		end
		if (not Lib:CallBack({"Lib:Str2Val", szDate})) then	
			return 0;
		end
	end
	return 1;
end
--[[
function uiAutoFuBen:Reload()
        local function fnDoScript(szFilePath)
		local szFileData	= KFile.ReadTxtFile(szFilePath);
		assert(loadstring(szFileData, szFilePath))();
	end
	fnDoScript("\\interface2\\AutoTrongCayGT\\SupportTrongCay.lua");
        me.Msg("Reload done");
end
]]
LoadUiGroup(Ui.UI_AUTOFUBEN, "TrongCayGiaToc.ini");

