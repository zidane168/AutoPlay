--cyberdemon--
local tbPlayerPanel = Ui(Ui.UI_PLAYERPANEL)
local BTN_REPAIRJX_ALL		= "BtnRepairJxAll"
local BTN_VALUE				= "BtnEquipValue"
local BTN_ACTIVE_TITLE		= "BtnActiveTitle"
local BTN_INACTIVE_TITLE	= "BtnInactiveTitle"
local OUTLOOK_REPUTE		= "OutLookRepute"
local OnButtonClick_bk = tbPlayerPanel.OnButtonClick
local BTN_FIGHTPOWER		= "BtnFightPower"; 

function tbPlayerPanel:UpdateFightPower(nPower)
	nPower = math.floor(nPower * 100) / 100;
	local szFightPower = string.format("Lực chiến: %g", nPower);
	Btn_SetTxt(self.UIGROUP, BTN_FIGHTPOWER, szFightPower);
end

tbPlayerPanel.OnButtonClick = function(self, szWnd, nParam)
	if (BTN_REPAIRJX_ALL == szWnd) then
		AutoAi:RepairAll()
	elseif (BTN_VALUE == szWnd) then
		if UiManager:WindowVisible(Ui.UI_VIEWWEALTHVALUE) == 0 then
			UiManager:OpenWindow(Ui.UI_VIEWWEALTHVALUE)
		else
			UiManager:CloseWindow(Ui.UI_VIEWWEALTHVALUE)
		end	
	else
		OnButtonClick_bk(self, szWnd, nParam)
	end
end

tbPlayerPanel.GetSeriesReputeValue=function(self,tbContent, tbSet, nClass, nType, nLevel)
	local tbShowSeries	= {0, 0, 0, 0, 0}
	local nSeries		= me.nSeries
	local tbFactionInfo = Faction:GetGerneFactionInfo(me)
	if (nSeries <= 0 or nSeries > 5) and (#tbSet[nClass][nType] ~= nLevel) then
		local tbItemContent = {}
		tbItemContent[1] = ""
		tbItemContent[2] = tbSet[nClass][nType].szName
		tbItemContent[3] = "["..nLevel.."] "..tbSet[nClass][nType][nLevel].szName
		if (#tbSet[nClass][nType] == nLevel) then
			tbItemContent[4] = "Cấp cao nhất"
		else
			tbItemContent[4] = me.GetReputeValue(nClass, nType, nLevel).."/"..tbSet[nClass][nType][nLevel].nLevelUp
		end
		tbContent[#tbContent + 1] = tbItemContent
		return;	
	end
	tbShowSeries[nSeries] = 1
	for _, nFactionId in pairs(tbFactionInfo) do
		local tbFactionInfo = KPlayer.GetFactionInfo(nFactionId)
		tbShowSeries[tbFactionInfo.nSeries] = 1
	end
	for nSeriesType = 1, #tbShowSeries do
		if (tbShowSeries[nSeriesType] == 1) then
			local szFlag		= ""
			local tbItemContent	= {}
			local nValue		= 0
			local nNowLevel		= 0
			if (nSeriesType == nSeries) then	
				nValue		= me.GetReputeValue(nClass, nType, nLevel)
				nNowLevel	= nLevel
				szFlag		= "★"
			else
				nValue, nNowLevel = Faction:GetRepute(me, nSeriesType, nClass, nType)
				if (not nValue) then
					nValue		= 0
					nNowLevel	= tbSet[nClass][nType].nDefLevel
				end
			end
			if (nValue) and (#tbSet[nClass][nType] ~= nNowLevel) then
				tbItemContent[1] = szFlag
				tbItemContent[2] = tbSet[nClass][nType].szName .. "（" .. SERIES_NAME[nSeriesType] .. "）"
				tbItemContent[3] = "["..nNowLevel.."] "..tbSet[nClass][nType][nNowLevel].szName
				if (#tbSet[nClass][nType] == nNowLevel) then
					tbItemContent[4] = "Cấp cao nhất"
				else
					tbItemContent[4] = nValue.."/"..tbSet[nClass][nType][nNowLevel].nLevelUp
				end
				tbContent[#tbContent + 1] = tbItemContent
			end			
		end
	end
end

function tbPlayerPanel:GetReputePanelValue()
	local tbSet	= self.tbReputeSetting
	if (not tbSet) then
		return;
	end
	local tbResultSet = {}
	for i = 1, #tbSet do
		if (tbSet[i].nIsDisable and 0 == tbSet[i].nIsDisable) then
			local tbInfo = {}
			tbInfo.szName = tbSet[i].szName
			tbInfo.nIsDisable = tbSet[i].nIsDisable or 0
			local tbContent = {}
			for j = 1, #tbSet[i] do
				local nLevel = me.GetReputeLevel(i, j)
				local nClassIsDisable = tbSet[i][j].nIsDisable
				if (nLevel and 0 == nClassIsDisable) then
					if (1 == i and 1 == j) then	 	
						self:GetSeriesReputeValue(tbContent, tbSet, i, j, nLevel)
					elseif (2 == i) then			
						self:GetSeriesReputeValue(tbContent, tbSet, i, j, nLevel)
					elseif (5 == i and 1 == j) then
						self:GetSeriesReputeValue(tbContent, tbSet, i, j, nLevel)
					elseif (4 == i and 1 == j) then	
						self:GetSeriesReputeValue(tbContent, tbSet, i, j, nLevel)
					elseif (#tbSet[i][j] ~= nLevel) then
						local tbItemContent = {}
						tbItemContent[1] = ""
						tbItemContent[2] = tbSet[i][j].szName
						tbItemContent[3] = "          [<color=yellow>"..nLevel.."<color>] "..tbSet[i][j][nLevel].szName
						if (#tbSet[i][j] == nLevel) then
							tbItemContent[4] = "               <color=yellow>Cấp cao nhất<color>"
						else
							tbItemContent[4] = "                         <color=yellow>"..me.GetReputeValue(i, j, nLevel).."<color> / "..tbSet[i][j][nLevel].nLevelUp
						end
						tbContent[#tbContent + 1] = tbItemContent
					end
				end
			end
			tbInfo.tbContent = tbContent
			tbResultSet[#tbResultSet + 1] = tbInfo
		end
	end
	return tbResultSet
end

tbPlayerPanel.OnUpdatePageRepute=function(self)
	self:UpdateReputeName()
	local tbSet = self.tbReputeSetting
	if (not tbSet) then
		return
	end
	OutLookPanelClearAll(self.UIGROUP, OUTLOOK_REPUTE)
	AddOutLookPanelColumnHeader(self.UIGROUP, OUTLOOK_REPUTE, "")
	AddOutLookPanelColumnHeader(self.UIGROUP, OUTLOOK_REPUTE, "")
	AddOutLookPanelColumnHeader(self.UIGROUP, OUTLOOK_REPUTE, "")
	SetOutLookHeaderWidth(self.UIGROUP, OUTLOOK_REPUTE, 0, 100)
	SetOutLookHeaderWidth(self.UIGROUP, OUTLOOK_REPUTE, 1, 60)
	SetOutLookHeaderWidth(self.UIGROUP, OUTLOOK_REPUTE, 2, 100)
	AddOutLookGroup(self.UIGROUP, OUTLOOK_REPUTE, "<color=green>Cá nhân<color>")
	AddOutLookGroup(self.UIGROUP, OUTLOOK_REPUTE, "<color=red>Giang hồ<color>")
	for i = 1, #tbSet do
		for j = 1, #tbSet[i] do
			local nLevel = me.GetReputeLevel(i, j)
			if (nLevel) and (#tbSet[i][j] ~= nLevel) then
				local tbItemContent = {}
				tbItemContent[1] = tbSet[i][j].szName
				tbItemContent[2] = "          [<color=yellow>"..nLevel.."<color>] "..tbSet[i][j][nLevel].szName
				if (#tbSet[i][j] == nLevel) then
					tbItemContent[3] = "               <color=yellow>Cấp cao nhất<color>"
				else
					tbItemContent[3] = "                         <color=yellow>"..me.GetReputeValue(i, j, nLevel).."<color> / "..tbSet[i][j][nLevel].nLevelUp
				end
				if nLevel == 1 and me.GetReputeValue(i, j, nLevel) == 0 then
					AddOutLookItem(self.UIGROUP, OUTLOOK_REPUTE, 1, tbItemContent)
				else
					AddOutLookItem(self.UIGROUP, OUTLOOK_REPUTE, 0, tbItemContent)
				end
			end
		end
	end
	Wnd_SetEnable(self.UIGROUP, BTN_ACTIVE_TITLE,	0)
	Wnd_SetEnable(self.UIGROUP, BTN_INACTIVE_TITLE,	0)
end