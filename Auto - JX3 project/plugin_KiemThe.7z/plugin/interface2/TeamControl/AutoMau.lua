--Lấy máu: tống kim - tranh đoạt--
local self = AutoMau

local tbAutoMau = Map.tbAutoMau or {};
Map.tbAutoMau = tbAutoMau;

local n = 2

local loadLayMau1 = 0
local loadLayMau2 = 0

local nTimerM1 = 0
local nTimerM2 = 0

--[[local szCmd = [=[
	Map.tbAutoMau:LayMau1Switch();
]=];

function tbAutoMau:LayMau1Switch()
	if loadLayMau1 == 0 then
		loadLayMau1 = 1;
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=pink><color=white>Bật Tự lấy rương máu chiến trường [Shift+1]<color>");
		me.Msg("<color=yellow>Tụ bật<color>");
		nTimerM1 = Ui.tbLogic.tbTimer:Register(1 * Env.GAME_FPS,self.GoToLayMau1,self);
	else
		loadLayMau1 = 0;
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tắt Tự lấy rương máu chiến trường [Shift+1]<color>");
		me.Msg("<color=yellow>Tự tắt<color>");
		Ui.tbLogic.tbTimer:Close(nTimerM1);
		nTimerM1 = 0;
	end
end

function tbAutoMau:GoToLayMau1()
	local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
	local tbAroundNpc	= KNpc.GetAroundNpcList(me, 100);
	for _, pNpc in ipairs(tbAroundNpc) do
	if (me.GetItemCountInBags(18,1,59,1) < n) and (me.GetItemCountInBags(18,1,60,1) < n) and (me.GetItemCountInBags(18,1,61,1) < n) then
		if   (me.GetMapTemplateId()==182) or (me.GetMapTemplateId()==185) or (me.GetMapTemplateId()==1635) or (me.GetMapTemplateId()==1636) or (me.GetMapTemplateId()==1637) or (me.GetMapTemplateId()==1638) or (me.GetMapTemplateId()==1639) or (me.GetMapTemplateId()==1640) or (me.GetMapTemplateId()==1641) or (me.GetMapTemplateId()==1642) or (me.GetMapTemplateId()==1643) or (me.GetMapTemplateId()==20000) or (me.GetMapTemplateId()==20001) or (me.GetMapTemplateId()==20002) or (me.GetMapTemplateId()==20003) or (me.GetMapTemplateId()==20004) or (me.GetMapTemplateId()==20005) or (me.GetMapTemplateId()==20006) or (me.GetMapTemplateId()==20007) or (me.GetMapTemplateId()==20008) or (me.GetMapTemplateId()==20009) or (me.GetMapTemplateId()==20010) or (me.GetMapTemplateId()==20011) or (me.GetMapTemplateId()==20012) or (me.GetMapTemplateId()==20013) or (me.GetMapTemplateId()==20014) then
			me.Msg("<color=pink>Đây có phải là nơi có máu đâu<color>");
			loadLayMau1 = 0;
			UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tự động dừng chương trình !!!");
			Ui.tbLogic.tbTimer:Close(nTimerM1);
			nTimerM1 = 0;		
		else
			if  (pNpc.szName=="Quan Quân Nhu (Tây Hạ)") or (pNpc.szName=="Quan Quân Nhu (Mông Cổ)") then
				AutoAi.SetTargetIndex(pNpc.nIndex);
				UiManager:OpenWindow("UI_INFOBOARD", "<bclr=pink><color=white>Tự lấy rương máu chiến trường bắt đầu [Shift+1]<color>");
				me.AnswerQestion(5)
				me.AnswerQestion(0)
				break;
			end
		end
	else
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
		me.Msg("<color=pink>Nhận rương máu hoàn thành<color>");
		loadLayMau1 = 0;
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tự động dừng chương trình !!!");
		Ui.tbLogic.tbTimer:Close(nTimerM1);
		nTimerM1 = 0;			
		end
	end	
end ]]

local szCmd = [=[
	Map.tbAutoMau:LayMau2Switch();
]=];

function tbAutoMau:LayMau2Switch()
	if loadLayMau2 == 0 then
		loadLayMau2 = 1;
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=pink><color=white>Bật Tự lấy rương máu Lãnh thổ <color>");
		me.Msg("<color=yellow>Tụ bật<color>");
		nTimerM2 = Ui.tbLogic.tbTimer:Register(1 * Env.GAME_FPS,self.GoToLayMau2,self);
	else
		loadLayMau2 = 0;
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tắt Tự lấy rương máu Lãnh thổ <color>");
		me.Msg("<color=yellow>Tự tắt<color>");
		Ui.tbLogic.tbTimer:Close(nTimerM2);
		nTimerM2 = 0;
	end
end

function tbAutoMau:GoToLayMau2()
	local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
	local tbAroundNpc	= KNpc.GetAroundNpcList(me, 500);
	for _, pNpc in ipairs(tbAroundNpc) do
	if (me.GetItemCountInBags(18,1,1783,4) < n) and (me.GetItemCountInBags(18,1,1784,4) < n) and (me.GetItemCountInBags(18,1,1785,4) < n) then
		if me.GetMapTemplateId() < 23 or  me.GetMapTemplateId() > 29 then
			me.Msg("<color=pink>Đây có phải là nơi có máu đâu<color>");
			loadLayMau2 = 0;
			UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tự động dừng chương trình !!!");
			Ui.tbLogic.tbTimer:Close(nTimerM2);
			nTimerM2 = 0;			
		else
			if  (pNpc.szName=="Quan Lãnh Thổ") or (pNpc.nTemplateId == 3406) then
				UiManager:OpenWindow("UI_INFOBOARD", "<bclr=pink><color=white>Tự lấy rương máu Lãnh thổ bắt đầu<color>");
				--AutoAi.SetTargetIndex(pNpc.nIndex);
				--me.AnswerQestion(0)
				--me.AnswerQestion(0)
				--me.AnswerQestion(0)
				--me.AnswerQestion(0)
				--me.AnswerQestion(0)
				if  me.nFaction ~= 9 then
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,3406,Quân nhu Lãnh thổ chiến,2,1"});
					--me.AnswerQestion(0)
					--me.AnswerQestion(0)
					--me.AnswerQestion(0)
				break;
				else
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,3406,Quân nhu Lãnh thổ chiến,2,3"});
					--me.AnswerQestion(2)
					--me.AnswerQestion(0)
					--me.AnswerQestion(0)
				end
			end
		end	
	else
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
		loadLayMau2 = 0;
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tự động dừng chương trình !!!");
		me.Msg("<color=pink>Nhận rương máu thành công<color>");
		SendChannelMsg("NearBy", "<color=pink>Lấy máu xong rồi, chiến thôi<pic=82>");
		Ui.tbLogic.tbTimer:Close(nTimerM2);
		nTimerM2 = 0;			
		end
	end	
end 

-------------------------------------------end---------------------------------------------------
local --[[tCmd={"Map.tbAutoMau:LayMau1Switch()", "LayMau1", "", "Shift+1", "Shift+1", "LayMau1"};
	AddCommand(tCmd[4], tCmd[3], tCmd[2], tCmd[7] or UiShortcutAlias.emKSTATE_INGAME);
	UiShortcutAlias:AddAlias(tCmd[2], tCmd[1]);]]
	
	tCmd={"Map.tbAutoMau:LayMau2Switch()", "LayMau2", "", "Shift+4", "Shift+4", "LayMau2"};
	AddCommand(tCmd[4], tCmd[3], tCmd[2], tCmd[7] or UiShortcutAlias.emKSTATE_INGAME);
	UiShortcutAlias:AddAlias(tCmd[2], tCmd[1]);