----------------------chỉnh sửa bởi Mr.DUY---------------------


local tbMember	= Map.tbMember or {}; 
Map.tbMember	= tbMember;


local GuessSwitch = 1;
local Guess2Switch = 1;
local TeamLeaderGetBox=0;

local MainPlayer="";


local nChoseTime=0.6;
local tbMsgInfo = Ui.tbLogic.tbMsgInfo;
local nCheckMap1TimerId=0;
local nCheckMap2TimerId=0;
local nCheckMap3TimerId=0;
local nChose3TimerId=0;
local nAutoTaskTimerId=0;
local i,j,k,a,b,c

function tbMember:ModifyUi()
	local uiMsgPad =Ui(Ui.UI_MSGPAD)
	tbMember.Say_bak	= tbMember.Say_bak or Ui(Ui.UI_MSGPAD).OnSendMsgToChannel;
	function uiMsgPad:OnSendMsgToChannel(szChannelName, szName, szMsg, szGateway)
		tbMember.Say_bak(Ui(Ui.UI_MSGPAD), szChannelName, szName, szMsg, szGateway);
		local function fnOnSay()			
			tbMember:OnSay(szChannelName, szName, szMsg, szGateway);
			return 0;
		end
		Timer:Register(1, fnOnSay);
	end

end

tbMember.Init =function(self)
	self:ModifyUi();
end

function tbMember:OnSay(szChannelName, szName, szMsg, szGateway)	
	local stype
	if   szChannelName=="Team" then
		stype="Đồng Đội"
	elseif  szChannelName=="Tong" then
		stype="Bang"
	elseif  szChannelName=="Friend" then
		stype="Hảo hữu"
	elseif  szChannelName=="Kin" then
		stype="Gia Tộc"
	elseif  szChannelName=="NearBy" then
		stype="Lân cận"
	end
	
	if (GuessSwitch == 0) then
		return;
	end

	
	if string.find(szMsg,"3") and stype=="Đồng Đội" then
		if me.GetMapTemplateId() < 65500 then
		return
		end
		local tbAroundNpc	= KNpc.GetAroundNpcList(me, 1000);
		for _, pNpc in ipairs(tbAroundNpc) do
			if (pNpc.nTemplateId == 4223) then  
				AutoAi.SetTargetIndex(pNpc.nIndex);
				break;
			end
		end
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Bắt đầu mở Quang Ảnh Thạch");
	elseif string.find(szMsg,"Luyện.:.Công") and stype=="Đồng Đội" then
		me.nPkModel = Player.emKPK_STATE_PRACTISE;
		Ui(Ui.UI_TASKTIPS):Begin("<bclr=red><color=white>Đồng đội gọi bật [Luyện Công]<color>");
		me.Msg("<color=yellow>Đồng đội gọi bật [Luyện Công]<color>")
	end	
	---------------------------He Thong--------------------
	if  string.find(szMsg,"Tất cả bật tự động đánh") and stype=="Đồng Đội" then	
		if me.nAutoFightState ~= 1 then
			AutoAi:UpdateCfg(Ui.tbLogic.tbAutoFightData:ShortKey());
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");	
		end
	end
	
	if  string.find(szMsg,"Tất cả dừng mọi hoạt động") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() > 65500 or Guess2Switch == 1 then
			if me.nAutoFightState == 1 then
			AutoAi:UpdateCfg(Ui.tbLogic.tbAutoFightData:ShortKey());
		end
		Map.tbAutoAim:AutoFollowStop();
		UiManager:StopBao();
		return;
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
	if  string.find(szMsg,"Tất cả bật hộ tống") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() > 65500 or Guess2Switch == 1 then
		Map.tbAutoAim:AutoFollowStart();
				return;
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
	-------------------------HLVM------------------------
	if  string.find(szMsg,"VAOHL") or string.find(szMsg,"Anh em Vào HLVM nào!!") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() == 24 or me.GetMapTemplateId() == 25 or me.GetMapTemplateId() == 29 then
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,4038,3,2"});
		else
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",29,4038,3,2"});
			return;			
		end
	end
	
		----------------------BMS-------------------------
	if  string.find(szMsg,"VAOBMS") or string.find(szMsg,"Anh em Vào BMS nào!!") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() == 24 or me.GetMapTemplateId() == 25 or me.GetMapTemplateId() == 29 then
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,4038,2,2"});
		else
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",29,4038,2,2"});
			return;
		end
	end
	
		
	if  string.find(szMsg,"Anh em Rời khỏi BMS nào!!") or string.find(szMsg,"QUITBMS") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() < 65500 then
			me.Msg("<color=lightgreen>Chỉ hoạt động trong Bách Man Sơn!");
			return;
		else 
				Map.tbTeamControl:QuitBMS();
		end
	end
	
	
	--------------------------------HPNS-------------------------
	if  string.find(szMsg,"VAOHS") or string.find(szMsg,"Anh em Vào HSPN nào!!") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() == 24 or me.GetMapTemplateId() == 25 or me.GetMapTemplateId() == 29 then
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,4038,1,2"});
		else
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",29,4038,1,2"});
		end
	end
	
	-------------------------------Khác--------------------------
	if  string.find(szMsg,"Anh em vào TDC 2 nào!!") and stype=="Đồng Đội" then	
		
Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",23,3237,2"});
		return;
	
	end
	
	if  string.find(szMsg,"Anh em lấy rương máu TDC nào!!") and stype=="Đồng Đội" then	
	if Guess2Switch == 1 then
			if me.nFaction ~= 9 then
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,3234,Nhận thuốc miễn phí hôm nay,1"});
			else
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,3234,Nhận thuốc miễn phí hôm nay,3"});
			end
		return;
		else 
			me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
	if  string.find(szMsg,"Anh em mở rương máu TDC nào!!") and stype=="Đồng Đội" then	
	AutoAi:MoRuongThuocPL();
--AutoAi:MoRuongThuocTDC1();
		return;
		
	end
	
	if  string.find(szMsg,"Trả máu Phúc Lợi!!") and stype=="Đồng Đội" then	
	AutoAi:TraRuongThuocPL();	
--AutoAi:TraRuongThuocTDC();
		return;
		
	end
		
	if  string.find(szMsg,"canmdt") or string.find(szMsg, "Anh em cán Lak Ma Đao Thạch cấp 7 nào!!") and stype=="Đồng Đội" then	
	if Guess2Switch == 1 then
		local tbFind = me.FindItemInBags(18,1,66,7); -- ma dao thach c7
		for j, tbItem in pairs(tbFind) do
			me.UseItem(tbItem.pItem);
			SendChannelMsg("Team", "Đã cắn Ma Đao Thạch");
		end
	else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
	end
end
	
	--------BHD lien server-------
	if  string.find(szMsg,"Anh em vào BHĐ Liên Server nào!!") and stype=="Đồng Đội" then	
			if (me.GetMapTemplateId() > 22) and  (me.GetMapTemplateId() < 30) then
	Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,2654,1,1"});
			else
	Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",29,2654,1,1"});		
		return;
			end
	end
	
	
if  string.find(szMsg,"Anh em đi ghép HT nào!!") and stype=="Đồng Đội" then	
	Ui(Ui.UI_COMPOSE):SwitchCompose();
--UiManager:hexuan();
		return;
		
	end
	
if  string.find(szMsg,"Anh em chạy BVĐ nào!!") and stype=="Đồng Đội" then	
		--tbSuperBao.Started();
		UiManager:StartBao();

		return;
		
	end
	---mộng cảnh---
if  string.find(szMsg,"Anh em vào Mộng Cảnh thôi!!!") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
			Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",24,20178,Vào mộng cảnh Phó Thụy Lỗi"});
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
if  string.find(szMsg,"Anh em rời khỏi Mộng Cảnh thôi!!!") and stype=="Đồng Đội" then	
		if me.GetMapTemplateId() < 65500 then
			me.Msg("<color=lightgreen>Chỉ Hoạt động trong Mộng Cảnh");
		else 
				Map.tbvCTTK:CTTK4Switch();
				
		end
	end
if  string.find(szMsg,"Anh Em ơi Train trong Mộng Cảnh!!!") and stype=="Đồng Đội" then	
		 
				Map.tbvCTTK:CTTK5Switch();
		
	end
	------------------- Lâu Lan Cổ Thành ---------
	if  string.find(szMsg,"roilaulan") and stype=="Đồng Đội" then	
		 
				Map.tbvCTTK:CTTK7Switch();
		
	end
	----------- phi thiên lệnh-----------
	if  string.find(szMsg,"aephithien") and stype=="Đồng Đội" then	
		 
				Ui(Ui.UI_PhiThienLenh).Switch();
		
	end
	--------------- Thời quang lệnh -------------
	if  string.find(szMsg,"lbtql") and stype=="Đồng Đội" then	
		 
		Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,2711,7,1,1"});
		
	end
	if  string.find(szMsg,"nvtql") and stype=="Đồng Đội" then	
		 
		Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",132,9615,[Thế giới]Địa cung thần bí"});
		
	end
	if  string.find(szMsg,"vaotql") and stype=="Đồng Đội" then	
		 
		Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",132,9615,Ta muốn hỏi chuyện khác,1,1"});
		
	end
	if  string.find(szMsg,"roitql") and stype=="Đồng Đội" then	
		 
			Map.tbvCTTK:CTTK8Switch();
		
	end
	------------------ VAGT + nhận thưởng ------
	if  string.find(szMsg,"Anh Em ơi Vào Ải gia tộc chơi đê!!!") and stype=="Đồng Đội" then	
			Map.tbAutoXuyenSon:MaXSSwitch();
		
	end
	
	if  string.find(szMsg,"Anh em đi đổi tiền nào!!!") and stype=="Đồng Đội" then	
		 
				Map.tbAutoXuyenSon:MrXSSwitch();
	end	
	
	if  string.find(szMsg,"Xong ải gia tộc rồi ra thôi!!!") and stype=="Đồng Đội" then
				Map.tbvCTTK:CTTK6Switch();
			
	end
	
	if  string.find(szMsg,"Anh em vào lãnh địa gia tộc nào !!") and stype=="Đồng Đội" then	
		Ui(Ui.UI_TULUYENCHAU):State1()
			
	end
	
	if  string.find(szMsg,"Anh em rời khỏi lãnh địa gia tộc nào !!") and stype=="Đồng Đội" then	
			me.CallServerScript({"UseUnlimitedTrans", 6}); 
			
	end
	
	if  string.find(szMsg,"aetrongcay") and stype=="Đồng Đội" then	
			Map.tbKinZhongZhi:Switch();
			
	end
	
	-----------------báo boss---
	if  string.find(szMsg,"Anh em bật/tắt báo boss nào!!") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
			Map.uiDetector:Switch();	
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	------------- vứt nguyên liệu TDC ----------
	if string.find(szMsg,"Anh em xả rác nào <pic=94>!!!") and stype=="Đồng Đội" then
if Guess2Switch == 1 then
AutoAi:SwitchAutoThrowAway3();
return;
else
me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
end
end
	
	-----------------TĐLT-------------------
    if  string.find(szMsg,"Anh em lấy rương máu TDLT nào!!") and stype=="Đồng Đội" then
       Map.tbAutoMau:LayMau2Switch();
	end
	
	if  string.find(szMsg,"Anh em nhận Lak TDLT nào!!") or string.find(szMsg,"laktd") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
			Ui(Ui.UI_LAKLANHTHO):State();
		else 
			me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
	if  string.find(szMsg,"canlak") or string.find(szMsg, "Anh em cắn Lak TDLT nào!!") and stype=="Đồng Đội" then	
	if Guess2Switch == 1 then
		local tbFind = me.FindItemInBags(18,1,321,1); -- lak tdlt tieu
		for j, tbItem in pairs(tbFind) do
			me.UseItem(tbItem.pItem);
			SendChannelMsg("Team", "Đã cắn Lak Tiểu");
		end
		local tbFind = me.FindItemInBags(18,1,322,2); -- lak tdlt trung
		for j, tbItem in pairs(tbFind) do
			me.UseItem(tbItem.pItem);
			SendChannelMsg("Team", "Đã cắn Lak Trung");
		end
		local tbFind = me.FindItemInBags(18,1,323,3); -- lak tdlt dai
		for j, tbItem in pairs(tbFind) do
			me.UseItem(tbItem.pItem);
			SendChannelMsg("Team", "Đã cắn Lak Đại");
		end
	else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
	end
end

if  string.find(szMsg,"Nhận thưởng TDLT mau thôi") and stype=="Đồng Đội" then	
				tbMember:ThuongTD();
	end
if  string.find(szMsg,"Anh em nhan,tra nv hiep khach nao!!") and stype=="Đồng Đội" then	
		
Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",29,7346,1,1"});
		return;
		
	end	
	if  string.find(szMsg,"Anh em lấy rương máu Tống Kim!!") and stype=="Đồng Đội" then	
		
			tbMember:LayRuongTK();
		
	end
	
	if  string.find(szMsg,"Anh em mở rương máu Tống Kim!!") and stype=="Đồng Đội" then	
		AutoAi:MoRuongThuocPL();
		return;
		else 
	end
	if  string.find(szMsg,"Anh em mở rương máu Phúc Lợi!!") and stype=="Đồng Đội" then	
		AutoAi:MoRuongThuocPL();
		return;
		
	end
	-------------TK-----------
	if  string.find(szMsg,"Anh em vào MÔNG CỔ nào") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
	Map.tbvCTTK:CTTK1Switch()
		return;
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
if  string.find(szMsg,"Anh em vào TÂY HẠ nào") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
	Map.tbvCTTK:CTTK2Switch()
		return;
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end
	
------LMPK---
if  string.find(szMsg,"Anh em vào Hầm LMPK thôi!!!") and stype=="Đồng Đội" then	
		if Guess2Switch == 1 then
Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",0,2711,4,1"});
		return;
		else 
		me.Msg("<color=lightgreen>Phải bật hỗ trợ PT [Alt+N] mới sử dụng được");
		end
	end

if string.find(szMsg,"Đi qua nào !!!") then--diem truyen tong
    local s=szMsg;
    self:OpenPanel();
    Timer:Register(Env.GAME_FPS*nChoseTime,self.Chose);
    end 

function tbMember:OpenPanel()
local tbAroundNpc = KNpc.GetAroundNpcList(me, 200);
for _, pNpc in ipairs(tbAroundNpc) do
if pNpc.szName=="Điểm truyền tống" then
AutoAi.SetTargetIndex(pNpc.nIndex)
end
end
return 0;
end

function tbMember:Chose()
local nId = tbMember:GetAroundNpcId(4210)
if nId then
return
end
if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 and me.GetMapTemplateId() > 65500 then
me.AnswerQestion(0);
me.AnswerQestion(0);
UiManager:CloseWindow(Ui.UI_SAYPANEL);
end
return 0
end


	------------mua mau--------------------------------------------
	if  string.find(szMsg,"Anh em đi mua máu nào!!") and stype=="Đồng Đội" then	
		
			tbMember:MuaMau();
		
	end
	
	
	
	if  string.find(szMsg,"Anh em đi mua thức ăn!!") and stype=="Đồng Đội" then	
		
			tbMember:MuaCai1();
		
	end
	---------------------------------------------
	if  string.find(szMsg,"Tất cả bật tự buff") and stype=="Đồng Đội" then
	Map.tbAutoAsist:Asistswitch();
	Map.tbAutoAim:AutoFollowStart();
	end
	-------------------------------het---------------------------
	
	
	
	

end







function tbMember:AutoTask()	
	if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
		me.AnswerQestion(0);		
		UiManager:CloseWindow(Ui.UI_SAYPANEL)
	elseif
		UiManager:WindowVisible(Ui.UI_GUTAWARD) == 1 then
		local uiGutAward = Ui(Ui.UI_GUTAWARD);		
		uiGutAward.OnButtonClick(uiGutAward,"zBtnAccept");
	end
end




function tbMember:Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end



	local BDStart     = 0;
	local nBDTimerId = 0;
	local nBDTime    = 0.5;
	local nBDState   = 0;
	function tbMember:OnBDTimer()
		if (nBDState == 0) then
		return 0
		end
		local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
		local tbAroundNpc	= KNpc.GetAroundNpcList(me, 1000);
			for _, pNpc in ipairs(tbAroundNpc) do		
				if (pNpc.nTemplateId == 2503) then  	
				AutoAi.SetTargetIndex(pNpc.nIndex)
				me.AnswerQestion(0);
				me.AnswerQestion(0);
				break;
				elseif (pNpc.nTemplateId == 2506) then  	
				AutoAi.SetTargetIndex(pNpc.nIndex)
				me.AnswerQestion(0);
				me.AnswerQestion(0);
				break;
			
				end
			
			
			end
			if  (me.GetMapTemplateId() > 185) or (me.GetMapTemplateId() < 182) then
				tbMember:AutoBD();
				AutoAi.SetTargetIndex(0)
				if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
				UiManager:CloseWindow(Ui.UI_SAYPANEL);
				end
			end
	end	

function AutoAi:MoRuongThuocTK()
	
	local tbSetting = Map.tbTeamControl:Load(Map.tbTeamControl.DATA_KEY) or {};
	local nFreeNum = tonumber (tbSetting.nFreeBag) or 2
	local nPlanNum = tonumber (tbSetting.nNeedB) or 100; 
	local nCountFree = me.CountFreeBagCell();
	local nDangCo = (me.GetItemCountInBags(17,6,1,2) + me.GetItemCountInBags(17,6,3,2)) ;	
	if ((nCountFree - nFreeNum) > (nPlanNum - nDangCo)) then
		nPlanNum = (nPlanNum - nDangCo);
		else
		nPlanNum = (nCountFree - nFreeNum) ;
	end	
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật Mở rương thuốc TK<color>");
				local tbFind = me.FindItemInBags(18,1,59,1)[1] or me.FindItemInBags(18,1,62,1)[1] or me.FindItemInBags(18,1,56,1)[1] or me.FindItemInBags(18,1,61,1)[1];
	if not tbFind then
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=White>Hành trang không có rương thuốc TK<color>");
	else
		local pItem = tbFind.pItem;
		local g = pItem.nGenre;
		local d = pItem.nDetail;
		local p = pItem.nParticular;
		local l = pItem.nLevel;
		AutoAi:StartMoRuongThuoc(g,d,p,l,nPlanNum);
	end
end

function AutoAi:MoRuongThuocTDC1()
	 
	local tbSetting = Map.tbTeamControl:Load(Map.tbTeamControl.DATA_KEY) or {};
	local nFreeNum = tonumber (tbSetting.nFreeBag) or 2
	local nPlanNum = tonumber (tbSetting.nNeedB) or 100; 
	local nCountFree = me.CountFreeBagCell();
	local nDangCo = me.GetItemCountInBags(17,8,1,3);	
	if ((nCountFree - nFreeNum) > (nPlanNum - nDangCo)) then
		nPlanNum = (nPlanNum - nDangCo);
		else
		nPlanNum = (nCountFree - nFreeNum) ;
	end	
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật Mở rương thuốc Tiêu Dao Cốc<color>");
				local tbFind = me.FindItemInBags(18,1,352,1)[1] or me.FindItemInBags(18,1,352,2)[1] or me.FindItemInBags(18,1,352,3)[1]
							or me.FindItemInBags(18,1,354,1)[1] or me.FindItemInBags(18,1,354,2)[1] or me.FindItemInBags(18,1,354,3)[1]
							or me.FindItemInBags(18,1,59,1)[1] or me.FindItemInBags(18,1,353,2)[1] or me.FindItemInBags(18,1,353,3)[1];
	if not tbFind then
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=White>Hành trang không có rương thuốc Tiêu Dao Cốc<color>");
	else
		local pItem = tbFind.pItem;
		local g = pItem.nGenre;
		local d = pItem.nDetail;
		local p = pItem.nParticular;
		local l = pItem.nLevel;
		AutoAi:StartMoRuongThuoc(g,d,p,l,nPlanNum);
	end
end

function AutoAi:MoRuongThuocTDLT1()
	
	local tbSetting = Map.tbTeamControl:Load(Map.tbTeamControl.DATA_KEY) or {};
	local nFreeNum = tonumber (tbSetting.nFreeBag) or 2
	local nPlanNum = tonumber (tbSetting.nNeedB) or 100; 
	local nCountFree = me.CountFreeBagCell();
	local nDangCo = me.GetItemCountInBags(17,7,1,2);	
	if ((nCountFree - nFreeNum) > (nPlanNum - nDangCo)) then
		nPlanNum = (nPlanNum - nDangCo);
		else
		nPlanNum = (nCountFree - nFreeNum) ;
	end	
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật Mở rương thuốc TDLT<color>");
				local tbFind = me.FindItemInBags(18,1,273,3)[1] or me.FindItemInBags(18,1,273,2)[1] or me.FindItemInBags(18,1,273,1)[1] or me.FindItemInBags(18,1,20111,1)[1] or me.FindItemInBags(18,1,481,1)[1];
	if not tbFind then
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=White>Hành trang không có rương thuốc TDLT/CTC<color>");
	else
		local pItem = tbFind.pItem;
		local g = pItem.nGenre;
		local d = pItem.nDetail;
		local p = pItem.nParticular;
		local l = pItem.nLevel;
		AutoAi:StartMoRuongThuoc(g,d,p,l,nPlanNum);
	end
end

function AutoAi:MoRuongThuocPL()
	local tbSetting = Map.tbTeamControl:Load(Map.tbTeamControl.DATA_KEY) or {};
	local nFreeNum = tonumber (tbSetting.nFreeBag) or 2
	local nPlanNum = tonumber (tbSetting.nNeedB) or 100; 
	local nCountFree = me.CountFreeBagCell(); 
	local nDangCo = (me.GetItemCountInBags(17,13,1,4) + me.GetItemCountInBags(17,13,3,4)) ;	
	if ((nCountFree - nFreeNum) > (nPlanNum - nDangCo)) then
		nPlanNum = (nPlanNum - nDangCo);
		else
		nPlanNum = (nCountFree - nFreeNum) ;
	end	
	local tbFindp	= {1783, 1784, 1785, 20111};
	local tbFindl	= {1, 2, 3, 4, 5};
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật Mở rương thuốc Phúc lợi<color>");
	for _, nFindp in ipairs(tbFindp) do
		for _, nFindl in ipairs(tbFindl) do
			local tbFind = me.FindItemInBags(18,1,nFindp,nFindl)[1];
			if tbFind then
				local pItem = tbFind.pItem;
				local g = pItem.nGenre;
				local d = pItem.nDetail;
				local p = pItem.nParticular;
				local l = pItem.nLevel;
				AutoAi:StartMoRuongThuoc(g,d,p,l,nPlanNum);
			end
		end
	end
end


function AutoAi:TraRuongThuocPL()
	local nPlanNum = (me.GetItemCountInBags(17,13,1,4) + me.GetItemCountInBags(17,13,3,4)) ; 
	local tbFindp	= {1783, 1784, 1785};
	local tbFindl	= {1, 2, 3, 4, 5};
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật trả rương thuốc Phúc lợi<color>");
	for _, nFindp in ipairs(tbFindp) do
		for _, nFindl in ipairs(tbFindl) do
			local tbFind = me.FindItemInBags(18,1,nFindp,nFindl)[1];
			if tbFind then
				local pItem = tbFind.pItem;
				local g = pItem.nGenre;
				local d = pItem.nDetail;
				local p = pItem.nParticular;
				local l = pItem.nLevel;
				AutoAi:StartTraRuongThuoc(g,d,p,l,nPlanNum);
			end
		end
	end
end
	---------------------------------------------bao danh TK----------------------------------------
	function tbMember:AutoBD()
	if nBDState == 0 and (me.GetMapTemplateId() > 181) and (me.GetMapTemplateId() < 186) then 
		nBDState = 1; 
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=yellow>Bật chức năng bao danh TK");
		nBDTimerId = Timer:Register(Env.GAME_FPS * nBDTime, self.OnBDTimer, self);
	else
		nBDState = 0;
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Tắt chức năng bao danh TK");
		Timer:Close(nBDTimerId);
	end
end

function tbMember:AutoBDStart()
	if self.nBDState == 0 then
		tbMember:AutoBD();
	end
end

function tbMember:AutoBDStop()
	if self.nBDState == 1 then
		tbMember:AutoBD();
	end
end
tbMember.GetAroundNpcId = function(self,nTempId)
	local tbAroundNpc	= KNpc.GetAroundNpcList(me,1000);
	for _, pNpc in ipairs(tbAroundNpc) do
		if (pNpc.nTemplateId == nTempId) then
			return pNpc.nIndex
		end
	end
	return
end
-------------------------------


tbMember.ThuongTD=function(self)
	self.nTimerRegisterId	= Ui.tbLogic.tbTimer:Register(20, 1, self.OnTimer_ThuongTD, self);
end

tbMember.OnTimer_ThuongTD = function(self)
	local nId =  tbMember:GetAroundNpcId(3406)
				
	if nId then
		Ui.tbLogic.tbTimer:Close(self.nTimerRegisterId);
		tbMember:ThuongTD1()
		return 0
	
	else
	tbMember:fnfindNpc(3406,"Quan Lãnh Thổ");
	return 0
	end
end

tbMember.ThuongTD1=function(self)
	
	local nId =  tbMember:GetAroundNpcId(3406) 		
	
	if nId then
		AutoAi.SetTargetIndex(nId);
		
			local function CloseWindow2()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
			UiManager:CloseWindow(Ui.UI_SAYPANEL);
			end
			return 0
			end
		local function fnCloseSay()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
				
							me.AnswerQestion(1);
							me.AnswerQestion(0);
							me.AnswerQestion(0);
							--me.AnswerQestion(0);
							--me.AnswerQestion(0);
							--me.AnswerQestion(0);me.AnswerQestion(0);
							--me.AnswerQestion(0);
							--me.AnswerQestion(0);
							--me.AnswerQestion(0);
				
				Ui.tbLogic.tbTimer:Register(20, CloseWindow2);
			return 0;
			end
		end
		Ui.tbLogic.tbTimer:Register(36, fnCloseSay);
	end
end

------------------------------------
tbMember.LayRuongTK=function(self)
	self.nTimerRegisterId	= Ui.tbLogic.tbTimer:Register(20, 1, self.OnTimer_LayRTK, self);
end

tbMember.OnTimer_LayRTK = function(self)
	local nId =  tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
				
	if nId then
		Ui.tbLogic.tbTimer:Close(self.nTimerRegisterId);
		tbMember:LayRuongTK1()
		return 0
	elseif me.GetMapTemplateId() == 182 then
					if me.nFaction ~= 9 then
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",182,2504,6,1"});
					return 0
					else
					Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",182,2504,6,3"});
					return 0
					end
	elseif me.GetMapTemplateId() == 185 then
					if me.nFaction ~= 9 then
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",185,2507,6,1"});
					return 0
					else
				Map.tbSuperMapLink:StartGoto({szType = "npcpos", szLink = ",185,2507,6,3"});
					return 0
						end
	else
	me.Msg("<color=pink>không tìm thấy quan quân nhu tống kim");
	return 0
	end
end




tbMember.LayRuongTK1=function(self)
	
	local nId =  tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
	local cId = 0
		if me.nFaction == 9 then
		cId = 2
		end
	
	if nId then
		AutoAi.SetTargetIndex(nId);
		
			local function CloseWindow2()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
			UiManager:CloseWindow(Ui.UI_SAYPANEL);
			end
			return 0
			end
		local function fnCloseSay()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
				
							me.AnswerQestion(5);
							me.AnswerQestion(cId);
					
							
					
				Ui.tbLogic.tbTimer:Register(15, CloseWindow2);
			return 0;
			end
		end
		Ui.tbLogic.tbTimer:Register(36, fnCloseSay);
	end
end
----------------------------------------------------------------

tbMember.MuaMau=function(self)
	self.nTimerRegisterId	= Ui.tbLogic.tbTimer:Register(20, 1, self.OnTimer_Mau, self);
end

tbMember.OnTimer_Mau = function(self)
		local nId = tbMember:GetAroundNpcId(3564) or tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
				or tbMember:GetAroundNpcId(7373) or tbMember:GetAroundNpcId(2443) or tbMember:GetAroundNpcId(2447)
		if nId then
		Ui.tbLogic.tbTimer:Close(self.nTimerRegisterId);
		tbMember:MuaMau1();
		return 0
	else
		Map.tbMember:fnfindNpc(3564,"Trương Trảm Kinh");
		return
	end
end


function tbMember:MuaMau1()
			local nBac
			local uId = 680
			if me.nFaction == 9 then      --武当 
			uId = 690;  -- 690 五花玉露丸
			end
			local nHPLvId
			local tbSetting = Map.tbTeamControl:Load(Map.tbTeamControl.DATA_KEY) or {};
			local nFreeNum = tonumber (tbSetting.nFreeBag) or 2
			local nCBuyHP = tonumber (tbSetting.nNeedB) or 50
			local nCountFree = me.CountFreeBagCell();	
			local nBacE = 0;			
			local nId = tbMember:GetAroundNpcId(3564) or tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
				or tbMember:GetAroundNpcId(7373) or tbMember:GetAroundNpcId(2443) or tbMember:GetAroundNpcId(2447)
				if (nCountFree > nFreeNum) then
					if nId   then
						AutoAi.SetTargetIndex(nId);	
						local function fnbuy()
							local nCountHP = (me.GetItemCountInBags(17,1,1,5) + me.GetItemCountInBags(17,3,1,5));
							if nCountHP < nCBuyHP then
								if ((nCountFree - nFreeNum) > (nCBuyHP - nCountHP)) then
									local bOK, szMsg = me.ShopBuyItem(uId, nCBuyHP - nCountHP);
								else
									local bOK, szMsg = me.ShopBuyItem(uId, nCountFree - nFreeNum);
								end
							end
							UiNotify:OnNotify(UiNotify.emUIEVENT_REPAIREXALL_SEND);
							if UiManager:WindowVisible(Ui.UI_SHOP) == 1 then
							UiManager:CloseWindow(Ui.UI_SHOP);
							end
							
						return 0
						end
						local function CloseWindow3()
							if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
							UiManager:CloseWindow(Ui.UI_SAYPANEL);
							end
						return 0
						end
						local function fnCloseSay3()
							if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
								if (me.GetMapTemplateId() > 187) and (me.GetMapTemplateId() < 196) 
								or (me.GetMapTemplateId() > 262) and (me.GetMapTemplateId() < 272)
								or	(me.GetMapTemplateId() > 289) and (me.GetMapTemplateId() < 298)
								or (me.GetMapTemplateId() > 1634) and (me.GetMapTemplateId() < 1644)
								or (me.GetMapTemplateId() > 19999) and (me.GetMapTemplateId() < 20018)
								then
							
								me.AnswerQestion(1);
								else
								me.AnswerQestion(0);
								end
							
								Ui.tbLogic.tbTimer:Register(15, CloseWindow3);
								Ui.tbLogic.tbTimer:Register(40, fnbuy);
								return 0
							end																			
						end
					Ui.tbLogic.tbTimer:Register(36, fnCloseSay3);
					end
				else 
				me.Msg("<color=pink>Đã có đủ thuốc ,ko cần mua ");
				end
end

-------------------------thức ăn-------------------
tbMember.MuaCai1=function(self)
	self.nTimerRegisterId	= Ui.tbLogic.tbTimer:Register(20, 1, self.OnTimer_Cai, self);
end

tbMember.OnTimer_Cai = function(self)
	local nId = tbMember:GetAroundNpcId(3566) or tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
				or tbMember:GetAroundNpcId(7373) or tbMember:GetAroundNpcId(2443) or tbMember:GetAroundNpcId(2447)
	if nId then
		Ui.tbLogic.tbTimer:Close(self.nTimerRegisterId);
		tbMember:MuaCai()
		return 0
	else
	tbMember:fnfindNpc(3566,"Đại lão Bạch");
		return 0;
	end
end




tbMember.MuaCai=function(self)
	print("Bắt đầu mua thức ăn")
	local nId = tbMember:GetAroundNpcId(3566) or tbMember:GetAroundNpcId(2613) or tbMember:GetAroundNpcId(2614)
				or tbMember:GetAroundNpcId(7373) or tbMember:GetAroundNpcId(2443) or tbMember:GetAroundNpcId(2447)
	local nCBuyCai = 3
	if nId then
		AutoAi.SetTargetIndex(nId);
		local function fnMaiCai()
		local nCaiLevel,nCaiID
                                if me.nLevel<30 then
									nCaiLevel=1
                                    nCaiID = 821
								end
								if (me.nLevel> 29) and (me.nLevel<50) then
								nCaiLevel=2
                                  nCaiID = 822
								end
								if (me.nLevel> 49) and (me.nLevel<70) then
								nCaiLevel=3
                                 nCaiID = 823
								end
								if (me.nLevel>69) and (me.nLevel < 90) then
								nCaiLevel =4
								nCaiID = 824
								end
								if me.nLevel >= 90 then
								nCaiLevel = 5
								nCaiID = 825
								end
				local nCount_Cai = me.GetItemCountInBags(19,3,1,nCaiLevel);
				if nCount_Cai < nCBuyCai then
				local pItem = KItem.GetItemObj(825);
				local bOK, szMsg = me.ShopBuyItem(nCaiID, nCBuyCai -nCount_Cai);
				end
				UiNotify:OnNotify(UiNotify.emUIEVENT_REPAIREXALL_SEND);
				if UiManager:WindowVisible(Ui.UI_SHOP) == 1 then
				UiManager:CloseWindow(Ui.UI_SHOP);
				end
		return 0
		end
			local function CloseWindow2()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
			UiManager:CloseWindow(Ui.UI_SAYPANEL);
			end
			return 0
			end
		local function fnCloseSay()
			if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
				if (me.GetMapTemplateId() > 187) and (me.GetMapTemplateId() < 196) 
							or (me.GetMapTemplateId() > 262) and (me.GetMapTemplateId() < 272)
							or	(me.GetMapTemplateId() > 289) and (me.GetMapTemplateId() < 298)
							or (me.GetMapTemplateId() > 1634) and (me.GetMapTemplateId() < 1644)
							or (me.GetMapTemplateId() > 19999) and (me.GetMapTemplateId() < 20018)
							then
							me.AnswerQestion(4);
					elseif 	(me.GetMapTemplateId() == 182) or (me.GetMapTemplateId() == 185)	then
							me.AnswerQestion(3);
					elseif 	(me.GetMapTemplateId() == 1536) or (me.GetMapTemplateId() == 1538) then
							me.AnswerQestion(1);
					else 
						me.AnswerQestion(0);
				end	
				Ui.tbLogic.tbTimer:Register(15, CloseWindow2);
				Ui.tbLogic.tbTimer:Register(40, fnMaiCai);
			return 0;
			end
		end
		Ui.tbLogic.tbTimer:Register(36, fnCloseSay);
	end
end

tbMember.GetAroundNpcId = function(self,nTempId)
	local tbAroundNpc	= KNpc.GetAroundNpcList(me,1000);
	for _, pNpc in ipairs(tbAroundNpc) do
		if (pNpc.nTemplateId == nTempId) then
			return pNpc.nIndex
		end
	end
	return
end
tbMember.fnfindNpc = function(self, nNpcId, szName)
	local nMyMapId	= me.GetMapTemplateId();
	local nTargetMapId;
	if (nMyMapId <30 and nMyMapId >22) or (nMyMapId <9 and nMyMapId >0) then
		nTargetMapId = nMyMapId;
	elseif nCityId then
		nTargetMapId = nCityId
	else
		nTargetMapId = 5
	end
	if (nMyMapId == 556 or nMyMapId == 558 or nMyMapId == 559) and (nNpcId == 3566 or nNpcId == 3564) then 
		nTargetMapId = nMyMapId;
	end

	local nX1, nY1;
	nX1, nY1 = KNpc.ClientGetNpcPos(nTargetMapId, nNpcId);


	local tbPosInfo ={}
	tbPosInfo.szType = "pos"
	tbPosInfo.szLink = szName..","..nTargetMapId..","..nX1..","..nY1
	if (nMyMapId <30 and nMyMapId >22) or (nMyMapId <9 and nMyMapId >0) or nSetPhu == 0 then	
		Ui.tbLogic.tbAutoPath:GotoPos({nMapId=nTargetMapId,nX=nX1,nY=nY1})
	else
		local tbFind = me.FindItemInBags(unpack({18,1,nSetHTPId,1}));
		for j, tbItem in pairs(tbFind) do
			me.UseItem(tbItem.pItem);
			return;
		end
		self.fnfindNpc(nNpcId, szName);
	end	
end

local tCmd={ "Map.tbMember:GuessSwitch()", "GuessSwitch", "", "Alt+M", "Alt+M", "GuessSwitch"};
       AddCommand(tCmd[4], tCmd[3], tCmd[2], tCmd[7] or UiShortcutAlias.emKSTATE_INGAME);
       UiShortcutAlias:AddAlias(tCmd[2], tCmd[1]);	
local tCmd={ "Map.tbMember:Guess2Switch()", "Guess2Switch", "", "Alt+N", "Alt+N", "Guess2Switch"};
       AddCommand(tCmd[4], tCmd[3], tCmd[2], tCmd[7] or UiShortcutAlias.emKSTATE_INGAME);
       UiShortcutAlias:AddAlias(tCmd[2], tCmd[1]);

tbMember:Init();