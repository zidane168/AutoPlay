local RELOAD 		= UiManager;
local ReloadCH		= {};
local tbAutoPath		= Ui.tbLogic.tbAutoPath or {};
local tbScrCallUi	= Ui.tbScrCallUi or {}; 
Ui.tbScrCallUi	= tbScrCallUi;
local self = tbScrCallUi;
local UiScrCallUi = Ui.tbScrCallUi;


---------------------------------------------

local Reload = 0
local nTimer_TienIch = 0

local filereload = {

-------------------------------------------
"\\interface2\\ToolTuDong\\aliasdefine.lua",
-------------------------------------------
}
--[[RELOAD.EnterGame_bak    = RELOAD.EnterGame_bak or Ui.EnterGame;
RELOAD.OnEnterGame_Bak = RELOAD.OnEnterGame_Bak or RELOAD.OnEnterGame;
function RELOAD:OnEnterGame()
	self:OnOpen()
	Map.tbNangDong:Start()
	Ui(Ui.UI_NGUNGCONGDON):Start()	
	self:OpenWindow(Ui.UI_BUTTONE)
	self:OnEnterGame_Bak()
end
function Ui:EnterGame()
	RELOAD.EnterGame_bak(Ui);
	AutoAi:ReLoadCheck()
	self:dotimer();
end]]

local state = 0;
local timer = 0;
local timer1 = 0;
function RELOAD.AutoAlert()
			
end
function RELOAD.AutoAlertGB()
	
end
function RELOAD.dotimer()
	if state == 0 then
		timer = Ui.tbLogic.tbTimer:Register(300,RELOAD.AutoAlert);
		timer1 = Ui.tbLogic.tbTimer:Register(10000,RELOAD.AutoAlertGB);
		state = 1;
	end
	me.Msg("<color=pink>Done");
end

function RELOAD.OnOpen()
	
	if AutoThuongHoi.state and AutoThuongHoi.state == 1 then
		AutoThuongHoi.State()
	end
	
	if NhiemVuChinhTuyen.state and NhiemVuChinhTuyen.state == 1 then
		NhiemVuChinhTuyen.State()
	end
		
	if TuiQuanHuong.state and TuiQuanHuong.State == 1 then
		TuiQuanHuong.State()
	end	
	
	if QuanTroLongMon.state and QuanTroLongMon.state == 1 then
		QuanTroLongMon.State()
	end	
	
	if Train.state and Train.state == 1 then
		Train.Train_State()
	end
	
	if AutoQLT.state and AutoQLT.state == 1 then
		AutoQLT.State()
	end
	
	if AutoLQ.state and AutoLQ.state == 1 then
		AutoLQ.State()
	end
	
	if AutoLQ2.state and AutoLQ2.state == 1 then
		AutoLQ2.State()
	end
	
	if HoaDang.state and HoaDang.state == 1 then	
		HoaDang.State()	
	end
	
	UiManager:CloseWindow(Ui.UI_ITEMBOX);
	UiManager:CloseWindow(Ui.UI_REPOSITORY);
	for i = 1,table.getn(filereload) do
		local str = KIo.ReadTxtFile(filereload[i]);
		if str ~= "" then
			assert(loadstring(str,filereload[i]))()
			me.Msg(tostring("<color=orange>ReLoad : "..filereload[i]))
		else
			me.Msg(tostring("Error:"..filereload[i]))
		end
	end
	
	UiManager:OpenWindow("UI_INFOBOARD", "<bclr=blue><color=yellow>Chúc bạn<color> \<bclr=red><color=white>mạnh khỏe <pic=78><color>");
	UiManager:CloseWindow(Ui.UI_EQUIPENHANCE);	
	UiManager:CloseWindow(Ui.UI_HELPSPRITE);
	UiManager:CloseWindow(Ui.UI_ITEMGIFT);
	UiManager:SwitchWindow(Ui.UI_MINICLOCK);
	UiManager:SwitchWindow(Ui.UI_TOOLSS);
	UiManager:SwitchWindow(Ui.UI_AUTOTOOLS);
	UiManager:CloseWindow(Ui.UI_HELPSPRITE);
	UiManager:CloseWindow(Ui.UI_SYSTEM);
	me.Msg("<bclr=0,0,200><color=white>{-----------------------------------------------------------------}<color><bclr>")
	me.Msg("<bclr=0,0,200><color=white>	ScriptLoad Oke !!!<color><bclr>")	
end

local szCmd	= [=[
		UiManager.OnOpen();
	]=];
UiShortcutAlias:AddAlias("GM_C9", szCmd);

-- tbScrCallUi.Init = function(self)
	-- self:StartGoTo(M,X,Y);
-- end

tbScrCallUi.GetTeamLeader =function(self)
	local nAllotModel, tbMemberList = me.GetTeamInfo();
	if nAllotModel and tbMemberList then
    local tLeader = tbMemberList[1];
    local pNpc = KNpc.GetByPlayerId(tLeader.nPlayerID);
    if(not pNpc or pNpc.szName == me.szName) then
    	return nil;
    end
		return pNpc;
	end
end
tbScrCallUi.TimNPC_TEN = function(self, sName)
	local tbNpcList = KNpc.GetAroundNpcList(me,1000);
	for _, pNpc in ipairs(tbNpcList) do
		if pNpc and pNpc.szName == sName then
			return pNpc
		end
	end
end
tbScrCallUi.TimNPC_ID = function(self, TemplateId)
	local tbEnemyList = {}	
	local tbNpcList = KNpc.GetAroundNpcList(me,1000);
	for _, pNpc in ipairs(tbNpcList) do
		if pNpc and pNpc.nTemplateId == TemplateId then
			table.insert(tbEnemyList,pNpc)			 
		end		
	end
	return 
end
function tbScrCallUi.CloseWinDow()
	if UiManager:WindowVisible(Ui.UI_EQUIPENHANCE) == 1 then
		UiManager:CloseWindow(Ui.UI_EQUIPENHANCE);
	end
	if UiManager:WindowVisible(Ui.UI_SHOP) == 1 then
		UiManager:CloseWindow(Ui.UI_SHOP);
	end
	if UiManager:WindowVisible(Ui.UI_ITEMBOX) == 1 then
		UiManager:CloseWindow(Ui.UI_ITEMBOX);
	end
	if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
	end
	if UiManager:WindowVisible(Ui.UI_ITEMBOX) == 1 then	
		UiManager:CloseWindow(Ui.UI_ITEMBOX);
	end
	if UiManager:WindowVisible(Ui.UI_REPOSITORY) == 1 then
		UiManager:CloseWindow(Ui.UI_REPOSITORY);
	end
end
tbScrCallUi.StopAutoFight= function(self)
	if me.nAutoFightState == 1 then
		AutoAi:UpdateCfg(Ui.tbLogic.tbAutoFightData:ShortKey());
	end	
end
tbScrCallUi.StartAutoFight = function(self)
	if me.nAutoFightState == 0 then
		AutoAi:UpdateCfg(Ui.tbLogic.tbAutoFightData:ShortKey());
	end	
end
local nLastMapId = 0
local nLastMapX = 0 
local nLastMapY = 0
function tbScrCallUi:StartGoTo(M,X,Y)
	if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then
		return
	end
	self:CloseWinDow();
	self:StopAutoFight();
	if me.GetNpc().nIsRideHorse == 0 then
		me.Msg("<color=pink>Tự động lên ngựa")
		Switch("horse")
	end	
	local nMapId,nMyPosX,nMyPosY = me.GetWorldPos()
	if nMapId == M and nMyPosX == X and nMyPosY == Y then		
		-- me.Msg("Đến rồi chạy chi nữa")
		return
	else
		if M ~= 0 and X ~= 0 and Y ~= 0 then
			-- me.Msg("<bclr=blue><color=white>Di chuyển")
			me.Msg("<bclr=0,0,200><color=white>Bước chân <bclr><color><color=white>[<color>"..nMapId.."<bclr=0,0,200><color=white> ,<bclr><color>"..nMyPosX.."<bclr=0,0,200><color=white> ,<bclr><color>"..nMyPosY.."<bclr><color><color=white>]")
			local tbPos = {}
			tbPos.nMapId = M
			tbPos.nX = X
			tbPos.nY = Y
			-- Ui.tbLogic.tbAutoPath:OnMiniMapClick(X, Y, M)			
		else
			if me.GetNpc().nDoing == 6 then
				return
			end
		end
		Ui.tbLogic.tbAutoPath:OnMiniMapClick(X, Y, M)
	end
end

function tbScrCallUi.KhoangCach(myX,myY,keyX,keyY)
	local nDistance	= 0;
	nDistance = math.sqrt((myX-keyX)^2 + (myY-keyY)^2);
	return nDistance;
end

function tbScrCallUi:StartMove(x,y)
	self:CloseWinDow();
	self:StopAutoFight();
	if me.GetNpc().nIsRideHorse == 0 then
		me.Msg("<color=pink>Tự động lên ngựa")
		Switch("horse")
	end
	local nMapId,nMyPosX,nMyPosY = me.GetWorldPos()
	local kc_2d = tbScrCallUi.KhoangCach(x/32,y/32,nMyPosX,nMyPosY)
	if nMyPosX*32 == x and nMyPosY*32 == y then		
		-- me.Msg("Đến rồi chạy chi nữa")
		return
	else
		if x ~= nMyPosX*32 and y ~= nMyPosY*32 then
			if kc_2d > 5 then
				if x > nMyPosX*32 then
					if y > nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) + 160, (nMyPosY*32) + 160)
					elseif y < nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) + 160, (nMyPosY*32) - 160)
					end
				elseif x < nMyPosX*32 then
					if y > nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) - 160, (nMyPosY*32) + 160)
					elseif y < nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) - 160, (nMyPosY*32) - 160)
					end
				end
			else	
				if x > nMyPosX*32 then
					if y > nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) + 96, (nMyPosY*32) + 96)
					elseif y < nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) + 96, (nMyPosY*32) - 96)
					end
				elseif x < nMyPosX*32 then
					if y > nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) - 96, (nMyPosY*32) + 96)
					elseif y < nMyPosY*32 then
						return Env.GAME_FPS * 1, AutoAi.AiAutoMoveTo((nMyPosX*32) - 96, (nMyPosY*32) - 96)
					end
				end
			end
		end
	end
end

function tbScrCallUi.MoveTo(x,y)
	self:CloseWinDow();
	self:StopAutoFight();
	if me.GetNpc().nIsRideHorse == 0 then
		me.Msg("<color=pink>Tự động lên ngựa")
		Switch("horse")
	end
	local _, nX, nY	= me.GetWorldPos();
	local nDx		= x - nX + MathRandom(-5, 5);
	local nDy		= y - nY + MathRandom(-5, 5);
	local nDir		= math.fmod(64 - math.atan2(nDx, nDy) * 32 / math.pi, 64);
	MoveTo(nDir, 0);
end

-- tbScrCallUi:Init();