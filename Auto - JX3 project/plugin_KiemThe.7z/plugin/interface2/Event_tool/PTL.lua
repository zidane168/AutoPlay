	------------------------------Edit By Mr DUY---------------------

local PhiThienLenh = Ui:GetClass("PhiThienLenh") or {}
local nTimerId = 1
local nStatus = 0
local nStartTimer=10
local nNhanDiem=0
local uiSayPanel = Ui(Ui.UI_SAYPANEL)
PhiThienLenh.Say_bak = PhiThienLenh.Say_bak or uiSayPanel.OnOpen

function uiSayPanel:OnOpen(tbParam)
	PhiThienLenh.Say_bak(uiSayPanel,tbParam)
	if(nStatus==0)then
		return
	end	
	for i = 1,table.getn(tbParam[2]) do
		if string.find(tbParam[2][i],"Báo danh và Điểm Năng Động") then
			me.AnswerQestion(i-1)
			break
		end
	end	
	if(nNhanDiem==0)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"Báo Danh") then
				me.AnswerQestion(i-1)
				me.AnswerQestion(0)
				nNhanDiem=1
				PhiThienLenh.Doi_Timer(15)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==1)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"10 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=2
				PhiThienLenh.Doi_Timer(25)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==2)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"20 điểm năng động") then			
				me.AnswerQestion(i-1)
				nNhanDiem=3
				PhiThienLenh.Doi_Timer(35)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==3)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"30 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=4
				PhiThienLenh.Doi_Timer(45)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end
	if(nNhanDiem==4)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"40 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=5
				PhiThienLenh.Doi_Timer(55)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==5)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"50 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=6
				PhiThienLenh.Doi_Timer(65)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==6)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"60 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=7
				PhiThienLenh.Doi_Timer(75)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==7)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"70 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=8
				PhiThienLenh.Doi_Timer(85)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==8)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"80 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=9
				PhiThienLenh.Doi_Timer(95)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
	if(nNhanDiem==9)then
		for i = 1,table.getn(tbParam[2]) do
			if string.find(tbParam[2][i],"90 điểm năng động") then
				me.AnswerQestion(i-1)
				nNhanDiem=10
				PhiThienLenh.Doi_Timer(105)
				break
			end
		end
		PhiThienLenh.CloseWinDows()
		return
	end	
end

function PhiThienLenh.Stop()
	if (nTimerId ~= 1) then
		Ui.tbLogic.tbTimer:Close(nTimerId)
	end
	nTimerId=0
	nStatus=0
end
function PhiThienLenh.Start()
	nTimerId = Ui.tbLogic.tbTimer:Register(nStartTimer,PhiThienLenh.OnTimer)
end
function PhiThienLenh.Status()
	return nStatus
end
function PhiThienLenh.Switch()
	if nStatus == 0 then
		nStatus=1
		PhiThienLenh.Start()
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=Yellow>Bật: Tự nhận điểm Phi Thiên Lệnh<color>");
		me.Msg("<color=green>Bật<color> Tự nhận điểm tích lũy")
	else
		nStatus=0
		PhiThienLenh.Stop()	
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=White>Tắt: Tự nhận điểm Phi Thiên Lệnh<color>");		
		me.Msg("<color=green>Tắt<color> Tự nhận điểm tích lũy")
	end
end
function PhiThienLenh.OnTimer()
	local tbFind = me.FindItemInBags(18,1,20332,1) or me.FindItemInBags(18,1,20333,1)
	local nBaoRuongSuKien=table.getn(tbFind)
	if(nBaoRuongSuKien==0)then
		me.Msg("Không có Lệnh bài trong hành trang!")
		PhiThienLenh.Stop()
		PhiThienLenh.CloseWinDows()
		return
	end
	if (me.nLevel >= 50) then
		if(nNhanDiem==10)then
			nNhanDiem=0			
			PhiThienLenh.CloseWinDows()
			nStatus=0
			PhiThienLenh.Stop()	
			UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=White>Tắt: Tự nhận điểm Phi Thiên Lệnh<color>");		
			me.Msg("<color=green>Tắt<color> Tự nhận điểm tích lũy")
			return
		end
		PhiThienLenh.CloseWinDows()
		if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 0 then
			for j, tbItem in pairs(tbFind) do
				me.UseItem(tbItem.pItem)
			end
		end
	end
end
function PhiThienLenh.Doi_Timer(nTime)
	if nStartTimer ~= nTime then
		Ui.tbLogic.tbTimer:Close(nTimerId);
		nTimerId = Ui.tbLogic.tbTimer:Register(nTime,PhiThienLenh.OnTimer);
		nStartTimer = nTime
	end
end
function PhiThienLenh.CloseWinDows()
	if UiManager:WindowVisible(Ui.UI_GUTAWARD) == 1 then
		local uiGutAward = Ui(Ui.UI_GUTAWARD)
		uiGutAward.OnButtonClick(uiGutAward, "zBtnAccept");
		UiManager:CloseWindow(Ui.UI_GUTAWARD)
	end
	if UiManager:WindowVisible(Ui.UI_SHOP) == 1 then
		UiManager:CloseWindow(Ui.UI_SHOP);
	end
	if UiManager:WindowVisible(Ui.UI_ITEMBOX) == 1 then
		UiManager:CloseWindow(Ui.UI_ITEMBOX);
	end
	if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
		UiManager:CloseWindow(Ui.UI_SAYPANEL);
	end
	if UiManager:WindowVisible(Ui.UI_EQUIPENHANCE) == 1 then
		UiManager:CloseWindow(Ui.UI_EQUIPENHANCE);
	end
end


Ui:RegisterNewUiWindow("UI_PhiThienLenh", "PhiThienLenh", {"a",320,200}, {"b", 250, 150}, {"c", 250, 150});
local tCmd={ "Ui(Ui.UI_PhiThienLenh).Switch()", "PhiThienLenh", "", "Shift+K", "Shift+K", "PhiThienLenh"};
	AddCommand(tCmd[4], tCmd[3], tCmd[2], tCmd[7] or UiShortcutAlias.emKSTATE_INGAME);
	UiShortcutAlias:AddAlias(tCmd[2], tCmd[1]);
	


